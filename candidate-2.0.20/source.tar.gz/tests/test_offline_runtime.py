"""Regression checks for packaged offline entry points and child isolation."""
from __future__ import annotations
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import zipfile

ROOT = Path(__file__).resolve().parents[1]


class OfflineRuntimeTests(unittest.TestCase):
    def test_packaged_child_preserves_isolation_and_ignores_poisoned_pythonpath(self):
        from tools.build_defensive_release import build
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            runtime = build(root)
            poison = root/'poison'
            poison.mkdir()
            (poison/'sitecustomize.py').write_text("raise RuntimeError('system package contamination')\n")
            code = "import sys,json; sys.path.insert(0,sys.argv[1]); sys.argv=[sys.argv[1]]; from sentinel_blue.desktop_jobs import runtime_command; print(json.dumps(runtime_command()))"
            import os
            result = subprocess.run([sys.executable,'-I','-B','-c',code,str(runtime)],
                env=dict(os.environ,PYTHONPATH=str(poison)),capture_output=True,text=True,timeout=15)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertEqual(json.loads(result.stdout),[sys.executable,'-I','-B',str(runtime)])
            version = subprocess.run([*json.loads(result.stdout),'--version'],capture_output=True,text=True,timeout=15)
            self.assertEqual(version.returncode,0,version.stderr)
            from sentinel_blue import __version__
            self.assertIn(__version__,version.stdout)

    def test_nonisolated_source_development_still_resolves_module(self):
        from sentinel_blue.desktop_jobs import runtime_command
        command=runtime_command()
        self.assertEqual(command[0],sys.executable)
        self.assertEqual(command[-2:],['-m','sentinel_blue'])

    def test_launch_refuses_system_python_instead_of_downloading(self):
        # Run under a Python that is not a bundle's own runtime: the bundled one
        # is the interpreter launch.py is meant to accept (and then starts the GUI).
        python=sys.executable
        if Path(python).parent.name=='bin' and Path(python).parent.parent.name=='runtime':
            import shutil
            python=shutil.which('python3',path='/usr/bin:/bin')
            if python is None:
                self.skipTest('needs a system Python; this suite runs under the bundled runtime')
        env = dict(os.environ)
        env.pop('DISPLAY', None)  # This negative test asserts stderr/exit, not a dialog.
        result=subprocess.run([python,'-I','-B',str(ROOT/'packaging/offline/launch.py')],
                              capture_output=True,text=True,timeout=10,env=env)
        self.assertNotEqual(result.returncode,0)
        self.assertIn('fully extracted offline bundle',result.stderr)


if __name__ == '__main__':
    unittest.main()
