"""Offline packaging/source-policy regressions. No host service/network changes."""
import concurrent.futures
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

from sentinel_blue.runtime_environment import (target_runtime, target_python,
    validate_linux_python, host_python, bundled_python)
from sentinel_blue.setup_recipes import compile_recipe

ROOT = Path(__file__).resolve().parents[1]


class OfflinePrerequisites(unittest.TestCase):
    def test_apt_default_is_cache_only(self):
        _, apply, _ = compile_recipe('linux-packages', {'packages':['nginx']},Path('.'),'linux')
        self.assertIn('--no-download',apply);self.assertNotIn(' update',apply)
    def test_dnf_default_is_cache_only(self):
        _, apply, _ = compile_recipe('linux-packages', {'packages':['nginx'],'manager':'dnf'},Path('.'),'linux')
        self.assertIn('--cacheonly',apply);self.assertNotIn('retries=',apply)
    def test_online_package_option_refuses(self):
        for manager in ('apt','dnf'):
            with self.subTest(manager=manager),self.assertRaisesRegex(ValueError,'Offline'):
                compile_recipe('linux-packages',{'packages':['nginx'],'manager':manager,'cache_only':False},Path('.'),'linux')
    def test_cache_mode_must_be_boolean(self):
        for value in (0,1,'true',None):
            with self.subTest(value=value),self.assertRaises(ValueError):
                compile_recipe('linux-packages',{'packages':['nginx'],'cache_only':value},Path('.'),'linux')
    def test_windows_python_never_downloads(self):
        check,apply,_=compile_recipe('windows-python',{'version':'3.13.15','sha256':'a'*64,
            'install_directory':r'C:\ProgramData\SentinelPython'},Path('.'),'windows')
        for forbidden in ('https://','GetAsync','HttpClient','Start-Process'):
            self.assertNotIn(forbidden,apply)
        self.assertIn('Offline prerequisite missing',apply)
        self.assertIn('platform.python_version',check)
    def test_windows_features_never_uses_update(self):
        _,apply,_=compile_recipe('windows-features',{'features':['Web-Server']},Path('.'),'windows')
        self.assertNotIn('Install-WindowsFeature',apply)
        self.assertIn('Offline prerequisite missing',apply)
    def test_package_url_is_refused(self):
        from sentinel_blue.launcher import deployment_plan
        inventory={'authorized_networks':['127.0.0.0/8'],'hosts':[]}
        with self.assertRaisesRegex(ValueError,'local --package'):
            deployment_plan(inventory,'https://example.test/sentinel.pyz')
    def test_local_package_planning_remains_available(self):
        from sentinel_blue.launcher import deployment_plan
        rows=deployment_plan({'authorized_networks':['127.0.0.0/8'],
            'hosts':[{'address':'127.0.0.1','platform':'linux','transport':'local'}]})
        self.assertEqual(len(rows),1)
        self.assertFalse(any('internet' in x for x in rows[0].requires))
    def test_nginx_default_compiles_without_online_prerequisites(self):
        from sentinel_blue.application_setup import linux_nginx
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'index.html';path.write_text('offline fixture')
            options={'name':'offline','listen_address':'127.0.0.1','port':8080,
                'content':{'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}}
            check,apply,_=linux_nginx(options,Path(d))
            self.assertNotIn('apt-get update',apply)
            self.assertIn('prerequisites',apply)
            with self.assertRaisesRegex(ValueError,'Offline'):
                linux_nginx(dict(options,cache_only=False),Path(d))

    def test_router_defaults_to_cached_prerequisites(self):
        from sentinel_blue.network_setup import normalize
        spec=normalize({'name':'offline','management':[{'source':'127.0.0.0/8','port':22}]})
        self.assertIs(spec['cache_only'],True)


class InterpreterBinding(unittest.TestCase):
    def test_absolute_bundle_path_allowed(self):
        self.assertEqual(validate_linux_python('/opt/sentinel-blue-offline/runtime/bin/python3'),'/opt/sentinel-blue-offline/runtime/bin/python3')
    def test_unsafe_interpreters_refused(self):
        for p in ('python3;id','/opt/../bin/python3','/opt/$USER/python3','/opt/python\n3','relative/path','/a/',''):
            with self.subTest(p=p),self.assertRaises(ValueError):validate_linux_python(p)
    def test_space_path_is_literal(self):
        from sentinel_blue.runtime_environment import target_python_shell
        with target_runtime('/opt/Offline Bundle/runtime/bin/python3'):
            self.assertEqual(target_python_shell(),"'/opt/Offline Bundle/runtime/bin/python3'")
    def test_context_resets_after_error(self):
        before=target_python()
        with self.assertRaises(RuntimeError):
            with target_runtime('/opt/bundle/python3'):raise RuntimeError('fixture')
        self.assertEqual(target_python(),before)
    def test_nested_binding_restores_outer(self):
        with target_runtime('/opt/outer/python3'):
            with target_runtime('/opt/inner/python3'):self.assertEqual(target_python(),'/opt/inner/python3')
            self.assertEqual(target_python(),'/opt/outer/python3')
    def test_parallel_targets_do_not_leak(self):
        def worker(path):
            with target_runtime(path):return target_python()
        paths=['/opt/a/python3','/opt/b/python3']*10
        with concurrent.futures.ThreadPoolExecutor(2) as pool:self.assertEqual(list(pool.map(worker,paths)),paths)
    def test_direct_local_helper_defaults_to_own_bundle(self):
        with patch('sentinel_blue.runtime_environment.bundled_python',return_value='/opt/local/runtime/bin/python3'):
            self.assertEqual(target_python(),'/opt/local/runtime/bin/python3')
    def test_withdrawal_uses_local_bundle(self):
        from sentinel_blue.withdrawal import NetworkGuest
        from sentinel_blue.setup_transport import SetupTransport, CommandResult
        from sentinel_blue.mutation_ledger import LedgerError
        with tempfile.TemporaryDirectory() as d:
            transport=SetupTransport()
            guest=NetworkGuest({'local':{'platform':'linux','transport':'local'}},d,transport=transport)
            with patch('sentinel_blue.runtime_environment.bundled_python',return_value='/opt/local/runtime/bin/python3'),patch.object(transport,'execute',return_value=CommandResult(0,0)) as execute:
                with self.assertRaises(LedgerError):guest('local',{'operation':'review'})
                self.assertIn('/opt/local/runtime/bin/python3 -I -B',execute.call_args.args[1])
    def test_withdrawal_remote_requires_staged_interpreter(self):
        from sentinel_blue.withdrawal import NetworkGuest
        from sentinel_blue.setup_transport import SetupTransport
        with tempfile.TemporaryDirectory() as d:
            transport=SetupTransport()
            guest=NetworkGuest({'remote':{'platform':'linux','transport':'ssh'}},d,transport=transport)
            with patch('sentinel_blue.runtime_environment.bundled_python',return_value='/opt/local/runtime/bin/python3'),patch.object(transport,'execute') as execute:
                with self.assertRaisesRegex(ValueError,'pre-staged'):guest('remote',{'operation':'review'})
                execute.assert_not_called()
    def test_nonbundled_default_retained(self):
        with patch('sentinel_blue.runtime_environment.bundled_python',return_value=None):
            self.assertEqual(host_python({'transport':'local'}),'/usr/bin/python3')
    def test_bundled_local_selects_its_own_python(self):
        with patch('sentinel_blue.runtime_environment.bundled_python',return_value='/opt/bundle/runtime/bin/python3'):
            self.assertEqual(host_python({'transport':'local'}),'/opt/bundle/runtime/bin/python3')
    def test_remote_cannot_borrow_controllers_path(self):
        with patch('sentinel_blue.runtime_environment.bundled_python',return_value='/controller/runtime/bin/python3'):
            with self.assertRaisesRegex(ValueError,'pre-staged'):host_python({'transport':'ssh'})
    def test_remote_explicit_path_survives(self):
        with patch('sentinel_blue.runtime_environment.bundled_python',return_value='/controller/runtime/bin/python3'):
            self.assertEqual(host_python({'transport':'ssh','python':'/target/runtime/bin/python3'}),'/target/runtime/bin/python3')
    def test_compiled_host_keeps_python(self):
        from test_setup import fixture
        from sentinel_blue.setup import compile_plan
        with tempfile.TemporaryDirectory() as d:
            inv,profile=fixture(Path(d),hosts=1,services=True)
            inv['hosts'][0]['python']='/opt/staged/runtime/bin/python3'
            plan=compile_plan(inv,profile,Path(d))
            self.assertEqual(plan['hosts']['host-0']['python'],'/opt/staged/runtime/bin/python3')
    def test_config_and_access_helpers_use_selected_python(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);f=root/'input';f.write_bytes(b'test\n')
            options={'service':'offline.service','files':[{'path':str(root/'config'),'source':{'path':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()},'previous_sha256':'absent','mode':'0640',
                'create_owner':'root','create_group':'root','readable_by':'root'}]}
            with target_runtime('/opt/offline/runtime/bin/python3'):
                check,apply,_=compile_recipe('linux-service',options,root,'linux')
                self.assertIn('/opt/offline/runtime/bin/python3',check)
                self.assertIn('/opt/offline/runtime/bin/python3',apply)
                self.assertNotIn('/usr/bin/python3',check+apply)
    def test_transaction_shell_uses_selected_python(self):
        from sentinel_blue.setup_transactions import commands
        with tempfile.TemporaryDirectory() as d,target_runtime('/opt/offline/runtime/bin/python3'):
            result=commands('linux-service',{'service':'offline.service','files':[]},Path(d),'exit 0\n')
            self.assertIn('/opt/offline/runtime/bin/python3 -I -B',result['apply'])
    def test_router_script_uses_selected_python(self):
        from sentinel_blue.network_setup import script
        with target_runtime('/opt/offline/runtime/bin/python3'):
            value=script('check',{'name':'offline','management':[{'source':'127.0.0.0/8','port':22}]})
        self.assertIn('/opt/offline/runtime/bin/python3 -I -B',value)
    def test_witness_script_uses_selected_python(self):
        from sentinel_blue.route_verification import script
        with target_runtime('/opt/offline/runtime/bin/python3'):
            value=script('cancel',{},'a'*32)
        self.assertIn('/opt/offline/runtime/bin/python3 -I -B',value)
    def test_service_pack_script_uses_selected_python(self):
        from sentinel_blue.service_pack_checks import check_scripts
        with target_runtime('/opt/offline/runtime/bin/python3'):
            scripts=check_scripts('redis',{}, {})
        self.assertTrue(all(x.startswith('/opt/offline/runtime/bin/python3 -I -B') for x in scripts))
    def test_persistent_router_units_retain_interpreter(self):
        from sentinel_blue.network_native import units
        with patch('sys.executable','/opt/Offline Bundle/runtime/bin/python3'):
            text='\n'.join(units(Path('/var/lib/fixture'),'fixture',60).values())
        self.assertIn('ExecStart="/opt/Offline Bundle/runtime/bin/python3" -I -B',text)
        self.assertNotIn('ExecStart=/usr/bin/python3',text)
    def test_persistent_agent_uses_absolute_interpreter(self):
        from sentinel_blue.launcher import _linux_unit
        unit=_linux_unit('http://127.0.0.1:8765','/opt/sentinel/runtime.pyz','/var/lib/sentinel',
            ['127.0.0.0/8'],False,False,60,python_executable='/opt/offline/runtime/bin/python3')
        self.assertIn('ExecStart=/opt/offline/runtime/bin/python3 -I -B',unit)
    def test_setup_preflight_tests_selected_interpreter(self):
        from sentinel_blue.setup_transport import SetupTransport,CommandResult
        tx=SetupTransport()
        with patch.object(tx,'execute',return_value=CommandResult(0,0)) as call:
            tx.preflight({'platform':'linux','transport':'local','address':'127.0.0.1','python':'/opt/offline/runtime/bin/python3'},10)
        self.assertIn('/opt/offline/runtime/bin/python3 -I -B',call.call_args.args[1])


class OfflineLaunchInventory(unittest.TestCase):
    def setUp(self):
        spec=importlib.util.spec_from_file_location('offline_launch_fixture',ROOT/'packaging/offline/launch.py')
        self.module=importlib.util.module_from_spec(spec);spec.loader.exec_module(self.module)
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name)
        for name in ('launch.py','sentinel-blue.pyz','offline-manifest.json','Start-Sentinel-Blue.sh','runtime/bin/python3'):
            p=self.root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b'fixture')
        self.inventory=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(self.root).as_posix()+'\n' for p in sorted(self.root.rglob('*')) if p.is_file())
        (self.root/'SHA256SUMS').write_text(self.inventory)
    def test_complete_inventory_passes(self):self.assertEqual(self.module.verify_bundle(self.root)['files_checked'],5)
    def test_altered_payload_fails(self):
        (self.root/'runtime/bin/python3').write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError,'mismatch'):self.module.verify_bundle(self.root)
    def test_missing_payload_fails(self):
        (self.root/'runtime/bin/python3').unlink()
        with self.assertRaisesRegex(ValueError,'missing'):self.module.verify_bundle(self.root)
    def test_symlink_payload_fails(self):
        p=self.root/'runtime/bin/python3';p.unlink();p.symlink_to(self.root/'launch.py')
        with self.assertRaisesRegex(ValueError,'symbolic'):self.module.verify_bundle(self.root)
    def test_traversal_inventory_refused(self):
        (self.root/'SHA256SUMS').write_text('a'*64+'  ../file\n')
        with self.assertRaises(ValueError):self.module.verify_bundle(self.root)
    def test_duplicate_inventory_refused(self):
        (self.root/'SHA256SUMS').write_text(self.inventory+self.inventory)
        with self.assertRaises(ValueError):self.module.verify_bundle(self.root)
    def test_incomplete_manifest_refused(self):
        (self.root/'SHA256SUMS').write_text('')
        with self.assertRaisesRegex(ValueError,'incomplete'):self.module.verify_bundle(self.root)
    def test_launcher_and_installer_do_not_search_python(self):
        for name in ('Start-Sentinel-Blue.sh','install-linux-launcher.sh'):
            text=(ROOT/'packaging/offline'/name).read_text()
            self.assertIn('runtime/bin/python3',text)
            for bad in ('pip install','apt install','command -v python','dirname','curl','wget'):
                self.assertNotIn(bad,text)


if __name__=='__main__':unittest.main()
