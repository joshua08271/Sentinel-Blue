import io
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
import zipfile

with patch.object(sys,'path',[str(Path(__file__).resolve().parents[1]/'tools'),*sys.path]):
    import azure_result_archive as results


def archive(name, data=b'{}'):
    stream=io.BytesIO()
    with zipfile.ZipFile(stream,'w') as z:
        z.writestr(name,data)
    return stream.getvalue()


class ResultArchiveTests(unittest.TestCase):
    def test_nested_json_evidence_accepted(self):
        results.validate(archive('sb-windows-target-evidence.zip',archive('defensive-native_regressions.json')))

    def test_command_and_path_entries_rejected_before_upload(self):
        for name in ('runner-private.log','payload.zip','../result.json','result.json/other'):
            with self.subTest(name=name), self.assertRaises(ValueError):
                results.validate(archive(name))

    def test_non_json_nested_file_rejected(self):
        with self.assertRaises(ValueError):
            results.validate(archive('sb-windows-target-evidence.zip',archive('defensive-setup.json',b'not JSON')))

    def test_failed_upload_deletes_only_the_new_container(self):
        calls=[]
        def cli(*args):
            calls.append(args)
            if args[:3]==('storage','account','show'):
                return {'allowBlobPublicAccess':False,'primaryEndpoints':{'blob':'https://owned.blob.core.windows.net/'}}
            if args[:3]==('storage','container','create'):
                return {'created':True}
            if args[:3]==('storage','blob','upload'):
                raise RuntimeError('upload unavailable')
            if args[:3]==('storage','container','delete'):
                return None
            raise AssertionError(args)
        with tempfile.TemporaryDirectory() as temporary:
            p=Path(temporary)/'evidence.zip';p.write_bytes(archive('result.json'))
            with patch.object(results,'cli',side_effect=cli), self.assertRaises(RuntimeError):
                results.retain(p,account='owned',group='owned',runtime_sha256='a'*64)
        created=calls[1][calls[1].index('--name')+1]
        self.assertEqual(calls[-1][:3],('storage','container','delete'))
        self.assertEqual(calls[-1][calls[-1].index('--name')+1],created)
