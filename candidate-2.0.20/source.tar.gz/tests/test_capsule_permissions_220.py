"""Native 2.0.19 regression: nested restore metadata must stay private."""
import hashlib
import os
from pathlib import Path
import shutil
import unittest

from sentinel_blue.controller_restore import verify_capsule, prune_capsules
from sentinel_blue.restoration import RestorePointStore


@unittest.skipUnless(os.name == 'posix', 'POSIX capsule permissions')
class CapsulePermissionsTests(unittest.TestCase):
    def fixture(self):
        from test_controller_restore_workflow import RestoreWorkflowTests
        fixture = RestoreWorkflowTests('run')
        fixture.setUp()
        self.addCleanup(fixture.doCleanups)
        target = fixture.root / 'owned.conf'
        target.write_bytes(b'owned recovery fixture')
        target.chmod(0o600)
        restore = RestorePointStore(fixture.root / 'restore',
                                  mirror=fixture.ledger.directory / 'restore-mirror')
        data, metadata = restore._read_target(target)
        captured = restore.capture([{'path': str(target),
            'sha256': hashlib.sha256(data).hexdigest(),
            'security_descriptor_sha256': restore._metadata_security_descriptor_sha256(metadata)}])
        self.assertTrue(captured['success'])
        self.assertTrue((fixture.ledger.directory / 'restore-metadata').is_dir())
        return fixture

    def verify(self, fixture, saved):
        return verify_capsule(saved['capsule'], fixture.anchor, fixture.key,
                              release_sha256='a' * 64,
                              profile_fingerprint=fixture.profile.fingerprint)

    def test_nested_metadata_remains_private_through_backup_and_restore(self):
        for mask in (0o022, 0o000):
            with self.subTest(umask=oct(mask)):
                fixture = self.fixture()
                original = {p.relative_to(fixture.ledger.directory): p.read_bytes()
                            for p in fixture.ledger.directory.rglob('*')
                            if p.is_file() and p.name != 'writer.lock'}
                previous = os.umask(mask)
                try:
                    saved = fixture.backup()
                    self.verify(fixture, saved)
                    fixture.loss()
                    shutil.rmtree(fixture.ledger.directory)
                    self.assertEqual(fixture.restore(saved)['phase'], 'complete')
                finally:
                    os.umask(previous)
                for relative, content in original.items():
                    self.assertEqual((fixture.ledger.directory / relative).read_bytes(), content)
                for root in (Path(saved['capsule']), fixture.ledger.directory):
                    for path in (root, *root.rglob('*')):
                        self.assertEqual(path.stat().st_mode & 0o077, 0, str(path))

    def test_retention_prunes_complete_nested_capsules_and_keeps_two(self):
        fixture = self.fixture()
        previous = os.umask(0o022)
        try:
            saved = [fixture.backup() for _ in range(4)]
        finally:
            os.umask(previous)
        removed = prune_capsules(fixture.backups, fixture.anchor, fixture.key,
                                keep=2, maximum_bytes=0)
        self.assertEqual(set(removed), {Path(s['capsule']).name for s in saved[:2]})
        self.assertTrue(Path(saved[-2]['capsule']).is_dir())
        self.verify(fixture, saved[-1])

    def test_changed_permissions_are_rejected_and_not_normalized_or_pruned(self):
        fixture = self.fixture()
        saved = [fixture.backup() for _ in range(3)]
        changed = Path(saved[-1]['capsule']) / 'ledger/restore-metadata'
        changed.chmod(0o755)
        with self.assertRaisesRegex(ValueError, 'group or other'):
            self.verify(fixture, saved[-1])
        self.assertEqual(prune_capsules(fixture.backups, fixture.anchor, fixture.key,
                                       keep=2, maximum_bytes=0), [])
        self.assertEqual(changed.stat().st_mode & 0o777, 0o755)
        self.assertTrue(all(Path(s['capsule']).is_dir() for s in saved))

    def test_history_rehearsal_verifies_old_capsules_without_admitting_stale_restore(self):
        from tools.history_storage_rehearsal import verify_retained_capsules
        fixture = self.fixture()
        saved = [fixture.backup() for _ in range(3)]
        result = verify_retained_capsules(fixture.backups, fixture.anchor, fixture.key,
            release_sha256='a' * 64, profile_fingerprint=fixture.profile.fingerprint)
        self.assertEqual(result['backups_verified'], 3)
        self.assertTrue(result['latest_capsule_verified'])
        self.assertGreater(result['nested_ledger_files_verified'], 0)
        with self.assertRaisesRegex(ValueError, 'latest'):
            self.verify(fixture, saved[0])
        # Old retained material must be checked too, not merely counted.
        changed = Path(saved[0]['capsule']) / 'inputs/event_profile'
        changed.write_bytes(changed.read_bytes() + b' ')
        with self.assertRaisesRegex(ValueError, 'tampered'):
            verify_retained_capsules(fixture.backups, fixture.anchor, fixture.key,
                release_sha256='a' * 64, profile_fingerprint=fixture.profile.fingerprint)


if __name__ == '__main__':
    unittest.main()
