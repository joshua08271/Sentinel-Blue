"""Automatic journaled Linux recovery and durable operator undo holds.

Native manager transitions and application probes are inert; temporary file,
SQLite, signed HTTP, and Tk tests do not constitute live VM acceptance.
"""
import copy
from dataclasses import asdict
import hashlib
import json
import os
from pathlib import Path
import tempfile
import time
import unittest
import uuid
from unittest.mock import patch

from sentinel_blue.actions import ActionExecutor
from sentinel_blue.agent import AgentClient, execute_queued_action
from sentinel_blue.controller import ControllerApp
from sentinel_blue.event_profile import EventProfile
from sentinel_blue.journaled_recovery import START_JOURNAL, start_plan
from sentinel_blue.operator_recovery import _hold_inverse
from sentinel_blue.protocol import ProbeResult
from sentinel_blue.service_automation import LocalAutomation, empty, snapshot, update, refusal, validate
from sentinel_blue.service_recovery import recovery_parameters, validate_automatic_recovery
from sentinel_blue.service_repair import plan_digest
from sentinel_blue.state import ActionJournal, read_private_json, write_private_json
from sentinel_blue.store import Store, _require_success_result_contract
from test_autonomous_service_recovery import fixtures, stopped
from test_store_controller import _promote_integrity_baseline


class AutomaticStartFixture(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory(prefix='sb214-automatic-')
        self.addCleanup(temp.cleanup); self.root = Path(temp.name).resolve()
        self.target = self.root / 'web.conf'; self.target.write_bytes(b'trusted')
        self.profile, self.baseline = fixtures(str(self.target))
        self.store = Store(':memory:'); self.addCleanup(self.store.close)
        self.app = ControllerApp(self.store, 't'*32, operator_token='o'*32,
                                 event_profile=self.profile, auto_recover_services=True)
        self.app.ingest(self.baseline); _promote_integrity_baseline(self.app, self.store, 'agent-one')
        self.executor = ActionExecutor(self.root/'state', allow_service_recovery=True, allow_restoration=False,
                                       profile_fingerprint=self.profile.fingerprint)
        self.native = 'stopped'; self.transitions = []
        self.journal = ActionJournal(self.root/'delivery')
        self.local = LocalAutomation(self.executor.state_dir, self.profile, 'agent-one')
        def transition(service, state):
            self.transitions.append((service, state)); self.native = state
        for p in (patch.object(self.executor, '_service_state', side_effect=lambda _: self.native),
                  patch.object(self.executor, '_set_service_state', side_effect=transition),
                  patch.object(self.executor.repairs, '_transition', side_effect=transition),
                  patch.object(self.executor, '_wait_for_service_probes', return_value=(
                      [ProbeResult('web-health', self.profile.services[0]['expected_transactions'][0]['target'], True)], 3, True))):
            p.start(); self.addCleanup(p.stop)

    def queue_automatic(self):
        for seq in (2, 3):
            self.current = stopped(self.baseline, seq); self.app.ingest(self.current)
        items = self.store.dashboard()['actions']
        actions = [x for x in items if x['action_type'] == 'restart_service']
        self.assertEqual(len(actions), 1, actions)
        self.assertTrue(actions[0]['automated'])
        return actions[0]['action_id']

    def deliver(self, identifier, *, acknowledge=True):
        self.local.accept(snapshot(self.store, self.profile, 'agent-one'))
        envelope = next(asdict(x) for x in self.app.pending_actions_for_agent('agent-one') if x.action_id == identifier)
        result = execute_queued_action(self.journal, self.executor, envelope,
                    self.store.latest_telemetry_for_agent('agent-one'), {'action_safe': True}, self.profile)
        if acknowledge:
            self.assertEqual(self.app.complete_action(dict(result, action_id=identifier), 'agent-one'), 'new', result)
        return result

    def forward(self):
        identifier = self.queue_automatic(); result = self.deliver(identifier)
        self.assertTrue(result['success'], result)
        fresh = copy.deepcopy(self.baseline); fresh.update(sequence=4, observed_at=time.time())
        self.app.ingest(fresh)
        return identifier, result

    def undo(self, identifier, *, acknowledge=True):
        review = self.app.review_service_action({'agent_id':'agent-one', 'service':'web.service',
            'choice':'undo', 'action_id':identifier}, 'operator')
        queued = self.app.execute_service_action({'review_id':review['review_id'],
            'review_sha256':review['review_sha256'], 'reason':'Undo this witnessed automatic start',
            'authorization_code':''}, 'operator')
        return queued['action_id'], self.deliver(queued['action_id'], acknowledge=acknowledge)

    def fresh_stopped(self, seq=5):
        sample = stopped(self.baseline, seq); sample['observed_at'] = time.time()
        self.app.ingest(sample); return sample

    def resume(self):
        state = snapshot(self.store, self.profile, 'agent-one')
        return self.app.set_service_automation({'agent_id':'agent-one','service':'web.service','paused':False,
            'reason':'Explicitly resume previously authorized service recovery',
            'expected_revision':state['revision']}, 'operator')


class AutomaticUndoTests(AutomaticStartFixture):
    def test_automatic_start_without_file_restoration_permission_has_real_inverse(self):
        identifier, result = self.forward()
        self.assertFalse(self.executor.allow_restoration)
        self.assertEqual(result['pre_state']['journal_kind'], START_JOURNAL)
        self.assertEqual(result['record']['origin_action'], 'restart_service')
        self.assertEqual(self.native, 'running')
        self.assertEqual(self.target.read_bytes(), b'trusted')
        history = self.app.service_action_history({'agent_id':'agent-one','service':'web.service'})
        row = next(x for x in history['actions'] if x['action_id']==identifier)
        self.assertTrue(row['automated']); self.assertTrue(row['undo_candidate'])
        inverse, undone = self.undo(identifier)
        self.assertTrue(undone['success'], undone); self.assertEqual(self.native, 'stopped')
        self.assertEqual(self.target.read_bytes(), b'trusted')
        self.assertEqual(self.store.get_action(inverse)['action_type'], 'rollback_service')

    def test_completed_inverse_marks_original_undone_not_reviewable_again(self):
        identifier,_=self.forward();self.undo(identifier)
        rows=self.app.service_action_history({'agent_id':'agent-one','service':'web.service'})['actions']
        original=next(r for r in rows if r['action_id']==identifier)
        self.assertFalse(original['undo_candidate']);self.assertEqual(original['undo_status'],'Undone')
        self.assertIn('completed',original['undo_unavailable_reason'])
        with self.assertRaisesRegex(ValueError,'later service action'):self.undo(identifier)

    def test_unconfirmed_inverse_marks_original_pending_not_successfully_undone(self):
        identifier,_=self.forward();self.undo(identifier,acknowledge=False)
        rows=self.app.service_action_history({'agent_id':'agent-one','service':'web.service'})['actions']
        original=next(r for r in rows if r['action_id']==identifier)
        self.assertFalse(original['undo_candidate']);self.assertEqual(original['undo_status'],'Pending')

    def test_undo_persists_pause_and_never_automatically_reapplies_without_resume(self):
        identifier, result = self.forward(); self.undo(identifier)
        self.fresh_stopped(5); self.fresh_stopped(6)
        state = snapshot(self.store, self.profile, 'agent-one')
        self.assertTrue(state['services']['web.service']['paused'])
        self.assertEqual(state['services']['web.service']['transaction_id'], result['pre_state']['transaction_id'])
        self.assertEqual(self.app.pending_actions_for_agent('agent-one'), [])
        self.assertIsNotNone(LocalAutomation(self.executor.state_dir, self.profile, 'agent-one').refusal(
            'restart_service', {'service':'web.service'}))
        self.assertIsNone(self.app._queue_action('agent-one','restart_service',
            recovery_parameters(self.profile,'agent-one','web.service',self.baseline,self.current), automated=True))

    def test_explicit_resume_clears_matching_local_latch_but_does_not_reset_budget(self):
        identifier, result = self.forward(); self.undo(identifier); self.fresh_stopped()
        before = self.store.service_recovery_budget_status('agent-one','web.service')
        resumed = self.resume(); self.assertFalse(resumed['service_automation']['services']['web.service']['paused'])
        self.local.accept(snapshot(self.store,self.profile,'agent-one'))
        self.assertIsNone(self.local.refusal('restart_service',{'service':'web.service'}))
        after = self.store.service_recovery_budget_status('agent-one','web.service')
        self.assertEqual(before['attempts_in_window'], after['attempts_in_window'])
        self.assertFalse(after['allowed']) # still the ordinary cooldown
        record = self.executor.repairs._read(self.executor.repairs._path(result['pre_state']['transaction_id']))
        self.assertTrue(record['forward_success']); self.assertEqual(record['status'], 'rolled_back')

    def test_lost_undo_result_stays_paused_locally_and_blocks_controller_resume(self):
        identifier, result = self.forward(); self.undo(identifier, acknowledge=False)
        self.assertEqual(self.native, 'stopped'); self.fresh_stopped()
        self.assertTrue(self.local.read()['latches'])
        with self.assertRaises(PermissionError): self.resume()

    def test_later_file_change_refuses_inverse_without_stopping_service(self):
        identifier, result = self.forward()
        self.target.write_bytes(b'teammate change after observation')
        inverse, undone = self.undo(identifier)
        self.assertFalse(undone['success']); self.assertEqual(self.native,'running')
        self.assertEqual(self.target.read_bytes(),b'teammate change after observation')
        self.assertTrue(snapshot(self.store,self.profile,'agent-one')['services']['web.service']['paused'])

    def test_missing_recorded_undo_guard_refused_by_agent(self):
        parameters = recovery_parameters(self.profile,'agent-one','web.service',self.baseline,stopped(self.baseline))
        parameters['recovery_guard'].pop('recorded_undo')
        with self.assertRaises(ValueError): validate_automatic_recovery(self.profile,'agent-one',parameters,stopped(self.baseline))
        with self.assertRaises(ValueError): start_plan(parameters)

    def test_missing_inverse_authority_does_not_get_silently_granted(self):
        raw = copy.deepcopy(self.profile.raw); raw['services'][0]['approval_actions'].remove('rollback_service')
        profile = EventProfile.from_dict(raw)
        with self.assertRaisesRegex(ValueError,'rollback_service'):
            recovery_parameters(profile,'agent-one','web.service',self.baseline,stopped(self.baseline))
        self.assertNotIn('rollback_service', profile.services[0]['approval_actions'])

    def test_failed_validation_restores_pre_state_and_is_not_undo_candidate(self):
        self.executor._wait_for_service_probes.return_value = ([], 3, False)
        identifier = self.queue_automatic(); result = self.deliver(identifier)
        self.assertFalse(result['success']); self.assertTrue(result['rolled_back']); self.assertEqual(self.native,'stopped')
        row = self.app.service_action_history({'agent_id':'agent-one','service':'web.service'})['actions'][0]
        self.assertFalse(row['undo_candidate'])

    def test_start_plan_cannot_add_a_startup_change_or_foreign_origin(self):
        identifier, result = self.forward()
        path = self.executor.repairs._path(result['pre_state']['transaction_id'])
        record = self.executor.repairs._read(path)
        record['parameters']['repair']['restart_unhealthy'] = True
        record['plan_sha256'] = plan_digest(record['parameters']); write_private_json(path, record)
        with self.assertRaisesRegex(ValueError, 'outside restart'): self.executor.repairs._read(path)

    def test_receipt_without_journal_cannot_claim_undoable_automatic_success(self):
        identifier, result = self.forward(); params = self.store.get_action(identifier)['parameters']
        for field in ('pre_state','record'):
            changed = copy.deepcopy(result); changed[field].pop('transaction_id')
            with self.assertRaises(ValueError): _require_success_result_contract('restart_service', params, changed)

    def test_existing_action_rollback_api_uses_same_hold_and_exact_journal(self):
        identifier, result = self.forward(); response = self.app.rollback_action(identifier)
        self.assertTrue(snapshot(self.store,self.profile,'agent-one')['services']['web.service']['paused'])
        undone = self.deliver(response['action_id']); self.assertTrue(undone['success'],undone)
        self.assertEqual(self.native,'stopped')

    def test_pause_filters_a_previously_queued_automatic_action(self):
        identifier = self.queue_automatic()
        update(self.store,self.profile,'agent-one','web.service',True,'pause before delivery')
        self.assertEqual(self.app.pending_actions_for_agent('agent-one'),[])
        self.assertEqual(self.store.get_action(identifier)['status'],'queued')

    def test_old_delivered_action_rechecked_against_local_pause(self):
        identifier = self.queue_automatic()
        action = asdict(self.app.pending_actions_for_agent('agent-one')[0])
        paused = update(self.store,self.profile,'agent-one','web.service',True,'pause before execution')
        self.local.accept(paused)
        result = execute_queued_action(self.journal,self.executor,action,self.current,{'action_safe':True},self.profile)
        self.assertFalse(result['success']); self.assertIn('paused',result['message'])
        self.assertEqual(self.transitions,[])

    def test_emergency_stop_and_missing_baseline_still_prevent_resume(self):
        update(self.store,self.profile,'agent-one','web.service',True,'operator pause')
        self.app.emergency_stop()
        with self.assertRaises(PermissionError): self.resume()
        self.app.emergency_stopped=False
        with patch.object(self.store,'baseline_status',return_value='pending'):
            with self.assertRaises(PermissionError): self.resume()

    def test_archive_lookup_preserves_recorded_start_undo(self):
        identifier, result = self.forward()
        path = self.executor.repairs._path(result['pre_state']['transaction_id'])
        record = self.executor.repairs._read(path)
        record['created_at']-=4000;record['completed_at']-=4000;write_private_json(path,record)
        self.executor.repairs.reconcile(); self.assertFalse(path.exists())
        inverse, undone = self.undo(identifier)
        self.assertTrue(undone['success'],undone); self.assertEqual(self.native,'stopped')


class PersistentHoldTests(unittest.TestCase):
    def setUp(self):
        td=tempfile.TemporaryDirectory(prefix='sb214-holds-');self.addCleanup(td.cleanup);self.root=Path(td.name)
        self.profile,self.baseline=fixtures()
        self.store=Store(self.root/'controller.db');self.addCleanup(self.store.close)
        self.directory=self.root/'agent';self.directory.mkdir(mode=0o700)
        self.local=LocalAutomation(self.directory,self.profile,'agent-one')

    def test_sqlite_reopen_keeps_operator_pause(self):
        expected=update(self.store,self.profile,'agent-one','web.service',True,'test durable pause')
        another=Store(self.root/'controller.db');self.addCleanup(another.close)
        self.assertEqual(snapshot(another,self.profile,'agent-one'),expected)

    def test_compare_and_swap_does_not_overwrite_a_newer_choice(self):
        first=update(self.store,self.profile,'agent-one','web.service',True,'first pause',expected_revision=0)
        with self.assertRaises(PermissionError):update(self.store,self.profile,'agent-one','web.service',False,'stale resume',expected_revision=0)
        self.assertEqual(snapshot(self.store,self.profile,'agent-one'),first)

    def test_corrupt_controller_state_does_not_clear_hold(self):
        update(self.store,self.profile,'agent-one','web.service',True,'pause first')
        self.store._connection.execute("UPDATE controller_state SET state_value='{' WHERE state_key='service_automation:agent-one'")
        self.store._connection.commit()
        with self.assertRaises(ValueError):snapshot(self.store,self.profile,'agent-one')

    def test_unrelated_service_and_read_only_checks_are_not_held(self):
        control=update(self.store,self.profile,'agent-one','web.service',True,'only the web service')
        self.assertIsNone(refusal(control,self.profile,'agent-one','restart_service',{'service':'other.service'}))
        self.assertIsNone(refusal(control,self.profile,'agent-one','validate_service',{'service':'web.service'}))
        self.assertIsNotNone(refusal(control,self.profile,'agent-one','restore_integrity',{'path':'/etc/web.conf'}))

    def test_stale_or_changed_equal_revision_cannot_clear_agent_hold(self):
        control=update(self.store,self.profile,'agent-one','web.service',True,'durable pause')
        self.local.accept(control)
        # 2.0.15 (R214-01b): a stale controller no longer fails the whole poll,
        # but it still cannot replace the durable floor or clear the hold.
        self.assertEqual(self.local.accept(empty(self.profile,'agent-one')),'behind')
        self.assertEqual(self.local.read()['snapshot'],control)
        altered=copy.deepcopy(control);altered['services']['web.service']['paused']=False
        self.assertEqual(self.local.accept(altered),'behind')
        self.assertEqual(self.local.read()['snapshot'],control)
        self.assertIsNotNone(self.local.refusal('restart_service',{'service':'web.service'}))
        self.assertIsNotNone(self.local.refusal('restart_service',{'service':'other.service'}))

    def test_latch_needs_explicit_newer_matching_transaction_resume(self):
        txn=str(uuid.uuid4());self.local.latch('web.service',txn)
        self.local.accept(empty(self.profile,'agent-one'))
        self.assertTrue(self.local.read()['latches'])
        control=update(self.store,self.profile,'agent-one','web.service',False,'wrong inverse resume',transaction_id=str(uuid.uuid4()))
        self.local.accept(control);self.assertTrue(self.local.read()['latches'])
        control=update(self.store,self.profile,'agent-one','web.service',False,'matching inverse resume',transaction_id=txn)
        self.local.accept(control);self.assertFalse(self.local.read()['latches'])

    def test_local_restart_does_not_forget_latch(self):
        self.local.latch('web.service',str(uuid.uuid4()))
        reopened=LocalAutomation(self.directory,self.profile,'agent-one')
        self.assertIsNotNone(reopened.refusal('repair_service',{'service':'web.service'}))

    def test_corrupt_local_state_or_symlink_never_becomes_no_hold(self):
        self.local.path.write_text('{');self.local.path.chmod(0o600)
        with self.assertRaises(ValueError):self.local.refusal('restart_service',{'service':'web.service'})
        self.local.path.unlink();other=self.root/'other';write_private_json(other,{'snapshot':empty(self.profile,'agent-one'),'latches':{}})
        self.local.path.symlink_to(other)
        with self.assertRaises((ValueError,OSError)):self.local.read()

    def test_profile_mismatch_and_unapproved_service_refused(self):
        value=empty(self.profile,'agent-one');value['profile_fingerprint']='f'*64
        with self.assertRaises(ValueError):self.local.accept(value)
        with self.assertRaises(ValueError):update(self.store,self.profile,'agent-one','foreign.service',True,'not in manifest')
        self.assertEqual(snapshot(self.store,self.profile,'agent-one')['revision'],0)

    def test_automatic_action_poll_persists_hold_before_returning_actions(self):
        client=AgentClient.__new__(AgentClient);client.agent_id='agent-one';client.service_automation=self.local
        state=update(self.store,self.profile,'agent-one','web.service',True,'hold before poll result')
        with patch.object(client,'_request',return_value={'actions':[],'service_automation':state}):
            self.assertEqual(client.actions(),[])
        self.assertIsNotNone(self.local.refusal('restart_service',{'service':'web.service'}))
        with patch.object(client,'_request',return_value={'actions':[]}):
            with self.assertRaises(ValueError):client.actions()

    def test_shared_file_inverse_holds_every_declared_affected_service(self):
        raw=copy.deepcopy(self.profile.raw);second=copy.deepcopy(raw['services'][0]);second['service_id']='second.service'
        raw['services'].append(second);p=EventProfile.from_dict(raw)
        app=ControllerApp(self.store,'t'*32,operator_token='o'*32,event_profile=p)
        txn=str(uuid.uuid4())
        _hold_inverse(app,'agent-one','web.service','rollback_integrity',{'path':'/etc/web.conf','transaction_id':txn},'undo shared file')
        control=snapshot(self.store,p,'agent-one')
        self.assertEqual(set(control['services']),{'web.service','second.service'})
        self.assertTrue(all(x['paused'] for x in control['services'].values()))



class SignedAutomationTests(AutomaticStartFixture):
    def setUp(self):
        super().setUp()
        import threading
        from sentinel_blue.controller import ControllerServer, make_handler
        from sentinel_blue.desktop_control import DesktopClient
        self.server=ControllerServer(('127.0.0.1',0),make_handler(self.app))
        thread=threading.Thread(target=self.server.serve_forever,daemon=True);thread.start()
        self.addCleanup(self.server.server_close);self.addCleanup(thread.join,3);self.addCleanup(self.server.shutdown)
        self.client=DesktopClient(f'http://127.0.0.1:{self.server.server_port}','operator',1,'o'*32)

    def test_real_signed_pause_history_resume_and_stale_revision(self):
        body={'agent_id':'agent-one','service':'web.service','paused':True,'reason':'pause via signed GUI request','expected_revision':0}
        response=self.client.request('/api/v1/service-actions/automation',body)
        self.assertTrue(response['service_automation']['services']['web.service']['paused'])
        history=self.client.request('/api/v1/service-actions/history',{'agent_id':'agent-one','service':'web.service'})
        self.assertFalse(history['automatic_recovery_enabled'])
        with self.assertRaises(RuntimeError):self.client.request('/api/v1/service-actions/automation',dict(body,paused=False))
        body.update(paused=False,expected_revision=1,reason='resume existing signed policy')
        self.assertFalse(self.client.request('/api/v1/service-actions/automation',body)['service_automation']['services']['web.service']['paused'])

    def test_unauthenticated_control_is_denied_and_route_is_bounded(self):
        import http.client
        from sentinel_blue.controller import controller_post_route_limit,CONTROLLER_JSON_REQUEST_BYTES
        self.assertEqual(controller_post_route_limit('/api/v1/service-actions/automation'),CONTROLLER_JSON_REQUEST_BYTES)
        connection=http.client.HTTPConnection('127.0.0.1',self.server.server_port,timeout=3)
        try:
            connection.request('POST','/api/v1/service-actions/automation',body=b'{}',headers={'Content-Type':'application/json'})
            response=connection.getresponse();response.read();self.assertEqual(response.status,401)
        finally:connection.close()
        self.assertEqual(snapshot(self.store,self.profile,'agent-one')['revision'],0)

    def test_extra_permissions_or_command_cannot_be_smuggled_in_resume(self):
        body={'agent_id':'agent-one','service':'web.service','paused':True,'reason':'bounded control','expected_revision':0,'command':'unused'}
        with self.assertRaisesRegex(RuntimeError,'HTTP 400'):self.client.request('/api/v1/service-actions/automation',body)
        self.assertEqual(snapshot(self.store,self.profile,'agent-one')['revision'],0)


class DedicatedControlTests(unittest.TestCase):
    def test_guest_source_cannot_pause_or_resume_even_with_operator_key(self):
        from test_management_isolation_212 import HTTPRoleTests,MANAGER,WEB
        from sentinel_blue.desktop_control import DesktopClient
        fixture=HTTPRoleTests('test_management_still_requires_operator_signature');fixture.setUp();self.addCleanup(fixture.doCleanups)
        client=DesktopClient(f'http://127.0.0.1:{fixture.server.server_port}','operator',1,'o'*48)
        fixture.peer=MANAGER;self.assertIsInstance(client.dashboard(),dict)
        fixture.peer=WEB
        with patch.object(fixture.server.RequestHandlerClass,'_read_body',side_effect=AssertionError('must reject before parsing')):
            with self.assertRaisesRegex(RuntimeError,'HTTP 403'):client.request('/api/v1/service-actions/automation',{})


class FileAndRepairHistoryTests(unittest.TestCase):
    def setUp(self):
        from test_service_repair import RepairExecutionTests
        self.f=RepairExecutionTests('test_file_restore_and_start_commit_together_and_support_exact_undo')
        self.f.setUp();self.addCleanup(self.f.doCleanups)
        raw=copy.deepcopy(self.f.profile.raw);raw['services'][0]['approval_actions']+=['restore_integrity','rollback_integrity']
        self.profile=EventProfile.from_dict(raw)
        self.store=Store(':memory:');self.addCleanup(self.store.close)
        self.app=ControllerApp(self.store,'t'*32,operator_token='o'*32,event_profile=self.profile)
        self.app.ingest(self.f.baseline);_promote_integrity_baseline(self.app,self.store,'agent-one');self.app.ingest(self.f.current)
        self.journal=ActionJournal(self.f.root/'delivery-214')
        p=patch('sentinel_blue.restoration.run_probes',side_effect=lambda specs,*a,**kw: self.f.healthy if specs else []);p.start();self.addCleanup(p.stop)
        p=patch.object(self.f.executor.repairs,'_transition',side_effect=self.f.change_state);p.start();self.addCleanup(p.stop)

    def deliver(self,identifier):
        action=next(asdict(x) for x in self.app.pending_actions_for_agent('agent-one') if x.action_id==identifier)
        local=LocalAutomation(self.f.executor.state_dir,self.profile,'agent-one');local.accept(snapshot(self.store,self.profile,'agent-one'))
        result=execute_queued_action(self.journal,self.f.executor,action,self.store.latest_telemetry_for_agent('agent-one'),{'action_safe':True},self.profile)
        self.assertEqual(self.app.complete_action(dict(result,action_id=identifier),'agent-one'),'new',result)
        return result

    def test_automatic_standalone_file_restore_appears_and_can_be_undone(self):
        params=copy.deepcopy(self.f.parameters['repair']['restore_files'][0]);params['probes']=copy.deepcopy(self.f.parameters['probes'])
        identifier=self.app._queue_action('agent-one','restore_integrity',params,automated=True)
        self.assertIsNotNone(identifier)
        result=self.deliver(identifier);self.assertTrue(result['success'],result)
        self.assertEqual(self.f.target.read_bytes(),b'trusted')
        fresh=copy.deepcopy(self.f.baseline);fresh.update(sequence=3,observed_at=time.time());self.app.ingest(fresh)
        history=self.app.service_action_history({'agent_id':'agent-one','service':'web.service'})
        self.assertTrue(history['actions'][0]['automated']);self.assertTrue(history['actions'][0]['undo_candidate'])
        selection={'agent_id':'agent-one','service':'web.service','choice':'undo','action_id':identifier}
        review=self.app.review_service_action(selection,'operator');self.assertEqual(review['action_type'],'rollback_integrity')
        queued=self.app.execute_service_action({'review_id':review['review_id'],'review_sha256':review['review_sha256'],
            'reason':'undo witnessed file restoration','authorization_code':''},'operator')
        inverse=self.deliver(queued['action_id']);self.assertTrue(inverse['success'],inverse)
        self.assertEqual(self.f.target.read_bytes(),b'damaged')
        self.assertTrue(snapshot(self.store,self.profile,'agent-one')['services']['web.service']['paused'])

    def test_automatic_full_repair_uses_same_undo_and_pause(self):
        identifier=self.app._queue_action('agent-one','repair_service',self.f.parameters,automated=True)
        self.assertIsNotNone(identifier)
        result=self.deliver(identifier);self.assertTrue(result['success'],result)
        fresh=copy.deepcopy(self.f.baseline);fresh.update(sequence=3,observed_at=time.time());self.app.ingest(fresh)
        reviewed=self.app.review_service_action({'agent_id':'agent-one','service':'web.service','choice':'undo','action_id':identifier},'operator')
        queued=self.app.execute_service_action({'review_id':reviewed['review_id'],'review_sha256':reviewed['review_sha256'],
            'reason':'undo automatic coordinated recovery','authorization_code':''},'operator')
        inverse=self.deliver(queued['action_id']);self.assertTrue(inverse['success'],inverse)
        self.assertEqual(self.f.target.read_bytes(),b'damaged');self.assertEqual(self.f.native_state,'stopped')
        self.assertTrue(snapshot(self.store,self.profile,'agent-one')['services']['web.service']['paused'])

    def test_missing_inverse_permission_holds_automatic_file_restore(self):
        raw=copy.deepcopy(self.profile.raw);raw['services'][0]['approval_actions'].remove('rollback_integrity')
        self.app.event_profile=EventProfile.from_dict(raw)
        params=copy.deepcopy(self.f.parameters['repair']['restore_files'][0]);params['probes']=copy.deepcopy(self.f.parameters['probes'])
        self.assertIsNone(self.app._queue_action('agent-one','restore_integrity',params,automated=True))
        self.assertEqual(self.f.target.read_bytes(),b'damaged')


@unittest.skipUnless(os.environ.get('DISPLAY'),'Tk display unavailable')
class AutomationGUIControls(unittest.TestCase):
    def setUp(self):
        from test_operator_recovery_213 import OperatorActionGUI
        self.f=OperatorActionGUI('test_actual_widgets_choose_repair_then_review_recorded_undo')
        self.f.setUp();self.addCleanup(self.f.doCleanups)
        existing=self.f.gui.client.request;backend=self.f.backend.app
        def request(path,payload):
            if path.endswith('/automation'):return backend.set_service_automation(payload,'operator')
            return existing(path,payload)
        self.f.gui.client.request=request

    def test_actual_pause_resume_buttons_operate_only_on_selected_service(self):
        dialog=self.f.dialog;dialog.reason.set('Explicit GUI hold and approved resume')
        dialog.refresh_history()
        with patch.object(self.f.gui.messagebox,'askyesno',return_value=True):dialog.change_automation(True)
        state=snapshot(self.f.backend.store,self.f.backend.profile,'agent-one')
        self.assertTrue(state['services']['web.service']['paused'])
        self.assertIn('PAUSED',dialog.automation_status.get())
        with patch.object(self.f.gui.messagebox,'askyesno',return_value=True):dialog.change_automation(False)
        self.assertFalse(snapshot(self.f.backend.store,self.f.backend.profile,'agent-one')['services']['web.service']['paused'])
        # Clearing a per-service hold does not enable a disabled controller.
        self.assertFalse(self.f.backend.app.auto_recover_services)
        self.assertIn('disabled',dialog.automation_status.get())

    def test_cancel_and_missing_reason_do_not_change_automation(self):
        dialog=self.f.dialog;dialog.refresh_history();dialog.reason.set('')
        with patch.object(self.f.gui.messagebox,'askyesno',return_value=True):dialog.change_automation(True)
        self.assertEqual(snapshot(self.f.backend.store,self.f.backend.profile,'agent-one')['revision'],0)
        dialog.reason.set('Do not apply a canceled dialog')
        with patch.object(self.f.gui.messagebox,'askyesno',return_value=False):dialog.change_automation(True)
        self.assertEqual(snapshot(self.f.backend.store,self.f.backend.profile,'agent-one')['revision'],0)

    def test_switched_controller_cannot_apply_old_automation_revision(self):
        self.f.dialog.refresh_history();self.f.dialog.reason.set('old controller')
        self.f.gui.generation+=1
        with patch.object(self.f.gui.messagebox,'askyesno') as ask:self.f.dialog.change_automation(True)
        ask.assert_not_called()


class RetentionAndBudgetTests(AutomaticStartFixture):
    def test_completed_history_is_not_a_lifetime_resume_gate(self):
        from sentinel_blue.json_codec import canonical_json_dumps
        now=time.time()-7200
        for i in range(1050):
            # Explicitly terminal read-only audit fixtures, no real operations.
            identifier=self.store.queue_action('agent-one','validate_service',{'service':'web.service','probes':self.profile.services[0]['expected_transactions']})
            self.store._connection.execute("UPDATE actions SET status='completed',created_at=?,completed_at=?,result_json=?,result_source='agent' WHERE action_id=?",
                (now+i/100,now+i/100,canonical_json_dumps({'success':True,'message':'terminal test-only check'}),identifier))
        self.store._connection.commit()
        update(self.store,self.profile,'agent-one','web.service',True,'pause with old completed history')
        self.assertFalse(self.resume()['service_automation']['services']['web.service']['paused'])

    def test_undo_success_does_not_become_failed_recovery_in_native_budget(self):
        identifier,result=self.forward();self.undo(identifier)
        future=time.time()+301; sample=stopped(self.baseline,10);sample['observed_at']=future
        with patch('time.time',return_value=future):
            params=recovery_parameters(self.profile,'agent-one','web.service',self.baseline,sample)
            # Four earlier undone successful records must not count as failures.
            original=self.executor.repairs._read(self.executor.repairs._path(result['pre_state']['transaction_id']))
            for i in range(3):
                record=copy.deepcopy(original);record['transaction_id']=str(uuid.uuid4());record['created_at']=future-900-i*100
                write_private_json(self.executor.repairs._path(record['transaction_id']),record)
            params['recovery_guard']['attempt_limits']={'cooldown_seconds':15,'maximum_attempts':60}
            self.executor._service_recovery_preflight(params)
            for i in range(3):
                write_private_json(self.executor.state_dir/f'service-transaction-failed-{i}.json',{
                    'service':'web.service','operation':'restart_service','status':'rolled_back','created_at':future-900-i*100})
            with self.assertRaisesRegex(ValueError,'failed_attempt_hourly_budget'):
                self.executor._service_recovery_preflight(params)

    def test_hold_stays_if_inverse_queue_rejected(self):
        identifier,result=self.forward()
        review=self.app.review_service_action({'agent_id':'agent-one','service':'web.service','choice':'undo','action_id':identifier},'operator')
        with patch.object(self.app,'_queue_action_locked',side_effect=PermissionError('queue deliberately unavailable')):
            with self.assertRaises(PermissionError):self.app.execute_service_action({'review_id':review['review_id'],'review_sha256':review['review_sha256'],
                'reason':'hold before trying inverse','authorization_code':''},'operator')
        self.assertTrue(snapshot(self.store,self.profile,'agent-one')['services']['web.service']['paused'])
        self.assertEqual(self.native,'running')

    def test_setup_redo_is_held_after_undo(self):
        identifier,result=self.forward();self.undo(identifier)
        policy=self.app.setup_redo_policy([('agent-one','web.service')])
        self.assertIn('operator',json.dumps(policy).lower())



class NoOpAndCancellationTests(AutomaticStartFixture):
    def test_self_recovered_service_has_explicit_noop_without_fake_undo(self):
        from sentinel_blue.journaled_recovery import START_NOOP
        identifier=self.queue_automatic(); self.native='running'
        result=self.deliver(identifier)
        self.assertTrue(result['success'],result)
        self.assertEqual(result['record']['journal_kind'],START_NOOP)
        self.assertEqual(self.transitions,[])
        self.assertEqual(list(self.executor.state_dir.glob('service-repair-*.json')),[])
        rows=self.app.service_action_history({'agent_id':'agent-one','service':'web.service'})['actions']
        self.assertFalse(next(r for r in rows if r['action_id']==identifier)['undo_candidate'])
        with self.assertRaises(ValueError):self.undo(identifier)

    def test_noop_cannot_smuggle_stopped_before_state_or_transaction(self):
        identifier=self.queue_automatic(); self.native='running'
        result=self.deliver(identifier)
        params=self.store.get_action(identifier)['parameters']
        for change in ({'desired_state':'stopped'}, {'transaction_id':str(uuid.uuid4())}):
            bad=copy.deepcopy(result); bad['pre_state'].update(change)
            with self.assertRaises(ValueError):_require_success_result_contract('restart_service',params,bad)

    def test_service_stopping_during_noop_validation_is_not_restarted(self):
        identifier=self.queue_automatic();self.native='running'
        def validate(*args,**kwargs):
            self.native='stopped'
            return [ProbeResult('web-health',self.profile.services[0]['expected_transactions'][0]['target'],True)],3,True
        with patch.object(self.executor,'_wait_for_service_probes',side_effect=validate):result=self.deliver(identifier)
        self.assertFalse(result['success']);self.assertEqual(self.transitions,[])
        self.assertEqual(list(self.executor.state_dir.glob('service-repair-*.json')),[])

    def test_operator_pause_cancels_only_never_delivered_automatic_work(self):
        from sentinel_blue.service_automation import cancelled_before_delivery
        identifier=self.queue_automatic()
        manual=self.store.queue_action('agent-one','validate_service',{'service':'web.service','probes':self.profile.services[0]['expected_transactions']})
        self.app.set_service_automation({'agent_id':'agent-one','service':'web.service','paused':True,
            'reason':'cancel undelivered automatic work only','expected_revision':0},'operator')
        self.assertTrue(cancelled_before_delivery(self.store.get_action(identifier)))
        self.assertEqual(self.store.get_action(manual)['status'],'queued')
        budget=self.store.service_recovery_budget_status('agent-one','web.service')
        self.assertEqual(budget['attempts_in_window'],0)
        # Read-only queued checks do not block resume, nor get cancelled.
        self.assertFalse(self.resume()['service_automation']['services']['web.service']['paused'])

    def test_operator_pause_never_claims_delivered_work_is_cancelled(self):
        identifier=self.queue_automatic();self.app.pending_actions_for_agent('agent-one')
        self.app.set_service_automation({'agent_id':'agent-one','service':'web.service','paused':True,
            'reason':'a delivered effect remains uncertain','expected_revision':0},'operator')
        self.assertEqual(self.store.get_action(identifier)['status'],'dispatched')
        with self.assertRaises(PermissionError):self.resume()

    def test_changed_configuration_prevents_fake_successful_noop(self):
        identifier=self.queue_automatic();self.native='running';self.target.write_bytes(b'changed')
        result=self.deliver(identifier)
        self.assertFalse(result['success']);self.assertEqual(self.transitions,[])


class OfflineRecordedUndoTests(unittest.TestCase):
    def setUp(self):
        from test_offline_authority import OfflineAuthorityTests
        self.f=OfflineAuthorityTests('test_no_policy_means_monitoring_only')
        self.f.setUp();self.addCleanup(self.f.doCleanups)

    def test_authenticated_offline_import_is_visible_for_reviewed_undo(self):
        f=self.f;f.authorize();f.repair();f.agent.sync(f.client,f.journal)
        identifier=f.store._connection.execute("SELECT action_id FROM actions WHERE result_source='agent-offline'").fetchone()[0]
        fresh=copy.deepcopy(f.baseline);fresh.update(sequence=4,observed_at=time.time())
        f.app.ingest(fresh,'agent-one',f.store.agent_secret('agent-one'))
        rows=f.app.service_action_history({'agent_id':'agent-one','service':'web.service'})['actions']
        row=next(r for r in rows if r['action_id']==identifier)
        self.assertTrue(row['automated']);self.assertTrue(row['undo_candidate'])
        review=f.app.review_service_action({'agent_id':'agent-one','service':'web.service','choice':'undo','action_id':identifier},'operator')
        self.assertEqual(review['action_type'],'rollback_service')
        # This is the signed offline importer + controller review. The fixture's
        # native executor is inert; native inverse is covered by the other tests.

    def test_local_undo_hold_stops_offline_before_intent_or_budget_consumption(self):
        f=self.f;f.authorize();control=LocalAutomation(f.executor.state_dir,f.profile,'agent-one')
        control.latch('web.service',str(uuid.uuid4()));f.outage()
        before=f.agent.journal.head()
        self.assertEqual(f.step(2),0);self.assertEqual(f.step(3),0)
        self.assertEqual(f.calls,0);self.assertEqual(f.agent.journal.head(),before)
        self.assertIn('paused',f.agent.status.lower())
        # Restart/reload of the continuity helper cannot erase its agent latch.
        from sentinel_blue.offline_continuity import AgentContinuity
        f.agent=AgentContinuity(f.root,f.profile,'agent-one',f.token,ledger=f.ledger)
        f.agent.online=False;f.agent.state['lease_until']=0;f.agent._save()
        f.step(4);f.step(5)
        self.assertEqual(f.calls,0);self.assertEqual(f.agent.journal.head(),before)

    def test_new_offline_authorization_respects_controller_service_hold(self):
        f=self.f;update(f.store,f.profile,'agent-one','web.service',True,'held before offline authorization')
        with self.assertRaisesRegex(ValueError,'paused'):f.authorize()

    def test_local_pause_snapshot_stops_offline_even_without_undo_latch(self):
        f=self.f;f.authorize()
        state=update(f.store,f.profile,'agent-one','web.service',True,'explicit standalone operator pause')
        LocalAutomation(f.executor.state_dir,f.profile,'agent-one').accept(state)
        f.outage();f.step(2);f.step(3)
        self.assertEqual(f.calls,0);self.assertEqual(f.agent.journal.head()['sequence'],0)
        self.assertIn('paused',f.agent.status.lower())

if __name__=='__main__':unittest.main()
