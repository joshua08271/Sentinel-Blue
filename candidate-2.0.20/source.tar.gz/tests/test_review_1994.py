"""Corrective 1.9.94 tests. Temporary files/loopback/Tk or explicit models only.

No case here is native service acceptance, real systemd, or competition uptime.
"""
from __future__ import annotations
import contextlib
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import socket
import sys
import tempfile
import time
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'tools'))
from acceptance_profile import profile_problems, transition_problems, probe_problems, argv_safety_problems
from service_pack_acceptance import probe_verdict, Executor, load_json_argument, absolute_sources, show_plan
from acceptance_steps import Acceptance
from service_pack_acceptance import Report
from sentinel_blue import pack_acceptance
from sentinel_blue.linux_service_catalog import CATALOG, entry
from sentinel_blue.service_ports import resolve_ports
from test_acceptance_walk import OPTIONS, PROFILE, INVENTORY, FakeHost, FakeRuntime


def result(code=0, stdout='', stderr='', **extra):
    return {'returncode':code, 'stdout':stdout, 'stderr':stderr, **extra}


class ProbeJudgment1994Tests(unittest.TestCase):
    def test_real_closed_loopback_port_is_not_an_access_denial(self):
        if not Path('/usr/bin/curl').exists():
            self.skipTest('native curl unavailable')
        with socket.socket() as reserved:
            reserved.bind(('127.0.0.1',0))
            r=Executor().run(['/usr/bin/curl','--silent','--show-error','--max-time','2',
                             f'http://127.0.0.1:{reserved.getsockname()[1]}/'])
            self.assertEqual(r['returncode'],7)
            self.assertFalse(probe_verdict(r,{'expect_failure':True})[0])

    def test_unspecified_exit_code_requires_success(self):
        self.assertFalse(probe_verdict(result(7),{})[0])
        self.assertTrue(probe_verdict(result(),{})[0])

    def test_denial_needs_positive_signature_not_only_absent_success(self):
        self.assertFalse(probe_verdict(result(1), {'expect_failure':True, 'expect_stdout_absent':['PONG']})[0])

    def test_specific_denial_is_accepted(self):
        self.assertTrue(probe_verdict(result(1,stderr='NOAUTH Authentication required'),
            {'expect_failure':True,'expect_stderr_contains':['NOAUTH']}, require_denial=True)[0])

    def test_transport_error_with_expected_exit_but_no_refusal_signature_fails(self):
        self.assertFalse(probe_verdict(result(1,stderr='Connection refused'),
            {'expect_returncode':1, 'expect_stderr_contains':['NOAUTH']},require_denial=True)[0])

    def test_denial_with_zero_status_needs_explicit_product_evidence(self):
        r=result(stdout='Transfer failed')
        self.assertTrue(probe_verdict(r,{'expect_returncode':0,'expect_stdout_contains':['Transfer failed']},require_denial=True)[0])
        self.assertFalse(probe_verdict(r,{'expect_returncode':0},require_denial=True)[0])

    def test_stderr_cannot_satisfy_a_stdout_assertion(self):
        self.assertFalse(probe_verdict(result(stdout='WRONG',stderr='EXPECTED'),
            {'expect_returncode':0,'expect_stdout_contains':['EXPECTED']})[0])

    def test_explicit_combined_stream_is_supported(self):
        self.assertTrue(probe_verdict(result(stderr='EXPECTED'),
            {'expect_returncode':0,'expect_output_contains':['EXPECTED']})[0])

    def test_stream_boundaries_do_not_join_into_false_signature(self):
        self.assertFalse(probe_verdict(result(stdout='PART',stderr='TWO'),
            {'expect_output_contains':['PARTTWO']})[0])

    def test_missing_output_is_not_measured_success(self):
        for data in ({'returncode':0}, result(stdout=None), result(stderr=[])):
            with self.subTest(data=data):self.assertFalse(probe_verdict(data,{})[0])

    def test_infrastructure_results_never_prove_denial(self):
        for data in (result(-1,stderr='NOAUTH'), result(1,stderr='NOAUTH',infrastructure_error=True),
                     result(1,stderr='NOAUTH',truncated=True),result(1,stderr='NOAUTH',skipped=True)):
            with self.subTest(data=data):
                self.assertFalse(probe_verdict(data,{'expect_failure':True,'expect_stderr_contains':['NOAUTH']})[0])

    def test_malformed_match_collections_are_refused(self):
        for bad in ('EXPECTED', None, {}, [None], [''], ['x']*33):
            with self.subTest(value=bad):
                self.assertFalse(probe_verdict(result(),{'expect_stdout_contains':bad})[0])

    def test_only_real_exit_code_expectations_are_accepted(self):
        for bad in (True, False, 256, -1, '0',None):
            with self.subTest(code=bad):
                self.assertFalse(probe_verdict(result(),{'expect_returncode':bad})[0])


class AcceptancePreflight1994Tests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.profile=copy.deepcopy(PROFILE)

    def problems(self,profile=None,options=None):
        return profile_problems('redis',OPTIONS if options is None else options,
                                self.profile if profile is None else profile,self.root)

    def test_complete_model_contract_is_structurally_valid(self):
        self.assertEqual(self.problems(),[])

    def test_builder_rejection_cannot_be_native_failure_options(self):
        self.profile['invalid_options']={'port':0}
        self.assertTrue(any('must compile before apply' in p for p in self.problems()))

    def test_update_requires_correct_preceding_file_hash(self):
        self.profile['update_options'].pop('previous_files')
        self.assertTrue(any('update_options: reviewed previous_sha256' in p for p in self.problems()))

    def test_invalid_apply_requires_post_update_hash(self):
        self.profile['invalid_options']['previous_files']=copy.deepcopy(self.profile['update_options']['previous_files'])
        self.assertTrue(any('invalid_options: reviewed previous_sha256' in p for p in self.problems()))

    def test_metadata_only_update_is_not_configuration_update(self):
        self.profile['update_options']=dict(OPTIONS,previous_sha256='a'*64)
        self.assertTrue(any('must change generated configuration' in p for p in self.problems()))

    def test_bad_profile_blocks_before_any_host_command_or_apply(self):
        inv=self.root/'inventory';inv.write_text(json.dumps(INVENTORY))
        self.profile['invalid_options']={'port':0}
        host=FakeHost();runtime=mock.Mock()
        a=Acceptance(service_id='redis',row=entry('redis'),options=OPTIONS,profile=self.profile,
                     executor=host,runtime=runtime,workdir=self.root,inventory=inv,report=Report('redis'),fingerprint='a'*64)
        with contextlib.redirect_stdout(io.StringIO()):a.walk()
        self.assertEqual(a.report.results['preflight']['verdict'],'failed')
        self.assertFalse(a.report.required_all_passed)
        runtime.apply.assert_not_called();runtime.withdraw.assert_not_called()
        self.assertEqual(host.log,[]);self.assertEqual(host.writes,[])

    def test_rejected_options_remain_separate_read_only_check(self):
        self.profile['rejected_options']={'port':0}
        self.assertEqual(self.problems(),[])
        self.profile['rejected_options']=copy.deepcopy(OPTIONS)
        self.assertTrue(any('rejected_options was accepted' in p for p in self.problems()))

    def test_empty_initial_defaults_are_actually_compiled(self):
        # Redis defaults are valid; initial default bytes agree with OPTIONS.
        self.assertEqual(self.problems(options={}),[])

    def test_missing_native_input_and_observer_are_both_named(self):
        self.profile['invalid_options']={};self.profile.pop('withdrawal')
        p=self.problems()
        self.assertIn('invalid_options is missing or empty',p)
        self.assertIn('withdrawal is missing or empty',p)

    def test_placeholder_observer_is_refused(self):
        self.profile['withdrawal']['inventory']='/REPLACE/inventory.json'
        self.assertTrue(any('not a placeholder' in p for p in self.problems()))

    def test_positive_probe_cannot_request_failure(self):
        self.profile['positive']['expect_returncode']=1
        self.assertTrue(any('must prove command success' in p for p in self.problems()))

    def test_denied_probe_cannot_turn_off_failure_without_explicit_code(self):
        self.profile['denied']['expect_failure']=False
        self.assertTrue(any('refusal exit status' in p for p in self.problems()))

    def test_data_invariant_must_name_declared_data(self):
        self.profile['data_invariants']={'/unrelated':{'argv':['/query']}}
        self.assertTrue(any('data_invariants' in p for p in self.problems()))

    def test_all_examples_are_honestly_incomplete_before_native_work(self):
        profiles=json.loads((ROOT/'examples/acceptance-profile.example.json').read_text())
        options=json.loads((ROOT/'examples/acceptance-options.example.json').read_text())
        for sid,opts in options.items():
            if sid.startswith('_'):continue
            with self.subTest(service=sid):
                self.assertIn('DRAFT',profiles[sid]['_review'])
                self.assertEqual(profiles[sid]['invalid_options'],{})
                self.assertIn('rejected_options',profiles[sid])
                errors=profile_problems(sid,opts,profiles[sid],ROOT/'examples')
                self.assertIn('invalid_options is missing or empty',errors)
                self.assertIn('withdrawal is missing or empty',errors)

    def test_nested_malformed_probe_fails_without_exception(self):
        for value in (None,[],{'argv':None},{'argv':['/x'],'expect_returncode':True},
                      {'argv':['/x'],'expect_stderr_contains':[None]}):
            with self.subTest(value=value):
                p=copy.deepcopy(self.profile);p['denied']=value
                self.assertTrue(self.problems(p))


class ProfileSecurity1994Tests(unittest.TestCase):
    def test_known_inline_password_forms_are_rejected_without_echoing_secret(self):
        secret='TEST-NOT-A-REAL-SECRET'
        commands=[['/usr/bin/redis-cli','-a',secret,'PING'],
                  ['/usr/bin/mosquitto_sub','-P',secret],
                  ['/usr/bin/curl','--user','blue:'+secret,'https://127.0.0.1'],
                  ['/usr/bin/smbclient','-U','blue%'+secret],
                  ['/usr/bin/mysql','--password='+secret],
                  ['/usr/bin/mariadb','-p'+secret],
                  ['/usr/bin/curl','https://blue:'+secret+'@127.0.0.1/']]
        for argv in commands:
            with self.subTest(client=argv[0]):
                errors=argv_safety_problems(argv,'probe')
                self.assertTrue(errors);self.assertNotIn(secret,' '.join(errors))

    def test_ssh_verification_bypass_is_refused(self):
        for flag in ('StrictHostKeyChecking=no','stricthostkeychecking off','UserKnownHostsFile=/dev/null'):
            argv=['/usr/bin/ssh','-o',flag,'127.0.0.1','true']
            if ' off' in flag:argv[2]='StrictHostKeyChecking=off'
            with self.subTest(flag=flag):self.assertTrue(argv_safety_problems(argv,'ssh'))

    def test_verified_ssh_and_protected_file_arguments_are_allowed(self):
        self.assertEqual(argv_safety_problems(['/usr/bin/ssh','-o','StrictHostKeyChecking=yes',
            '-o','UserKnownHostsFile=/etc/sentinel/hosts','blue@127.0.0.1','true'],'ssh'),[])
        self.assertEqual(argv_safety_problems(['/usr/bin/smbclient','-A','/private/client.conf'],'smb'),[])
        self.assertEqual(argv_safety_problems(['/usr/bin/curl','--config','/private/client.conf'],'curl'),[])

    def test_tls_bypass_is_refused(self):
        self.assertTrue(argv_safety_problems(['/usr/bin/curl','-k','https://127.0.0.1'],'curl'))

    def test_duplicate_profile_keys_are_refused(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'profile';p.write_text('{"denied":{},"denied":{"expect_failure":false}}')
            with contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit):load_json_argument(p,'profile')

    def test_nonfinite_and_oversize_profile_files_are_refused(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'profile'
            for data in ('{"x":NaN}', ' '* (2*1024*1024+1)):
                p.write_text(data)
                with contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit):load_json_argument(p,'profile')


class ExistingPortProtection1994Tests(unittest.TestCase):
    def observation(self):return {'observed_at':time.time(),'complete':True,'listeners':[{'port':80,'protocol':'tcp'}]}

    def test_unknown_service_does_not_auto_migrate(self):
        options,report=resolve_ports('nginx',{}, {},observation=self.observation(),allow_alternates=True)
        self.assertEqual(options['port'],80);self.assertIn('no automatic migration',report['decisions'][0]['reason'])

    def test_existing_service_keeps_default_when_current_value_omitted(self):
        for state in ('installed','running'):
            with self.subTest(state=state):
                options,_=resolve_ports('nginx',{}, {},observation=self.observation(),allow_alternates=True,service_presence=state)
                self.assertEqual(options['port'],80)

    def test_absent_service_can_use_reviewable_alternate(self):
        options,_=resolve_ports('nginx',{}, {},observation=self.observation(),allow_alternates=True,service_presence='absent')
        self.assertEqual(options['port'],20000)

    def test_missing_service_does_not_override_configured_port(self):
        options,_=resolve_ports('nginx',{'port':80}, {},observation=self.observation(),allow_alternates=True,service_presence='absent')
        self.assertEqual(options['port'],80)

    def test_missing_service_does_not_override_event_port(self):
        options,_=resolve_ports('nginx',{}, {},required={'port':80},observation=self.observation(),allow_alternates=True,service_presence='absent')
        self.assertEqual(options['port'],80)

    def test_existing_collision_requires_explicit_review(self):
        with self.assertRaises(ValueError):
            resolve_ports('nginx',{}, {},reserved={('tcp',80)},observation=self.observation(),allow_alternates=True,service_presence='running')

    def test_manual_choice_remains_available_without_scanning(self):
        options,_=resolve_ports('nginx',{}, {'port':{'mode':'manual','port':8080}},service_presence='running')
        self.assertEqual(options['port'],8080)

    def test_malformed_presence_is_not_new_service_evidence(self):
        for bad in (None,True,[],{},'new'):
            with self.subTest(value=bad),self.assertRaises(ValueError):
                resolve_ports('nginx',{}, {},service_presence=bad)

    def test_catalog_flags_remain_unaccepted(self):
        self.assertTrue(all(row['native_tested'] is False for row in CATALOG.values()))



class EarlyPlanning1994Tests(unittest.TestCase):
    def make_walk(self, root, runtime_class=FakeRuntime):
        inv = root/'inventory.json'; inv.write_text(json.dumps(INVENTORY))
        host = FakeHost()
        owned = [f['path'] for f in pack_acceptance.pack_contract('redis',OPTIONS,root)['files']]
        runtime = runtime_class(host, owned)
        a = Acceptance(service_id='redis',row=entry('redis'),options=OPTIONS,profile=copy.deepcopy(PROFILE),
                       executor=host,runtime=runtime,workdir=root,inventory=inv,report=Report('redis'),fingerprint='b'*64)
        return a, runtime, host

    def test_future_update_plan_failure_blocks_initial_apply(self):
        class FutureFails(FakeRuntime):
            def plan(self, inventory, plan_out):
                if 'preflight-inventory-update' in str(inventory):
                    return result(2,stderr='event port mismatch'),None
                return super().plan(inventory,plan_out)
        with tempfile.TemporaryDirectory() as td:
            a, runtime, host = self.make_walk(Path(td), FutureFails)
            with contextlib.redirect_stdout(io.StringIO()): a.walk()
            self.assertEqual(a.report.results['compile']['verdict'],'failed')
            self.assertIn('update planning failed',a.report.results['compile']['detail'])
            self.assertEqual(runtime.applied,0);self.assertEqual(host.writes,[])

    def test_future_invalid_plan_failure_blocks_initial_apply(self):
        class FutureFails(FakeRuntime):
            def plan(self, inventory, plan_out):
                if 'preflight-inventory-invalid' in str(inventory):
                    return result(2,stderr='out of approved scope'),None
                return super().plan(inventory,plan_out)
        with tempfile.TemporaryDirectory() as td:
            a,runtime,host=self.make_walk(Path(td),FutureFails)
            with contextlib.redirect_stdout(io.StringIO()):a.walk()
            self.assertEqual(a.report.results['compile']['verdict'],'failed')
            self.assertEqual(runtime.applied,0);self.assertEqual(host.writes,[])

    def test_changed_initial_digest_cannot_be_auto_approved_after_preflight(self):
        class Changes(FakeRuntime):
            def plan(self,inventory,plan_out):
                value,digest=super().plan(inventory,plan_out)
                if Path(plan_out).name=='plan.json':digest='c'*64
                return value,digest
        with tempfile.TemporaryDirectory() as td:
            a,runtime,host=self.make_walk(Path(td),Changes)
            with contextlib.redirect_stdout(io.StringIO()):a.walk()
            self.assertEqual(a.report.results['compile']['verdict'],'passed')
            self.assertEqual(a.report.results['apply']['verdict'],'failed')
            self.assertEqual(runtime.applied,0);self.assertEqual(host.writes,[])

    def test_normal_simulation_has_three_prepared_plans_and_completes(self):
        with tempfile.TemporaryDirectory() as td:
            a,runtime,host=self.make_walk(Path(td))
            with contextlib.redirect_stdout(io.StringIO()):a.walk()
            self.assertTrue(a.report.required_all_passed)
            self.assertEqual(set(a.prepared_digests),{'initial','update','invalid'})
            self.assertEqual(len(set(a.prepared_digests.values())),3)

    def test_plan_refuses_to_echo_password_arguments(self):
        profile=copy.deepcopy(PROFILE)
        profile['positive']={'argv':['/usr/bin/redis-cli','-a','fixture-password-do-not-echo','PING']}
        output=io.StringIO()
        with contextlib.redirect_stdout(output):show_plan('redis',OPTIONS,profile,root=ROOT)
        self.assertNotIn('fixture-password-do-not-echo',output.getvalue())
        self.assertIn('arguments withheld',output.getvalue())
        self.assertIn('password-bearing argv',output.getvalue())

    def test_options_and_profile_resolve_sources_relative_to_their_own_file(self):
        one={'activation':{'/etc/service.conf':{'path':'snapshot.conf','sha256':'a'*64}}}
        two={'update_options':{'activation':{'/etc/service.conf':{'path':'snapshot.conf','sha256':'b'*64}}},
             'positive':{'argv':['/some/absolute-client','relative-argument']}}
        a=absolute_sources(one,Path('/first'))
        b=absolute_sources(two,Path('/second'))
        self.assertEqual(a['activation']['/etc/service.conf']['path'],'/first/snapshot.conf')
        self.assertEqual(b['update_options']['activation']['/etc/service.conf']['path'],'/second/snapshot.conf')
        self.assertEqual(b['positive'],two['positive'])
        self.assertEqual(one['activation']['/etc/service.conf']['path'],'snapshot.conf')

    def test_ssh_space_form_and_observer_verification_are_not_bypasses(self):
        for flag in ('StrictHostKeyChecking no','StrictHostKeyChecking = no','UserKnownHostsFile /dev/null'):
            self.assertTrue(argv_safety_problems(['/usr/bin/ssh','-o',flag],'ssh'))
        p=copy.deepcopy(PROFILE)
        p['withdrawal']['runtime_argv']=['/usr/bin/ssh','-o','StrictHostKeyChecking=no','observer']
        self.assertTrue(any('peer verification' in e for e in profile_problems('redis',OPTIONS,p,ROOT)))

    def test_non_string_option_keys_are_controlled_refusals(self):
        errors=profile_problems('redis',{1:'bad'},copy.deepcopy(PROFILE),ROOT)
        self.assertTrue(any('string keys' in e for e in errors))

@unittest.skipUnless(os.environ.get('DISPLAY'),'requires a graphical display')
class RealPortGUI1994Tests(unittest.TestCase):
    def test_actual_dialog_retains_existing_and_allows_absent_service_candidate(self):
        import tkinter as tk
        from tkinter import ttk
        from sentinel_blue.desktop_services import ServiceSelectionPanel
        root=tk.Tk();root.withdraw()
        panel=ServiceSelectionPanel(root,(tk,ttk),port_context_provider=lambda *_:{'host':'web',
            'observation':{'observed_at':time.time(),'complete':True,'listeners':[{'protocol':'tcp','port':80}]}})
        try:
            panel.observe({'nginx':'running'},host='web')
            panel.tree.selection_set('nginx');panel._edit_ports();root.update()
            editor=panel.port_editor;editor.alternate.set(True);editor.preview()
            self.assertEqual(editor.result[0]['port'],80)
            self.assertEqual(editor.result[1]['service_presence'],'running')
            editor.close()
            panel.observe({'nginx':'absent'},host='web')
            panel.tree.selection_set('nginx');panel._edit_ports();root.update()
            editor=panel.port_editor;editor.alternate.set(True);editor.preview()
            self.assertEqual(editor.result[0]['port'],20000)
            editor.rows['port']['mode'].set('Manual');editor.rows['port']['value'].set('18094');editor.save()
            self.assertEqual(panel.options['nginx']['port'],18094)
        finally:
            if panel.port_editor and panel.port_editor.window is not None:panel.port_editor.close()
            root.destroy()


if __name__=='__main__':unittest.main()
