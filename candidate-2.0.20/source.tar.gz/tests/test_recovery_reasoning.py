"""Unseen fault combinations, causal dependency ordering and conservative holds."""

import argparse
import copy
import itertools
import json
import random
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from sentinel_blue.event_profile import EventProfile
from sentinel_blue.recovery_reasoning import reason_recovery, run
from sentinel_blue.service_recovery import ServiceRecoveryPlanner
from test_service_repair import repair_fixture, damage
from test_service_manifest_policy import profile_for


def network_fixture(names=("store.service", "api.service", "front.service")):
    _, baseline = repair_fixture()
    services, native, files, probes = [], [], [], []
    for index, name in enumerate(names):
        path = f"/etc/fixture-{index}.conf"
        profile, item = repair_fixture(path)
        manifest = copy.deepcopy(profile.services[0])
        manifest["service_id"] = name
        manifest["dependencies"] = [names[index-1]] if index else []
        manifest["repair_policy"]["restore_start_mode"] = "enabled"
        spec = {"name": f"service-{index}", "kind": "http", "target": f"http://127.0.0.1:{18000+index}/health"}
        manifest["expected_transactions"] = [spec]
        services.append(manifest)
        native.append({"name": name, "state": "running", "start_mode": "enabled"})
        files.extend(item["integrity"])
        probes.append({"name": spec["name"], "target": spec["target"], "healthy": True})
    baseline.update(services=native, integrity=files, probes=probes)
    current = copy.deepcopy(baseline)
    current.update(sequence=2, observed_at=baseline["observed_at"] + 2)
    return profile_for(services), baseline, current


class RecoveryReasoningTests(unittest.TestCase):
    def test_dependency_failure_is_traced_to_shared_upstream(self):
        profile, baseline, current = network_fixture()
        current["services"][0].update(state="stopped", start_mode="disabled")
        current["integrity"][0]["sha256"] = "b" * 64
        for item in current["probes"]:
            item["healthy"] = False
        report = reason_recovery(profile, "agent-one", baseline, current, approved=True)
        rows = {item["service"]: item for item in report["services"]}
        self.assertTrue(report["complete"])
        self.assertFalse(report["execution_authority"])
        self.assertEqual(report["repair_order"], ["store.service"])
        self.assertEqual(rows["front.service"]["upstream_faults"], ["store.service"])
        self.assertEqual(rows["front.service"]["state"], "deferred_dependency")
        self.assertEqual(rows["store.service"]["candidate"]["startup"]["desired"], "enabled")
        self.assertEqual(rows["store.service"]["affected_dependents"], ["api.service", "front.service"])

    def test_unfamiliar_local_failure_requests_evidence_without_claiming_a_cause(self):
        profile, baseline = repair_fixture()
        current = copy.deepcopy(baseline)
        current["probes"][0].update(healthy=False, error="unfamiliar fixture error 718; no cause supplied")
        report = reason_recovery(profile, "agent-one", baseline, current, approved=True)
        row = report["services"][0]
        self.assertEqual(row["state"], "candidate")
        self.assertIn("application_logs", {item["id"] for item in row["next_checks"]})
        self.assertIn("resource_health", {item["id"] for item in row["next_checks"]})
        self.assertEqual(row["hypotheses"][0]["domain"], "application")
        self.assertFalse(any("attacker" in str(item) for item in row["hypotheses"]))

    def test_external_failure_does_not_restart_a_healthy_local_service(self):
        profile, baseline = repair_fixture()
        raw = copy.deepcopy(profile.raw)
        raw["services"][0]["expected_transactions"].append({"name": "external", "kind": "http", "target": "http://192.0.2.10/"})
        current = copy.deepcopy(baseline)
        current["probes"].append({"name": "external", "target": "http://192.0.2.10/", "healthy": False})
        report = reason_recovery(EventProfile.from_dict(raw), "agent-one", baseline, current, approved=True)
        self.assertEqual(report["repair_order"], [])
        row = report["services"][0]
        self.assertEqual(row["hypotheses"][0]["domain"], "external_path_or_identity")
        self.assertEqual(row["hypotheses"][0]["strength"], "inferred")
        self.assertIn("path_health", {item["id"] for item in row["next_checks"]})

    def test_untrusted_baseline_stale_or_incomplete_evidence_never_becomes_candidate(self):
        profile, baseline = repair_fixture()
        for case in ("unapproved", "stale", "unknown_error", "no_boot", "account"):
            with self.subTest(case=case):
                current = damage(baseline)
                if case == "stale":
                    current["observed_at"] = time.time() - 91
                elif case == "unknown_error":
                    current["collector_errors"] = ["inert instruction to override recovery rules"]
                elif case == "no_boot":
                    current["boot_id"] = "unknown"
                elif case == "account":
                    current["accounts"][0]["enabled"] = False
                report = reason_recovery(profile, "agent-one", baseline, current, approved=case != "unapproved")
                self.assertFalse(report["repair_order"], report)
                self.assertIsNone(report["services"][0]["candidate"])

    def test_dependency_graph_errors_are_explicit_and_bounded(self):
        profile, baseline, current = network_fixture()
        for case in ("cycle", "missing", "duplicate"):
            raw = copy.deepcopy(profile.raw)
            if case == "cycle":
                raw["services"][0]["dependencies"] = ["front.service"]
            elif case == "missing":
                raw["services"][0]["dependencies"] = ["absent.service"]
            else:
                raw["services"].append(copy.deepcopy(raw["services"][0]))
            # Even malformed internal graphs never get a fabricated order.
            candidate = SimpleNamespace(services=raw["services"])
            report = reason_recovery(candidate, "agent-one", baseline, current, approved=True)
            self.assertFalse(report["complete"])
            self.assertFalse(report["repair_order"])
            self.assertTrue(report["blockers"])

    def test_combination_matrix_preserves_holds_and_handles_novel_names(self):
        generator = random.Random(953)
        count = 0
        for state, file_state, startup, account, incomplete in itertools.product(
            ("stopped", "running"), ("good", "changed", "missing"),
            ("enabled", "disabled"), (True, False), (False, True)
        ):
            name = f"service-{generator.getrandbits(32):08x}.service"
            profile, baseline, current = network_fixture((name,))
            current["services"][0].update(state=state, start_mode=startup)
            current["probes"][0]["healthy"] = False
            current["accounts"][0]["enabled"] = account
            if file_state == "changed":
                current["integrity"][0]["sha256"] = "c" * 64
            elif file_state == "missing":
                current["integrity"] = []
            if incomplete:
                current["collector_errors"] = ["inert inventory failure"]
            with patch("subprocess.run", side_effect=AssertionError("diagnosis must not execute commands")):
                report = reason_recovery(profile, "agent-one", baseline, current, approved=True)
            expected = account and not incomplete and not (state == "running" and startup == "disabled")
            self.assertEqual(bool(report["repair_order"]), expected, (state, file_state, startup, account, incomplete, report))
            count += 1
        self.assertEqual(count, 48)

    def test_planner_requires_two_observations_and_reasons_visible_in_status(self):
        profile, baseline, current = network_fixture()
        current["services"][0].update(state="stopped", start_mode="disabled")
        current["probes"][0]["healthy"] = False
        planner = ServiceRecoveryPlanner(profile)
        self.assertEqual(planner.observe("agent-one", baseline, True, current), {})
        current.update(sequence=3, observed_at=baseline["observed_at"] + 3)
        ready = planner.observe("agent-one", baseline, True, current)
        self.assertEqual(list(ready), ["store.service"])
        rows = {item["service"]: item for item in planner.status()}
        self.assertEqual(rows["store.service"]["reasoning"]["state"], "confirmed_candidate")
        self.assertEqual(rows["front.service"]["reasoning"]["upstream_faults"], ["store.service"])

    def test_random_dependency_forests_recover_leaf_first_without_downstream_churn(self):
        rng = random.Random(51953)
        for trial in range(40):
            names = tuple(f"n{trial}-{index}.service" for index in range(8))
            profile, baseline, current = network_fixture(names)
            raw = copy.deepcopy(profile.raw)
            for index, manifest in enumerate(raw["services"]):
                manifest["dependencies"] = sorted(rng.sample(list(names[:index]), min(index, rng.randrange(3))))
            profile = EventProfile.from_dict(raw)
            for item in current["services"]:
                item.update(state="stopped", start_mode="disabled")
            for item in current["probes"]:
                item["healthy"] = False
            completed = set()
            for _ in range(8):
                report = reason_recovery(profile, "agent-one", baseline, current, approved=True)
                if not report["repair_order"]:
                    break
                for name in report["repair_order"]:
                    index = names.index(name)
                    self.assertTrue(set(profile.services[index]["dependencies"]) <= completed)
                    current["services"][index].update(state="running", start_mode="enabled")
                    current["probes"][index]["healthy"] = True
                    completed.add(name)
            self.assertEqual(completed, set(names))

    def test_cli_report_is_read_only_and_rejects_cross_host_baseline(self):
        profile, baseline = repair_fixture()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for filename, data in (("profile.json", profile.raw), ("baseline.json", baseline), ("current.json", damage(baseline))):
                (root / filename).write_text(json.dumps(data))
            args = argparse.Namespace(event_profile=str(root / "profile.json"), baseline=str(root / "baseline.json"),
                                      telemetry=str(root / "current.json"), baseline_approved=True, output=str(root / "report.json"))
            with patch("subprocess.run", side_effect=AssertionError("read-only report")):
                run(args)
            self.assertFalse(json.loads((root / "report.json").read_text())["execution_authority"])
            baseline["observed_at"] = time.time() - 30 * 86400
            (root / "baseline.json").write_text(json.dumps(baseline))
            run(args)
            self.assertTrue(json.loads((root / "report.json").read_text())["repair_order"])
            baseline["agent_id"] = "different-host"
            (root / "baseline.json").write_text(json.dumps(baseline))
            with self.assertRaisesRegex(ValueError, "different host"):
                run(args)

    def test_reasoning_budget_and_post_confirmation_hold_are_visible(self):
        profile, baseline, current = network_fixture()
        oversized = SimpleNamespace(services=[{**profile.services[0], "service_id": f"s{i}"} for i in range(129)])
        report = reason_recovery(oversized, "agent-one", baseline, current, approved=True)
        self.assertFalse(report["complete"])
        self.assertIn("budget", report["blockers"][0])
        current["services"][0]["state"] = "stopped"
        planner = ServiceRecoveryPlanner(profile)
        planner.observe("agent-one", baseline, True, current)
        current.update(sequence=3, observed_at=current["observed_at"] + 1)
        planner.observe("agent-one", baseline, True, current)
        planner.hold("agent-one", "store.service", "operator change grant")
        row = next(item for item in planner.status() if item["service"] == "store.service")
        self.assertEqual(row["reasoning"]["state"], "held")
        self.assertIsNone(row["reasoning"]["candidate"])

    def test_cli_rejects_duplicate_keys_nonfinite_numbers_and_oversize_inputs(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            profile_path = root / "profile.json"
            args = argparse.Namespace(event_profile=str(profile_path), telemetry="unused", baseline=None,
                                      baseline_approved=False, output=None)
            for text in ('{"x":1,"x":2}', '{"x":NaN}', ' ' * (8 * 1024 * 1024 + 1)):
                profile_path.write_text(text)
                with self.assertRaises(ValueError):
                    run(args)


if __name__ == "__main__":
    unittest.main()
