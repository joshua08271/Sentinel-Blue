"""2.0.16: the first five autonomy blockers from the 2.0.15 review.

1. The open-alert quota switched off automatic service recovery.
2. After a controller crash automation stayed off, and the GUI could not bring
   it back; a start that failed before serving was recorded as a crash.
3. A wall-clock step stopped all agent actions until the agent restarted
   (covered in test_offline_authority).
4. One process running from a deleted executable held every service.
5. The controller supervisor gave up for good (covered in
   test_controller_supervisor and test_boot_and_continuity_controls).
"""
import copy
import hashlib
import os
import shutil
import tempfile
import threading
import time
import unittest
from dataclasses import asdict
from pathlib import Path
from unittest.mock import Mock, patch

from sentinel_blue import store as store_module
from sentinel_blue.controller import (
    ControllerApp, _abandon_controller_startup, is_recovery_candidate, prioritize_detection_candidates,
)
from sentinel_blue.protocol import AlertCandidate, PersistenceItem
from sentinel_blue.store import OPEN_ALERT_LIMITS_BY_SEVERITY, Store
from test_autonomous_service_recovery import fixtures, stopped
from test_store_controller import _promote_integrity_baseline


def _candidate(kind, service=None, severity="high", **evidence):
    if service is not None:
        evidence["service"] = service
    return AlertCandidate(kind=kind, title=kind, summary=kind, severity=severity, confidence=0.9,
                          evidence=evidence, recommendation="review", recommended_action="snapshot")


class AlertQuotaRecoveryLaneTests(unittest.TestCase):
    """Bug 1 (and the same mechanism, bug 10): unrelated alerts cannot switch recovery off."""

    def controller(self, baseline_changes=None):
        profile, baseline = fixtures()
        if baseline_changes:
            baseline_changes(baseline)
        store = Store(":memory:")
        self.addCleanup(store.close)
        app = ControllerApp(store, "t" * 32, operator_token="o" * 32,
                            event_profile=profile, auto_recover_services=True)
        app.ingest(baseline)
        _promote_integrity_baseline(app, store, "agent-one")
        return store, app, baseline

    def outage(self, app, baseline, sequence, changes=None):
        for step in (sequence, sequence + 1):
            sample = stopped(baseline, step)
            sample["observed_at"] = baseline["observed_at"] + step * 0.1
            if changes:
                changes(sample)
            app.ingest(sample)

    def restarts(self, store):
        return [asdict(item) for item in store.pending_actions("agent-one")
                if asdict(item)["action_type"] == "restart_service"]

    def test_high_alert_flood_does_not_disable_restart(self):
        store, app, baseline = self.controller()
        sequence, account = 2, 0
        for _ in range(5):  # 8 new accounts per sample (the per-kind cap) x 5
            sample = copy.deepcopy(baseline)
            sample["sequence"], sample["observed_at"] = sequence, baseline["observed_at"] + sequence * 0.1
            sample["security_events"] = [
                {"event_id": f"linux-{account + i:032x}", "category": "account_created", "outcome": "success",
                 "account": f"u{account + i}", "actor": "root", "remote_address": "unknown",
                 "occurred_at": baseline["observed_at"] + 1, "detail": f"new user: name=u{account + i}"}
                for i in range(8)]
            account += 8
            app.ingest(sample)
            sequence += 1
        alerts = store.dashboard()["alerts"]
        self.assertEqual(sum(a["severity"] == "high" and a["status"] == "open" for a in alerts),
                         OPEN_ALERT_LIMITS_BY_SEVERITY["high"])
        self.outage(app, baseline, sequence)
        self.assertEqual(len(self.restarts(store)), 1)
        stopped_alerts = [a for a in store.dashboard()["alerts"] if a["kind"] == "baseline_service_stopped"]
        self.assertEqual(len(stopped_alerts), 1)
        self.assertEqual(stopped_alerts[0]["status"], "open")

    def test_full_open_alert_quota_does_not_disable_restart(self):
        store, app, baseline = self.controller()
        for severity, limit in OPEN_ALERT_LIMITS_BY_SEVERITY.items():
            for index in range(limit):
                self.assertIsNotNone(store.add_alert(
                    "agent-one", _candidate("persistence_change", severity=severity, item=f"{severity}-{index}")))
        open_alerts = store._connection.execute(
            "SELECT COUNT(*) FROM alerts WHERE agent_id='agent-one' AND status='open'").fetchone()[0]
        self.assertEqual(open_alerts, store_module.MAX_OPEN_ALERTS_PER_AGENT)
        self.outage(app, baseline, 2)
        self.assertEqual(len(self.restarts(store)), 1)

    def test_decoy_outages_do_not_starve_the_scored_service(self):
        decoys = [f"a{index}.service" for index in range(8)]
        def add_decoys(baseline):
            baseline["services"] += [{"name": name, "state": "running", "start_mode": "enabled"}
                                     for name in decoys]
        store, app, baseline = self.controller(add_decoys)
        def stop_decoys(sample):
            for row in sample["services"]:
                row["state"] = "stopped"
        self.outage(app, baseline, 2, stop_decoys)
        self.assertEqual(len(self.restarts(store)), 1)
        kinds = [(a["kind"], a["summary"]) for a in store.dashboard()["alerts"] if a["kind"] == "baseline_service_stopped"]
        self.assertEqual(len(kinds), 9)

    def test_only_confirmed_manifest_recovery_is_exempt_from_the_per_sample_caps(self):
        decoys = [_candidate("baseline_service_stopped", f"a{i}.service") for i in range(8)]
        scored = _candidate("baseline_service_stopped", "web.service")
        selected, summary = prioritize_detection_candidates([*decoys, scored])
        self.assertNotIn(scored, selected)
        selected, summary = prioritize_detection_candidates([*decoys, scored], {"web.service": {}})
        self.assertIs(selected[0], scored)
        self.assertEqual(len(selected), 9)
        self.assertEqual(summary["reserved_recovery_candidates"], 1)
        self.assertFalse(is_recovery_candidate(_candidate("new_network_listener", "web.service"), {"web.service"}))
        self.assertFalse(is_recovery_candidate(_candidate("baseline_service_stopped", "x.service"), {"web.service"}))

    def test_reserved_lane_is_bounded_and_limited_to_recovery_kinds(self):
        store = Store(":memory:")
        self.addCleanup(store.close)
        for index in range(OPEN_ALERT_LIMITS_BY_SEVERITY["high"]):
            self.assertIsNotNone(store.add_alert("agent-one", _candidate("persistence_change", item=index)))
        self.assertIsNone(store.add_alert("agent-one", _candidate("baseline_service_stopped", "s0.service")))
        with self.assertRaisesRegex(ValueError, "service-recovery"):
            store.add_alert("agent-one", _candidate("persistence_change", item="x"), reserved=True)
        with patch.object(store_module, "MAX_OPEN_RECOVERY_ALERTS_PER_AGENT", 3):
            admitted = [store.add_alert("agent-one", _candidate("baseline_service_stopped", f"s{i}.service"),
                                        reserved=True) for i in range(4)]
        self.assertEqual(sum(value is not None for value in admitted), 3)
        self.assertIsNone(admitted[3])
        # A repeat still coalesces into its existing alert when the lane is full.
        with patch.object(store_module, "MAX_OPEN_RECOVERY_ALERTS_PER_AGENT", 3):
            self.assertEqual(store.add_alert("agent-one", _candidate("baseline_service_stopped", "s0.service"),
                                             reserved=True), admitted[0])


class CrashGovernanceTests(unittest.TestCase):
    """Bug 2: a crash no longer leaves the GUI workspace without automation."""

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.root.chmod(0o700)
        self.runtime = self.root / "sentinel.pyz"
        self.runtime.write_bytes(b"fixture runtime")

    def workspace(self, autonomy):
        from sentinel_blue.event_profile import load_event_profile
        from sentinel_blue.linux_workspace import prepare_workspace
        config, _ = prepare_workspace(self.root / "sessions", self.runtime, ["openssh-server"], {}, {},
                                      autonomy=autonomy)
        return config, load_event_profile(config["event_profile"])

    def test_guarded_workspace_opts_into_crash_resume_and_approval_based_does_not(self):
        _, guarded = self.workspace("guarded-autonomous")
        self.assertIs(guarded.raw["recovery"]["resume_after_controller_crash"], True)
        self.assertEqual(guarded.raw["recovery"]["baseline_promotion_delay_seconds"], 0)
        _, approval = self.workspace("approval-based")
        self.assertNotIn("resume_after_controller_crash", approval.raw["recovery"])

    def app(self, config, profile, *, crash=False):
        from sentinel_blue.recovery import load_recovery_key
        directory = Path(config["directory"])
        store = Store(directory / "controller.db")
        self.addCleanup(store.close)
        app = ControllerApp(store, "t" * 64, operator_token="o" * 64, operator_credential_epoch=2,
                            event_profile=profile, recovery_key=load_recovery_key(str(directory / "recovery.key")),
                            recovery_anchor=directory / "recovery.anchor", require_authenticated_recovery=True,
                            unclean_shutdown=crash)
        return store, app

    def crash_restart(self, autonomy):
        config, profile = self.workspace(autonomy)
        store, app = self.app(config, profile)
        app.set_autonomy_mode(profile.autonomy_mode)
        app.resume_changes()
        store.begin_controller_session()
        store.close()  # the process dies: the session marker is never cleared
        store, _ = self.app(config, profile)
        _, dirty = store.begin_controller_session()
        store.close()
        self.assertTrue(dirty)
        return self.app(config, profile, crash=True)

    def test_generated_guarded_workspace_keeps_its_mode_after_a_crash(self):
        _, app = self.crash_restart("guarded-autonomous")
        status = app.governance_status()
        self.assertEqual(status["autonomy_mode"], "guarded-autonomous")
        self.assertFalse(status["emergency_stopped"])
        self.assertTrue(status["automatic_allowed"])

    def test_resume_restores_the_approved_mode_after_an_unresumed_crash(self):
        _, app = self.crash_restart("approval-based")
        status = app.governance_status()
        self.assertEqual((status["autonomy_mode"], status["emergency_stopped"]), ("observe", True))
        self.assertEqual(status["profile_autonomy_mode"], "guarded-autonomous")
        self.assertFalse(status["automatic_allowed"])
        # Plain Resume keeps the current mode, as before.
        self.assertEqual(app.resume_changes()["autonomy_mode"], "observe")
        restored = app.resume_changes(restore_profile_mode=True)
        self.assertEqual((restored["autonomy_mode"], restored["emergency_stopped"]),
                         ("guarded-autonomous", False))
        self.assertTrue(restored["automatic_allowed"])

    def test_restore_never_exceeds_the_signed_profile(self):
        _, app = self.crash_restart("approval-based")
        app._allowed_governance_modes = frozenset({"observe", "approval-based"})
        with self.assertRaisesRegex(PermissionError, "exceeds"):
            app.resume_changes(restore_profile_mode=True)
        self.assertTrue(app.governance_status()["emergency_stopped"])

    def test_signed_resume_endpoint_restores_mode_and_rejects_other_fields(self):
        from sentinel_blue.controller import ControllerServer, make_handler
        from sentinel_blue.desktop_control import DesktopClient
        profile, _ = fixtures()
        store = Store(":memory:")
        self.addCleanup(store.close)
        app = ControllerApp(store, "t" * 32, operator_token="o" * 32, event_profile=profile)
        server = ControllerServer(("127.0.0.1", 0), make_handler(app))
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(server.server_close)
        self.addCleanup(thread.join, 3)
        self.addCleanup(server.shutdown)
        client = DesktopClient(f"http://127.0.0.1:{server.server_port}", "operator", 1, "o" * 32)
        app.set_autonomy_mode("observe")
        app.emergency_stop()
        for body in ({"restore_profile_mode": "yes"}, {"restore_profile_mode": True, "mode": "range-autonomous"}):
            with self.subTest(body=body), self.assertRaisesRegex(RuntimeError, "HTTP 400"):
                client.request("/api/v1/governance/resume", body)
        self.assertEqual(client.request("/api/v1/governance/resume", {})["autonomy_mode"], "observe")
        result = client.request("/api/v1/governance/resume", {"restore_profile_mode": True})
        self.assertEqual(result["autonomy_mode"], profile.autonomy_mode)
        self.assertFalse(result["emergency_stopped"])

    def test_gui_resume_requests_the_approved_mode(self):
        from tests.test_desktop_workflow import window_without_display
        window = window_without_display(self.root)
        window.polling = True
        window.client = Mock()
        window.client.request.return_value = {"emergency_stopped": False}
        worker = threading.Thread(target=window._control_worker)
        worker.start()
        self.addCleanup(worker.join, 3)
        self.addCleanup(window.worker_stop.set)
        window._governance("resume")
        deadline = time.monotonic() + 3
        while window.control_pending and time.monotonic() < deadline:
            window._tick()
            time.sleep(0.01)
        window.client.request.assert_called_once_with("/api/v1/governance/resume", {"restore_profile_mode": True})
        self.assertIn("Controller resume confirmed", window.footer.get())

    def test_label_says_whether_automatic_changes_can_run(self):
        from sentinel_blue.desktop import governance_label
        crashed = {"autonomy_mode": "observe", "profile_autonomy_mode": "guarded-autonomous",
                   "emergency_stopped": True, "automatic_allowed": False}
        self.assertEqual(governance_label(crashed), "Mode: observe · Automatic changes: paused · "
                                                    "Resume restores the approved guarded-autonomous mode")
        self.assertIn("Automatic changes: off", governance_label({**crashed, "emergency_stopped": False}))
        self.assertEqual(governance_label({"autonomy_mode": "guarded-autonomous",
                                           "profile_autonomy_mode": "guarded-autonomous",
                                           "emergency_stopped": False, "automatic_allowed": True}),
                         "Mode: guarded-autonomous · Automatic changes: on, as the event profile allows")
        self.assertIn("paused · Resume to continue",
                      governance_label({"autonomy_mode": "guarded-autonomous", "emergency_stopped": True,
                                        "profile_autonomy_mode": "guarded-autonomous"}))
        self.assertNotIn("governed by event profile", governance_label(crashed))
        running = {"autonomy_mode": "guarded-autonomous", "profile_autonomy_mode": "guarded-autonomous",
                   "emergency_stopped": False, "automatic_allowed": True, "automatic_recovery": True}
        self.assertIn("paused by the host-wide Pause", governance_label(running, True))
        self.assertIn("on, as the event profile allows", governance_label(running, False))
        self.assertIn("service recovery waits for approval",
                      governance_label({**running, "automatic_recovery": False}))

    def test_status_reports_automatic_recovery_separately(self):
        _, approval = self.workspace("approval-based")
        store = Store(":memory:")
        self.addCleanup(store.close)
        app = ControllerApp(store, "t" * 32, operator_token="o" * 32, event_profile=approval)
        app.set_autonomy_mode(approval.autonomy_mode)
        app.resume_changes()
        status = app.governance_status()
        self.assertTrue(status["automatic_allowed"])  # automatic restore points
        self.assertFalse(status["automatic_recovery"])
        _, guarded = self.workspace("guarded-autonomous")
        store = Store(":memory:")
        self.addCleanup(store.close)
        app = ControllerApp(store, "t" * 32, operator_token="o" * 32, event_profile=guarded,
                            auto_recover_services=True)
        app.set_autonomy_mode(guarded.autonomy_mode)
        app.resume_changes()
        self.assertTrue(app.governance_status()["automatic_recovery"])
        self.assertIsNone(app.dashboard()["controller"]["host_automation_paused"])  # no continuity in-process

    def test_dashboard_never_waits_for_a_busy_host_ledger(self):
        import subprocess
        import sys
        ledger_dir = self.root / "ledger"
        profile, _ = fixtures()
        store = Store(":memory:")
        self.addCleanup(store.close)
        app = ControllerApp(store, "t" * 32, operator_token="o" * 32, event_profile=profile)
        app.continuity = Mock()
        app.continuity.status.return_value = {"authority": None, "network_reconciled": True, "agents": []}
        def settled(expected):
            deadline = time.monotonic() + 10
            while time.monotonic() < deadline:
                if app.dashboard()["controller"]["host_automation_paused"] is expected:
                    return True
                time.sleep(0.05)
            return False
        with patch.dict(os.environ, {"SENTINEL_LEDGER_DIR": str(ledger_dir)}):
            from sentinel_blue.mutation_ledger import MutationLedger
            MutationLedger().read()
            self.assertTrue(settled(False))
            holder = subprocess.Popen(
                [sys.executable, "-c", "import time; from sentinel_blue.mutation_ledger import MutationLedger\n"
                 "with MutationLedger().lock():\n    print('locked', flush=True); time.sleep(30)\n"],
                stdout=subprocess.PIPE, text=True, env=dict(os.environ))
            try:
                self.assertEqual(holder.stdout.readline().strip(), "locked")
                started = time.monotonic()
                value = app.dashboard()["controller"]["host_automation_paused"]
                self.assertLess(time.monotonic() - started, 5)
                self.assertIs(value, False)  # the last value read, not a false "paused"
            finally:
                holder.kill()
                holder.wait()
                holder.stdout.close()
            from sentinel_blue.continuity_controls import local_control
            local_control(MutationLedger(), True, "fixture host pause")
            self.assertTrue(settled(True))

    def test_start_that_never_served_is_not_recorded_as_a_crash(self):
        database = self.root / "controller.db"
        store = Store(database)
        self.addCleanup(store.close)
        session, prior = store.begin_controller_session()
        self.assertFalse(prior)
        _abandon_controller_startup(store, session, prior, None, None, threading.Event(), [])
        session, prior = store.begin_controller_session()
        self.assertFalse(prior, "a failed start after a clean stop is not a crash")

    def test_failed_start_keeps_the_marker_when_it_must(self):
        store = Store(self.root / "controller.db")
        self.addCleanup(store.close)
        store.begin_controller_session()
        session, prior = store.begin_controller_session()  # the run before crashed
        self.assertTrue(prior)
        _abandon_controller_startup(store, session, prior, None, None, threading.Event(), [])
        session, prior = store.begin_controller_session()
        self.assertTrue(prior, "a failed start must not erase an unanswered crash")
        store.end_controller_session(session)
        uncertain = Mock(_governance_persistence_uncertain=True)
        session, prior = store.begin_controller_session()
        _abandon_controller_startup(store, session, prior, uncertain, None, threading.Event(), [])
        self.assertTrue(store.begin_controller_session()[1])
        stuck = Mock()
        stuck.is_alive.return_value = True
        session, _ = store.begin_controller_session()
        store.end_controller_session(session)
        session, prior = store.begin_controller_session()
        self.assertFalse(prior)
        _abandon_controller_startup(store, session, prior, None, None, threading.Event(), [stuck])
        self.assertTrue(store.begin_controller_session()[1])

    def test_failed_start_closes_its_listener_and_stops_workers(self):
        store = Store(self.root / "controller.db")
        self.addCleanup(store.close)
        session, prior = store.begin_controller_session()
        stop = threading.Event()
        worker = threading.Thread(target=stop.wait, args=(30,))
        worker.start()
        server = Mock()
        _abandon_controller_startup(store, session, prior, None, server, stop, [worker])
        server.server_close.assert_called_once_with()
        self.assertFalse(worker.is_alive())
        self.assertFalse(store.begin_controller_session()[1])


class PayloadScopeTests(unittest.TestCase):
    """Bug 4 (and bug 14): a payload-coverage gap holds only the recovery it concerns."""

    def setUp(self):
        self.proc = Path(tempfile.mkdtemp(prefix="sentinel-proc-"))
        self.addCleanup(shutil.rmtree, self.proc, True)

    def process(self, pid, exe, cgroup=None):
        entry = self.proc / str(pid)
        entry.mkdir()
        os.symlink(exe, entry / "exe")
        (entry / "cmdline").write_bytes(b"")
        if cgroup is not None:
            (entry / "cgroup").write_text(cgroup)
        return entry

    def test_process_owner_comes_from_the_cgroup_path(self):
        from sentinel_blue.payload_inventory import process_service_unit
        cases = {
            "0::/system.slice/web.service\n": "web.service",
            "0::/system.slice/nginx.service/worker\n": "nginx.service",
            "12:name=systemd:/system.slice/named.service\n1:cpu:/\n": "named.service",
            "0::/user.slice/user-1000.slice/session-3.scope\n": "",
            "0::/user.slice/user-1000.slice/user@1000.service/app.slice/web.service\n": "user@1000.service",
            "0::/init.scope\n": "",
            "not a cgroup file": "*running",
        }
        for index, (text, owner) in enumerate(cases.items()):
            with self.subTest(text=text):
                self.assertEqual(process_service_unit(self.process(100 + index, "/usr/bin/true", text)), owner)
        self.assertEqual(process_service_unit(self.process(200, "/usr/bin/true")), "*running")
        self.assertIsNone(process_service_unit(self.proc / "999"))

    def test_deleted_executables_are_attributed_to_their_service(self):
        from sentinel_blue.payload_inventory import linux_process_payloads
        from sentinel_blue.telemetry_diagnostics import normalize_diagnostics_with_owners
        self.process(10, "/tmp/implant (deleted)", "0::/user.slice/user-0.slice/session-1.scope\n")
        self.process(11, "/usr/sbin/web (deleted)", "0::/system.slice/web.service\n")
        errors = []
        linux_process_payloads(errors, proc_root=self.proc)
        _, sources, owners = normalize_diagnostics_with_owners(errors)
        unlinked = sorted(owner for error, owner in zip(errors, owners) if "unlinked" in error)
        self.assertEqual(unlinked, ["", "web.service"])
        self.assertTrue(all(source == "payload_fingerprint" for source in sources))

    def test_startup_references_belong_to_the_unit_that_names_them(self):
        from sentinel_blue.payload_inventory import startup_file_owner
        item = lambda kind, name: PersistenceItem(kind, name, "root", True)
        self.assertEqual(startup_file_owner(item("systemd-file", "/etc/systemd/system/web.service")), "web.service")
        self.assertEqual(startup_file_owner(item("systemd-file", "/etc/systemd/system/web.service.d/o.conf")),
                         "web.service")
        self.assertEqual(startup_file_owner(item("systemd-file", "/etc/systemd/system/web.socket")), "*")
        self.assertEqual(startup_file_owner(item("cron", "/etc/cron.d/job")), "")

    def test_fingerprint_gaps_are_reported_once_per_owner(self):
        from sentinel_blue.payload_inventory import fingerprint_references
        blocked = Path(tempfile.mkdtemp(prefix="sentinel-ref-"))
        self.addCleanup(shutil.rmtree, blocked, True)
        target = blocked / "run.sh"
        target.write_text("x")
        link = blocked / "link.sh"
        link.symlink_to(target)  # fingerprinting refuses a symlinked payload
        errors = []
        fingerprint_references([str(link)], errors, owners={str(link): {"web.service", ""}})
        self.assertEqual(sorted(error.owner for error in errors), ["", "web.service"])
        many = [str(blocked / f"s{i}.sh") for i in range(4)]
        for path in many:
            Path(path).write_text("x")
        errors = []
        fingerprint_references(many, errors, max_files=1,
                               owners={path: {f"u{i}.service"} for i, path in enumerate(many)})
        self.assertEqual(sorted(error.owner for error in errors), ["u1.service", "u2.service", "u3.service"])
        errors = []
        fingerprint_references(many * 3 + [str(target)], errors, max_files=0,
                               owners={**{path: {f"u{i}.service", f"v{i}.service", f"w{i}.service"}
                                          for i, path in enumerate(many)}})
        self.assertEqual([error.owner for error in errors], ["*"])

    def test_owners_survive_normalization_merging_and_validation(self):
        from sentinel_blue.payload_inventory import PayloadCoverageIssue
        from sentinel_blue.telemetry_diagnostics import (
            NetworkInventoryIssue, merge_health_diagnostics, normalize_diagnostics_with_owners)
        from sentinel_blue.validation import ValidationError, validate_telemetry
        errors, sources, owners = normalize_diagnostics_with_owners(
            [PayloadCoverageIssue("gap", "web.service"), "plain", NetworkInventoryIssue("net"),
             PayloadCoverageIssue("old")])
        self.assertEqual(owners, ["web.service", "", "", "*"])
        telemetry = {"collector_errors": errors, "collector_issue_sources": sources, "collector_issue_owners": owners}
        merge_health_diagnostics(telemetry, ["self-health"])
        self.assertEqual(telemetry["collector_issue_owners"], ["web.service", "", "", "*", ""])
        telemetry["collector_issue_owners"] = ["web.service"]  # misaligned: never trusted
        merge_health_diagnostics(telemetry, [])
        self.assertEqual(telemetry["collector_issue_owners"][0], "*")
        _, baseline = fixtures()
        sample = {**baseline, "observed_at": time.time(), "collector_errors": ["gap"],
                  "collector_issue_sources": ["payload_fingerprint"], "collector_issue_owners": ["web.service"]}
        self.assertEqual(validate_telemetry(sample)["collector_issue_owners"], ["web.service"])
        for owners in (["bad owner"], ["web.service", ""], "web.service"):
            with self.subTest(owners=owners), self.assertRaises(ValidationError):
                validate_telemetry({**sample, "collector_issue_owners": owners})

    def test_recovery_blocking_rules(self):
        from sentinel_blue.telemetry_diagnostics import recovery_blocking
        def sample(owner, state):
            return {"collector_errors": ["gap"], "collector_issue_sources": ["payload_fingerprint"],
                    "collector_issue_owners": [owner],
                    "services": [{"name": "web.service", "state": state}]}
        expectations = [
            ("", "inactive", False), ("", "running", False),
            ("db.service", "inactive", False), ("db.service", "running", False),
            ("web.service", "inactive", True), ("web.service", "running", True),
            ("*running", "inactive", False), ("*running", "failed", False), ("*running", "running", True),
            ("*", "inactive", True), ("not valid", "inactive", True),
        ]
        for owner, state, blocks in expectations:
            with self.subTest(owner=owner, state=state):
                self.assertEqual(bool(recovery_blocking(sample(owner, state), service="web.service")), blocks)
                # The manifest opt-out ignores unrelated and unattributable gaps,
                # never a gap attributed to the service being recovered.
                self.assertEqual(bool(recovery_blocking(sample(owner, state), service="web.service",
                                                        allow_payload=True)), owner == "web.service")
                # Callers that name no service keep the host-wide rule.
                self.assertTrue(recovery_blocking(sample(owner, state)))
        legacy = sample("", "inactive")
        del legacy["collector_issue_owners"]
        self.assertTrue(recovery_blocking(legacy, service="web.service"))
        unknown = {"collector_errors": ["x"], "collector_issue_sources": ["unknown"], "collector_issue_owners": [""]}
        self.assertTrue(recovery_blocking(unknown, service="web.service"))
        for owner, blocks in (("", False), ("web.service", False), ("*running", False), ("*", True)):
            with self.subTest(deferred=owner):
                self.assertEqual(bool(recovery_blocking(sample(owner, "running"), defer_attributed_payload=True)),
                                 blocks)

    def test_identical_gaps_merge_and_overflow_keeps_owner_scope(self):
        from sentinel_blue.payload_inventory import PayloadCoverageIssue
        from sentinel_blue.telemetry_diagnostics import normalize_diagnostics_with_owners, recovery_blocking
        workers = [PayloadCoverageIssue("running executable was unlinked; on-disk payload coverage is incomplete",
                                        "nginx.service")] * 300
        errors, sources, owners = normalize_diagnostics_with_owners(workers)
        self.assertEqual(len(errors), 1)
        self.assertIn("(300 occurrences)", errors[0])
        distinct = [PayloadCoverageIssue(f"cron fingerprint failed; path=/tmp/x{i}", "") for i in range(300)]
        distinct += [PayloadCoverageIssue(f"startup fingerprint failed; path=/opt/d{i}", "db.service") for i in range(5)]
        errors, sources, owners = normalize_diagnostics_with_owners(distinct, extra_errors=["self-health"])
        self.assertEqual(len(errors), 256)
        self.assertEqual(errors[-3], "self-health")  # health faults are kept
        self.assertTrue(all("omitted" in error for error in errors[-2:]))
        self.assertEqual(sources[-2:], ["payload_fingerprint", "payload_fingerprint"])
        self.assertEqual(sorted(owners[-2:]), ["", "db.service"])
        telemetry = {"collector_errors": errors, "collector_issue_sources": sources, "collector_issue_owners": owners,
                     "services": [{"name": "web.service", "state": "inactive"}]}
        blocking = recovery_blocking(telemetry, service="web.service")
        self.assertEqual(blocking, ["self-health"])  # only the unknown self-health row, never the payload overflow
        many = [PayloadCoverageIssue(f"gap {i}", f"u{i}.service") for i in range(300)]
        errors, sources, owners = normalize_diagnostics_with_owners(many)
        self.assertEqual((sources[-1], owners[-1]), ("payload_fingerprint", "*"))
        errors, sources, owners = normalize_diagnostics_with_owners(["plain"] * 300)
        self.assertEqual((sources[-1], owners[-1]), ("unknown", ""))
        several = [PayloadCoverageIssue(f"gap {i}", "") for i in range(254)]
        several += [PayloadCoverageIssue(f"gap a{i}", f"a{i}.service") for i in range(3)]
        errors, sources, owners = normalize_diagnostics_with_owners(several)
        self.assertEqual(len(errors), 256)
        self.assertEqual(sorted(owners[-3:]), ["a0.service", "a1.service", "a2.service"])
        self.assertTrue(all(source == "payload_fingerprint" for source in sources))

    def test_template_and_prefix_unit_gaps_hold_their_instances(self):
        from sentinel_blue.telemetry_diagnostics import payload_gap_concerns
        for owner, service, concerns in (("app@.service", "app@1.service", True),
                                         ("app@.service", "app.service", False),
                                         ("app-.service", "app-web.service", True),
                                         ("a-.service", "a-b-c.service", True),
                                         ("app-.service", "apps.service", False),
                                         ("app@1.service", "app@2.service", False)):
            with self.subTest(owner=owner, service=service):
                self.assertIs(payload_gap_concerns(owner, service, False), concerns)

    def test_unscanned_processes_are_attributed_to_their_services(self):
        from sentinel_blue.payload_inventory import linux_process_payloads
        from sentinel_blue.telemetry_diagnostics import normalize_diagnostics_with_owners, recovery_blocking
        for pid in range(1, 4200):
            entry = self.proc / str(pid)
            entry.mkdir()
            (entry / "cgroup").write_text("0::/system.slice/web.service\n" if pid % 2
                                          else "0::/user.slice/user-0.slice/session-1.scope\n")
        order = [entry for entry in self.proc.iterdir() if entry.name.isdigit()]
        expected = sorted({"web.service" if int(entry.name) % 2 else "" for entry in order[4096:]})
        self.assertEqual(expected, ["", "web.service"])
        errors = []
        linux_process_payloads(errors, proc_root=self.proc)
        bound = sorted(error.owner for error in errors if "reached its process/time bound" in error)
        # Every process past the bound was attributed; none is left "*running".
        self.assertEqual(bound, expected)
        errors, sources, owners = normalize_diagnostics_with_owners(errors)
        for service, held in (("web.service", True), ("db.service", False)):
            telemetry = {"collector_errors": errors, "collector_issue_sources": sources,
                         "collector_issue_owners": owners, "services": [{"name": service, "state": "running"}]}
            with self.subTest(service=service):
                self.assertEqual(bool(recovery_blocking(telemetry, service=service)), held)

    def test_reference_bound_names_the_truncated_process(self):
        from sentinel_blue.payload_inventory import linux_process_payloads
        entry = self.process(7, "/usr/bin/python3", "0::/system.slice/app.service\n")
        (entry / "cmdline").write_bytes(b"\0".join(f"/opt/app/s{i}.py".encode() for i in range(600)))
        errors = []
        linux_process_payloads(errors, proc_root=self.proc)
        bound = [error.owner for error in errors if "reference inventory reached its bound" in error]
        self.assertEqual(bound, ["app.service"])

    def test_post_crash_gate_relaxes_only_rechecked_automatic_recovery(self):
        profile, baseline = fixtures()
        store = Store(":memory:")
        self.addCleanup(store.close)
        app = ControllerApp(store, "t" * 32, operator_token="o" * 32, event_profile=profile)
        app._recovery_fresh_after = time.time() - 60
        sample = {"observed_at": time.time() - 1, "collector_errors": ["gap"],
                  "collector_issue_sources": ["payload_fingerprint"], "collector_issue_owners": ["db.service"]}
        with patch.object(store, "latest_telemetry_for_agent", return_value=sample):
            self.assertFalse(app._post_recovery_observation("agent-one"))
            self.assertFalse(app._post_recovery_observation("agent-one", "restore_integrity", automated=True))
            self.assertFalse(app._post_recovery_observation("agent-one", "restart_service", automated=False))
            self.assertTrue(app._post_recovery_observation("agent-one", "restart_service", automated=True))
            self.assertEqual(app._post_recovery_scope("agent-one"), {"restart_service", "repair_service"})
            sample["collector_issue_owners"] = ["*"]
            self.assertEqual(app._post_recovery_scope("agent-one"), frozenset())
            sample["collector_errors"] = []
            sample["collector_issue_sources"] = []
            sample["collector_issue_owners"] = []
            self.assertIsNone(app._post_recovery_scope("agent-one"))

    def planner_status(self, owner, *, allow=False):
        from sentinel_blue.event_profile import EventProfile
        from sentinel_blue.service_recovery import ServiceRecoveryPlanner
        profile, baseline = fixtures()
        if allow:
            raw = copy.deepcopy(profile.raw)
            raw["services"][0]["repair_policy"] = {"restore_files": [], "restart_unhealthy": False,
                                                   "validation_timeout_seconds": 30,
                                                   "allow_unrelated_payload_errors": True}
            profile = EventProfile.from_dict(raw)
        planner = ServiceRecoveryPlanner(profile)
        ready = {}
        for sequence in (2, 3):
            sample = stopped(baseline, sequence)
            sample["observed_at"] = time.time() - (4 - sequence)
            sample["collector_errors"] = ["running executable was unlinked; on-disk payload coverage is incomplete"]
            sample["collector_issue_sources"] = ["payload_fingerprint"]
            sample["collector_issue_owners"] = [owner]
            ready = planner.observe("agent-one", baseline, True, sample)
        return planner.status()[0]["status"], ready

    def test_restart_planner_is_held_only_by_its_own_gaps(self):
        for owner, expected in (("", "ready"), ("sshd.service", "ready"), ("*running", "ready"),
                                ("web.service", "incomplete collection holds service recovery"),
                                ("*", "incomplete collection holds service recovery")):
            with self.subTest(owner=owner):
                self.assertEqual(self.planner_status(owner)[0], expected)

    def test_restart_only_path_honours_the_manifest_opt_out(self):
        status, ready = self.planner_status("*", allow=True)
        self.assertEqual(status, "ready")
        self.assertIs(ready["web.service"]["recovery_guard"]["allow_unrelated_payload_errors"], True)
        self.assertEqual(self.planner_status("*", allow=False)[0], "incomplete collection holds service recovery")
        self.assertEqual(self.planner_status("web.service", allow=True)[0],
                         "incomplete collection holds service recovery")
        status, ready = self.planner_status("", allow=False)
        self.assertNotIn("allow_unrelated_payload_errors", ready["web.service"]["recovery_guard"])

    def test_queued_restart_is_rechecked_against_its_own_service_only(self):
        from sentinel_blue.service_recovery import check_recovery_observation
        _, ready = self.planner_status("")
        parameters = ready["web.service"]
        _, baseline = fixtures()
        sample = stopped(baseline, 4)
        sample["observed_at"] = time.time()
        sample["collector_errors"] = ["gap", "gap"]
        sample["collector_issue_sources"] = ["payload_fingerprint", "payload_fingerprint"]
        sample["collector_issue_owners"] = ["", "db.service"]
        check_recovery_observation(parameters, sample)
        sample["collector_issue_owners"] = ["", "web.service"]
        with self.assertRaisesRegex(ValueError, "incomplete collection"):
            check_recovery_observation(parameters, sample)


if __name__ == "__main__":
    unittest.main()
