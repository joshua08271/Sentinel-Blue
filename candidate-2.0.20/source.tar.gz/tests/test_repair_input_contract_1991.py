"""Malformed input into a repair decision must refuse, never raise an internal error.

Every caller of these paths reports a held restart by catching ValueError. A
TypeError or AttributeError escapes that, so the operator gets a traceback
instead of a stated reason — and for a queued restart, "held because X" and
"crashed" look nothing alike in a competition.

The specific bug class this locks down has now appeared three times in this
codebase: a value is used before its type is checked. `_network` tested set
membership before `isinstance` and crashed on a nested list; `_haproxy` called
`.get()` on a list element; `check_restart_target` tested `state not in stopped`
on a value the wire had not yet guaranteed to be a string. Each was reachable
only from a different direction, and each was found by sweeping rather than by
reading. So this sweeps.

None of these inputs is reachable from the network today — `validate_telemetry`
rejects a non-string service state with its own clean error, and action
parameters are validated before execution. This is the layer behind that one,
and it is the layer that decides whether a future caller gets a refusal or a
crash.
"""
import itertools
import unittest

from sentinel_blue.probe_evidence import (all_probes_healthy, matching_probe_health,
                                          probe_verdict)
from sentinel_blue.service_recovery import check_recovery_deadline, check_restart_target

# Shapes an operator, a malformed agent or a future caller could plausibly hand
# in. Unhashable values matter most: they crash a set membership test before any
# guard below it runs.
JUNK = (None, "", "unexpected", 0, 7, True, 1.5, [], {}, [1], [None], [[]],
        {"a": 1}, {"name": None}, ({"name": "n", "target": "t"},), "x" * 300)

TELEMETRY = {"platform": "Linux 6.8.0", "probes": [], "filesystems": [], "memory": None,
             "services": [{"name": "nginx", "state": "stopped", "start_mode": "enabled"}]}
PARAMETERS = {"service": "nginx", "probes": [],
              "recovery_guard": {"files": [{"path": "/etc/nginx/nginx.conf"}],
                                 "dependency_probes": [], "observed_at": 0.0}}
MANIFEST = {"expected_transactions": [], "required_files": [], "required_data": []}


def replaced(mapping, key, value):
    return {**mapping, key: value}


class RestartRevalidationContractTests(unittest.TestCase):
    """`check_restart_target` refuses everything it cannot understand."""

    def outcome(self, parameters, telemetry, manifest=MANIFEST):
        try:
            check_restart_target(parameters, telemetry, manifest=manifest)
            return "accepted"
        except ValueError:
            return "refused"

    def test_a_healthy_queued_restart_is_still_admitted(self):
        """The fix must not turn a legitimate outage into a hold."""
        self.assertEqual(self.outcome(PARAMETERS, TELEMETRY), "accepted")

    def test_a_running_target_is_validation_only(self):
        telemetry = replaced(TELEMETRY, "services",
                             [{"name": "nginx", "state": "running"}])
        self.assertEqual(self.outcome(PARAMETERS, telemetry), "accepted")

    def test_a_disabled_or_masked_target_is_held(self):
        for mode in ("disabled", "masked", "masked-runtime", "MASKED"):
            with self.subTest(start_mode=mode):
                telemetry = replaced(TELEMETRY, "services",
                                     [{"name": "nginx", "state": "stopped", "start_mode": mode}])
                self.assertEqual(self.outcome(PARAMETERS, telemetry), "refused")

    def test_a_non_string_state_is_refused_not_crashed(self):
        """The regression: `state not in stopped` raised on an unhashable value."""
        for value in ([], {}, ["stopped"], None, 7, {"state": "stopped"}):
            with self.subTest(state=repr(value)):
                telemetry = replaced(TELEMETRY, "services",
                                     [{"name": "nginx", "state": value}])
                self.assertEqual(self.outcome(PARAMETERS, telemetry), "refused")

    def test_a_malformed_manifest_is_refused_not_crashed(self):
        # None is not malformed: it is the executor path, which builds a narrower
        # manifest from its own guard. Everything else that is not a mapping is.
        for value in JUNK:
            if value is None or isinstance(value, dict):
                continue
            with self.subTest(manifest=repr(value)[:24]):
                self.assertEqual(self.outcome(PARAMETERS, TELEMETRY, manifest=value), "refused")

    def test_the_executor_path_builds_its_manifest_from_a_sound_guard(self):
        self.assertEqual(self.outcome(PARAMETERS, TELEMETRY, manifest=None), "accepted")

    def test_a_malformed_guard_is_refused_when_the_executor_builds_its_own_manifest(self):
        """With manifest=None the guard is the only source, so it must be checked."""
        for guard in (None, "", [], {}, {"files": "not a list"}, {"files": [None]},
                      {"files": [{"no_path": 1}]}, {"files": [{"path": 7}]}):
            with self.subTest(guard=repr(guard)[:30]):
                parameters = replaced(PARAMETERS, "recovery_guard", guard)
                self.assertEqual(self.outcome(parameters, TELEMETRY, manifest=None), "refused")

    def test_no_shape_of_input_escapes_as_an_internal_error(self):
        """The sweep. Anything but ValueError is a defect, whatever the input."""
        tried = 0
        for target in ("telemetry", "parameters"):
            base = TELEMETRY if target == "telemetry" else PARAMETERS
            for key, value in itertools.product(list(base), JUNK):
                tried += 1
                telemetry = dict(TELEMETRY)
                parameters = dict(PARAMETERS)
                if target == "telemetry":
                    telemetry[key] = value
                else:
                    parameters[key] = value
                with self.subTest(where=target, key=key, value=repr(value)[:20]):
                    try:
                        check_restart_target(parameters, telemetry, manifest=MANIFEST)
                    except ValueError:
                        pass
                    except Exception as exc:          # noqa: BLE001 - that is the point
                        self.fail(f"{target}.{key}={value!r} raised "
                                  f"{type(exc).__name__}: {exc}")
        for key, value in itertools.product(("name", "state", "start_mode"), JUNK):
            tried += 1
            telemetry = replaced(TELEMETRY, "services",
                                 [replaced(TELEMETRY["services"][0], key, value)])
            with self.subTest(row_key=key, value=repr(value)[:20]):
                try:
                    check_restart_target(dict(PARAMETERS), telemetry, manifest=MANIFEST)
                except ValueError:
                    pass
                except Exception as exc:              # noqa: BLE001
                    self.fail(f"services[0].{key}={value!r} raised "
                              f"{type(exc).__name__}: {exc}")
        self.assertGreater(tried, 100)

    def test_the_deadline_guard_refuses_every_malformed_guard(self):
        for value in JUNK:
            with self.subTest(guard=repr(value)[:24]):
                try:
                    check_recovery_deadline({"recovery_guard": value})
                except ValueError:
                    pass
                except Exception as exc:              # noqa: BLE001
                    self.fail(f"recovery_guard={value!r} raised {type(exc).__name__}: {exc}")


class ProbeEvidenceContractTests(unittest.TestCase):
    """The shared decision surface validated `rows` but not `specs`."""

    def test_no_pair_of_shapes_crashes(self):
        for specs, rows in itertools.product(JUNK, JUNK):
            with self.subTest(specs=repr(specs)[:18], rows=repr(rows)[:18]):
                matching_probe_health(specs, rows)
                matching_probe_health(specs, rows, exact=True)
                all_probes_healthy(specs, rows)
                all_probes_healthy(specs, rows, allow_empty=True)

    def test_a_malformed_contract_is_never_a_pass(self):
        for specs in (None, "", 7, {}, {"a": 1}):
            with self.subTest(specs=repr(specs)):
                self.assertFalse(all_probes_healthy(specs, []))
                self.assertEqual(matching_probe_health(specs, []), [])

    def test_a_verdict_survives_any_row(self):
        for row in JUNK:
            with self.subTest(row=repr(row)[:24]):
                self.assertIn(probe_verdict(row), (True, False, None))


if __name__ == "__main__":
    unittest.main()
