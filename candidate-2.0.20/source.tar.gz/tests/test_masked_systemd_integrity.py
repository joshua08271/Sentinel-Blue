"""Real symlink regressions for the Workshop 3 native baseline failure."""
import hashlib
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

from sentinel_blue import collectors
from sentinel_blue import payload_inventory
from sentinel_blue.restoration import RestorePointStore
from dataclasses import asdict


@unittest.skipUnless(os.name == 'posix', 'POSIX systemd links')
class MaskedSystemdIntegrityTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.mask = self.root / 'masked.service'
        self.mask.symlink_to('/dev/null')

    def discover(self, root, pattern):
        return [self.mask] if root == Path('/etc/systemd/system') else []

    def test_discovered_mask_is_not_a_restore_target(self):
        errors = []
        with patch.object(collectors, '_discover_integrity_paths', self.discover):
            paths = collectors._integrity_paths('linux', errors=errors)
        self.assertNotIn(Path('/dev/null'), paths)
        self.assertNotIn(self.mask, paths)
        self.assertFalse(errors)

    def test_explicit_protected_device_and_mask_still_fail_closed(self):
        for target in ('/dev/null', str(self.mask)):
            with self.subTest(target=target), patch.object(collectors, '_discover_integrity_paths', self.discover):
                errors = []
                paths = collectors._integrity_paths('linux', [target], errors=errors)
                self.assertEqual(paths[0], Path(target))
                with self.assertRaisesRegex(ValueError, 'not a regular file'):
                    collectors._posix_integrity_item(paths[0], collectors._IntegrityBudget())

    def test_regular_service_alias_keeps_canonical_file(self):
        target = self.root / 'real.service'
        target.write_text('[Service]\nExecStart=/usr/bin/true\n')
        self.mask.unlink()
        self.mask.symlink_to(target)
        with patch.object(collectors, '_discover_integrity_paths', self.discover):
            paths = collectors._integrity_paths('linux', errors=[])
        self.assertIn(target, paths)
        self.assertNotIn(self.mask, paths)

    def test_other_device_alias_is_not_silently_ignored(self):
        self.mask.unlink()
        self.mask.symlink_to('/dev/zero')
        with patch.object(collectors, '_discover_integrity_paths', self.discover):
            paths = collectors._integrity_paths('linux', errors=[])
        self.assertIn(Path('/dev/zero'), paths)
        with self.assertRaisesRegex(ValueError, 'not a regular file'):
            collectors._posix_integrity_item(Path('/dev/zero'), collectors._IntegrityBudget())

    def test_mask_and_later_link_edit_remain_visible_in_persistence(self):
        def discovered(path, pattern):
            return iter([self.mask]) if path == Path('/etc/systemd/system') else iter(())
        def collect_link():
            errors = []
            with patch.object(Path, 'rglob', discovered), \
                 patch.object(Path, 'iterdir', return_value=iter(())), \
                 patch.object(collectors, 'pwd', None), \
                 patch.object(collectors, '_run', return_value=subprocess.CompletedProcess([], 0, '', '')), \
                 patch.object(payload_inventory, 'linux_startup_payloads', return_value=[]), \
                 patch.object(payload_inventory, 'linux_process_payloads', return_value=[]):
                rows = collectors._linux_persistence(errors)
            return [row for row in rows if row.name == str(self.mask)]
        rows = collect_link()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0].kind, 'systemd-file-link')
        self.assertEqual(rows[0].sha256, hashlib.sha256(b'/dev/null').hexdigest())
        old = rows[0].sha256
        self.mask.unlink()
        self.mask.symlink_to(self.root / 'missing.service')
        changed = collect_link()
        self.assertEqual(len(changed), 1)
        self.assertNotEqual(changed[0].sha256, old)

    def test_default_configuration_alias_captures_real_file_and_keeps_link_evidence(self):
        target = self.root / 'mariadb.cnf'
        target.write_text('[client]\nport=3306\n')
        alias = self.root / 'my.cnf'
        alias.symlink_to(target)
        with patch.object(collectors, '_linux_default_integrity_paths', return_value=[alias]), \
             patch.object(collectors, '_discover_integrity_paths', return_value=[]):
            errors = []
            paths = collectors._integrity_paths('linux', errors=errors)
            self.assertEqual(paths, [target])
            items = collectors._integrity('linux', errors)
        self.assertFalse(errors)
        store = RestorePointStore(self.root / 'backups')
        result = store.capture([asdict(item) for item in items])
        self.assertTrue(result['success'], result)
        self.assertEqual(result['captured'], [str(target)])
        with patch.object(collectors, '_linux_default_integrity_paths', return_value=[alias]), \
             patch.object(Path, 'rglob', return_value=iter(())), \
             patch.object(Path, 'iterdir', return_value=iter(())), \
             patch.object(collectors, 'pwd', None), \
             patch.object(collectors, '_run', return_value=subprocess.CompletedProcess([], 0, '', '')), \
             patch.object(payload_inventory, 'linux_startup_payloads', return_value=[]), \
             patch.object(payload_inventory, 'linux_process_payloads', return_value=[]):
            rows = collectors._linux_persistence([])
        linked = [row for row in rows if row.name == str(alias)]
        self.assertEqual(len(linked), 1)
        self.assertEqual(linked[0].kind, 'protected-config-link')
        self.assertEqual(linked[0].sha256, hashlib.sha256(os.readlink(alias).encode()).hexdigest())

    def test_explicit_configuration_alias_is_not_redirected(self):
        target = self.root / 'real.conf'
        target.write_bytes(b'configuration')
        alias = self.root / 'approved.conf'
        alias.symlink_to(target)
        with patch.object(collectors, '_linux_default_integrity_paths', return_value=[alias]), \
             patch.object(collectors, '_discover_integrity_paths', return_value=[]):
            paths = collectors._integrity_paths('linux', [str(alias)])
        self.assertEqual(paths, [alias, target])
        item = asdict(collectors._posix_integrity_item(alias, collectors._IntegrityBudget()))
        result = RestorePointStore(self.root / 'backups').capture([item])
        self.assertFalse(result['success'])
        self.assertEqual(result['rejected'][0]['path'], str(alias))


if __name__ == '__main__':
    unittest.main()
