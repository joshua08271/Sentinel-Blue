"""Reviewed port planning and GUI contracts; native products remain VM-pending."""
import copy
import hashlib
import os
from pathlib import Path
import subprocess
import tempfile
import time
import unittest
from unittest.mock import patch

from sentinel_blue.linux_service_catalog import CATALOG
from sentinel_blue import linux_service_packs as packs
from sentinel_blue.service_ports import (capability, fields_for, port_number, port_text,
    configured_ports, endpoint_set, resolve_ports, listener_observation,
    manifest_constraints, validate_manifest_ports)
from sentinel_blue.port_config_merge import bind_port, postfix_smtp_port
from sentinel_blue.desktop_services import ServiceSelectionPanel, selection_report, service_plan
from test_generated_script_contract import baseline_for


class PortPlanner1992Tests(unittest.TestCase):
    def test_all_catalog_rows_have_explicit_port_status(self):
        statuses = {sid: capability(sid) for sid in CATALOG}
        self.assertEqual(len(statuses), 39)
        self.assertEqual(sum(row['editable'] for row in statuses.values()), 18)
        self.assertTrue(all(row['reason'] for row in statuses.values()))
        self.assertTrue(all(row['native_tested'] is False for row in CATALOG.values()))

    def test_manual_port_is_literal_and_input_unchanged(self):
        original = {'bind_address': '127.0.0.1'}
        out, report = resolve_ports('mariadb', original, {'port': {'mode': 'manual', 'port': 13306}})
        self.assertEqual(out['port'], 13306)
        self.assertNotIn('port', original)
        self.assertEqual(report['decisions'][0]['mode'], 'manual')

    def test_automatic_standard(self):
        out, _ = resolve_ports('mariadb', {}, {})
        self.assertEqual(out['port'], 3306)

    def test_automatic_preserves_explicit_current(self):
        out, _ = resolve_ports('mariadb', {'port': 13306}, {})
        self.assertEqual(out['port'], 13306)

    def test_required_port_outranks_configured_auto(self):
        out, _ = resolve_ports('nginx', {'port': 8080}, {}, required={'port': 80})
        self.assertEqual(out['port'], 80)

    def test_manual_cannot_override_required_port(self):
        with self.assertRaisesRegex(ValueError, 'required to stay'):
            resolve_ports('nginx', {}, {'port': {'mode': 'manual', 'port': 8080}}, required={'port': 80})

    def test_automatic_tls_standard(self):
        out, _ = resolve_ports('apache2', {'tls_certificate_path': '/a', 'tls_key_path': '/b'}, {})
        self.assertEqual(out['port'], 443)

    def test_alternate_requires_explicit_permission(self):
        with self.assertRaisesRegex(ValueError, 'conflicts'):
            resolve_ports('nginx', {}, {}, reserved={('tcp', 80)})

    def test_alternate_requires_fresh_complete_host_data(self):
        with self.assertRaisesRegex(ValueError, 'fresh, complete'):
            resolve_ports('nginx', {}, {}, reserved={('tcp', 80)}, allow_alternates=True, service_presence="absent")

    def test_alternate_is_bounded_deterministic_and_avoids_existing(self):
        observation = {'observed_at': time.time(), 'complete': True,
                       'listeners': [{'port': 20000, 'protocol': 'tcp'}, {'port': 80, 'protocol': 'tcp'}]}
        args = dict(reserved={('tcp', 20001)}, observation=observation, allow_alternates=True, service_presence="absent")
        first, _ = resolve_ports('nginx', {}, {}, **args)
        second, _ = resolve_ports('nginx', {}, {}, **args)
        self.assertEqual(first['port'], 20002)
        self.assertEqual(first, second)

    def test_stale_observation_does_not_prove_free(self):
        observation = {'observed_at': time.time()-100, 'complete': True, 'listeners': []}
        with self.assertRaises(ValueError):
            resolve_ports('nginx', {}, {}, reserved={('tcp', 80)}, observation=observation, allow_alternates=True, service_presence="absent")

    def test_incomplete_observation_does_not_prove_free(self):
        observation = {'observed_at': time.time(), 'complete': False, 'listeners': []}
        with self.assertRaises(ValueError):
            resolve_ports('nginx', {}, {}, reserved={('tcp', 80)}, observation=observation, allow_alternates=True, service_presence="absent")

    def test_ssh_never_silently_hops_ports(self):
        observation = {'observed_at': time.time(), 'complete': True,
                       'listeners': [{'port': 22, 'protocol': 'tcp'}]}
        out, report = resolve_ports('openssh-server', {}, {}, observation=observation, allow_alternates=True, service_presence="absent")
        self.assertEqual(out['port'], 22)
        self.assertIn('verify ownership', report['decisions'][0]['reason'])

    def test_reserved_udp_does_not_claim_tcp_conflict(self):
        out, _ = resolve_ports('nginx', {}, {}, reserved={('udp', 80)})
        self.assertEqual(out['port'], 80)

    def test_dns_reserves_both_transports(self):
        self.assertEqual(endpoint_set('unbound', {'port': 1053}), {('tcp', 1053), ('udp', 1053)})

    def test_invalid_port_shapes_refused(self):
        for value in (True, False, None, 0, 65536, -1, 1.5, '80', [], {}):
            with self.subTest(value=value), self.assertRaises(ValueError):
                port_number(value)

    def test_ui_port_text_validated_without_eval(self):
        self.assertEqual(port_text(' 8080 '), 8080)
        for value in ('', '1.2', '-80', '0', '65536', '80;id', '８０', '1e3', 'True'):
            with self.subTest(value=value), self.assertRaises(ValueError):
                port_text(value)

    def test_malformed_choice_is_controlled(self):
        for value in (None, [], 'auto', {'mode': []}, {'mode': 'bad'}, {'mode': 'auto', 'port': 9999}):
            with self.subTest(value=value), self.assertRaises(ValueError):
                resolve_ports('nginx', {}, {'port': value})

    def test_unknown_field_refused(self):
        with self.assertRaises(ValueError):
            resolve_ports('nginx', {}, {'made_up_port': {'mode': 'auto'}})

    def test_adoption_only_not_misrepresented_as_configured(self):
        for sid in ('docker', 'slapd', 'mongodb', 'rabbitmq-server'):
            with self.subTest(service=sid):
                self.assertFalse(capability(sid)['editable'])
                with self.assertRaises(ValueError):
                    resolve_ports(sid, {}, {})

    def test_dhcp_and_nfs_listener_boundaries_explicit(self):
        self.assertFalse(capability('isc-dhcp-server')['editable'])
        self.assertFalse(capability('nfs-server')['editable'])

    def test_rsyslog_is_destination_not_listener(self):
        self.assertEqual(fields_for('rsyslog')[0].role, 'destination')
        self.assertEqual(endpoint_set('rsyslog', {'forward_port': 1514}), set())

    def test_dovecot_fields_follow_enabled_protocols_and_tls(self):
        self.assertEqual([f.key for f in fields_for('dovecot')], ['imap_port'])
        options = {'protocols': ['imap', 'pop3'], 'ssl_certificate_path': '/c', 'ssl_key_path': '/k'}
        self.assertEqual([f.key for f in fields_for('dovecot', options)], ['imap_port','imaps_port','pop3_port','pop3s_port'])

    def test_ftp_range_cannot_overlap_control(self):
        with self.assertRaisesRegex(ValueError, 'control port'):
            endpoint_set('vsftpd', {'listen_port': 40005})

    def test_ftp_range_reversed_or_too_large_refused(self):
        for options in ({'pasv_min_port': 5000, 'pasv_max_port': 4999}, {'pasv_min_port': 5000, 'pasv_max_port': 9000}):
            with self.assertRaises(ValueError): endpoint_set('vsftpd', options)

    def test_ftp_passive_range_collision_refused(self):
        with self.assertRaisesRegex(ValueError, 'passive FTP range'):
            resolve_ports('vsftpd', {}, {}, reserved={('tcp', 40050)})

    def test_duplicate_mail_listener_ports_refused(self):
        with self.assertRaises(ValueError):
            resolve_ports('dovecot', {'protocols': ['imap','pop3']},
                          {'imap_port': {'mode':'manual','port':2143}, 'pop3_port':{'mode':'manual','port':2143}})

    def test_different_explicit_web_ports_allow_selection(self):
        report = selection_report(['nginx','apache2'], options={'nginx':{'port':8080}, 'apache2':{'port':8081}})
        self.assertFalse(report['blocking'])

    def test_same_explicit_web_ports_refused(self):
        report = selection_report(['nginx','apache2'], options={'nginx':{'port':8080}, 'apache2':{'port':8080}})
        self.assertTrue(report['blocking'])

    def test_different_family_listener_collision_refused(self):
        report = selection_report(['nginx','redis'], options={'nginx':{'port':6379}, 'redis':{'port':6379}})
        self.assertTrue(report['blocking'])

    def test_existing_running_unselected_role_stays_protected(self):
        report = selection_report(['nginx'], presence={'apache2':'running'}, options={'nginx':{'port':8080}})
        self.assertTrue(report['blocking'])

    def test_listener_snapshot_bounded_and_stale_aware(self):
        sample = {'observed_at': 100, 'listeners':[{'port':8080,'protocol':'tcp6'}]}
        self.assertEqual(listener_observation(sample, now=101)['listeners'], [{'port':8080,'protocol':'tcp'}])
        self.assertFalse(listener_observation(sample, now=200)['complete'])
        sample['listeners'] *= 300
        self.assertFalse(listener_observation(sample, now=101)['complete'])
        self.assertEqual(len(listener_observation(sample, now=101)['listeners']), 256)

    def test_required_constraints_exact_unit_and_host(self):
        manifests=[{'host':'agent','service_id':'nginx','port':8080,'protocol':'http'}]
        self.assertEqual(manifest_constraints('nginx', {}, manifests, {'agent'}), {'port':8080})
        self.assertEqual(manifest_constraints('nginx', {}, manifests, {'different'}), {})

    def test_imaps_constraint_does_not_change_plaintext_listener(self):
        options={'protocols':['imap'],'ssl_certificate_path':'/c','ssl_key_path':'/k'}
        self.assertEqual(manifest_constraints('dovecot', options,
             [{'host':'a','service_id':'dovecot','port':1993,'protocol':'imaps'}], {'a'}), {'imaps_port':1993})

    def test_actual_manifest_port_mismatch_refused(self):
        with self.assertRaisesRegex(ValueError, 'approved manifest'):
            validate_manifest_ports('nginx', {'port':8080}, {'host':'a','service_id':'nginx','port':80,'expected_transactions':[]}, {'address':'127.0.0.1'})

    def test_stale_probe_port_refused(self):
        with self.assertRaisesRegex(ValueError, 'check still uses'):
            validate_manifest_ports('nginx', {'port':8080}, {'host':'a','service_id':'nginx','port':8080,
                'expected_transactions':[{'kind':'http','target':'http://127.0.0.1/'}]}, {'address':'127.0.0.1'})

    def test_ssh_management_migration_not_invented(self):
        with self.assertRaisesRegex(ValueError, 'management port'):
            validate_manifest_ports('openssh-server', {'port':2222}, {'host':'a','service_id':'ssh','port':2222,'expected_transactions':[]},
                                    {'address':'127.0.0.1','transport':'ssh','port':22})


class PortGeneration1992Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='sb1992-ports-');self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)

    def source(self, name, text):
        path=self.root/name;path.write_text(text)
        return {'path':str(path),'sha256':hashlib.sha256(text.encode()).hexdigest()}

    def generated(self, sid, options):
        captured={}
        def renderer(opt, root, **kwargs):
            captured.update(options=opt, files=kwargs['generated_sources']);return 'check','apply',None
        with patch.object(packs,'_linux_service',renderer):
            packs.build(sid, options, self.root, metadata=captured)
        return captured

    def test_all_new_simple_port_fields_reach_configuration(self):
        cases = [('unbound','port',1053,'port: 1053'), ('dnsmasq','port',2053,'port=2053'),
                 ('chrony','port',1123,'port 1123'), ('vsftpd','listen_port',2121,'listen_port=2121'),
                 ('dovecot','imap_port',1143,'port = 1143'), ('samba','smb_port',1445,'smb ports = 1445 139')]
        for sid, key, value, expected in cases:
            with self.subTest(service=sid):
                options=baseline_for(sid,self.root);options[key]=value
                self.assertIn(expected, '\n'.join(self.generated(sid,options)['files'].values()))

    def test_ordinary_existing_port_fields_still_reach_configuration(self):
        cases=[('openssh-server','port',2222,'Port 2222'), ('mariadb','port',13306,'13306'),
               ('postgresql','port',15432,'15432'),('redis','port',16379,'port 16379'),
               ('gunicorn','port',18000,':18000'),('haproxy','frontend_port',18080,':18080'),
               ('mosquitto','listener_port',11883,'listener 11883'),('apache2','port',18081,':18081')]
        for sid,key,value,text in cases:
            with self.subTest(service=sid):
                options=baseline_for(sid,self.root);options[key]=value
                self.assertIn(text, '\n'.join(self.generated(sid,options)['files'].values()))

    def test_bind_port_snapshot_preserves_other_options(self):
        text='// fixture\noptions { directory "/var/cache/bind"; recursion no; };\n'
        options=baseline_for('bind9', self.root)
        options.update(port=1053,listener_config=self.source('named.conf.options',text))
        result=self.generated('bind9',options)
        self.assertIn('port 1053;',result['files']['/etc/bind/named.conf.options'])
        self.assertIn('recursion no;',result['files']['/etc/bind/named.conf.options'])
        item=next(f for f in result['files'] if f.endswith('named.conf.options'))
        self.assertEqual(next(f['previous_sha256'] for f in result['options']['files'] if f['path']==item),options['listener_config']['sha256'])

    def test_bind_port_requires_snapshot(self):
        with self.assertRaisesRegex(ValueError,'listener_config'):
            self.generated('bind9',dict(baseline_for('bind9', self.root),port=1053))

    def test_bind_explicit_other_listener_refused(self):
        with self.assertRaisesRegex(ValueError,'explicit BIND'):
            bind_port('options { listen-on port 8053 { 127.0.0.1; }; };',1053)

    def test_bind_comments_quotes_and_nested_braces_preserved(self):
        text='/* options { port 1; }; */\noptions { directory "/x/{port}"; allow-query { 127.0.0.1; }; };\n'
        result=bind_port(text,1053)
        self.assertIn('directory "/x/{port}";',result)
        self.assertEqual(result.count('port 1053;'),1)
        self.assertEqual(bind_port(result,2053).count('port 2053;'),1)

    def test_bind_multiple_options_or_include_refused(self):
        for text in ('options {}; options {};','options { include "/x"; };','options {'):
            with self.subTest(text=text), self.assertRaises(ValueError):bind_port(text,1053)

    def test_postfix_port_exact_parent_snapshot(self):
        text='smtp inet n - y - - smtpd\n  -o some_option=yes\nsubmission inet n - y - - smtpd\n'
        options=baseline_for('postfix',self.root)
        options.update(smtp_port=2525,master_config=self.source('master.cf',text))
        result=self.generated('postfix',options)
        generated=result['files']['/etc/postfix/master.cf']
        self.assertTrue(generated.startswith('2525 inet'))
        self.assertIn('  -o some_option=yes\nsubmission inet',generated)

    def test_postfix_port_snapshot_required(self):
        with self.assertRaisesRegex(ValueError,'master_config'):
            self.generated('postfix',dict(baseline_for('postfix',self.root),smtp_port=2525))

    def test_postfix_update_existing_numeric_listener(self):
        self.assertEqual(postfix_smtp_port('2525 inet n - y - - smtpd\n',2526,'2525'), '2526 inet n - y - - smtpd\n')

    def test_postfix_ambiguous_or_occupied_listener_refused(self):
        cases=('smtp inet n - y - - smtpd\nsmtp inet n - y - - smtpd\n',
               'smtp inet n - y - - smtpd\n2525 inet n - y - - smtpd\n',
               'smtp inet n - y - - OTHER\n')
        for text in cases:
            with self.assertRaises(ValueError):postfix_smtp_port(text,2525)

    def test_dovecot_tls_port_requires_tls_prerequisites(self):
        with self.assertRaisesRegex(ValueError,'certificate and key'):
            self.generated('dovecot',{'imaps_port':1993})

    def test_dovecot_secure_listener_remains_secure(self):
        result=self.generated('dovecot',{'imaps_port':1993,'ssl_certificate_path':'/cert','ssl_key_path':'/key'})
        text=next(iter(result['files'].values()))
        self.assertIn('inet_listener imaps {\n        port = 1993\n        ssl = yes',text)
        self.assertIn('ssl = required',text)

    def test_dovecot_disabled_protocol_port_refused(self):
        with self.assertRaisesRegex(ValueError,'disabled'):
            self.generated('dovecot',{'protocols':['imap'],'pop3_port':1110})

    def test_new_fields_reject_bad_types_before_script_generation(self):
        for sid,key in [('unbound','port'),('dnsmasq','port'),('chrony','port'),('vsftpd','listen_port'),
                        ('dovecot','imap_port'),('samba','smb_port'),('bind9','port'),('postfix','smtp_port')]:
            for value in ([],{},'80',True,0,65536,None):
                with self.subTest(service=sid,value=value), self.assertRaises(ValueError):
                    self.generated(sid,dict(baseline_for(sid,self.root),**{key:value}))

    def test_new_custom_port_scripts_parse(self):
        for sid,key,value in [('unbound','port',1053),('dnsmasq','port',2053),('chrony','port',1123),
                              ('vsftpd','listen_port',2121),('dovecot','imap_port',1143),('samba','smb_port',1445)]:
            options=dict(baseline_for(sid,self.root),**{key:value})
            for phase, script in zip(('check','apply','rollback'),packs.build(sid,options,self.root)):
                if script:
                    with self.subTest(service=sid,phase=phase):
                        result=subprocess.run(['sh','-n'],input=script,text=True,capture_output=True)
                        self.assertEqual(result.returncode,0,result.stderr)

    def test_actual_setup_compiler_enforces_manifest_port(self):
        from test_setup import fixture
        from sentinel_blue.event_profile import EventProfile
        from sentinel_blue.setup import compile_plan
        inventory,profile=fixture(self.root,hosts=1)
        raw=copy.deepcopy(profile.raw);raw['services'][0]['service_id']='nginx'
        profile=EventProfile.from_dict(raw)
        content=self.source('content.txt','healthy')
        inventory['setup']['tasks']=[{'id':'site','host':'host-0','service_id':'nginx','recipe':'linux-nginx',
                                     'options':{'name':'fixture','listen_address':'127.0.0.1','port':8081,'content':content}}]
        with self.assertRaisesRegex(ValueError,'approved manifest'):
            compile_plan(inventory,profile,self.root)
        inventory['setup']['tasks'][0]['options']['port']=8080
        plan=compile_plan(inventory,profile,self.root)
        self.assertTrue(plan)


@unittest.skipUnless(os.environ.get('DISPLAY'), 'actual port GUI requires a display')
class PortGUI1992Tests(unittest.TestCase):
    def setUp(self):
        import tkinter as tk
        from tkinter import ttk
        self.tk,self.ttk=tk,ttk
        self.root=tk.Tk();self.root.geometry('1050x780')
        self.panel=ServiceSelectionPanel(self.root,(tk,ttk))
        self.root.update()

    def tearDown(self):
        editor=self.panel.port_editor
        if editor and editor.window is not None:editor.close()
        self.root.destroy()
        self.panel=None
        import gc;gc.collect()

    def open(self,sid,options=None):
        if options is not None:self.panel.options[sid]=options
        self.panel.tree.selection_set(sid);self.panel._edit_ports();self.root.update()
        return self.panel.port_editor

    def test_manual_box_saves_real_numeric_option(self):
        editor=self.open('mariadb')
        row=editor.rows['port'];row['mode'].set('Manual');row['value'].set('13306');editor.preview()
        self.assertEqual(str(editor.save_button['state']),'normal')
        editor.save();self.root.update()
        self.assertEqual(self.panel.options['mariadb']['port'],13306)
        self.assertIn('mariadb',self.panel.selection)

    def test_invalid_box_disables_save_and_preserves_options(self):
        editor=self.open('mariadb',{'port':3306})
        row=editor.rows['port'];row['mode'].set('Manual');row['value'].set('65536');editor.preview()
        self.assertEqual(str(editor.save_button['state']),'disabled')
        self.assertEqual(self.panel.options['mariadb']['port'],3306)
        self.assertIn('65535',editor.error.get())

    def test_auto_shows_and_saves_default(self):
        editor=self.open('mariadb')
        self.assertEqual(editor.rows['port']['value'].get(),'3306')
        self.assertEqual(str(editor.rows['port']['box']['state']),'readonly')
        editor.save();self.assertEqual(self.panel.options['mariadb']['port'],3306)

    def test_fixed_service_explains_without_a_port_dialog(self):
        self.panel.tree.selection_set('isc-dhcp-server')
        with patch('tkinter.messagebox.showinfo') as info:
            self.panel._edit_ports()
            self.assertIn('67/68',info.call_args.args[1])
        self.assertIsNone(self.panel.port_editor)

    def test_other_required_parameters_are_not_fabricated(self):
        editor=self.open('apache2');editor.save()
        self.assertIn('apache2',self.panel.port_requirements)
        self.assertTrue(self.panel.report()['blocking'])

    def test_host_switch_retains_separate_options(self):
        self.panel.observe({},host='host-a')
        self.panel.selection=['mariadb'];self.panel.options={'mariadb':{'port':13306}}
        self.panel.observe({},host='host-b')
        self.assertFalse(self.panel.options)
        self.panel.observe({},host='host-a')
        self.assertEqual(self.panel.options['mariadb']['port'],13306)

    def test_dialog_detects_changed_host(self):
        self.panel.observe({},host='host-a');editor=self.open('mariadb')
        self.panel.observe({},host='host-b');editor.preview()
        self.assertIn('host changed',editor.error.get())
        self.assertEqual(str(editor.save_button['state']),'disabled')

    def test_ftp_has_control_and_passive_range_boxes(self):
        editor=self.open('vsftpd')
        self.assertEqual(set(editor.rows),{'listen_port','pasv_min_port','pasv_max_port'})

    def test_bulk_auto_skips_adoption_only(self):
        self.panel.selection=['mariadb','docker']
        with patch('tkinter.messagebox.showinfo'):
            self.panel._automatic_ports()
        self.assertEqual(self.panel.options['mariadb']['port'],3306)
        self.assertNotIn('docker',self.panel.options)

    def test_stale_service_parameters_cannot_overwrite_newer_choices(self):
        editor=self.open('mariadb',{'port':3306})
        self.panel.options['mariadb']['bind_address']='127.0.0.2'
        editor.preview()
        self.assertEqual(str(editor.save_button['state']),'disabled')
        self.assertIn('parameters changed',editor.error.get())

    def test_long_mail_form_has_visible_footer_and_scrollable_content(self):
        editor=self.open('dovecot',{'protocols':['imap','pop3','submission'],
            'ssl_certificate_path':'/test/cert','ssl_key_path':'/test/key'})
        editor.window.geometry('790x480');self.root.update()
        self.assertEqual(len(editor.rows),6)
        bottom=editor.save_button.winfo_rooty()+editor.save_button.winfo_height()
        self.assertLessEqual(bottom,editor.window.winfo_rooty()+editor.window.winfo_height())
        self.assertIsNotNone(editor.canvas.bbox('all'))

    def test_cancel_does_not_apply_or_save(self):
        editor=self.open('mariadb')
        editor.rows['port']['mode'].set('Manual');editor.rows['port']['value'].set('14000')
        editor.close();self.assertNotIn('mariadb',self.panel.options)

class PortAdditional1992Tests(unittest.TestCase):
    def test_unix_socket_mail_configuration_is_not_mislabeled_adopt_only(self):
        status=capability('dovecot',{'protocols':['lmtp']})
        self.assertFalse(status['editable'])
        self.assertIn('Unix sockets',status['reason'])
        self.assertNotIn('Adopt-only',status['reason'])

    def test_collector_errors_prevent_complete_port_observation(self):
        now=time.time()
        row=listener_observation({'observed_at':now,'listeners':[],'collector_errors':['listeners failed']},now=now)
        self.assertFalse(row['complete'])

    def test_postfix_symbolic_submission_collision_refused(self):
        from sentinel_blue.port_config_merge import postfix_smtp_port
        text='smtp inet n - y - - smtpd\nsubmission inet n - y - - smtpd\n'
        with self.assertRaisesRegex(ValueError,'already uses'):
            postfix_smtp_port(text,587)

    def test_postfix_bound_numeric_conflict_refused(self):
        from sentinel_blue.port_config_merge import postfix_smtp_port
        with self.assertRaisesRegex(ValueError,'already uses'):
            postfix_smtp_port('smtp inet n - y - - smtpd\n127.0.0.1:2525 inet n - y - - smtpd\n',2525)

    def test_postfix_unknown_symbolic_listener_held(self):
        from sentinel_blue.port_config_merge import postfix_smtp_port
        with self.assertRaisesRegex(ValueError,'explicit reviewed'):
            postfix_smtp_port('smtp inet n - y - - smtpd\ncustom-mail inet n - y - - smtpd\n',2525)

    def test_parent_merge_helpers_reject_invalid_port_types(self):
        from sentinel_blue.port_config_merge import bind_port, postfix_smtp_port
        for fn,text in ((bind_port,'options {};'),(postfix_smtp_port,'smtp inet n - y - - smtpd\n')):
            for value in (None,True,[],{},'53',0,65536):
                with self.subTest(fn=fn.__name__,value=value), self.assertRaises(ValueError):
                    fn(text,value)
