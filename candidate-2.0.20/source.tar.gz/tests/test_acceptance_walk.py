"""The acceptance walk, driven against a simulated host.

1.9.86 shipped a harness that could never succeed: eleven of the seventeen
required steps were recorded as skipped unconditionally, so `--run` ended in
"NO RECEIPT" on every host, forever. The plan output was real; the thing it
promised was not reachable.

These tests exist so that cannot happen again. They stand up a fake host and a
fake Sentinel runtime and walk the whole matrix, which proves two things a lab
cannot be borrowed to prove on demand: that a healthy host reaches a receipt, and
that failing any one required step prevents one and names the step.

The fake is a model of a host, not a host. It says the orchestration asks the
right questions in the right order and judges the answers correctly. It says
nothing about whether a real BIND or Postfix would pass.
"""
import hashlib
import json
import copy
import contextlib
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

from acceptance_steps import Acceptance                      # noqa: E402
from sentinel_blue import pack_acceptance                    # noqa: E402
from sentinel_blue.linux_service_catalog import entry        # noqa: E402
from service_pack_acceptance import Report                   # noqa: E402

SERVICE = "redis"
OPTIONS = {"bind_address": "127.0.0.1"}
UPDATE = {"bind_address": "127.0.0.1", "port": 6380}
INVALID = {"bind_address": "127.0.0.1", "port": 1}

PROFILE = {
    "positive": {"argv": ["redis-cli", "PING"], "expect_returncode": 0,
                 "expect_stdout_contains": ["PONG"]},
    "denied": {"argv": ["redis-cli", "--no-auth", "PING"], "expect_failure": True,
               "expect_stderr_contains": ["NOAUTH"]},
    "config_test": {"argv": ["redis-server", "--check-config",
                             "/etc/redis/sentinel.conf"]},
    "update_options": UPDATE,
    "invalid_options": INVALID,
    "effective": {"argv": ["fixture-effective-query"], "expect_stdout_contains": ["MATCH"]},
    "withdrawal": {"runtime_argv": ["/fixture/observer"], "inventory": "/fixture/inventory",
                   "event_profile": "/fixture/profile", "directory": "/fixture/review"},
}

# These are synthetic model configurations, not native Redis rejection inputs.
# The fixture's low-port failure is modeled only; real profiles need real product evidence.
UPDATE['previous_files'] = {f['path']: f['sha256'] for f in pack_acceptance.pack_contract(SERVICE, OPTIONS, ROOT)['files']}
INVALID['previous_files'] = {f['path']: f['sha256'] for f in pack_acceptance.pack_contract(SERVICE, UPDATE, ROOT)['files']}

INVENTORY = {
    "hosts": [{"name": "lab-linux", "platform": "linux", "agent_id": "lab-linux", "transport": "local", "address": "127.0.0.1"}],
    "setup": {"tasks": []},
}


class FakeHost:
    """Explicit simulation. Snapshots/lifecycle/write signals are modeled, not native."""
    def __init__(self, *, files=None, fail=()):
        self.files = dict(files or {})
        self.hashes = {}
        self.fail = set(fail)
        self.log = []
        self.restarts = 0
        self.writes = []

    def _digest(self,path):
        value = self.files.get(path)
        return self.hashes.get(path) or (hashlib.sha256(value.encode()).hexdigest() if value is not None else None)

    def write(self,path,content,sha=None):
        self.files[path] = content
        self.hashes.pop(path,None)
        if sha:
            self.hashes[path] = sha
        self.writes.append(path)

    def remove(self,path):
        self.files.pop(path,None)
        self.hashes.pop(path,None)
        self.writes.append(path)

    def snapshot(self,paths):
        return {p: ({'type':'file','sha256':self._digest(p),'mode':420,'uid':0,'gid':0}
                    if p in self.files else {'type':'absent'}) for p in paths}

    def service_state(self,unit):
        return {'LoadState':'not-found' if 'units' in self.fail else 'loaded',
                'ActiveState':'inactive' if 'active' in self.fail else 'active',
                'UnitFileState':'enabled','InvocationID':f'{self.restarts+1:032x}',
                'MainPID':str(100+self.restarts),'ExecMainStartTimestampMonotonic':str(1000+self.restarts),
                'ActiveEnterTimestampMonotonic':str(1000+self.restarts),'NRestarts':str(self.restarts)}

    def stage_edit(self,path,marker,backup_dir):
        original = self.files[path]
        token = {'path':path,'before':self.snapshot([path])[path],
                 'original':original,'original_hash':self.hashes.get(path)}
        self.write(path,original+marker)
        token['edited'] = self.snapshot([path])[path]
        return token

    def restore_edit(self,token):
        if self.snapshot([token['path']])[token['path']] != token['edited']:
            raise RuntimeError('fixture conflict')
        self.write(token['path'],token['original'],token['original_hash'])
        return True

    @contextlib.contextmanager
    def watch_writes(self,paths):
        start = len(self.writes)
        host = self
        class Watch:
            def changed_paths(self):
                return list(set(host.writes[start:]) & set(paths))
        yield Watch()

    def run(self,argv,**kwargs):
        argv = [str(x) for x in argv]
        self.log.append(argv)
        def result(code=0,out='',err=''):
            return {'argv':argv,'returncode':code,'stdout':out,'stderr':err}
        if argv[0]=='dpkg-query':
            return result(1 if 'packages' in self.fail else 0,
                          ''.join('install ok installed\n' for p in argv[3:]))
        if argv[0]=='systemctl' and 'restart' in argv:
            self.restarts+=1
            return result(1 if 'restart' in self.fail else 0)
        if argv[0]=='redis-server':
            return result(1 if 'configtest' in self.fail else 0)
        if argv[0]=='redis-cli':
            if '--no-auth' in argv:
                return result(1 if 'denied' not in self.fail else 0,
                              '' if 'denied' not in self.fail else 'PONG',
                              'NOAUTH' if 'denied' not in self.fail else '')
            return result(1 if 'positive' in self.fail else 0,
                          '' if 'positive' in self.fail else 'PONG')
        if argv[0]=='fixture-effective-query':
            return result(0,'MATCH')
        return result(0)


class FakeRuntime:
    """Deliberately configurable faults to test the judge, not a real server."""
    def __init__(self,host,owned,*,fail=()):
        self.host,self.owned,self.fail = host,owned,set(fail)
        self.applied = 0
        self.original_files = copy.deepcopy(host.files)
        self.original_hashes = copy.deepcopy(host.hashes)
        self.transaction = 0

    def plan(self,inventory,plan_out):
        body = Path(inventory).read_text()
        digest = hashlib.sha256(body.encode()).hexdigest()
        if 'plan' in self.fail:
            return {'returncode':1,'stdout':'','stderr':'planning refused'},None
        return {'returncode':0,'stdout':json.dumps({'plan_sha256':digest}),'stderr':''},digest

    def apply(self,inventory,digest,state_dir):
        from sentinel_blue.pack_acceptance import pack_contract
        body = Path(inventory).read_text()
        self.transaction+=1
        def result(code=0,changed=True,reason='',rollback=False):
            task = {'status':'ready' if code==0 else 'failed','changed':changed,
                    'transaction_id':f'{self.transaction:032x}',
                    'apply':{'returncode':code,'uncertain':False,'stderr':reason},'reason':reason}
            if rollback:
                task['rollback_status']='completed'
            report = {'status':'ready' if code==0 else 'incomplete','tasks':{'sentinel-redis':task}}
            return {'returncode':code,'stdout':json.dumps(report),'stderr':reason,'report':report}
        if json.loads(body)['setup']['tasks'][0]['options'].get('port') == 1:
            before_files,before_hashes = copy.deepcopy(self.host.files),copy.deepcopy(self.host.hashes)
            if 'no-write' not in self.fail:
                for path in self.owned:
                    self.host.write(path,'invalid configuration')
            if 'interrupted' in self.fail:
                return result()
            self.host.files,self.host.hashes = before_files,before_hashes
            return result(1,reason='product rejected after write',rollback=True)
        for path in self.owned:
            if 'sentinel acceptance: an edit' in self.host.files.get(path,''):
                if 'outside-delete' in self.fail:
                    self.host.remove(path)
                    return result(1,reason='OwnershipConflict')
                if 'outside' in self.fail:
                    self.host.write(path,'overwritten')
                    return result()
                return result(1,changed=False,reason='OwnershipConflict: unreviewed change present')
        if 'apply' in self.fail:
            return result(1,changed=False,reason='apply failed')
        opts = json.loads(body)['setup']['tasks'][0]['options']
        opts = {k:v for k,v in opts.items() if k not in {'catalog_id','manager'}}
        contract = pack_contract('redis',opts,Path(inventory).parent)
        changed = any(self.host._digest(row['path'])!=row['sha256'] for row in contract['files'])
        self.applied+=1
        for row in contract['files']:
            self.host.write(row['path'],'generated:'+row['sha256'],row['sha256'])
        if 'reapply' in self.fail and self.applied>1:
            for path in self.owned:self.host.write(path,'unnecessary change')
            changed=True
        if 'reapply-restart' in self.fail and self.applied>1:
            self.host.restarts+=1
        return result(changed=changed)

    def withdraw(self,inventory,directory,mode='restore-withdraw',**kwargs):
        assert mode=='restore-withdraw', 'Remove is not restoration'
        if 'withdraw' in self.fail:
            return {'returncode':1,'stdout':'','stderr':'withdraw failed'}
        self.host.files,self.host.hashes = copy.deepcopy(self.original_files),copy.deepcopy(self.original_hashes)
        report={'status':'complete','mode':mode,'conflicts':[],
                'external_verification':[{'healthy':True,'external':True,'simulation':True}]}
        return {'returncode':0,'stdout':json.dumps(report),'stderr':'','report':report}


def walk(*, host_fail=(), runtime_fail=(), profile=None):
    root = Path(tempfile.mkdtemp(prefix="sentinel-walk-"))
    inventory = root / "inventory.json"
    inventory.write_text(json.dumps(INVENTORY), encoding="utf-8")
    fingerprint = pack_acceptance.pack_fingerprint(SERVICE, OPTIONS, root)

    metadata: dict = {}
    from sentinel_blue.linux_service_packs import build
    build(SERVICE, OPTIONS, root, metadata=metadata)
    owned = [row["path"] for row in metadata["files"]]

    host = FakeHost(files={"/etc/redis/redis.conf": "# the operator's own file\n",
                           "/var/lib/redis": "data"}, fail=host_fail)
    runtime = FakeRuntime(host, owned, fail=runtime_fail)
    report = Report(SERVICE)
    acceptance = Acceptance(service_id=SERVICE, row=entry(SERVICE), options=OPTIONS,
                            profile=PROFILE if profile is None else profile,
                            executor=host, runtime=runtime, workdir=root,
                            inventory=inventory, report=report, fingerprint=fingerprint)
    acceptance.walk()
    return report, host, runtime, fingerprint


class HealthyHostTests(unittest.TestCase):
    """The case 1.9.86 could not reach at all."""

    @classmethod
    def setUpClass(cls):
        cls.report, cls.host, cls.runtime, cls.fingerprint = walk()

    def test_every_required_step_passes(self):
        for name in pack_acceptance.REQUIRED:
            with self.subTest(step=name):
                self.assertEqual(self.report.results[name]["verdict"], "passed",
                                 self.report.results[name]["detail"])

    def test_the_walk_reaches_a_receipt(self):
        self.assertTrue(self.report.required_all_passed)
        receipt = pack_acceptance.build_receipt(
            SERVICE, options=OPTIONS, results=self.report.results,
            product_version="redis 7.0.15", fingerprint=self.fingerprint,
            runtime="b" * 64, operator="lab")
        self.assertEqual(receipt["service_id"], SERVICE)

    def test_the_optional_steps_are_skipped_with_their_reason(self):
        for name in pack_acceptance.OPTIONAL:
            with self.subTest(step=name):
                self.assertEqual(self.report.results[name]["verdict"], "skipped")
                self.assertTrue(self.report.results[name]["detail"])

    def test_the_host_is_left_as_it_was_found(self):
        self.assertEqual(self.host.files.get("/etc/redis/redis.conf"),
                         "# the operator's own file\n")
        self.assertIsNone(self.host.files.get("/etc/redis/sentinel.conf"))


class FailingStepTests(unittest.TestCase):
    """Each way a host can fail must stop the receipt and name the step."""

    def assert_blocks(self, step, **kwargs):
        report, *_ = walk(**kwargs)
        self.assertEqual(report.results[step]["verdict"], "failed",
                         f"{step} should have failed: {report.results[step]}")
        self.assertFalse(report.required_all_passed)
        with self.assertRaises(ValueError) as error:
            pack_acceptance.build_receipt(
                SERVICE, options=OPTIONS, results=report.results,
                product_version="redis 7.0.15", fingerprint="a" * 64,
                runtime="b" * 64, operator="lab")
        self.assertIn(step, str(error.exception))

    def test_a_rejected_configuration_blocks(self):
        self.assert_blocks("config-test", host_fail=("configtest",))

    def test_a_missing_package_blocks(self):
        self.assert_blocks("preflight", host_fail=("packages",))

    def test_an_inactive_unit_blocks(self):
        self.assert_blocks("service-active", host_fail=("active",))

    def test_a_failed_apply_blocks(self):
        self.assert_blocks("apply", runtime_fail=("apply",))

    def test_a_failing_scored_transaction_blocks(self):
        self.assert_blocks("positive-transaction", host_fail=("positive",))

    def test_a_weakening_that_is_not_refused_blocks(self):
        """The service answered an unauthenticated client. That is the whole point."""
        self.assert_blocks("denied-transaction", host_fail=("denied",))

    def test_a_reapply_that_rewrites_blocks(self):
        self.assert_blocks("identical-reapply", runtime_fail=("reapply",))

    def test_overwriting_an_outside_edit_blocks(self):
        self.assert_blocks("outside-edit-refused", runtime_fail=("outside",))

    def test_applying_a_configuration_the_product_rejects_blocks(self):
        self.assert_blocks("interrupted-setup", runtime_fail=("interrupted",))

    def test_a_failed_restart_blocks(self):
        self.assert_blocks("restart-survives", host_fail=("restart",))

    def test_a_withdrawal_that_leaves_artifacts_blocks(self):
        self.assert_blocks("rollback", runtime_fail=("withdraw",))


class MissingProfileTests(unittest.TestCase):
    def test_without_probes_the_required_steps_are_skipped_and_no_receipt_follows(self):
        report, *_ = walk(profile={})
        for step in ("positive-transaction", "denied-transaction",
                     "approved-update", "interrupted-setup"):
            with self.subTest(step=step):
                self.assertEqual(report.results[step]["verdict"], "skipped")
                self.assertTrue(report.results[step]["detail"])
        self.assertFalse(report.required_all_passed)


if __name__ == "__main__":
    unittest.main()
