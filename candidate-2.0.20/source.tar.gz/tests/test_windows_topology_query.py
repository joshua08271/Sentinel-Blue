"""Compare read-only IP Helper observations with Windows' existing provider."""
import ipaddress
import os
import socket
import time
import unittest

from sentinel_blue.windows_topology_query import TOPOLOGY_QUERY


class WindowsTopologyTests(unittest.TestCase):
    @unittest.skipUnless(os.name == 'nt', 'requires native Windows IP Helper APIs')
    def test_native_routes_match_provider_and_owned_listener_has_exact_identity(self):
        from sentinel_blue.windows_query_batch import read_query_batch
        with socket.socket() as listener:
            listener.bind(('127.0.0.1', 0))
            listener.listen(1)
            port = listener.getsockname()[1]
            query = '$native=(& {\n'+TOPOLOGY_QUERY+'\n}) | ConvertFrom-Json\n'
            query += r'''
$reference=@(Get-NetRoute | Select-Object DestinationPrefix,NextHop,InterfaceAlias,RouteMetric)
[PSCustomObject]@{Native=$native;ReferenceRoutes=$reference} | ConvertTo-Json -Depth 7 -Compress
'''
            result = read_query_batch(time.monotonic()+60, {'TOPOLOGY':query})['TOPOLOGY']
            self.assertFalse(result.error, result.error)
            self.assertEqual(len(result.rows), 1)
            actual = result.rows[0]['Native']
            self.assertEqual(actual['Errors'], {})
            def key(row):
                return (str(ipaddress.ip_network(row['DestinationPrefix'], strict=False)),
                        str(ipaddress.ip_address(row['NextHop'].split('%')[0])),
                        row['InterfaceAlias'].casefold(), row['RouteMetric'])
            self.assertEqual({key(row) for row in actual['Routes']},
                             {key(row) for row in result.rows[0]['ReferenceRoutes']})
            self.assertTrue(any(row['LocalAddress']=='127.0.0.1' and row['LocalPort']==port
                                and row['OwningProcess']==os.getpid()
                                for row in actual['Listeners']))
            for row in actual['Neighbors']:
                ipaddress.ip_address(row['IPAddress'])
                self.assertTrue(row['InterfaceAlias'])
                self.assertIn(row['State'], {'Unreachable','Incomplete','Probe','Delay','Stale','Reachable','Permanent'})


if __name__ == '__main__':
    unittest.main()
