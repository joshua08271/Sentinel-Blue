"""Regression tests for the P0 reliability fixes.

Covered: offline policy version skew, large/replaced executable inventory,
baseline readiness classification, and operator-visible refusal reasons.
"""
import hashlib
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from sentinel_blue.controller import assess_baseline_readiness
from sentinel_blue.desktop_control import rejection_error
from sentinel_blue.offline_continuity import (
    MINIMUM_POLICY_SCHEMA_VERSIONS, POLICY_SCHEMA, supports_policy_schema)
from sentinel_blue.payload_inventory import fingerprint_references
from sentinel_blue.restoration import RestorePointStore


class OfflinePolicyVersionSkewTests(unittest.TestCase):
    def test_only_releases_that_parse_the_schema_may_be_authorized(self):
        self.assertTrue(supports_policy_schema(MINIMUM_POLICY_SCHEMA_VERSIONS[POLICY_SCHEMA], POLICY_SCHEMA))
        self.assertTrue(supports_policy_schema('1.9.76', POLICY_SCHEMA))
        self.assertTrue(supports_policy_schema('1.10.0', POLICY_SCHEMA))
        for value in ('1.9.74', '1.9.7', '1.8.99', '', None, 'nightly', '1.9.74a', '1.9.-1'):
            with self.subTest(version=value):
                self.assertFalse(supports_policy_schema(value, POLICY_SCHEMA))

    def test_earlier_signed_policy_schema_is_still_accepted(self):
        from sentinel_blue import offline_continuity as continuity
        legacy = {
            'schema': 1, 'id': '0' * 8, 'authority': {}, 'agent_id': 'agent-a',
            'profile_fingerprint': 'f' * 64, 'services': ['web'], 'action_types': ['restart_service'],
            'authorized_by': 'operator', 'created_at': 0.0, 'expires_at': 60.0, 'max_attempts': 1,
            'cooldown_seconds': 300, 'baseline': {'agent_id': 'agent-a'},
            'baseline_sha256': 'a' * 64, 'contracts': {}, 'validation': 'x', 'rollback': 'y',
        }
        # Stop after the schema gate: this test pins schema acceptance only.
        with patch.object(continuity.r, 'verify_signed_payload', return_value=dict(legacy)):
            with self.assertRaises(ValueError) as error:
                continuity.verify_policy({}, b'k', object(), 'agent-a', {}, 0.0)
        self.assertNotIn('Unsupported offline policy', str(error.exception))
        unknown = {**legacy, 'schema': 3}
        with patch.object(continuity.r, 'verify_signed_payload', return_value=unknown):
            with self.assertRaises(ValueError) as error:
                continuity.verify_policy({}, b'k', object(), 'agent-a', {}, 0.0)
        self.assertIn('Unsupported offline policy', str(error.exception))


@unittest.skipIf(os.name == 'nt', 'POSIX streaming fingerprint path')
class LargePayloadFingerprintTests(unittest.TestCase):
    def test_executable_larger_than_the_restore_limit_is_fingerprinted(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            root.chmod(0o755)
            target = root / 'large-program'
            payload = os.urandom(1024) * 40 * 1024  # ~40 MiB, over the 32 MiB restore limit
            target.write_bytes(payload)
            errors = []
            items = fingerprint_references([str(target)], errors, kind='process-payload')
            self.assertEqual(errors, [])
            self.assertEqual(len(items), 1)
            self.assertEqual(items[0].sha256, hashlib.sha256(payload).hexdigest())

    def test_small_file_digest_matches_the_in_memory_reader(self):
        with tempfile.TemporaryDirectory() as temporary:
            target = Path(temporary) / 'small'
            target.write_bytes(b'sentinel')
            digest, metadata, read = RestorePointStore._hash_target(target, maximum=1024)
            self.assertEqual(digest, hashlib.sha256(b'sentinel').hexdigest())
            self.assertEqual(read, len(b'sentinel'))
            self.assertIn('uid', metadata)

    def test_file_over_the_supplied_bound_is_still_refused(self):
        with tempfile.TemporaryDirectory() as temporary:
            target = Path(temporary) / 'big'
            target.write_bytes(b'x' * 4096)
            with self.assertRaises(ValueError):
                RestorePointStore._hash_target(target, maximum=1024)

    def test_symlinked_target_is_refused(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            real = root / 'real'
            real.write_bytes(b'data')
            link = root / 'link'
            link.symlink_to(real)
            with self.assertRaises(ValueError):
                RestorePointStore._hash_target(link, maximum=1024)


class BaselineReadinessClassificationTests(unittest.TestCase):
    BASE = {'probes': [{'healthy': True}], 'integrity': [{'path': '/etc/x'}], 'platform': 'linux'}

    def test_payload_coverage_gap_warns_instead_of_blocking(self):
        telemetry = {
            **self.BASE,
            'collector_errors': ['running executable was unlinked; on-disk payload coverage is incomplete'],
            'collector_issue_sources': ['payload_fingerprint'],
        }
        result = assess_baseline_readiness(telemetry)
        self.assertTrue(result['ready'], result)
        self.assertEqual(result['blockers'], [])
        self.assertTrue(any('payload coverage' in warning for warning in result['warnings']))
        self.assertLess(result['score'], 100)

    def test_real_collector_failure_still_blocks(self):
        telemetry = {
            **self.BASE,
            'collector_errors': ["route inventory failed: No such file or directory: 'ip'"],
            'collector_issue_sources': ['unknown'],
        }
        result = assess_baseline_readiness(telemetry)
        self.assertFalse(result['ready'])
        self.assertTrue(any('self-health' in blocker for blocker in result['blockers']))

    def test_mixed_errors_block_on_the_real_failure_only(self):
        telemetry = {
            **self.BASE,
            'collector_errors': ['payload gap', 'systemctl service inventory unavailable'],
            'collector_issue_sources': ['payload_fingerprint', 'unknown'],
        }
        result = assess_baseline_readiness(telemetry)
        self.assertFalse(result['ready'])
        self.assertEqual(result['blockers'], ['1 collector or agent self-health error(s)'])
        self.assertTrue(any('payload coverage' in warning for warning in result['warnings']))

    def test_untagged_errors_are_treated_as_failures(self):
        telemetry = {**self.BASE, 'collector_errors': ['something failed'], 'collector_issue_sources': []}
        result = assess_baseline_readiness(telemetry)
        self.assertFalse(result['ready'])


class ControllerRefusalMessageTests(unittest.TestCase):
    def test_reason_reaches_the_operator(self):
        error = rejection_error(403, {'error': 'agent release binding is not current and fresh'})
        self.assertIn('agent release binding is not current and fresh', str(error))

    def test_control_characters_and_length_are_bounded(self):
        message = str(rejection_error(403, {'error': 'bad\n\x00reason ' + 'z' * 500}))
        self.assertNotIn('\n', message)
        self.assertNotIn('\x00', message)
        self.assertLess(len(message), 300)

    def test_missing_or_unusable_error_keeps_the_generic_message(self):
        for value in ({}, {'error': {'nested': True}}, {'error': ''}, {'error': '   '}, 'not-a-dict'):
            with self.subTest(value=value):
                self.assertIn('refresh and review the current state', str(rejection_error(403, value)))


if __name__ == '__main__':
    unittest.main()
