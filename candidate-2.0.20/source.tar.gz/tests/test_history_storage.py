"""Real SQLite/archive transactions, recovery, and bounded storage behavior."""
import json
import os
from pathlib import Path
import sqlite3
import time
import unittest
from dataclasses import replace
from unittest.mock import patch

import test_baseline_promotion as promotion
import test_session_alert_continuity as continuity
from sentinel_blue.history_storage import HistoryPolicy, HistoryStorage, MIB, StoragePressure, compact_database, read_archive
from sentinel_blue.recovery_ops import prune_recovery_backups, verify_controller_backup
from sentinel_blue.store import Store


class HistoryStorageTests(unittest.TestCase):
    def setUp(self):
        self.fixture = continuity.SessionAlertContinuityTests()
        self.fixture.setUp()
        self.addCleanup(self.fixture.tearDown)
        self.store = self.fixture.store
        self.root = self.fixture.root / 'history'
        self.root.mkdir(mode=0o700)
        self.policy = HistoryPolicy(database_max_bytes=32*MIB, archive_max_bytes=16*MIB,
                                    archive_max_files=2, minimum_free_bytes=8*MIB,
                                    backup_max_bytes=32*MIB, minimum_online_seconds=60)
        self.manager = HistoryStorage(self.store, self.root, self.fixture.key, self.policy)
        self.fixture.app.history_storage = self.manager

    def archives(self):
        return [read_archive(path, self.fixture.key) for path in self.root.glob('*.sbhistory')]

    def event(self, name):
        with patch('sentinel_blue.store.time.time', return_value=time.time()-40*86400):
            return self.store.add_external_event('history-fixture', name, 'info')

    def age(self):
        with patch('sentinel_blue.history_storage.time.time', return_value=time.time()+31*86400):
            return self.manager.maintain()

    def row(self, table, key, value):
        found = self.store._connection.execute(f'SELECT * FROM {table} WHERE {key}=?', (value,)).fetchone()
        return dict(found) if found else None

    def test_expired_snapshots_are_archived_exactly_and_current_snapshot_is_kept(self):
        for n in range(1, 4):
            self.fixture.ingest(self.fixture.sample(n, []))
        before = {row['observation_id']: dict(row) for row in self.store._connection.execute(
            'SELECT * FROM telemetry_observations')}
        current = self.store.latest_telemetry_for_agent('agent-one')['sequence']
        removed = self.age()
        self.assertEqual(removed['telemetry_observations'], 2)
        self.assertEqual(self.store.latest_telemetry_for_agent('agent-one')['sequence'], current)
        archive = self.archives()[0]
        for identifier in archive['contents']['deleted']['telemetry_observations']:
            self.assertEqual(archive['contents']['records']['telemetry_observations'][identifier], before[identifier])
        self.assertEqual(self.store._connection.execute('SELECT COUNT(*) FROM telemetry_observations').fetchone()[0], 1)
        self.assertEqual(self.store._connection.execute('PRAGMA foreign_key_check').fetchall(), [])

    def test_closed_learning_graph_is_preserved_in_archive_before_expiry(self):
        self.fixture.ingest(self.fixture.sample(1, [self.fixture.session(201)]))
        alert = self.fixture.session_alerts()[0]
        lineage = self.store.alert_learning_lineage(alert['alert_id'])
        self.store.decide_alert_with_learning_label(
            alert['alert_id'], 'observe', 0, occurrence_id=lineage['creation_occurrence_id'],
            reviewer_principal_id='history-reviewer', label_source='unit-test',
        )
        label = dict(self.store._connection.execute('SELECT * FROM learning_labels').fetchone())
        occurrence = self.row('alert_occurrences', 'occurrence_id', label['occurrence_id'])
        observation = self.row('telemetry_observations', 'observation_id', occurrence['observation_id'])
        self.age()
        self.assertIsNone(self.store.get_alert(alert['alert_id']))
        archived = self.archives()[0]['contents']['records']
        self.assertEqual(archived['learning_labels'][label['label_id']], label)
        self.assertEqual(archived['alert_occurrences'][label['occurrence_id']], occurrence)
        self.assertEqual(archived['telemetry_observations'][occurrence['observation_id']], observation)
        self.assertEqual(archived['alert_lineage'][alert['alert_id']]['creation_occurrence_id'], label['occurrence_id'])
        self.assertEqual(self.store._connection.execute('PRAGMA foreign_key_check').fetchall(), [])

    def test_open_alert_keeps_first_latest_and_monotonic_occurrence_count(self):
        for n in range(1, 6):
            self.fixture.ingest(self.fixture.sample(n, [self.fixture.session(201)]))
        alert = self.fixture.session_alerts()[0]
        lineage = self.store.alert_learning_lineage(alert['alert_id'])
        self.age()
        self.assertEqual(self.store.alert_learning_lineage(alert['alert_id']), lineage)
        self.assertEqual(self.store._connection.execute('SELECT COUNT(*) FROM alert_occurrences').fetchone()[0], 2)
        self.assertEqual(self.store.alert_occurrence_count(alert['alert_id']), 5)
        self.fixture.ingest(self.fixture.sample(6, [self.fixture.session(201)]))
        self.assertEqual(self.store.alert_occurrence_count(alert['alert_id']), 6)
        self.assertEqual(self.store._connection.execute('PRAGMA foreign_key_check').fetchall(), [])

    def test_pending_work_pins_its_observations(self):
        for n in range(1, 4):
            self.fixture.ingest(self.fixture.sample(n, []))
        action = self.store.queue_action('agent-one', 'observe', {})
        self.age()
        self.assertIsNotNone(self.store.get_action(action))
        self.assertEqual(self.store._connection.execute('SELECT COUNT(*) FROM telemetry_observations').fetchone()[0], 3)

    def test_recent_label_stays_available_to_learning(self):
        self.fixture.ingest(self.fixture.sample(1, [self.fixture.session(201)]))
        alert = self.fixture.session_alerts()[0]
        lineage = self.store.alert_learning_lineage(alert['alert_id'])
        self.store.decide_alert_with_learning_label(
            alert['alert_id'], 'observe', 0, occurrence_id=lineage['creation_occurrence_id'],
            reviewer_principal_id='history-reviewer', label_source='unit-test')
        before = [tuple(row) for row in self.store._connection.execute('SELECT * FROM learning_labels')]
        self.manager.maintain()
        self.assertEqual([tuple(row) for row in self.store._connection.execute('SELECT * FROM learning_labels')], before)
        self.assertFalse(self.archives())

    def test_archive_write_failure_rolls_back_and_verified_backup_still_works(self):
        event = self.event('write-failure')
        with patch('sentinel_blue.history_storage._atomic_private_write', side_effect=OSError('fixture write failure')):
            with self.assertRaises(OSError):
                self.manager.maintain()
        self.assertIsNotNone(self.row('external_events', 'event_id', event))
        self.assertFalse(self.store._connection.in_transaction)
        backups = self.fixture.root / 'backups'
        backups.mkdir(mode=0o700)
        backup = self.fixture.app.create_recovery_backup(backups)
        self.assertTrue(verify_controller_backup(backup['bundle'], self.fixture.anchor, self.fixture.key)['verified'])

    def test_failure_after_archive_publish_retains_live_rows_and_recovers_on_restart(self):
        event = self.event('after-publication')
        with patch.object(self.manager, '_save_locked', side_effect=sqlite3.OperationalError('fixture commit failure')):
            with self.assertRaises(sqlite3.OperationalError):
                self.manager.maintain()
        self.assertIsNotNone(self.row('external_events', 'event_id', event))
        self.assertEqual(len(self.archives()), 1)
        self.assertFalse(self.store._connection.in_transaction)
        self.manager = HistoryStorage(self.store, self.root, self.fixture.key, self.policy)
        self.manager.maintain()
        self.assertIsNone(self.row('external_events', 'event_id', event))
        self.assertEqual(self.manager.status()['archived_records']['external_events'], 1)
        self.assertEqual(len(self.manager._state['committed_archives']), 1)

    def test_interruption_after_archive_publish_also_rolls_back(self):
        event = self.event('interrupt')
        with patch.object(self.manager, '_save_locked', side_effect=KeyboardInterrupt):
            with self.assertRaises(KeyboardInterrupt):
                self.manager.maintain()
        self.assertIsNotNone(self.row('external_events', 'event_id', event))
        self.assertFalse(self.store._connection.in_transaction)

    def test_archive_rotation_is_bounded_and_expiry_counts_survive_restart(self):
        for n in range(4):
            self.event(str(n))
            self.manager.maintain()
        self.assertEqual(len(self.archives()), 2)
        self.assertLessEqual(sum(p.stat().st_size for p in self.root.iterdir()), self.policy.archive_max_bytes)
        state = self.manager.status()
        self.assertEqual(state['archived_records']['external_events'], 4)
        self.assertEqual(state['expired_archive_records']['external_events'], 2)
        restarted = HistoryStorage(self.store, self.root, self.fixture.key, self.policy)
        self.assertEqual(restarted.status()['expired_archives'], 2)
        self.assertEqual(len(restarted._state['committed_archives']), 2)

    def test_expiry_intent_recovers_after_unlink_before_database_commit(self):
        for n in range(2):
            self.event(str(n))
            self.manager.maintain()
        self.event('third')
        save = self.manager._save_locked

        def fail_after_unlink():
            if 'pending_expiry' not in self.manager._state:
                raise OSError('fixture interrupted expiry receipt')
            save()

        with patch.object(self.manager, '_save_locked', side_effect=fail_after_unlink):
            with self.assertRaises(OSError):
                self.manager.maintain()
        restarted = HistoryStorage(self.store, self.root, self.fixture.key, self.policy)
        self.assertEqual(restarted.status()['expired_archives'], 1)
        restarted.maintain()
        again = HistoryStorage(self.store, self.root, self.fixture.key, self.policy)
        self.assertEqual(again.status()['expired_archives'], 1)
        self.assertEqual(again.status()['archived_records']['external_events'], 3)

    def test_age_based_archive_expiry_does_not_require_database_pressure(self):
        self.event('expired archive')
        self.manager.maintain()
        first_archive = self.archives()[0]['header']['archive_id']
        with patch('sentinel_blue.history_storage.time.time', return_value=time.time()+91*86400):
            self.manager.maintain()
        self.assertNotIn(first_archive, {a['header']['archive_id'] for a in self.archives()})
        self.assertEqual(self.manager.status()['expired_archive_records']['external_events'], 1)

    def test_missing_or_changed_committed_archive_is_reported(self):
        self.event('missing')
        self.manager.maintain()
        path = next(self.root.glob('*.sbhistory'))
        original = path.read_bytes()
        path.write_bytes(original[:-1] + bytes([original[-1] ^ 1]))
        with self.assertRaises(ValueError):
            self.manager.maintain()
        path.write_bytes(original)
        path.unlink()
        recovered = HistoryStorage(self.store, self.root, self.fixture.key, self.policy)
        self.assertTrue(recovered.status()['missing_historical_archives'])
        self.assertFalse(recovered.status()['telemetry_admission_paused'])

    def test_unrelated_files_are_never_deleted_to_make_archive_space(self):
        foreign = self.root / 'operator-kept.bin'
        foreign.write_bytes(b'x' * (16*MIB))
        foreign.chmod(0o600)
        event = self.event('keep this live')
        with self.assertRaises(StoragePressure):
            self.manager.maintain()
        self.assertEqual(foreign.stat().st_size, 16*MIB)
        self.assertIsNotNone(self.row('external_events', 'event_id', event))

    def test_caller_transaction_is_neither_committed_nor_rolled_back(self):
        self.store._connection.execute("INSERT INTO external_events VALUES('pending','fixture','pending','info',0)")
        with self.assertRaisesRegex(RuntimeError, 'existing transaction'):
            self.manager.maintain()
        self.assertTrue(self.store._connection.in_transaction)
        self.assertIsNotNone(self.row('external_events', 'event_id', 'pending'))
        self.store._connection.rollback()
        self.assertIsNone(self.row('external_events', 'event_id', 'pending'))

    def test_batch_limit_makes_progress_across_multiple_cycles(self):
        for n in range(10):
            self.event(str(n))
        with patch('sentinel_blue.history_storage.MAX_BATCH_UNITS', 3):
            first = self.manager.maintain()
            self.assertEqual(first['external_events'], 3)
            for _ in range(3):
                self.manager.maintain()
        self.assertEqual(self.store._connection.execute('SELECT COUNT(*) FROM external_events').fetchone()[0], 0)
        self.assertEqual(self.manager.status()['archived_records']['external_events'], 10)

    def test_database_pressure_blocks_before_advancing_telemetry_then_recovers(self):
        self.fixture.ingest(self.fixture.sample(1, []))
        db = self.store._connection
        detail = json.dumps({'fixture': 'z'*64000})
        n = 0
        while self.manager.status()['database_used_bytes'] < 28*MIB:
            db.execute('INSERT INTO audit_log VALUES(?,?,?,?,?,?)',
                       (f'capacity-{n}', 'fixture', 'storage', 'fixture', detail, time.time()-40*86400))
            db.commit()
            n += 1
        with self.assertRaises(StoragePressure):
            self.fixture.ingest(self.fixture.sample(2, []))
        self.assertEqual(self.store.latest_telemetry_for_agent('agent-one')['sequence'], 1)
        self.assertEqual(self.store.pending_telemetry_processing(), [])
        for _ in range(8):
            self.manager.maintain()
            if not self.manager.status()['telemetry_admission_paused']:
                break
        self.fixture.ingest(self.fixture.sample(2, []))
        self.assertEqual(self.store.latest_telemetry_for_agent('agent-one')['sequence'], 2)
        self.assertLessEqual(self.manager.status()['database_allocated_bytes'], self.policy.database_max_bytes)

    def test_native_free_space_floor_blocks_archive_without_losing_rows(self):
        event = self.event('disk floor')
        # The error path is deterministic; real disk size is covered in the
        # sustained process exercise without exhausting the shared host disk.
        from collections import namedtuple
        Usage = namedtuple('Usage', 'total used free')
        with patch('sentinel_blue.history_storage.shutil.disk_usage', return_value=Usage(64*MIB,63*MIB,MIB)):
            with self.assertRaises(StoragePressure):
                self.manager.maintain()
            self.assertTrue(self.manager.status()['telemetry_admission_paused'])
        self.assertIsNotNone(self.row('external_events', 'event_id', event))

    def test_current_baseline_receipt_survives_history_expiry(self):
        fixture = promotion.BaselinePromotionTests()
        fixture.setUp()
        self.addCleanup(fixture.tearDown)
        sample, approval, action = fixture._begin()
        fixture.app.complete_action(promotion.capture_result(action), 'promotion-agent')
        fixture.store.initialize_recovery_identity()
        folder = Path(fixture.directory.name) / 'history'
        folder.mkdir(mode=0o700)
        manager = HistoryStorage(fixture.store, folder, self.fixture.key, self.policy)
        before = fixture.store.latest_baseline_promotion('promotion-agent')
        with patch('sentinel_blue.history_storage.time.time', return_value=time.time()+31*86400):
            manager.maintain()
        self.assertEqual(fixture.store.latest_baseline_promotion('promotion-agent'), before)
        self.assertIsNotNone(fixture.store.get_action(action.action_id))
        self.assertEqual(fixture.store.get_baseline('promotion-agent'), sample)

    def test_backup_byte_rotation_keeps_two_verified_bundles_and_latest_anchor(self):
        folder = self.fixture.root / 'backups'
        folder.mkdir(mode=0o700)
        saved = [self.fixture.app.create_recovery_backup(folder) for _ in range(4)]
        removed = prune_recovery_backups(folder, self.fixture.anchor, self.fixture.key,
                                        keep=96, maximum_bytes=1)
        self.assertEqual(len(removed), 2)
        remaining = list(folder.glob('*.sbbackup'))
        self.assertEqual(len(remaining), 2)
        self.assertIn(Path(saved[-1]['bundle']), remaining)
        for path in remaining:
            self.assertTrue(verify_controller_backup(path, self.fixture.anchor, self.fixture.key)['verified'])

    def test_new_and_legacy_database_reclamation_modes_remain_usable(self):
        self.assertTrue(self.manager.status()['incremental_reclamation'])
        self.store._connection.execute('PRAGMA auto_vacuum=NONE')
        self.store._connection.execute('VACUUM')
        self.fixture.store.close()
        self.fixture.store = self.store = Store(self.fixture.database)
        self.manager = HistoryStorage(self.store, self.root, self.fixture.key, self.policy)
        self.assertFalse(self.manager.status()['incremental_reclamation'])
        self.event('legacy data')
        self.manager.maintain()
        self.assertEqual(self.store._connection.execute('PRAGMA integrity_check').fetchone()[0], 'ok')
        self.assertEqual(self.manager.status()['archived_records']['external_events'], 1)

    def test_invalid_policy_is_rejected(self):
        for changes in ({'retention_days': 0}, {'archive_max_files': 1000},
                        {'database_max_bytes': 0}, {'minimum_free_bytes': -1},
                        {'minimum_online_seconds': 1}, {'archive_days': True}):
            with self.assertRaises(ValueError):
                replace(self.policy, **changes)

    def test_real_held_sqlite_reader_causes_backpressure_then_checkpoint_recovers(self):
        self.event('reader control')
        reader = sqlite3.connect(self.store.path)
        self.addCleanup(reader.close)
        reader.execute('BEGIN')
        reader.execute('SELECT COUNT(*) FROM external_events').fetchone()
        payload = json.dumps({'fixture': 'w'*64000})
        for n in range(300):
            self.store._connection.execute('INSERT INTO audit_log VALUES(?,?,?,?,?,?)',
                (f'wal-{n}', 'fixture', 'reader', 'fixture', payload, time.time()-40*86400))
            self.store._connection.commit()
        self.assertIn('wal_checkpoint_waiting', self.manager.status()['reasons'])
        before = self.manager.status()['archived_records']
        self.manager.maintain()
        self.assertEqual(self.manager.status()['archived_records'], before)
        self.assertTrue(self.manager.status()['telemetry_admission_paused'])
        reader.rollback()
        self.manager.maintain()
        self.assertFalse(self.manager.status()['telemetry_admission_paused'])
        self.assertLess(self.manager.status()['wal_bytes'], self.manager.status()['wal_max_bytes'])

    def test_offline_compaction_reclaims_legacy_pages_and_preserves_recovery_identity(self):
        self.store._connection.execute('PRAGMA auto_vacuum=NONE')
        self.store._connection.execute('VACUUM')
        for n in range(100):
            self.store._connection.execute('INSERT INTO external_events VALUES(?,?,?,?,?)',
                (f'compact-{n}', 'fixture', 'x'*64000, 'info', time.time()-40*86400))
        self.store._connection.commit()
        self.manager.maintain()
        identity = self.store.recovery_identity()
        self.store.close()
        result = compact_database(self.fixture.database, self.fixture.anchor, self.fixture.key,
                                  minimum_free_bytes=8*MIB)
        self.assertTrue(result['recovery_ready'])
        self.assertLess(result['after_bytes'], result['before_bytes'])
        self.fixture.store = self.store = Store(self.fixture.database)
        self.assertEqual(self.store.recovery_identity(), identity)
        self.assertEqual(self.store._connection.execute('PRAGMA auto_vacuum').fetchone()[0], 2)

    def test_offline_compaction_refuses_an_active_controller_lock(self):
        from sentinel_blue.controller import ControllerDatabaseLock
        with ControllerDatabaseLock(self.fixture.database):
            with self.assertRaisesRegex(RuntimeError, 'already owns'):
                compact_database(self.fixture.database, self.fixture.anchor, self.fixture.key,
                                 minimum_free_bytes=8*MIB)


if __name__ == '__main__':
    unittest.main()
