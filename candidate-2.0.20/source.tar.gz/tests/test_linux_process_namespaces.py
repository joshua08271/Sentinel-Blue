"""Process numbers must refer to the caller's namespace, including collisions."""
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from sentinel_blue import collectors, process_identity as identity, bounded_capture


@unittest.skipUnless(sys.platform.startswith('linux') and hasattr(os, 'pidfd_open'), 'Linux pidfd namespace checks')
class NamespacePathTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        (self.root / 'self/fdinfo').mkdir(parents=True)
        (self.root / 'self/status').write_text('NSpid:\t9000\t20\n')
        # A parent-namespace process collides with the requested local PID.
        (self.root / '42').mkdir()
        (self.root / '9042').mkdir()
        (self.root / 'self/fdinfo/77').write_text('Pid:\t9042\nNSpid:\t9042\t42\n')
        real_path = Path
        def proc_path(value):
            value = str(value)
            return self.root / value.removeprefix('/proc/').removeprefix('/proc') if value.startswith('/proc') else real_path(value)
        self.paths = patch.object(identity, 'Path', side_effect=proc_path)
        self.paths.start(); self.addCleanup(self.paths.stop)
        real_open = open
        opened = patch.object(bounded_capture, 'open',
            side_effect=lambda path, *a, **kw: real_open(proc_path(path), *a, **kw), create=True)
        opened.start(); self.addCleanup(opened.stop)
        directories = patch.object(bounded_capture.os.path, 'isdir',
            side_effect=lambda path: proc_path(path).is_dir())
        directories.start(); self.addCleanup(directories.stop)
        self.pid = patch.object(identity.os, 'getpid', return_value=20)
        self.pid.start(); self.addCleanup(self.pid.stop)
        self.openfd = patch.object(identity.os, 'pidfd_open', return_value=77)
        self.openfd.start(); self.addCleanup(self.openfd.stop)
        self.closefd = patch.object(identity.os, 'close')
        self.closed = self.closefd.start(); self.addCleanup(self.closefd.stop)

    def test_existing_parent_pid_is_not_the_requested_process(self):
        self.assertEqual(identity._linux_proc_path(42), self.root / '9042')
        self.closed.assert_called_once_with(77)

    def test_same_inner_pid_in_a_sibling_is_not_ambiguous(self):
        (self.root / '8042').mkdir()
        (self.root / '8042/status').write_text('NSpid:\t8042\t42\n')
        self.assertEqual(identity._linux_proc_path(42), self.root / '9042')

    def test_descendant_uses_callers_depth_not_innermost_pid(self):
        (self.root / 'self/fdinfo/77').write_text('Pid:\t9042\nNSpid:\t9042\t42\t3\n')
        self.assertEqual(identity._linux_proc_path(42), self.root / '9042')

    def test_native_proc_mount_needs_no_pid_translation(self):
        (self.root / 'self/status').write_text('NSpid:\t20\n')
        self.assertEqual(identity._linux_proc_path(42), self.root / '42')
        self.closed.assert_not_called()

    def test_missing_native_process_is_not_found_in_another_namespace(self):
        (self.root / 'self/status').write_text('NSpid:\t20\n')
        with self.assertRaises(ProcessLookupError):
            identity._linux_proc_path(43)

    def test_exited_target_is_refused_and_descriptor_closed(self):
        (self.root / 'self/fdinfo/77').write_text('Pid:\t-1\nNSpid:\t-1\n')
        with self.assertRaises(ProcessLookupError):
            identity._linux_proc_path(42)
        self.closed.assert_called_once_with(77)

    def test_inconsistent_or_oversized_fdinfo_never_uses_the_collision(self):
        for content in ('Pid:\t9042\n', 'Pid:\t9042\nNSpid:\t8042\t42\n',
                        'Pid:\t9042\nNSpid:\t9042\t43\n',
                        'Pid:\t9042\nPid:\t42\nNSpid:\t9042\t42\n',
                        'Pid:\t0\nNSpid:\t0\t42\n', 'x' * 65537):
            with self.subTest(content=content[:80]):
                (self.root / 'self/fdinfo/77').write_text(content)
                with self.assertRaises(OSError):
                    identity._linux_proc_path(42)

    def test_unknown_caller_namespace_fails_closed(self):
        (self.root / 'self/status').write_text('NSpid:\t9000\t21\n')
        with self.assertRaises(OSError):
            identity._linux_proc_path(42)

    def test_pidfd_access_failure_is_not_bypassed(self):
        with patch.object(identity.os, 'pidfd_open', side_effect=PermissionError('denied')):
            with self.assertRaises(PermissionError):
                identity._linux_proc_path(42)


@unittest.skipUnless(sys.platform.startswith('linux') and hasattr(os, 'pidfd_open'), 'Linux pidfd required')
class RealNamespaceTests(unittest.TestCase):
    def setUp(self):
        self.child = subprocess.Popen([sys.executable, '-c',
            'import os,time; print(os.getpid(),flush=True); time.sleep(60)'],
            stdout=subprocess.PIPE, text=True)
        self.addCleanup(self.cleanup_child)
        self.assertEqual(int(self.child.stdout.readline()), self.child.pid)

    def cleanup_child(self):
        if self.child.poll() is None:
            self.child.terminate()
        self.child.wait(5)
        self.child.stdout.close()

    def test_real_child_identity_uses_its_actual_executable(self):
        observed = identity.inspect_process_identity(self.child.pid)
        executable = os.stat(sys.executable)
        self.assertEqual(observed['process_id'], self.child.pid)
        self.assertEqual(observed['executable_file_id'],
                         f'dev:{executable.st_dev:x}:ino:{executable.st_ino:x}')

    def test_inventory_uses_the_same_pid_and_parent_as_subprocess(self):
        errors = []
        rows = collectors._linux_processes(errors)
        matches = [row for row in rows if row.process_id == self.child.pid]
        self.assertEqual(len(matches), 1, errors)
        self.assertEqual(matches[0].parent_id, os.getpid())
        self.assertEqual(Path(matches[0].path).resolve(), Path(sys.executable).resolve())


if __name__ == '__main__':
    unittest.main()
