import copy
import hashlib
import tempfile
import unittest
from pathlib import Path

from sentinel_blue.event_profile import EventProfile
from sentinel_blue.network_setup import normalize, ruleset
from sentinel_blue.protocol import ProbeResult
from sentinel_blue.setup import compile_plan, plan_digest, SetupRunner
from sentinel_blue.setup_recipes import compile_recipe
from sentinel_blue.setup_transport import CommandResult
from tests.test_setup import fixture, FixtureTransport


class ConfigurationBoundaryTests(unittest.TestCase):
    def test_router_rejects_unbounded_or_ambiguous_configuration(self):
        original = {'name': 'competition', 'management': [{'source': '10.0.0.0/24', 'port': 22}]}
        for change in ({'name': 'router;reboot'}, {'management': []}, {'rollback_seconds': 0},
            {'routes': [{'destination': '0.0.0.0/0', 'via': '10.0.0.1', 'interface': 'eth0'}]},
            {'addresses': [{'address': '::1/128', 'interface': 'eth0'}]},
            {'forwarding': False, 'masquerade': [{'source': '10.0.0.0/24', 'out_interface': 'eth0'}]}):
            with self.subTest(change=change), self.assertRaises(ValueError):
                normalize(original | change)

    def test_router_setup_requires_native_manifest_management_and_downstream_evidence(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            inventory, profile = fixture(root, hosts=1)
            raw = copy.deepcopy(profile.raw)
            raw['services'][0]['service_id'] = 'sentinel-router-test'
            inventory['setup']['tasks'][0].update(recipe='linux-router', service_id='sentinel-router-test',
                options={'name': 'test', 'management': [{'source': '127.0.0.0/8', 'port': 22}]})
            with self.assertRaisesRegex(ValueError, 'management connection'):
                compile_plan(inventory, EventProfile.from_dict(raw), root)
            raw['services'][0]['expected_transactions'].append({'kind': 'tcp', 'target': '127.0.0.1', 'port': 22})
            inventory['setup']['tasks'][0]['options']['routes'] = [{'destination': '10.1.0.0/24', 'via': '127.0.0.2', 'interface': 'eth0'}]
            with self.assertRaisesRegex(ValueError, 'downstream'):
                compile_plan(inventory, EventProfile.from_dict(raw), root)
            inventory['setup']['tasks'][0]['options'].pop('routes')
            plan = compile_plan(inventory, EventProfile.from_dict(raw), root)
            self.assertTrue(plan['tasks'][0]['commit'])
            self.assertTrue(plan['tasks'][0]['rollback'])

    def test_application_content_digest_and_platform_are_enforced(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root/'index.html').write_text('scored content')
            options = {'name': 'score', 'listen_address': '127.0.0.1', 'port': 8080,
                       'content': {'path': 'index.html', 'sha256': 'a'*64}}
            for recipe, platform in (('linux-nginx', 'linux'), ('windows-iis', 'windows')):
                with self.assertRaisesRegex(ValueError, 'checksum'):
                    compile_recipe(recipe, options, root, platform)
            options['content']['sha256'] = hashlib.sha256(b'scored content').hexdigest()
            with self.assertRaisesRegex(ValueError, 'platform'):
                compile_recipe('linux-nginx', options, root, 'windows')
            for recipe, platform in (('linux-nginx', 'linux'), ('windows-iis', 'windows')):
                check, apply, _ = compile_recipe(recipe, options, root, platform)
                self.assertTrue(check and apply)

    def test_firewall_rejects_commands_and_non_network_sources(self):
        for allow in ([{'source': 'example.org', 'protocol': 'tcp', 'port': 8080}],
                      [{'source': '10.0.0.0/24', 'protocol': 'tcp;exit', 'port': 8080}],
                      [{'source': '10.0.0.0/24', 'protocol': 'tcp', 'port': True}]):
            with self.assertRaises(ValueError):
                compile_recipe('windows-firewall', {'name': 'score', 'allow': allow}, Path.cwd(), 'windows')


class ConfirmationSchedulerTests(unittest.TestCase):
    def run_scenario(self, healthy):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            inventory, profile = fixture(root, hosts=1, budget=4)
            plan = compile_plan(inventory, profile, root)
            task = plan['tasks'][0]
            task.update(commit='CONFIRM', rollback='ROLLBACK', health_wait_seconds=1.2)
            class Transport(FixtureTransport):
                def __init__(self):
                    super().__init__()
                    self.confirmed = 0
                    self.rolled_back = 0
                def execute(self, host, script, seconds):
                    if script == 'CONFIRM':
                        self.confirmed += 1
                        return CommandResult(0, 0)
                    if script == 'ROLLBACK':
                        self.rolled_back += 1
                        self.ready.discard(host['name'])
                        return CommandResult(0, 0)
                    return super().execute(host, script, seconds)
            transport = Transport()
            probes = []
            def probe(*args, **kwargs):
                passed = healthy and bool(transport.ready)
                probes.append(passed)
                return ProbeResult('content', 'http://127.0.0.1:8080/', passed, 1)
            result = SetupRunner(plan, profile, transport=transport, probe=probe).execute(root/'state', plan_digest(plan))
            return result, transport, probes

    def test_external_failure_rolls_back_and_never_confirms(self):
        result, transport, _ = self.run_scenario(False)
        self.assertNotEqual(result['status'], 'ready')
        self.assertEqual(transport.confirmed, 0)
        self.assertEqual(transport.rolled_back, 1)

    def test_confirmation_requires_repeated_healthy_observations(self):
        result, transport, probes = self.run_scenario(True)
        self.assertEqual(result['status'], 'ready', result)
        self.assertEqual(transport.confirmed, 1)
        self.assertGreaterEqual(probes.count(True), 2)
        self.assertEqual(transport.rolled_back, 0)


if __name__ == '__main__':
    unittest.main()
