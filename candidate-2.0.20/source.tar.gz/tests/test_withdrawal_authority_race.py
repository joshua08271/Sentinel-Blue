"""A controller restart cannot invalidate a paused withdrawal review."""
import copy
import threading
import unittest
from unittest.mock import patch

from sentinel_blue.offline_continuity import AgentContinuity, ControllerContinuity
import test_offline_authority as authority_fixtures


class WithdrawalAuthorityRaceTests(unittest.TestCase):
    setUp = authority_fixtures.OfflineAuthorityTests.setUp

    def test_withdrawal_blocks_refresh_before_network_request(self):
        self.app.continuity = ControllerContinuity(self.app)
        authority = copy.deepcopy(self.agent.state['authority'])
        saved = self.agent.path.read_bytes()
        self.ledger.pause('withdraw-before-sync')
        head = self.ledger.head()
        self.client.reset_mock()
        with self.assertRaisesRegex(ValueError, 'Withdraw'):
            self.agent.sync(self.client, self.journal)
        self.client._request.assert_not_called()
        self.assertFalse(self.agent.online)
        self.assertEqual(self.agent.state['authority'], authority)
        self.assertEqual(self.agent.path.read_bytes(), saved)
        self.assertEqual(self.ledger.head(), head)

    def test_withdrawal_during_request_rejects_late_controller_authority(self):
        self.app.continuity = ControllerContinuity(self.app)
        saved = self.agent.path.read_bytes()
        authority = copy.deepcopy(self.agent.state['authority'])
        paused = {}
        def request(method, path, body):
            response = self.app.continuity.sync('agent-one', body)
            paused.update(self.ledger.pause('withdraw-during-request'))
            return response
        self.client._request.side_effect = request
        with self.assertRaisesRegex(ValueError, 'Withdraw'):
            self.agent.sync(self.client, self.journal)
        self.assertFalse(self.agent.online)
        self.assertEqual(self.ledger.head(), paused['head'])
        self.assertEqual(self.agent.path.read_bytes(), saved)
        reopened = AgentContinuity(self.root, self.profile, 'agent-one', self.token, ledger=self.ledger)
        self.assertEqual(reopened.state['authority'], authority)

    def test_pause_drains_admitted_authority_state_flush(self):
        self.app.continuity = ControllerContinuity(self.app)
        entered, release, paused = threading.Event(), threading.Event(), threading.Event()
        errors, results = [], []
        save = self.agent._save
        def held_save():
            entered.set()
            if not release.wait(5):
                raise RuntimeError('Fixture did not release state flush')
            save()
        def sync():
            try:
                self.agent.sync(self.client, self.journal)
            except BaseException as error:
                errors.append(error)
        def pause():
            try:
                results.append(self.ledger.pause('drain-authority-flush'))
            except BaseException as error:
                errors.append(error)
            finally:
                paused.set()
        writer = threading.Thread(target=sync)
        pauser = threading.Thread(target=pause)
        with patch.object(self.agent, '_save', side_effect=held_save):
            try:
                writer.start()
                self.assertTrue(entered.wait(3))
                pauser.start()
                self.assertFalse(paused.wait(.15), 'Pause returned before admitted state was durable')
            finally:
                release.set()
                writer.join(5)
                if pauser.ident is not None:
                    pauser.join(5)
        self.assertEqual(errors, [])
        self.assertFalse(writer.is_alive())
        self.assertFalse(pauser.is_alive())
        self.assertEqual(self.ledger.head(), results[0]['head'])
        reopened = AgentContinuity(self.root, self.profile, 'agent-one', self.token, ledger=self.ledger)
        self.assertEqual(reopened.state['authority'], self.app.continuity.authority)
        self.assertTrue(self.ledger.paused())


if __name__ == '__main__':
    unittest.main()
