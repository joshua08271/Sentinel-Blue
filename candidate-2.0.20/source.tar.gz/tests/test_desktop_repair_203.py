"""2.0.3 desktop controls: grant repair to a profile, and see or start a setup redo."""
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from sentinel_blue.state import write_private_json
from test_repair_grants_203 import written_without_repair


@unittest.skipUnless(os.environ.get("DISPLAY") and sys.platform.startswith("linux"), "Linux graphical session required")
class DesktopRepairControls(unittest.TestCase):
    def setUp(self):
        import tkinter as tk
        from sentinel_blue.desktop import DesktopWindow
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root_dir = Path(temp.name)
        self.tk_root = tk.Tk()
        self.addCleanup(self.tk_root.destroy)
        with patch("sentinel_blue.linux_workspace.local_observation",
                   return_value={"observation": None, "presence": {}}):
            self.window = DesktopWindow(self.tk_root, directory=self.root_dir / "desktop")
        self.window.notify.set(False)
        self.addCleanup(self.window.worker_stop.set)

    def test_grant_writes_a_new_profile_and_uses_it(self):
        raw, _ = written_without_repair()
        source = self.root_dir / "event.json"
        source.write_text(json.dumps(raw))
        original = source.read_bytes()
        self.window.profile_path.set(str(source))
        with patch.object(self.window.messagebox, "askyesnocancel", return_value=False):
            self.window.grant_profile_repair()
        granted = self.root_dir / "event.repair.json"
        self.assertTrue(granted.is_file())
        self.assertEqual(source.read_bytes(), original)
        self.assertEqual(self.window.profile_path.get(), str(granted))
        report = self.window.setup_text.get("1.0", "end")
        self.assertIn("Repair granted to 1 service(s)", report)
        self.assertIn("review the setup plan again", report)
        self.assertEqual(str(self.window.start_setup.cget("state")), "disabled")

    def test_cancel_changes_nothing(self):
        raw, _ = written_without_repair()
        source = self.root_dir / "event.json"
        source.write_text(json.dumps(raw))
        self.window.profile_path.set(str(source))
        with patch.object(self.window.messagebox, "askyesnocancel", return_value=None):
            self.window.grant_profile_repair()
        self.assertFalse((self.root_dir / "event.repair.json").exists())
        self.assertEqual(self.window.profile_path.get(), str(source))

    def test_recovery_shows_redo_status_for_the_local_session(self):
        workspace = self.root_dir / "session"
        workspace.mkdir()
        self.window.local_workspace = {"directory": str(workspace), "event_profile": str(workspace / "profile.json")}
        snapshot = {"controller": {"governance": {}, "service_recovery_status": []}, "service_health": [
            {"agent_id": "local-linux", "service": "web.service", "health": "healthy", "native_state": "running",
             "passed_checks": 1, "expected_checks": 1}]}
        self.window.render(snapshot)
        self.assertIn("no approved local setup", self.window.redo_status.get())
        self.window.client = None
        self.window.redo_local_setup()
        self.assertIn("Reconnect the local session", self.window.footer.get())


if __name__ == "__main__":
    unittest.main()
