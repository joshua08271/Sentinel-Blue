"""2.0.7 independent-review regressions: real private files, SQLite and local DNS.

Service observations, clocks and setup-job launches are modeled explicitly;
these tests neither configure native services nor contact remote hosts.
"""
import copy
import hashlib
import json
import os
from pathlib import Path
import socket
import struct
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

from sentinel_blue.restoration import RestorePointStore
from sentinel_blue.telemetry_diagnostics import restore_point_issues
from sentinel_blue import setup_redo
from sentinel_blue.linux_workspace import config_files, default_probe
from sentinel_blue.probes import _dns_response_answers, _dns_exact_answers, _dns_query


def digest(data):
    return hashlib.sha256(data).hexdigest()


@unittest.skipUnless(os.name == 'posix', 'POSIX metadata replicas')
class Manifest207(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory(prefix='sb207-manifest-'); self.addCleanup(tmp.cleanup)
        self.root = Path(tmp.name)
        self.path = self.root/'web.conf'; self.path.write_bytes(b'trusted'); self.path.chmod(0o600)
        self.store = RestorePointStore(self.root/'state', mirror=self.root/'ledger/restore-mirror')
        self.item = self.record()
        self.assertTrue(self.store.capture([self.item])['success'])
        self.auth = self.store._manifest_authority

    def record(self):
        data, meta = self.store._read_target(self.path)
        return {'path': str(self.path), 'sha256': digest(data),
                'security_descriptor_sha256': self.store._metadata_security_descriptor_sha256(meta)}

    def damage(self):
        (self.store.blobs/self.item['sha256']).unlink()
        self.path.write_bytes(b'changed'); self.path.chmod(0o644)

    def restore(self):
        now = self.record()
        return self.store.restore({'path':str(self.path), 'sha256':self.item['sha256'],
                    'observed_sha256':now['sha256'],
                    'baseline_security_descriptor_sha256':self.item['security_descriptor_sha256'],
                    'observed_security_descriptor_sha256':now['security_descriptor_sha256']}, allowed=True)

    def test_deleted_manifest_rebuilds_metadata_bytes_and_permissions(self):
        self.damage(); self.store.manifest_path.unlink()
        report = self.store.audit_backups()
        self.assertIn(str(self.path), report['rebuilt'])
        self.assertIn(str(self.store.manifest_path), report['rebuilt'])
        self.assertTrue(restore_point_issues(report))
        self.assertTrue(self.restore()['success'])
        self.assertEqual(self.path.read_bytes(), b'trusted')
        self.assertEqual(self.path.stat().st_mode & 0o777, 0o600)

    def test_corrupt_manifest_is_preserved_and_recovered(self):
        self.damage(); self.store.manifest_path.write_bytes(b'{broken')
        self.assertFalse(self.store.audit_backups()['lost'])
        saved = self.store.evidence/('manifest-damaged-'+digest(b'{broken'))
        self.assertEqual(saved.read_bytes(), b'{broken')
        self.assertTrue(self.restore()['success'])

    def test_primary_tamper_never_becomes_approved(self):
        primary = json.loads(self.store.manifest_path.read_text())
        primary[str(self.path)]['mode'] = 0o777
        self.store.manifest_path.write_text(json.dumps(primary))
        self.assertEqual(self.store._read_manifest()[str(self.path)]['mode'],0o600)

    def test_missing_primary_and_local_auth_recover_after_object_restart(self):
        self.damage(); self.store.manifest_path.unlink(); self.auth.local.unlink()
        self.store = RestorePointStore(self.root/'state', mirror=self.root/'ledger/restore-mirror')
        self.assertFalse(self.store.audit_backups()['lost'])
        self.assertTrue(self.restore()['success'])

    def test_remote_copy_can_be_rebuilt_from_local(self):
        self.auth.remote.unlink()
        report=self.store.audit_backups()
        self.assertTrue(report['rebuilt']);self.assertTrue(self.auth.remote.is_file())
        self.assertEqual(self.auth.local.read_bytes(),self.auth.remote.read_bytes())

    def test_corrupt_local_auth_is_rebuilt_from_remote(self):
        self.auth.local.write_bytes(b'{')
        self.assertFalse(self.store.audit_backups()['lost'])
        self.assertEqual(self.auth.local.read_bytes(),self.auth.remote.read_bytes())

    def test_corrupt_remote_auth_is_rebuilt_from_local(self):
        self.auth.remote.write_bytes(b'{')
        self.assertFalse(self.store.audit_backups()['lost'])
        self.assertEqual(self.auth.local.read_bytes(),self.auth.remote.read_bytes())

    def test_missing_both_auth_copies_warns_and_preserves_live_file(self):
        self.damage(); self.auth.local.unlink(); self.auth.remote.unlink()
        self.assertIn(str(self.store.manifest_path),self.store.audit_backups()['lost'])
        with self.assertRaisesRegex(ValueError,'authenticated'): self.restore()
        self.assertEqual(self.path.read_bytes(),b'changed')

    def test_invalid_mac_in_both_copies_holds(self):
        bad = json.loads(self.auth.remote.read_bytes());bad['body']['manifest'][str(self.path)]['mode']=0o777
        for p in (self.auth.local,self.auth.remote):p.write_text(json.dumps(bad))
        self.assertTrue(self.store.audit_backups()['lost'])

    def test_deleted_key_is_not_recreated(self):
        self.auth.key_path.unlink();report=self.store.audit_backups()
        self.assertTrue(report['lost']);self.assertFalse(self.auth.key_path.exists())
        with self.assertRaises(ValueError):self.store.capture([self.item])
        self.assertFalse(self.auth.key_path.exists())

    def test_corrupt_key_does_not_reapprove_primary(self):
        self.auth.key_path.write_bytes(b'x'*32)
        self.assertTrue(self.store.audit_backups()['lost'])
        with self.assertRaises(ValueError):self.store.capture([self.item])

    def test_unsafe_key_permissions_are_rejected(self):
        self.auth.key_path.chmod(0o644)
        self.assertTrue(self.store.audit_backups()['lost'])

    def test_key_link_is_not_followed(self):
        outside=self.root/'outside';outside.write_bytes(b'outside')
        self.auth.key_path.unlink();self.auth.key_path.symlink_to(outside)
        self.assertTrue(self.store.audit_backups()['lost']);self.assertEqual(outside.read_bytes(),b'outside')

    def test_manifest_symlink_is_not_overwritten(self):
        outside=self.root/'outside';outside.write_bytes(b'outside')
        self.store.manifest_path.unlink();self.store.manifest_path.symlink_to(outside)
        self.assertTrue(self.store.audit_backups()['lost'])
        self.assertEqual(outside.read_bytes(),b'outside');self.assertTrue(self.store.manifest_path.is_symlink())

    def test_replayed_old_signed_generation_is_refused(self):
        old=self.auth.local.read_bytes()
        self.assertTrue(self.store.capture([self.item])['success'])
        self.auth.local.write_bytes(old);self.auth.remote.write_bytes(old)
        self.assertTrue(self.store.audit_backups()['lost'])

    def test_scope_blocks_copy_from_another_store(self):
        other=RestorePointStore(self.root/'other',mirror=self.root/'ledger/restore-mirror')
        self.assertTrue(other.capture([self.item])['success'])
        for p in (self.auth.local,self.auth.remote):p.write_bytes(other._manifest_authority.remote.read_bytes())
        self.assertTrue(self.store.audit_backups()['lost'])

    def test_corrupt_floor_cannot_downgrade_authority(self):
        self.auth.floor.write_bytes(b'{')
        self.assertTrue(self.store.audit_backups()['lost'])

    def test_interrupted_remote_publication_completes_on_retry(self):
        save=self.auth._save
        def fail_remote(path,data):
            if path == self.auth.remote:raise OSError('modeled publication fault')
            return save(path,data)
        with patch.object(self.auth,'_save',side_effect=fail_remote),self.assertRaises(OSError):
            self.store.capture([self.item])
        self.assertFalse(self.store.audit_backups()['lost'])
        self.assertEqual(self.auth.local.read_bytes(),self.auth.remote.read_bytes())
        self.assertTrue(self.store.capture([self.item])['success'])

    def test_interrupted_primary_publication_completes_from_signed_state(self):
        save=self.auth._save
        def fail_primary(path,data):
            if path == self.store.manifest_path:raise OSError('modeled publication fault')
            return save(path,data)
        with patch.object(self.auth,'_save',side_effect=fail_primary),self.assertRaises(OSError):
            self.store.capture([self.item])
        self.assertFalse(self.store.audit_backups()['lost'])
        self.assertTrue(self.store.capture([self.item])['success'])

    def test_simultaneous_store_capture_cannot_overwrite_new_generation(self):
        old=self.store._read_manifest()
        other=RestorePointStore(self.root/'state',mirror=self.root/'ledger/restore-mirror')
        self.assertTrue(other.capture([self.item])['success'])
        with self.assertRaisesRegex(ValueError,'changed during capture'):
            self.store._write_manifest(old,captured=[str(self.path)])

    def test_legacy_manifest_not_silently_authenticated(self):
        raw=self.store.manifest_path.read_bytes()
        legacy=RestorePointStore(self.root/'legacy')
        legacy.manifest_path.write_bytes(raw);legacy.manifest_path.chmod(0o600)
        report=legacy.audit_backups()
        self.assertTrue(report['metadata_notices'])
        self.assertFalse(legacy._manifest_authority.key_path.exists())
        self.assertTrue(legacy.capture([self.item])['success'])
        self.assertTrue(legacy._manifest_authority.key_path.exists())

    def test_missing_unsigned_manifest_with_existing_blobs_is_not_empty_healthy(self):
        legacy=RestorePointStore(self.root/'legacy')
        (legacy.blobs/self.item['sha256']).write_bytes(b'trusted')
        self.assertTrue(legacy.audit_backups()['lost'])

    def test_corrupt_unsigned_manifest_holds_even_explicit_capture(self):
        legacy=RestorePointStore(self.root/'legacy')
        legacy.manifest_path.write_bytes(b'{');legacy.manifest_path.chmod(0o600)
        self.assertTrue(legacy.audit_backups()['lost'])
        with self.assertRaises(ValueError):legacy.capture([self.item])

    def test_empty_never_captured_store_has_no_loss_warning(self):
        fresh=RestorePointStore(self.root/'fresh')
        self.assertEqual(fresh.audit_backups(),{'rebuilt':[],'lost':[]})

    def test_no_live_content_recapture_on_metadata_loss(self):
        self.damage();self.store.manifest_path.unlink()
        self.store.audit_backups()
        record=self.store._read_manifest()[str(self.path)]
        self.assertEqual(record['sha256'],self.item['sha256']);self.assertEqual(record['mode'],0o600)

    def test_metadata_is_private_and_not_configuration_ledger_mutation(self):
        from sentinel_blue import mutation_tracking
        with patch.object(mutation_tracking,'_ENABLED',True), patch.object(mutation_tracking,'mutation') as mutate:
            self.auth._save(self.auth.remote,self.auth.local.read_bytes())
        mutate.assert_not_called()
        for p in (self.auth.local,self.auth.remote,self.auth.key_path,self.auth.floor,self.auth.marker):
            self.assertEqual(p.stat().st_mode & 0o777,0o600)
        self.assertEqual(self.auth.directory.stat().st_mode & 0o777,0o700)

    def test_metadata_loss_generates_bounded_valid_telemetry(self):
        from test_autonomous_service_recovery import fixtures
        from sentinel_blue.telemetry_diagnostics import merge_health_diagnostics
        from sentinel_blue.validation import validate_telemetry
        self.auth.key_path.unlink()
        _,value=fixtures();merge_health_diagnostics(value,restore_point_issues(self.store.audit_backups()))
        valid=validate_telemetry(value)
        self.assertTrue(any('restore point lost:' in error for error in valid['collector_errors']))
        self.assertEqual(len(valid['collector_errors']),len(valid['collector_issue_sources']))

    def test_posix_xattr_preserved_with_recovered_manifest(self):
        if not hasattr(os,'setxattr'):self.skipTest('POSIX xattrs unavailable')
        os.setxattr(self.path,'user.sb207',b'approved')
        self.item=self.record();self.assertTrue(self.store.capture([self.item])['success'])
        self.damage();os.setxattr(self.path,'user.sb207',b'changed');self.store.manifest_path.unlink()
        self.assertFalse(self.store.audit_backups()['lost'])
        self.assertTrue(self.restore()['success']);self.assertEqual(os.getxattr(self.path,'user.sb207'),b'approved')

    def test_entire_session_restore_directory_loss_recovers_from_independent_metadata(self):
        import shutil
        self.path.write_bytes(b'changed'); self.path.chmod(0o644)
        shutil.rmtree(self.store.root)
        self.store = RestorePointStore(self.root/'state', mirror=self.root/'ledger/restore-mirror')
        report = self.store.audit_backups()
        self.assertFalse(report['lost']); self.assertIn(str(self.path), report['rebuilt'])
        self.assertTrue(self.restore()['success'])
        self.assertEqual(self.path.read_bytes(), b'trusted')
        self.assertEqual(self.path.stat().st_mode & 0o777, 0o600)

    def test_oversized_authenticated_copy_holds_without_unbounded_read(self):
        from sentinel_blue.restore_manifest import ENVELOPE_BYTES
        with self.auth.local.open('r+b') as stream: stream.truncate(ENVELOPE_BYTES + 1)
        self.assertTrue(self.store.audit_backups()['lost'])
        self.assertEqual(self.path.read_bytes(), b'trusted')

    def test_interrupted_floor_publication_completes_on_retry(self):
        save=self.auth._save
        def fail_floor(path,data):
            if path == self.auth.floor: raise OSError('modeled floor publication fault')
            return save(path,data)
        with patch.object(self.auth,'_save',side_effect=fail_floor),self.assertRaises(OSError):
            self.store.capture([self.item])
        self.assertFalse(self.store.audit_backups()['lost'])
        self.assertEqual(self.auth.local.read_bytes(),self.auth.remote.read_bytes())
        self.assertTrue(self.store.capture([self.item])['success'])


class Closure207(unittest.TestCase):
    def setUp(self):
        from sentinel_blue.controller import ControllerApp
        from sentinel_blue.store import Store
        from test_service_repair import repair_fixture
        from test_store_controller import _promote_integrity_baseline
        tmp=tempfile.TemporaryDirectory(prefix='sb207-close-');self.addCleanup(tmp.cleanup)
        self.path=Path(tmp.name)/'web.conf';self.path.write_bytes(b'trusted');self.path.chmod(0o600)
        profile,self.baseline=repair_fixture(str(self.path))
        self.db=Store(':memory:');self.addCleanup(self.db.close)
        self.app=ControllerApp(self.db,'t'*32,operator_token='o'*32,event_profile=profile)
        self.app.ingest(self.baseline);_promote_integrity_baseline(self.app,self.db,'agent-one')
        self.path.chmod(0o644);self.current=self.observation();self.app.ingest(self.current)
        self.assertTrue(any(x['kind']=='critical_file_changed' and x['status']=='open' for x in self.db.dashboard()['alerts']))

    def observation(self):
        value=copy.deepcopy(self.baseline);value.update(sequence=2,observed_at=time.time())
        data,meta=RestorePointStore._read_target(self.path)
        value['integrity'][0].update(sha256=digest(data),security_descriptor_sha256=RestorePointStore._metadata_security_descriptor_sha256(meta))
        return value

    def close(self,value=None):
        if value is not None:
            with patch.object(self.db,'latest_telemetry_for_agent',return_value=value):
                return self.app.close_recovered_incident('agent-one','web.service','setup_redo')
        return self.app.close_recovered_incident('agent-one','web.service','setup_redo')

    def good(self):
        self.path.chmod(0o600);return self.observation()

    def test_permission_only_change_stays_open(self):self.assertEqual(self.close()['closed'],0)
    def test_verified_permission_restoration_closes(self):
        value=self.good();value['sequence']=3;self.app.ingest(value)
        self.assertEqual(self.close()['closed'],1)
    def test_stale_sample_does_not_close(self):
        value=self.good();value['observed_at']=time.time()-500;self.assertEqual(self.close(value)['closed'],0)
    def test_future_sample_does_not_close(self):
        value=self.good();value['observed_at']=time.time()+500;self.assertEqual(self.close(value)['closed'],0)
    def test_missing_baseline_file_does_not_close(self):
        value=self.good();before=copy.deepcopy(self.baseline);before['integrity']=[]
        with patch.object(self.db,'get_baseline',return_value=before):self.assertEqual(self.close(value)['closed'],0)
    def test_missing_current_file_does_not_close(self):
        value=self.good();value['integrity']=[];self.assertEqual(self.close(value)['closed'],0)
    def test_duplicate_current_file_does_not_close(self):
        value=self.good();value['integrity']*=2;self.assertEqual(self.close(value)['closed'],0)
    def test_unreadable_file_does_not_close(self):
        value=self.good();value['integrity'][0]['readable']=False;self.assertEqual(self.close(value)['closed'],0)
    def test_missing_security_evidence_does_not_close(self):
        value=self.good();value['integrity'][0]['security_descriptor_sha256']='';self.assertEqual(self.close(value)['closed'],0)
    def test_duplicate_probe_does_not_close(self):
        value=self.good();value['probes']*=2;self.assertEqual(self.close(value)['closed'],0)
    def test_probe_not_executed_does_not_close(self):
        value=self.good();value['probes'][0]['executed']=False;self.assertEqual(self.close(value)['closed'],0)
    def test_disabled_service_does_not_close(self):
        value=self.good();value['services'][0]['start_mode']='disabled';self.assertEqual(self.close(value)['closed'],0)
    def test_duplicate_service_does_not_close(self):
        value=self.good();value['services']*=2;self.assertEqual(self.close(value)['closed'],0)
    def test_incomplete_collector_sample_does_not_close(self):
        value=self.good();value['collector_errors']=['read failed'];self.assertEqual(self.close(value)['closed'],0)

    def test_two_empty_legacy_security_fields_are_not_proof(self):
        value=self.good(); before=copy.deepcopy(self.baseline)
        value['integrity'][0]['security_descriptor_sha256']=''
        before['integrity'][0]['security_descriptor_sha256']=''
        with patch.object(self.db,'get_baseline',return_value=before):
            self.assertEqual(self.close(value)['closed'],0)

    def test_malformed_equal_security_fields_are_not_proof(self):
        value=self.good(); before=copy.deepcopy(self.baseline)
        value['integrity'][0]['security_descriptor_sha256']='not-a-hash'
        before['integrity'][0]['security_descriptor_sha256']='not-a-hash'
        with patch.object(self.db,'get_baseline',return_value=before):
            self.assertEqual(self.close(value)['closed'],0)


def dns_name(name):
    return b''.join(bytes([len(x)])+x.encode() for x in name.split('.'))+b'\0' if name else b'\0'

def rr(name,kind,data,klass=1):
    return dns_name(name)+struct.pack('!HHIH',kind,klass,60,len(data))+data

def packet(records,*,qtype=1,query='lab.test',authority=(),extra=(),flags=0x8180):
    return (struct.pack('!HHHHHH',77,flags,1,len(records),len(authority),len(extra))
            +dns_name(query)+struct.pack('!HH',qtype,1)+b''.join([*records,*authority,*extra]))


class DNS207(unittest.TestCase):
    def good(self):return rr('lab.test',1,socket.inet_aton('192.0.2.10'))
    def parse(self,value,qtype=1):
        return _dns_response_answers(value,'lab.test',qtype,struct.unpack('!H',value[6:8])[0])
    def test_header_without_records_fails(self):
        with self.assertRaises(RuntimeError):self.parse(struct.pack('!HHHHHH',77,0x8180,1,1,0,0))
    def test_question_without_answer_fails(self):
        with self.assertRaises(RuntimeError):self.parse(packet([self.good()])[:-len(self.good())])
    def test_valid_a_no_expected_list_is_parsed(self):self.assertEqual(self.parse(packet([self.good()])),{'192.0.2.10'})
    def test_valid_exact_a_passes(self):_dns_exact_answers(packet([self.good()]),'lab.test',1,1,['192.0.2.10'])
    def test_wrong_exact_answer_fails(self):
        with self.assertRaises(RuntimeError):_dns_exact_answers(packet([self.good()]),'lab.test',1,1,['192.0.2.11'])
    def test_wrong_question_fails(self):
        with self.assertRaises(RuntimeError):self.parse(packet([self.good()],query='other.test'))
    def test_wrong_class_not_an_answer(self):
        with self.assertRaises(RuntimeError):self.parse(packet([rr('lab.test',1,b'\x01\x02\x03\x04',klass=3)]))
    def test_wrong_owner_not_an_answer(self):
        with self.assertRaises(RuntimeError):self.parse(packet([rr('other.test',1,b'\x01\x02\x03\x04')]))
    def test_wrong_type_not_an_answer(self):
        with self.assertRaises(RuntimeError):self.parse(packet([rr('lab.test',16,b'\x01x')]))
    def test_truncated_address_fails(self):
        with self.assertRaises(RuntimeError):self.parse(packet([rr('lab.test',1,b'\x01\x02\x03')]))
    def test_truncated_authority_fails(self):
        with self.assertRaises(RuntimeError):self.parse(packet([self.good()],authority=[rr('test',2,dns_name('ns.test'))])[:-2])
    def test_truncated_additional_fails(self):
        with self.assertRaises(RuntimeError):self.parse(packet([self.good()],extra=[self.good()])[:-2])
    def test_trailing_undeclared_bytes_fail(self):
        with self.assertRaises(RuntimeError):self.parse(packet([self.good()])+b'x')
    def test_record_budget_is_bounded(self):
        value=bytearray(packet([self.good()]));value[10:12]=struct.pack('!H',65535)
        with self.assertRaises(RuntimeError):self.parse(bytes(value))
    def test_compressed_answer_owner_passes(self):
        value=packet([b'\xc0\x0c'+struct.pack('!HHIH',1,1,60,4)+socket.inet_aton('192.0.2.10')])
        self.assertEqual(self.parse(value),{'192.0.2.10'})
    def test_forward_name_pointer_fails(self):
        value=packet([b'\xc0\xff'+struct.pack('!HHIH',1,1,60,4)+socket.inet_aton('192.0.2.10')])
        with self.assertRaises(RuntimeError):self.parse(value)
    def test_cname_chain_passes(self):
        value=packet([rr('lab.test',5,dns_name('alias.test')),rr('alias.test',1,socket.inet_aton('192.0.2.10'))])
        self.assertEqual(self.parse(value),{'192.0.2.10'})
    def test_cname_cycle_fails(self):
        value=packet([rr('lab.test',5,dns_name('a.test')),rr('a.test',5,dns_name('lab.test'))])
        with self.assertRaises(RuntimeError):self.parse(value)
    def test_cname_conflicting_data_fails(self):
        with self.assertRaises(RuntimeError):self.parse(packet([rr('lab.test',5,dns_name('a.test')),self.good()]))
    def test_cname_without_requested_type_fails(self):
        with self.assertRaises(RuntimeError):self.parse(packet([rr('lab.test',5,dns_name('a.test'))]))
    def test_aaaa_ptr_mx_txt_are_validated(self):
        for kind,data in [(28,socket.inet_pton(socket.AF_INET6,'2001:db8::10')),(12,dns_name('host.test')),
                          (15,struct.pack('!H',10)+dns_name('mail.test')),(16,b'\x03abc\x01d')]:
            with self.subTest(kind=kind):self.assertTrue(self.parse(packet([rr('lab.test',kind,data)],qtype=kind),kind))
    def test_invalid_txt_fails(self):
        with self.assertRaises(RuntimeError):self.parse(packet([rr('lab.test',16,b'\x03ab')],qtype=16),16)
    def test_valid_authority_and_opt_pass(self):
        value=packet([self.good()],authority=[rr('test',2,dns_name('ns.test'))],extra=[rr('',41,b'',klass=4096)])
        self.assertTrue(self.parse(value))
    def test_edns_extended_error_fails(self):
        opt=b'\0'+struct.pack('!HHIH',41,4096,1<<24,0)
        with self.assertRaises(RuntimeError):self.parse(packet([self.good()],extra=[opt]))
    def test_default_dns_always_requires_operator_contract(self):
        for sid,options in [('bind9',{'zone':'lab.test'}),('dnsmasq',{'domain':'lab.test'}),('unbound',{'domain':'lab.test'})]:
            with self.subTest(sid=sid),self.assertRaisesRegex(ValueError,'expected address'):default_probe(sid,options)
    def test_tcp_transport_valid_and_invalid_real_loopback(self):
        for bad in (False,True):
            with self.subTest(header_only=bad):
                server=socket.socket();server.bind(('127.0.0.1',0));server.listen();server.settimeout(3)
                port=server.getsockname()[1];errors=[]
                def serve():
                    try:
                        connection,_=server.accept()
                        with connection:
                            connection.settimeout(3)
                            size=struct.unpack('!H',connection.recv(2))[0];q=b''
                            while len(q)<size:q+=connection.recv(size-len(q))
                            data=q[:2]+struct.pack('!HHHHH',0x8180,1,1,0,0)
                            if not bad:data+=q[12:]+self.good()
                            connection.sendall(struct.pack('!H',len(data))+data)
                    except Exception as exc:errors.append(str(exc))
                    finally:server.close()
                thread=threading.Thread(target=serve);thread.start()
                try:
                    if bad:
                        with self.assertRaises(RuntimeError):_dns_query('127.0.0.1',port,'lab.test','A',2,transport='tcp')
                    else:self.assertIn('returned 1',_dns_query('127.0.0.1',port,'lab.test','A',2,transport='tcp'))
                finally:thread.join(4)
                self.assertFalse(thread.is_alive());self.assertFalse(errors,errors)


class Cooldown207(unittest.TestCase):
    def test_batch_matches_each_recorded_member(self):
        item={'unit':'*','units':['web.service','db.service']}
        self.assertTrue(setup_redo._history_covers(item,'web.service'))
        self.assertTrue(setup_redo._history_covers(item,'db.service'))
        self.assertFalse(setup_redo._history_covers(item,'other.service'))
    def test_legacy_wildcards_and_malformed_members_are_conservative(self):
        for members in (None,[],{},'web.service',[1],['']):
            with self.subTest(members=members):
                self.assertTrue(setup_redo._history_covers({'unit':'*','units':members},'web.service'))
    def test_network_history_does_not_cross_agent_ids(self):
        item={'unit':'*','units':['vm1/web.service','vm2/db.service']}
        self.assertTrue(setup_redo._history_covers(item,'vm1/web.service'))
        self.assertFalse(setup_redo._history_covers(item,'vm3/web.service'))
    def test_whole_plan_wildcard_cools_every_service(self):
        self.assertTrue(setup_redo._history_covers({'unit':'*','units':['*']},'web.service'))
    def test_actual_batch_waits_then_resumes_after_cooldown(self):
        from test_live_findings_206 import RedoWorkspace
        from sentinel_blue.state import write_private_json
        f=RedoWorkspace();self.addCleanup(f.doCleanups)
        workspace,launcher=f.make(units=('web.service','db.service'))
        snap=f.snapshot([('local-linux',u,'unhealthy') for u in ('web.service','db.service')]);t=f.NOW
        setup_redo.tick(workspace,snap,now=t,launcher=launcher)
        self.assertIn('launched',setup_redo.tick(workspace,snap,now=t+181,launcher=launcher))
        state=setup_redo.load_state(workspace);job=Path(state['running']['job'])
        write_private_json(job.parent/'result.json',{'status':'ready'})
        setup_redo.tick(workspace,snap,now=t+182,launcher=launcher)
        self.assertNotIn('launched',setup_redo.tick(workspace,snap,now=t+364,launcher=launcher))
        self.assertIn('launched',setup_redo.tick(workspace,snap,now=t+782,launcher=launcher))
        self.assertEqual(len(f.launched),2)


@unittest.skipUnless(os.name == 'posix', 'POSIX directory discovery')
class Discovery207(unittest.TestCase):
    def setUp(self):
        tmp=tempfile.TemporaryDirectory(prefix='sb207-files-');self.addCleanup(tmp.cleanup);self.root=Path(tmp.name)
    def put(self,name,data=b'x'):
        p=self.root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);return p
    def test_shallow_sibling_survives_default_limit(self):
        for i in range(64):self.put(f'a/deeper/{i:02}.conf')
        shallower=self.put('z/important.conf');rows=config_files(self.root)
        self.assertEqual(len(rows),64);self.assertEqual(rows[0],shallower);self.assertTrue(rows.issues)
    def test_complete_small_tree_is_sorted_by_depth_then_name(self):
        paths=[self.put(x) for x in ('a/z/f.conf','b/b.conf','a/a.conf','top.conf')]
        rows=config_files(self.root)
        self.assertEqual(rows,sorted(paths,key=lambda p:(len(p.relative_to(self.root).parts),str(p))))
        self.assertFalse(rows.issues)
    def test_exact_limit_complete_has_no_false_overflow(self):
        self.put('a');self.put('b');rows=config_files(self.root,limit=2)
        self.assertEqual(len(rows),2);self.assertFalse(rows.issues)
    def test_more_than_limit_is_reported(self):
        for name in ('a','b','c'):self.put(name)
        self.assertTrue(config_files(self.root,limit=2).issues)
    def test_invalid_limits_refused(self):
        for n in (0,-1,True,1.1,999999):
            with self.subTest(limit=n),self.assertRaises(ValueError):config_files(self.root,n)
    def test_oversized_file_is_excluded_and_reported(self):
        p=self.put('big',b'x'*(1024*1024+1));rows=config_files(p)
        self.assertEqual(rows,[]);self.assertTrue(rows.issues)
    def test_symlink_files_and_directories_are_not_followed(self):
        outside=self.put('outside/f');(self.root/'alias').symlink_to(self.root/'outside',target_is_directory=True)
        (self.root/'link').symlink_to(outside)
        rows=config_files(self.root);self.assertEqual(rows,[outside]);self.assertTrue(rows.issues)
    def test_symlink_ancestor_is_not_followed(self):
        self.put('outside/sub/f');(self.root/'alias').symlink_to(self.root/'outside',target_is_directory=True)
        rows=config_files(self.root/'alias/sub');self.assertEqual(rows,[]);self.assertTrue(rows.issues)
    def test_directory_work_is_bounded(self):
        for i in range(1030):(self.root/f'{i:04}').mkdir()
        rows=config_files(self.root);self.assertEqual(rows,[]);self.assertTrue(rows.issues)
    def test_gui_plan_shows_incomplete_coverage(self):
        from sentinel_blue.linux_desktop_setup import plan_description
        text=plan_description({'tasks':[]},repair_coverage={'web.service':{'restorable':[],
                              'discovery_issues':['test configuration coverage incomplete'],'alert_only':[]}})
        self.assertIn('WARNING: test configuration coverage incomplete',text)
    def test_local_owner_discovery_keeps_warnings(self):
        from sentinel_blue.linux_workspace import _local_file_owners
        from sentinel_blue.linux_service_catalog import CATALOG
        for i in range(65):self.put(f'{i:02}.conf')
        fragment={'tasks':[{'id':'sentinel-apache2','service_id':'apache2.service','recipe':'linux-service','options':{}}]}
        catalog=copy.deepcopy(CATALOG['apache2']);catalog['config_paths']=[str(self.root)]
        warnings={}
        with patch.dict(CATALOG,{'apache2':catalog}),patch('sentinel_blue.collectors.integrity_watch_paths',return_value=[]),patch('sentinel_blue.linux_workspace._unit_file',return_value=None):
            scope,owned=_local_file_owners(fragment,self.root,discovery_issues=warnings)
        self.assertEqual(len(owned['apache2.service']),64);self.assertTrue(warnings['apache2.service'])


if __name__=='__main__':unittest.main()
