"""Observed host capacity, not inferred capacity (issue #13 follow-on, Linux).

#13 could name an out-of-memory kill only because systemd happened to record one.
A filesystem with no room stops a service just as reliably and leaves no such
verdict: the service simply fails to write, and recovery restarts it into the
same wall. The agent now measures free space, free inodes and memory headroom,
so "the disk is full" is observed rather than guessed at.

The boundary these tests defend: capacity that was never reported is *unknown*,
and unknown must never be treated as healthy.
"""

import os
import shutil
import tempfile
import time
import unittest
from dataclasses import asdict
from pathlib import Path
from unittest.mock import patch

from sentinel_blue import collectors
from sentinel_blue.collectors import MAX_CAPACITY_FILESYSTEMS, _linux_capacity
from sentinel_blue.desktop_control import service_rows
from sentinel_blue.detection import (
    CAPACITY_AMPLE_FREE_BYTES, CAPACITY_CRITICAL_FRACTION, CAPACITY_LOW_FRACTION,
    MEMORY_CRITICAL_FRACTION, detect)
from sentinel_blue.protocol import FilesystemCapacity, MemoryCapacity, Telemetry
from sentinel_blue.recovery_reasoning import CHECKS, DOMAINS, reason_recovery
from sentinel_blue.risk import KIND_FEATURES
from sentinel_blue.service_recovery import recovery_parameters
from sentinel_blue.service_repair import (
    RESTART_FUTILE_CODES, diagnose_service, host_capacity_findings, restart_futility)
from sentinel_blue.validation import ValidationError, validate_telemetry

from test_autonomous_service_recovery import fixtures, stopped
from test_service_manifest_policy import profile_for, service_manifest


GIB = 1024 ** 3


def filesystem(mount="/", *, free=50 * GIB, total=100 * GIB,
               free_inodes=1_000_000, total_inodes=2_000_000, read_only=False):
    return {"mount_point": mount, "device": "254:0", "total_bytes": total, "free_bytes": free,
            "total_inodes": total_inodes, "free_inodes": free_inodes, "read_only": read_only}


def codes(findings):
    return [item["code"] for item in findings]


def kinds(candidates):
    return [item.kind for item in candidates]


class LinuxCapacityCollectionTests(unittest.TestCase):
    """Measured against this host's real filesystems, not a stub."""

    @unittest.skipIf(os.name == "nt", "POSIX statvfs")
    def test_real_capacity_is_observed(self):
        errors = []
        filesystems, memory = _linux_capacity(errors)
        self.assertEqual(errors, [])
        self.assertTrue(filesystems, "at least the root filesystem must be observed")
        for row in filesystems:
            with self.subTest(mount=row.mount_point):
                self.assertGreater(row.total_bytes, 0)
                self.assertLessEqual(row.free_bytes, row.total_bytes)
                self.assertLessEqual(row.free_inodes, row.total_inodes)
        self.assertGreater(memory.total_bytes, 0)
        self.assertLessEqual(memory.available_bytes, memory.total_bytes)

    @unittest.skipIf(os.name == "nt", "POSIX statvfs")
    def test_one_row_per_device_not_per_path(self):
        # /, /var and /tmp are usually one device. Reporting it three times would
        # triple every alert about it.
        _filesystems, _memory = _linux_capacity([])
        devices = [row.device for row in _filesystems]
        self.assertEqual(len(devices), len(set(devices)))

    @unittest.skipIf(os.name == "nt", "POSIX statvfs")
    def test_free_space_excludes_the_root_reserve(self):
        # f_bfree counts the reserved blocks an ordinary service cannot use.
        # Reporting those as free would overstate the real headroom.
        root = os.statvfs("/")
        observed = next(row for row in _linux_capacity([])[0] if row.mount_point == "/")
        self.assertEqual(observed.free_bytes, root.f_frsize * root.f_bavail)
        if root.f_bfree != root.f_bavail:
            self.assertLess(observed.free_bytes, root.f_frsize * root.f_bfree)

    def test_an_unreadable_path_never_raises(self):
        with patch.object(collectors, "CAPACITY_PATHS", ("/nonexistent-sentinel-test",)):
            filesystems, _memory = _linux_capacity(errors := [])
        self.assertEqual(filesystems, [])
        self.assertIn("filesystem capacity is unavailable", errors)

    def test_the_filesystem_count_is_bounded(self):
        # Every path a distinct device, so deduplication cannot do the limiting.
        directory = Path(tempfile.mkdtemp(prefix="sentinel-capacity-"))
        self.addCleanup(shutil.rmtree, directory, True)
        paths = []
        for index in range(MAX_CAPACITY_FILESYSTEMS + 8):
            child = directory / f"m{index}"
            child.mkdir()
            paths.append(str(child))
        devices = {path: index + 900 for index, path in enumerate(paths)}
        real_stat = os.stat

        class Overridden:
            """A real stat result with only st_dev replaced."""

            def __init__(self, real, device):
                self._real, self.st_dev = real, device

            def __getattr__(self, name):
                return getattr(self._real, name)

        def stat(path, *args, **kwargs):
            result = real_stat(path, *args, **kwargs)
            device = devices.get(str(path))
            return result if device is None else Overridden(result, device)

        with patch.object(collectors, "CAPACITY_PATHS", tuple(paths)), \
                patch.object(collectors.os, "stat", stat):
            filesystems, _memory = _linux_capacity([])
        self.assertEqual(len(filesystems), MAX_CAPACITY_FILESYSTEMS)

    def test_missing_memory_information_is_reported_not_faked(self):
        with patch.object(collectors.Path, "open", side_effect=OSError("no /proc")):
            _filesystems, memory = _linux_capacity(errors := [])
        self.assertEqual(memory.total_bytes, 0)
        self.assertIn("host memory capacity is unavailable", errors)


class CapacityValidationTests(unittest.TestCase):
    def sample(self, **extra):
        return {"agent_id": "agent-one", "hostname": "h", "platform": "Linux",
                "observed_at": time.time(), "boot_id": "b", "sequence": 1,
                "collector_errors": [], **extra}

    def test_capacity_round_trips(self):
        result = validate_telemetry(self.sample(
            filesystems=[filesystem("/var")], memory=asdict(MemoryCapacity(8 * GIB, 4 * GIB))))
        self.assertEqual(result["filesystems"][0]["mount_point"], "/var")
        self.assertEqual(result["memory"]["available_bytes"], 4 * GIB)

    def test_an_older_agent_reports_no_capacity_at_all(self):
        # Absent must stay absent. A default of "0 bytes free" would alert on
        # every 1.9.76 agent; a default of "plenty" would hide a real fault.
        result = validate_telemetry(self.sample())
        self.assertNotIn("filesystems", result)
        self.assertNotIn("memory", result)

    def test_free_above_total_is_treated_as_unknown(self):
        result = validate_telemetry(self.sample(
            filesystems=[filesystem(free=200 * GIB, total=100 * GIB)]))
        row = result["filesystems"][0]
        self.assertEqual((row["free_bytes"], row["total_bytes"]), (0, 0))

    def test_free_inodes_above_total_is_treated_as_unknown(self):
        result = validate_telemetry(self.sample(
            filesystems=[filesystem(free_inodes=9, total_inodes=2)]))
        row = result["filesystems"][0]
        self.assertEqual((row["free_inodes"], row["total_inodes"]), (0, 0))

    def test_available_memory_above_total_is_treated_as_unknown(self):
        result = validate_telemetry(self.sample(
            memory={"total_bytes": 1, "available_bytes": 99, "swap_total_bytes": 0,
                    "swap_free_bytes": 0}))
        self.assertEqual(result["memory"]["available_bytes"], 0)

    def test_malformed_capacity_is_refused_not_silently_accepted(self):
        for value in ([{"mount_point": "/", "free_bytes": -1}],
                      [{"mount_point": "/", "free_bytes": "lots"}],
                      [{"mount_point": None}],
                      ["/"]):
            with self.subTest(value=value), self.assertRaises(ValidationError):
                validate_telemetry(self.sample(filesystems=value))

    def test_the_filesystem_list_is_bounded(self):
        with self.assertRaises(ValidationError):
            validate_telemetry(self.sample(filesystems=[filesystem(f"/m{i}") for i in range(65)]))

    def test_a_collected_observation_validates_unchanged(self):
        telemetry = Telemetry(
            agent_id="agent-one", hostname="h", platform="Linux", observed_at=time.time(),
            boot_id="b", sequence=1,
            filesystems=[FilesystemCapacity("/", "254:0", 100 * GIB, 50 * GIB, 100, 50)],
            memory=MemoryCapacity(8 * GIB, 4 * GIB))
        result = validate_telemetry(telemetry.as_dict())
        self.assertEqual(result["filesystems"][0]["free_bytes"], 50 * GIB)


class CapacityAlertTests(unittest.TestCase):
    def candidates(self, **extra):
        telemetry = {"agent_id": "agent-one", "platform": "Linux", "observed_at": time.time(),
                     "accounts": [], "sessions": [], "services": [], "integrity": [],
                     "probes": [], "processes": [], "persistence": [], "listeners": [],
                     "security_events": [], "collector_errors": [], **extra}
        return detect(telemetry, None, set())

    def test_a_filesystem_running_out_of_space_is_reported(self):
        found = [c for c in self.candidates(filesystems=[filesystem(free=4 * GIB, total=100 * GIB)])
                 if c.kind == "host_capacity_low"]
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0].severity, "medium")
        self.assertEqual(found[0].evidence["measure"], "space")

    def test_a_critically_full_filesystem_is_high_severity(self):
        found = [c for c in self.candidates(filesystems=[filesystem(free=GIB, total=100 * GIB)])
                 if c.kind == "host_capacity_low"]
        self.assertEqual(found[0].severity, "high")

    def test_exhausted_inodes_are_reported_even_with_free_space(self):
        # A filesystem with terabytes free and no inodes still cannot create a
        # file. Checking only bytes would miss this entirely.
        found = [c for c in self.candidates(filesystems=[
            filesystem(free=90 * GIB, total=100 * GIB, free_inodes=10, total_inodes=2_000_000)])
            if c.kind == "host_capacity_low"]
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0].evidence["measure"], "inodes")

    def test_a_large_volume_with_ample_room_does_not_cry_wolf(self):
        # 5% of 4 TB is 200 GB. Percentage alone would alert; it should not.
        self.assertEqual([c for c in self.candidates(filesystems=[
            filesystem(free=200 * GIB, total=4000 * GIB)]) if c.kind == "host_capacity_low"], [])
        self.assertGreater(200 * GIB, CAPACITY_AMPLE_FREE_BYTES)

    def test_a_healthy_filesystem_is_silent(self):
        self.assertNotIn("host_capacity_low", kinds(self.candidates(filesystems=[filesystem()])))

    def test_low_memory_is_reported(self):
        found = [c for c in self.candidates(
            memory={"total_bytes": 100 * GIB, "available_bytes": 2 * GIB,
                    "swap_total_bytes": 0, "swap_free_bytes": 0})
            if c.kind == "host_memory_pressure"]
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0].severity, "high")
        self.assertLessEqual(found[0].evidence["available_fraction"], MEMORY_CRITICAL_FRACTION)

    def test_absent_capacity_raises_nothing(self):
        # An older agent must not light up the board.
        raised = kinds(self.candidates())
        self.assertNotIn("host_capacity_low", raised)
        self.assertNotIn("host_memory_pressure", raised)

    def test_malformed_capacity_never_raises_an_exception(self):
        for value in ("unavailable", [None, 7], [{"mount_point": "/", "total_bytes": "x"}],
                      [{"mount_point": "/", "total_bytes": 0, "free_bytes": 0}]):
            with self.subTest(value=value):
                self.assertIsInstance(self.candidates(filesystems=value), list)

    def test_both_alert_kinds_are_known_to_the_risk_model(self):
        for kind in ("host_capacity_low", "host_memory_pressure"):
            with self.subTest(kind=kind):
                self.assertIn(kind, KIND_FEATURES)

    def test_the_thresholds_are_ordered_sensibly(self):
        self.assertLess(CAPACITY_CRITICAL_FRACTION, CAPACITY_LOW_FRACTION)


class ServiceFilesystemFaultTests(unittest.TestCase):
    """Only the filesystem under *this* service's files is its problem."""

    manifest = {"required_files": ["/etc/web.conf"], "required_data": ["/srv/web"]}

    def findings(self, rows):
        return host_capacity_findings("web.service", self.manifest, {"filesystems": rows})

    def test_a_full_filesystem_under_the_service_is_named(self):
        found = self.findings([filesystem("/etc", free=1024, total=100 * GIB)])
        self.assertEqual(codes(found), ["service_filesystem_full"])
        self.assertEqual(found[0]["evidence"]["mount_point"], "/etc")

    def test_a_full_filesystem_elsewhere_is_not_blamed(self):
        self.assertEqual(self.findings([filesystem("/boot", free=1024, total=100 * GIB)]), [])

    def test_the_closest_mount_point_wins(self):
        # With / and /srv both reported, /srv/web belongs to /srv.
        found = self.findings([filesystem("/", free=90 * GIB, total=100 * GIB),
                               filesystem("/srv", free=1024, total=100 * GIB)])
        self.assertEqual(codes(found), ["service_filesystem_full"])
        self.assertEqual(found[0]["evidence"]["mount_point"], "/srv")

    def test_exhausted_inodes_under_the_service_are_named(self):
        found = self.findings([filesystem("/", free=90 * GIB, total=100 * GIB,
                                          free_inodes=3, total_inodes=2_000_000)])
        self.assertEqual(codes(found), ["service_filesystem_inodes_exhausted"])

    def test_a_read_only_filesystem_is_named_before_anything_else(self):
        found = self.findings([filesystem("/", free=1024, total=100 * GIB, read_only=True)])
        self.assertEqual(codes(found), ["service_filesystem_read_only"])

    def test_a_healthy_filesystem_produces_nothing(self):
        self.assertEqual(self.findings([filesystem("/")]), [])

    def test_absent_capacity_produces_nothing(self):
        for telemetry in ({}, {"filesystems": []}, {"filesystems": "unavailable"},
                          {"filesystems": [None, 7]}):
            with self.subTest(telemetry=telemetry):
                self.assertEqual(
                    host_capacity_findings("web.service", self.manifest, telemetry), [])

    def test_relative_and_malformed_paths_are_ignored(self):
        manifest = {"required_files": ["etc/web.conf", "", None], "required_data": []}
        self.assertEqual(host_capacity_findings("web.service", manifest,
                                                {"filesystems": [filesystem("/", free=0)]}), [])

    def test_every_filesystem_fault_blocks_a_restart(self):
        for code in ("service_filesystem_full", "service_filesystem_inodes_exhausted",
                     "service_filesystem_read_only"):
            with self.subTest(code=code):
                self.assertIn(code, RESTART_FUTILE_CODES)
                self.assertTrue(restart_futility([{"code": code, "subject": "web.service"}]))

    def test_each_code_has_a_planner_domain_and_a_real_check(self):
        for code in ("service_filesystem_full", "service_filesystem_inodes_exhausted",
                     "service_filesystem_read_only"):
            with self.subTest(code=code):
                self.assertIn(code, DOMAINS)
                self.assertEqual(DOMAINS[code][0], "host_capacity")
                for check in DOMAINS[code][2]:
                    self.assertIn(check, CHECKS)


class RecoveryAndReportTests(unittest.TestCase):
    def fixture(self, rows):
        profile, baseline = fixtures()
        current = stopped(baseline, 2)
        current["observed_at"] = time.time() - 1
        current["filesystems"] = rows
        baseline["filesystems"] = rows
        return profile, baseline, current

    def test_a_full_filesystem_holds_recovery_and_names_it(self):
        profile, baseline, current = self.fixture([filesystem("/etc", free=0, total=100 * GIB)])
        with self.assertRaisesRegex(ValueError, "no room"):
            recovery_parameters(profile, "agent-one", "web.service", baseline, current)

    def test_a_healthy_filesystem_does_not_hold_recovery(self):
        profile, baseline, current = self.fixture([filesystem("/")])
        self.assertEqual(recovery_parameters(profile, "agent-one", "web.service",
                                             baseline, current)["service"], "web.service")

    def test_an_older_agent_still_recovers_normally(self):
        # No capacity telemetry at all must not become a silent hold.
        profile, baseline = fixtures()
        current = stopped(baseline, 2)
        current["observed_at"] = time.time() - 1
        self.assertEqual(recovery_parameters(profile, "agent-one", "web.service",
                                             baseline, current)["service"], "web.service")

    def test_the_cause_reaches_diagnosis_and_the_report(self):
        profile, baseline, current = self.fixture([filesystem("/etc", free=0, total=100 * GIB)])
        diagnosis = diagnose_service(profile, "agent-one", "web.service", baseline, current)
        self.assertIn("service_filesystem_full", codes(diagnosis["findings"]))
        report = reason_recovery(profile, "agent-one", baseline, current, approved=True)
        row = report["services"][0]
        self.assertEqual({h["evidence"]: h["domain"] for h in row["hypotheses"]}
                         ["service_filesystem_full"], "host_capacity")
        self.assertIn("host_capacity", [c["id"] for c in row["next_checks"]])
        self.assertEqual(row["state"], "held")

    def test_a_running_service_on_a_full_filesystem_is_still_flagged(self):
        # A running service that cannot write is failing, even though it is up.
        profile, baseline, current = self.fixture([filesystem("/etc", free=0, total=100 * GIB)])
        current["services"][0]["state"] = "running"
        self.assertIn("service_filesystem_full",
                      codes(diagnose_service(profile, "agent-one", "web.service",
                                             baseline, current)["findings"]))


class OperatorDisplayTests(unittest.TestCase):
    def row(self, rows):
        probe = {"name": "web-health", "kind": "http", "target": "http://192.0.2.10/health"}
        manifest = service_manifest(required_files=["/etc/web.conf"],
                                    expected_transactions=[probe],
                                    automatic=["restart_service"])
        sample = {"agent_id": "agent-one", "observed_at": time.time(),
                  "services": [{"name": "web.service", "state": "failed"}],
                  "filesystems": rows, "listeners": [],
                  "probes": [{"name": "web-health", "target": probe["target"], "healthy": False}]}
        return service_rows([manifest], {"agent-one": sample},
                            [{"agent_id": "agent-one", "enabled": True}])[0]

    def test_the_filesystem_cause_reaches_the_services_table(self):
        self.assertEqual(self.row([filesystem("/etc", free=0, total=100 * GIB)])["reason"],
                         "the filesystem holding its files is full")

    def test_a_read_only_filesystem_is_named_in_the_table(self):
        self.assertEqual(self.row([filesystem("/", read_only=True)])["reason"],
                         "the filesystem holding its files is read-only")

    def test_a_healthy_host_leaves_the_reason_alone(self):
        self.assertEqual(self.row([filesystem("/")])["reason"], "")


if __name__ == "__main__":
    unittest.main()
