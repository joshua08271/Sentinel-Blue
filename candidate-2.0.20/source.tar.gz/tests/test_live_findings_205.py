"""2.0.5: the remaining issues found in and after the 2.0.4 live runs."""
import copy
import json
import os
import shutil
import subprocess
import tempfile
import time
import unittest
from pathlib import Path


class AUnitStuckStoppingIsNamedForWhatItIs(unittest.TestCase):
    """Live: redis-server with an unwritable data directory refused to stop
    (TimeoutStopSec=0) and Sentinel said 'another process holds its port'."""

    def fixture(self, state):
        from test_service_repair import damage, repair_fixture
        profile, baseline = repair_fixture()
        current = damage(baseline)
        current["services"][0].update(state=state, substate="stop-sigterm")
        current["listeners"] = [{"protocol": "tcp", "address": "127.0.0.1", "port": 8765}]
        return profile, baseline, current

    def test_the_finding_is_stuck_stopping_not_a_port_owner_conflict(self):
        from sentinel_blue.service_repair import (RESTART_FUTILE_CODES, fault_summary, restart_blockers,
                                                  _manifest)
        profile, baseline, current = self.fixture("deactivating")
        manifest = _manifest(profile, "agent-one", "web.service")
        findings = restart_blockers("web.service", manifest, current["services"][0], baseline["services"][0], current)
        codes = [item["code"] for item in findings]
        self.assertIn("service_stop_stuck", codes)
        self.assertNotIn("listening_port_occupied", codes)
        self.assertIn("service_stop_stuck", RESTART_FUTILE_CODES)
        self.assertIn("stuck stopping", fault_summary(findings))

    def test_a_stopped_unit_still_reports_a_real_port_owner(self):
        from sentinel_blue.service_repair import restart_blockers, _manifest
        profile, baseline, current = self.fixture("failed")
        manifest = _manifest(profile, "agent-one", "web.service")
        codes = [item["code"] for item in restart_blockers("web.service", manifest, current["services"][0],
                                                           baseline["services"][0], current)]
        self.assertIn("listening_port_occupied", codes)

    def test_repair_is_held_with_that_reason(self):
        from sentinel_blue.service_repair import repair_parameters
        profile, baseline, current = self.fixture("deactivating")
        with self.assertRaisesRegex(ValueError, "still stopping"):
            repair_parameters(profile, "agent-one", "web.service", baseline, current)

    def test_the_service_table_says_so(self):
        from sentinel_blue.desktop_control import service_rows
        from test_service_repair import repair_fixture
        profile, baseline = repair_fixture()
        sample = copy.deepcopy(baseline)
        sample.update(observed_at=time.time())
        sample["services"][0].update(state="deactivating", substate="stop-sigterm")
        sample["listeners"] = [{"protocol": "tcp", "address": "127.0.0.1", "port": 8765}]
        rows = service_rows(profile.services, {"agent-one": sample}, [{"agent_id": "agent-one", "enabled": True}])
        self.assertIn("stuck stopping", rows[0]["reason"])
        self.assertNotIn("another process", rows[0]["reason"])


class TheRedoWaitsForAUnitThatIsChangingState(unittest.TestCase):
    def assess(self, native, reason=""):
        from sentinel_blue import setup_redo
        snapshot = {"agents": [{"agent_id": "local-linux", "baseline_status": "approved"}],
                    "service_health": [{"agent_id": "local-linux", "service": "web.service", "health": "unhealthy",
                                        "native_state": native, "reason": reason}],
                    "actions": [], "controller": {"governance": {"emergency_stopped": False, "autonomy_mode": "guarded-autonomous"}}}
        state = {"history": [], "missing_since": {}, "unhealthy_since": {"web.service": 0}, "seen_healthy": [],
                 "running": None}
        return setup_redo.assess(snapshot, None, state, 1000)["units"]["web.service"]

    def test_stuck_stopping_is_held_as_something_setup_cannot_fix(self):
        from sentinel_blue.service_repair import FAULT_SUMMARIES
        row = self.assess("deactivating", FAULT_SUMMARIES["service_stop_stuck"])
        self.assertEqual(row["status"], "held")

    def test_starting_or_stopping_is_waited_for(self):
        for native in ("activating", "deactivating", "reloading"):
            with self.subTest(native=native):
                row = self.assess(native)
                self.assertEqual(row["status"], "waiting")
                self.assertIn("changing its state", row["reason"])


class SetupServiceCommandsAreBounded(unittest.TestCase):
    def apply(self, **options):
        from sentinel_blue.setup_recipes import compile_recipe
        return compile_recipe("linux-service", {"service": "web.service", "enable": True, **options}, Path("."), "linux")[1]

    def test_every_blocking_service_command_has_a_time_limit(self):
        from sentinel_blue.setup_recipes import SERVICE_COMMAND_SECONDS
        script = self.apply(unmask=True)
        for verb in ("start", "restart", "stop"):
            with self.subTest(verb=verb):
                uses = [line for line in script.splitlines() if f"systemctl {verb} --" in line]
                self.assertTrue(uses)
                for line in uses:
                    for part in line.split(";"):
                        if f"systemctl {verb} --" in part:
                            self.assertIn(f"timeout {SERVICE_COMMAND_SECONDS} systemctl {verb} --", part)

    @unittest.skipUnless(shutil.which("sh") and shutil.which("timeout"), "needs a POSIX shell and timeout")
    def test_a_start_that_never_returns_fails_the_step_instead_of_hanging(self):
        import sentinel_blue.setup_recipes as recipes
        original = recipes.SERVICE_COMMAND_SECONDS
        recipes.SERVICE_COMMAND_SECONDS = 1
        try:
            script = self.apply()
        finally:
            recipes.SERVICE_COMMAND_SECONDS = original
        start = script.index("sb_started=0")
        section = "set -eu\nsb_active=0\nsb_changed=0\nsb_runtime_replaced=0\n" + script[start:script.index("systemctl is-active --quiet -- web.service", start)]
        with tempfile.TemporaryDirectory() as temp:
            fake = Path(temp) / "systemctl"
            fake.write_text("#!/bin/sh\nexec sleep 30\n")
            fake.chmod(0o755)
            began = time.monotonic()
            result = subprocess.run(["sh", "-c", section + "echo returned\n"], capture_output=True, text=True,
                                    env={"PATH": temp + ":/usr/bin:/bin"}, timeout=20)
        self.assertNotEqual(result.returncode, 0)
        self.assertNotIn("returned", result.stdout)
        self.assertLess(time.monotonic() - began, 10)

    @unittest.skipUnless(shutil.which("sh"), "needs a POSIX shell")
    def test_an_untouched_running_service_is_not_waited_on(self):
        script = self.apply()
        section = script[script.index("sb_started=0"):script.index("trap - EXIT")]
        with tempfile.TemporaryDirectory() as temp:
            fake = Path(temp) / "systemctl"
            fake.write_text("#!/bin/sh\nexit 0\n")
            fake.chmod(0o755)
            began = time.monotonic()
            result = subprocess.run(["sh", "-c", "set -eu\nsb_active=1\nsb_changed=0\nsb_runtime_replaced=0\n" + section],
                                    capture_output=True, text=True, env={"PATH": temp + ":/usr/bin:/bin"}, timeout=20)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertLess(time.monotonic() - began, 1.5)



class NetworkInventoryGapsDoNotHoldRecovery(unittest.TestCase):
    """Any collector error used to hold every restart and repair and the baseline."""

    def sample(self, sources):
        return {"observed_at": time.time(), "boot_id": "b", "sequence": 4,
                "collector_errors": [f"issue {i}" for i in range(len(sources))], "collector_issue_sources": list(sources)}

    def test_network_gaps_are_typed_at_the_collection_boundary(self):
        from sentinel_blue.telemetry_diagnostics import NetworkInventoryIssue, normalize_diagnostics
        errors, sources = normalize_diagnostics(["systemctl failed", NetworkInventoryIssue("route inventory failed")])
        self.assertEqual(sources, ["unknown", "network_inventory"])

    def test_the_controller_accepts_the_new_provenance(self):
        from sentinel_blue.validation import validate_telemetry
        from test_service_repair import repair_fixture
        _, baseline = repair_fixture()
        sample = dict(baseline, collector_errors=["route inventory failed"], collector_issue_sources=["network_inventory"])
        self.assertEqual(validate_telemetry(sample)["collector_issue_sources"], ["network_inventory"])

    def test_service_recovery_is_held_only_by_gaps_in_its_own_evidence(self):
        from sentinel_blue.service_recovery import _fresh
        _fresh(self.sample(["network_inventory", "network_inventory"]), time.time())
        with self.assertRaisesRegex(ValueError, "incomplete collection"):
            _fresh(self.sample(["network_inventory", "unknown"]), time.time())
        with self.assertRaisesRegex(ValueError, "incomplete collection"):
            _fresh(self.sample(["payload_fingerprint"]), time.time())
        _fresh(self.sample(["payload_fingerprint", "network_inventory"]), time.time(), allow_payload_issues=True)

    def test_the_baseline_is_approvable_with_a_warning(self):
        from sentinel_blue.controller import assess_baseline_readiness
        from test_service_repair import repair_fixture
        _, baseline = repair_fixture()
        baseline = dict(baseline, probes=[{"name": "p", "healthy": True}],
                        collector_errors=["nftables firewall query has diagnostics; coverage is incomplete"],
                        collector_issue_sources=["network_inventory"])
        readiness = assess_baseline_readiness(baseline)
        self.assertTrue(readiness["ready"], readiness)
        self.assertTrue(any("network inventory" in item for item in readiness["warnings"]))
        baseline["collector_issue_sources"] = ["unknown"]
        self.assertFalse(assess_baseline_readiness(baseline)["ready"])

    def test_a_firewall_failure_in_a_real_collection_is_a_network_issue(self):
        from unittest.mock import patch
        from sentinel_blue import collectors
        from sentinel_blue.protocol import FirewallState
        def failing(errors):
            errors.append("nftables firewall query has diagnostics; coverage is incomplete")
            return FirewallState(enabled=None)
        with patch.object(collectors, "_linux_firewall", side_effect=failing), \
             patch.object(collectors, "_linux_services", return_value=[]):
            telemetry = collectors.collect("probe-agent")
        pairs = dict(zip(telemetry.collector_errors, telemetry.collector_issue_sources))
        self.assertEqual(pairs["nftables firewall query has diagnostics; coverage is incomplete"], "network_inventory")


@unittest.skipUnless(os.path.exists("/proc/net/tcp"), "needs Linux /proc")
class WithoutIproute2TheKernelTablesAreRead(unittest.TestCase):
    def without(self, *tools):
        """Make these commands not installed, as on a minimal image."""
        from unittest.mock import patch
        from sentinel_blue import collectors
        real = collectors._run
        def run(command, timeout=8.0):
            if command[0] in tools:
                raise FileNotFoundError(command[0])
            return real(command, timeout=timeout)
        return patch.object(collectors, "_run", side_effect=run)

    def test_listeners_come_from_the_kernel_with_no_error(self):
        import socket
        from sentinel_blue import collectors
        server = socket.socket()
        server.bind(("127.0.0.1", 0))
        server.listen()
        self.addCleanup(server.close)
        port = server.getsockname()[1]
        errors = []
        with self.without("ss"):
            listeners = collectors._linux_listeners(errors)
        self.assertEqual(errors, [])
        self.assertIn(("tcp", "127.0.0.1", port), {(x.protocol, x.address, x.port) for x in listeners})

    def test_routes_neighbors_and_interfaces_come_from_the_kernel(self):
        from sentinel_blue import collectors
        errors = []
        with self.without("ip"):
            routes, _neighbors = collectors._linux_routes(errors)
            interfaces = collectors._linux_interfaces(errors)
        self.assertTrue(routes or not Path("/proc/net/route").read_text().splitlines()[1:])
        self.assertIn("lo", {item.name for item in interfaces})
        self.assertIn("127.0.0.1/8", next(item for item in interfaces if item.name == "lo").addresses)
        self.assertFalse([e for e in errors if "unavailable" in e or "failed" in e], errors)



@unittest.skipUnless(hasattr(os, "geteuid") and os.geteuid() == 0, "reconciliation runs as root")
class AnUncertainSetupIsClosedOnlyOnEvidence(unittest.TestCase):
    """2.0.3's redo could leave one; it held every later setup and all recovery."""

    def setUp(self):
        from unittest.mock import patch
        from sentinel_blue import setup_linux_transaction as tx
        from sentinel_blue.mutation_ledger import MutationLedger
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)
        root.chmod(0o700)
        self.tx = tx
        self.ledger = MutationLedger(root / "ledger")
        self.native = {"exists": True, "active": False, "enabled": "enabled", "configuration_sha256": "c" * 64}
        for name, value in (("ROOT", root / "transactions"),):
            item = patch.object(tx, name, value)
            item.start()
            self.addCleanup(item.stop)
        item = patch.object(tx, "service_state", side_effect=lambda _name: dict(self.native))
        item.start()
        self.addCleanup(item.stop)
        # The real check requires every ancestor to be root-owned and closed,
        # which a temporary directory under /tmp never is.
        item = patch.object(tx, "secure_directory", side_effect=lambda path, create=False:
                            path.mkdir(mode=0o700, parents=True, exist_ok=True) if create else None)
        item.start()
        self.addCleanup(item.stop)
        self.spec = {"service": "web.service", "files": [], "apply_sha256": "a" * 64}
        self.token = "b" * 32
        before = tx.ledger_capture(self.spec)
        target = {"spec": self.spec, "token": self.token, "objects": ["service:web.service"]}
        self.ledger.prepare("setup-linux-v1", target, before, action_id="setup-" + self.token)
        self.ledger.append("uncertain", action_id="setup-" + self.token, reason="ValueError")
        # The private record and resource claim the interrupted apply left behind.
        with tx.transaction_lock():
            base = tx.ROOT / self.token
            tx.secure_directory(base, create=True)
            state = {"status": "applied", "spec": self.spec, "before": before["native"],
                     "resources": tx.resources(self.spec)}
            tx.save(base / "state.json", state)
            for key in state["resources"]:
                tx.save(tx.ROOT / ("resource-" + key + ".json"), {"transaction": self.token})

    def status(self):
        return next(a for a in self.ledger.actions() if a["action_id"] == "setup-" + self.token)["status"]

    def test_objects_back_in_their_before_state_are_reconciled(self):
        report = self.tx.reconcile_uncertain(ledger_directory=self.ledger.directory)
        self.assertEqual([r["result"] for r in report], ["reconciled"])
        self.assertEqual(self.status(), "cancelled")
        self.assertEqual(list(self.tx.ROOT.glob("resource-*.json")), [], "the claim that blocked later setups is released")

    def test_an_approved_setup_found_in_effect_is_recorded_done(self):
        self.native["active"] = True
        record = self.tx.ROOT / self.token / "state.json"
        self.tx.save(record, dict(self.tx.read(record), after=self.tx.capture(self.spec)))
        report = self.tx.reconcile_uncertain(ledger_directory=self.ledger.directory)
        self.assertEqual([(r["result"], r["outcome"]) for r in report], [("reconciled", "took effect")])
        self.assertEqual(self.status(), "committed", "Withdraw can still reverse it")
        self.assertEqual(self.tx.read(record)["status"], "committed")
        self.assertEqual(list(self.tx.ROOT.glob("resource-*.json")), [])

    def test_anything_still_changed_is_held_and_named(self):
        self.native["active"] = True
        report = self.tx.reconcile_uncertain(ledger_directory=self.ledger.directory)
        self.assertEqual(report[0]["result"], "held")
        self.assertIn("running but was stopped", report[0]["reason"])
        self.assertEqual(self.status(), "uncertain")
        self.assertTrue(list(self.tx.ROOT.glob("resource-*.json")))

    def test_the_command_reports_both(self):
        from sentinel_blue.setup_reconcile import report_text
        self.assertIn("reconciled", report_text([{"service": "a.service", "result": "reconciled"}]))
        self.assertIn("held", report_text([{"service": "b.service", "result": "held", "reason": "x"}]))
        self.assertIn("No uncertain", report_text([]))



class WithdrawAfterARedoReturnsThePreSentinelState(unittest.TestCase):
    """Withdraw used to reverse a redo to the damage it replaced, then hold the
    original setup's inverse because the host was no longer in its post-state."""

    def setUp(self):
        from sentinel_blue.mutation_ledger import MutationLedger
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)
        root.chmod(0o700)
        self.ledger = MutationLedger(root / "ledger")
        self.pre = {"native": {"service": {"active": False, "enabled": "disabled"}}, "file_evidence": {}}
        self.approved = {"native": {"service": {"active": True, "enabled": "enabled"}}, "file_evidence": {}}
        self.damage = {"native": {"service": {"active": False, "enabled": "masked"}}, "file_evidence": {}}
        self.restored_to = []

    def record(self, name, spec, before, after):
        target = {"spec": spec, "token": name * 32, "objects": ["service:web.service"]}
        self.ledger.prepare("setup-linux-v1", target, before, action_id="setup-" + name * 32)
        self.ledger.commit("setup-" + name * 32, after, {"success": True})
        return "setup-" + name * 32

    def withdraw(self, *action_ids):
        from unittest.mock import patch
        from sentinel_blue import withdrawal
        state = {"current": self.approved}
        test = self
        class Adapter:
            def snapshot(self, target):
                return state["current"]
            def restore(self, target, before, expected):
                test.restored_to.append(before)
                state["current"] = before
                return before
        self.ledger.pause("withdraw-test")
        results = []
        with patch.object(withdrawal, "adapter_for", return_value=Adapter()):
            for action_id in action_ids:
                results.append(withdrawal._restore_one(self.ledger, action_id))
        return results, state["current"]

    def test_the_redo_is_absorbed_and_the_original_inverse_runs(self):
        spec = {"service": "web.service", "files": [], "apply_sha256": "a" * 64}
        original = self.record("a", spec, self.pre, self.approved)
        redo = self.record("b", spec, self.damage, self.approved)
        results, final = self.withdraw(redo, original)
        self.assertEqual(results[0]["absorbed_by"], original)
        self.assertEqual(results[1]["status"], "undone")
        self.assertEqual(self.restored_to, [self.pre], "the damage is never put back")
        self.assertEqual(final, self.pre)

    def test_a_different_later_step_is_still_reversed_literally(self):
        original = self.record("a", {"service": "web.service", "files": [], "apply_sha256": "a" * 64},
                               self.pre, self.approved)
        other = self.record("b", {"service": "web.service", "files": [], "apply_sha256": "c" * 64},
                            self.damage, self.approved)
        results, _ = self.withdraw(other)
        self.assertNotIn("absorbed_by", results[0])
        self.assertEqual(self.restored_to, [self.damage])



class ChecksOnThisVMsOwnAddress(unittest.TestCase):
    """A custom service bound only to the VM's network address could not be checked."""
    OWN = ("192.0.2.2",)

    def test_the_form_accepts_this_vms_address_and_nothing_else(self):
        from sentinel_blue.custom_services import local_check
        check = local_check("http", "http://192.0.2.2:8080/", local_addresses=self.OWN)
        self.assertEqual(check["target"], "http://192.0.2.2:8080/")
        with self.assertRaisesRegex(ValueError, "own addresses"):
            local_check("tcp", "192.0.2.99", 22, local_addresses=self.OWN)
        with self.assertRaisesRegex(ValueError, "127.0.0.1"):
            local_check("tcp", "192.0.2.2", 22)          # a remote host's panel knows no own address

    def test_own_addresses_come_from_the_interface_inventory(self):
        from sentinel_blue.service_repair import host_addresses, local_probe
        telemetry = {"interfaces": [{"name": "lo", "addresses": ["127.0.0.1/8", "::1/128"]},
                                    {"name": "eth0", "addresses": ["192.0.2.2/24", "fe80::1/64"]}]}
        own = host_addresses(telemetry)
        self.assertEqual(own, frozenset({"192.0.2.2"}))
        self.assertTrue(local_probe({"target": "http://192.0.2.2:8080/"}, own))
        self.assertFalse(local_probe({"target": "http://192.0.2.9:8080/"}, own))
        self.assertTrue(local_probe({"target": "127.0.0.1"}))

    def test_the_local_profile_is_scoped_to_exactly_the_address_used(self):
        from unittest.mock import patch
        from sentinel_blue.event_profile import load_event_profile
        from sentinel_blue.linux_workspace import prepare_workspace
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)
        runtime = root / "sentinel.pyz"
        runtime.write_bytes(b"fixture runtime")
        custom = [{"unit": "scoreboard.service", "check": {"kind": "tcp", "target": "192.0.2.2", "port": 9000, "timeout": 5}}]
        with patch("sentinel_blue.collectors.integrity_watch_paths", return_value=[]):
            config, plan = prepare_workspace(root / "sessions", runtime, [], {}, {}, custom_services=custom,
                                             local_addresses=("192.0.2.2", "198.51.100.7"))
        profile = load_event_profile(config["event_profile"])
        self.assertIn("192.0.2.2", profile.raw["scope"]["authorized_hosts"])
        self.assertNotIn("198.51.100.7", profile.raw["scope"]["authorized_hosts"], "only an address a check uses")
        self.assertIn("192.0.2.2/32", profile.raw["scope"]["authorized_networks"])
        with patch("sentinel_blue.collectors.integrity_watch_paths", return_value=[]), \
             self.assertRaisesRegex(ValueError, "own addresses"):
            prepare_workspace(root / "sessions2", runtime, [], {}, {}, custom_services=custom, local_addresses=())


class AVerifiedRepairClosesItsIncident(unittest.TestCase):
    """Live: after redis was repaired, its stopped / check-failed / file-changed
    alerts all stayed open, so a burst of red never cleared."""

    def open_alerts(self, store):
        return {(row["kind"], row["alert_id"]) for row in store.dashboard()["alerts"] if row["status"] == "open"}

    def run_repair(self, *, success=True, stable=True, dry_run=False):
        from dataclasses import asdict
        from sentinel_blue.controller import ControllerApp
        from sentinel_blue.store import Store
        from test_service_repair import damage, repair_fixture
        from test_store_controller import _promote_integrity_baseline
        from sentinel_blue.service_repair import plan_digest
        profile, baseline = repair_fixture()
        store = Store(":memory:")
        self.addCleanup(store.close)
        app = ControllerApp(store, "t" * 32, operator_token="o" * 32, event_profile=profile,
                            auto_recover_services=True, auto_restore=True,
                            restoration_probes=profile.services[0]["expected_transactions"])
        app.ingest(baseline)
        _promote_integrity_baseline(app, store, "agent-one")
        app.ingest(damage(baseline, 2))
        app.ingest(damage(baseline, 3))
        action = next(asdict(item) for item in store.pending_actions("agent-one") if item.action_type == "repair_service")
        before = self.open_alerts(store)
        now = time.time()
        result = {
            "action_id": action["action_id"], "action_type": "repair_service", "success": success,
            "message": "fixture repair", "started_at": now, "completed_at": now,
            "pre_state": {"service": "web.service", "desired_state": "stopped", "transaction_id": "tx-1"},
            "probes": [{"name": "local-web", "target": "http://127.0.0.1:8765/health", "healthy": success}],
            "stable_health": stable, "probe_attempts": 3,
            "record": {"plan_sha256": plan_digest(action["parameters"]), "transaction_id": "tx-1",
                       "files": action["parameters"]["recovery_guard"]["files"],
                       "startup": action["parameters"]["repair"].get("startup")},
        }
        if dry_run:
            result["dry_run"] = True
        self.assertEqual(app.complete_action(result, "agent-one"), "new")
        return store, before, self.open_alerts(store)

    def test_the_repaired_service_alerts_are_resolved(self):
        store, before, after = self.run_repair()
        kinds_before = {kind for kind, _ in before}
        self.assertTrue({"baseline_service_stopped", "service_probe_failed", "critical_file_changed"} <= kinds_before,
                        kinds_before)
        closed = before - after
        self.assertEqual({kind for kind, _ in closed} & {"baseline_service_stopped", "service_probe_failed",
                                                          "critical_file_changed"},
                         {"baseline_service_stopped", "service_probe_failed", "critical_file_changed"})
        decisions = {store.get_alert(alert_id)["decision"] for _, alert_id in closed}
        # The alert that queued the repair records how it was decided; the
        # rest of the incident is closed by the verified repair.
        self.assertEqual(decisions, {"automatic_service_recovery", "resolved_by_repair"})

    def test_nothing_closes_without_a_stable_verified_success(self):
        # (A success without stable health is refused outright for an
        # automatic repair, so it never reaches this point.)
        for options in ({"success": False, "stable": False}, {"dry_run": True}):
            with self.subTest(**options):
                _, before, after = self.run_repair(**options)
                self.assertFalse({kind for kind, _ in before - after} & {"baseline_service_stopped",
                                                                          "service_probe_failed",
                                                                          "critical_file_changed"})

    def test_other_hosts_services_and_files_stay_open(self):
        from sentinel_blue.store import Store
        store = Store(":memory:")
        self.addCleanup(store.close)
        store_rows = []
        import json as _json
        for agent, kind, evidence in (
            ("agent-one", "baseline_service_stopped", {"service": "web.service"}),
            ("agent-one", "baseline_service_stopped", {"service": "db.service"}),
            ("agent-two", "baseline_service_stopped", {"service": "web.service"}),
            ("agent-one", "critical_file_changed", {"path": "/etc/shadow"}),
            ("agent-one", "critical_file_changed", {"path": "/etc/web.conf"}),
            ("agent-one", "service_probe_failed", {"probe": {"name": "db-check", "target": "127.0.0.1"}}),
            ("agent-one", "service_probe_failed", {"probe": {"name": "local-web", "target": "x"}}),
            ("agent-one", "suspicious_account", {"service": "web.service", "path": "/etc/web.conf"}),
        ):
            alert_id = f"alert-{len(store_rows)}"
            store._connection.execute(
                "INSERT INTO alerts (alert_id, agent_id, kind, title, summary, severity, confidence, evidence_json, "
                "recommendation, recommended_action, status, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                (alert_id, agent, kind, "t", "s", "high", 0.9, _json.dumps(evidence), "r", "snapshot", "open",
                 time.time()))
            store_rows.append(alert_id)
        closed = store.resolve_repaired_incident("agent-one", "web.service", ["local-web"], ["/etc/web.conf"])
        self.assertEqual(sorted(closed), ["alert-0", "alert-4", "alert-6"])



def stock_like_redis_conf(size=106_604):
    """Text shaped like Ubuntu's redis.conf: long comment blocks, a few settings."""
    import hashlib
    lines, index = [], 0
    while sum(len(line) + 1 for line in lines) < size:
        digest = hashlib.sha256(str(index).encode()).hexdigest()[:12]
        lines.append(f"# Section {index % 53}: the server {'reads' if index % 3 else 'writes'} value {digest} here.")
        if index % 40 == 0:
            lines.append(f"# setting-{index} {index * 7 % 1000}")
        index += 1
    return "\n".join(lines) + "\nbind 127.0.0.1 -::1\nport 6379\n"


class AStockConfigurationFitsInASetupStep(unittest.TestCase):
    """Live: configuring Redis on Ubuntu 24.04 (106 KB redis.conf) failed before
    setup started: 'JSON string exceeds the per-string limit' (393 KB script)."""

    def setUp(self):
        import hashlib
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.parent = stock_like_redis_conf()
        snapshot = self.root / "redis.conf.snapshot"
        snapshot.write_text(self.parent)
        self.options = {"catalog_id": "redis", "manager": "apt", "bind_address": "127.0.0.1",
                        "previous_files": {"/etc/redis/sentinel.conf": "absent"},
                        "activation": {"/etc/redis/redis.conf": {
                            "path": str(snapshot), "sha256": hashlib.sha256(self.parent.encode()).hexdigest()}}}

    def compiled(self):
        from sentinel_blue.setup_recipes import compile_recipe
        from sentinel_blue.setup_transactions import commands
        _check, apply, _ = compile_recipe("linux-service-pack", self.options, self.root, "linux")
        return apply, commands("linux-service-pack", self.options, self.root, apply, context={"task_id": "t1"})

    def test_every_phase_is_a_valid_plan_string(self):
        from sentinel_blue.json_codec import MAX_JSON_STRING_CHARS, canonical_json_dumps
        apply, scripts = self.compiled()
        for phase, script in scripts.items():
            self.assertLess(len(script), MAX_JSON_STRING_CHARS // 2, phase)
        canonical_json_dumps({"tasks": [scripts | {"apply_raw": apply}]})

    def test_the_embedded_file_and_script_decode_exactly(self):
        import re
        import subprocess
        import sys
        from sentinel_blue.setup_recipes import INFLATE
        apply, scripts = self.compiled()
        expected = self.parent + "include /etc/redis/sentinel.conf\n"
        blobs = re.findall(r"printf '%s' '([A-Za-z0-9+/=]+)' \| \S+ -I -S -c '" + re.escape(INFLATE) + "'", apply)
        self.assertEqual(len(blobs), 2, "sentinel.conf and redis.conf")
        decoded = [subprocess.run([sys.executable, "-I", "-S", "-c", INFLATE], input=blob.encode(),
                                  capture_output=True, check=True).stdout.decode() for blob in blobs]
        self.assertIn(expected, decoded)
        import base64
        import zlib
        payload = re.search(r"unpack\('([A-Za-z0-9+/=]+)'\)\.decode\(\)", scripts["apply"]).group(1)
        self.assertEqual(zlib.decompress(base64.b64decode(payload)).decode(), apply)

    def test_a_file_too_large_to_carry_is_refused_with_a_reason(self):
        import hashlib
        import os as _os
        big = _os.urandom(450_000).hex()
        snapshot = self.root / "huge.conf"
        snapshot.write_text(big)
        self.options["activation"]["/etc/redis/redis.conf"] = {
            "path": str(snapshot), "sha256": hashlib.sha256(big.encode()).hexdigest()}
        with self.assertRaisesRegex(ValueError, "too large to carry in one reviewed setup step"):
            self.compiled()



class ARefusalBeforeAnyChangeIsACleanFailure(unittest.TestCase):
    """Live: the Redis pack was refused before it changed anything (/etc/redis
    is owned by redis), then its rollback failed for want of an ownership
    record, and the task was reported uncertain — which holds all setup."""

    def setUp(self):
        import hashlib
        from unittest.mock import patch
        from sentinel_blue import setup_linux_transaction as tx
        from sentinel_blue.mutation_ledger import MutationLedger
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)
        root.chmod(0o700)
        self.tx = tx
        self.ledger_directory = root / "ledger"
        self.ledger = MutationLedger(self.ledger_directory)
        native = {"exists": True, "active": True, "enabled": "enabled", "configuration_sha256": "c" * 64}
        for target, name, value in ((tx, "ROOT", root / "transactions"), (tx.os, "geteuid", lambda: 0)):
            item = patch.object(target, name, value)
            item.start()
            self.addCleanup(item.stop)
        for name, effect in (("service_state", lambda _name: dict(native)),
                             ("secure_directory", lambda path, create=False:
                              path.mkdir(mode=0o700, parents=True, exist_ok=True) if create else None)):
            item = patch.object(tx, name, side_effect=effect)
            item.start()
            self.addCleanup(item.stop)
        self.apply = "exit 0\n"
        self.spec = {"service": "redis-server.service", "apply_sha256": hashlib.sha256(self.apply.encode()).hexdigest(),
                     "files": [{"path": "/etc/redis/sentinel.conf", "sha256": "d" * 64, "mode": 420,
                                "previous_sha256": "absent"}]}
        self.token = "e" * 32

    def refuse_the_directory(self):
        import os as _os
        import stat as _stat
        from unittest.mock import patch
        info = _os.stat_result((_stat.S_IFDIR | 0o2770, 1, 1, 2, 110, 110, 4096, 0, 0, 0))
        return patch.object(self.tx, "trusted_parent",
                            side_effect=ValueError(self.tx.untrusted_directory_reason(Path("/etc/redis"), info)))

    def test_the_rollback_of_a_refused_step_succeeds_and_changes_nothing(self):
        with self.refuse_the_directory():
            with self.assertRaisesRegex(ValueError, "/etc/redis is owned by uid 110, not root"):
                self.tx.run("apply", self.spec, self.token, self.apply, ledger_directory=self.ledger_directory)
            self.assertEqual(self.ledger.read(), [])
            import contextlib
            import io
            printed = io.StringIO()
            with contextlib.redirect_stdout(printed):
                self.assertIsNone(self.tx.run("rollback", self.spec, self.token, self.apply,
                                              ledger_directory=self.ledger_directory))
            self.assertIn("refused before it changed anything", printed.getvalue())
        self.assertFalse((self.tx.ROOT / self.token).exists())
        self.assertEqual(self.ledger.read(), [])

    def test_a_prepared_step_is_never_mistaken_for_a_refused_one(self):
        before = self.tx.ledger_capture({"service": self.spec["service"], "files": []})
        self.ledger.prepare("setup-linux-v1", {"spec": self.spec, "token": self.token, "objects": []}, before,
                            action_id="setup-" + self.token)
        with self.assertRaises(ValueError):
            self.tx.run("rollback", self.spec, self.token, self.apply, ledger_directory=self.ledger_directory)


class APackIsRefusedAtReviewWhenItsDirectoryIsNotRootOwned(unittest.TestCase):
    def test_the_rule_matches_the_transactions(self):
        from sentinel_blue.linux_workspace import setup_write_refusal
        self.assertIsNone(setup_write_refusal("/etc/sentinel-blue-test-absent/child/file.conf"))
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.assertIn("can be written by a group or other accounts",
                      setup_write_refusal(str(Path(temp.name) / "file.conf")))  # under /tmp (1777)
        if os.geteuid() == 0:
            owned = Path("/var/lib") / ("sentinel-test-" + os.urandom(4).hex())
            owned.mkdir(mode=0o750)
            self.addCleanup(owned.rmdir)
            os.chown(owned, 4321, 4321)
            self.assertIn(f"{owned} is owned by uid 4321, not root", setup_write_refusal(str(owned / "a.conf")))

    def test_review_names_the_directory_and_offers_adoption(self):
        from unittest.mock import patch
        from sentinel_blue import linux_workspace
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)
        runtime = root / "sentinel.pyz"
        runtime.write_bytes(b"fixture runtime")
        options = {"redis": {"bind_address": "127.0.0.1", "previous_files": {"/etc/redis/sentinel.conf": "absent"}}}
        refusal = lambda path: "/etc/redis is owned by redis, not root" if path.startswith("/etc/redis/") else None
        with patch.object(linux_workspace, "setup_write_refusal", side_effect=refusal):
            with self.assertRaisesRegex(ValueError, r"Redis cannot be configured on this VM: /etc/redis is owned by "
                                                    r"redis, not root.*adopt the running Redis"):
                linux_workspace.prepare_workspace(root / "s", runtime, ["redis"], options, {"redis": "running"})
            # Adopting it (no configuration choices) is accepted, with repair.
            config, _plan = linux_workspace.prepare_workspace(root / "s2", runtime, ["redis"], {}, {"redis": "running"})
        self.assertIn("redis-server.service", config["repair_coverage"])



class ApprovingTheBaselineAnswersAlertsAboutWhatItApproves(unittest.TestCase):
    """Live: the Redis pack changed redis.conf seconds before the first baseline
    was approved; the critical 'no longer matches the approved host baseline'
    alert about that reviewed change stayed open."""

    def run_flow(self, *, change_again=False):
        import hashlib
        from sentinel_blue.controller import ControllerApp
        from sentinel_blue.store import Store
        from test_autonomous_service_recovery import fixtures
        from test_store_controller import _promote_integrity_baseline
        profile, baseline = fixtures()
        store = Store(":memory:")
        self.addCleanup(store.close)
        app = ControllerApp(store, "t" * 32, operator_token="o" * 32, event_profile=profile)
        app.ingest(baseline)
        changed = copy.deepcopy(baseline)
        changed.update(sequence=2, observed_at=baseline["observed_at"] + 2)
        changed["integrity"][0]["sha256"] = hashlib.sha256(b"include /etc/generated.conf").hexdigest()
        app.ingest(changed)
        alerts = [row for row in store.dashboard()["alerts"] if row["kind"] == "critical_file_changed"]
        self.assertEqual(len(alerts), 1)
        if change_again:
            again = copy.deepcopy(changed)
            again.update(sequence=3, observed_at=baseline["observed_at"] + 3)
            again["integrity"][0]["sha256"] = hashlib.sha256(b"third").hexdigest()
            app.ingest(again)
        _promote_integrity_baseline(app, store, "agent-one")
        return store, store.get_alert(alerts[0]["alert_id"])

    def test_the_alert_about_the_approved_change_is_resolved(self):
        _, alert = self.run_flow()
        self.assertEqual((alert["status"], alert["decision"]), ("decided", "resolved_by_baseline_approval"))

    def test_a_state_that_was_not_approved_stays_open(self):
        _, alert = self.run_flow(change_again=True)
        self.assertEqual(alert["status"], "open")



class DeletedRestorePointsAreNoticedAndRebuilt(unittest.TestCase):
    """Live: deleting Sentinel's restore-point blobs went unnoticed until a
    repair failed with "[Errno 2] No such file or directory: '0cda…'"."""

    def setUp(self):
        import hashlib
        from sentinel_blue.restoration import RestorePointStore
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.target = self.root / "site" / "web.conf"
        self.target.parent.mkdir(mode=0o755)
        self.target.write_bytes(b"trusted")
        self.target.chmod(0o644)
        self.store = RestorePointStore(self.root / "agent-state")
        self.digest = hashlib.sha256(b"trusted").hexdigest()
        result = self.store.capture([{"path": str(self.target), "sha256": self.digest}])
        self.assertTrue(result["success"], result)

    def test_a_blob_whose_file_still_matches_is_rebuilt(self):
        (self.store.blobs / self.digest).unlink()
        self.assertEqual(self.store.audit_backups(), {"rebuilt": [str(self.target)], "lost": []})
        self.assertEqual((self.store.blobs / self.digest).read_bytes(), b"trusted")
        self.assertEqual(self.store.audit_backups(), {"rebuilt": [], "lost": []}, "quiet once whole")

    def test_a_blob_whose_file_changed_is_lost_until_the_file_is_put_back(self):
        (self.store.blobs / self.digest).unlink()
        self.target.write_bytes(b"attacker")
        self.assertEqual(self.store.audit_backups(), {"rebuilt": [], "lost": [str(self.target)]})
        self.assertFalse((self.store.blobs / self.digest).exists(), "attacker bytes are never captured")
        self.target.write_bytes(b"trusted")
        self.assertEqual(self.store.audit_backups()["rebuilt"], [str(self.target)])

    def test_a_truncated_blob_is_replaced(self):
        (self.store.blobs / self.digest).write_bytes(b"x")
        self.assertEqual(self.store.audit_backups()["rebuilt"], [str(self.target)])
        self.assertEqual((self.store.blobs / self.digest).read_bytes(), b"trusted")

    def test_repair_names_the_lost_restore_point(self):
        (self.store.blobs / self.digest).unlink()
        self.target.write_bytes(b"attacker")
        import hashlib
        with self.assertRaisesRegex(ValueError, "the restore point for .*web.conf was deleted"):
            self.store.restore({"path": str(self.target), "sha256": self.digest,
                                "observed_sha256": hashlib.sha256(b"attacker").hexdigest()}, allowed=True)

    def test_the_diagnostic_alerts_without_holding_recovery(self):
        from sentinel_blue.controller import assess_baseline_readiness
        from sentinel_blue.detection import detect
        from sentinel_blue.telemetry_diagnostics import (merge_health_diagnostics, recovery_blocking,
                                                         restore_point_issues)
        from test_autonomous_service_recovery import fixtures
        _, telemetry = fixtures()
        merge_health_diagnostics(telemetry, restore_point_issues(
            {"lost": ["/etc/web.conf"], "rebuilt": ["/etc/other.conf"]}))
        self.assertEqual(telemetry["collector_issue_sources"], ["restore_points", "restore_points"])
        self.assertEqual(recovery_blocking(telemetry), [])
        readiness = assess_baseline_readiness(telemetry)
        self.assertEqual(readiness["blockers"], [])
        self.assertTrue(any("restore point(s) deleted" in text and "/etc/web.conf" in text
                            for text in readiness["warnings"]), readiness)
        alerts = {alert.kind: alert for alert in detect(telemetry, None, set())}
        self.assertNotIn("telemetry_degraded", alerts, "Sentinel's own backups are not a collector gap")
        alert = alerts["restore_point_deleted"]
        self.assertEqual((alert.evidence["lost"], alert.evidence["rebuilt"]), (["/etc/web.conf"], ["/etc/other.conf"]))
        self.assertEqual(alert.severity, "high")
        self.assertIn("cannot be restored by repair: /etc/web.conf", alert.summary)

    def test_one_alert_per_loss_closed_when_rebuilt(self):
        """Live: one deletion opened three alerts (each cycle's evidence differed)."""
        from sentinel_blue.controller import ControllerApp
        from sentinel_blue.store import Store
        from sentinel_blue.telemetry_diagnostics import merge_health_diagnostics, restore_point_issues
        from test_autonomous_service_recovery import fixtures
        profile, baseline = fixtures()
        store = Store(":memory:")
        self.addCleanup(store.close)
        app = ControllerApp(store, "t" * 32, operator_token="o" * 32, event_profile=profile)
        app.ingest(baseline)
        def cycle(sequence, lost=(), rebuilt=()):
            value = copy.deepcopy(baseline)
            value.update(sequence=sequence, observed_at=baseline["observed_at"] + sequence)
            merge_health_diagnostics(value, restore_point_issues({"lost": list(lost), "rebuilt": list(rebuilt)}))
            app.ingest(value)
            return [row for row in store.dashboard()["alerts"] if row["kind"] == "restore_point_deleted"]
        rows = cycle(2, lost=["/etc/redis/sentinel.conf"], rebuilt=["/etc/redis/redis.conf"])
        self.assertEqual([row["status"] for row in rows], ["open"])
        rows = cycle(3, lost=["/etc/redis/sentinel.conf"])
        self.assertEqual(len(rows), 1, "the same loss reported again coalesces")
        rows = cycle(4, rebuilt=["/etc/redis/sentinel.conf"])
        self.assertEqual({row["status"] for row in rows}, {"decided"})
        self.assertEqual({row["decision"] for row in rows}, {"resolved_restore_point_rebuilt"})
        # A later deletion whose files were intact stays open for review.
        rows = cycle(5, rebuilt=["/etc/hosts"])
        self.assertEqual(sum(row["status"] == "open" for row in rows), 1)

    def test_the_wire_format_accepts_the_new_provenance(self):
        from sentinel_blue.validation import validate_telemetry
        from sentinel_blue.telemetry_diagnostics import merge_health_diagnostics, restore_point_issues
        from test_autonomous_service_recovery import fixtures
        _, telemetry = fixtures()
        merge_health_diagnostics(telemetry, restore_point_issues({"lost": ["/etc/web.conf"], "rebuilt": []}))
        normalized = validate_telemetry(telemetry)
        self.assertEqual(normalized["collector_issue_sources"], ["restore_points"])



INCIDENT = {"service_repair_required", "service_probe_failed", "critical_file_changed"}


class ARedoThatFixedAServiceClosesItsIncident(unittest.TestCase):
    """Live: after the setup redo rebuilt Redis, its five incident alerts
    (stopped, restart loop ×2, check failed, file changed) stayed open."""

    def app_with_incident(self):
        import hashlib
        from sentinel_blue.controller import ControllerApp
        from sentinel_blue.store import Store
        from test_service_repair import damage, repair_fixture
        from test_store_controller import _promote_integrity_baseline
        profile, baseline = repair_fixture()
        # Model a complete approved security observation, now required by the
        # redo-closure gate. This fixture has no real file; native metadata is
        # exercised separately by test_linux_hotfix_207.Closure207.
        baseline["integrity"][0]["security_descriptor_sha256"] = "a" * 64
        store = Store(":memory:")
        self.addCleanup(store.close)
        app = ControllerApp(store, "t" * 32, operator_token="o" * 32, event_profile=profile)
        app.ingest(baseline)
        _promote_integrity_baseline(app, store, "agent-one")
        app.ingest(damage(baseline, 2))
        self.assertEqual(self.incident_open(store), INCIDENT)
        return app, store, baseline

    def healthy_again(self, app, baseline, sequence=3, **changes):
        value = copy.deepcopy(baseline)
        value.update(sequence=sequence, observed_at=baseline["observed_at"] + sequence)
        for key, item in changes.items():
            item(value)
        app.ingest(value)

    def incident_open(self, store):
        return {row["kind"] for row in store.dashboard()["alerts"] if row["status"] == "open"} & INCIDENT

    def test_it_closes_only_on_this_controllers_own_evidence(self):
        app, store, baseline = self.app_with_incident()
        answer = app.close_recovered_incident("agent-one", "web.service", "setup_redo")
        self.assertEqual(answer["closed"], 0)
        self.assertIn("not running", answer["reason"])
        self.healthy_again(app, baseline)
        self.assertEqual(app.close_recovered_incident("agent-one", "web.service", "setup_redo")["closed"], 3)
        self.assertEqual(self.incident_open(store), set())
        decided = {row["decision"] for row in store.dashboard()["alerts"] if row["status"] == "decided"}
        self.assertIn("resolved_by_setup_redo", decided)

    def test_a_failed_check_or_a_changed_file_keeps_it_open(self):
        import hashlib
        app, store, baseline = self.app_with_incident()
        def failing(value):
            value["probes"][0]["healthy"] = False
        self.healthy_again(app, baseline, probe=failing)
        self.assertIn("checks", app.close_recovered_incident("agent-one", "web.service", "setup_redo")["reason"])
        def changed(value):
            value["integrity"][0]["sha256"] = hashlib.sha256(b"other").hexdigest()
        self.healthy_again(app, baseline, sequence=4, file=changed)
        self.assertIn("files", app.close_recovered_incident("agent-one", "web.service", "setup_redo")["reason"])
        self.assertEqual(len(self.incident_open(store)), 3)
        with self.assertRaises(ValueError):
            app.close_recovered_incident("agent-one", "web.service", "operator")

    def test_the_route_is_recognised(self):
        from sentinel_blue.controller import CONTROLLER_JSON_REQUEST_BYTES, controller_post_route_limit
        self.assertEqual(controller_post_route_limit("/api/v1/agents/local-linux/services/recovered"),
                         CONTROLLER_JSON_REQUEST_BYTES)

    def test_the_session_asks_after_a_ready_redo_until_the_controller_agrees(self):
        from sentinel_blue import setup_redo
        from sentinel_blue.state import write_private_json
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        workspace = Path(temp.name)
        job = workspace / "job-redo-1" / "job.json"
        job.parent.mkdir()
        write_private_json(job, {"kind": "setup"})
        write_private_json(job.parent / "result.json", {"status": "ready"})
        state = setup_redo.load_state(workspace)
        state["running"] = {"at": 1.0, "unit": "redis-server.service", "units": ["redis-server.service"],
                            "reason": "", "job": str(job)}
        setup_redo.save_state(workspace, state)
        answers = [{"closed": 0, "reason": "the service is not running"}, {"closed": 5}]
        asked = []
        def close(agent, unit):
            asked.append(unit)
            self.assertEqual(agent, "local-linux")
            return answers.pop(0)
        snap = {"service_health": [], "actions": [], "controller": {"governance": {"emergency_stopped": False, "autonomy_mode": "guarded-autonomous"}}}
        setup_redo.tick(workspace, snap, now=100.0, close_incident=close)
        self.assertIn("redis-server.service", setup_redo.load_state(workspace)["close_pending"])
        setup_redo.tick(workspace, snap, now=115.0, close_incident=close)
        self.assertEqual(asked, ["redis-server.service", "redis-server.service"])
        self.assertEqual(setup_redo.load_state(workspace)["close_pending"], {})
        setup_redo.tick(workspace, snap, now=130.0, close_incident=close)
        self.assertEqual(len(asked), 2, "never asked again")



class TheServicesTabSpeaksPlainly(unittest.TestCase):
    """Live: every healthy service's Recovery column read 'running service needs
    authorized restart and a failed local application transaction', and a
    service just repaired read 'service_recovery_cooldown'."""

    def test_a_healthy_service_needs_nothing(self):
        from sentinel_blue.service_recovery import HEALTHY_STATUS, ServiceRecoveryPlanner
        from test_service_repair import repair_fixture
        profile, baseline = repair_fixture()
        for restart_only in (False, True):
            planner = ServiceRecoveryPlanner(profile)
            planner.restart_only = restart_only
            planner.observe("agent-one", baseline, True, baseline)
            self.assertEqual({row["status"] for row in planner.status()}, {HEALTHY_STATUS})

    def test_status_codes_are_translated_for_display_only(self):
        from sentinel_blue.desktop_control import recovery_words
        self.assertIn("cooldown", recovery_words("service_recovery_cooldown"))
        self.assertNotIn("_", recovery_words("service_recovery_prior_outcome_unresolved"))
        self.assertEqual(recovery_words("ready"), "ready")



class ARestartLoopCausedByBrokenConfigurationIsRepaired(unittest.TestCase):
    """Live: redis-server (Restart=always) with a corrupted redis.conf looped,
    then hit its start limit, and repair was 'held for review' for good."""

    def looping(self, *, corrupt=True, substate="failed"):
        from test_service_repair import damage, repair_fixture
        profile, baseline = repair_fixture()
        baseline["services"][0]["restart_count"] = 0
        current = damage(baseline, 3) if corrupt else copy.deepcopy(baseline)
        current.update(sequence=3, observed_at=baseline["observed_at"] + 3)
        current["services"][0].update(state="failed", substate=substate, restart_count=5, result="exit-code",
                                       exit_code=1)
        current["probes"][0]["healthy"] = False
        return profile, baseline, current

    def test_the_repair_that_restores_the_cause_is_planned(self):
        from sentinel_blue.service_repair import repair_parameters
        profile, baseline, current = self.looping()
        parameters = repair_parameters(profile, "agent-one", "web.service", baseline, current)
        self.assertEqual([item["path"] for item in parameters["repair"]["restore_files"]], ["/etc/web.conf"])

    def test_a_loop_with_nothing_to_restore_is_still_held(self):
        from sentinel_blue.service_repair import repair_parameters
        profile, baseline, current = self.looping(corrupt=False)
        with self.assertRaisesRegex(ValueError, "restarting this unit in a loop; repair is held"):
            repair_parameters(profile, "agent-one", "web.service", baseline, current)

    def test_a_plain_restart_is_still_held(self):
        from sentinel_blue.service_recovery import recovery_parameters
        profile, baseline, current = self.looping()
        with self.assertRaisesRegex(ValueError, "loop"):
            recovery_parameters(profile, "agent-one", "web.service", baseline, current)

    def test_the_executor_reads_auto_restart_as_stopped_and_clears_the_start_limit(self):
        from unittest.mock import MagicMock, patch
        from sentinel_blue import service_repair_executor as module
        repairs = module.ServiceRepairExecutor.__new__(module.ServiceRepairExecutor)
        repairs.executor = MagicMock()
        repairs.executor._service_state.return_value = "unknown"
        shown = "LoadState=loaded\nActiveState=activating\nSubState=auto-restart\n"
        with patch.object(module.subprocess, "run",
                          return_value=subprocess.CompletedProcess([], 0, shown, "")) as run:
            self.assertEqual(repairs._observed_state("redis-server.service", None, ()), "stopped")
            repairs.executor._service_state.return_value = "running"
            repairs._transition("redis-server.service", "running")
        commands = [call.args[0] for call in run.call_args_list]
        self.assertIn(["systemctl", "reset-failed", "--", "redis-server.service"], commands)
        repairs.executor._set_service_state.assert_called_once_with("redis-server.service", "running")



class SentinelCanRunAgainAfterAnExecutedWithdrawal(unittest.TestCase):
    """Live: after Withdraw, a new session's controller only 'exited before
    readiness'. The host stays paused by design, but nothing could record the
    human decision to use Sentinel there again short of deleting the ledger."""

    def setUp(self):
        from unittest.mock import patch
        from sentinel_blue.mutation_ledger import MutationLedger
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.directory = Path(temp.name) / "ledger"
        item = patch.dict(os.environ, {"SENTINEL_LEDGER_DIR": str(self.directory)})
        item.start()
        self.addCleanup(item.stop)
        self.ledger = MutationLedger(self.directory)
        key = self.ledger.prepare("native-objects-v1", {"objects": ["file:/etc/x"]}, {"x": 1})
        self.ledger.commit(key, {"x": 2}, {"success": True})
        self.key = key

    def withdraw(self, operation="op-1", *, executed=True):
        self.ledger.pause(operation)
        if executed:
            self.ledger.append("undo_prepared", action_id=self.key)
            self.ledger.append("undone", action_id=self.key, restored_hash=self.ledger.store({"x": 1}))

    def test_the_refusal_names_the_way_back(self):
        from sentinel_blue.mutation_tracking import admission_refusal
        self.assertIsNone(admission_refusal(self.ledger))
        self.withdraw()
        text = admission_refusal(self.ledger)
        self.assertIn("re-enrollment requires human review", text)
        self.assertIn("sentinel-blue withdraw-release --operation-id op-1", text)

    def test_release_needs_the_operation_and_a_quiet_ledger(self):
        from sentinel_blue.mutation_ledger import LedgerError
        self.withdraw()
        with self.assertRaisesRegex(LedgerError, "not the withdrawal"):
            self.ledger.release_after_withdrawal("op-2")
        self.assertEqual(self.ledger.release_after_withdrawal("op-1", check_only=True)["status"], "can_release")
        self.assertTrue(self.ledger.paused(), "checking changes nothing")
        self.assertEqual(self.ledger.release_after_withdrawal("op-1")["status"], "released")
        self.assertFalse(self.ledger.paused())
        with self.assertRaisesRegex(LedgerError, "No withdrawal"):
            self.ledger.release_after_withdrawal("op-1")

    def test_a_review_that_changed_nothing_is_cancelled_not_released(self):
        from sentinel_blue.mutation_ledger import LedgerError
        self.withdraw(executed=False)
        with self.assertRaisesRegex(LedgerError, "only reviewed"):
            self.ledger.release_after_withdrawal("op-1")

    def test_an_action_in_flight_holds_the_release(self):
        from sentinel_blue.mutation_ledger import LedgerError
        other = self.ledger.prepare("native-objects-v1", {"objects": ["file:/etc/y"]}, {"y": 1})
        self.withdraw()
        with self.assertRaisesRegex(LedgerError, "interrupted mutation"):
            self.ledger.release_after_withdrawal("op-1")
        self.assertTrue(other)

    def test_the_command(self):
        import argparse
        import contextlib
        import io
        from unittest.mock import patch
        from sentinel_blue import withdrawal_release
        self.withdraw()
        out = io.StringIO()
        with patch.object(withdrawal_release.os, "geteuid", return_value=0), contextlib.redirect_stdout(out):
            self.assertEqual(withdrawal_release.run(argparse.Namespace(operation_id=None, json=False)), 0)
            self.assertIn("--operation-id op-1", out.getvalue())
            self.assertTrue(self.ledger.paused())
            self.assertEqual(withdrawal_release.run(argparse.Namespace(operation_id="wrong", json=False)), 2)
            self.assertTrue(self.ledger.paused())
            self.assertEqual(withdrawal_release.run(argparse.Namespace(operation_id="op-1", json=False)), 0)
        self.assertFalse(self.ledger.paused())
        self.assertIn("Released", out.getvalue())



class AnAccountChangeDoesNotHoldAServicesRepair(unittest.TestCase):
    """Live red-team run: `useradd redteam` changed /etc/passwd and /etc/group,
    which local setup had attached to redis-server for baseline coverage; its
    repair then read 'file repair is not authorized: /etc/group' for good."""

    def fixture(self, host_files=True):
        import hashlib
        from test_service_manifest_policy import profile_for
        from test_service_repair import damage, repair_fixture
        profile, baseline = repair_fixture()
        manifest = copy.deepcopy(profile.services[0])
        manifest["required_files"] = ["/etc/web.conf", "/etc/passwd", "/etc/group"]
        if host_files:
            manifest["repair_policy"]["host_files"] = ["/etc/passwd", "/etc/group"]
        for path in ("/etc/passwd", "/etc/group"):
            baseline["integrity"].append({"path": path, "sha256": hashlib.sha256(path.encode()).hexdigest(),
                                          "size": 1, "modified_at": 1, "security_descriptor_sha256": ""})
        current = damage(baseline, 3)
        current.update(observed_at=baseline["observed_at"] + 3)
        for row in current["integrity"][1:]:
            row["sha256"] = hashlib.sha256(b"redteam added").hexdigest()
        return profile_for([manifest]), baseline, current

    def test_repair_proceeds_and_leaves_host_files_alone(self):
        from sentinel_blue.service_repair import repair_parameters
        profile, baseline, current = self.fixture()
        parameters = repair_parameters(profile, "agent-one", "web.service", baseline, current)
        self.assertEqual([item["path"] for item in parameters["repair"]["restore_files"]], ["/etc/web.conf"])
        self.assertEqual([item["path"] for item in parameters["recovery_guard"]["files"]], ["/etc/web.conf"])

    def test_without_the_marking_it_is_held_as_before(self):
        from sentinel_blue.service_repair import repair_parameters
        profile, baseline, current = self.fixture(host_files=False)
        with self.assertRaisesRegex(ValueError, "file repair is not authorized: /etc/"):
            repair_parameters(profile, "agent-one", "web.service", baseline, current)

    def test_the_marking_is_validated(self):
        from sentinel_blue.service_repair import normalize_repair_policy
        manifest = {"required_files": ["/etc/web.conf", "/etc/passwd"]}
        base = {"restore_files": ["/etc/web.conf"], "restart_unhealthy": True, "validation_timeout_seconds": 30}
        self.assertEqual(normalize_repair_policy(base | {"host_files": ["/etc/passwd"]}, manifest)["host_files"],
                         ["/etc/passwd"])
        for bad in (["/etc/web.conf"], ["/etc/other"], "x", ["/etc/passwd", "/etc/passwd"]):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                normalize_repair_policy(base | {"host_files": bad}, manifest)

    def test_local_setup_marks_the_host_wide_files_it_attaches(self):
        from sentinel_blue.event_profile import EventProfile
        from sentinel_blue.linux_workspace import prepare_workspace
        from sentinel_blue.state import read_private_json
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)
        runtime = root / "sentinel.pyz"
        runtime.write_bytes(b"fixture runtime")
        config, _ = prepare_workspace(root / "s", runtime, ["redis"], {}, {"redis": "running"})
        profile = EventProfile.from_dict(json.loads(Path(config["event_profile"]).read_text()))
        policy = profile.services[0]["repair_policy"]
        if not Path("/etc/passwd").is_file():
            self.skipTest("this host has no /etc/passwd")
        self.assertIn("/etc/passwd", policy["host_files"])
        self.assertNotIn("/etc/passwd", policy["restore_files"])
        self.assertTrue(set(policy["host_files"]) <= set(profile.services[0]["required_files"]))

    def test_repair_grant_counts_a_check_on_the_hosts_own_address_as_local(self):
        from sentinel_blue.repair_grants import grant_repair
        from test_repair_grants_203 import written_without_repair
        raw, _ = written_without_repair()
        raw["services"][0]["expected_transactions"] = [{"name": "own", "kind": "tcp", "target": "10.0.0.5", "port": 80}]
        for host, warned in (("10.0.0.5", False), ("agent-one", True)):
            candidate = copy.deepcopy(raw)
            candidate["services"][0]["host"] = host
            _, report = grant_repair(candidate)
            self.assertEqual(any("own address" in text for text in report["warnings"]), warned, host)

    def test_repair_grant_marks_identity_files(self):
        from sentinel_blue.repair_grants import grant_repair
        from test_repair_grants_203 import written_without_repair
        raw, _ = written_without_repair()
        raw["services"][0]["required_files"] = ["/etc/web.conf", "/etc/shadow"]
        granted, _ = grant_repair(raw)
        self.assertEqual(granted["services"][0]["repair_policy"]["host_files"], ["/etc/shadow"])


if __name__ == "__main__":
    unittest.main()
