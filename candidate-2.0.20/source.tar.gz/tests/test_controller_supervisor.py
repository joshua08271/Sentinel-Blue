"""Real owned subprocess failures, paced unbounded restarts, and private output paths."""
import argparse
import json
import os
from pathlib import Path
import sys
import tempfile
import threading
import time
import unittest

from sentinel_blue.controller import prepare_controller_directories
from sentinel_blue.controller_supervisor import heartbeat_fresh, supervise
from sentinel_blue.state import write_private_json


class ControllerSupervisorTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.root.chmod(0o700)
        self.status = self.root / "status.json"
        self.heartbeat = self.root / "heartbeat.json"

    def arguments(self, **changes):
        values = dict(database=str(self.root/"controller.db"),
                      recovery_anchor=str(self.root/"recovery.anchor"),
                      recovery_key_file=str(self.root/"recovery.key"),
                      backup_directory=None, supervise=True)
        values.update(changes)
        return argparse.Namespace(**values)

    def run_child(self, source, **options):
        return supervise(lambda: [sys.executable, "-c", source], self.status,
                         self.heartbeat, options.pop("stop", threading.Event()),
                         poll_interval=0.01, restart_delay=0.001, **options)

    def test_automatic_backup_and_supervision_directories_are_private(self):
        args = self.arguments()
        prepare_controller_directories(args)
        self.assertTrue(Path(args.backup_directory).is_dir())
        self.assertTrue(Path(args.supervisor_directory).is_dir())
        if os.name == "posix":
            self.assertEqual(Path(args.backup_directory).stat().st_mode & 0o777, 0o700)
        prepare_controller_directories(args)  # Safe repeated startup.

    def test_output_cannot_contain_live_authority(self):
        args = self.arguments(backup_directory=str(self.root))
        with self.assertRaisesRegex(ValueError, "outside the backup"):
            prepare_controller_directories(args)
        args = self.arguments(recovery_key_file=str(self.root/"recovery.anchor.supervisor"/"key"))
        with self.assertRaisesRegex(ValueError, "outside the supervisor"):
            prepare_controller_directories(args)
        self.assertFalse((self.root/"recovery.anchor.supervisor").exists())

    @unittest.skipUnless(os.name == "posix", "POSIX mode check")
    def test_public_existing_directory_is_rejected_without_chmod(self):
        directory = self.root/"public"
        directory.mkdir(mode=0o755)
        directory.chmod(0o755)
        with self.assertRaisesRegex(ValueError, "group or other"):
            prepare_controller_directories(self.arguments(backup_directory=str(directory)))
        self.assertEqual(directory.stat().st_mode & 0o777, 0o755)

    def stop_after(self, restarts, stop):
        """Request a stop once the status file reports this many restarts."""
        def watch():
            deadline = time.monotonic() + 20
            while time.monotonic() < deadline and not stop.is_set():
                try:
                    if json.loads(self.status.read_text()).get("restarts", 0) >= restarts:
                        stop.set()
                        return
                except (OSError, ValueError):
                    pass
                time.sleep(0.005)
            stop.set()
        thread = threading.Thread(target=watch)
        thread.start()
        self.addCleanup(thread.join)

    def test_failed_children_back_off_and_are_never_abandoned(self):
        # 2.0.16: five failures in five minutes used to stop supervision for
        # good (exit 70). Restarts now back off to a capped delay and go on.
        stop = threading.Event()
        self.stop_after(8, stop)
        began = time.monotonic()
        self.assertEqual(self.run_child("raise SystemExit(2)", stop=stop, max_restart_delay=0.05), 0)
        self.assertLess(time.monotonic()-began, 15)
        state = json.loads(self.status.read_text())
        self.assertEqual(state["reason"], "supervisor_stop_requested")
        self.assertGreaterEqual(state["restarts"], 8)
        self.assertEqual(len(state["failures"]), 5)  # only recent failures pace restarts
        # A later supervisor run resumes from the saved history and still starts.
        calls = []
        stop = threading.Event()
        def command():
            calls.append(True)
            stop.set()
            return [sys.executable, "-c", "raise SystemExit(2)"]
        self.assertEqual(supervise(command, self.status, self.heartbeat, stop, restart_delay=0), 0)
        self.assertEqual(len(calls), 1)

    def test_backoff_is_capped_once_failures_are_recent(self):
        waits = []
        class Stop(threading.Event):
            def wait(self, timeout=None):
                if timeout is not None and timeout > 0.02:
                    waits.append(round(timeout, 3))
                    if len(waits) >= 7:
                        self.set()
                    return self.is_set()
                return super().wait(timeout)
        supervise(lambda: [sys.executable, "-c", "raise SystemExit(3)"], self.status, self.heartbeat,
                  Stop(), poll_interval=0.01, restart_delay=1.0, max_restart_delay=6.0)
        self.assertEqual(waits, [1.0, 2.0, 4.0, 6.0, 6.0, 6.0, 6.0])
        state = json.loads(self.status.read_text())
        self.assertEqual(state["reason"], "supervisor_stop_requested")

    def test_clean_child_exit_without_a_stop_request_is_restarted(self):
        # The controller exits 0 on SIGTERM. A signal to the child alone
        # (pkill, kill) used to end supervision with the controller down.
        marker = self.root/"child-attempts"
        source = ("from pathlib import Path; p=Path(" + repr(str(marker)) + "); "
                  "n=int(p.read_text())+1 if p.exists() else 1; p.write_text(str(n)); "
                  "raise SystemExit(0)")
        stop = threading.Event()
        self.stop_after(3, stop)
        self.assertEqual(self.run_child(source, stop=stop), 0)
        self.assertGreaterEqual(int(marker.read_text()), 3)
        self.assertEqual(json.loads(self.status.read_text())["reason"], "supervisor_stop_requested")

    def test_real_sigterm_to_the_child_alone_restarts_it(self):
        if os.name != "posix":
            self.skipTest("POSIX signal")
        import signal
        stop = threading.Event()
        pids = []
        def watch():
            deadline = time.monotonic() + 20
            while time.monotonic() < deadline and not stop.is_set():
                try:
                    state = json.loads(self.status.read_text())
                except (OSError, ValueError):
                    state = {}
                pid = state.get("child_pid") if state.get("state") == "running" else None
                if pid and pid not in pids:
                    pids.append(pid)
                    if len(pids) == 1:
                        time.sleep(0.2)
                        os.kill(pid, signal.SIGTERM)
                    else:
                        stop.set()
                        return
                time.sleep(0.01)
            stop.set()
        thread = threading.Thread(target=watch)
        thread.start()
        self.addCleanup(thread.join)
        source = ("import signal, sys, time; signal.signal(signal.SIGTERM, lambda *_: sys.exit(0)); "
                  "time.sleep(30)")
        self.assertEqual(self.run_child(source, stop=stop), 0)
        self.assertEqual(len(pids), 2)

    def test_stalled_children_are_stopped_and_never_overlap(self):
        children = []
        stop = threading.Event()
        from sentinel_blue.controller_supervisor import OwnedController
        def own(command):
            self.assertTrue(all(child.process.poll() is not None for child in children))
            child = OwnedController(command)
            children.append(child)
            if len(children) >= 6:
                stop.set()
            return child
        result = self.run_child("import time; time.sleep(30)", heartbeat_limit=0.12,
                                child_factory=own, stop=stop, max_restart_delay=0.05)
        self.assertEqual(result, 0)
        self.assertEqual(len(children), 6)
        self.assertTrue(all(child.process.poll() is not None for child in children))

    def test_future_or_malformed_history_is_set_aside_not_a_hold(self):
        for saved in ({"failures": [time.time() + 3600]}, {"failures": "x"}, ["not", "an", "object"]):
            with self.subTest(saved=saved):
                write_private_json(self.status, saved)
                stop = threading.Event()
                calls = []
                def command():
                    calls.append(True)
                    stop.set()
                    return [sys.executable, "-c", "pass"]
                self.assertEqual(supervise(command, self.status, self.heartbeat, stop, restart_delay=0), 0)
                self.assertEqual(calls, [True])
                self.assertTrue(self.status.with_name("status.json.invalid").exists())
                self.assertEqual(json.loads(self.status.read_text())["state"], "stopped")

    def test_status_write_failure_does_not_end_supervision(self):
        from unittest.mock import patch
        stop = threading.Event()
        attempts = []
        def command():
            attempts.append(True)
            if len(attempts) >= 3:
                stop.set()
            return [sys.executable, "-c", "raise SystemExit(2)"]
        with patch("sentinel_blue.controller_supervisor.write_private_json", side_effect=OSError(28, "No space")):
            self.assertEqual(supervise(command, self.status, self.heartbeat, stop,
                                       poll_interval=0.01, restart_delay=0.001), 0)
        self.assertEqual(len(attempts), 3)

    def test_transient_io_error_in_preflight_is_retried_not_a_hold(self):
        stop = threading.Event()
        calls = []
        def command():
            calls.append(True)
            if len(calls) < 3:
                raise OSError(5, "Input/output error")
            stop.set()
            return [sys.executable, "-c", "pass"]
        self.assertEqual(supervise(command, self.status, self.heartbeat, stop,
                                   poll_interval=0.01, restart_delay=0.001), 0)
        self.assertEqual(len(calls), 3)
        self.assertEqual(json.loads(self.status.read_text())["state"], "stopped")

    def test_heartbeat_write_failure_is_not_raised_into_the_server(self):
        from unittest.mock import patch
        from sentinel_blue.controller_supervisor import heartbeat_writer
        beat = heartbeat_writer(self.heartbeat, object())
        with patch("sentinel_blue.controller_supervisor.write_private_json", side_effect=OSError(30, "Read-only")):
            beat()
        self.assertFalse(self.heartbeat.exists())
        beat = heartbeat_writer(self.heartbeat, object())
        beat()
        self.assertEqual(json.loads(self.heartbeat.read_text())["pid"], os.getpid())

    def test_stop_request_cleans_child_without_restart(self):
        stop = threading.Event()
        timer = threading.Timer(0.2, stop.set)
        timer.start()
        try:
            self.assertEqual(self.run_child("import time; time.sleep(30)", stop=stop), 0)
        finally:
            timer.cancel()
            timer.join()
        state = json.loads(self.status.read_text())
        self.assertEqual(state["reason"], "supervisor_stop_requested")
        self.assertEqual(state["restarts"], 0)

    def test_heartbeat_requires_current_child_and_both_live_loops(self):
        row = {"pid": 1234, "server": 20.0, "maintenance": 20.0}
        write_private_json(self.heartbeat, row)
        self.assertTrue(heartbeat_fresh(self.heartbeat, 1234, 19.0, 21.0))
        for changes in ({"pid": 1}, {"maintenance": 0.0}, {"server": 200.0},
                        {"server": True}, {"maintenance": "20"}):
            write_private_json(self.heartbeat, {**row, **changes})
            self.assertFalse(heartbeat_fresh(self.heartbeat, 1234, 19.0, 21.0))

    def test_changed_launch_authority_is_held_before_any_child(self):
        def changed():
            raise ValueError("profile changed")
        with self.assertRaisesRegex(ValueError, "profile changed"):
            supervise(changed, self.status, self.heartbeat, threading.Event())
        self.assertEqual(json.loads(self.status.read_text())["state"], "held")


if __name__ == "__main__":
    unittest.main()
