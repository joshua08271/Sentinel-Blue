"""R207-01..05 regression and boundary coverage. Real private state, no VM mutation."""
from __future__ import annotations
import copy
import hashlib
import json
import os
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from sentinel_blue import setup_redo
from sentinel_blue.controller import ControllerApp
from sentinel_blue.desktop_control import DesktopClient
from sentinel_blue.event_profile import EventProfile
from sentinel_blue.job_control import SetupPaused
from sentinel_blue.redo_governance import (CHECK_PATH, WorkerGuard, automatic_allowed, snapshot_hold, prepare_guard, check)
from sentinel_blue.restore_health import from_audit, validate, evidence, refusal
from sentinel_blue.restoration import RestorePointStore
from sentinel_blue.state import write_private_json
from sentinel_blue.store import Store
from sentinel_blue.telemetry_diagnostics import restore_point_issues, merge_health_diagnostics
from sentinel_blue.validation import validate_telemetry, ValidationError
from test_service_repair import repair_fixture, damage
from test_store_controller import _promote_integrity_baseline
from test_setup_redo_203 import Workspace, snapshot, health, repair, NOW
from redo_gate_fixture import live_client

class RedoPolicy208(Workspace):
    def broken(self, actions=()):
        return snapshot([health(state='unhealthy',native='failed')], actions)
    def eligible_state(self):
        state=setup_redo.load_state(self.workspace)
        state['seen_healthy']=['web.service'];state['unhealthy_since']={'web.service':NOW-181}
        setup_redo.save_state(self.workspace,state)
    def test_active_grant_blocks_auto(self):
        self.eligible_state();value=self.broken()
        value['change_grants']=[{'agent_id':'local-linux','expires_at':NOW+500,'revoked_at':None}]
        result=setup_redo.tick(self.workspace,value,now=NOW,launcher=self.launcher)
        self.assertEqual(result['units']['web.service']['status'],'held');self.assertFalse(self.launched)
    def test_active_grant_blocks_manual(self):
        self.eligible_state();value=self.broken()
        value['change_grants']=[{'agent_id':'local-linux','expires_at':NOW+500,'revoked_at':None}]
        with self.assertRaisesRegex(ValueError,'change grant'): setup_redo.manual_redo(self.workspace,value,now=NOW,launcher=self.launcher)
    def test_other_host_grant_does_not_block(self):
        self.eligible_state();value=self.broken()
        value['change_grants']=[{'agent_id':'another','expires_at':NOW+500,'revoked_at':None}]
        self.assertIn('launched',setup_redo.tick(self.workspace,value,now=NOW,launcher=self.launcher))
    def test_revoked_grant_is_not_active(self):
        self.eligible_state();value=self.broken()
        value['change_grants']=[{'agent_id':'local-linux','expires_at':NOW+500,'revoked_at':NOW-1}]
        self.assertIn('launched',setup_redo.tick(self.workspace,value,now=NOW,launcher=self.launcher))
    def test_expired_grant_is_not_active(self):
        self.eligible_state();value=self.broken()
        value['change_grants']=[{'agent_id':'local-linux','expires_at':NOW-1,'revoked_at':None}]
        self.assertIn('launched',setup_redo.tick(self.workspace,value,now=NOW,launcher=self.launcher))
    def test_missing_mode_does_not_grant_auto(self):
        self.eligible_state();value=self.broken();value['controller']['governance'].pop('autonomy_mode')
        self.assertNotIn('launched',setup_redo.tick(self.workspace,value,now=NOW,launcher=self.launcher))
    def test_missing_emergency_state_does_not_grant_auto(self):
        self.eligible_state();value=self.broken();value['controller']['governance'].pop('emergency_stopped')
        self.assertNotIn('launched',setup_redo.tick(self.workspace,value,now=NOW,launcher=self.launcher))
    def test_approval_mode_blocks_auto(self):
        self.eligible_state();value=self.broken();value['controller']['governance']['autonomy_mode']='approval-based'
        self.assertNotIn('launched',setup_redo.tick(self.workspace,value,now=NOW,launcher=self.launcher))
    def test_observe_mode_blocks_manual(self):
        self.eligible_state();value=self.broken();value['controller']['governance']['autonomy_mode']='observe'
        with self.assertRaisesRegex(ValueError,'governance'): setup_redo.manual_redo(self.workspace,value,now=NOW,launcher=self.launcher)
    def test_original_approval_does_not_grow(self):
        self.eligible_state();value=self.broken()
        self.assertNotIn('launched',setup_redo.tick(self.workspace,value,now=NOW,automatic=False,launcher=self.launcher))
    def test_dirty_rollback_never_expires(self):
        self.eligible_state()
        for age in (901,3601,31*86400):
            with self.subTest(age=age):
                item=repair(rolled_back=False,rollback_failed=True,completed=NOW-age,created=NOW-age-10)
                value=self.broken([item]);result=setup_redo.tick(self.workspace,value,now=NOW,launcher=self.launcher)
                self.assertEqual(result['units']['web.service']['status'],'held');self.assertFalse(self.launched)
    def test_newer_clean_failure_does_not_hide_old_dirty(self):
        self.eligible_state();value=self.broken([repair(rolled_back=False,rollback_failed=True,completed=NOW-901,created=NOW-902),repair()])
        self.assertNotIn('launched',setup_redo.tick(self.workspace,value,now=NOW,launcher=self.launcher))
    def test_old_unknown_outcome_stays_held(self):
        self.eligible_state();value=self.broken([repair(status='outcome_unknown',created=NOW-99999)])
        self.assertNotIn('launched',setup_redo.tick(self.workspace,value,now=NOW,launcher=self.launcher))
    def test_clean_rollback_still_allows_redo(self):
        self.eligible_state();self.assertIn('launched',setup_redo.tick(self.workspace,self.broken([repair()]),now=NOW,launcher=self.launcher))
    def test_stale_policy_holds(self):
        self.eligible_state();value=self.broken()
        value['controller']['setup_redo_policy']={'complete':True,'observed_at':NOW-31}
        self.assertEqual(setup_redo.assess(value,self.record,setup_redo.load_state(self.workspace),NOW)['units']['web.service']['status'],'held')
    def test_production_redo_requires_live_connection(self):
        with self.assertRaises(SetupPaused):setup_redo.launch_redo(self.workspace,self.record,setup_redo.load_state(self.workspace),['web.service'],'test')

class ControllerGate208(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='sb208-');self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name)
        self.path=self.root/'config';self.path.write_bytes(b'trusted');self.path.chmod(0o600)
        self.profile,self.base=repair_fixture(str(self.path));self.base['observed_at']=time.time()
        self.app,self.db,self.client=live_client(self,self.profile,self.base)
        _promote_integrity_baseline(self.app,self.db,'agent-one')
        self.req={'profile_fingerprint':self.profile.fingerprint,'services':[['agent-one','web.service']],'automated':True}
    def insert_dirty(self,name='dirty',service='web.service',age=1000):
        now=time.time()-age
        # Explicitly modeled failed native action. No native mutation is executed.
        self.db._connection.execute("INSERT INTO actions(action_id,agent_id,action_type,parameters_json,status,created_at,completed_at,result_json) VALUES(?,?,?,?,?,?,?,?)",
            (name,'agent-one','repair_service',json.dumps({'service':service}),'failed',now-5,now,json.dumps({'success':False,'rolled_back':False,'review_required':True,'errors':['start','rollback']})))
        self.db._connection.commit()
    def test_real_signed_endpoint_accepts_current_scope(self):
        self.assertTrue(self.client.request(CHECK_PATH,self.req)['allowed'])
    def test_real_signed_endpoint_rejects_mode_downgrade(self):
        self.app.set_autonomy_mode('approval-based');self.assertFalse(self.client.request(CHECK_PATH,self.req)['allowed'])
    def test_manual_request_allowed_in_approval_mode(self):
        self.app.set_autonomy_mode('approval-based');self.assertTrue(self.client.request(CHECK_PATH,{**self.req,'automated':False})['allowed'])
    def test_observe_denies_manual(self):
        self.app.set_autonomy_mode('observe');self.assertFalse(self.client.request(CHECK_PATH,{**self.req,'automated':False})['allowed'])
    def test_real_signed_endpoint_rejects_emergency(self):
        self.app.emergency_stop();self.assertFalse(self.client.request(CHECK_PATH,self.req)['allowed'])
    def test_unknown_service_refused(self):
        value={**self.req,'services':[['agent-one','other.service']]};self.assertFalse(self.client.request(CHECK_PATH,value)['allowed'])
    def test_wrong_profile_refused(self):
        with self.assertRaises(Exception):self.client.request(CHECK_PATH,{**self.req,'profile_fingerprint':'0'*64})
    def test_unsigned_endpoint_refused(self):
        import http.client
        from urllib.parse import urlsplit
        parsed=urlsplit(self.client.origin);c=http.client.HTTPConnection(parsed.hostname,parsed.port,timeout=5)
        self.addCleanup(c.close);c.request('POST',CHECK_PATH,json.dumps(self.req),{'Content-Type':'application/json'})
        self.assertIn(c.getresponse().status,(401,403))
    def test_wrong_operator_key_refused(self):
        bad=DesktopClient(self.client.origin,'operator',1,'x'*48)
        with self.assertRaises(Exception):bad.request(CHECK_PATH,self.req)
    def test_grant_is_read_beyond_dashboard_limit(self):
        self.app.authorize_change({'agent_id':'agent-one','path':str(self.path),'ttl_seconds':600})
        for n in range(110):self.db.create_change_grant('other',f'/tmp/{n}',600)
        self.assertFalse(self.client.request(CHECK_PATH,self.req)['allowed'])
    def test_dirty_failure_is_read_beyond_dashboard_limit(self):
        self.insert_dirty()
        for n in range(110):
            self.db._connection.execute("INSERT INTO actions(action_id,agent_id,action_type,parameters_json,status,created_at) VALUES(?,?,?,?,?,?)",
                (f'noise{n}','agent-one','observe','{}','completed',time.time()))
        self.db._connection.commit()
        self.assertFalse(self.client.request(CHECK_PATH,self.req)['allowed'])
    def test_dirty_failure_retained_past_prune(self):
        self.insert_dirty(age=90*86400);self.db.prune(30)
        self.assertIsNotNone(self.db.get_action('dirty'));self.assertFalse(self.client.request(CHECK_PATH,self.req)['allowed'])
    def test_worker_rechecks_late_grant(self):
        path=prepare_guard(self.client,self.root/'job',self.req['services'],True,self.profile)
        guard=WorkerGuard({'redo_guard_file':path,'only_services':self.req['services']},self.profile)
        self.app.authorize_change({'agent_id':'agent-one','path':str(self.path),'ttl_seconds':600})
        with self.assertRaisesRegex(SetupPaused,'change grant'):guard.checkpoint()
    def test_worker_rechecks_late_mode_change(self):
        path=prepare_guard(self.client,self.root/'job',self.req['services'],True,self.profile)
        guard=WorkerGuard({'redo_guard_file':path,'only_services':self.req['services']},self.profile)
        self.app.set_autonomy_mode('approval-based')
        with self.assertRaises(SetupPaused):guard.checkpoint()
    def test_worker_connection_is_private(self):
        path=Path(prepare_guard(self.client,self.root/'job',self.req['services'],True,self.profile))
        self.assertEqual(path.stat().st_mode & 0o777,0o600);self.assertEqual(path.parent.stat().st_mode & 0o777,0o700)
    def test_worker_missing_reference_fails_closed(self):
        with self.assertRaises(SetupPaused):WorkerGuard({},self.profile)
    def test_worker_refuses_changed_scope(self):
        path=prepare_guard(self.client,self.root/'job',self.req['services'],True,self.profile)
        with self.assertRaises(SetupPaused):WorkerGuard({'redo_guard_file':path,'only_services':[['agent-one','other.service']]},self.profile)
    def test_live_connection_error_is_a_hold(self):
        broken=SimpleNamespace(request=lambda *args: (_ for _ in ()).throw(TimeoutError()))
        with self.assertRaises(SetupPaused):check(broken,self.req)
    def test_live_response_cannot_widen_scope(self):
        broken=SimpleNamespace(request=lambda *args: {**self.req,'services':[['other','web.service']],'allowed':True})
        with self.assertRaises(SetupPaused):check(broken,self.req)
    def test_unresolved_failure_does_not_clear_from_healthy_snapshot(self):
        self.insert_dirty();self.assertFalse(self.client.request(CHECK_PATH,self.req)['allowed'])
        self.app.dashboard();self.assertFalse(self.client.request(CHECK_PATH,self.req)['allowed'])
    def test_verified_operator_recovery_preserves_failure(self):
        self.insert_dirty();sample=copy.deepcopy(self.base);sample.update(sequence=2,observed_at=time.time())
        self.app.ingest(sample)
        value=self.app.close_recovered_incident('agent-one','web.service','operator_verified_recovery')
        self.assertEqual(value.get('reconciled_redo_holds'),1,value)
        self.assertEqual(self.db.get_action('dirty')['status'],'failed')
        self.assertTrue(self.client.request(CHECK_PATH,self.req)['allowed'])
    def test_broken_files_cannot_release_hold(self):
        self.insert_dirty();sample=damage(self.base,2);sample['observed_at']=time.time();self.app.ingest(sample)
        result=self.app.close_recovered_incident('agent-one','web.service','operator_verified_recovery')
        self.assertEqual(result['closed'],0);self.assertFalse(self.client.request(CHECK_PATH,self.req)['allowed'])
    def test_new_failure_not_covered_by_old_reconciliation(self):
        self.insert_dirty();sample=copy.deepcopy(self.base);sample.update(sequence=2,observed_at=time.time());self.app.ingest(sample)
        self.app.close_recovered_incident('agent-one','web.service','operator_verified_recovery')
        self.insert_dirty('another');self.assertFalse(self.client.request(CHECK_PATH,self.req)['allowed'])
    def test_modified_failure_does_not_reuse_receipt(self):
        self.insert_dirty();sample=copy.deepcopy(self.base);sample.update(sequence=2,observed_at=time.time());self.app.ingest(sample)
        self.app.close_recovered_incident('agent-one','web.service','operator_verified_recovery')
        self.db._connection.execute("UPDATE actions SET result_json=? WHERE action_id='dirty'",(json.dumps({'review_required':True,'errors':['changed']}),));self.db._connection.commit()
        self.assertFalse(self.client.request(CHECK_PATH,self.req)['allowed'])

    def test_modified_failure_stays_held_after_prune(self):
        self.insert_dirty(age=90*86400)
        sample=copy.deepcopy(self.base);sample.update(sequence=2,observed_at=time.time());self.app.ingest(sample)
        self.app.close_recovered_incident('agent-one','web.service','operator_verified_recovery')
        self.db._connection.execute("UPDATE actions SET result_json=? WHERE action_id='dirty'",(json.dumps({'review_required':True,'errors':['changed']}),));self.db._connection.commit()
        self.db.prune(30)
        self.assertIsNotNone(self.db.get_action('dirty'))
        self.assertFalse(self.client.request(CHECK_PATH,self.req)['allowed'])
    def test_failed_repair_evidence_retained_after_verified_recovery(self):
        self.insert_dirty(age=90*86400)
        sample=copy.deepcopy(self.base);sample.update(sequence=2,observed_at=time.time());self.app.ingest(sample)
        self.app.close_recovered_incident('agent-one','web.service','operator_verified_recovery')
        self.db.prune(30)
        self.assertEqual(self.db.get_action('dirty')['status'],'failed')
        self.assertTrue(self.client.request(CHECK_PATH,self.req)['allowed'])
    def test_stale_agent_cannot_admit_redo(self):
        with patch('sentinel_blue.controller.time.time',return_value=time.time()+300):
            self.assertFalse(self.app.check_setup_redo(self.req)['allowed'])
    def test_unknown_outcome_cannot_be_released_as_failed_repair(self):
        self.insert_dirty();self.db._connection.execute("UPDATE actions SET status='outcome_unknown' WHERE action_id='dirty'");self.db._connection.commit()
        sample=copy.deepcopy(self.base);sample.update(sequence=2,observed_at=time.time());self.app.ingest(sample)
        result=self.app.close_recovered_incident('agent-one','web.service','operator_verified_recovery')
        self.assertEqual(result['reconciled_redo_holds'],0)
        self.assertFalse(self.client.request(CHECK_PATH,self.req)['allowed'])
    def test_maintenance_still_holds_after_verified_recovery(self):
        self.insert_dirty();sample=copy.deepcopy(self.base);sample.update(sequence=2,observed_at=time.time());self.app.ingest(sample)
        self.app.close_recovered_incident('agent-one','web.service','operator_verified_recovery')
        self.app.authorize_change({'agent_id':'agent-one','path':str(self.path),'ttl_seconds':600})
        self.assertFalse(self.client.request(CHECK_PATH,self.req)['allowed'])
    def test_receipt_table_is_an_explicit_recovery_extension(self):
        from sentinel_blue.recovery import CONTROLLER_ALLOWED_TABLES, CONTROLLER_REQUIRED_TABLES
        self.assertIn('redo_recovery_receipts', CONTROLLER_ALLOWED_TABLES)
        self.assertNotIn('redo_recovery_receipts', CONTROLLER_REQUIRED_TABLES)
        self.db.initialize_recovery_identity()
        self.assertIsNotNone(self.db.recovery_identity())

class BackupEvidence208(unittest.TestCase):
    def test_long_identifier_survives_display_truncation(self):
        path='/'+'a'*300;sample={};merge_health_diagnostics(sample,restore_point_issues({'lost':[path]}))
        self.assertEqual(sample['restore_point_health']['lost'],[path]);self.assertLessEqual(len(sample['collector_errors'][0]),256)
        self.assertIsNotNone(refusal(sample,[path]));self.assertIsNone(refusal(sample,['/other']))
    def test_healthy_empty_report_is_explicit(self):
        sample={};merge_health_diagnostics(sample,restore_point_issues({}));self.assertTrue(sample['restore_point_health']['complete'])
        self.assertEqual(sample['collector_errors'],[])
    def test_lost_key_blocks_all_restoring_files_only(self):
        sample={};merge_health_diagnostics(sample,restore_point_issues({'lost':['/state/manifest'],'metadata_errors':['key missing']}))
        self.assertIsNotNone(refusal(sample,['/web.conf']));self.assertIsNone(refusal(sample,[]))
    def test_unrelated_missing_backup_does_not_block(self):
        sample={};merge_health_diagnostics(sample,restore_point_issues({'lost':['/other.conf']}))
        self.assertIsNone(refusal(sample,['/web.conf']))
    def test_report_survives_diagnostic_saturation(self):
        sample={'collector_errors':['error']*256,'collector_issue_sources':['network_inventory']*256}
        merge_health_diagnostics(sample,restore_point_issues({'lost':['/'+'x'*307]}))
        self.assertEqual(len(sample['collector_errors']),256);self.assertEqual(len(sample['restore_point_health']['lost'][0]),308)
    def test_concatenation_preserves_report(self):
        sample={};merge_health_diagnostics(sample,['some health issue']+restore_point_issues({'lost':['/file']}))
        self.assertEqual(sample['restore_point_health']['lost'],['/file'])
    def test_conflicting_reports_hold(self):
        sample={};merge_health_diagnostics(sample,restore_point_issues({'lost':['/a']})+restore_point_issues({'lost':['/b']}))
        self.assertIsNotNone(refusal(sample,['/other']))
    def test_path_count_overflow_is_incomplete(self):
        report=from_audit({'lost':[f'/{i}' for i in range(2050)]});self.assertFalse(report['complete']);self.assertEqual(len(report['lost']),2048)
    def test_byte_limit_is_incomplete(self):
        report=from_audit({'lost':['/'+str(i)+'x'*2000 for i in range(200)]});self.assertFalse(report['complete']);validate(report)
    def test_invalid_path_is_not_shortened(self):
        for path in ('x'*4097,'/x\x00y','/x\ny'):
            with self.subTest(path=path[:12]):
                report=from_audit({'lost':[path]});self.assertFalse(report['complete']);self.assertFalse(report['lost'])
    def test_schema_rejects_duplicates(self):
        with self.assertRaises(ValueError):validate({**from_audit({}),'lost':['/a','/a']})
    def test_schema_rejects_unsupported_version(self):
        with self.assertRaises(ValueError):validate({**from_audit({}),'schema':2})
    def test_schema_rejects_boolean_schema(self):
        with self.assertRaises(ValueError):validate({**from_audit({}),'schema':True})
    def test_schema_rejects_extra_fields(self):
        with self.assertRaises(ValueError):validate({**from_audit({}),'all_safe':True})
    def test_schema_rejects_invalid_complete(self):
        with self.assertRaises(ValueError):validate({**from_audit({}),'complete':'yes'})
    def test_legacy_loss_is_conservative_not_path_parsing(self):
        sample={'collector_errors':['restore point lost: /short'],'collector_issue_sources':['restore_points']}
        self.assertFalse(evidence(sample)['complete']);self.assertIsNotNone(refusal(sample,['/anything']))
    def test_unknown_or_tampered_structured_report_holds(self):
        self.assertIsNotNone(refusal({'restore_point_health':{}},['/x']))
    def test_generic_network_warning_does_not_hold_backup(self):
        sample={'collector_errors':['unavailable ip tool'],'collector_issue_sources':['network_inventory']}
        self.assertIsNone(refusal(sample,['/x']))
    def test_telemetry_validator_preserves_full_identity(self):
        _,sample=repair_fixture();sample['restore_point_health']=from_audit({'lost':['/'+'x'*307]})
        result=validate_telemetry(sample);self.assertEqual(result['restore_point_health'],sample['restore_point_health'])
    def test_telemetry_validator_rejects_forged_coverage_shape(self):
        _,sample=repair_fixture();sample['restore_point_health']={'complete':True}
        with self.assertRaises(ValidationError):validate_telemetry(sample)

    def test_generator_preserves_errors_and_complete_identity(self):
        sample={};issues=restore_point_issues({'lost':['/'+'q'*310]})
        merge_health_diagnostics(sample,(x for x in issues))
        self.assertEqual(len(sample['collector_errors']),1)
        self.assertEqual(sample['restore_point_health']['lost'],['/'+'q'*310])

class RealBackup208(unittest.TestCase):
    def run_fault(self,fault,long=False):
        with tempfile.TemporaryDirectory(prefix='sb208-file-') as tmp:
            root=Path(tmp);target=root
            if long:target=target/('a'*100)/('b'*100)/('c'*70)
            target.mkdir(exist_ok=True,parents=True);path=target/'web.conf';path.write_bytes(b'trusted');path.chmod(0o600)
            profile,base=repair_fixture(str(path));db=Store(':memory:');self.addCleanup(db.close)
            app=ControllerApp(db,'t'*32,operator_token='o'*48,event_profile=profile,auto_recover_services=False)
            app.set_autonomy_mode('approval-based');app.ingest(base);_promote_integrity_baseline(app,db,'agent-one')
            rp=RestorePointStore(root/'backups',mirror=root/'ledger/mirror');self.assertTrue(rp.capture(base['integrity'])['success'])
            digest=base['integrity'][0]['sha256'];path.write_bytes(b'damaged')
            if fault=='key':rp._manifest_authority.key_path.unlink()
            elif fault=='metadata':rp._manifest_authority.local.unlink();rp._manifest_authority.remote.unlink()
            elif fault=='blobs':(rp.blobs/digest).unlink();(rp.mirror/digest).unlink()
            elif fault=='recoverable':rp.manifest_path.unlink();(rp.blobs/digest).unlink()
            current=damage(base,2);current['observed_at']=time.time();merge_health_diagnostics(current,restore_point_issues(rp.audit_backups()))
            app.ingest(current);offers=[x for x in app.dashboard()['alerts'] if x['status']=='open' and x['kind']=='service_repair_required']
            return current,offers
    def test_missing_auth_key_suppresses_offer(self):self.assertFalse(self.run_fault('key')[1])
    def test_missing_metadata_replicas_suppresses_offer(self):self.assertFalse(self.run_fault('metadata')[1])
    def test_long_path_missing_blobs_suppresses_offer(self):
        current,offers=self.run_fault('blobs',True);self.assertFalse(offers);self.assertGreater(len(current['restore_point_health']['lost'][0]),300)
    def test_short_path_missing_blobs_suppresses_offer(self):self.assertFalse(self.run_fault('blobs')[1])
    def test_recoverable_metadata_retains_offer(self):self.assertEqual(len(self.run_fault('recoverable')[1]),1)

    def test_earlier_offer_is_withdrawn_not_reported_repaired(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'config';path.write_bytes(b'trusted');path.chmod(0o600)
            profile,base=repair_fixture(str(path));db=Store(':memory:');self.addCleanup(db.close)
            app=ControllerApp(db,'t'*32,operator_token='o'*48,event_profile=profile,auto_recover_services=False)
            app.set_autonomy_mode('approval-based');app.ingest(base);_promote_integrity_baseline(app,db,'agent-one')
            current=damage(base,2);current['observed_at']=time.time();merge_health_diagnostics(current,restore_point_issues({}));app.ingest(current)
            previous=[r for r in app.dashboard()['alerts'] if r['kind']=='service_repair_required' and r['status']=='open']
            self.assertEqual(len(previous),1)
            current.update(sequence=3,observed_at=time.time());merge_health_diagnostics(current,restore_point_issues({'metadata_errors':['key missing']}));app.ingest(current)
            row=db.get_alert(previous[0]['alert_id']);self.assertEqual(row['decision'],'repair_offer_withdrawn_backup_unavailable')
            self.assertFalse(any(r['kind']=='service_repair_required' and r['status']=='open' for r in app.dashboard()['alerts']))

class MutationBoundary208(unittest.TestCase):
    def fixture(self,hosts=1):
        from test_setup import fixture
        from sentinel_blue.setup import compile_plan
        tmp=tempfile.TemporaryDirectory(prefix='sb208-boundary-');self.addCleanup(tmp.cleanup)
        root=Path(tmp.name);inventory,profile=fixture(root,hosts=hosts)
        app,db,client=live_client(self,profile)
        return root,inventory,profile,compile_plan(inventory,profile,root),app,db,client
    def run_gate_change(self,change):
        from test_setup import FixtureTransport, healthy_probe
        from sentinel_blue.setup import SetupRunner, plan_digest
        root,inv,profile,plan,app,db,client=self.fixture()
        pairs=[['host-0','web']]
        ref=prepare_guard(client,root/'job',pairs,False,profile)
        guard=WorkerGuard({'redo_guard_file':ref,'only_services':pairs},profile,plan)
        transport=FixtureTransport();execute=transport.execute
        def changed(host,script,seconds):
            result=execute(host,script,seconds)
            if script.startswith('# check'):
                if change=='mode':app.set_autonomy_mode('observe')
                elif change=='grant':app.authorize_change({'agent_id':'host-0','path':'/etc/web.conf','ttl_seconds':600})
                elif change=='disconnect':guard.client.request=lambda *a: (_ for _ in ()).throw(TimeoutError())
            return result
        transport.execute=changed
        with patch('sentinel_blue.mutation_tracking.active',return_value=False):
            report=SetupRunner(plan,profile,transport=transport,probe=healthy_probe,checkpoint=guard.checkpoint).execute(root/'state',plan_digest(plan),only_services=pairs,redo=True)
        self.assertEqual(transport.applies,[],report)
        self.assertEqual(report['tasks']['host-0']['status'],'paused',report)
    def test_grant_after_native_precheck_prevents_apply(self):self.run_gate_change('grant')
    def test_observe_after_native_precheck_prevents_apply(self):self.run_gate_change('mode')
    def test_connection_failure_after_precheck_prevents_apply(self):self.run_gate_change('disconnect')
    def test_dependency_host_is_in_live_permission_scope(self):
        from sentinel_blue.setup import compile_plan
        root,inv,profile,plan,app,db,client=self.fixture(hosts=2)
        inv['setup']['tasks'][1]['requires']=['host-0'];plan=compile_plan(inv,profile,root)
        pairs=[['host-1','web']]
        ref=prepare_guard(client,root/'job',pairs,False,profile)
        app.authorize_change({'agent_id':'host-0','path':'/etc/dependency.conf','ttl_seconds':600})
        with self.assertRaisesRegex(SetupPaused,'change grant'):
            WorkerGuard({'redo_guard_file':ref,'only_services':pairs},profile,plan)
    def test_unchanged_live_policy_still_allows_apply(self):
        from test_setup import FixtureTransport, healthy_probe
        from sentinel_blue.setup import SetupRunner, plan_digest
        root,inv,profile,plan,app,db,client=self.fixture()
        pairs=[['host-0','web']];ref=prepare_guard(client,root/'job',pairs,False,profile)
        guard=WorkerGuard({'redo_guard_file':ref,'only_services':pairs},profile,plan)
        transport=FixtureTransport()
        with patch('sentinel_blue.mutation_tracking.active',return_value=False):
            report=SetupRunner(plan,profile,transport=transport,probe=healthy_probe,checkpoint=guard.checkpoint).execute(root/'state',plan_digest(plan),only_services=pairs,redo=True)
        self.assertEqual(transport.applies,['host-0']);self.assertEqual(report['status'],'ready',report)

if __name__=='__main__':unittest.main()
