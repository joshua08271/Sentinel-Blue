"""Named Linux service faults instead of an unknown one (issue #13).

The service manager already records why a unit stopped, and the agent already
collects that verdict, its exit status, sub-state and restart counter, plus every
listening port. None of it reached diagnosis: a scored service systemd was
refusing to start looked exactly like one that had simply been stopped, and
recovery spent its attempt budget on restarts that could not succeed.

These tests fix the boundary in both directions. A plain crash must still be
restarted automatically; a fault a restart cannot fix must be named and held.
"""

import copy
import time
import unittest

from sentinel_blue.desktop_control import service_rows
from sentinel_blue.recovery_reasoning import CHECKS, DOMAINS, reason_recovery
from sentinel_blue.service_recovery import ServiceRecoveryPlanner, recovery_parameters
from sentinel_blue.service_repair import (
    NATIVE_FAULT_CODES, RESTART_FUTILE_CODES, declared_local_ports, diagnose_service,
    local_probe_port, native_fault_findings, port_conflict_findings, repair_parameters,
    restart_blockers, restart_futility)

from test_autonomous_service_recovery import fixtures, stopped
from test_service_manifest_policy import profile_for, service_manifest


LOCAL_HTTP = {"name": "local-web", "kind": "http", "target": "http://127.0.0.1:8080/health"}


def codes(findings):
    return [item["code"] for item in findings]


def failed(baseline, sequence=2, **service):
    """A stopped service carrying the service manager's failure verdict."""
    value = stopped(baseline, sequence)
    value["services"][0].update({"state": "failed", **service})
    return value


def local_fixture(path="/etc/web.conf"):
    """A manifest whose scored transaction is a loopback port on this host."""
    profile, baseline = fixtures(path)
    manifest = copy.deepcopy(profile.services[0])
    manifest["expected_transactions"] = [LOCAL_HTTP]
    baseline["probes"] = [{"name": "local-web", "target": LOCAL_HTTP["target"], "healthy": True}]
    baseline["listeners"] = []
    return profile_for([manifest]), baseline


class NativeVerdictTests(unittest.TestCase):
    """Each verdict the service manager can record maps to one named cause."""

    def finding(self, **service):
        current = {"name": "web.service", "state": "failed", "substate": "failed", **service}
        return native_fault_findings("web.service", current, {"restart_count": 0})

    def test_every_recorded_verdict_is_named(self):
        expected = {
            "start-limit-hit": "service_start_refused_by_limit",
            "oom-kill": "service_killed_for_memory",
            "resources": "host_resources_exhausted",
            "signal": "service_killed_by_signal",
            "core-dump": "service_killed_by_signal",
            "timeout": "service_start_timed_out",
            "watchdog": "service_watchdog_timeout",
            "protocol": "service_startup_protocol_violation",
        }
        for verdict, code in expected.items():
            with self.subTest(verdict=verdict):
                self.assertEqual(codes(self.finding(result=verdict)), [code])
        self.assertEqual(NATIVE_FAULT_CODES["exit-code"], "service_exited_with_error")

    def test_a_nonzero_exit_is_an_application_error(self):
        findings = self.finding(result="exit-code", exit_code=78)
        self.assertEqual(codes(findings), ["service_exited_with_error"])
        self.assertEqual(findings[0]["evidence"]["exit_code"], 78)

    def test_a_zero_exit_is_a_startup_contract_fault_not_an_application_error(self):
        # systemd records `exit-code` with status 0 when the main process
        # succeeded but the unit's type contract was never met. Restarting the
        # program is pointless; the unit definition is what is wrong.
        for value in (0, None):
            with self.subTest(exit_code=value):
                self.assertEqual(codes(self.finding(result="exit-code", exit_code=value)),
                                 ["service_startup_protocol_violation"])

    def test_an_unrecognized_verdict_stays_unknown_rather_than_guessing(self):
        findings = self.finding(result="some-future-systemd-verdict")
        self.assertEqual(codes(findings), ["native_failure_reason_unrecognized"])
        self.assertEqual(findings[0]["evidence"]["native_result"], "some-future-systemd-verdict")

    def test_a_healthy_or_absent_verdict_says_nothing(self):
        for value in ("success", "unknown", ""):
            with self.subTest(result=value):
                self.assertEqual(self.finding(result=value), [])

    def test_a_running_unit_does_not_report_its_last_failure_as_current(self):
        # `Result=` keeps the previous failure until the unit starts again.
        current = {"name": "web.service", "state": "running", "substate": "running",
                   "result": "exit-code", "exit_code": 1}
        self.assertEqual(native_fault_findings("web.service", current, {}, running=True), [])
        self.assertEqual(codes(native_fault_findings("web.service", current, {})),
                         ["service_exited_with_error"])

    def test_verdict_text_is_bounded_and_never_executed(self):
        findings = self.finding(result="x" * 400)
        self.assertLessEqual(len(findings[0]["evidence"]["native_result"]), 128)


class RestartLoopTests(unittest.TestCase):
    def test_the_service_manager_cycling_a_unit_is_a_loop(self):
        current = {"name": "web.service", "state": "activating", "substate": "auto-restart",
                   "result": "exit-code", "exit_code": 1, "restart_count": 5}
        findings = native_fault_findings("web.service", current, {"restart_count": 4})
        self.assertEqual(codes(findings), ["service_restart_looping", "service_exited_with_error"])
        self.assertEqual(findings[0]["evidence"]["restarts"], 5)

    def test_a_climbing_counter_is_a_loop_even_between_cycles(self):
        current = {"name": "web.service", "state": "failed", "substate": "failed", "restart_count": 9}
        self.assertEqual(codes(native_fault_findings("web.service", current, {"restart_count": 6})),
                         ["service_restart_looping"])

    def test_one_or_two_restarts_are_not_a_loop(self):
        current = {"name": "web.service", "state": "failed", "substate": "failed", "restart_count": 2}
        self.assertEqual(native_fault_findings("web.service", current, {"restart_count": 0}), [])

    def test_malformed_counters_never_raise(self):
        for pair in (("many", 0), (5, "none"), (None, None)):
            with self.subTest(pair=pair):
                current = {"name": "web.service", "state": "failed", "restart_count": pair[0]}
                self.assertEqual(native_fault_findings("web.service", current,
                                                       {"restart_count": pair[1]}), [])


class DeclaredPortTests(unittest.TestCase):
    def test_a_loopback_url_port_is_derived(self):
        self.assertEqual(local_probe_port(LOCAL_HTTP), 8080)
        self.assertEqual(local_probe_port({"kind": "http", "target": "http://127.0.0.1/"}), 80)
        self.assertEqual(local_probe_port({"kind": "https", "target": "https://127.0.0.1/"}), 443)

    def test_an_explicit_port_wins(self):
        self.assertEqual(local_probe_port({"kind": "tcp", "target": "127.0.0.1", "port": 3306}), 3306)

    def test_an_external_target_is_never_this_hosts_port(self):
        self.assertIsNone(local_probe_port({"kind": "http", "target": "http://192.0.2.10/health"}))
        self.assertIsNone(local_probe_port({"kind": "tcp", "target": "192.0.2.10", "port": 443}))

    def test_an_unstated_port_is_not_guessed(self):
        for spec in ({"kind": "tcp", "target": "127.0.0.1"},
                     {"kind": "dns", "target": "127.0.0.1"},
                     {"kind": "http", "target": "ftp://127.0.0.1/"},
                     {"kind": "tcp", "target": "127.0.0.1", "port": 0},
                     {"kind": "tcp", "target": "127.0.0.1", "port": "8080"},
                     "not-a-spec"):
            with self.subTest(spec=spec):
                self.assertIsNone(local_probe_port(spec))

    def test_ports_are_deduplicated_and_ordered(self):
        manifest = {"expected_transactions": [
            {"kind": "tcp", "target": "127.0.0.1", "port": 443},
            LOCAL_HTTP,
            {"kind": "tcp", "target": "127.0.0.1", "port": 443},
            {"kind": "http", "target": "http://192.0.2.10/"},
        ]}
        self.assertEqual(declared_local_ports(manifest), [443, 8080])


class PortConflictTests(unittest.TestCase):
    manifest = {"expected_transactions": [LOCAL_HTTP]}

    def conflict(self, **listener):
        row = {"protocol": "tcp", "address": "0.0.0.0", "port": 8080, "process": "", **listener}
        return port_conflict_findings("web.service", self.manifest, {"listeners": [row]})

    def test_a_foreign_listener_on_the_declared_port_blocks_the_bind(self):
        findings = self.conflict(process='users:(("nc",pid=4242,fd=3))')
        self.assertEqual(codes(findings), ["listening_port_occupied"])
        self.assertEqual(findings[0]["evidence"]["port"], 8080)
        self.assertIn("4242", findings[0]["evidence"]["holder"])

    def test_matching_ipv4_loopback_and_wildcard_listeners_conflict(self):
        for address in ("0.0.0.0", "127.0.0.1", "[127.0.0.1]"):
            with self.subTest(address=address):
                self.assertEqual(codes(self.conflict(address=address)), ["listening_port_occupied"])

    def test_a_different_hosts_address_does_not_conflict(self):
        self.assertEqual(self.conflict(address="192.0.2.10"), [])

    def test_a_udp_listener_does_not_block_a_tcp_bind(self):
        self.assertEqual(self.conflict(protocol="udp"), [])

    def test_another_port_is_not_this_services_problem(self):
        self.assertEqual(self.conflict(port=9090), [])

    def test_socket_activation_is_reported_separately(self):
        # A .socket unit legitimately holds the port while its service is
        # inactive. Naming it as an attacker's listener would be wrong.
        findings = self.conflict(process='users:(("systemd",pid=1,fd=34))')
        self.assertEqual(codes(findings), ["socket_activation_holds_port"])
        self.assertNotIn("socket_activation_holds_port", RESTART_FUTILE_CODES)

    def test_an_unattributed_listener_is_still_reported(self):
        findings = self.conflict(process="")
        self.assertEqual(findings[0]["evidence"]["holder"], "unattributed")

    def test_holder_text_is_bounded(self):
        findings = self.conflict(process="u" * 4000)
        self.assertLessEqual(len(findings[0]["evidence"]["holder"]), 200)

    def test_one_finding_per_declared_port(self):
        telemetry = {"listeners": [
            {"protocol": "tcp", "address": "0.0.0.0", "port": 8080, "process": "a"},
            {"protocol": "tcp", "address": "127.0.0.1", "port": 8080, "process": "b"},
        ]}
        self.assertEqual(len(port_conflict_findings("web.service", self.manifest, telemetry)), 1)

    def test_malformed_listener_telemetry_never_raises(self):
        for value in ({"listeners": "unavailable"}, {"listeners": [None, 7, {}]}, {}):
            with self.subTest(value=value):
                self.assertEqual(port_conflict_findings("web.service", self.manifest, value), [])

    def test_a_running_service_is_not_accused_of_holding_its_own_port(self):
        current = {"name": "web.service", "state": "running", "substate": "running"}
        telemetry = {"listeners": [{"protocol": "tcp", "address": "0.0.0.0", "port": 8080,
                                    "process": 'users:(("nginx",pid=9,fd=6))'}]}
        self.assertEqual(restart_blockers("web.service", self.manifest, current, {}, telemetry), [])


class FutilityBoundaryTests(unittest.TestCase):
    """Which faults hold a restart, and — just as important — which do not."""

    def reason(self, code, evidence=None):
        return restart_futility([{"code": code, "subject": "web.service",
                                  "evidence": evidence or {}}])

    def test_a_futile_restart_is_named(self):
        for code in RESTART_FUTILE_CODES:
            with self.subTest(code=code):
                self.assertTrue(self.reason(code))

    def test_a_plain_crash_is_still_restartable(self):
        for code in ("service_exited_with_error", "service_killed_by_signal",
                     "service_start_timed_out", "service_watchdog_timeout",
                     "service_startup_protocol_violation", "socket_activation_holds_port",
                     "native_failure_reason_unrecognized", "service_stopped"):
            with self.subTest(code=code):
                self.assertEqual(self.reason(code), "")

    def test_a_port_conflict_names_the_port(self):
        self.assertIn("port 8080", self.reason("listening_port_occupied", {"port": 8080}))

    def test_the_first_blocking_cause_is_the_reason(self):
        reason = restart_futility([{"code": "service_exited_with_error"},
                                   {"code": "service_killed_for_memory"},
                                   {"code": "host_resources_exhausted"}])
        self.assertEqual(reason, RESTART_FUTILE_CODES["service_killed_for_memory"])


class DiagnosisTests(unittest.TestCase):
    def test_a_stopped_service_now_carries_its_cause(self):
        profile, baseline = local_fixture()
        current = failed(baseline, result="start-limit-hit")
        diagnosis = diagnose_service(profile, "agent-one", "web.service", baseline, current)
        self.assertEqual(codes(diagnosis["findings"])[:2],
                         ["service_stopped", "service_start_refused_by_limit"])

    def test_the_headline_state_finding_is_unchanged(self):
        # Existing operators and stored history key on this code; the cause is
        # added beside it, never in place of it.
        profile, baseline = local_fixture()
        self.assertEqual(
            diagnose_service(profile, "agent-one", "web.service", baseline,
                             failed(baseline, result="oom-kill"))["code"], "service_stopped")

    def test_an_activating_unit_is_no_longer_simply_unknown(self):
        profile, baseline = local_fixture()
        current = failed(baseline, state="activating", substate="auto-restart", restart_count=7)
        found = codes(diagnose_service(profile, "agent-one", "web.service", baseline,
                                       current)["findings"])
        self.assertIn("native_state_unknown", found)
        self.assertIn("service_restart_looping", found)

    def test_an_occupied_port_reaches_diagnosis(self):
        profile, baseline = local_fixture()
        current = failed(baseline)
        current["listeners"] = [{"protocol": "tcp", "address": "0.0.0.0", "port": 8080,
                                 "process": 'users:(("nc",pid=4242,fd=3))'}]
        self.assertIn("listening_port_occupied",
                      codes(diagnose_service(profile, "agent-one", "web.service",
                                             baseline, current)["findings"]))

    def test_a_healthy_service_reports_no_fault(self):
        profile, baseline = local_fixture()
        self.assertEqual(diagnose_service(profile, "agent-one", "web.service",
                                          baseline, baseline)["code"], "healthy")

    def test_every_new_code_has_a_planner_domain_and_real_checks(self):
        produced = set(NATIVE_FAULT_CODES.values()) | set(RESTART_FUTILE_CODES) | {
            "socket_activation_holds_port", "native_failure_reason_unrecognized",
            "service_startup_protocol_violation"}
        for code in produced:
            with self.subTest(code=code):
                self.assertIn(code, DOMAINS)
                for check in DOMAINS[code][2]:
                    self.assertIn(check, CHECKS)


class RecoveryHoldTests(unittest.TestCase):
    """The executing paths, not only the report, refuse a futile restart."""

    def held(self, **service):
        profile, baseline = local_fixture()
        current = failed(baseline, **service)
        current["observed_at"] = time.time() - 1
        with self.assertRaises(ValueError) as error:
            recovery_parameters(profile, "agent-one", "web.service", baseline, current)
        return str(error.exception)

    def test_a_start_limit_holds_recovery_and_says_so(self):
        message = self.held(result="start-limit-hit")
        self.assertIn("refusing to start", message)
        self.assertIn("held for review", message)

    def test_a_memory_kill_holds_recovery(self):
        self.assertIn("host memory", self.held(result="oom-kill"))

    def test_host_resource_exhaustion_holds_recovery(self):
        self.assertIn("resources", self.held(result="resources"))

    def test_a_restart_loop_still_holds_recovery(self):
        self.assertIn("restarting this unit in a loop", self.held(restart_count=4))

    def test_a_cycling_unit_is_named_rather_than_called_an_unhandled_state(self):
        # The state check alone would refuse with "recovery requires an
        # explicitly stopped approved running service", which tells an operator
        # nothing about why the service is down.
        message = self.held(state="activating", substate="auto-restart", restart_count=1)
        self.assertIn("restarting this unit in a loop", message)

    def test_an_occupied_port_holds_recovery(self):
        profile, baseline = local_fixture()
        current = failed(baseline)
        current["observed_at"] = time.time() - 1
        current["listeners"] = [{"protocol": "tcp", "address": "0.0.0.0", "port": 8080,
                                 "process": 'users:(("nc",pid=4242,fd=3))'}]
        with self.assertRaisesRegex(ValueError, "port 8080"):
            recovery_parameters(profile, "agent-one", "web.service", baseline, current)

    def test_a_crash_is_still_recovered_automatically(self):
        profile, baseline = local_fixture()
        current = failed(baseline, result="exit-code", exit_code=1)
        current["observed_at"] = time.time() - 1
        parameters = recovery_parameters(profile, "agent-one", "web.service", baseline, current)
        self.assertEqual(parameters["service"], "web.service")

    def test_socket_activation_does_not_hold_recovery(self):
        profile, baseline = local_fixture()
        current = failed(baseline)
        current["observed_at"] = time.time() - 1
        current["listeners"] = [{"protocol": "tcp", "address": "0.0.0.0", "port": 8080,
                                 "process": 'users:(("systemd",pid=1,fd=34))'}]
        self.assertEqual(recovery_parameters(profile, "agent-one", "web.service",
                                             baseline, current)["service"], "web.service")

    def test_coordinated_repair_is_held_by_the_same_causes(self):
        profile, baseline = local_fixture()
        manifest = copy.deepcopy(profile.services[0])
        manifest["allowed_automatic_actions"] = [*manifest["allowed_automatic_actions"],
                                                 "repair_service"]
        # The fixture models an approved automatic repair and its required inverse.
        manifest["approval_actions"] = [*manifest["approval_actions"], "rollback_service_repair"]
        manifest["repair_policy"] = {"restore_files": ["/etc/web.conf"],
                                     "restart_unhealthy": True, "validation_timeout_seconds": 5}
        profile = profile_for([manifest])
        current = failed(baseline, result="start-limit-hit")
        current["observed_at"] = time.time() - 1
        with self.assertRaisesRegex(ValueError, "repair is held for review"):
            repair_parameters(profile, "agent-one", "web.service", baseline, current)


class OperatorDisplayTests(unittest.TestCase):
    """A stopped scored service must not be an unexplained red row."""

    def row(self, service, listeners=None):
        manifest = service_manifest(expected_transactions=[LOCAL_HTTP],
                                    automatic=["restart_service"])
        sample = {"agent_id": "agent-one", "observed_at": time.time(),
                  "services": [{"name": "web.service", **service}],
                  "listeners": list(listeners or []),
                  "probes": [{"name": "local-web", "target": LOCAL_HTTP["target"], "healthy": False}]}
        return service_rows([manifest], {"agent-one": sample},
                            [{"agent_id": "agent-one", "enabled": True}])[0]

    def test_the_cause_reaches_the_service_table(self):
        row = self.row({"state": "failed", "result": "oom-kill"})
        self.assertEqual(row["health"], "unhealthy")
        self.assertEqual(row["reason"], "it was killed for host memory")

    def test_an_exit_status_is_shown_with_the_cause(self):
        self.assertEqual(self.row({"state": "failed", "result": "exit-code", "exit_code": 78})["reason"],
                         "it exited with an error status (78)")

    def test_an_occupied_port_is_named_in_the_table(self):
        row = self.row({"state": "inactive"},
                       [{"protocol": "tcp", "address": "0.0.0.0", "port": 8080, "process": "nc"}])
        self.assertEqual(row["reason"], "another process holds its declared port (8080)")

    def test_a_long_lived_restart_counter_is_not_called_a_loop(self):
        # Without an approved baseline the counter is a lifetime total, not a
        # rate, so the table reads the sub-state instead of guessing.
        self.assertEqual(self.row({"state": "failed", "substate": "failed",
                                   "restart_count": 40})["reason"], "")
        self.assertEqual(self.row({"state": "activating", "substate": "auto-restart",
                                   "restart_count": 40})["reason"],
                         "the service manager is restarting it in a loop")

    def test_the_blocking_cause_outranks_an_incidental_one(self):
        # A crash exit status is true but not why the service will stay down.
        row = self.row({"state": "failed", "result": "exit-code", "exit_code": 1},
                       [{"protocol": "tcp", "address": "127.0.0.1", "port": 8080, "process": "nc"}])
        self.assertEqual(row["reason"], "another process holds its declared port (8080)")

    def test_a_service_with_no_recorded_cause_is_unchanged(self):
        self.assertEqual(self.row({"state": "stopped"})["reason"], "")

    def test_an_earlier_explanation_still_wins(self):
        manifest = service_manifest(expected_transactions=[LOCAL_HTTP], automatic=["restart_service"])
        rows = service_rows([manifest], {}, [{"agent_id": "agent-one", "enabled": True}])
        self.assertEqual(rows[0]["reason"], "no telemetry received from this agent yet")

    def test_a_running_service_is_never_given_a_stale_cause(self):
        self.assertEqual(self.row({"state": "running", "result": "exit-code",
                                   "exit_code": 1})["reason"], "")


class PlannerAndReportTests(unittest.TestCase):
    def observe(self, current):
        profile, baseline = local_fixture()
        planner = ServiceRecoveryPlanner(profile)
        first = copy.deepcopy(current)
        first.update(sequence=2, observed_at=time.time() - 2)
        second = copy.deepcopy(current)
        second.update(sequence=3, observed_at=time.time() - 1)
        planner.observe("agent-one", baseline, True, first)
        ready = planner.observe("agent-one", baseline, True, second)
        return planner, ready

    def test_a_futile_restart_is_never_queued_and_the_reason_is_visible(self):
        profile, baseline = local_fixture()
        planner, ready = self.observe(failed(baseline, result="start-limit-hit"))
        self.assertEqual(ready, {})
        row = planner.status()[0]
        self.assertIn("refusing to start", row["status"])
        self.assertIn("service_start_refused_by_limit", codes(row["diagnosis"]["findings"]))
        self.assertEqual(row["reasoning"]["state"], "held")

    def test_a_plain_crash_still_reaches_two_confirmations(self):
        profile, baseline = local_fixture()
        _planner, ready = self.observe(failed(baseline, result="exit-code", exit_code=1))
        self.assertIn("web.service", ready)

    def test_the_report_explains_the_cause_and_the_next_check(self):
        profile, baseline = local_fixture()
        current = failed(baseline, result="oom-kill")
        current["observed_at"] = time.time() - 1
        report = reason_recovery(profile, "agent-one", baseline, current, approved=True)
        row = report["services"][0]
        hypotheses = {item["evidence"]: item["domain"] for item in row["hypotheses"]}
        self.assertEqual(hypotheses["service_killed_for_memory"], "host_capacity")
        self.assertIn("host_capacity", [item["id"] for item in row["next_checks"]])
        self.assertEqual(row["state"], "held")
        self.assertIn("host memory", row["reason"])

    def test_a_dependency_fault_still_outranks_this_services_own_cause(self):
        web = copy.deepcopy(local_fixture()[0].services[0])
        web["dependencies"] = ["database.service"]
        database = service_manifest("database.service", required_files=["/etc/db.conf"],
                                    automatic=["restart_service"])
        profile = profile_for([web, database])
        _unused, baseline = local_fixture()
        baseline["services"].append({"name": "database.service", "state": "running"})
        current = failed(baseline, result="start-limit-hit")
        current["services"][1]["state"] = "stopped"
        diagnosis = diagnose_service(profile, "agent-one", "web.service", baseline, current)
        self.assertEqual(diagnosis["repair_order"], ["database.service", "web.service"])
        self.assertIn("service_start_refused_by_limit", codes(diagnosis["findings"]))


if __name__ == "__main__":
    unittest.main()
