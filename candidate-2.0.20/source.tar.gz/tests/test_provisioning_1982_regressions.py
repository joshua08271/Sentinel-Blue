"""Independent regressions for V81-01..18. Native tests are reported separately."""
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

from sentinel_blue import linux_service_packs as packs
from sentinel_blue.desktop_services import service_plan, selection_report, merge_service_fragment
from sentinel_blue.service_pack_checks import validate_acl, run_checks
from sentinel_blue.setup_recipes import compile_recipe


class Provisioning1982Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='sb1982-unit-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def source(self, name, content):
        path = self.root / name
        path.write_text(content)
        path.chmod(0o600)
        return {'path': str(path), 'sha256': hashlib.sha256(content.encode()).hexdigest()}

    def generated(self, service, options):
        captured = {}
        def renderer(opt, root, **kwargs):
            captured.update(options=opt, files=kwargs['generated_sources'], extra=kwargs)
            return ('check', 'apply', None)
        with patch.object(packs, '_linux_service', renderer):
            packs.build(service, options, self.root, metadata=captured)
        return captured

    def bind_options(self):
        return {'zone': 'range.test', 'soa_mname': 'ns.range.test',
                'records': [{'name': 'web', 'type': 'A', 'value': '192.0.2.10'}]}

    def test_ssh_false_stays_no(self):
        text = next(iter(self.generated('openssh-server', {'permit_root_login': False})['files'].values()))
        self.assertIn('PermitRootLogin no\n', text)

    def test_ssh_true_stays_explicit_yes(self):
        text = next(iter(self.generated('openssh-server', {'permit_root_login': True})['files'].values()))
        self.assertIn('PermitRootLogin yes\n', text)

    def test_ssh_bad_booleans_fail_closed(self):
        for key in ('permit_root_login', 'password_authentication'):
            for value in ('false', 'true', None, 0, 1, [], {}):
                with self.subTest(key=key, value=value), self.assertRaises(ValueError):
                    self.generated('openssh-server', {key: value})

    def test_other_security_booleans_are_strict(self):
        examples = [('vsftpd', 'anonymous_enable'), ('vsftpd', 'write_enable'),
                    ('mariadb', 'require_tls'), ('redis', 'protected_mode'),
                    ('mosquitto', 'allow_anonymous'), ('samba', 'read_only'),
                    ('nfs-server', 'read_only'), ('dnsmasq', 'no_dhcp')]
        for service, key in examples:
            with self.subTest(service=service), self.assertRaises(ValueError):
                self.generated(service, {key: 'false'})

    def test_redis_legacy_password_reference_rejected(self):
        with self.assertRaisesRegex(ValueError, 'acl_file'):
            self.generated('redis', {'bind_address': '192.0.2.10', 'password_file': '/run/secret'})

    def test_redis_has_active_auth_and_pin(self):
        g = self.generated('redis', {'bind_address': '192.0.2.10', 'acl_file': '/etc/redis/approved.acl',
                                     'acl_sha256': 'a' * 64, 'protected_mode': False})
        self.assertIn('aclfile "/etc/redis/approved.acl"', '\n'.join(g['files'].values()))
        self.assertEqual(g['checked_files'][0]['sha256'], 'a' * 64)
        self.assertTrue(g['checked_files'][0]['redis_acl'])
        self.assertTrue(g['extra']['preflight_script'])

    def test_redis_requires_pin_and_auth_off_loopback(self):
        for options in ({'bind_address': '0.0.0.0'}, {'acl_file': '/etc/redis/a.acl'},
                        {'acl_sha256': 'a' * 64}, {'acl_file': '/etc/redis/a.acl', 'acl_sha256': 'bad'}):
            with self.subTest(options=options), self.assertRaises(ValueError):
                self.generated('redis', options)

    def test_acl_accepts_password_hash_and_explicit_default_off(self):
        validate_acl(('user default reset off\nuser blue reset on #' + 'a' * 64 + ' ~* +get\n').encode())
        validate_acl(('user default reset on #' + 'b' * 64 + ' ~* +@all\n').encode())

    def test_acl_refuses_unauthenticated_and_plaintext_forms(self):
        for data in (b'user default on nopass ~* +@all', b'user default on >plain ~* +@all',
                     b'user blue off', b'user default on',
                     ('user default on #' + 'a' * 64 + ' resetpass').encode()):
            with self.subTest(data=data), self.assertRaises(ValueError):
                validate_acl(data)

    def test_secret_preflight_checks_actual_file_and_hash(self):
        path = self.root / 'auth.acl'
        data = ('user default reset on #' + 'a' * 64 + ' ~* +get\n').encode()
        path.write_bytes(data); path.chmod(0o600)
        requirement = {'path': str(path), 'secret': True, 'redis_acl': True,
                       'sha256': hashlib.sha256(data).hexdigest()}
        run_checks({'checked_files': [requirement]}, 'preflight')
        path.write_bytes(data + b'# changed\n')
        with self.assertRaisesRegex(ValueError, 'digest'):
            run_checks({'checked_files': [requirement]}, 'preflight')

    def test_secret_preflight_refuses_permissions_missing_symlink(self):
        path = self.root / 'secret'; path.write_text('hello'); path.chmod(0o644)
        for req in ({'path': str(path), 'secret': True}, {'path': str(self.root/'absent')}):
            with self.subTest(req=req), self.assertRaises((ValueError, OSError)):
                run_checks({'checked_files': [req]}, 'preflight')
        link = self.root / 'link'; link.symlink_to(path)
        with self.assertRaises(ValueError):
            run_checks({'checked_files': [{'path': str(link)}]}, 'preflight')

    def test_apache_writes_active_include_directory(self):
        g = self.generated('apache2', {'server_name': 'web.range.test', 'document_root': '/srv/site'})
        self.assertEqual(list(g['files']), ['/etc/apache2/sites-enabled/sentinel-web.range.test.conf'])
        self.assertIn('apache_site', g)

    def test_apache_quotes_paths_and_requires_both_tls_inputs(self):
        g = self.generated('apache2', {'server_name': 'web.range.test', 'document_root': '/srv/my site',
            'tls_certificate_path': '/etc/certs/site cert.pem', 'tls_key_path': '/etc/certs/site key.pem'})
        text = '\n'.join(g['files'].values())
        self.assertIn('DocumentRoot "/srv/my site"', text)
        self.assertIn('SSLCertificateKeyFile "/etc/certs/site key.pem"', text)
        for extra in ({'tls_key_path': '/etc/key.pem'}, {'tls_certificate_path': '/etc/cert.pem'}):
            with self.assertRaises(ValueError):
                self.generated('apache2', {'server_name': 'web.test', 'document_root': '/srv/site'} | extra)

    def test_apache_listener_is_explicit(self):
        g = self.generated('apache2', {'server_name': 'web.test', 'document_root': '/srv/site',
                                     'manage_listener': True, 'listen_address': '127.0.0.1', 'port': 18281})
        self.assertIn('Listen 127.0.0.1:18281', '\n'.join(g['files'].values()))

    def test_path_injection_and_noncanonical_values_are_rejected(self):
        for path in ('/srv/../root', '/srv//site', '/srv/"\nInclude /tmp/x', '/srv/${EVIL}', '/srv/a\\b'):
            with self.subTest(path=path), self.assertRaises(ValueError):
                self.generated('apache2', {'server_name': 'web.test', 'document_root': path})

    def test_apache_inactive_include_is_rejected(self):
        spec = {'service_id': 'apache2', 'generated': ['/etc/apache2/sites-enabled/sentinel-web.test.conf'], 'apache_site': 'web.test'}
        with patch('sentinel_blue.service_pack_checks._command', return_value='Syntax OK'), self.assertRaisesRegex(ValueError, 'load'):
            run_checks(spec, 'configuration')

    def test_gunicorn_unit_identity_matches_all_files(self):
        g = self.generated('gunicorn', {'application': 'app:application', 'working_directory': '/srv/app', 'user': 'nobody'})
        self.assertIn('/etc/systemd/system/' + g['service'] + '.service', g['files'])
        self.assertEqual(service_plan(['gunicorn'], 'host')['tasks'][0]['service_id'], g['service'])

    def test_gunicorn_systemd_quotes_and_percent_escaping(self):
        # 2.0.6 (found live): systemd does not unquote WorkingDirectory=, so the
        # quoted form this test used to require made the unit fail to load
        # ("path is not absolute"). Only plain path characters are accepted
        # now, so the value needs neither quoting nor %-escaping.
        text = '\n'.join(self.generated('gunicorn', {'application': 'app:application', 'working_directory': '/srv/app', 'user': 'nobody'})['files'].values())
        self.assertIn('\nWorkingDirectory=/srv/app\n', text)
        with self.assertRaises(ValueError):
            self.generated('gunicorn', {'application': 'app:application', 'working_directory': '/srv/app %h', 'user': 'nobody'})

    def test_bind_records_materially_change_zone(self):
        a = self.generated('bind9', self.bind_options())
        changed = self.bind_options(); changed['records'][0]['value'] = '192.0.2.99'
        b = self.generated('bind9', changed)
        self.assertNotEqual(a['files'], b['files'])
        self.assertIn('web IN A 192.0.2.10', a['files']['/etc/bind/sentinel-range.test.zone'])
        self.assertTrue(all(not name.startswith('/var/') for name in a['files']))

    def test_bind_adopt_preserves_zone_and_requires_hash(self):
        g = self.generated('bind9', {'zone': 'range.test', 'mode': 'adopt-existing',
            'zone_file': '/var/lib/bind/range.zone', 'zone_sha256': 'a'*64})
        self.assertNotIn('/var/lib/bind/range.zone', g['files'])
        self.assertEqual(g['checked_files'][0]['sha256'], 'a'*64)
        with self.assertRaises(ValueError):
            self.generated('bind9', {'zone': 'range.test', 'mode': 'adopt-existing', 'records': []})

    def test_bind_rejects_record_family_mismatch(self):
        opts = self.bind_options(); opts['records'][0]['type'] = 'AAAA'
        with self.assertRaises(ValueError):
            self.generated('bind9', opts)

    def test_bind_activation_preserves_existing_snapshot_and_pins(self):
        current = '// teammate-owned existing declarations\n'
        ref = self.source('named.local', current)
        g = self.generated('bind9', self.bind_options() | {'activation': {'/etc/bind/named.conf.local': ref}})
        self.assertTrue(g['files']['/etc/bind/named.conf.local'].startswith(current))
        self.assertIn('include "/etc/bind/named.conf.sentinel";', g['files']['/etc/bind/named.conf.local'])
        row = next(r for r in g['options']['files'] if r['path'].endswith('named.conf.local'))
        self.assertEqual(row['previous_sha256'], ref['sha256'])

    def test_activation_refuses_unrelated_paths(self):
        with self.assertRaises(ValueError):
            self.generated('bind9', self.bind_options() | {'activation': {'/etc/passwd': self.source('x', 'x')}})

    def test_postgres_cert_uses_hostssl_and_declares_tls(self):
        g = self.generated('postgresql', {'config_directory': '/etc/postgresql/17/main',
            'allowed_networks': ['127.0.0.0/8'], 'auth_method': 'cert',
            'ssl_certificate_path': '/etc/ssl/cert.pem', 'ssl_key_path': '/etc/ssl/key.pem', 'ssl_ca_path': '/etc/ssl/ca.pem'})
        self.assertIn('hostssl all all 127.0.0.0/8 cert', g['files']['/etc/postgresql/17/main/sentinel-pg-hba.conf'])
        self.assertEqual(len(g['checked_files']), 3)
        self.assertIn('ssl = on', g['files']['/etc/postgresql/17/main/conf.d/60-sentinel.conf'])

    def test_postgres_requires_explicit_cluster_and_certificate_prerequisites(self):
        # 2.0.6: PostgreSQL 10+ is accepted; including pg_hba rules needs 16+.
        for opts in ({}, {'config_directory': '/etc/postgresql/9/main'},
                     {'config_directory': '/etc/postgresql/15/main', 'allowed_networks': ['127.0.0.0/8']},
                     {'config_directory': '/etc/postgresql/17/main', 'auth_method': 'cert'}):
            with self.subTest(options=opts), self.assertRaises(ValueError):
                self.generated('postgresql', opts)

    def test_postgres_hba_include_precedes_old_match_rules(self):
        old = 'host all all 127.0.0.0/8 md5\n'
        g = self.generated('postgresql', {'config_directory': '/etc/postgresql/17/main',
            'allowed_networks': ['127.0.0.0/8'], 'activation': {'/etc/postgresql/17/main/pg_hba.conf': self.source('hba', old)}})
        # Double quotes: PostgreSQL reads single quotes as part of the file name.
        self.assertEqual(g['files']['/etc/postgresql/17/main/pg_hba.conf'], 'include "sentinel-pg-hba.conf"\n' + old)

    def test_previous_digest_honored_for_dropin(self):
        g = self.generated('mariadb', {'port': 3307, 'previous_sha256': 'a'*64})
        self.assertTrue(all(row['previous_sha256'] == 'a'*64 for row in g['options']['files']))

    def test_multifile_requires_exact_per_object_prestate(self):
        with self.assertRaisesRegex(ValueError, 'multi-file'):
            self.generated('bind9', self.bind_options() | {'previous_sha256': 'a'*64})
        g = self.generated('bind9', self.bind_options() | {'previous_files': {'/etc/bind/named.conf.sentinel': 'a'*64}})
        row = next(r for r in g['options']['files'] if r['path'].endswith('named.conf.sentinel'))
        self.assertEqual(row['previous_sha256'], 'a'*64)

    def test_unknown_or_bad_prestate_is_not_ignored(self):
        for value in ({'previous_sha256': 'bad'}, {'previous_files': {'/etc/passwd': 'a'*64}},
                      {'previous_files': []}):
            with self.subTest(value=value), self.assertRaises(ValueError):
                self.generated('mariadb', value)

    def test_postfix_relay_option_rejected_not_ignored(self):
        with self.assertRaisesRegex(ValueError, 'relay_restrictions'):
            self.generated('postfix', {'myhostname': 'mail.test', 'mydomain': 'test', 'relay_restrictions': 'reject'})

    def test_postfix_merges_actual_main_not_unused_directory(self):
        original = 'queue_directory = /var/spool/postfix\nmyhostname = old.test\nmynetworks = 127.0.0.0/8,\n    192.0.2.0/24\n# teammate comment\n'
        ref = self.source('main.cf', original)
        g = self.generated('postfix', {'myhostname': 'mail.range.test', 'mydomain': 'range.test', 'main_config': ref})
        text = g['files']['/etc/postfix/main.cf']
        self.assertIn('queue_directory = /var/spool/postfix', text)
        self.assertIn('# teammate comment', text)
        self.assertNotIn('192.0.2.0/24', text)
        self.assertNotIn('old.test', text)
        self.assertIn('myhostname = mail.range.test', text)
        self.assertEqual(g['options']['files'][0]['previous_sha256'], ref['sha256'])

    def test_postfix_requires_snapshot_and_rejects_open_relay(self):
        for extra in ({}, {'mynetworks': ['0.0.0.0/0']}, {'mynetworks': ['localnets']}):
            with self.subTest(extra=extra), self.assertRaises(ValueError):
                self.generated('postfix', {'myhostname': 'mail.test', 'mydomain': 'test'} | extra)

    def test_dhcp_rejects_network_broadcast_inversion_gateway_pool_and_wrong_family(self):
        base = {'authorized': True, 'subnet': '192.0.2.0', 'netmask': '255.255.255.0', 'range_start': '192.0.2.10', 'range_end': '192.0.2.20'}
        for extra in ({'range_start': '192.0.2.0'}, {'range_end': '192.0.2.255'},
                      {'range_start': '192.0.2.30'}, {'routers': ['192.0.2.12']},
                      {'routers': ['192.0.3.1']}, {'lease_seconds': '3600'}, {'authorized': 'true'}):
            with self.subTest(extra=extra), self.assertRaises(ValueError):
                self.generated('isc-dhcp-server', base | extra)
        self.generated('isc-dhcp-server', base | {'routers': ['192.0.2.1']})

    def test_existing_running_conflict_is_blocked(self):
        for selected, other in (('nginx', 'apache2'), ('bind9', 'dnsmasq')):
            self.assertFalse(selection_report([selected], presence={other: 'running'})['ready'])

    def test_existing_dependency_is_not_forced_into_new_mutations(self):
        report = selection_report(['dovecot'], presence={'postfix': 'running'})
        self.assertTrue(report['ready'])
        plan = service_plan(['dovecot'], 'host', presence={'postfix': 'running'})
        self.assertEqual(len(plan['tasks']), 1)
        self.assertEqual(plan['review_notes']['existing_dependencies'], ['postfix'])

    def test_unknown_dependency_stays_blocked(self):
        self.assertFalse(selection_report(['dovecot'], presence={'postfix': 'unknown'})['ready'])

    def test_no_parameters_means_honest_start_only_summary(self):
        report = selection_report(['apache2'], options={})
        self.assertEqual(report['configure'], [])
        self.assertEqual(report['adopt_only'], ['apache2'])
        plan = service_plan(['apache2'], 'host')
        self.assertEqual(plan['review_notes']['configure'], [])

    def test_nginx_dispatches_to_actual_adapter(self):
        plan = service_plan(['nginx'], 'host', options={'nginx': {'name': 'test'}})
        self.assertEqual(plan['tasks'][0]['recipe'], 'linux-nginx')
        self.assertNotIn('catalog_id', plan['tasks'][0]['options'])

    def test_configuration_options_are_preserved_not_silently_dropped(self):
        opts = {'mariadb': {'bind_address': '127.0.0.1', 'port': 3307}}
        task = service_plan(['mariadb'], 'host', options=opts)['tasks'][0]
        self.assertEqual(task['options']['port'], 3307)
        self.assertEqual(task['recipe'], 'linux-service-pack')

    def test_service_plan_rejects_unselected_options_or_injected_identity(self):
        for opts in ({'nginx': {}}, {'mariadb': {'catalog_id': 'redis'}}, {'mariadb': None}):
            with self.subTest(opts=opts), self.assertRaises(ValueError):
                service_plan(['mariadb'], 'host', options=opts)

    def test_non_debian_layout_is_refused_not_mislabelled(self):
        for manager in ('dnf', 'yum', 'pacman', 'zypper'):
            with self.subTest(manager=manager), self.assertRaises(ValueError):
                service_plan(['apache2'], 'host', manager=manager)
        with self.assertRaises(ValueError):
            self.generated('mariadb', {'manager': 'dnf'})

    def test_fragment_merge_preserves_scope_existing_data_and_original(self):
        inventory = {'authorized_networks': ['127.0.0.0/8'], 'hosts': [
            {'name': 'host', 'agent_id': 'agent', 'platform': 'linux'}],
            'setup': {'tasks': [{'id': 'old', 'host': 'host'}]}, 'probes': [{'name': 'kept'}]}
        original = copy.deepcopy(inventory)
        merged = merge_service_fragment(inventory, service_plan(['nginx'], 'agent'))
        self.assertEqual(inventory, original)
        self.assertEqual(merged['authorized_networks'], original['authorized_networks'])
        self.assertEqual(merged['probes'], original['probes'])
        self.assertEqual(merged['setup']['tasks'][1]['host'], 'host')

    def test_fragment_merge_refuses_collision_or_unscoped_host(self):
        inv = {'hosts': [{'name': 'host', 'platform': 'linux'}], 'setup': {'tasks': []}}
        fragment = service_plan(['nginx'], 'host')
        once = merge_service_fragment(inv, fragment)
        with self.assertRaises(ValueError): merge_service_fragment(once, fragment)
        with self.assertRaises(ValueError): merge_service_fragment(inv, service_plan(['nginx'], 'other'))

    def test_fragment_merge_does_not_allow_arbitrary_runbook(self):
        inv = {'hosts': [{'name': 'host', 'platform': 'linux'}], 'setup': {'tasks': []}}
        fragment = service_plan(['nginx'], 'host'); fragment['tasks'][0]['recipe'] = 'runbook'
        with self.assertRaises(ValueError): merge_service_fragment(inv, fragment)

    def test_guarded_transaction_contains_exact_generated_files(self):
        from sentinel_blue.setup_transactions import commands
        opts = {'catalog_id': 'mariadb', 'port': 3307, 'previous_sha256': 'a'*64}
        _, apply, _ = compile_recipe('linux-service-pack', opts, self.root, 'linux')
        commands_out = commands('linux-service-pack', opts, self.root, apply)
        self.assertEqual(set(commands_out), {'admit', 'apply', 'rollback', 'commit'})

    def test_generated_scripts_still_parse_and_keep_failure_restore(self):
        fixtures = [('apache2', {'server_name': 'web.test', 'document_root': '/srv/site'}),
                    ('redis', {'bind_address': '127.0.0.1'}), ('mariadb', {'port': 3307}),
                    ('bind9', self.bind_options()),
                    ('gunicorn', {'application': 'app:application', 'working_directory': '/srv/app', 'user': 'nobody'})]
        for service, options in fixtures:
            check, apply, rollback = packs.build(service, options, self.root)
            with self.subTest(service=service):
                for script in (check, apply):
                    self.assertEqual(subprocess.run(['sh', '-n'], input=script, text=True, capture_output=True).returncode, 0)
                self.assertIn('sb_restore', apply)
                self.assertIn('preflight', apply)
                self.assertIsNone(rollback)


if __name__ == '__main__':
    unittest.main()

class AdditionalActivation1982Tests(unittest.TestCase):
    def test_presence_freshness(self):
        from sentinel_blue.desktop_services import catalog_presence
        sample={'observed_at':100,'services':[{'name':'postfix','state':'running'}]}
        self.assertEqual(catalog_presence(sample,now=105)['postfix'],'running')
        for now in (99, 191):
            self.assertEqual(catalog_presence(sample,now=now),{})
        for stamp in (None,'100',True,float('nan')):
            self.assertEqual(catalog_presence({**sample,'observed_at':stamp},now=105),{})

    def test_existing_dependency_is_guarded_before_start_and_on_recheck(self):
        from sentinel_blue.service_pack_checks import run_checks
        with patch('sentinel_blue.service_pack_checks._command',side_effect=ValueError('dependency is down')) as cmd:
            for phase in ('preflight','configuration'):
                with self.assertRaisesRegex(ValueError,'dependency is down'):
                    run_checks({'service_id':'dovecot','dependency_units':['postfix']},phase)
            self.assertEqual(cmd.call_count,2)

    def test_file_mode_malformed_input_fails_validation(self):
        with tempfile.TemporaryDirectory() as directory:
            for val in (None,1,[],{},True):
                with self.subTest(value=val),self.assertRaises(ValueError):
                    packs.build('mariadb',{'file_modes':{'/etc/mysql/mariadb.conf.d/60-sentinel.cnf':val}},Path(directory))

    def test_snapshot_mode_cannot_be_widened(self):
        with tempfile.TemporaryDirectory() as directory:
            p=Path(directory)/'private.conf';p.write_text('private');p.chmod(0o600)
            with self.assertRaisesRegex(ValueError,'widened'):
                run_checks({'service_id':'postfix','mode_preconditions':[{'path':str(p),'mode':'0644'}]},'preflight')

    def test_bind_active_check_uses_masked_explicit_config_and_correct_zone_block(self):
        spec={'service_id':'bind9','bind_zone':{'name':'range.test','path':'/etc/bind/sentinel-range.test.zone'}}
        valid='zone "range.test" IN {\n file "/etc/bind/sentinel-range.test.zone";\n};\n'
        with patch('sentinel_blue.service_pack_checks._command',return_value=valid) as cmd:
            run_checks(spec,'configuration')
            self.assertEqual(cmd.call_args_list[0].args[0],['/usr/sbin/named-checkconf','-p','-x','/etc/bind/named.conf'])
        wrong='zone "range.test" {\n file "/var/lib/bind/other.zone";\n};\nzone "other.test" {\n file "/etc/bind/sentinel-range.test.zone";\n};\n'
        with patch('sentinel_blue.service_pack_checks._command',return_value=wrong),self.assertRaises(ValueError):
            run_checks(spec,'configuration')

    def test_acl_avoids_inherited_auth_and_duplicate_users(self):
        for acl in ('user default off', 'user default reset off\nuser default reset off'):
            with self.subTest(acl=acl),self.assertRaises(ValueError):validate_acl(acl.encode())
