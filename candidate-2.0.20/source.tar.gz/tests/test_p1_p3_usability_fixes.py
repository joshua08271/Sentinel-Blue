"""Regression tests for the P1-P3 usability and reporting fixes."""
import unittest
from unittest.mock import patch

from sentinel_blue import desktop_jobs
from sentinel_blue.desktop_control import SEVERITY_ORDER, service_rows, verification_rows
from sentinel_blue.offline_continuity import restart_baseline


AGENT = {'agent_id': 'agent-a', 'enabled': True}
MANIFEST = {'host': 'agent-a', 'service_id': 'web',
            'expected_transactions': [{'name': 'web', 'kind': 'tcp', 'target': '127.0.0.1', 'port': 80}]}


class ServiceHealthReasonTests(unittest.TestCase):
    def test_manifest_host_that_is_not_an_enrolled_agent_says_so(self):
        # The manifest must name the agent_id; an address nothing reports used to
        # sit at "unknown" with no explanation at all.
        rows = service_rows([{**MANIFEST, 'host': '127.0.0.1'}], {}, [AGENT])
        self.assertEqual(rows[0]['health'], 'unknown')
        self.assertIn('no enrolled agent reports manifest host', rows[0]['reason'])

    def test_missing_and_stale_telemetry_are_distinguished(self):
        rows = service_rows([MANIFEST], {}, [AGENT])
        self.assertIn('no telemetry received', rows[0]['reason'])
        stale = service_rows([MANIFEST], {'agent-a': {'observed_at': 0.0}}, [AGENT], now=10_000.0)
        self.assertEqual(stale[0]['health'], 'stale')
        self.assertIn('stale', stale[0]['reason'])

    def test_probe_that_never_ran_names_the_mismatch(self):
        sample = {'observed_at': 100.0, 'services': [{'name': 'web', 'state': 'running'}], 'probes': []}
        rows = service_rows([MANIFEST], {'agent-a': sample}, [AGENT], now=101.0)
        self.assertIn('no matching service check ran', rows[0]['reason'])

    def test_healthy_service_reports_no_reason(self):
        sample = {'observed_at': 100.0, 'services': [{'name': 'web', 'state': 'running'}],
                  'probes': [{'name': 'web', 'target': '127.0.0.1', 'healthy': True}]}
        rows = service_rows([MANIFEST], {'agent-a': sample}, [AGENT], now=101.0)
        self.assertEqual((rows[0]['health'], rows[0]['reason']), ('healthy', ''))


class ReviewSeverityTests(unittest.TestCase):
    SNAPSHOT = {
        'alerts': [{'alert_id': 'a1', 'agent_id': 'agent-a', 'status': 'open',
                    'title': 'Unverified privileged account', 'severity': 'high'},
                   {'alert_id': 'a2', 'agent_id': 'agent-a', 'status': 'open',
                    'title': 'Login-capable account', 'severity': 'medium'}],
        'agents': [{'agent_id': 'agent-a', 'baseline_status': 'pending'}],
        'actions': [{'action_id': 'x1', 'agent_id': 'agent-a', 'status': 'outcome_unknown'}],
        'external_observers': [{'observer_id': 'o1', 'check_id': 'c1', 'agent_id': 'agent-a',
                                'service_id': 'web', 'health': 'unhealthy'}],
    }

    def test_every_review_row_carries_a_severity(self):
        rows = verification_rows(self.SNAPSHOT)
        self.assertTrue(rows)
        for row in rows:
            with self.subTest(kind=row['kind']):
                self.assertIn(row['severity'], SEVERITY_ORDER)

    def test_alert_severity_is_the_controller_value(self):
        rows = {row['id']: row for row in verification_rows(self.SNAPSHOT)}
        self.assertEqual(rows['a1']['severity'], 'high')
        self.assertEqual(rows['a2']['severity'], 'medium')

    def test_severity_order_ranks_most_severe_first(self):
        self.assertLess(SEVERITY_ORDER['critical'], SEVERITY_ORDER['high'])
        self.assertLess(SEVERITY_ORDER['high'], SEVERITY_ORDER['medium'])
        self.assertLess(SEVERITY_ORDER['medium'], SEVERITY_ORDER['low'])


class SetupReviewGateTests(unittest.TestCase):
    class _Profile:
        fingerprint = 'f' * 64

        def __init__(self, allowed):
            self._allowed = allowed

        def allows(self, name):
            return self._allowed

        def require_runtime_ready(self, **_kwargs):
            return None

        def verify_release_file(self, _runtime):
            return None

    def _prepare(self, allowed):
        with patch.object(desktop_jobs, 'load_inventory', return_value={'hosts': []}), \
             patch.object(desktop_jobs, 'load_event_profile', return_value=self._Profile(allowed)), \
             patch.object(desktop_jobs, 'compile_plan', return_value={'tasks': {}}):
            return desktop_jobs.prepare('inventory.json', 'profile.json', 'runtime.pyz', 'setup', False)

    def test_review_refuses_a_plan_execution_would_refuse(self):
        with self.assertRaises(ValueError) as error:
            self._prepare(False)
        self.assertIn('initial_provisioning', str(error.exception))

    def test_approved_profile_still_reviews(self):
        plan, _profile = self._prepare(True)
        self.assertEqual(plan, {'tasks': {}})


class OfflineBaselineCoverageMessageTests(unittest.TestCase):
    CONTRACT = {'dependencies': [], 'files': ['/etc/web.conf'], 'required_accounts': [],
                'probes': [], 'dependency_probes': []}

    def test_missing_protected_file_names_the_gap(self):
        baseline = {'agent_id': 'agent-a', 'services': [{'name': 'web'}], 'integrity': [], 'accounts': []}
        with self.assertRaises(ValueError) as error:
            restart_baseline(baseline, {'web': self.CONTRACT})
        message = str(error.exception)
        self.assertIn('/etc/web.conf', message)
        self.assertIn('approved baseline does not cover', message)

    def test_complete_baseline_projects_successfully(self):
        baseline = {'agent_id': 'agent-a', 'services': [{'name': 'web', 'state': 'running'}],
                    'integrity': [{'path': '/etc/web.conf', 'sha256': 'a' * 64}], 'accounts': []}
        projected = restart_baseline(baseline, {'web': self.CONTRACT})
        self.assertEqual(projected['integrity'][0]['path'], '/etc/web.conf')
        self.assertEqual(projected['services'][0]['name'], 'web')


class CommandLineErrorTests(unittest.TestCase):
    def test_configuration_error_prints_a_reason_without_a_traceback(self):
        from sentinel_blue import __main__ as cli
        with patch.object(cli, '_main', side_effect=ValueError('inventory requires a setup object with tasks')):
            with patch('sys.stderr') as stderr:
                with self.assertRaises(SystemExit) as exit_code:
                    cli.main()
        self.assertEqual(exit_code.exception.code, 2)
        printed = ''.join(str(call.args[0]) for call in stderr.write.call_args_list)
        self.assertIn('inventory requires a setup object with tasks', printed)

    def test_unexpected_errors_keep_their_traceback(self):
        from sentinel_blue import __main__ as cli
        with patch.object(cli, '_main', side_effect=RuntimeError('unexpected')):
            with self.assertRaises(RuntimeError):
                cli.main()


if __name__ == '__main__':
    unittest.main()
