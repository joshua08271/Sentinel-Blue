"""2.0.2: a drop policy drops IPv6 too.

The router adapter's table is `inet`, so it filters both families, but both of
its drops were written `meta nfproto ipv4 drop`. With `input_policy: drop` on a
host with IPv6 enabled — the Linux default — every dual-stack listener stayed
reachable over IPv6 while the operator believed the host was default-deny.

These tests pin the generated rules, prove they load into a real kernel, and
prove IPv4 filtering is unchanged by connecting through them. The IPv6 half of
the connection test runs only where the kernel has IPv6; `tools/firewall_reachability.py`
is the same check for a VM.
"""
import json
import os
import shutil
import subprocess
import sys
import unittest
from pathlib import Path

from sentinel_blue.network_setup import normalize, ruleset

ROOT = Path(__file__).resolve().parents[1]
TOOL = ROOT / "tools" / "firewall_reachability.py"

HOST = {"name": "edge", "input_policy": "drop", "forwarding": False,
        "management": [{"source": "198.51.100.0/24", "port": 22}]}


def chain(text, name):
    body = text.split(f" chain {name} {{\n", 1)[1].split("\n }", 1)[0]
    return [line.strip() for line in body.splitlines()][1:]   # drop the hook line


def namespaces_available():
    if not shutil.which("unshare") or not shutil.which("nft"):
        return False
    probe = subprocess.run(["unshare", "-n", "nft", "list", "ruleset"], capture_output=True)
    return probe.returncode == 0


class DropCoversBothFamilies(unittest.TestCase):
    def test_no_rule_is_limited_to_ipv4_any_more(self):
        for options in (HOST, {**HOST, "forwarding": True}):
            with self.subTest(forwarding=options["forwarding"]):
                self.assertNotIn("meta nfproto ipv4", ruleset(normalize(options)))

    def test_the_input_drop_is_last_and_family_agnostic(self):
        rules = chain(ruleset(normalize(HOST)), "input")
        self.assertEqual(rules[-1], "drop")

    def test_accept_policy_adds_no_drop(self):
        rules = chain(ruleset(normalize({**HOST, "input_policy": "accept"})), "input")
        self.assertNotIn("drop", rules)

    def test_icmpv6_is_accepted_before_the_invalid_drop(self):
        """Neighbor discovery is ICMPv6. Without it the host leaves the IPv6 network."""
        rules = chain(ruleset(normalize(HOST)), "input")
        self.assertLess(rules.index("meta l4proto ipv6-icmp accept"), rules.index("ct state invalid drop"))
        self.assertLess(rules.index("ct state invalid drop"), rules.index("drop"))

    def test_a_forwarding_router_drops_ipv6_transit(self):
        """Forward rules are IPv4 only, so IPv6 transit is never reviewed and never passed."""
        options = {**HOST, "forwarding": True,
                   "forward": [{"source": "10.0.1.0/24", "destination": "10.0.2.0/24",
                                "in_interface": "eth1", "out_interface": "eth2"}]}
        self.assertEqual(chain(ruleset(normalize(options)), "forward")[-1], "drop")


class IPv6SourcesCanBeAllowed(unittest.TestCase):
    def test_ipv6_sources_are_written_as_ip6_matches(self):
        options = {**HOST,
                   "management": [{"source": "198.51.100.0/24", "port": 22},
                                  {"source": "2001:db8:100::/64", "port": 22}],
                   "allow": [{"source": "0.0.0.0/0", "protocol": "tcp", "port": 80},
                             {"source": "::/0", "protocol": "tcp", "port": 80}]}
        rules = chain(ruleset(normalize(options)), "input")
        for expected in ("ip saddr 198.51.100.0/24 tcp dport 22 accept",
                         "ip6 saddr 2001:db8:100::/64 tcp dport 22 accept",
                         "ip saddr 0.0.0.0/0 tcp dport 80 accept",
                         "ip6 saddr ::/0 tcp dport 80 accept"):
            self.assertIn(expected, rules)
        self.assertLess(max(rules.index(r) for r in rules if r.endswith(" accept") and "saddr" in r),
                        rules.index("drop"))

    def test_routing_and_nat_stay_ipv4(self):
        """Filtering gained IPv6; routing did not, and says so rather than half-working."""
        for change in ({"forwarding": True, "forward": [{"source": "2001:db8:1::/64", "destination": "10.0.2.0/24",
                                                         "in_interface": "eth1", "out_interface": "eth2"}]},
                       {"forwarding": True, "masquerade": [{"source": "2001:db8:1::/64", "out_interface": "eth0"}]},
                       {"routes": [{"destination": "2001:db8:9::/64", "via": "10.0.0.1", "interface": "eth0"}]},
                       {"addresses": [{"address": "2001:db8::5/64", "interface": "eth0"}]}):
            with self.subTest(change=list(change)[-1]), self.assertRaises(ValueError):
                normalize({**HOST, **change})

    def test_a_number_is_not_a_network(self):
        """`ipaddress.ip_network(5)` is 0.0.0.5/32; an operator's typo must not become an address."""
        for bad in (5, 0, True, ["10.0.0.0/8"], {"a": 1}, None):
            with self.subTest(source=bad), self.assertRaises(ValueError):
                normalize({**HOST, "allow": [{"source": bad, "protocol": "tcp", "port": 80}]})


@unittest.skipUnless(namespaces_available(), "needs unshare and nft with network-namespace privileges")
class RulesInARealKernel(unittest.TestCase):
    def test_every_generated_ruleset_loads(self):
        cases = [HOST, {**HOST, "input_policy": "accept"},
                 {**HOST, "allow": [{"source": "::/0", "protocol": "udp", "port": 53}]},
                 {**HOST, "forwarding": True,
                  "forward": [{"source": "10.0.1.0/24", "destination": "10.0.2.0/24",
                               "in_interface": "eth1", "out_interface": "eth2", "protocol": "tcp", "port": 443}],
                  "masquerade": [{"source": "10.0.1.0/24", "out_interface": "eth0"}]}]
        for options in cases:
            with self.subTest(options=options):
                done = subprocess.run(["unshare", "-n", "nft", "-f", "-"], input=ruleset(normalize(options)),
                                      text=True, capture_output=True)
                self.assertEqual(done.returncode, 0, done.stderr)

    def reach(self, *extra):
        done = subprocess.run(["unshare", "-n", sys.executable, str(TOOL), str(ROOT), *extra],
                              capture_output=True, text=True, timeout=60)
        self.assertEqual(done.returncode, 0, done.stderr)
        return json.loads(done.stdout.strip().splitlines()[-1])

    def test_ipv4_filtering_is_unchanged(self):
        result = self.reach()
        self.assertEqual(result["IPv4 port 8080"], "blocked")
        self.assertEqual(result["IPv4 port 8081"], "reachable")

    def test_ipv6_is_dropped_unless_allowed(self):
        result = self.reach()
        if "IPv6 port 8080" not in result:
            self.skipTest(result.get("IPv6", "IPv6 unavailable in this kernel"))
        self.assertEqual(result["IPv6 port 8080"], "blocked")
        self.assertEqual(result["IPv6 port 8081"], "blocked")
        allowed = self.reach("with-ipv6-allow")
        self.assertEqual(allowed["IPv6 port 8081"], "reachable")
        self.assertEqual(allowed["IPv6 port 8080"], "blocked")


if __name__ == "__main__":
    unittest.main()
