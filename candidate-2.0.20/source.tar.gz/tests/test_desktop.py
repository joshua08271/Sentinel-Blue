import copy
import http.server
import json
import os
import tempfile
import threading
import time
import unittest
from pathlib import Path

from sentinel_blue.desktop_control import DesktopClient, service_rows, verification_rows
from sentinel_blue.desktop_credentials import DesktopCredentials, credential_requirements
from sentinel_blue.operator_auth import authenticate_operator_request


class ServiceDisplayTests(unittest.TestCase):
    def setUp(self):
        self.manifest = [{'host': 'web', 'service_id': 'nginx', 'expected_transactions': [
            {'name': 'content', 'target': 'http://127.0.0.1/'}]}]
        self.agent = [{'agent_id': 'web', 'enabled': True}]
        self.sample = {'observed_at': 100, 'services': [{'name': 'nginx', 'state': 'running'}],
                       'probes': [{'name': 'content', 'target': 'http://127.0.0.1/', 'healthy': True}]}

    def rows(self, sample=None, now=101):
        return service_rows(self.manifest, {'web': sample or self.sample}, self.agent, now=now)[0]

    def test_health_requires_complete_fresh_transaction_evidence(self):
        self.assertEqual(self.rows()['health'], 'healthy')
        self.assertEqual(self.rows(now=201)['health'], 'stale')
        self.assertEqual(self.rows(now=90)['health'], 'stale')
        sample = copy.deepcopy(self.sample)
        sample['probes'] = []
        self.assertEqual(self.rows(sample)['health'], 'unverified')
        sample['probes'] = self.sample['probes'] * 2
        self.assertEqual(self.rows(sample)['health'], 'unverified')
        self.agent[0]['enabled'] = False
        self.assertEqual(self.rows()['health'], 'unknown')

    def test_failed_transaction_or_stopped_service_is_unhealthy(self):
        self.sample['probes'][0]['healthy'] = False
        self.assertEqual(self.rows()['health'], 'unhealthy')
        self.sample['probes'][0]['healthy'] = True
        self.sample['services'][0]['state'] = 'stopped'
        self.assertEqual(self.rows()['health'], 'unhealthy')

    def test_unknown_outcomes_and_baselines_are_visible(self):
        result = verification_rows({'agents': [{'agent_id': 'host', 'baseline_status': 'pending'}],
            'actions': [{'agent_id': 'host', 'action_id': 'x', 'status': 'outcome_unknown'}],
            'alerts': [{'status': 'open', 'alert_id': 'a', 'agent_id': 'host'}]})
        self.assertEqual({row['kind'] for row in result}, {'alert', 'baseline', 'outcome'})
        self.assertEqual(result[-1]['choices'], ['executed', 'not_executed'])


class DesktopCredentialTests(unittest.TestCase):
    @unittest.skipUnless(os.name == 'nt', 'Windows DPAPI credential export')
    def test_windows_credential_file_round_trip(self):
        from sentinel_blue.setup_transport import SetupTransport, _ps
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            credentials = DesktopCredentials()
            self.addCleanup(credentials.lock)
            credentials.unlock(root/'vault', 'test vault passphrase long enough', create=True)
            path = root/'runtime'/'management.xml'
            key = credentials.save('owned fixture', 'winrm', 'fixture-user', 'fixture-desktop-password', str(path))
            credentials.supply(key)
            self.assertNotIn(b'fixture-desktop-password', path.read_bytes())
            result = SetupTransport()._powershell("$ErrorActionPreference='Stop'\n"
                + f"$c=Import-Clixml -LiteralPath {_ps(str(path))}\n"
                + "if ($c.UserName -ne 'fixture-user' -or $c.GetNetworkCredential().Password -ne 'fixture-desktop-password') {exit 20}\nexit 0\n", 20)
            credentials.lock()
            self.assertEqual(result.returncode, 0)

    def test_encrypted_round_trip_private_runtime_and_lock(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            credentials = DesktopCredentials()
            phrase = 'test vault passphrase long enough'
            credentials.unlock(root/'vault', phrase, create=True)
            value = 'sentinel-desktop-test-secret'
            key = credentials.save('SMB scoring', 'password', 'scorer', value, str(root/'runtime'/'smb.password'))
            self.assertNotIn(value.encode(), (root/'vault'/'vault.json').read_bytes())
            self.assertNotIn(value, json.dumps(credentials.entries()))
            credentials.supply(key)
            self.assertEqual((root/'runtime'/'smb.password').read_text(), value)
            if os.name == 'posix':
                self.assertEqual((root/'runtime'/'smb.password').stat().st_mode & 0o777, 0o600)
            credentials.lock()
            with self.assertRaisesRegex(ValueError, 'Unlock'):
                credentials.supply(key)
            credentials.unlock(root/'vault', phrase)
            self.assertEqual(credentials.entries()[0]['username'], 'scorer')
            credentials.lock()

    @unittest.skipUnless(os.name == 'posix', 'POSIX file boundary')
    def test_unsafe_path_and_link_never_receive_a_secret(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            credentials = DesktopCredentials()
            credentials.unlock(root/'vault', 'test vault passphrase long enough', create=True)
            self.addCleanup(credentials.lock)
            (root/'runtime').mkdir(mode=0o700)
            (root/'target').write_text('unchanged')
            (root/'runtime'/'secret').symlink_to(root/'target')
            key = credentials.save('system', 'password', '', 'test-secret', str(root/'runtime'/'secret'))
            with self.assertRaises(ValueError):
                credentials.supply(key)
            self.assertEqual((root/'target').read_text(), 'unchanged')
            with self.assertRaises(ValueError):
                credentials.save('system', 'password', '', 'test-secret', str(root/'vault'/'vault.json'))

    def test_requirements_come_from_local_inventory(self):
        result = credential_requirements({'hosts': [{'name': 'router', 'key_file': 'credentials/router.key'}],
            'event_profile': {'services': [{'host': 'sql', 'service_id': 'postgres', 'expected_transactions': [
                {'password_file': 'credentials/sql.password', 'username': 'scorer'}]}]}}, Path.cwd())
        self.assertEqual([x['kind'] for x in result], ['ssh-key', 'password'])
        self.assertEqual(result[1]['username'], 'scorer')


class DesktopHTTPTests(unittest.TestCase):
    def test_remote_cleartext_and_embedded_credentials_rejected(self):
        for origin in ('http://10.0.0.1:8765', 'https://user:secret@127.0.0.1', 'http://127.0.0.1/private'):
            with self.assertRaises(ValueError):
                DesktopClient(origin, 'operator', 2, 'a'*48)

    def test_requests_are_signed_and_post_failure_is_not_retried(self):
        observed = []
        token = 'a'*48
        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                self.handle_request()
            def do_POST(self):
                self.handle_request()
            def handle_request(self):
                body = self.rfile.read(int(self.headers.get('Content-Length', 0)))
                observed.append((self.command, self.path, dict(self.headers), body))
                self.send_response(409 if self.command == 'POST' else 200)
                raw = b'{"status":"ok"}'
                self.send_header('Content-Length', str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)
            def log_message(self, *_):
                pass
        server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        client = DesktopClient(f'http://127.0.0.1:{server.server_port}', 'operator', 2, token)
        value = client.dashboard()
        # 2.0.9: the client adds its local receipt time for redo freshness.
        self.assertIsInstance(value.pop('client_received_at'), float)
        self.assertEqual(value, {'status': 'ok'})
        with self.assertRaisesRegex(RuntimeError, '409'):
            client.request('/api/v1/governance/resume', {})
        self.assertEqual(len(observed), 2)
        for method, target, headers, body in observed:
            from sentinel_blue.operator_auth import operator_signature
            expected = operator_signature(token, 'operator', 2, headers['X-SB-Operator-Timestamp'],
                headers['X-SB-Operator-Request-ID'], method, target, body)
            self.assertEqual(headers['X-SB-Operator-Signature'], expected)
            self.assertNotIn(token, repr(headers) + body.decode())
        self.assertNotEqual(observed[0][2]['X-SB-Operator-Request-ID'], observed[1][2]['X-SB-Operator-Request-ID'])


@unittest.skipUnless(os.environ.get('DISPLAY') or os.name == 'nt', 'Native graphical session required')
class DesktopWindowTests(unittest.TestCase):
    def test_render_disconnect_lock_and_terminal_independence(self):
        import tkinter as tk
        from sentinel_blue.desktop import DesktopWindow
        with tempfile.TemporaryDirectory() as directory:
            root = tk.Tk()
            window = DesktopWindow(root, directory=Path(directory)/'desktop')
            window.notify.set(False)
            try:
                window.render({'controller': {'governance': {}, 'service_recovery_status': []}, 'service_health': [
                    {'agent_id': 'web', 'service': 'nginx', 'health': 'healthy', 'native_state': 'running', 'passed_checks': 1, 'expected_checks': 1}]})
                display_deadline = time.monotonic() + 2
                while time.monotonic() < display_deadline:
                    root.update()
                    if window.footer_label.winfo_height() > 15:
                        break
                    time.sleep(.05)
                self.assertEqual(window.services.item('0', 'values')[2], 'healthy')
                self.assertLessEqual(window.footer_label.winfo_y() + window.footer_label.winfo_height(), root.winfo_height())
                self.assertGreater(window.footer_label.winfo_height(), 15)
                window.disconnected()
                self.assertEqual(window.services.item('0', 'values')[2], 'unknown')
                window.operator_key.set('private-input')
                window.lock()
                root.update()
                self.assertEqual(window.operator_key.get(), '')
                self.assertEqual(window.services.get_children(), ())
                self.assertIsNone(window.background_controller)
            finally:
                window.close()


if __name__ == '__main__':
    unittest.main()
