"""Read-only release review; private files, inert clients, and loopback sockets.

Requires the matching source tests on sys.path for setup_fixture/repair_fixture.
Native service, route and firewall mutations are never invoked.
"""
from contextlib import ExitStack
from dataclasses import asdict
from pathlib import Path
from unittest.mock import patch
import copy,hashlib,json,os,socket,subprocess,sys,tempfile,time,uuid
from sentinel_blue import collectors as c,setup_linux_transaction as tx
from sentinel_blue.detection import detect
from sentinel_blue.risk import RiskModel
from sentinel_blue.setup_recipes import _linux_service
from linux_19101_review_cases import setup_fixture,outcome


def corrected_spec(root,target):
    before=hashlib.sha256(target.read_bytes()).hexdigest()
    opt={'service':'sb-review-fixture.service','enable':False,'files':[
        {'path':str(target),'mode':'0644','previous_sha256':before}]}
    _,script,_=_linux_service(opt,root,generated_sources={str(target):'AFTER\n'})
    script=script.replace('/var/lib/sentinel-setup-backup.XXXXXXXX',str(root/'backup.XXXXXXXX'))
    spec={'version':1,'recipe':'linux-service','service':opt['service'],
          'apply_sha256':hashlib.sha256(script.encode()).hexdigest(),
          'files':[{'path':str(target),'mode':'0644','previous_sha256':before,
                    'sha256':hashlib.sha256(b'AFTER\n').hexdigest()}]}
    return spec,script


def readonly_admission():
    with setup_fixture() as (root,target,spec,token,ledger,run,state):
        target.write_text('TEAM_PREEXISTING\n');start=target.read_bytes()
        first=outcome(lambda:run('apply'))
        unchanged=target.read_bytes()==start
        correct,script=corrected_spec(root,target)
        result={'first':first,'original_configuration_preserved':unchanged,
            'native_transaction_exists':(tx.ROOT/token).exists(),
            'claims_count':len(list(tx.ROOT.glob('resource-*'))),
            'service_mutation_calls':tx.command.call_count,
            'ledger_statuses':[a['status'] for a in ledger.actions()],
            'corrected_plan_retry':'not run'}
        result['corrected_plan_retry']=outcome(lambda:tx.run('apply',correct,uuid.uuid4().hex,script,ledger_directory=root/'ledger'))
    with setup_fixture() as (root,target,spec,token,ledger,run,state):
        target.write_text('TEAM_PREEXISTING\n');correct,script=corrected_spec(root,target)
        result['corrected_plan_fresh_ledger']=outcome(lambda:tx.run('apply',correct,token,script,ledger_directory=root/'ledger'))
        result['fresh_control_content']=target.read_text()
    return result


def worker_isolation(package):
    # The parent interpreter itself is isolated. A native scoring worker should
    # inherit that property; benign sitecustomize writes only a private marker.
    code='''import sys,json,os
sys.path.insert(0,sys.argv[1])
from sentinel_blue.native_probes import run_native_probe
from sentinel_blue.runtime_environment import python_command
r={'parent_isolated':sys.flags.isolated,'parent_executable':sys.executable,'intended_python_command':python_command()}
try:r['probe']=run_native_probe('icmp',{},'127.0.0.1',5.0);r['success']=True
except Exception as e:r['probe']=type(e).__name__+':'+str(e);r['success']=False
print(json.dumps(r))
'''
    rows=[]
    with tempfile.TemporaryDirectory(prefix='sb-worker-isolation-') as tmp:
        p=Path(tmp);bin=p/'bin';bin.mkdir();marker=p/'ambient-marker';ran=p/'client-ran'
        ping=bin/'ping'
        import shlex
        ping.write_text('#!/bin/sh\nprintf "client ran" > '+shlex.quote(str(ran))+'\nprintf "fixture only\\n"\nexit 0\n');ping.chmod(0o700)
        custom=p/'custom';custom.mkdir()
        (custom/'sitecustomize.py').write_text('from pathlib import Path\nPath('+repr(str(marker))+').write_text("ambient child startup")\n')
        for variant in ('clean','invalid_home','ambient_site'):
            marker.unlink(missing_ok=True);ran.unlink(missing_ok=True)
            env=os.environ.copy();env.pop('PYTHONHOME',None);env.pop('PYTHONPATH',None)
            env.update(PATH=str(bin)+':/usr/bin:/bin',PYTHONDONTWRITEBYTECODE='1')
            if variant=='invalid_home':env['PYTHONHOME']='/nonexistent-sentinel-review-home'
            elif variant=='ambient_site':env['PYTHONPATH']=str(custom)
            proc=subprocess.run([sys.executable,'-I','-B','-c',code,package],env=env,capture_output=True,text=True,timeout=12)
            if proc.returncode:raise RuntimeError('Isolated parent fixture did not execute: '+proc.stderr[:500])
            row=json.loads(proc.stdout);row.update(variant=variant,ambient_marker=marker.exists(),native_client_ran=ran.exists())
            rows.append(row)
    return {'cases':rows,'scope':'Actual isolated parent, scoring worker and inert native client; no network traffic.'}


def case_services():
    baseline={'agent_id':'review','platform':'Linux','services':[
        {'name':'Worker.service','state':'running','start_mode':'enabled','restart_count':0,'result':'success'},
        {'name':'worker.service','state':'running','start_mode':'enabled','restart_count':0,'result':'success'}]}
    current=copy.deepcopy(baseline);current['services'][0].update(start_mode='masked',restart_count=7,result='exit-code')
    kinds=[a.kind for a in detect(current,baseline,set(),RiskModel())]
    comparison_before=copy.deepcopy(baseline);comparison_after=copy.deepcopy(current)
    comparison_before['services'][1]['name']='other.service';comparison_after['services'][1]['name']='other.service'
    control=[a.kind for a in detect(comparison_after,comparison_before,set(),RiskModel())]
    reverse_before=copy.deepcopy(baseline);reverse_after=copy.deepcopy(current)
    reverse_before['services'].reverse();reverse_after['services'].reverse()
    reversed_kinds=[a.kind for a in detect(reverse_after,reverse_before,set(),RiskModel())]
    return {'baseline_services':baseline['services'],'current_services':current['services'],
            'alert_kinds':kinds,'different_name_control_kinds':control,'same_rows_reverse_order_kinds':reversed_kinds}


def integrity_permissions():
    with tempfile.TemporaryDirectory(prefix='sb-permission-review-',dir='/var/lib') as tmp:
        root=Path(tmp);root.chmod(0o755);file=root/'example.conf'
        file.write_text('fixture-content-not-a-secret\n');file.chmod(0o600)
        # Use an already accessible interpreter for the independent OS access
        # check, not one whose distribution directory might be private.
        interpreter='/usr/bin/python3'
        def other_read():
            return subprocess.run([interpreter,'-I','-c','import pathlib,sys;pathlib.Path(sys.argv[1]).read_bytes()',str(file)],
                user=65534,group=65534,extra_groups=[],capture_output=True,timeout=5).returncode
        with patch.object(c,'_integrity_paths',return_value=[file]):
            be=[];before=[asdict(r) for r in c._integrity('linux',be)];read_before=other_read()
            mode_before=file.stat().st_mode&0o777;file.chmod(0o644);mode_after=file.stat().st_mode&0o777
            ae=[];after=[asdict(r) for r in c._integrity('linux',ae)];read_after=other_read()
            base={'agent_id':'review','platform':'Linux','integrity':before}
            kinds=[a.kind for a in detect(dict(base,integrity=after),base,set(),RiskModel())]
            file.write_text('CHANGED CONTENT\n');ce=[];changed=[asdict(r) for r in c._integrity('linux',ce)]
            control=[a.kind for a in detect(dict(base,integrity=changed),base,set(),RiskModel())]
        return {'mode_before':oct(mode_before),'mode_after':oct(mode_after),'equal_integrity_telemetry':before==after,
                'before':before,'after':after,'collector_errors':be+ae,
                'unrelated_uid':65534,'read_before_exit':read_before,'read_after_exit':read_after,
                'alert_kinds':kinds,'content_change_control_kinds':control}


def interfaces():
    results={}
    for kind in ('provider_error','provider_timeout'):
        with ExitStack() as stack:
            kwargs={'side_effect':subprocess.TimeoutExpired(['ip'],15)} if kind=='provider_timeout' else {
                'return_value':subprocess.CompletedProcess(['ip'],1,'','controlled denial')}
            stack.enter_context(patch.object(c,'_run',**kwargs))
            stack.enter_context(patch.object(c.socket,'if_nameindex',return_value=[(2,'eth0')]))
            stack.enter_context(patch.object(c.socket,'getaddrinfo',return_value=[(socket.AF_INET,1,6,'',('127.0.1.1',0))]))
            errors=[];observed=c._linux_interfaces(errors)
            results[kind]={'interfaces':[asdict(r) for r in observed],'collector_errors':errors}
    rows=[{'ifname':f'veth{i}','addr_info':[{'local':f'192.0.{i//250}.{i%250+1}','prefixlen':24}]} for i in range(513)]
    with patch.object(c,'_run',return_value=subprocess.CompletedProcess(['ip'],0,json.dumps(rows),'')):
        errors=[];observed=c._linux_interfaces(errors)
        results['overflow']={'provider_rows':len(rows),'returned_rows':len(observed),'collector_errors':errors,
                             'last_provider_interface_returned':any(r.name==rows[-1]['ifname'] for r in observed)}
    return results


def nonconflicting_loopback():
    from sentinel_blue.service_repair import restart_blockers,restart_futility,repair_parameters
    from test_service_repair import repair_fixture,damage
    from sentinel_blue.event_profile import EventProfile
    with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as existing:
        existing.bind(('127.0.0.2',0));existing.listen();port=existing.getsockname()[1]
        errors=[];listeners=[asdict(r) for r in c._linux_listeners(errors) if r.port==port]
        if not any(r['address']=='127.0.0.2' for r in listeners):raise RuntimeError('Native listener fixture missing')
        profile,baseline=repair_fixture();raw=copy.deepcopy(profile.raw)
        target=f'http://127.0.0.1:{port}/health';raw['services'][0]['expected_transactions'][0]['target']=target
        profile=EventProfile.from_dict(raw)
        baseline['probes'][0]['target']=target;current=damage(baseline)
        current['observed_at']=time.time();current['listeners']=listeners
        manifest=profile.services[0];service=manifest['service_id']
        findings=restart_blockers(service,manifest,current['services'][0],baseline['services'][0],current)
        held=outcome(lambda:repair_parameters(profile,'agent-one',service,baseline,current))
        control=copy.deepcopy(current);control['listeners']=[]
        control_result=outcome(lambda:repair_parameters(profile,'agent-one',service,baseline,control))
        with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as intended:
            intended.bind(('127.0.0.1',port));intended.listen();simultaneous=True
        return {'observed_listeners':listeners,'collector_errors':errors,'intended_endpoint':['127.0.0.1',port],
                'findings':findings,'restart_futility':restart_futility(findings),'repair_plan':held,
                'same_plan_without_unrelated_listener':control_result,'both_addresses_listened_simultaneously':simultaneous}


def run_all(package):
    return {'module_origin':tx.__file__,'python':sys.version,'cases':{
        'LINUX-31':readonly_admission(),'LINUX-32':worker_isolation(package),'LINUX-33':case_services(),
        'LINUX-34':integrity_permissions(),'LINUX-35':interfaces(),'LINUX-36':nonconflicting_loopback()}}
