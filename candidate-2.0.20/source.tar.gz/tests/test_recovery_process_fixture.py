"""Real loopback HTTP/process/file exercise with an owned service-manager adapter.

The adapter is deliberately not a claim of systemd or Windows SCM validation.
Controller planning, signed agent actions, file restoration, journals, application
probes and failure confirmations use the actual implementation.
"""

import copy
import hashlib
import json
import subprocess
import sys
import tempfile
import time
import unittest
from dataclasses import asdict
from contextlib import closing
from pathlib import Path
from unittest.mock import patch

from sentinel_blue.actions import ActionExecutor
from sentinel_blue.agent import execute_queued_action
from sentinel_blue.controller import ControllerApp
from sentinel_blue.event_profile import EventProfile
from sentinel_blue.probes import run_probes
from sentinel_blue.state import ActionJournal
from sentinel_blue.store import Store
from test_service_startup_repair import startup_fixture


WORKER = r'''
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
import sys
root=Path(sys.argv[1]); port=int(sys.argv[2]); latched=False
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        global latched
        latched=latched or (root/'memory.flag').exists()
        try: good=not latched and (root/'web.conf').read_bytes()==b'trusted'
        except OSError: good=False
        body=b'fixture-ok' if good else b'fixture-failure'
        self.send_response(200 if good else 503)
        self.send_header('Content-Length',str(len(body)))
        self.end_headers(); self.wfile.write(body)
    def log_message(self,*args): pass
class Server(HTTPServer): allow_reuse_address=True
server=Server(('127.0.0.1',port),Handler)
(root/'ready.tmp').write_text(str(server.server_port))
(root/'ready.tmp').replace(root/'ready.json')
server.serve_forever()
'''


class RecoveryProcessFixtureTests(unittest.TestCase):
    def test_real_application_recovers_from_three_combined_fault_scenarios(self):
        for case in ("disabled_missing", "disabled_corrupt", "unknown_memory_fault"):
            with self.subTest(case=case), tempfile.TemporaryDirectory() as directory:
                root = Path(directory).resolve()
                config = root / "web.conf"
                config.write_bytes(b"trusted")
                (root / "worker.py").write_text(WORKER)
                process = None
                mode = "enabled"
                port = 0

                def stop():
                    nonlocal process
                    if process is not None:
                        process.terminate()
                        try:
                            process.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            process.kill()
                            process.wait(timeout=5)
                        process = None

                def start():
                    nonlocal process, port
                    if mode != "enabled":
                        raise ValueError("owned service is disabled")
                    (root / "ready.json").unlink(missing_ok=True)
                    process = subprocess.Popen([sys.executable, str(root / "worker.py"), str(root), str(port)],
                                               stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    until = time.monotonic() + 5
                    while not (root / "ready.json").exists():
                        if process.poll() is not None or time.monotonic() >= until:
                            raise RuntimeError("owned HTTP fixture failed to start")
                        time.sleep(0.01)
                    port = int((root / "ready.json").read_text())

                try:
                    start()
                    profile, baseline, _ = startup_fixture(str(config))
                    spec = {"name": "local-web", "kind": "http", "target": f"http://127.0.0.1:{port}/health",
                            "expected_status": [200], "expected_body": "fixture-ok", "timeout": 1}
                    raw = copy.deepcopy(profile.raw)
                    raw["services"][0]["expected_transactions"] = [spec]
                    profile = EventProfile.from_dict(raw)
                    executor = ActionExecutor(root / "agent", allow_service_recovery=True, allow_restoration=True,
                                               authorized_networks=["127.0.0.0/8"])
                    sequence = 0

                    def observe():
                        nonlocal sequence
                        sequence += 1
                        row = copy.deepcopy(baseline)
                        row.update(sequence=sequence, observed_at=time.time())
                        row["services"][0].update(state="running" if process and process.poll() is None else "stopped", start_mode=mode)
                        observed = executor.restore_points._read_target_if_present(config)
                        row["integrity"] = [] if observed is None else [{
                            "path": str(config), "sha256": hashlib.sha256(observed[0]).hexdigest(),
                            "security_descriptor_sha256": executor.restore_points._metadata_security_descriptor_sha256(observed[1]),
                            "size": len(observed[0]), "modified_at": config.stat().st_mtime, "readable": True}]
                        row["probes"] = [asdict(value) for value in run_probes([spec], ["127.0.0.0/8"])]
                        return row

                    def set_state(service, desired):
                        self.assertEqual(service, "web.service")
                        start() if desired == "running" else stop()

                    def set_mode(service, expected, desired):
                        nonlocal mode
                        self.assertEqual(mode, expected)
                        mode = desired

                    with closing(Store(":memory:")) as store, \
                         patch.object(executor, "_service_state", side_effect=lambda _: "running" if process and process.poll() is None else "stopped"), \
                         patch.object(executor, "_set_service_state", side_effect=set_state), \
                         patch.object(executor.repairs, "_startup_mode", side_effect=lambda _: mode), \
                         patch.object(executor.repairs, "_change_startup", side_effect=set_mode):
                        app = ControllerApp(store, "t" * 32, operator_token="o" * 32,
                                            event_profile=profile, auto_recover_services=True, auto_restore=True)
                        journal = ActionJournal(root / "journal")

                        def execute(action, telemetry):
                            result = execute_queued_action(journal, executor, asdict(action), telemetry,
                                                           {"action_safe": True}, profile)
                            app.complete_action({**result, "action_id": action.action_id}, "agent-one")
                            self.assertTrue(result["success"], result)
                            return result

                        initial = observe()
                        self.assertTrue(initial["probes"][0]["healthy"])
                        app.ingest(initial)
                        promotion = app.approve_baseline("agent-one")
                        action = next(item for item in store.pending_actions("agent-one")
                                      if item.action_id == promotion["restore_point_action_id"])
                        execute(action, initial)
                        self.assertEqual(store.baseline_status("agent-one"), "approved")
                        if case == "unknown_memory_fault":
                            (root / "memory.flag").write_text("inert unfamiliar application state")
                            self.assertFalse(observe()["probes"][0]["healthy"])
                            (root / "memory.flag").unlink()
                        else:
                            stop()
                            mode = "disabled"
                            config.unlink() if case == "disabled_missing" else config.write_bytes(b"damaged")
                        first = observe()
                        app.ingest(first)
                        self.assertFalse(any(item.action_type == "repair_service" for item in store.pending_actions("agent-one")))
                        second = observe()
                        app.ingest(second)
                        action = next(item for item in store.pending_actions("agent-one") if item.action_type == "repair_service")
                        result = execute(action, second)
                        self.assertTrue(result["stable_health"])
                        self.assertEqual((mode, config.read_bytes()), ("enabled", b"trusted"))
                        self.assertTrue(observe()["probes"][0]["healthy"])
                        status = app.dashboard()["controller"]["service_recovery_status"][0]
                        self.assertIn("reasoning", status)
                finally:
                    stop()


if __name__ == "__main__":
    unittest.main()
