"""2.0.3: repair reaches every service setup, not only hand-written profiles.

Part 1 — the repair engine itself:
  * a masked unit can be repaired, with its own explicit grant;
  * a restored systemd unit or drop-in is reloaded before the service starts;
  * an operator-approved repair is authorized by the approval list, an automatic
    one by the automatic list, each checked where it is used.
"""
import copy
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from sentinel_blue.actions import ActionExecutor
from sentinel_blue.controller import ControllerApp
from sentinel_blue.store import Store
from sentinel_blue.event_profile import EventProfile
from sentinel_blue.protocol import ProbeResult
from sentinel_blue.service_repair import (normalize_repair_policy, repair_parameters,
                                          validate_repair_contract, validate_repair_shape)
from sentinel_blue.service_repair_executor import touches_units
from sentinel_blue.service_startup import change_start_mode
from test_service_repair import repair_fixture, damage
from test_store_controller import _promote_integrity_baseline


def masked_fixture(path="/etc/web.conf", mode="masked", unmask=True):
    profile, baseline = repair_fixture(path)
    raw = copy.deepcopy(profile.raw)
    raw["services"][0]["repair_policy"]["restore_start_mode"] = "enabled"
    if unmask is not None:
        raw["services"][0]["repair_policy"]["unmask"] = unmask
    profile = EventProfile.from_dict(raw)
    baseline["services"][0]["start_mode"] = "enabled"
    current = damage(baseline)
    current["services"][0]["start_mode"] = mode
    current["services"][0]["state"] = "inactive"
    return profile, baseline, current


class MaskedPlanning(unittest.TestCase):
    def test_a_masked_unit_is_repaired_to_enabled_with_the_grant(self):
        for mode in ("masked", "masked-runtime"):
            with self.subTest(mode=mode):
                profile, baseline, current = masked_fixture(mode=mode)
                plan = repair_parameters(profile, "agent-one", "web.service", baseline, current)
                self.assertEqual(plan["repair"]["startup"], {"observed": mode, "desired": "enabled"})
                validate_repair_contract(profile, "agent-one", plan, current)

    def test_without_the_unmask_grant_a_mask_still_holds(self):
        for unmask in (None, False):
            with self.subTest(unmask=unmask):
                profile, baseline, current = masked_fixture(unmask=unmask)
                with self.assertRaisesRegex(ValueError, "startup"):
                    repair_parameters(profile, "agent-one", "web.service", baseline, current)

    def test_unmask_needs_enabled_as_the_restored_mode(self):
        profile, _, _ = masked_fixture()
        policy = copy.deepcopy(profile.services[0]["repair_policy"])
        policy.pop("restore_start_mode")
        with self.assertRaisesRegex(ValueError, "unmask"):
            normalize_repair_policy(policy, profile.services[0])
        for bad in ("yes", 1, None):
            policy = copy.deepcopy(profile.services[0]["repair_policy"])
            policy["unmask"] = bad
            with self.subTest(value=bad), self.assertRaises(ValueError):
                normalize_repair_policy(policy, profile.services[0])

    def test_windows_has_no_mask_to_repair(self):
        profile, baseline, current = masked_fixture()
        for value in (baseline, current):
            value["platform"] = "Windows"
            value["integrity"][0]["security_descriptor_sha256"] = "a" * 64
        with self.assertRaises(ValueError):
            repair_parameters(profile, "agent-one", "web.service", baseline, current)

    def test_a_masked_observation_can_only_be_repaired_to_enabled(self):
        profile, baseline, current = masked_fixture()
        plan = repair_parameters(profile, "agent-one", "web.service", baseline, current)
        for desired in ("auto", "manual"):
            bad = copy.deepcopy(plan)
            bad["repair"]["startup"]["desired"] = desired
            with self.subTest(desired=desired), self.assertRaises(ValueError):
                validate_repair_shape(bad)


class MaskedNativeCommands(unittest.TestCase):
    @staticmethod
    def ok():
        return subprocess.CompletedProcess([], 0, "", "")

    def run_change(self, expected, desired, final=None):
        with patch("sentinel_blue.service_startup.platform.system", return_value="Linux"), \
             patch("sentinel_blue.service_startup.read_start_mode", side_effect=[expected, final or desired]), \
             patch("sentinel_blue.service_startup._run", return_value=self.ok()) as run:
            change_start_mode("web.service", expected, desired)
        return [call.args[0] for call in run.call_args_list]

    def test_unmask_then_enable(self):
        self.assertEqual(self.run_change("masked", "enabled"),
                         [["systemctl", "unmask", "web.service"], ["systemctl", "enable", "web.service"]])
        self.assertEqual(self.run_change("masked-runtime", "enabled"),
                         [["systemctl", "unmask", "--runtime", "web.service"],
                          ["systemctl", "enable", "web.service"]])

    def test_rollback_returns_the_unit_to_its_mask(self):
        self.assertEqual(self.run_change("enabled", "masked"),
                         [["systemctl", "disable", "web.service"], ["systemctl", "mask", "web.service"]])
        self.assertEqual(self.run_change("disabled", "masked-runtime"),
                         [["systemctl", "mask", "--runtime", "web.service"]])

    def test_a_failed_step_stops_the_sequence(self):
        failed = subprocess.CompletedProcess([], 1, "", "")
        with patch("sentinel_blue.service_startup.platform.system", return_value="Linux"), \
             patch("sentinel_blue.service_startup.read_start_mode", return_value="masked"), \
             patch("sentinel_blue.service_startup._run", return_value=failed) as run:
            with self.assertRaisesRegex(ValueError, "unmask"):
                change_start_mode("web.service", "masked", "enabled")
        self.assertEqual(run.call_count, 1)

    def test_the_result_is_verified(self):
        with self.assertRaisesRegex(ValueError, "verification"):
            self.run_change("masked", "enabled", final="disabled")


class MaskedExecution(unittest.TestCase):
    """The real executor, with only the service manager replaced."""

    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name).resolve()
        self.target = self.root / "web.conf"
        self.target.write_bytes(b"trusted")
        self.profile, self.baseline, self.current = masked_fixture(str(self.target))
        self.executor = ActionExecutor(self.root / "state", allow_restoration=True,
                                       allow_service_recovery=True, authorized_networks=["127.0.0.0/8"])
        self.assertTrue(self.executor.restore_points.capture(self.baseline["integrity"])["success"])
        self.target.write_bytes(b"damaged")
        self.parameters = repair_parameters(self.profile, "agent-one", "web.service", self.baseline, self.current)
        self.mode, self.state, self.events = "masked", "stopped", []
        repairs = self.executor.repairs
        for target, name, effect in ((self.executor, "_service_state", self.native_state),
                                     (self.executor, "_set_service_state", self.set_state),
                                     (repairs, "_startup_mode", lambda _: self.mode),
                                     (repairs, "_change_startup", self.set_mode),
                                     (repairs, "_reload_units", lambda: self.events.append(("reload",))),
                                     (self.executor, "_wait_for_service_probes", self.probe)):
            item = patch.object(target, name, side_effect=effect)
            item.start()
            self.addCleanup(item.stop)

    def native_state(self, _):
        # systemd reports a masked unit as not loaded; the generic reader says unknown.
        return "unknown" if self.mode.startswith("masked") else self.state

    def set_state(self, _service, desired):
        if desired == "running":
            self.assertEqual((self.mode, self.target.read_bytes()), ("enabled", b"trusted"))
        self.events.append(("state", desired))
        self.state = desired

    def set_mode(self, _service, expected, desired):
        self.assertEqual(self.mode, expected)
        self.events.append(("mode", desired))
        self.mode = desired

    def probe(self, specs, **_):
        return [ProbeResult(item["name"], item["target"], True) for item in specs], 3, True

    def test_a_masked_service_is_unmasked_restored_and_started(self):
        result = self.executor.execute("repair_service", self.parameters, self.current)
        self.assertTrue(result["success"], result)
        self.assertEqual(self.events, [("mode", "enabled"), ("state", "running")])
        self.assertEqual((self.mode, self.state, self.target.read_bytes()), ("enabled", "running", b"trusted"))

    def test_a_failed_repair_puts_the_mask_back(self):
        self.executor._wait_for_service_probes.side_effect = lambda *a, **k: ([], 3, False)
        result = self.executor.execute("repair_service", self.parameters, self.current)
        self.assertFalse(result["success"])
        self.assertTrue(result["rolled_back"], result)
        self.assertEqual((self.mode, self.target.read_bytes()), ("masked", b"damaged"))

    def test_a_failure_between_unmask_and_enable_still_rolls_back(self):
        def partial(_service, expected, desired):
            if desired == "enabled":
                self.mode = "disabled"          # unmasked, never enabled
                raise ValueError("inert enable failure fixture")
            self.set_mode(_service, expected, desired)
        self.executor.repairs._change_startup.side_effect = partial
        result = self.executor.execute("repair_service", self.parameters, self.current)
        self.assertFalse(result["success"])
        self.assertTrue(result["rolled_back"], result)
        self.assertEqual((self.mode, self.target.read_bytes()), ("masked", b"damaged"))


class UnitFilesAreReloaded(unittest.TestCase):
    def test_unit_paths_are_recognised(self):
        for path in ("/etc/systemd/system/web.service", "/etc/systemd/system/web.service.d/override.conf",
                     "/lib/systemd/system/nginx.service", "/usr/lib/systemd/system/sshd.service"):
            with self.subTest(path=path):
                self.assertTrue(touches_units([path]))
        for path in ("/etc/nginx/nginx.conf", "/etc/systemd/system.conf", "/home/x/.config/systemd/user/a.service"):
            with self.subTest(path=path):
                self.assertFalse(touches_units([path]))

    def test_restoring_a_unit_file_reloads_before_the_start(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name).resolve()
        target = root / "web.conf"
        target.write_bytes(b"trusted")
        profile, baseline = repair_fixture(str(target))
        executor = ActionExecutor(root / "state", allow_restoration=True, allow_service_recovery=True,
                                  authorized_networks=["127.0.0.0/8"])
        self.assertTrue(executor.restore_points.capture(baseline["integrity"])["success"])
        target.write_bytes(b"damaged")
        current = damage(baseline)
        parameters = repair_parameters(profile, "agent-one", "web.service", baseline, current)
        events, state = [], {"value": "stopped"}

        def set_state(_s, desired):
            events.append(("state", desired))
            state["value"] = desired
        with patch("sentinel_blue.service_repair_executor.touches_units", return_value=True), \
             patch.object(executor, "_service_state", side_effect=lambda _: state["value"]), \
             patch.object(executor, "_set_service_state", side_effect=set_state), \
             patch.object(executor.repairs, "_reload_units", side_effect=lambda: events.append(("reload",))), \
             patch.object(executor, "_wait_for_service_probes",
                          side_effect=lambda specs, **_: ([ProbeResult(s["name"], s["target"], True) for s in specs], 3, True)):
            result = executor.execute("repair_service", parameters, current)
        self.assertTrue(result["success"], result)
        self.assertEqual(events, [("reload",), ("state", "running")])


class ApprovalAuthority(unittest.TestCase):
    def approval_only(self):
        profile, baseline = repair_fixture()
        raw = copy.deepcopy(profile.raw)
        raw["services"][0]["allowed_automatic_actions"] = [
            a for a in raw["services"][0]["allowed_automatic_actions"] if a != "repair_service"]
        return EventProfile.from_dict(raw), baseline

    def test_an_operator_approved_repair_uses_the_approval_list(self):
        profile, baseline = self.approval_only()
        current = damage(baseline)
        with self.assertRaisesRegex(ValueError, "automatic"):
            repair_parameters(profile, "agent-one", "web.service", baseline, current)
        plan = repair_parameters(profile, "agent-one", "web.service", baseline, current, automated=False)
        validate_repair_contract(profile, "agent-one", plan, current, automated=False)
        with self.assertRaises(ValueError):
            validate_repair_contract(profile, "agent-one", plan, current, automated=True)

    def test_an_automatic_grant_does_not_imply_an_approval_grant(self):
        profile, baseline = repair_fixture()
        raw = copy.deepcopy(profile.raw)
        raw["services"][0]["approval_actions"] = [
            a for a in raw["services"][0]["approval_actions"] if a != "repair_service"]
        profile = EventProfile.from_dict(raw)
        with self.assertRaisesRegex(ValueError, "operator-approved"):
            repair_parameters(profile, "agent-one", "web.service", baseline, damage(baseline), automated=False)


class ApprovalModeOffersRepair(unittest.TestCase):
    """Approval-based recovery gets the same repair, for a person to approve."""

    def app(self, profile):
        store = Store(":memory:")
        self.addCleanup(store.close)
        return store, ControllerApp(store, "t" * 32, operator_token="o" * 32, event_profile=profile,
                                    auto_recover_services=False, auto_restore=False,
                                    restoration_probes=profile.services[0]["expected_transactions"])

    def open_alerts(self, store, kind):
        return [row for row in store.dashboard()["alerts"] if row["kind"] == kind and row["status"] == "open"]

    def test_a_broken_service_is_offered_for_repair_and_nothing_runs_until_approved(self):
        profile, baseline = repair_fixture()
        store, app = self.app(profile)
        app.ingest(baseline)
        _promote_integrity_baseline(app, store, "agent-one")
        app.ingest(damage(baseline, 2))
        repairs = self.open_alerts(store, "service_repair_required")
        self.assertEqual(len(repairs), 1)
        self.assertEqual(repairs[0]["recommended_action"], "repair_service")
        self.assertFalse(self.open_alerts(store, "baseline_service_stopped"),
                         "the weaker restart-only recommendation is replaced, not repeated")
        self.assertFalse(any(item.action_type == "repair_service" for item in store.pending_actions("agent-one")))
        result = app.decision(repairs[0]["alert_id"], "approve")
        self.assertEqual(result["status"], "queued", result)
        queued = [item for item in store.pending_actions("agent-one") if item.action_type == "repair_service"]
        self.assertEqual(len(queued), 1)
        self.assertFalse(queued[0].automated)
        plan = queued[0].parameters
        self.assertEqual(plan["repair"]["restore_files"][0]["path"], "/etc/web.conf")
        validate_repair_contract(profile, "agent-one", plan, damage(baseline, 2), automated=False)

    def test_an_approval_only_manifest_can_still_be_repaired(self):
        """The guided approval-based setup grants repair for approval only."""
        profile, baseline = repair_fixture()
        raw = copy.deepcopy(profile.raw)
        raw["services"][0]["allowed_automatic_actions"] = [
            a for a in raw["services"][0]["allowed_automatic_actions"] if a != "repair_service"]
        profile = EventProfile.from_dict(raw)
        store, app = self.app(profile)
        app.ingest(baseline)
        _promote_integrity_baseline(app, store, "agent-one")
        app.ingest(damage(baseline, 2))
        repairs = self.open_alerts(store, "service_repair_required")
        self.assertEqual(len(repairs), 1)
        self.assertEqual(app.decision(repairs[0]["alert_id"], "approve")["status"], "queued")

    def test_no_offer_without_an_approval_grant(self):
        profile, baseline = repair_fixture()
        raw = copy.deepcopy(profile.raw)
        raw["services"][0]["approval_actions"] = [
            a for a in raw["services"][0]["approval_actions"] if a != "repair_service"]
        profile = EventProfile.from_dict(raw)
        store, app = self.app(profile)
        app.ingest(baseline)
        _promote_integrity_baseline(app, store, "agent-one")
        app.ingest(damage(baseline, 2))
        self.assertFalse(self.open_alerts(store, "service_repair_required"))
        self.assertTrue(self.open_alerts(store, "baseline_service_stopped"))


class GuidedSetupGrantsRepair(unittest.TestCase):
    """Every service chosen in Service setup gets the repair a profile author would write."""

    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.runtime = self.root / "sentinel.pyz"
        self.runtime.write_bytes(b"fixture runtime")

    def workspace(self, selection=("openssh-server",), autonomy="approval-based", custom=None, watch=()):
        from sentinel_blue.linux_workspace import prepare_workspace
        with patch("sentinel_blue.collectors.integrity_watch_paths", return_value=[str(p) for p in watch]):
            cfg, plan = prepare_workspace(self.root / "sessions", self.runtime, list(selection), {}, {},
                                          autonomy=autonomy, custom_services=custom)
        from sentinel_blue.event_profile import load_event_profile
        return cfg, plan, load_event_profile(cfg["event_profile"])

    def test_each_service_can_repair_itself_in_both_modes(self):
        for autonomy, automatic in (("approval-based", False), ("guarded-autonomous", True)):
            with self.subTest(autonomy=autonomy):
                _, _, profile = self.workspace(autonomy=autonomy)
                manifest = profile.services[0]
                policy = manifest["repair_policy"]
                self.assertEqual((policy["restart_unhealthy"], policy["restore_start_mode"], policy["unmask"]),
                                 (True, "enabled", True))
                self.assertIn("repair_service", manifest["approval_actions"])
                self.assertIn("rollback_service_repair", manifest["approval_actions"])
                self.assertEqual("repair_service" in manifest["allowed_automatic_actions"], automatic)
                self.assertEqual(profile.action_allowed("repair_service", automated=True), automatic)
                self.assertTrue(profile.action_allowed("repair_service", automated=False))

    def test_host_wide_files_are_watched_but_never_restored_by_a_service(self):
        shadow = self.root / "shadow"
        shadow.write_text("host identity")
        cfg, _, profile = self.workspace(watch=[shadow])
        manifest = profile.services[0]
        self.assertIn(str(shadow.resolve()), manifest["required_files"], "still watched and alerted on")
        self.assertNotIn(str(shadow.resolve()), manifest["repair_policy"]["restore_files"])
        self.assertEqual(cfg["repair_coverage"][manifest["service_id"]]["restorable"],
                         manifest["repair_policy"]["restore_files"])

    def test_generated_files_are_what_a_configured_service_restores(self):
        import hashlib
        source = self.root / "index.html"
        source.write_text("local test")
        options = {"nginx": {"name": "scope-test", "listen_address": "127.0.0.1", "port": 18081,
                             "content": {"path": str(source), "sha256": hashlib.sha256(source.read_bytes()).hexdigest()}}}
        from sentinel_blue.linux_workspace import prepare_workspace
        from sentinel_blue.event_profile import load_event_profile
        with patch("sentinel_blue.collectors.integrity_watch_paths", return_value=[]):
            cfg, _ = prepare_workspace(self.root / "sessions", self.runtime, ["nginx"], options, {})
        restore = set(load_event_profile(cfg["event_profile"]).services[0]["repair_policy"]["restore_files"])
        self.assertTrue({"/etc/nginx/conf.d/sentinel-scope-test.conf",
                         "/var/lib/sentinel-blue-apps/scope-test/www/index.html"} <= restore)


class CustomServices(unittest.TestCase):
    def check(self, **extra):
        return {"kind": "tcp", "target": "127.0.0.1", "port": 9000, "timeout": 5, **extra}

    def test_a_custom_unit_is_validated_type_first(self):
        from sentinel_blue.custom_services import normalize_custom_service
        good = normalize_custom_service({"unit": "scoreboard.service", "files": ["/etc/scoreboard/app.yml"],
                                         "check": self.check()})
        self.assertEqual(good["label"], "scoreboard")
        for bad in ({"unit": "scoreboard", "check": self.check()},                  # no .service
                    {"unit": "-x.service", "check": self.check()},                  # option injection
                    {"unit": "a b.service", "check": self.check()},
                    {"unit": 5, "check": self.check()},
                    {"unit": "s.service", "check": {"kind": "tcp", "target": "10.0.0.5", "port": 9000}},
                    {"unit": "s.service", "check": self.check(), "files": "/etc/s.conf"},
                    {"unit": "s.service", "check": self.check(), "files": ["relative.conf"]},
                    {"unit": "s.service", "check": self.check(), "files": ["/etc/../etc/shadow"]},
                    {"unit": "s.service", "check": self.check(), "extra": 1}):
            with self.subTest(spec=bad), self.assertRaises(ValueError):
                normalize_custom_service(bad)

    def test_files_that_decide_who_can_log_in_are_never_a_services_to_restore(self):
        from sentinel_blue.custom_services import normalize_custom_service
        for path in ("/etc/shadow", "/etc/passwd", "/etc/sudoers", "/etc/sudoers.d/ops",
                     "/root/.bashrc", "/home/blue/.ssh/authorized_keys", "/etc/pam.d/sshd", "/proc/1/environ"):
            with self.subTest(path=path), self.assertRaisesRegex(ValueError, "monitored|canonical"):
                normalize_custom_service({"unit": "s.service", "files": [path], "check": self.check()})

    def test_a_catalogued_unit_is_chosen_from_the_list_instead(self):
        from sentinel_blue.desktop_services import service_plan
        with self.assertRaisesRegex(ValueError, "catalogued"):
            service_plan([], "local-linux", custom=[{"unit": "nginx.service", "check": self.check()}])

    def test_a_custom_service_alone_makes_a_plan(self):
        from sentinel_blue.desktop_services import service_plan
        fragment = service_plan([], "local-linux", custom=[{"unit": "scoreboard.service", "check": self.check()}])
        self.assertEqual(len(fragment["tasks"]), 1)
        task = fragment["tasks"][0]
        self.assertEqual((task["recipe"], task["options"]),
                         ("linux-service", {"service": "scoreboard.service", "enable": True, "unmask": True}))

    def test_a_custom_service_gets_the_same_repair_in_the_profile(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)
        runtime = root / "sentinel.pyz"
        runtime.write_bytes(b"fixture runtime")
        config = root / "app.yml"
        config.write_text("port: 9000")
        from sentinel_blue.linux_workspace import prepare_workspace
        from sentinel_blue.event_profile import load_event_profile
        custom = [{"unit": "scoreboard.service", "label": "Scoreboard", "files": [str(config.resolve())],
                   "check": self.check()}]
        with patch("sentinel_blue.collectors.integrity_watch_paths", return_value=[]):
            cfg, plan = prepare_workspace(root / "sessions", runtime, ["openssh-server"], {}, {},
                                          autonomy="guarded-autonomous", custom_services=custom)
        profile = load_event_profile(cfg["event_profile"])
        manifest = next(m for m in profile.services if m["service_id"] == "scoreboard.service")
        self.assertEqual(manifest["repair_policy"]["restore_files"], [str(config.resolve())])
        self.assertIn("repair_service", manifest["allowed_automatic_actions"])
        self.assertEqual(manifest["port"], 9000)
        self.assertIn("custom-scoreboard", {task["id"] for task in plan["tasks"]})

    def test_one_file_has_one_owner(self):
        from sentinel_blue.custom_services import normalize_custom_services
        with self.assertRaisesRegex(ValueError, "one owner"):
            normalize_custom_services([
                {"unit": "a.service", "files": ["/etc/shared.conf"], "check": self.check()},
                {"unit": "b.service", "files": ["/etc/shared.conf"], "check": self.check(port=9001)}])



def _tk():
    import os
    if not os.environ.get("DISPLAY"):
        raise unittest.SkipTest("needs a display")
    try:
        import tkinter as tk
        from tkinter import ttk
        root = tk.Tk()
    except Exception as exc:  # no Tk in this interpreter, or no display
        raise unittest.SkipTest(str(exc))
    root.withdraw()
    return tk, ttk, root


class CustomServicePanel(unittest.TestCase):
    """The Service setup tab can add, keep and remove a service outside the catalog."""

    def setUp(self):
        tk, ttk, self.root = _tk()
        self.addCleanup(self.root.destroy)
        from sentinel_blue.desktop_services import ServiceSelectionPanel
        self.panel = ServiceSelectionPanel(self.root, (tk, ttk))
        self.panel.observe({}, host="local-linux")

    def fill(self, dialog, unit="scoreboard.service", files=("/etc/scoreboard/app.yml",), port="9000"):
        dialog.fields["unit"].set(unit)
        dialog.fields["kind"].set("tcp")
        dialog.fields["target"].set("127.0.0.1")
        dialog.fields["port"].set(port)
        dialog.files.delete("1.0", "end")
        dialog.files.insert("1.0", "\n".join(files))

    def test_a_custom_service_alone_is_ready_for_review(self):
        dialog = self.panel.edit_custom(None)
        self.fill(dialog)
        dialog.save()
        self.assertEqual([row["unit"] for row in self.panel.custom_services], ["scoreboard.service"])
        self.assertTrue(self.panel.tree.exists("custom:scoreboard.service"))
        report = self.panel.report()
        self.assertTrue(report["ready"])
        self.assertEqual(report["custom"], ["scoreboard.service"])
        self.assertIn("1 custom", self.panel.summary.get())

    def test_a_refused_file_keeps_nothing_and_says_why(self):
        dialog = self.panel.edit_custom(None)
        self.fill(dialog, files=("/etc/shadow",))
        dialog.save()
        self.assertEqual(self.panel.custom_services, [])
        self.assertIn("monitored", dialog.error.get())
        self.assertFalse(self.panel.report()["ready"])

    def test_a_catalogued_unit_is_refused(self):
        dialog = self.panel.edit_custom(None)
        self.fill(dialog, unit="nginx.service", files=())
        dialog.save()
        self.assertEqual(self.panel.custom_services, [])
        self.assertIn("catalogued", dialog.error.get())

    def test_editing_replaces_and_duplicates_are_refused(self):
        self.panel.save_custom({"unit": "scoreboard.service", "check": {"kind": "tcp", "target": "127.0.0.1", "port": 9000}})
        self.panel.tree.selection_set("custom:scoreboard.service")
        self.panel.toggle()        # double-click opens the form rather than deselecting
        dialog = self.panel.custom_editor
        self.assertIsNotNone(dialog)
        self.fill(dialog, port="9100")
        dialog.save()
        self.assertEqual(len(self.panel.custom_services), 1)
        self.assertEqual(self.panel.custom_services[0]["check"]["port"], 9100)
        with self.assertRaisesRegex(ValueError, "already"):
            self.panel.save_custom({"unit": "scoreboard.service", "check": {"kind": "tcp", "target": "127.0.0.1", "port": 9000}})

    def test_catalog_editors_do_not_break_on_a_custom_row(self):
        self.panel.save_custom({"unit": "scoreboard.service", "check": {"kind": "tcp", "target": "127.0.0.1", "port": 9000}})
        for editor in (self.panel._edit_ports, self.panel._edit_options):
            self.panel.custom_editor = None
            self.panel.tree.selection_set("custom:scoreboard.service")
            editor()
            self.assertIsNotNone(self.panel.custom_editor)

    def test_custom_services_belong_to_their_host_and_can_be_removed(self):
        self.panel.save_custom({"unit": "scoreboard.service", "check": {"kind": "tcp", "target": "127.0.0.1", "port": 9000}})
        self.panel.observe({}, host="other")
        self.assertEqual(self.panel.custom_services, [])
        self.panel.observe({}, host="local-linux")
        self.assertEqual(len(self.panel.custom_services), 1)
        self.panel.tree.selection_set("custom:scoreboard.service")
        self.panel.remove_custom()
        self.assertEqual(self.panel.custom_services, [])
        self.assertFalse(self.panel.tree.exists("custom:scoreboard.service"))


class ReviewShowsRepairCoverage(unittest.TestCase):
    def test_the_plan_review_lists_what_each_repair_restores(self):
        from sentinel_blue.linux_desktop_setup import plan_description
        plan = {"tasks": [{"id": "custom-scoreboard", "host": "local-linux", "recipe": "linux-service",
                           "configuration": {}, "probes": [{"kind": "tcp"}]}]}
        coverage = {"scoreboard.service": {"restorable": ["/etc/scoreboard/app.yml"], "alert_only": []}}
        approval = plan_description(plan, (), coverage, "approval-based")
        guarded = plan_description(plan, (), coverage, "guarded-autonomous")
        self.assertIn("scoreboard.service: 1 file(s) restorable", approval)
        self.assertIn("    /etc/scoreboard/app.yml", approval)
        self.assertIn("nothing is restored until you approve it", approval)
        self.assertIn("repaired automatically", guarded)
        self.assertIn("never restored by a service repair", approval)


if __name__ == "__main__":
    unittest.main()
