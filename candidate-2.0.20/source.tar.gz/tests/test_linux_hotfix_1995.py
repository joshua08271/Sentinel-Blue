"""Regressions for Linux review findings 1-4; private fixtures, no native mutations."""
from contextlib import ExitStack
import ast
import hashlib
import json
import os
from pathlib import Path
import shlex
import signal
import subprocess
import sys
import tempfile
import time
import unittest
import uuid
from unittest.mock import patch

from sentinel_blue import collectors, setup_linux_transaction as tx, network_native as net
from sentinel_blue import setup_transport as transport
from sentinel_blue.setup_recipes import _linux_service
from sentinel_blue.protocol import FirewallState, MemoryCapacity, Service


@unittest.skipUnless(os.name == 'posix' and os.geteuid() == 0, 'root-owned private filesystem fixtures')
class FailedApplyOwnership(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='sb-hotfix-', dir='/var/lib')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.path = self.root / 'configuration with spaces.conf'
        self.path.write_text('ORIGINAL\n'); self.path.chmod(0o640)
        self.before = tx.fingerprint(self.path)
        self.bin = self.root / 'bin'; self.bin.mkdir()
        self.control = self.bin / 'systemctl'
        self.control.write_text('#!/bin/sh\ncase "$1" in is-enabled) echo disabled;; esac\nexit 0\n')
        self.control.chmod(0o700)

    def make(self, validation, *, absent=False):
        if absent:
            self.path.unlink(missing_ok=True)
        options = {'service': 'sb-private-fixture.service', 'enable': False,
                   'files': [{'path': str(self.path), 'mode': '0644',
                     'previous_sha256': 'absent' if absent else hashlib.sha256(b'ORIGINAL\n').hexdigest()}]}
        _, script, _ = _linux_service(options, self.root,
            generated_sources={str(self.path): 'SENTINEL\n'}, validation_script=validation)
        # Only the private backup location and service-control executable differ.
        script = script.replace('/var/lib/sentinel-setup-backup.XXXXXXXX', str(self.root/'backup.XXXXXXXX'))
        spec = {'version': 1, 'recipe': 'linux-service', 'service': options['service'],
                'apply_sha256': hashlib.sha256(script.encode()).hexdigest(),
                'files': [{'path': str(self.path), 'mode': '0644',
                           'previous_sha256': options['files'][0]['previous_sha256'],
                           'sha256': hashlib.sha256(b'SENTINEL\n').hexdigest()}]}
        return script, spec

    def execute(self, script):
        return subprocess.run(['/bin/sh'], input=script, text=True, capture_output=True,
            env={**os.environ, 'PATH': str(self.bin)+':'+os.environ['PATH']}, timeout=15)

    def test_teammate_edit_survives_failed_validation(self):
        script, _ = self.make('printf "TEAMMATE\\n" > '+shlex.quote(str(self.path))+'\nexit 7\n')
        result = self.execute(script)
        self.assertEqual(self.path.read_text(), 'TEAMMATE\n')
        self.assertEqual(result.returncode, 43)

    def test_new_file_third_state_is_not_deleted(self):
        script, _ = self.make('printf "TEAMMATE\\n" > '+shlex.quote(str(self.path))+'\nexit 7\n', absent=True)
        self.assertEqual(self.execute(script).returncode, 43)
        self.assertEqual(self.path.read_text(), 'TEAMMATE\n')

    def test_metadata_only_edit_is_a_conflict(self):
        script, _ = self.make('chmod 0600 '+shlex.quote(str(self.path))+'\nexit 7\n')
        self.assertEqual(self.execute(script).returncode, 43)
        self.assertEqual(self.path.read_text(), 'SENTINEL\n')
        self.assertEqual(self.path.stat().st_mode & 0o777, 0o600)

    def test_unchanged_owned_state_restores_original_metadata(self):
        script, _ = self.make('exit 7\n')
        self.assertEqual(self.execute(script).returncode, 7)
        self.assertEqual(tx.fingerprint(self.path), self.before)

    def test_owned_new_file_is_removed_on_failure(self):
        script, _ = self.make('exit 7\n', absent=True)
        self.assertEqual(self.execute(script).returncode, 7)
        self.assertFalse(self.path.exists())

    def test_successful_apply_retains_desired_file(self):
        script, _ = self.make('')
        self.assertEqual(self.execute(script).returncode, 0)
        self.assertEqual(self.path.read_text(), 'SENTINEL\n')

    def test_outer_transaction_holds_and_preserves_resource_claim(self):
        script, spec = self.make('printf "TEAMMATE\\n" > '+shlex.quote(str(self.path))+'\nexit 7\n')
        token = uuid.uuid4().hex
        with patch.object(tx, 'ROOT', self.root/'transactions'), \
             patch.object(tx, 'service_state', return_value={'exists':True,'active':True,'enabled':'disabled','configuration_sha256':'a'*64}), \
             patch.object(tx, 'command'), \
             patch.dict(os.environ, {'PATH':str(self.bin)+':'+os.environ['PATH']}):
            with self.assertRaises((ValueError, SystemExit)):
                tx.run('apply', spec, token, script, ledger_directory=self.root/'ledger')
            self.assertEqual(self.path.read_text(), 'TEAMMATE\n')
            state = json.loads((tx.ROOT/token/'state.json').read_text())
            self.assertEqual(state['status'], 'rollback-held')
            self.assertTrue(list(tx.ROOT.glob('resource-*.json')))
            with self.assertRaises(ValueError):
                tx._run('admit', spec, uuid.uuid4().hex, script)

    def test_symlink_substitution_preserves_link_and_referent(self):
        other = self.root/'other.conf'; other.write_text('UNRELATED\n')
        script, _ = self.make('rm -- '+shlex.quote(str(self.path))+'\nln -s '+shlex.quote(str(other))+' '+shlex.quote(str(self.path))+'\nexit 7\n')
        self.assertEqual(self.execute(script).returncode, 43)
        self.assertTrue(self.path.is_symlink()); self.assertEqual(other.read_text(), 'UNRELATED\n')

    def test_failed_restart_conflict_does_not_attempt_second_restart(self):
        calls = self.root/'calls'
        self.control.write_text('#!/bin/sh\necho "$1" >> '+shlex.quote(str(calls))+'\n'
            'case "$1" in is-enabled) echo disabled;; restart) printf "TEAMMATE\\n" > '+shlex.quote(str(self.path))+'; exit 7;; esac\nexit 0\n')
        script, _ = self.make('')
        self.assertEqual(self.execute(script).returncode, 43)
        self.assertEqual(self.path.read_text(), 'TEAMMATE\n')
        self.assertEqual(calls.read_text().splitlines().count('restart'), 1)

    def test_unchanged_file_is_checked_for_third_state_during_failure(self):
        script, _ = self.make('printf "TEAMMATE\\n" > '+shlex.quote(str(self.path))+'\nexit 7\n')
        # Initially desired content means no Sentinel file write will be needed.
        self.path.write_text('SENTINEL\n'); self.path.chmod(0o644)
        result = self.execute(script)
        self.assertEqual(result.returncode,43)
        self.assertEqual(self.path.read_text(),'TEAMMATE\n')

    def test_same_content_rewrite_still_conflicts_by_revision(self):
        script,_=self.make('printf "SENTINEL\\n" > '+shlex.quote(str(self.path))+'\nexit 7\n')
        self.assertEqual(self.execute(script).returncode,43)
        self.assertEqual(self.path.read_text(),'SENTINEL\n')

    def test_multifile_preflight_does_not_partially_restore_known_conflict(self):
        second=self.root/'second.conf';second.write_text('SECOND\n');second.chmod(0o644)
        options={'service':'sb-private-fixture.service','files':[
            {'path':str(self.path),'mode':'0644','previous_sha256':hashlib.sha256(b'ORIGINAL\n').hexdigest()},
            {'path':str(second),'mode':'0644','previous_sha256':hashlib.sha256(b'SECOND\n').hexdigest()}]}
        _,script,_=_linux_service(options,self.root,
            generated_sources={str(self.path):'ONE_NEW\n',str(second):'TWO_NEW\n'},
            validation_script='printf "TEAMMATE\\n" > '+shlex.quote(str(second))+'\nexit 7\n')
        script=script.replace('/var/lib/sentinel-setup-backup.XXXXXXXX',str(self.root/'backup.XXXXXXXX'))
        self.assertEqual(self.execute(script).returncode,43)
        self.assertEqual(self.path.read_text(),'ONE_NEW\n')
        self.assertEqual(second.read_text(),'TEAMMATE\n')

    def test_guard_rechecks_after_staging_rollback_file(self):
        from sentinel_blue import setup_file_guard as guard
        base=self.root/'snapshot'
        import shutil
        shutil.copy2(self.path,base);guard.prepare(base,self.path)
        staged=self.root/'stage';staged.write_text('SENTINEL\n');staged.chmod(0o644)
        guard.install(base,self.path,staged)
        real_copy=shutil.copy2
        def copy_then_external_edit(*a,**kw):
            result=real_copy(*a,**kw);self.path.write_text('TEAMMATE\n');return result
        with patch.object(guard.shutil,'copy2',side_effect=copy_then_external_edit):
            with self.assertRaisesRegex(ValueError,'changed before rollback'):
                guard.restore(base,self.path)
        self.assertEqual(self.path.read_text(),'TEAMMATE\n')

    def test_missing_post_receipt_holds_possible_completed_write(self):
        from sentinel_blue import setup_file_guard as guard
        import shutil
        base=self.root/'snapshot';shutil.copy2(self.path,base);guard.prepare(base,self.path)
        stage=self.root/'stage';stage.write_text('SENTINEL\n');stage.chmod(0o644)
        guard.install(base,self.path,stage)
        Path(str(base)+'.post.json').unlink()
        with self.assertRaisesRegex(ValueError,'receipt'):
            guard.restore(base,self.path)
        self.assertEqual(self.path.read_text(),'SENTINEL\n')

    def test_corrupt_backup_never_restores(self):
        from sentinel_blue import setup_file_guard as guard
        import shutil
        base=self.root/'snapshot';shutil.copy2(self.path,base);guard.prepare(base,self.path)
        stage=self.root/'stage';stage.write_text('SENTINEL\n');stage.chmod(0o644)
        guard.install(base,self.path,stage);base.write_text('CORRUPT\n')
        with self.assertRaisesRegex(ValueError,'backup changed'):
            guard.restore(base,self.path)
        self.assertEqual(self.path.read_text(),'SENTINEL\n')


class CollectorTimeouts(unittest.TestCase):
    def test_service_timeout_reports_incomplete_inventory(self):
        errors=[]
        with patch.object(collectors, '_run', side_effect=subprocess.TimeoutExpired(['systemctl'],15)):
            rows=collectors._linux_services(errors)
        self.assertEqual(rows,[])
        self.assertTrue(any('service inventory' in e and 'unavailable' in e for e in errors), errors)

    def test_sessions_timeout_is_reported(self):
        errors=[]
        with patch.object(collectors,'_run',side_effect=subprocess.TimeoutExpired(['who'],8)):
            self.assertEqual(collectors._linux_sessions(set(),errors),[])
        self.assertTrue(errors)

    def test_accounts_timeout_keeps_available_local_accounts_with_warning(self):
        errors=[]
        with patch.object(collectors,'_run',side_effect=subprocess.TimeoutExpired(['getent'],8)):
            rows=collectors._linux_accounts(errors)
        self.assertIsInstance(rows,list)
        self.assertTrue(any('account' in e for e in errors),errors)

    def collect_fixture(self, failing):
        with ExitStack() as stack:
            stack.enter_context(patch.object(collectors.platform,'system',return_value='Linux'))
            values={'_linux_accounts':[], '_linux_sessions':[],
                '_linux_services':[Service(name='fixture.service',state='running')],
                '_linux_topology':([],[],[]),'_linux_processes':[], '_linux_persistence':[],
                '_linux_firewall':FirewallState(enabled=None),'_linux_interfaces':[],
                '_linux_security_events':[], '_linux_capacity':([],MemoryCapacity()),'_integrity':[]}
            mocked={}
            for name, value in values.items():
                mocked[name]=stack.enter_context(patch.object(collectors,name,return_value=value))
            mocked[failing].side_effect=subprocess.TimeoutExpired(['fixture-not-a-secret'],1)
            telemetry=collectors.collect('fixture-agent')
            self.assertTrue(telemetry.collector_errors)
            self.assertTrue(all('fixture-not-a-secret' not in e for e in telemetry.collector_errors))
            self.assertTrue(mocked['_linux_capacity'].called)
            return telemetry

    def test_collection_continues_after_each_linux_section_timeout(self):
        for section in ('_linux_accounts','_linux_sessions','_linux_services','_linux_topology',
                        '_linux_processes','_linux_persistence','_linux_firewall',
                        '_linux_interfaces','_linux_security_events','_linux_capacity'):
            with self.subTest(section=section):
                self.collect_fixture(section)

    def test_agent_cycle_catches_subprocess_timeout(self):
        from importlib.resources import files
        tree=ast.parse(files('sentinel_blue').joinpath('agent.py').read_text())
        handlers=[n for n in ast.walk(tree) if isinstance(n,ast.ExceptHandler)
                  and 'agent_cycle_failed' in ast.unparse(n)]
        self.assertEqual(len(handlers),1)
        self.assertIn('subprocess.SubprocessError',ast.unparse(handlers[0].type))

    def test_incomplete_collection_still_blocks_service_recovery(self):
        from sentinel_blue.service_recovery import _fresh
        sample=self.collect_fixture('_linux_services').as_dict()
        sample.update(sequence=1,boot_id='fixture-boot',observed_at=time.time())
        with self.assertRaisesRegex(ValueError,'incomplete collection'):
            _fresh(sample,time.time(),allow_payload_issues=True)

    def test_actual_agent_loop_survives_timeout_and_collects_again(self):
        from types import SimpleNamespace
        from unittest.mock import MagicMock
        from sentinel_blue import agent, __version__
        class EndFixture(BaseException): pass
        with tempfile.TemporaryDirectory() as directory:
            args=SimpleNamespace(log_level='WARNING',agent_id='fixture-agent',event_profile='fixture.json',
                range_deployment=False,expected_package_sha256=None,authorized_network=[],allow_containment=False,
                allow_restoration=False,state_dir=directory,log_file=None,controller='https://127.0.0.1:8765',
                token=None,token_file=None,reenroll=False,ca_file=None,spool_limit=8,probe_config=None,
                quarantine_ttl=300,change_watch_interval=1,once=False,interval=5)
            profile=MagicMock();profile.raw={};profile.assert_inventory_networks=MagicMock();profile.release={'sha256':''}
            profile.profile_id='fixture';profile.fingerprint='b'*64
            profile.authorized_networks=profile.authorized_hosts=profile.excluded_hosts=()
            client=MagicMock();client.agent_token='a'*64;client.actions.return_value=[]
            lock=MagicMock();lock.acquire.return_value=lock
            watcher=MagicMock();count=[0]
            def collect(*a,**kw):
                count[0]+=1
                if count[0]==1:
                    raise subprocess.TimeoutExpired(['fixture-command','DO-NOT-LOG'],1)
                return SimpleNamespace(as_dict=lambda:{'agent_id':'fixture-agent','agent_version':__version__,
                    'hostname':'fixture','platform':'Linux','boot_id':'fixture-boot','observed_at':time.time(),
                    'collector_errors':[],'probes':[],'integrity':[]})
            def wait(*a,**kw):
                if count[0]>=2: raise EndFixture
                return False
            watcher.wait.side_effect=wait
            with ExitStack() as stack:
                values={'configure_agent_logging':None,'load_event_profile':profile,'AgentProcessLock':lock,
                    'AgentClient':client,'load_agent_credentials':('', 'a'*64, None),'ActionExecutor':MagicMock(),
                    'ChangeWatcher':watcher,'assess_agent_health':{'healthy':True,'action_safe':True,'errors':[],
                    'critical_errors':[]},'refresh_windows_state_health':None,'refresh_recovery_health':None,
                    'systemd_notify':None}
                for name,value in values.items():
                    stack.enter_context(patch.object(agent,name,return_value=value))
                stack.enter_context(patch.object(agent,'collect',side_effect=collect))
                stack.enter_context(patch.object(agent.atexit,'register'))
                logger=stack.enter_context(patch.object(agent,'LOG'))
                with self.assertRaises(EndFixture): agent._run_with_windows_state_guard(args,None)
                self.assertEqual(count[0],2)
                self.assertEqual(client.telemetry.call_count,1)
                self.assertNotIn('DO-NOT-LOG',str(logger.error.call_args_list))


@unittest.skipUnless(os.name=='posix','POSIX process group fixtures')
class ProcessCleanup(unittest.TestCase):
    def test_parent_exit_does_not_spare_sigterm_ignoring_child(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory); pidfile=root/'pid'; marker=root/'marker'
            child=("import os,signal,time;from pathlib import Path;"
                "signal.signal(signal.SIGTERM,signal.SIG_IGN);"
                f"Path({str(pidfile)!r}).write_text(str(os.getpid()));time.sleep(0.8);"
                f"Path({str(marker)!r}).write_text('late mutation');time.sleep(10)")
            parent=("import subprocess,sys,time;from pathlib import Path;"
                f"p=subprocess.Popen([sys.executable,'-S','-c',{child!r}]);\n"
                f"while not Path({str(pidfile)!r}).exists(): time.sleep(0.005)\n"
                "time.sleep(10)\n")
            try:
                with patch.object(transport,'PROCESS_TERMINATION_GRACE',0.10,create=True):
                    result=transport.run_process([sys.executable,'-S','-c',parent],'',0.35)
                self.assertTrue(result.uncertain)
                self.assertTrue(pidfile.exists(), 'child must have armed TERM handler')
                time.sleep(0.65)
                self.assertFalse(marker.exists(),'timed-out child continued writing')
            finally:
                if pidfile.exists():
                    try: os.kill(int(pidfile.read_text()),signal.SIGKILL)
                    except ProcessLookupError: pass

    def test_normal_completion_is_not_uncertain(self):
        result=transport.run_process([sys.executable,'-c','print("fixture")'],'',3)
        self.assertEqual(result.returncode,0); self.assertFalse(result.uncertain)

    def test_term_ignoring_leader_is_killed(self):
        with patch.object(transport,'PROCESS_TERMINATION_GRACE',0.10,create=True):
            result=transport.run_process([sys.executable,'-S','-c',
                'import signal,time;signal.signal(signal.SIGTERM,signal.SIG_IGN);time.sleep(10)'],'',0.25)
        self.assertTrue(result.uncertain); self.assertEqual(result.returncode,-signal.SIGKILL)


class ForwardingRollback(unittest.TestCase):
    def state(self,before='1',*,status='unchanged'):
        spec={'name':'fixture','forwarding':True,'routes':[],'addresses':[]}
        state={'status':'pending','spec':spec,'files':{},
            'before':{'forwarding':before,'table':None,'added_routes':[],'added_addresses':[],'files':{},'state':None},
            'forwarding_change':{'before':before,'after':'1','status':status}}
        return spec,state

    def rollback(self,spec,state,current):
        calls=[]
        observed = [current]
        def command(argv,*args,**kw):
            calls.append(argv)
            if argv[0] == 'sysctl':
                observed[0] = argv[-1].split('=')[-1]
            return subprocess.CompletedProcess(argv,0,'','')
        with patch.object(net,'names',return_value=(Path('/private-fixture'),'fixture','fixture_table')), \
             patch.object(net,'table_data',return_value=None),patch.object(net,'save'), \
             patch.object(net,'command',side_effect=command), \
             patch.object(Path,'read_text',side_effect=lambda:observed[0]):
            net.rollback(spec,state)
        return calls

    def test_preexisting_forwarding_is_not_restored_over_operator_change(self):
        spec,state=self.state('1')
        calls=self.rollback(spec,state,'0')
        self.assertFalse(any(c[0]=='sysctl' for c in calls),calls)

    def test_owned_forwarding_is_restored_if_post_state_matches(self):
        spec,state=self.state('0',status='applied')
        calls=self.rollback(spec,state,'1')
        self.assertIn(['sysctl','-w','net.ipv4.ip_forward=0'],calls)

    def test_changed_owned_forwarding_holds_before_any_mutation(self):
        spec,state=self.state('0',status='applied')
        with self.assertRaisesRegex(ValueError,'forwarding'):
            self.rollback(spec,state,'0')

    def test_never_written_forwarding_is_not_restored(self):
        spec,state=self.state('0',status='not-written')
        calls=self.rollback(spec,state,'1')
        self.assertFalse(any(c[0]=='sysctl' for c in calls),calls)

    def test_ambiguous_inflight_write_is_held(self):
        spec,state=self.state('0',status='writing')
        with self.assertRaisesRegex(ValueError,'forwarding'):
            self.rollback(spec,state,'1')

    def test_legacy_pending_record_with_preexisting_forwarding_is_safe(self):
        spec,state=self.state('1'); del state['forwarding_change']
        self.assertFalse(any(c[0]=='sysctl' for c in self.rollback(spec,state,'0')))

    def test_legacy_pending_record_without_write_proof_is_held(self):
        spec,state=self.state('0'); del state['forwarding_change']
        with self.assertRaisesRegex(ValueError,'forwarding'):
            self.rollback(spec,state,'1')

    def test_install_persists_intent_before_forwarding_write(self):
        import copy
        spec,state=self.state('0',status='not-written');spec['ruleset']='fixture-rules'
        observed=['0'];receipts=[];writes=[]
        def command(argv,*a,**kw):
            if argv[0]=='sysctl':
                self.assertEqual(receipts[-1]['forwarding_change']['status'],'writing')
                writes.append(argv);observed[0]='1'
            return subprocess.CompletedProcess(argv,0,'','')
        with patch.object(net,'table_data',return_value=None),patch.object(net,'command',side_effect=command), \
             patch.object(net,'save',side_effect=lambda path,value:receipts.append(copy.deepcopy(value))), \
             patch.object(net,'forwarding_value',side_effect=lambda:observed[0]):
            net.install_runtime(spec,pending=state)
        self.assertEqual(len(writes),1)
        self.assertEqual(state['forwarding_change']['status'],'applied')
        self.assertEqual(receipts[-1]['forwarding_change']['status'],'applied')

    def test_install_skips_sysctl_if_forwarding_was_already_enabled(self):
        spec,state=self.state('1');spec['ruleset']='fixture-rules'
        with patch.object(net,'table_data',return_value=None),patch.object(net,'forwarding_value',return_value='1'), \
             patch.object(net,'command',return_value=subprocess.CompletedProcess([],0,'','')) as command, \
             patch.object(net,'save'):
            net.install_runtime(spec,pending=state)
        self.assertFalse(any(call.args[0][0]=='sysctl' for call in command.call_args_list))

    def test_install_rechecks_after_durable_intent_before_write(self):
        spec,state=self.state('0',status='not-written');spec['ruleset']='fixture-rules'
        with patch.object(net,'table_data',return_value=None),patch.object(net,'forwarding_value',side_effect=['0','1']), \
             patch.object(net,'command',return_value=subprocess.CompletedProcess([],0,'','')) as command, \
             patch.object(net,'save'):
            with self.assertRaisesRegex(ValueError,'forwarding changed'):
                net.install_runtime(spec,pending=state)
        self.assertFalse(any(call.args[0][0]=='sysctl' for call in command.call_args_list))

    def test_rollback_rechecks_after_intent_save(self):
        spec,state=self.state('0',status='applied')
        with patch.object(net,'table_data',return_value=None),patch.object(net,'forwarding_value',side_effect=['1','1','0']), \
             patch.object(net,'command',return_value=subprocess.CompletedProcess([],0,'','')) as command, \
             patch.object(net,'save'):
            with self.assertRaisesRegex(ValueError,'forwarding changed'):
                net.rollback(spec,state)
        self.assertFalse(any(call.args[0][0]=='sysctl' for call in command.call_args_list))

    def test_legacy_committed_withdrawal_uses_authenticated_snapshots(self):
        from sentinel_blue.withdrawal_router import RouterAdapter
        from unittest.mock import MagicMock
        spec,state=self.state('0',status='unchanged')
        state.update(status='committed',ledger_action_id='action-fixture')
        ledger=MagicMock();ledger.state.return_value=state['before']
        adapter=RouterAdapter(ledger)
        before={'files':{},'forwarding':'0'};expected={'files':{},'forwarding':'1'}
        target={'spec':spec,'action_id':'action-fixture','rollback_before_hash':'hash-fixture'}
        with patch.object(adapter,'snapshot',side_effect=[expected,before]), \
             patch.object(net,'read',return_value=json.dumps(state).encode()), \
             patch.object(net,'rollback') as rollback:
            adapter.restore(target,before,expected)
        self.assertEqual(rollback.call_args.args[1]['forwarding_change'],
                         {'before':'0','after':'1','status':'applied'})

    def test_conflict_preflight_runs_before_any_network_mutation(self):
        spec,state=self.state('0',status='applied')
        with patch.object(net,'forwarding_value',return_value='0'),patch.object(net,'command') as command:
            with self.assertRaisesRegex(ValueError,'forwarding changed'):
                net.rollback(spec,state)
            command.assert_not_called()

if __name__=='__main__': unittest.main()
