import copy
import unittest
from sentinel_blue.recovery_limits import evaluate_attempts, normalize_attempt_limits
from sentinel_blue.event_profile import EventProfile
from sentinel_blue.service_repair import repair_parameters, validate_repair_contract
from test_service_repair import repair_fixture, damage

LIMITS = {'cooldown_seconds': 30, 'maximum_attempts': 12}


class RecoveryLimitTests(unittest.TestCase):
    def test_successful_repairs_do_not_exhaust_default_three_attempt_allowance_when_opted_in(self):
        events = [(100., True), (220., True), (340., True)]
        self.assertFalse(evaluate_attempts(events, 500)['allowed'])
        self.assertTrue(evaluate_attempts(events, 500, LIMITS)['allowed'])

    def test_twelve_attempt_cap_remains_finite(self):
        result = evaluate_attempts([(float(x*60), True) for x in range(12)], 900, LIMITS)
        self.assertFalse(result['allowed'])
        self.assertEqual(result['retry_at'], 3600)

    def test_failed_attempt_retains_five_minute_cooldown(self):
        self.assertEqual(evaluate_attempts([(100., False)], 150, LIMITS)['retry_at'], 400)
        self.assertTrue(evaluate_attempts([(100., False)], 400, LIMITS)['allowed'])

    def test_success_never_clears_failed_attempt_history(self):
        events = [(0., False), (310., False), (620., False), (1000., True)]
        result = evaluate_attempts(events, 1100, LIMITS)
        self.assertFalse(result['allowed'])
        self.assertEqual(result['failed_attempts_in_window'], 3)
        self.assertEqual(result['retry_at'], 3600)

    def test_later_success_does_not_shorten_existing_failure_cooldown(self):
        events = [(100., False), (200., True)]
        result = evaluate_attempts(events, 250, LIMITS)
        self.assertFalse(result['allowed'])
        self.assertEqual(result['retry_at'], 400)
        self.assertTrue(evaluate_attempts(events, 400, LIMITS)['allowed'])

    def test_rolling_window_and_boundary(self):
        events = [(0., True), (60., True), (120., True)]
        self.assertFalse(evaluate_attempts(events, 3599)['allowed'])
        self.assertTrue(evaluate_attempts(events, 3600)['allowed'])

    def test_profile_binds_limits_and_rejects_envelope_expansion(self):
        profile, baseline = repair_fixture()
        raw = copy.deepcopy(profile.raw)
        raw['services'][0]['repair_policy']['attempt_limits'] = LIMITS
        approved = EventProfile.from_dict(raw)
        current = damage(baseline)
        parameters = repair_parameters(approved, 'agent-one', 'web.service', baseline, current)
        validate_repair_contract(approved, 'agent-one', parameters, current)
        with self.assertRaises(ValueError):
            validate_repair_contract(profile, 'agent-one', parameters, current)
        parameters['recovery_guard']['attempt_limits']['cooldown_seconds'] = 15
        with self.assertRaises(ValueError):
            validate_repair_contract(approved, 'agent-one', parameters, current)

    def test_invalid_unbounded_or_boolean_limits_rejected(self):
        for value in ({}, {'cooldown_seconds': 0, 'maximum_attempts': 12},
                      {'cooldown_seconds': 30, 'maximum_attempts': 121},
                      {'cooldown_seconds': True, 'maximum_attempts': 12},
                      {'cooldown_seconds': 30, 'maximum_attempts': 12, 'window': 1}):
            with self.subTest(value=value), self.assertRaises(ValueError):
                normalize_attempt_limits(value)


if __name__ == '__main__':
    unittest.main()
