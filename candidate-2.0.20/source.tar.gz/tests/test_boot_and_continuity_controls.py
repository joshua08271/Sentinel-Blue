import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from sentinel_blue.controller_boot import arguments_from_config, systemd_unit
from sentinel_blue.continuity_controls import local_control
from sentinel_blue.mutation_ledger import MutationLedger


class BootAndPauseTests(unittest.TestCase):
    def test_ambiguous_or_inline_boot_credentials_are_rejected_before_install(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            root.chmod(0o700)
            path = root / 'config.json'
            for arguments in [['--token', 'secret'], ['--operator-token=secret'], ['--supervisor-child'], ['--database', 'bad\ncommand']]:
                path.write_text(json.dumps({'controller_arguments': arguments}))
                path.chmod(0o600)
                with self.subTest(arguments=arguments), self.assertRaises(ValueError):
                    arguments_from_config(path)

    def test_systemd_control_characters_rejected_and_specifiers_remain_literal(self):
        for command in [['python', '/tmp/a\nExecStart=bad'], ['python', '/tmp/a\r'], ['python', '/tmp/a\x00']]:
            with self.assertRaises(ValueError):
                systemd_unit(command, '/private/ledger')
        value = systemd_unit(['/usr/bin/python3', '/private/a%u/$name.pyz', 'controller-boot-run'], '/private/ledger')
        self.assertIn('a%%u/$$name.pyz', value)
        self.assertNotIn('/bin/sh', value)
        # 2.0.16: the controller is restarted however it exits, without a start limit.
        self.assertIn('Restart=always', value)
        self.assertIn('StartLimitIntervalSec=0', value)
        self.assertNotIn('StartLimitBurst', value)
        self.assertIn('WantedBy=multi-user.target', value)

    def test_independent_pause_is_durable_and_resume_cannot_clear_withdraw(self):
        with tempfile.TemporaryDirectory() as temporary:
            ledger = MutationLedger(Path(temporary) / 'ledger')
            paused = local_control(ledger, True, 'owned fixture emergency Pause')
            self.assertTrue(paused['paused'])
            self.assertTrue(MutationLedger(ledger.directory).automation_paused())
            self.assertFalse(local_control(ledger, False, 'reviewed Resume')['paused'])
            ledger.pause('partial-withdrawal')
            with self.assertRaisesRegex(ValueError, 'Withdraw'):
                local_control(ledger, False, 'cannot override')
            self.assertTrue(ledger.paused())

    def test_withdraw_guest_independent_pause_does_not_begin_withdrawal(self):
        from sentinel_blue.withdrawal import guest
        with tempfile.TemporaryDirectory() as temporary:
            ledger = MutationLedger(Path(temporary) / 'ledger')
            result = guest({'operation': 'continuity-pause', 'reason': 'separate verified SSH transport'}, ledger)
            self.assertTrue(result['paused'])
            self.assertFalse(ledger.paused())
