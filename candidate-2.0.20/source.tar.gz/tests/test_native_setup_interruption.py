"""A real setup-process crash must not replay an uncertain native mutation."""
import copy
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import tempfile
import time
import unittest

import sentinel_blue
from sentinel_blue.event_profile import EventProfile
from sentinel_blue.setup import compile_plan, plan_digest
from sentinel_blue.state import write_private_json


CHILD = r'''
import json,sys
from pathlib import Path
sys.path.insert(0,sys.argv[1])
from sentinel_blue.event_profile import EventProfile
from sentinel_blue.setup import SetupRunner,compile_plan,plan_digest
root=Path(sys.argv[2])
profile=EventProfile.from_dict(json.loads((root/'profile.json').read_text()))
plan=compile_plan(json.loads((root/'inventory.json').read_text()),profile,root)
assert plan_digest(plan)==(root/'approved-digest.txt').read_text()
result=SetupRunner(plan,profile).execute(root/'state',plan_digest(plan),resume=sys.argv[3]=='resume')
(root/'result.json').write_text(json.dumps(result))
'''


@unittest.skipUnless(os.name == 'nt' or shutil.which('bash'), 'requires a native supported command interpreter')
class NativeSetupInterruption(unittest.TestCase):
    def test_crash_retains_deadline_and_does_not_repeat_uncertain_mutation(self):
        with tempfile.TemporaryDirectory(prefix='sentinel interrupted setup ') as directory:
            root = Path(directory).resolve()
            def ps(value):
                return "'" + str(value).replace("'", "''") + "'"
            if os.name == 'nt':
                check = "if (Test-Path -LiteralPath " + ps(root/'finished') + ") {exit 0}; exit 10\n"
                apply = ("$ErrorActionPreference='Stop'\n[IO.File]::AppendAllText(" + ps(root/'attempts') + ",\"one`n\")\n"
                         "[IO.File]::WriteAllText(" + ps(root/'began') + ",'started')\nStart-Sleep -Seconds 8\n"
                         "[IO.File]::WriteAllText(" + ps(root/'finished') + ",'finished')\nexit 0\n")
            else:
                check = 'test -f ' + shlex.quote(str(root/'finished')) + '\n'
                # A failed check uses the recipe's distinguished "not ready" code.
                check = 'if ' + check.strip() + '; then exit 0; else exit 10; fi\n'
                apply = ('set -eu\nprintf "one\\n" >> ' + shlex.quote(str(root/'attempts')) + '\n'
                         'printf started > ' + shlex.quote(str(root/'began')) + '\nsleep 8\n'
                         'printf finished > ' + shlex.quote(str(root/'finished')) + '\n')
            options = {}
            for phase, content in (('check', check), ('apply', apply)):
                path = root/(phase + ('.ps1' if os.name == 'nt' else '.sh'))
                path.write_bytes(content.encode())
                options[phase] = {'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
            raw = copy.deepcopy(EventProfile.testing().raw)
            raw['scope']['authorized_hosts'] = ['127.0.0.1']
            raw['scope']['controller_ingress_hosts'] = ['127.0.0.1']
            raw['services'] = []
            raw['services_confirmed'] = False
            profile = EventProfile.from_dict(raw)
            inventory = {'authorized_networks':raw['scope']['authorized_networks'],
                'hosts':[{'name':'owned','agent_id':'owned','address':'127.0.0.1','transport':'local',
                          'platform':'windows' if os.name == 'nt' else 'linux'}],
                'setup':{'budget_seconds':120,'max_parallel_hosts':1,'tasks':[
                    {'id':'fixture','host':'owned','recipe':'runbook','options':options,
                     'timeout_seconds':40,'health_wait_seconds':5,'estimate_seconds':10}]}}
            plan = compile_plan(inventory, profile, root)
            write_private_json(root/'profile.json', raw)
            write_private_json(root/'inventory.json', inventory)
            (root/'approved-digest.txt').write_text(plan_digest(plan))
            runtime = str(Path(sentinel_blue.__file__).parent.parent)
            argv = [sys.executable, '-c', CHILD, runtime, str(root)]
            with (root/'process.log').open('w') as log:
                child = subprocess.Popen([*argv,'new'], stdout=log, stderr=subprocess.STDOUT)
                try:
                    deadline = time.monotonic()+30
                    while not (root/'began').exists() and child.poll() is None and time.monotonic()<deadline:
                        time.sleep(.05)
                    self.assertTrue((root/'began').exists(), 'Native mutation never began')
                    state_path = root/'state/setup-state.json'
                    original = json.loads(state_path.read_text())
                    self.assertEqual(original['tasks']['fixture']['status'], 'running')
                    child.kill()
                    child.wait(timeout=5)
                    # The already-launched native mutation is bounded and allowed
                    # to finish. The replacement coordinator still cannot assume
                    # that the killed process recorded its completion.
                    deadline = time.monotonic()+20
                    while not (root/'finished').exists() and time.monotonic()<deadline:
                        time.sleep(.1)
                    self.assertTrue((root/'finished').exists())
                    resumed = subprocess.run([*argv,'resume'], stdout=log, stderr=subprocess.STDOUT, timeout=30)
                    self.assertEqual(resumed.returncode,0)
                    state = json.loads(state_path.read_text())
                    self.assertEqual(state['tasks']['fixture']['status'],'uncertain')
                    self.assertEqual(state['started_at'],original['started_at'])
                    self.assertEqual(state['deadline_at'],original['deadline_at'])
                    self.assertEqual((root/'attempts').read_text().splitlines(),['one'])
                    self.assertNotEqual(json.loads((root/'result.json').read_text())['status'],'ready')
                finally:
                    if child.poll() is None:
                        child.kill()
                        child.wait(timeout=5)


if __name__ == '__main__':
    unittest.main()
