"""2.0.6: the issues still open after 2.0.5 that could be fixed without a desktop VM."""
import copy
import json
import os
import subprocess
import tempfile
import time
import unittest
from pathlib import Path
from sentinel_blue.state import write_private_json


class OneInventoryReviewPerHost(unittest.TestCase):
    """2.0.5 live: three 'Existing persistence requires inventory review' alerts
    were open at once, one per change in the number of startup entries."""

    def test_changes_to_the_inventory_coalesce(self):
        from sentinel_blue.controller import ControllerApp
        from sentinel_blue.store import Store
        from test_autonomous_service_recovery import fixtures
        profile, baseline = fixtures()
        store = Store(":memory:")
        self.addCleanup(store.close)
        app = ControllerApp(store, "t" * 32, operator_token="o" * 32, event_profile=profile)
        for sequence, count in ((1, 3), (2, 4), (3, 5)):
            value = copy.deepcopy(baseline)
            value.update(sequence=sequence, observed_at=baseline["observed_at"] + sequence)
            value["persistence"] = [{"kind": "systemd-unit", "name": f"/etc/systemd/system/unit{index}.service",
                                     "sha256": f"{index:064x}"} for index in range(count)]
            app.ingest(value)
        rows = [row for row in store.dashboard()["alerts"]
                if row["kind"] == "persistence_inventory_unverified" and row["status"] == "open"]
        self.assertEqual(len(rows), 1)
        self.assertGreaterEqual(rows[0]["occurrence_count"], 2)


class AfterWithdrawTheWindowExplainsAndOffersTheWayBack(unittest.TestCase):
    """2.0.5: a single-VM Withdraw always ends 'held' (no separate observer), and
    allowing Sentinel again was command-line only."""

    def setUp(self):
        import tkinter as tk
        from unittest.mock import patch
        from sentinel_blue.desktop import DesktopWindow
        from sentinel_blue.mutation_ledger import MutationLedger
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root_dir = Path(temp.name)
        item = patch.dict(os.environ, {"SENTINEL_LEDGER_DIR": str(self.root_dir / "ledger")})
        item.start()
        self.addCleanup(item.stop)
        self.ledger = MutationLedger(self.root_dir / "ledger")
        key = self.ledger.prepare("native-objects-v1", {"objects": ["file:/etc/x"]}, {"x": 1})
        self.ledger.commit(key, {"x": 2}, {"success": True})
        self.ledger.pause("op-9")
        self.ledger.append("undo_prepared", action_id=key)
        self.ledger.append("undone", action_id=key, restored_hash=self.ledger.store({"x": 1}))
        self.tk_root = tk.Tk()
        self.addCleanup(self.tk_root.destroy)
        with patch("sentinel_blue.linux_workspace.local_observation",
                   return_value={"observation": None, "presence": {}}):
            self.window = DesktopWindow(self.tk_root, directory=self.root_dir / "desktop")
        self.window.notify.set(False)
        self.addCleanup(self.window.worker_stop.set)

    def test_the_single_vm_result_is_explained(self):
        from sentinel_blue.desktop_withdrawal import withdrawal_explanation
        text = "\n".join(withdrawal_explanation({
            "status": "held", "operation_id": "op-9",
            "external_verification": [{"healthy": False,
                                       "reason": "A separate observer is required to externally verify a local service host"}]}))
        self.assertIn("no separate observer", text)
        self.assertIn("were still reversed", text)
        self.assertIn("Allow Sentinel on this VM again", text)

    def test_the_button_releases_after_confirmation(self):
        from unittest.mock import patch
        texts = [child.cget("text") for frame in self.window.tabs["Withdraw"].winfo_children()
                 for child in (frame.winfo_children() or [frame]) if "text" in child.keys()]
        self.assertIn("Allow Sentinel on this VM again…", texts)
        with patch("os.geteuid", return_value=0), \
                patch.object(self.window.messagebox, "askyesno", return_value=False):
            self.window.release_withdrawal()
        self.assertTrue(self.ledger.paused(), "declining changes nothing")
        with patch("os.geteuid", return_value=0), \
                patch.object(self.window.messagebox, "askyesno", return_value=True):
            self.window.release_withdrawal()
        self.assertFalse(self.ledger.paused())
        self.assertIn("Released", self.window.withdraw_text.get("1.0", "end"))

    def test_an_ordinary_user_is_sent_to_the_administrator_window(self):
        from unittest.mock import patch
        with patch("os.geteuid", return_value=1000):
            self.window.release_withdrawal()
        self.assertTrue(self.ledger.paused())
        self.assertIn("administrator", self.window.footer.get())

    def test_the_recovery_column_fits_its_plain_words(self):
        from sentinel_blue.service_recovery import HEALTHY_STATUS
        width = int(self.window.services.column("Recovery", "width"))
        self.assertGreaterEqual(width, 7 * len(HEALTHY_STATUS))


class RestorePointsHaveASecondCopy(unittest.TestCase):
    """2.0.5: a restore point whose blob was deleted *and* whose file was
    changed could not be restored by anything; a same-size substitution of a
    blob was found only when a repair tried to use it."""

    def setUp(self):
        import hashlib
        from sentinel_blue.restoration import RestorePointStore
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.targets = []
        for index in range(3):
            target = self.root / "site" / f"web{index}.conf"
            target.parent.mkdir(mode=0o755, exist_ok=True)
            target.write_bytes(b"trusted-%d" % index)
            target.chmod(0o644)
            self.targets.append(target)
        self.mirror = self.root / "ledger" / "restore-mirror"
        self.store = RestorePointStore(self.root / "agent-state", mirror=self.mirror)
        self.digests = [hashlib.sha256(t.read_bytes()).hexdigest() for t in self.targets]
        result = self.store.capture([{"path": str(t), "sha256": d} for t, d in zip(self.targets, self.digests)])
        self.assertTrue(result["success"], result)

    def test_capture_keeps_a_private_second_copy(self):
        self.assertEqual(sorted(p.name for p in self.mirror.iterdir()), sorted(self.digests))
        self.assertEqual(self.mirror.stat().st_mode & 0o777, 0o700)

    def test_a_deleted_blob_of_a_changed_file_is_rebuilt_from_the_copy(self):
        (self.store.blobs / self.digests[0]).unlink()
        self.targets[0].write_bytes(b"attacker")
        self.assertEqual(self.store.audit_backups()["rebuilt"], [str(self.targets[0])])
        self.assertEqual((self.store.blobs / self.digests[0]).read_bytes(), b"trusted-0")

    def test_repair_reads_the_copy_when_the_blob_is_gone(self):
        (self.store.blobs / self.digests[1]).unlink()
        self.assertEqual(self.store.approved_bytes(self.digests[1]), b"trusted-1")

    def test_both_copies_gone_and_file_changed_is_lost(self):
        (self.store.blobs / self.digests[2]).unlink()
        (self.mirror / self.digests[2]).unlink()
        self.targets[2].write_bytes(b"attacker")
        self.assertEqual(self.store.audit_backups()["lost"], [str(self.targets[2])])

    def test_a_same_size_substitution_is_found_by_the_rolling_check(self):
        blob = self.store.blobs / self.digests[2]
        blob.write_bytes(b"XXXXXXXXX")            # same length as b"trusted-2"
        found = []
        for _ in range(3):                         # one blob verified per cycle
            found += self.store.audit_backups(verify_bytes=1)["rebuilt"]
        self.assertEqual(found, [str(self.targets[2])])
        self.assertEqual(blob.read_bytes(), b"trusted-2")

    def test_a_mirror_that_is_a_link_is_not_used(self):
        from sentinel_blue.restoration import RestorePointStore
        link = self.root / "link-mirror"
        link.symlink_to(self.root / "elsewhere", target_is_directory=True)
        self.assertIsNone(RestorePointStore(self.root / "other-state", mirror=link).mirror)

    def test_the_agent_keeps_it_in_the_ledger_directory(self):
        from unittest.mock import patch
        from sentinel_blue.agent import restore_mirror_directory
        with patch.dict(os.environ, {"SENTINEL_LEDGER_DIR": str(self.root / "ledger")}):
            self.assertEqual(restore_mirror_directory(), (self.root / "ledger" / "restore-mirror").absolute())


class ARedoRunsOnlyTheServicesItIsFor(unittest.TestCase):
    """2.0.5: a redo re-ran the whole approved plan, and was never automatic
    when any unrelated task of the original setup had failed."""

    def setUp(self):
        from test_setup import fixture
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.inventory, self.profile = fixture(self.root)

    def run_setup(self, transport, only=None):
        from sentinel_blue.setup import SetupRunner, compile_plan, plan_digest
        from test_setup import healthy_probe
        plan = compile_plan(self.inventory, self.profile, self.root)
        return SetupRunner(plan, self.profile, transport=transport, probe=healthy_probe).execute(
            self.root / "state", plan_digest(plan), only_services=only)

    def test_only_the_named_service_runs_and_decides_the_result(self):
        from test_setup import FixtureTransport
        transport = FixtureTransport()
        transport.failed = {"host-1"}
        report = self.run_setup(transport, [["host-0", "web"]])
        self.assertEqual(report["status"], "ready", report)
        self.assertEqual(report["tasks"]["host-1"]["status"], "not-selected")
        self.assertEqual(report["selected_tasks"], ["host-0"])
        self.assertNotIn("host-1", transport.applies)
        self.assertNotIn("host-1", report["host_preflight"], "an unrelated host is not even contacted")

    def test_a_service_without_a_task_is_refused_and_resume_is_not_partial(self):
        from sentinel_blue.setup import SetupRunner, compile_plan, plan_digest
        from test_setup import FixtureTransport
        with self.assertRaisesRegex(ValueError, "none of the requested services"):
            self.run_setup(FixtureTransport(), [["host-0", "db"]])
        plan = compile_plan(self.inventory, self.profile, self.root)
        with self.assertRaisesRegex(ValueError, "never resumed"):
            SetupRunner(plan, self.profile, transport=FixtureTransport()).execute(
                self.root / "state2", plan_digest(plan), resume=True, only_services=[["host-0", "web"]])


class RedoWorkspace(unittest.TestCase):
    NOW = 1_800_000_000.0

    def make(self, scope="local", hosts=(("local-linux", "127.0.0.1"),), original=None, units=("web.service",)):
        from sentinel_blue import setup_redo
        from sentinel_blue.state import write_private_json
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)
        workspace = root / "session"
        workspace.mkdir()
        job = root / "desktop" / "job-original" / "job.json"
        job.parent.mkdir(parents=True)
        write_private_json(job, {"kind": "setup"})
        write_private_json(job.parent / "result.json", original or {"status": "passed"})
        write_private_json(root / "inventory.json", {
            "hosts": [{"name": name, "address": address, "agent_id": name} for name, address in hosts],
            "setup": {"tasks": [{"id": f"{name}-{unit}", "host": name, "service_id": unit}
                                for name, _ in hosts for unit in units]}})
        setup_redo.record_approved_setup(
            workspace, {"kind": "setup", "inventory": str(root / "inventory.json"),
                        "event_profile": str(root / "profile.json"), "runtime": str(root / "sb.pyz"),
                        "range_deployment": False, "approved_digest": "a" * 64},
            job_root=root / "desktop", job_path=job, scope=scope)
        self.launched = []
        def launcher(job, directory):
            directory.mkdir(parents=True, exist_ok=True)  # live guard already owns a private directory
            path = directory / "job.json"
            write_private_json(path, job)
            self.launched.append(job)
            return None, path
        return workspace, launcher

    @staticmethod
    def snapshot(rows, approved=("local-linux",)):
        return {"service_health": [{"agent_id": agent, "service": unit, "health": health, "native_state":
                                    "running" if health == "healthy" else "failed", "reason": ""}
                                   for agent, unit, health in rows],
                "actions": [], "agents": [{"agent_id": agent, "baseline_status": "approved"} for agent in approved],
                "controller": {"governance": {"autonomy_mode":"guarded-autonomous", "emergency_stopped":False}}}

    def test_an_unrelated_failed_task_no_longer_blocks_the_automatic_redo(self):
        from sentinel_blue import setup_redo
        workspace, launcher = self.make(units=("web.service", "db.service"), original={
            "status": "incomplete", "tasks": {"local-linux-web.service": {"status": "ready"},
                                              "local-linux-db.service": {"status": "failed"}}})
        snap = self.snapshot([("local-linux", "web.service", "unhealthy"), ("local-linux", "db.service", "unhealthy")])
        setup_redo.tick(workspace, snap, now=self.NOW, launcher=launcher)
        verdict = setup_redo.tick(workspace, snap, now=self.NOW + setup_redo.UNREPAIRED_GRACE_SECONDS + 1,
                                  launcher=launcher)
        self.assertEqual([job["only_services"] for job in self.launched], [[["local-linux", "web.service"]]])
        self.assertEqual(verdict["units"]["db.service"]["status"], "held")
        self.assertIn("did not finish", verdict["units"]["db.service"]["reason"])

    def test_a_network_redo_names_each_host(self):
        from sentinel_blue import setup_redo
        workspace, launcher = self.make(scope="network", hosts=(("web-1", "10.0.0.5"), ("web-2", "10.0.0.6")))
        snap = self.snapshot([("web-1", "web.service", "healthy"), ("web-2", "web.service", "unhealthy")],
                             approved=("web-1", "web-2"))
        setup_redo.tick(workspace, snap, now=self.NOW, launcher=launcher)
        verdict = setup_redo.tick(workspace, snap, now=self.NOW + setup_redo.UNREPAIRED_GRACE_SECONDS + 1,
                                  launcher=launcher)
        self.assertEqual(verdict["units"]["web-1/web.service"]["status"], "healthy")
        self.assertEqual([job["only_services"] for job in self.launched], [[["web-2", "web.service"]]])
        self.assertIn("web-2/web.service", setup_redo.status_text(workspace, snap, now=self.NOW + 200))

    def test_a_service_no_task_covers_is_not_redone(self):
        from sentinel_blue import setup_redo
        workspace, launcher = self.make(units=("web.service",))
        snap = self.snapshot([("local-linux", "other.service", "unhealthy")])
        setup_redo.tick(workspace, snap, now=self.NOW, launcher=launcher)
        verdict = setup_redo.tick(workspace, snap, now=self.NOW + setup_redo.UNREPAIRED_GRACE_SECONDS + 1,
                                  launcher=launcher)
        self.assertEqual(self.launched, [])
        self.assertIn("no task of the approved setup", verdict["units"]["other.service"]["reason"])


class ANetworkSetupCanBeRedone(unittest.TestCase):
    """2.0.5: the setup redo existed only for the VM Sentinel runs on; services
    on other network hosts had nothing when repair failed."""

    def setUp(self):
        import tkinter as tk
        from unittest.mock import patch
        from sentinel_blue.desktop import DesktopWindow
        from sentinel_blue.state import write_private_json
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root_dir = Path(temp.name)
        self.tk_root = tk.Tk()
        self.addCleanup(self.tk_root.destroy)
        with patch("sentinel_blue.linux_workspace.local_observation",
                   return_value={"observation": None, "presence": {}}):
            self.window = DesktopWindow(self.tk_root, directory=self.root_dir / "desktop")
        self.window.notify.set(False)
        self.addCleanup(self.window.worker_stop.set)
        inventory = self.root_dir / "inventory.json"
        write_private_json(inventory, {"hosts": [{"name": "web-2", "address": "10.0.0.6", "agent_id": "web-2"}],
                                       "setup": {"tasks": [{"id": "web", "host": "web-2", "service_id": "web.service"}]}})
        original = self.root_dir / "desktop" / "job-1" / "job.json"
        original.parent.mkdir(parents=True)
        write_private_json(original, {"kind": "setup"})
        write_private_json(original.parent / "result.json", {"status": "ready"})
        self.window.job_path = original
        self.window.network_redo_workspace = self.window._record_network_setup(
            {"kind": "setup", "inventory": str(inventory), "event_profile": str(self.root_dir / "profile.json"),
             "runtime": str(self.root_dir / "sb.pyz"), "range_deployment": False, "approved_digest": "b" * 64})

    def snapshot(self, mode):
        now = time.time()
        return {"service_health": [{"agent_id": "web-2", "service": "web.service", "health": "unhealthy",
                                    "native_state": "failed", "reason": ""}],
                "actions": [{"agent_id": "web-2", "action_type": "repair_service", "status": "failed",
                             "parameters": {"service": "web.service"}, "created_at": now - 60, "completed_at": now - 30,
                             "result": {"rolled_back": True, "message": "start failed"}}],
                "agents": [{"agent_id": "web-2", "baseline_status": "approved"}],
                "controller": {"governance": {"autonomy_mode": mode, "emergency_stopped": False}}}

    def tick(self, mode):
        from unittest.mock import patch
        launched = []
        def launcher(job, directory):
            from sentinel_blue.state import write_private_json
            directory.mkdir(parents=True, exist_ok=True)  # live guard already owns a private directory
            path = directory / "job.json"
            write_private_json(path, job)
            launched.append(job)
            return None, path
        # The worker now requires an actual current signed governance check.
        from redo_gate_fixture import live_client
        from test_service_manifest_policy import service_manifest, profile_for
        profile = profile_for([service_manifest(host='web-2')])
        write_private_json(self.root_dir / 'profile.json', profile.raw)
        app, _, client = live_client(self, profile)
        app.set_autonomy_mode(mode)
        self.window.client = client
        original_dashboard = client.dashboard
        client.dashboard = lambda: {**original_dashboard(), **self.snapshot(mode)}
        self.window.next_redo_tick = 0
        with patch("sentinel_blue.desktop_jobs.launch_job", side_effect=launcher):
            self.window.tick_network_redo(self.snapshot(mode))
            deadline = time.monotonic() + 5
            while self.window.redo_ticking and time.monotonic() < deadline:
                time.sleep(0.02)
        return launched

    def test_the_approved_network_setup_is_remembered(self):
        self.assertEqual(self.window._saved_network_redo(), self.window.network_redo_workspace)

    def test_guarded_mode_redoes_only_the_failed_hosts_service(self):
        launched = self.tick("guarded-autonomous")
        self.assertEqual([job["only_services"] for job in launched], [[["web-2", "web.service"]]])

    def test_approval_mode_keeps_the_evidence_and_offers_it(self):
        from sentinel_blue.setup_redo import status_text
        self.assertEqual(self.tick("approval-based"), [])
        self.assertIn("web-2/web.service: eligible",
                      status_text(self.window.network_redo_workspace, self.snapshot("approval-based")))


class ThePostgreSQLPackFitsCurrentReleases(unittest.TestCase):
    """Found live on 2.0.6: the pack refused PostgreSQL 16 (Ubuntu 24.04) and
    wrote `include 'sentinel-pg-hba.conf'`, which a real PostgreSQL 16 reads as
    a file name containing quotes and refuses to start."""

    def generated(self, options):
        from sentinel_blue.linux_service_packs import build
        metadata = {}
        root = Path(tempfile.mkdtemp())
        self.addCleanup(__import__("shutil").rmtree, root)
        build("postgresql", options, root, metadata=metadata)
        return metadata

    def test_sixteen_and_fifteen_are_accepted(self):
        for version in (15, 16):
            with self.subTest(version=version):
                files = {row["path"] for row in self.generated({"config_directory": f"/etc/postgresql/{version}/main"})["files"]}
                self.assertIn(f"/etc/postgresql/{version}/main/conf.d/60-sentinel.conf", files)

    def test_the_hba_include_is_double_quoted(self):
        from sentinel_blue.linux_service_packs import _postgresql
        _files, extra = _postgresql({"config_directory": "/etc/postgresql/16/main", "allowed_networks": ["10.0.0.0/24"]})
        self.assertEqual(extra["activation_lines"]["/etc/postgresql/16/main/pg_hba.conf"], 'include "sentinel-pg-hba.conf"')

    def test_hba_rules_before_sixteen_are_refused_with_a_reason(self):
        from sentinel_blue.linux_service_packs import _postgresql
        with self.assertRaisesRegex(ValueError, "only from PostgreSQL 16"):
            _postgresql({"config_directory": "/etc/postgresql/15/main", "allowed_networks": ["10.0.0.0/24"]})

    def test_the_plan_does_not_depend_on_the_order_options_were_filled(self):
        """Found live on 2.0.6: with both parent files activated, the review
        built postgresql.conf before pg_hba.conf, the setup job (reading the
        saved, key-sorted inventory) built them the other way round, and every
        setup was refused as 'Configuration changed after review'."""
        import hashlib
        from sentinel_blue.linux_service_packs import build
        root = Path(tempfile.mkdtemp())
        self.addCleanup(__import__("shutil").rmtree, root)
        base = "/etc/postgresql/16/main"
        snapshots = {}
        for name, text in (("postgresql.conf", "listen_addresses = 'localhost'\n"),
                           ("pg_hba.conf", "local all postgres peer\n")):
            (root / name).write_text(text)
            snapshots[f"{base}/{name}"] = {"path": name, "sha256": hashlib.sha256(text.encode()).hexdigest()}
        common = {"config_directory": base, "allowed_networks": ["10.0.0.0/24"]}
        forward = dict(common, activation={f"{base}/postgresql.conf": snapshots[f"{base}/postgresql.conf"],
                                           f"{base}/pg_hba.conf": snapshots[f"{base}/pg_hba.conf"]})
        saved = json.loads(json.dumps(forward, sort_keys=True))
        self.assertNotEqual(list(forward["activation"]), list(saved["activation"]))
        self.assertEqual(build("postgresql", forward, root), build("postgresql", saved, root))


class ThePostgreSQLCheckReadsTheWholeConfiguration(unittest.TestCase):
    """Found live on 2.0.6: the step ran `pg_conftool 16 main show`, which only
    prints its usage and exits 1, so every PostgreSQL setup failed its check."""

    def test_the_check_asks_for_every_setting(self):
        from unittest import mock
        import sentinel_blue.service_pack_checks as checks
        root = Path(tempfile.mkdtemp())
        self.addCleanup(__import__("shutil").rmtree, root)
        base = root / "16" / "main"
        base.mkdir(parents=True)
        (base / "postgresql.conf").write_text("include_dir = 'conf.d'\n")
        (base / "pg_hba.conf").write_text('include "sentinel-pg-hba.conf"\nlocal all postgres peer\n')
        spec = {"service_id": "postgresql", "postgres_cluster": str(base),
                "activation_lines": {str(base / "pg_hba.conf"): 'include "sentinel-pg-hba.conf"'}}
        calls = []
        with mock.patch.object(checks, "_command", side_effect=lambda argv: calls.append(argv) or ""):
            checks.run_checks(spec, "validate")
        self.assertIn(["/usr/bin/pg_conftool", "16", "main", "show", "all"], calls)


class UbuntusPostgreSQLWrapperIsUpAndItsClusterIsWatched(unittest.TestCase):
    """Found live on 2.0.6: postgresql.service is a oneshot wrapper that stays
    "active (exited)" and starts postgresql@16-main.service. It read as
    "active", which nothing treats as up, so its baseline was never ready; and
    a restart could leave the wrapper active while its cluster failed."""

    def collect(self, rows):
        from unittest import mock
        from sentinel_blue import collectors
        def run(argv, **kwargs):
            if argv[1] == "list-units":
                output = "".join(f"{name} loaded {active} {sub} fixture\n" for name, active, sub, _ in rows)
            elif argv[1] == "list-unit-files":
                output = "".join(f"{name} enabled enabled\n" for name, *_ in rows)
            else:
                self.assertIn("RemainAfterExit", argv[3])
                output = "".join(f"Id={name}\nActiveState={active}\nSubState={sub}\nUnitFileState=enabled\nNRestarts=0\n"
                                 f"Result=success\nExecMainStatus=0\nRemainAfterExit={remain}\n\n"
                                 for name, active, sub, remain in rows if name in argv[4:])
            return subprocess.CompletedProcess(argv, 0, output, "")
        errors = []
        with mock.patch.object(collectors, "_run", side_effect=run):
            found = collectors._linux_services(errors)
        return {row.name: row.state for row in found}

    def test_a_unit_that_stays_active_by_design_is_up(self):
        states = self.collect([("postgresql.service", "active", "exited", "yes"),
                               ("postgresql@16-main.service", "active", "running", "no"),
                               ("finished.service", "active", "exited", "no"),
                               ("down.service", "inactive", "dead", "yes")])
        self.assertEqual(states, {"postgresql.service": "running", "postgresql@16-main.service": "running",
                                  "finished.service": "active", "down.service": "inactive"})

    def test_the_setup_step_waits_for_the_cluster_too(self):
        from sentinel_blue.linux_service_packs import build
        root = Path(tempfile.mkdtemp())
        self.addCleanup(__import__("shutil").rmtree, root)
        check, apply, _ = build("postgresql", {"config_directory": "/etc/postgresql/16/main"}, root)
        self.assertIn("systemctl is-active --quiet -- postgresql@16-main.service", check)
        settle = apply.split("sb_settle=0", 1)[1].split("done", 1)[0]
        self.assertIn("postgresql@16-main.service", settle)
        self.assertIn("\nsystemctl is-active --quiet -- postgresql@16-main.service\n", apply)

    def test_member_units_are_validated(self):
        from sentinel_blue.setup_recipes import _linux_service
        root = Path(tempfile.mkdtemp())
        self.addCleanup(__import__("shutil").rmtree, root)
        for bad in (["x; reboot"], "postgresql@16-main.service", ["a.service"] * 9):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                _linux_service({"service": "postgresql.service", "member_units": bad}, root)


class AnInstanceComesBackWithItsRepairedParent(unittest.TestCase):
    """Found live on 2.0.6: repairing postgresql.service restarted its cluster,
    postgresql@16-main.service, whose "not running" alert then stayed open."""

    def setUp(self):
        from sentinel_blue.store import Store
        self.store = Store(":memory:")
        self.addCleanup(self.store.close)
        self.now = time.time()

    def alert(self, alert_id, service, created):
        self.store._connection.execute(
            "INSERT INTO alerts (alert_id, agent_id, kind, title, summary, severity, confidence, evidence_json, "
            "recommendation, recommended_action, status, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            (alert_id, "local-linux", "baseline_service_stopped", "t", "s", "high", 0.9,
             json.dumps({"service": service}), "r", "restart_service", "open", created))

    def action(self, service, completed, **result):
        outcome = {"success": True, "stable_health": True} | result
        self.store._connection.execute(
            "INSERT INTO actions (action_id, agent_id, action_type, parameters_json, status, result_json, created_at, "
            "completed_at) VALUES (?,?,?,?,?,?,?,?)",
            (f"a-{service}-{completed}", "local-linux", "repair_service", json.dumps({"service": service}),
             "completed", json.dumps(outcome), completed - 1, completed))

    def test_only_an_instance_of_a_verified_repaired_parent_that_runs_again_closes(self):
        now = self.now
        self.alert("cluster", "postgresql@16-main.service", now)
        self.alert("earlier-repair", "postgresql@15-main.service", now + 10)
        self.alert("other-parent", "openvpn@site.service", now)
        self.alert("unstable", "wg-quick@wg0.service", now)
        self.alert("not-running", "postgresql@17-main.service", now)
        self.action("postgresql.service", now + 5)
        self.action("openvpn-helper.service", now + 5)
        self.action("wg-quick.service", now + 5, stable_health=False)
        closed = self.store.resolve_members_recovered_by_repair("local-linux", [
            "postgresql@16-main.service", "postgresql@15-main.service", "openvpn@site.service",
            "wg-quick@wg0.service", "redis-server.service"])
        self.assertEqual(closed, ["cluster"])

    def test_a_redo_that_fixed_the_parent_closes_its_instances_and_the_failed_repair(self):
        now = self.now
        self.alert("cluster", "postgresql@16-main.service", now)
        self.alert("other-cluster", "postgresql@17-main.service", now)
        self.alert("unrelated", "redis-server.service", now)
        for action_id, service in (("failed-pg", "postgresql.service"), ("failed-redis", "redis-server.service")):
            self.store._connection.execute(
                "INSERT INTO actions (action_id, agent_id, action_type, parameters_json, status, result_json, "
                "created_at, completed_at) VALUES (?,?,?,?,?,?,?,?)",
                (action_id, "local-linux", "repair_service", json.dumps({"service": service}), "failed",
                 json.dumps({"success": False}), now, now))
            self.store._connection.execute(
                "INSERT INTO alerts (alert_id, agent_id, kind, title, summary, severity, confidence, evidence_json, "
                "recommendation, recommended_action, status, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                (f"alert-{action_id}", "local-linux", "automation_action_failed", "t", "s", "high", 0.9,
                 json.dumps({"action_id": action_id, "action_type": "repair_service"}), "r", "observe", "open", now))
        closed = self.store.resolve_repaired_incident(
            "local-linux", "postgresql.service", [], [], decision="resolved_by_setup_redo",
            running_members=["postgresql@16-main.service", "redis-server.service"])
        self.assertEqual(sorted(closed), ["alert-failed-pg", "cluster"])

    def test_the_controller_passes_the_running_instances(self):
        from unittest import mock
        from sentinel_blue.controller import ControllerApp
        app = ControllerApp.__new__(ControllerApp)
        app.store = mock.Mock()
        app._close_member_alerts_after_repair("local-linux", {"services": [
            {"name": "postgresql@16-main.service", "state": "running"},
            {"name": "postgresql@17-main.service", "state": "failed"},
            {"name": "postgresql.service", "state": "running"}]})
        app.store.resolve_members_recovered_by_repair.assert_called_once_with(
            "local-linux", ["postgresql@16-main.service"])


class ARepairThatCannotRestoreIsNotOffered(unittest.TestCase):
    """Found live on 2.0.6: a file's restore point and its second copy were both
    deleted and the file changed. Approval mode still offered "a verified repair
    plan", which failed the moment it was approved."""

    def test_the_offer_waits_for_the_restore_point(self):
        from sentinel_blue.controller import ControllerApp
        from sentinel_blue.store import Store
        from test_service_repair import repair_fixture, damage
        from test_store_controller import _promote_integrity_baseline
        profile, baseline = repair_fixture()
        offers = []
        for lost in (["/etc/web.conf"], ["/etc/other.conf"]):
            store = Store(":memory:")
            self.addCleanup(store.close)
            app = ControllerApp(store, "t" * 32, operator_token="o" * 32, event_profile=profile,
                                auto_recover_services=False, auto_restore=False,
                                restoration_probes=profile.services[0]["expected_transactions"])
            app.ingest(baseline)
            _promote_integrity_baseline(app, store, "agent-one")
            broken = damage(baseline, 2)
            broken["collector_errors"] = [f"restore point lost: {path}" for path in lost]
            broken["collector_issue_sources"] = ["restore_points"] * len(lost)
            from sentinel_blue.restore_health import from_audit
            broken['restore_point_health'] = from_audit({'lost': lost})
            app.ingest(broken)
            offers.append([row for row in store.dashboard()["alerts"]
                           if row["kind"] == "service_repair_required" and row["status"] == "open"])
        self.assertEqual(offers[0], [])
        self.assertEqual(len(offers[1]), 1)


class ARedoPutsBackADamagedFile(unittest.TestCase):
    """Found live on 2.0.6: PostgreSQL's generated conf.d file was corrupted and
    its restore points deleted. Repair could not restore it, and the automatic
    setup redo was refused too ("Setup file differs from the reviewed
    before/after hashes"), because a setup step changes a file only from its
    reviewed before-state. A redo now replaces an owned file in any state."""

    def test_only_a_redo_is_bound_to_redo_mode(self):
        from sentinel_blue.setup_transactions import MODE, bind, commands
        root = Path(tempfile.mkdtemp())
        self.addCleanup(__import__("shutil").rmtree, root)
        scripts = commands("linux-service", {"service": "web.service", "files": []}, root, "true\n")
        self.assertIn(f"mode='{MODE}'", scripts["apply"])
        token = "0" * 32
        self.assertIn("mode='setup'", bind(scripts["apply"], token))
        self.assertIn("mode='redo'", bind(scripts["apply"], token, redo=True))
        with self.assertRaises(ValueError):
            bind(scripts["apply"], token, redo="yes")

    def test_the_transaction_admits_drift_only_for_a_redo(self):
        from sentinel_blue import setup_linux_transaction as tx
        spec = {"files": [{"path": "/etc/x.conf", "sha256": "a" * 64, "previous_sha256": "b" * 64},
                          {"path": "/etc/y.conf", "sha256": "c" * 64, "previous_sha256": "d" * 64}]}
        admitted = {"native": {"files": {"/etc/x.conf": {"sha256": "e" * 64}, "/etc/y.conf": None}}}
        root = Path(tempfile.mkdtemp())
        self.addCleanup(__import__("shutil").rmtree, root)
        from unittest import mock
        with mock.patch.object(tx, "ROOT", root), mock.patch.object(tx, "resources", return_value=[]):
            with self.assertRaisesRegex(ValueError, "differs from the reviewed"):
                tx.preflight_apply(spec, "1" * 32, admitted)
            self.assertEqual(tx.preflight_apply(spec, "1" * 32, admitted, redo=True), [])
            with self.assertRaisesRegex(ValueError, "Invalid setup mode"):
                tx.run("apply", {}, "1" * 32, None, mode="force")

    def test_the_step_itself_replaces_drift_only_under_a_redo(self):
        import hashlib, re, shlex
        from sentinel_blue.setup_recipes import _linux_service
        root = Path(tempfile.mkdtemp())
        self.addCleanup(__import__("shutil").rmtree, root)
        (root / "approved.txt").write_text("good\n")
        target = root / "live.conf"
        source = {"path": "approved.txt", "sha256": hashlib.sha256(b"good\n").hexdigest()}
        _check, apply, _ = _linux_service({"service": "web.service", "files": [
            {"path": str(target), "source": source, "mode": "0644", "previous_sha256": "b" * 64}]}, root)
        quoted = shlex.quote(str(target))
        block = re.search(r"if \[ -e " + re.escape(quoted) + r" \]; then\n.*?\nfi\n", apply, re.S).group(0)
        def admitted(content, redo):
            if content is None:
                target.unlink(missing_ok=True)
            else:
                target.write_text(content)
            env = {"PATH": "/usr/bin:/bin"} | ({"SENTINEL_SETUP_REDO": "1"} if redo else {})
            return subprocess.run(["/bin/sh", "-c", "set -eu\n" + block], env=env).returncode == 0
        self.assertTrue(admitted("good\n", False))
        self.assertFalse(admitted("damaged\n", False))
        self.assertTrue(admitted("damaged\n", True))
        self.assertFalse(admitted(None, False))
        self.assertTrue(admitted(None, True))

    def test_the_redo_job_asks_for_it_and_the_runner_refuses_it_elsewhere(self):
        from sentinel_blue.setup import SetupRunner
        runner = SetupRunner.__new__(SetupRunner)
        runner.on_host_ready = lambda *a: None
        with self.assertRaisesRegex(ValueError, "fresh run of setup tasks only"):
            runner.execute(Path("/nonexistent"), "0" * 64, redo=True)
        with self.assertRaisesRegex(ValueError, "fresh run of setup tasks only"):
            runner.execute(Path("/nonexistent"), "0" * 64, redo="yes")


class AStoppedBootControllerCanStillBeRemoved(unittest.TestCase):
    """Found live on 2.0.6 (real systemd): after `systemctl stop
    sentinel-blue-controller`, removing the boot registration was refused as
    "Object changed after inventory", recorded a conflict, and from then on the
    registration was neither listed nor removable. Withdraw had the same fault."""

    UNIT = "sentinel-blue-controller.service"

    def setUp(self):
        import hashlib as _hashlib
        from unittest import mock
        from sentinel_blue.mutation_ledger import MutationLedger
        from sentinel_blue.withdrawal_native import NativeObjects, object_target
        self.root = Path(tempfile.mkdtemp())
        self.addCleanup(__import__("shutil").rmtree, self.root, True)
        os.chmod(self.root, 0o700)
        self.ledger = MutationLedger(self.root / "ledger")
        self.unit_file = self.root / self.UNIT
        self.receipt = self.root / "controller-boot-binding.json"
        absent = {"exists": False, "active": False, "enabled": "", "configuration_sha256": "0" * 64,
                  "configuration": "", "revision": "StateChangeTimestampMonotonic=0"}
        self.service = dict(absent)
        real = NativeObjects.snapshot
        def snapshot(native, target):
            value = real(native, dict(target, services=[]))
            value["services"] = {name: dict(self.service) for name in target.get("services", [])}
            return value
        self.restored = []
        def restore(native, target, before, current):
            self.restored.append(current)
            for path in target.get("files", []):
                Path(path).unlink(missing_ok=True)
            self.service.clear()
            self.service.update(absent)
            return snapshot(native, target)
        for name, value in (("snapshot", snapshot), ("restore", restore)):
            patcher = mock.patch.object(NativeObjects, name, value)
            patcher.start()
            self.addCleanup(patcher.stop)
        native = NativeObjects(self.ledger)
        self.target = object_target(files=[str(self.unit_file), str(self.receipt)], services=[self.UNIT])
        def perform():
            self.receipt.write_text("{}")
            self.unit_file.write_text("[Unit]\n")
            self.service.update(exists=True, active=True, enabled="enabled", configuration="[Unit]\n",
                                configuration_sha256=_hashlib.sha256(b"[Unit]\n").hexdigest(),
                                revision="StateChangeTimestampMonotonic=5")
            return {"installed": True}
        with self.ledger.lock():
            self.ledger.mutate(native.name, self.target, perform, snapshot=native.snapshot,
                               ownership="sentinel_artifact", context={"controller_boot": True})

    def stop(self):
        self.service.update(active=False, revision="StateChangeTimestampMonotonic=9")

    def test_only_the_running_state_may_differ(self):
        from sentinel_blue.controller_boot import activity_only
        before = {"files": {"a": 1}, "services": {self.UNIT: {"exists": True, "active": True, "enabled": "enabled",
                                                              "revision": "1"}}, "tasks": {}, "persistence": {}}
        stopped = copy.deepcopy(before)
        stopped["services"][self.UNIT].update(active=False, revision="2")
        self.assertTrue(activity_only(stopped, before))
        for change in (lambda v: v["files"].update(a=2), lambda v: v["services"][self.UNIT].update(enabled="disabled"),
                       lambda v: v["services"][self.UNIT].update(exists=False), lambda v: v.pop("tasks")):
            other = copy.deepcopy(stopped)
            change(other)
            self.assertFalse(activity_only(other, before))

    def test_status_and_removal_after_a_stop(self):
        from sentinel_blue.controller_boot import status, uninstall
        self.stop()
        entry = status(self.ledger)["registrations"][0]
        self.assertTrue(entry["matches_record"], entry)
        self.assertTrue(entry["removable"])
        self.assertEqual(uninstall(ledger=self.ledger)["status"], "undone")
        self.assertFalse(self.unit_file.exists())
        self.assertTrue(any(event["kind"] == "rebased" and event.get("reason") == "controller_running_state_changed"
                            for event in self.ledger.read()))

    def test_withdraw_inventory_does_not_call_it_a_conflict(self):
        from sentinel_blue.withdrawal import inventory
        self.stop()
        rows = [row for row in inventory(self.ledger)["actions"] if row.get("context", {}).get("controller_boot")]
        self.assertTrue(rows[0]["matches_post"])
        self.assertNotIn("conflict", rows[0])

    def test_a_registration_held_by_the_old_fault_is_released_and_removed(self):
        from sentinel_blue.controller_boot import status, uninstall, registrations
        self.stop()
        action_id = registrations(self.ledger)[0]["action_id"]
        self.ledger.append("conflict", action_id=action_id, reason="Post-state changed before undo",
                           another_actor_modified=True)
        entry = status(self.ledger)["registrations"][0]
        self.assertTrue(entry["held"])
        self.assertIn("removing it releases the hold", entry["reason"])
        self.assertEqual(uninstall(ledger=self.ledger)["status"], "undone")
        self.assertFalse(self.unit_file.exists())

    def test_a_held_registration_that_really_changed_stays_held(self):
        from sentinel_blue.controller_boot import uninstall, registrations
        from sentinel_blue.mutation_ledger import OwnershipConflict
        self.stop()
        action_id = registrations(self.ledger)[0]["action_id"]
        self.ledger.append("conflict", action_id=action_id, reason="Post-state changed before undo",
                           another_actor_modified=True)
        self.unit_file.write_text("[Unit]\nDescription=edited by hand\n")
        with self.assertRaises(OwnershipConflict):
            uninstall(ledger=self.ledger)
        self.assertTrue(self.unit_file.exists())


class ANewUnitThatFailsRollsBackCleanly(unittest.TestCase):
    """Found live on 2.0.6 with the gunicorn pack: its unit wrote
    WorkingDirectory="/srv/app", which systemd rejects ("path is not
    absolute"), so the new unit never loaded. Rolling back then stopped the
    unit after its file was removed, which fails ("not loaded"); the step ended
    uncertain, held every other setup task on the host, and left its enable
    link behind."""

    def test_the_gunicorn_unit_is_not_quoted_and_needs_no_quoting(self):
        from sentinel_blue.linux_service_packs import _gunicorn
        options = {"application": "app:application", "working_directory": "/srv/app", "user": "www-data"}
        unit = next(iter(_gunicorn(options)[0].values()))
        self.assertIn("\nWorkingDirectory=/srv/app\n", unit)
        for bad in ("/srv/my app", "/srv/app\\", '/srv/"app"', "relative", "/srv/%h"):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                _gunicorn(dict(options, working_directory=bad))

    def test_the_rollback_disables_a_unit_it_created_before_removing_it(self):
        from sentinel_blue.setup_recipes import _linux_service
        import hashlib as _hashlib
        root = Path(tempfile.mkdtemp())
        self.addCleanup(__import__("shutil").rmtree, root)
        (root / "unit.txt").write_text("[Service]\nExecStart=/bin/true\n")
        _check, apply, _ = _linux_service({"service": "sentinel-new.service", "enable": True, "files": [
            {"path": "/etc/systemd/system/sentinel-new.service", "previous_sha256": "absent", "mode": "0644",
             "source": {"path": "unit.txt", "sha256": _hashlib.sha256(b"[Service]\nExecStart=/bin/true\n").hexdigest()}}]},
            root)
        restore = apply.split("sb_restore() {", 1)[1].split("\n}\n", 1)[0]
        self.assertLess(restore.index("systemctl disable -- sentinel-new.service"), restore.index("sb_file_guard restore"))
        self.assertIn('"$sb_new_unit" = 1', restore.split("sb_file_guard restore")[1])
        self.assertLess(apply.index("sb_new_unit=0"), apply.index("sb_restore() {"))


@unittest.skipUnless(os.name == "posix" and Path("/run/systemd/system").is_dir() and os.geteuid() == 0,
                     "requires root on a native systemd host")
class ANewUnitThatFailsRollsBackOnSystemd(unittest.TestCase):
    def test_a_unit_that_does_not_load_is_rolled_back_with_no_link_left(self):
        import hashlib as _hashlib, uuid
        from sentinel_blue.setup_recipes import compile_recipe
        name = "sentinel-new-unit-" + uuid.uuid4().hex[:12] + ".service"
        target = Path("/etc/systemd/system") / name
        link = Path("/etc/systemd/system/multi-user.target.wants") / name
        broken = '[Service]\nWorkingDirectory="/tmp"\nExecStart=/usr/bin/sleep 3600\n[Install]\nWantedBy=multi-user.target\n'
        def systemctl(*arguments):
            return subprocess.run(["systemctl", *arguments], capture_output=True, text=True, timeout=25)
        with tempfile.TemporaryDirectory(prefix="sentinel-new-unit-", dir="/var/lib") as folder:
            source = Path(folder) / "unit.service"
            source.write_text(broken)
            try:
                _check, apply, _ = compile_recipe("linux-service", {"service": name, "enable": True, "files": [
                    {"path": str(target), "previous_sha256": "absent", "mode": "0644",
                     "source": {"path": str(source), "sha256": _hashlib.sha256(broken.encode()).hexdigest()}}]},
                    Path(folder), "linux")
                result = subprocess.run(["sh", "-c", apply], capture_output=True, text=True, timeout=120)
                self.assertNotIn(result.returncode, (0, 43), result.stderr)
                self.assertFalse(target.exists())
                self.assertFalse(link.is_symlink())
                self.assertEqual(systemctl("show", "--property=LoadState", "--value", name).stdout.strip(), "not-found")
            finally:
                systemctl("disable", name)
                target.unlink(missing_ok=True)
                link.unlink(missing_ok=True)
                systemctl("daemon-reload")
                systemctl("reset-failed", name)


class SetupsOwnNewItemsCloseWithTheBaseline(unittest.TestCase):
    """Found live on 2.0.6: the gunicorn pack's unit, unit file, enable link and
    listener were raised as "new" during setup and stayed open after the
    baseline holding exactly them was approved."""

    def test_only_items_of_this_profiles_services_that_the_baseline_holds_close(self):
        from sentinel_blue.controller import ControllerApp
        from sentinel_blue.store import Store
        from test_service_repair import repair_fixture
        from test_store_controller import _promote_integrity_baseline
        profile, baseline = repair_fixture()
        service = profile.services[0]["service_id"]
        unit_file = f"/etc/systemd/system/{service}"
        items = [{"kind": "systemd-unit", "name": service, "owner": "root", "enabled": True, "sha256": ""},
                 {"kind": "systemd-file", "name": unit_file, "owner": "root", "enabled": True, "sha256": "1" * 64},
                 {"kind": "systemd-file-link", "name": f"/etc/systemd/system/multi-user.target.wants/{service}",
                  "owner": "unknown", "enabled": True, "sha256": "2" * 64},
                 {"kind": "systemd-unit", "name": "planted.service", "owner": "root", "enabled": True, "sha256": ""}]
        raw = copy.deepcopy(profile.raw)
        raw["services"][0]["repair_policy"]["restore_files"].append(unit_file)
        raw["services"][0]["required_files"] = [*raw["services"][0].get("required_files", []), unit_file]
        raw["services"][0]["port"] = 8765
        from sentinel_blue.event_profile import EventProfile
        profile = EventProfile.from_dict(raw)
        baseline = copy.deepcopy(baseline)
        baseline["persistence"] = items
        baseline["listeners"] = [{"protocol": "tcp", "address": "127.0.0.1", "port": 8765},
                                 {"protocol": "tcp", "address": "0.0.0.0", "port": 4444}]
        store = Store(":memory:")
        self.addCleanup(store.close)
        app = ControllerApp(store, "t" * 32, operator_token="o" * 32, event_profile=profile,
                            auto_recover_services=False, auto_restore=False,
                            restoration_probes=profile.services[0]["expected_transactions"])
        app.ingest(baseline)
        _promote_integrity_baseline(app, store, "agent-one")
        evidence = [("new_persistence_item", {"persistence": item}) for item in items]
        evidence.append(("new_persistence_item", {"persistence": dict(items[1], sha256="9" * 64)}))
        evidence += [("new_network_listener", {"listener": listener}) for listener in baseline["listeners"]]
        for index, (kind, value) in enumerate(evidence):
            store._connection.execute(
                "INSERT INTO alerts (alert_id, agent_id, kind, title, summary, severity, confidence, evidence_json, "
                "recommendation, recommended_action, status, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                (f"alert-{index}", "agent-one", kind, "t", "s", "high", 0.9, json.dumps(value), "r", "snapshot",
                 "open", time.time()))
        app._close_setup_items_in_baseline("agent-one")
        still = sorted(row["alert_id"] for row in store.dashboard()["alerts"]
                       if row["status"] == "open" and row["kind"] in {"new_persistence_item", "new_network_listener"})
        # Open: the planted unit, a unit file whose bytes differ from the
        # baseline, and a listener on a port no service declares.
        self.assertEqual(still, ["alert-3", "alert-4", "alert-6"])


class TwoChecksOfOneAddressAreToldApart(unittest.TestCase):
    """Found live on 2.0.6: Redis (6379) and PostgreSQL (5432) were both checked
    by TCP on 127.0.0.1. Both results were named "127.0.0.1", so neither matched
    its service, both stayed "unverified", and the baseline was never ready."""

    def listener(self):
        import socket
        server = socket.socket()
        server.bind(("127.0.0.1", 0))
        server.listen(4)
        self.addCleanup(server.close)
        return server.getsockname()[1]

    def test_an_unnamed_check_is_named_by_its_target_and_port(self):
        from sentinel_blue.probe_evidence import probe_name
        self.assertEqual(probe_name({"kind": "tcp", "target": "127.0.0.1", "port": 6379}), "127.0.0.1:6379")
        self.assertEqual(probe_name({"kind": "tcp", "target": "::1", "port": 5432}), "[::1]:5432")
        self.assertEqual(probe_name({"kind": "http", "target": "http://127.0.0.1:8080/"}), "http://127.0.0.1:8080/")
        self.assertEqual(probe_name({"kind": "tcp", "target": "127.0.0.1", "port": 1, "name": "db"}), "db")
        self.assertEqual(probe_name({"kind": "dns", "target": "127.0.0.1"}), "127.0.0.1")

    def test_both_services_are_verified_from_one_agent_report(self):
        from dataclasses import asdict
        from sentinel_blue.desktop_control import service_rows
        from sentinel_blue.probes import run_probes
        specs = {"redis-server.service": {"kind": "tcp", "target": "127.0.0.1", "port": self.listener(), "timeout": 2},
                 "postgresql.service": {"kind": "tcp", "target": "127.0.0.1", "port": self.listener(), "timeout": 2}}
        rows = [asdict(row) for row in run_probes(list(specs.values()), ["127.0.0.0/8"])]
        self.assertEqual(len({row["name"] for row in rows}), 2)
        now = time.time()
        telemetry = {"local-linux": {"observed_at": now, "probes": rows,
                                     "services": [{"name": name, "state": "running"} for name in specs]}}
        manifests = [{"host": "local-linux", "service_id": name, "expected_transactions": [spec]}
                     for name, spec in specs.items()]
        result = service_rows(manifests, telemetry, [{"agent_id": "local-linux", "enabled": True}], now=now)
        self.assertEqual([row["health"] for row in result], ["healthy", "healthy"], result)

    def test_closing_one_services_incident_leaves_the_other_open(self):
        from sentinel_blue.store import Store
        store = Store(":memory:")
        self.addCleanup(store.close)
        for port in (6379, 5432):
            store._connection.execute(
                "INSERT INTO alerts (alert_id, agent_id, kind, title, summary, severity, confidence, evidence_json, "
                "recommendation, recommended_action, status, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                (f"alert-{port}", "local-linux", "service_probe_failed", "t", "s", "high", 0.9,
                 json.dumps({"probe": {"name": f"127.0.0.1:{port}", "target": "127.0.0.1"}}),
                 "r", "snapshot", "open", time.time()))
        from sentinel_blue.probe_evidence import probe_name
        names = [probe_name({"kind": "tcp", "target": "127.0.0.1", "port": 6379})]
        self.assertEqual(store.resolve_repaired_incident("local-linux", "redis-server.service", names, []),
                         ["alert-6379"])


class AParentFileKeepsItsMode(unittest.TestCase):
    """Found live on 2.0.6: Ubuntu ships pg_hba.conf as 0640. The pack wrote
    it as 0644 by default, and its check refused to widen it only when the
    approved setup ran, so PostgreSQL could never be configured."""

    def test_the_mode_is_chosen_at_review_from_the_file_on_this_vm(self):
        from sentinel_blue.linux_workspace import keep_parent_modes
        root = Path(tempfile.mkdtemp())
        self.addCleanup(__import__("shutil").rmtree, root)
        cases = {"a.conf": (0o640, "0640"), "b.conf": (0o644, "0644"), "c.conf": (0o600, "0600"),
                 "d.conf": (0o660, "0640"), "e.conf": (0o400, None), "f.conf": (0o640, "0600")}
        for name, (mode, _) in cases.items():
            (root / name).write_text("x")
            (root / name).chmod(mode)
        (root / "link.conf").symlink_to(root / "a.conf")
        snapshot = {"path": "x", "sha256": "0" * 64}
        options = {"postgresql": {"activation": {str(root / name): snapshot for name in [*cases, "link.conf", "absent.conf"]},
                                  "file_modes": {str(root / "f.conf"): "0600"}},
                   "redis": {"bind_address": "127.0.0.1"}}
        before = copy.deepcopy(options)
        result = keep_parent_modes(options)
        self.assertEqual(options, before)
        self.assertEqual(result["postgresql"]["file_modes"],
                         {str(root / name): expected for name, (_, expected) in cases.items() if expected})
        self.assertEqual(result["redis"], {"bind_address": "127.0.0.1"})

    def test_the_step_names_the_file_it_would_widen(self):
        source = (Path(__file__).resolve().parents[1] / "src" / "sentinel_blue" / "service_pack_checks.py").read_text()
        self.assertIn("its permissions would be widened", source)
        self.assertIn("requirement['path']", source.split("its permissions would be widened")[1][:400])


class AFolderInTheCatalogStandsForItsFiles(unittest.TestCase):
    """2.0.5: catalog entries that name a folder (/etc/postgresql and six
    others) gave an adopted service no files of its own to repair."""

    def test_files_under_a_folder_shallowest_first_bounded_and_never_links(self):
        from sentinel_blue.linux_workspace import config_files
        root = Path(tempfile.mkdtemp())
        self.addCleanup(__import__("shutil").rmtree, root)
        (root / "16" / "main" / "conf.d").mkdir(parents=True)
        for name in ("16/main/postgresql.conf", "16/main/pg_hba.conf", "16/main/conf.d/extra.conf", "top.conf"):
            (root / name).write_text("x")
        (root / "16" / "main" / "big.conf").write_bytes(b"x" * (1024 * 1024 + 1))
        (root / "link.conf").symlink_to(root / "top.conf")
        found = [str(p.relative_to(root)) for p in config_files(root)]
        self.assertEqual(found, ["top.conf", "16/main/pg_hba.conf", "16/main/postgresql.conf",
                                 "16/main/conf.d/extra.conf"])
        self.assertEqual(len(config_files(root, limit=2)), 2)
        self.assertEqual(config_files(root / "top.conf"), [root / "top.conf"])
        self.assertEqual(config_files(root / "absent"), [])


if __name__ == "__main__":
    unittest.main()
