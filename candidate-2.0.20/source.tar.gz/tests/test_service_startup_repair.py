"""Startup recovery contracts, native command adapters and actual file rollback."""

import copy
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from sentinel_blue.actions import ActionExecutor
from sentinel_blue.event_profile import EventProfile
from sentinel_blue.protocol import ProbeResult
from sentinel_blue.service_repair import repair_parameters, validate_repair_contract, normalize_repair_policy
from sentinel_blue.service_startup import read_start_mode, change_start_mode
from sentinel_blue.store import _require_success_result_contract
from test_service_repair import repair_fixture, damage


def startup_fixture(path="/etc/web.conf"):
    profile, baseline = repair_fixture(path)
    raw = copy.deepcopy(profile.raw)
    raw["services"][0]["repair_policy"]["restore_start_mode"] = "enabled"
    profile = EventProfile.from_dict(raw)
    current = damage(baseline)
    current["services"][0]["start_mode"] = "disabled"
    return profile, baseline, current


class StartupContractTests(unittest.TestCase):
    def test_disabled_service_has_exact_manifest_and_baseline_bound_repair(self):
        profile, baseline, current = startup_fixture()
        plan = repair_parameters(profile, "agent-one", "web.service", baseline, current)
        self.assertEqual(plan["repair"]["startup"], {"observed": "disabled", "desired": "enabled"})
        validate_repair_contract(profile, "agent-one", plan, current)
        self.assertEqual(len(plan["repair"]["restore_files"]), 1)

    def test_startup_authority_cannot_be_omitted_or_changed_by_agent_plan(self):
        profile, baseline, current = startup_fixture()
        original = repair_parameters(profile, "agent-one", "web.service", baseline, current)
        for alter in (
            lambda value: value["repair"].pop("startup"),
            lambda value: value["repair"]["startup"].update(desired="manual"),
            lambda value: value["repair"]["startup"].update(observed="enabled"),
            lambda value: value["repair"]["startup"].update(command="inert unexpected field"),
        ):
            plan = copy.deepcopy(original)
            alter(plan)
            with self.assertRaises(ValueError):
                validate_repair_contract(profile, "agent-one", plan, current)

    def test_missing_policy_baseline_mismatch_masks_and_live_disabled_service_hold(self):
        for case in ("no_policy", "baseline", "masked", "masked-runtime", "running"):
            with self.subTest(case=case):
                profile, baseline, current = startup_fixture()
                if case == "no_policy":
                    raw = copy.deepcopy(profile.raw)
                    raw["services"][0]["repair_policy"].pop("restore_start_mode")
                    profile = EventProfile.from_dict(raw)
                elif case == "baseline":
                    baseline["services"][0]["start_mode"] = "disabled"
                elif case == "running":
                    current["services"][0]["state"] = "running"
                else:
                    current["services"][0]["start_mode"] = case
                with self.assertRaisesRegex(ValueError, "startup"):
                    repair_parameters(profile, "agent-one", "web.service", baseline, current)

    def test_windows_auto_and_manual_require_matching_baseline(self):
        for desired in ("auto", "manual"):
            profile, baseline, current = startup_fixture()
            raw = copy.deepcopy(profile.raw)
            raw["services"][0]["repair_policy"]["restore_start_mode"] = desired
            profile = EventProfile.from_dict(raw)
            for value in (baseline, current):
                value["platform"] = "Windows"
                value["integrity"][0]["security_descriptor_sha256"] = "a" * 64
            baseline["services"][0]["start_mode"] = desired.title()
            plan = repair_parameters(profile, "agent-one", "web.service", baseline, current)
            validate_repair_contract(profile, "agent-one", plan, current)
            self.assertEqual(plan["repair"]["startup"]["desired"], desired)

    def test_invalid_startup_policy_values_are_rejected(self):
        profile, _, _ = startup_fixture()
        for value in (True, None, {}, [], "disabled", "masked", "auto;unexpected", 1):
            policy = copy.deepcopy(profile.services[0]["repair_policy"])
            policy["restore_start_mode"] = value
            with self.assertRaises(ValueError):
                normalize_repair_policy(policy, profile.services[0])


class StartupExecutionTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name).resolve()
        self.target = self.root / "web.conf"
        self.target.write_bytes(b"trusted")
        self.profile, self.baseline, self.current = startup_fixture(str(self.target))
        self.executor = ActionExecutor(self.root / "state", allow_restoration=True,
                                       allow_service_recovery=True, authorized_networks=["127.0.0.0/8"])
        self.assertTrue(self.executor.restore_points.capture(self.baseline["integrity"])["success"])
        self.target.write_bytes(b"damaged")
        self.parameters = repair_parameters(self.profile, "agent-one", "web.service", self.baseline, self.current)
        self.mode, self.state = "disabled", "stopped"
        self.events = []
        self.patches = [
            patch.object(self.executor, "_service_state", side_effect=lambda _: self.state),
            patch.object(self.executor, "_set_service_state", side_effect=self.set_state),
            patch.object(self.executor.repairs, "_startup_mode", side_effect=lambda _: self.mode),
            patch.object(self.executor.repairs, "_change_startup", side_effect=self.set_mode),
            patch.object(self.executor, "_wait_for_service_probes", side_effect=self.probe),
        ]
        for item in self.patches:
            item.start()
            self.addCleanup(item.stop)

    def set_state(self, service, desired):
        if desired == "running":
            self.assertEqual(self.mode, "enabled")
            self.assertEqual(self.target.read_bytes(), b"trusted")
        self.events.append(("state", desired))
        self.state = desired

    def set_mode(self, service, expected, desired):
        self.assertEqual(self.mode, expected)
        self.events.append(("mode", desired))
        self.mode = desired

    def probe(self, specs, **kwargs):
        self.assertEqual(self.target.read_bytes(), b"trusted")
        self.assertEqual(self.mode, "enabled")
        return [ProbeResult(item["name"], item["target"], True) for item in specs], 3, True

    def execute(self):
        return self.executor.execute("repair_service", self.parameters, self.current)

    def test_commit_and_exact_rollback_cover_file_mode_and_runtime(self):
        result = self.execute()
        self.assertTrue(result["success"], result)
        _require_success_result_contract("repair_service", self.parameters, result)
        self.assertEqual(self.events, [("mode", "enabled"), ("state", "running")])
        altered = copy.deepcopy(result)
        altered["record"].pop("startup")
        with self.assertRaisesRegex(ValueError, "startup"):
            _require_success_result_contract("repair_service", self.parameters, altered)
        undone = self.executor.execute("rollback_service_repair", result["pre_state"], self.current)
        self.assertTrue(undone["success"], undone)
        self.assertEqual((self.mode, self.state, self.target.read_bytes()), ("disabled", "stopped", b"damaged"))

    def test_failed_application_rolls_back_all_effects(self):
        self.executor._wait_for_service_probes.side_effect = lambda *a, **k: ([], 3, False)
        result = self.execute()
        self.assertFalse(result["success"])
        self.assertTrue(result["rolled_back"], result)
        self.assertEqual((self.mode, self.state, self.target.read_bytes()), ("disabled", "stopped", b"damaged"))

    def test_concurrent_startup_change_stops_before_file_mutation(self):
        self.mode = "enabled"
        result = self.execute()
        self.assertFalse(result["success"])
        self.assertEqual(self.target.read_bytes(), b"damaged")
        self.assertEqual(self.events, [])

    def test_partial_native_change_is_rolled_back(self):
        def change(service, expected, desired):
            self.set_mode(service, expected, desired)
            if desired == "enabled":
                raise OSError("inert native post-change failure")
        self.executor.repairs._change_startup.side_effect = change
        result = self.execute()
        self.assertFalse(result["success"])
        self.assertTrue(result["rolled_back"], result)
        self.assertEqual((self.mode, self.state, self.target.read_bytes()), ("disabled", "stopped", b"damaged"))

    def test_third_startup_state_prevents_destructive_rollback(self):
        result = self.execute()
        self.assertTrue(result["success"], result)
        self.mode = "manual"
        before = list(self.events)
        undone = self.executor.execute("rollback_service_repair", result["pre_state"], self.current)
        self.assertFalse(undone["success"])
        self.assertEqual((self.mode, self.state, self.target.read_bytes()), ("manual", "running", b"trusted"))
        self.assertEqual(self.events, before)

    def test_crash_after_mode_change_recovers_exact_prior_state(self):
        self.executor._set_service_state.side_effect = KeyboardInterrupt("owned crash fixture")
        with self.assertRaises(KeyboardInterrupt):
            self.execute()
        self.executor._set_service_state.side_effect = self.set_state
        self.assertEqual((self.mode, self.state), ("enabled", "stopped"))
        recovery = self.executor.repairs.reconcile()
        self.assertTrue(recovery["healthy"], recovery)
        self.assertEqual((self.mode, self.state, self.target.read_bytes()), ("disabled", "stopped", b"damaged"))

    def test_crash_after_healthy_start_commits_verified_effects(self):
        self.executor._wait_for_service_probes.side_effect = KeyboardInterrupt("owned crash fixture")
        with self.assertRaises(KeyboardInterrupt):
            self.execute()
        self.executor._wait_for_service_probes.side_effect = self.probe
        recovery = self.executor.repairs.reconcile()
        self.assertTrue(recovery["healthy"], recovery)
        self.assertEqual((self.mode, self.state, self.target.read_bytes()), ("enabled", "running", b"trusted"))


class NativeStartupAdapterTests(unittest.TestCase):
    @staticmethod
    def result(text, code=0):
        return subprocess.CompletedProcess([], code, text, "")

    def test_linux_checks_load_state_and_exact_mode(self):
        with patch("sentinel_blue.service_startup.platform.system", return_value="Linux"):
            for text in ("LoadState=loaded\nUnitFileState=disabled\n", "UnitFileState=enabled\nLoadState=loaded\n"):
                with patch("sentinel_blue.service_startup._run", return_value=self.result(text)):
                    self.assertIn(read_start_mode("web.service"), {"disabled", "enabled"})
            # 2.0.3: a masked unit is a readable startup mode, so it can be repaired.
            for text, mode in (("LoadState=masked\nUnitFileState=masked\n", "masked"),
                               ("LoadState=masked\nUnitFileState=masked-runtime\n", "masked-runtime")):
                with patch("sentinel_blue.service_startup._run", return_value=self.result(text)):
                    self.assertEqual(read_start_mode("web.service"), mode)
            for text in ("LoadState=masked\nUnitFileState=enabled\n", "LoadState=loaded\nUnitFileState=disabled\nUnitFileState=enabled\n", "LoadState=not-found\nUnitFileState=disabled\n"):
                with patch("sentinel_blue.service_startup._run", return_value=self.result(text)):
                    with self.assertRaises(ValueError):
                        read_start_mode("web.service")

    def test_windows_numeric_mode_cannot_be_faked_by_display_name(self):
        with patch("sentinel_blue.service_startup.platform.system", return_value="Windows"):
            for native, expected in ((2, "auto"), (3, "manual"), (4, "disabled")):
                with patch("sentinel_blue.service_startup._run", return_value=self.result(f"START_TYPE         : {native} FIXTURE\nDISPLAY_NAME: START_TYPE : 2 AUTO\n")):
                    self.assertEqual(read_start_mode("web"), expected)
            for text in ("DISPLAY_NAME: START_TYPE : 2 AUTO\n", "START_TYPE : 4 DISABLED\nSTART_TYPE : 2 AUTO\n", "START_TYPE : 0 BOOT\n"):
                with patch("sentinel_blue.service_startup._run", return_value=self.result(text)):
                    with self.assertRaises(ValueError):
                        read_start_mode("web")

    def test_native_compare_change_verify_uses_literal_argv(self):
        for system, desired, command in (("Linux", "enabled", ["systemctl", "enable", "web"]),
                                          ("Windows", "auto", ["sc.exe", "config", "web", "start=", "auto"]),
                                          ("Windows", "manual", ["sc.exe", "config", "web", "start=", "demand"])):
            with patch("sentinel_blue.service_startup.platform.system", return_value=system), \
                 patch("sentinel_blue.service_startup.read_start_mode", side_effect=["disabled", desired]), \
                 patch("sentinel_blue.service_startup._run", return_value=self.result("")) as run:
                change_start_mode("web", "disabled", desired)
                run.assert_called_once_with(command)

    def test_mismatched_native_state_prevents_command(self):
        with patch("sentinel_blue.service_startup.platform.system", return_value="Windows"), \
             patch("sentinel_blue.service_startup.read_start_mode", return_value="manual"), \
             patch("sentinel_blue.service_startup._run") as run:
            with self.assertRaisesRegex(ValueError, "changed"):
                change_start_mode("web", "disabled", "auto")
            run.assert_not_called()


if __name__ == "__main__":
    unittest.main()
