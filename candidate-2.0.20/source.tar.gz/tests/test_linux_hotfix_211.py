"""SB210-R2 fixes. Native enablement uses a disposable systemctl --root only."""
import copy
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import uuid

from sentinel_blue import linux_service_packs as packs
from sentinel_blue import service_pack_checks as checks
from sentinel_blue.withdrawal_native import NativeObjects, object_target
from sentinel_blue.mutation_ledger import OwnershipConflict


@unittest.skipUnless(os.name == 'posix' and shutil.which('systemctl'), 'isolated native systemctl unavailable')
class Withdrawal211Tests(unittest.TestCase):
    def transition(self, initial, changed):
        with tempfile.TemporaryDirectory(prefix='sb211-systemctl-root-') as td:
            root = Path(td)
            units = root / 'usr/lib/systemd/system'
            units.mkdir(parents=True)
            name = 'sentinel-fixture.service'
            unit = '[Unit]\nDescription=Fixture\n[Service]\nExecStart=/bin/true\n[Install]\nWantedBy=multi-user.target\n'
            (units / name).write_text(unit)
            (units / 'neighbor.service').write_text(unit)
            (units / 'multi-user.target').write_text('[Unit]\nDescription=Test target\n')
            calls = []
            def command(*argv, **kwargs):
                self.assertEqual(argv[0], 'systemctl')
                if argv[1] in {'start', 'stop', 'restart', 'daemon-reload'}:
                    return subprocess.CompletedProcess(argv, 0, '', '')
                actual = [shutil.which('systemctl'), '--root=' + td, *argv[1:]]
                calls.append(actual)
                result = subprocess.run(actual, capture_output=True, text=True, timeout=10)
                self.assertIn(result.returncode, kwargs.get('allowed', (0,)), result.stderr)
                return result
            def set_mode(mode):
                command('systemctl', 'unmask', '--', name)
                command('systemctl', 'unmask', '--runtime', '--', name)
                command('systemctl', 'disable', '--', name)
                command('systemctl', 'disable', '--runtime', '--', name)
                if mode.startswith('enabled'):
                    command('systemctl', 'enable', *(['--runtime'] if mode.endswith('-runtime') else []), '--', name)
                elif mode.startswith('masked'):
                    command('systemctl', 'mask', *(['--runtime'] if mode.endswith('-runtime') else []), '--', name)
            def state(_):
                value = command('systemctl', 'is-enabled', name, allowed=(0, 1)).stdout.strip()
                return {'exists': True, 'enabled': value, 'active': False, 'configuration': unit}
            command('systemctl', 'enable', '--', 'neighbor.service')
            neighbor = root / 'etc/systemd/system/multi-user.target.wants/neighbor.service'
            neighbor_link = os.readlink(neighbor)
            set_mode(initial)
            adapter = object.__new__(NativeObjects)
            adapter.service = state
            target = object_target(services=[name])
            before = adapter.snapshot(target)
            self.assertEqual(before['services'][name]['enabled'], initial)
            set_mode(changed)
            expected = adapter.snapshot(target)
            with patch('sentinel_blue.setup_linux_transaction.command', side_effect=command):
                result = adapter.restore(target, before, expected)
            self.assertEqual(result, before)
            self.assertEqual(os.readlink(neighbor), neighbor_link)
            return calls

    def test_runtime_enablement_restored_from_persistent(self):
        self.transition('enabled-runtime', 'enabled')

    def test_disabled_restored_from_enabled(self):
        self.transition('disabled', 'enabled')

    def test_persistent_enablement_restored_from_runtime(self):
        self.transition('enabled', 'enabled-runtime')

    def test_runtime_mask_restored_from_enabled(self):
        self.transition('masked-runtime', 'enabled')

    def test_persistent_mask_restored_from_enabled(self):
        self.transition('masked', 'enabled')

    def test_runtime_mask_restored_from_persistent_mask(self):
        self.transition('masked-runtime', 'masked')

    def test_persistent_mask_restored_from_runtime_mask(self):
        self.transition('masked', 'masked-runtime')

    def test_changed_native_snapshot_still_blocks_before_mutation(self):
        adapter = object.__new__(NativeObjects)
        expected = {'files': {}, 'services': {}, 'tasks': {}, 'persistence': {}}
        with patch.object(adapter, 'snapshot', return_value={'outside': 'edit'}), \
                patch('sentinel_blue.setup_linux_transaction.command') as command:
            with self.assertRaisesRegex(OwnershipConflict, 'changed after Sentinel'):
                adapter.restore({}, expected, expected)
            command.assert_not_called()


class RepairHistory211Tests(unittest.TestCase):
    def setUp(self):
        from test_service_repair import RepairExecutionTests
        self.fixture = RepairExecutionTests('test_file_restore_and_start_commit_together_and_support_exact_undo')
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)
        self.ex = self.fixture.executor
        with patch.object(self.ex.repairs, '_transition', side_effect=self.fixture.change_state):
            self.result = self.fixture.run_repair()
        self.assertTrue(self.result['success'], self.result)
        self.identifier = self.result['record']['transaction_id']
        self.template = self.ex.repairs._read(self.ex.repairs._path(self.identifier))

    def add(self, count, *, age=0, status='committed'):
        identifiers = []
        for _ in range(count):
            record = copy.deepcopy(self.template)
            record['transaction_id'] = str(uuid.uuid4())
            record['created_at'] -= age
            record['completed_at'] -= age
            record['status'] = status
            self.ex.repairs._write(record)
            identifiers.append(record['transaction_id'])
        return identifiers

    def test_257_recent_completed_records_do_not_trip_health_gate(self):
        from sentinel_blue.agent import refresh_recovery_health
        self.add(256)
        result = self.ex.repairs.reconcile()
        self.assertTrue(result['healthy'], result)
        health = {'healthy': True, 'action_safe': True, 'errors': [], 'critical_errors': []}
        refresh_recovery_health(self.ex, health)
        self.assertTrue(health['action_safe'], health)
        self.assertEqual(len(list(self.ex.state_dir.glob('service-repair-*.json'))), 257)

    def test_aged_terminal_history_archived_not_deleted_and_lookup_preserved(self):
        ids = self.add(300, age=7200)
        result = self.ex.repairs.reconcile()
        self.assertTrue(result['healthy'], result)
        self.assertEqual(len(list(self.ex.state_dir.glob('service-repair-*.json'))), 1)
        self.assertEqual(len(list((self.ex.state_dir / 'service-repair-history').rglob('*.json'))), 300)
        for identifier in (ids[0], ids[-1]):
            record = self.ex.repairs._read(self.ex.repairs._path(identifier))
            self.assertEqual(record['transaction_id'], identifier)
            self.assertEqual(record['children'], self.template['children'])

    def test_archive_preserves_real_exact_rollback_and_child_evidence(self):
        record = copy.deepcopy(self.template)
        record['created_at'] -= 7200
        record['completed_at'] -= 7200
        self.ex.repairs._write(record)
        children = {p: p.read_bytes() for p in self.ex.restore_points.transactions.glob('*') if p.is_file()}
        self.assertTrue(self.ex.repairs.reconcile()['healthy'])
        self.assertFalse(self.ex.repairs._path(self.identifier).exists())
        self.assertEqual({p: p.read_bytes() for p in children}, children)
        with patch.object(self.ex.repairs, '_transition', side_effect=self.fixture.change_state):
            result = self.ex.execute('rollback_service_repair', self.result['pre_state'], self.fixture.current)
        self.assertTrue(result['success'], result)
        self.assertEqual(self.fixture.target.read_bytes(), b'damaged')
        self.assertEqual(self.fixture.native_state, 'stopped')
        self.assertEqual(self.ex.repairs._read(self.ex.repairs._path(self.identifier))['status'], 'rolled_back')

    def test_unfinished_old_journal_is_retained_and_remains_held(self):
        identifier = self.add(1, age=7200, status='rollback_failed')[0]
        self.ex.allow_restoration = False
        result = self.ex.repairs.reconcile()
        self.assertFalse(result['healthy'])
        self.assertTrue(self.ex.repairs._path(identifier).exists())
        self.assertFalse(self.ex.repairs._archive_path(identifier).exists())

    def test_malformed_old_journal_is_not_archived_or_ignored(self):
        identifier = self.add(1, age=7200)[0]
        path = self.ex.repairs._path(identifier)
        record = json.loads(path.read_text())
        record['parameters'] = []
        from sentinel_blue.state import write_private_json
        write_private_json(path, record)
        result = self.ex.repairs.reconcile()
        self.assertFalse(result['healthy'])
        self.assertTrue(path.exists())

    def test_recent_attempts_still_count_toward_recovery_limit(self):
        self.add(3)
        self.assertTrue(self.ex.repairs.reconcile()['healthy'])
        with self.assertRaisesRegex(ValueError, 'cooldown|limit|attempt|recent|hour'):
            self.ex._service_recovery_preflight(self.fixture.parameters)

    def test_archive_symlink_is_refused_without_removing_evidence(self):
        identifier = self.add(1, age=7200)[0]
        other = self.fixture.root / 'other'
        other.mkdir()
        (self.ex.state_dir / 'service-repair-history').symlink_to(other, target_is_directory=True)
        result = self.ex.repairs.reconcile()
        self.assertFalse(result['healthy'])
        self.assertTrue(self.ex.repairs._path(identifier).exists())
        self.assertFalse(list(other.rglob('*.json')))

    def test_interrupted_archive_copy_is_idempotent(self):
        identifier = self.add(1, age=7200)[0]
        with patch('sentinel_blue.state.remove_private_file', side_effect=OSError('simulated crash boundary')):
            self.assertFalse(self.ex.repairs.reconcile()['healthy'])
        self.assertTrue(self.ex.repairs._path(identifier).exists())
        self.assertTrue(self.ex.repairs._archive_path(identifier).exists())
        self.assertTrue(self.ex.repairs.reconcile()['healthy'])
        self.assertFalse(self.ex.repairs._path(identifier).exists())
        self.assertEqual(self.ex.repairs._read(self.ex.repairs._path(identifier))['transaction_id'], identifier)


    def test_migration_has_bounded_progress_instead_of_permanent_lifetime_failure(self):
        self.add(3, age=7200)
        with patch('sentinel_blue.service_repair_executor.MAX_REPAIR_SCAN', 2):
            results = [self.ex.repairs.reconcile() for _ in range(4)]
        self.assertFalse(results[0]['healthy'])
        self.assertTrue(results[-1]['healthy'], results)
        self.assertEqual(len(list((self.ex.state_dir/'service-repair-history').rglob('*.json'))), 3)

    def test_rollback_interruption_after_archival_is_visible_to_reconciliation(self):
        record = copy.deepcopy(self.template)
        record['created_at'] -= 7200; record['completed_at'] -= 7200
        self.ex.repairs._write(record)
        self.assertTrue(self.ex.repairs.reconcile()['healthy'])
        class Interrupted(BaseException): pass
        with patch.object(self.ex.repairs, '_transition', side_effect=Interrupted()):
            with self.assertRaises(Interrupted):
                self.ex.execute('rollback_service_repair', self.result['pre_state'], self.fixture.current)
        self.assertEqual(self.ex.repairs._read(self.ex.repairs._path(self.identifier))['status'], 'undo_prepared')
        with patch.object(self.ex.repairs, '_transition', side_effect=self.fixture.change_state):
            recovered = self.ex.repairs.reconcile()
        self.assertTrue(recovered['healthy'], recovered)
        self.assertEqual(self.fixture.target.read_bytes(), b'damaged')
        self.assertEqual(self.fixture.native_state, 'stopped')

    def test_conflicting_archive_never_replaces_live_evidence(self):
        identifier = self.add(1, age=7200)[0]
        live = self.ex.repairs._path(identifier)
        record = self.ex.repairs._read(live)
        archive = self.ex.repairs._archive_path(identifier, create=True)
        other = copy.deepcopy(record); other['profile_fingerprint'] = 'f' * 64
        from sentinel_blue.state import write_private_json
        write_private_json(archive, other)
        result = self.ex.repairs.reconcile()
        self.assertFalse(result['healthy'])
        self.assertEqual(self.ex.repairs._read(live), record)
        self.assertEqual(self.ex.repairs._read(archive), other)


class Activation211Tests(unittest.TestCase):
    proxy_options = {'frontend_port': 8080, 'backends': [{'address': '127.0.0.1', 'port': 9000}]}
    share_options = {'share': 'reviewshare', 'path': '/srv/reviewshare', 'valid_users': ['reviewuser']}

    def spec(self, sid, options):
        generated, extra = packs.BUILDERS[sid](options)
        return {**extra, 'service_id': sid, 'generated': list(generated)}, generated

    def command(self, argv, *, inputs='/etc/haproxy/haproxy.cfg', environment='', envfiles='', raw=None):
        if argv[0].endswith('systemctl'):
            prop = next(v for v in argv if v.startswith('--property=')).split('=', 1)[1]
            return {'ExecStart': raw or '{ path=/usr/sbin/haproxy ; argv[]=/usr/sbin/haproxy -Ws -f '+inputs+' -p /run/haproxy.pid ; ignore_errors=no ; start_time=[n/a] ; }',
                    'Environment': environment, 'EnvironmentFiles': envfiles,
                    'RootDirectory': '', 'RootImage': '', 'UnsetEnvironment': ''}[prop]
        self.assertEqual(argv[0], '/usr/sbin/haproxy')
        self.assertEqual(argv[1], '-c')
        return 'Configuration file is valid\n'

    def test_haproxy_inactive_snippet_rejected(self):
        spec, _ = self.spec('haproxy', self.proxy_options)
        with patch.object(checks, '_command', side_effect=self.command):
            with self.assertRaisesRegex(ValueError, 'does not load'):
                checks.run_checks(spec, 'configuration')

    def test_haproxy_explicit_snippet_input_accepted_and_tested(self):
        spec, generated = self.spec('haproxy', self.proxy_options)
        path = spec['generated'][0]
        with patch.object(checks, '_command', side_effect=lambda argv: self.command(argv, inputs=path)) as cmd, \
                patch.object(checks, '_read', return_value=generated[path].encode()):
            checks.run_checks(spec, 'configuration')
        self.assertEqual(cmd.call_args.args[0], ['/usr/sbin/haproxy', '-c', '-f', path])

    def test_haproxy_main_merge_preserves_existing_and_is_idempotent(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            text = 'global\n    maxconn 100\ndefaults\n    mode http\n    timeout connect 5s\n    timeout client 30s\n    timeout server 30s\n'
            file = root / 'main.cfg'
            file.write_text(text)
            def compile_text():
                options = {**self.proxy_options, 'main_config': {'path': 'main.cfg', 'sha256': hashlib.sha256(file.read_bytes()).hexdigest()}}
                metadata = {}
                with patch.object(packs, '_linux_service') as compiler:
                    packs.build('haproxy', options, root, metadata=metadata)
                generated = compiler.call_args.kwargs['generated_sources']
                return generated, metadata
            generated, metadata = compile_text()
            self.assertEqual(list(generated), ['/etc/haproxy/haproxy.cfg'])
            output = generated['/etc/haproxy/haproxy.cfg']
            self.assertTrue(output.startswith(text))
            self.assertIn('# BEGIN SENTINEL HAPROXY', output)
            self.assertEqual(metadata['files'][0]['previous_sha256'], hashlib.sha256(text.encode()).hexdigest())
            file.write_text(output)
            repeated, _ = compile_text()
            self.assertEqual(repeated, generated)
            spec = {**metadata, 'service_id': 'haproxy', 'generated': list(generated)}
            with patch.object(checks, '_command', side_effect=self.command), patch.object(checks, '_read', return_value=output.encode()):
                checks.run_checks(spec, 'configuration')

    def test_haproxy_merge_rejects_unowned_conflicting_names(self):
        with tempfile.TemporaryDirectory() as td:
            file = Path(td) / 'main.cfg'
            file.write_text('frontend sentinel_front\n    bind *:99\n')
            options = {**self.proxy_options, 'main_config': {'path': file.name, 'sha256': hashlib.sha256(file.read_bytes()).hexdigest()}}
            with self.assertRaisesRegex(ValueError, 'outside'):
                packs.build('haproxy', options, Path(td))

    def test_haproxy_environment_expansion_uses_recorded_config(self):
        spec, generated = self.spec('haproxy', self.proxy_options)
        path = spec['generated'][0]
        raw = '{ path=/usr/sbin/haproxy ; argv[]=/usr/sbin/haproxy -Ws -f $CONFIG $EXTRAOPTS ; ignore_errors=no ; }'
        def cmd(argv):
            return self.command(argv, raw=raw, environment=f'CONFIG={path} "EXTRAOPTS=-S /run/haproxy.sock"')
        with patch.object(checks, '_command', side_effect=cmd), patch.object(checks, '_read', return_value=generated[path].encode()):
            checks.run_checks(spec, 'configuration')

    def test_haproxy_unsupported_wrapper_is_refused(self):
        spec, _ = self.spec('haproxy', self.proxy_options)
        with patch.object(checks, '_command', return_value='{ path=/bin/sh ; argv[]=/bin/sh wrapper ; ignore_errors=no ; }'):
            with self.assertRaisesRegex(ValueError, 'wrappers'):
                checks.run_checks(spec, 'configuration')

    def test_haproxy_loaded_but_wrong_content_is_refused(self):
        spec, _ = self.spec('haproxy', self.proxy_options)
        with patch.object(checks, '_command', side_effect=lambda argv: self.command(argv, inputs=spec['generated'][0])), \
                patch.object(checks, '_read', return_value=b'frontend unrelated\n'):
            with self.assertRaisesRegex(ValueError, 'reviewed frontend'):
                checks.run_checks(spec, 'configuration')

    def samba_dump(self, *, extra='', change=None):
        values = {'path': '/srv/reviewshare', 'valid users': 'reviewuser', 'read only': 'Yes',
                  'browseable': 'Yes', 'guest ok': 'No', 'create mask': '0644', 'directory mask': '0755'}
        values.update(change or {})
        return 'Load smb config files from /etc/samba/smb.conf\nLoaded services file OK.\n[global]\n    smb ports = 445 139\n[reviewshare]\n' + ''.join(f'    {k} = {v}\n' for k,v in values.items()) + extra

    def samba_command(self, output, argv, config=None):
        if argv[0].endswith('systemctl'):
            prop = next(v for v in argv if v.startswith('--property=')).split('=',1)[1]
            if prop == 'ExecStart':
                suffix = ' --configfile=' + config if config else ''
                return '{ path=/usr/sbin/smbd ; argv[]=/usr/sbin/smbd --foreground' + suffix + ' ; ignore_errors=no ; }'
            return ''
        self.assertEqual(argv[0], '/usr/bin/testparm')
        return output

    def test_samba_missing_share_rejected_even_when_ports_match(self):
        spec, _ = self.spec('samba', {**self.share_options, 'smb_port': 445})
        with patch.object(checks, '_command', side_effect=lambda argv: self.samba_command('[global]\nsmb ports = 445 139\n', argv)):
            with self.assertRaisesRegex(ValueError, 'requested share'):
                checks.run_checks(spec, 'configuration')

    def test_samba_effective_share_and_access_settings_accepted(self):
        spec, _ = self.spec('samba', {**self.share_options, 'smb_port': 445})
        with patch.object(checks, '_command', side_effect=lambda argv: self.samba_command(self.samba_dump(), argv)):
            checks.run_checks(spec, 'configuration')

    def test_samba_wrong_path_user_readonly_guest_and_masks_rejected(self):
        spec, _ = self.spec('samba', self.share_options)
        for changed in ({'path': '/srv/other'}, {'valid users': 'everybody'}, {'read only': 'No'},
                        {'guest ok': 'Yes'}, {'create mask': '0777'}, {'directory mask': '0777'}):
            with self.subTest(changed=changed), patch.object(checks, '_command', side_effect=lambda argv: self.samba_command(self.samba_dump(change=changed), argv)):
                with self.assertRaisesRegex(ValueError, 'differs'):
                    checks.run_checks(spec, 'configuration')

    def test_samba_activation_is_offered_without_explicit_ports(self):
        spec, _ = self.spec('samba', self.share_options)
        self.assertIn('/etc/samba/smb.conf', spec['activation_lines'])

    def test_samba_reviewed_include_appends_global_context_and_pins_parent(self):
        with tempfile.TemporaryDirectory() as td:
            file = Path(td) / 'smb.conf'
            original = '[global]\n    workgroup = WORKGROUP\n[other]\n    path = /srv/other\n'
            file.write_text(original)
            digest = hashlib.sha256(file.read_bytes()).hexdigest()
            opts = {**self.share_options, 'activation': {'/etc/samba/smb.conf': {'path': file.name, 'sha256': digest}}}
            metadata = {}
            with patch.object(packs, '_linux_service') as compiler:
                packs.build('samba', opts, Path(td), metadata=metadata)
            generated = compiler.call_args.kwargs['generated_sources']
            self.assertEqual(generated['/etc/samba/smb.conf'], original + '[global]\ninclude = /etc/samba/conf.d/sentinel-reviewshare.conf\n')
            parent = next(f for f in metadata['files'] if f['path'] == '/etc/samba/smb.conf')
            self.assertEqual(parent['previous_sha256'], digest)


    def test_samba_validation_follows_explicit_launch_config(self):
        spec, _ = self.spec('samba', self.share_options)
        with patch.object(checks, '_command', side_effect=lambda argv: self.samba_command(self.samba_dump(), argv, '/etc/samba/custom.conf')) as cmd:
            checks.run_checks(spec, 'configuration')
        self.assertEqual(cmd.call_args.args[0][-1], '/etc/samba/custom.conf')

    def test_haproxy_conditional_generated_block_refused(self):
        spec, generated = self.spec('haproxy', self.proxy_options)
        path = spec['generated'][0]
        with patch.object(checks, '_command', side_effect=lambda argv: self.command(argv, inputs=path)), \
                patch.object(checks, '_read', return_value=('.if 0\n' + generated[path] + '.endif\n').encode()):
            with self.assertRaisesRegex(ValueError, 'conditional'):
                checks.run_checks(spec, 'configuration')

    def test_haproxy_alternate_root_is_not_mistaken_for_host_filesystem(self):
        spec, _ = self.spec('haproxy', self.proxy_options)
        def command(argv):
            return '/srv/jail' if '--property=RootDirectory' in argv else self.command(argv)
        with patch.object(checks, '_command', side_effect=command):
            with self.assertRaisesRegex(ValueError, 'root/environment'):
                checks.run_checks(spec, 'configuration')


@unittest.skipUnless(os.environ.get('DISPLAY'), 'Tk form requires a display')
class DovecotForm211Tests(unittest.TestCase):
    def save(self, original, protocols, clear_tls=False):
        import tkinter as tk
        from tkinter import ttk
        from sentinel_blue.linux_service_forms import ServiceForm
        root = tk.Tk(); root.withdraw()
        try:
            with tempfile.TemporaryDirectory() as td:
                panel = SimpleNamespace(tk=tk, ttk=ttk, tree=root, options={'dovecot': copy.deepcopy(original)},
                                        options_root=Path(td), port_requirements={}, selection=[], refresh=lambda: None)
                form = ServiceForm(panel, 'dovecot')
                form.inputs['protocols'].delete('1.0', 'end')
                form.inputs['protocols'].insert('1.0', '\n'.join(protocols))
                if clear_tls:
                    form.inputs['ssl_certificate_path'].set('');form.inputs['ssl_key_path'].set('')
                form.save()
                return bool(panel.selection), panel.options['dovecot'], form.error.get()
        finally:
            root.destroy()

    def test_imap_to_pop3_removes_hidden_imap_port(self):
        ok, options, error = self.save({'protocols': ['imap'], 'imap_port': 1143}, ['pop3'])
        self.assertTrue(ok, error);self.assertNotIn('imap_port', options);self.assertEqual(options['pop3_port'], 110)

    def test_remove_tls_retains_custom_plain_port_only(self):
        ok, options, error = self.save({'protocols': ['imap'], 'imap_port': 1143, 'imaps_port': 1993,
                                      'ssl_certificate_path': '/c', 'ssl_key_path': '/k'}, ['imap'], True)
        self.assertTrue(ok, error);self.assertEqual(options['imap_port'], 1143);self.assertNotIn('imaps_port', options)

    def test_kept_listeners_keep_custom_ports(self):
        original = {'protocols': ['imap', 'pop3'], 'imap_port': 1143, 'pop3_port': 1110, 'imaps_port': 1993,
                    'pop3s_port': 1995, 'ssl_certificate_path': '/c', 'ssl_key_path': '/k'}
        ok, options, error = self.save(original, ['imap'])
        self.assertTrue(ok, error);self.assertEqual(options['imap_port'], 1143);self.assertEqual(options['imaps_port'], 1993)
        self.assertNotIn('pop3_port', options);self.assertNotIn('pop3s_port', options)

    def test_invalid_protocol_still_refused_and_original_saved_options_preserved(self):
        original = {'protocols': ['imap'], 'imap_port': 1143}
        ok, options, error = self.save(original, ['nonsense'])
        self.assertFalse(ok);self.assertEqual(options, original);self.assertTrue(error)


class Gunicorn211Tests(unittest.TestCase):
    def bind(self, address):
        generated, _ = packs._gunicorn({'application': 'app:application', 'working_directory': '/srv/app',
                                        'user': 'reviewuser', 'bind_address': address, 'port': 8000})
        value = next(iter(generated.values()))
        argv = shlex.split(next(x.split('=',1)[1] for x in value.splitlines() if x.startswith('ExecStart=')))
        return argv[argv.index('--bind') + 1]

    def test_ipv4_format_unchanged(self):
        self.assertEqual(self.bind('127.0.0.1'), '127.0.0.1:8000')

    def test_ipv6_loopback_wildcard_and_compressed_are_bracketed(self):
        for address in ('::1', '::', '2001:db8::1', '::ffff:192.0.2.1'):
            with self.subTest(address=address):
                self.assertEqual(self.bind(address), f'[{address}]:8000')

    def test_invalid_address_still_refused(self):
        with self.assertRaises(ValueError): self.bind('::1;touch /tmp/forbidden')
