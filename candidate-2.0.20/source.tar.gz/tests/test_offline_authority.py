import copy
import json
import os
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import Mock, patch

from sentinel_blue.controller import ControllerApp
from sentinel_blue.offline_continuity import AgentContinuity, ControllerContinuity, read_state
from sentinel_blue.store import Store
from sentinel_blue.state import ActionJournal
from sentinel_blue.mutation_ledger import MutationLedger
from test_autonomous_service_recovery import fixtures, stopped
from test_store_controller import _promote_integrity_baseline


class OfflineAuthorityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.root.chmod(0o700)
        self.profile, self.baseline = fixtures()
        from sentinel_blue.event_profile import EventProfile
        raw = copy.deepcopy(self.profile.raw)
        raw['release']['sha256'] = 'a' * 64
        raw['scope']['controller_ingress_hosts'] = ['127.0.0.1']
        raw['scope']['authorized_hosts'] = ['127.0.0.1', '192.0.2.10']
        raw['scope']['authorized_networks'] = [*raw['scope']['authorized_networks'], '127.0.0.1/32']
        raw['official_identities'] = [{'agent_id': 'agent-one', 'name': 'root', 'class': 'blue-admin'}]
        self.profile = EventProfile.from_dict(raw)
        self.store = Store(self.root / 'controller.db')
        self.addCleanup(self.store.close)
        self.app = ControllerApp(self.store, 't'*32, operator_token='o'*32,
                                 event_profile=self.profile, auto_recover_services=True)
        from sentinel_blue import __version__
        self.baseline.update(queued_at=time.time(), agent_version=__version__, profile_id=self.profile.profile_id,
                             profile_fingerprint=self.profile.fingerprint)
        from sentinel_blue.auth import derive_enrollment_ticket
        self.app.enroll({'agent_id': 'agent-one', 'hostname': 'host', 'platform': 'Linux',
                         'agent_version': __version__, 'profile_id': self.profile.profile_id,
                         'profile_fingerprint': self.profile.fingerprint, 'enrollment_nonce': 'c'*64},
                        authenticated_ticket=derive_enrollment_ticket('t'*32, self.profile.fingerprint, 'agent-one'))
        self.app.set_autonomy_mode(self.profile.autonomy_mode)
        self.app.resume_changes()
        self.app.ingest(self.baseline, "agent-one", self.store.agent_secret("agent-one"))
        from test_store_controller import _dispatch_baseline_capture, _capture_result
        from sentinel_blue.validation import canonical_action_envelope_sha256
        from dataclasses import asdict
        _, capture = _dispatch_baseline_capture(self.app, 'agent-one')
        result = _capture_result(capture)
        result['action_envelope_sha256'] = canonical_action_envelope_sha256(asdict(capture))
        assert self.app.complete_action(result, 'agent-one') == 'new'
        self.store.initialize_recovery_identity()
        self.token = self.store.ensure_agent_secret('agent-one')
        self.app.continuity = ControllerContinuity(self.app)
        self.ledger = MutationLedger(self.root / 'ledger')
        self.agent = AgentContinuity(self.root, self.profile, 'agent-one', self.token, ledger=self.ledger)
        self.journal = ActionJournal(self.root, profile_fingerprint=self.profile.fingerprint)
        self.client = Mock()
        self.client._request.side_effect = lambda method, path, body: self.app.continuity.sync('agent-one', body)
        self.agent.sync(self.client, self.journal)
        self.agent.sync(self.client, self.journal)
        self.health = {'action_safe': True, 'critical_errors': []}
        self.executor = Mock()
        self.executor.allow_service_recovery = True
        self.executor.state_dir = self.root / "native-state"
        self.executor.state_dir.mkdir(mode=0o700)
        self.calls = 0
        def execute(kind, parameters, telemetry):
            self.calls += 1
            native = {'state': 'stopped'}
            def change():
                native['state'] = 'running'
                from sentinel_blue.journaled_recovery import START_JOURNAL, start_plan
                from sentinel_blue.service_repair import plan_digest
                import uuid
                identifier = str(uuid.uuid4())
                return {'success': True, 'message': 'simulated native service repair',
                        'pre_state': {'service': 'web.service', 'desired_state': 'stopped',
                                      'transaction_id': identifier, 'journal_kind': START_JOURNAL},
                        'record': {'transaction_id': identifier, 'journal_kind': START_JOURNAL,
                                   'origin_action': 'restart_service', 'plan_sha256': plan_digest(start_plan(parameters)),
                                   'files': copy.deepcopy(parameters['recovery_guard']['files'])},
                        'stable_health': True, 'probe_attempts': 3,
                        'probes': [{'name': 'web-health', 'target': parameters['probes'][0]['target'], 'healthy': True}]}
            return self.ledger.mutate('test-service', {'service': 'web.service'}, change,
                                     snapshot=lambda target: dict(native))
        self.executor.execute.side_effect = execute
        self.active = patch('sentinel_blue.mutation_tracking.active', return_value=True)
        self.active.start()
        self.addCleanup(self.active.stop)

    def authorize(self, maximum=3):
        result = self.app.continuity.authorize({'agent_id': 'agent-one', 'services': ['web.service'],
                                               'duration_seconds': 900, 'max_attempts': maximum, 'cooldown_seconds': 300})
        self.agent.sync(self.client, self.journal)
        return result

    def outage(self):
        self.agent.online = False
        self.agent.state['lease_until'] = 0
        self.agent._save()

    def step(self, sequence=2, changed=None):
        telemetry = stopped(self.baseline, sequence)
        if changed:
            changed(telemetry)
        return self.agent.run_offline(self.journal, self.executor, telemetry, self.health)

    def repair(self):
        self.outage()
        self.assertEqual(self.step(2), 0)
        self.assertEqual(self.step(3), 1, self.agent.status)

    def test_no_policy_means_monitoring_only(self):
        self.outage()
        self.step(2)
        self.step(3)
        self.assertEqual(self.calls, 0)
        self.assertIn('no pre-authorized', self.agent.status)

    def test_lease_prevents_overlap_before_expiry(self):
        self.authorize()
        self.agent.online = False
        self.step(2)
        self.step(3)
        self.assertEqual(self.calls, 0)
        self.assertIn('lease expiry', self.agent.status)

    def test_explicit_service_repair_uses_ledger_and_reconciles_before_dispatch(self):
        self.authorize()
        self.repair()
        self.assertEqual(len(self.ledger.actions()), 1)
        self.assertEqual(self.ledger.actions()[0]['status'], 'committed')
        self.agent.sync(self.client, self.journal)
        self.assertTrue(self.agent.online)
        self.assertTrue(self.app.continuity.ready('agent-one'))
        rows = self.store._connection.execute("SELECT status,result_source FROM actions WHERE result_source='agent-offline'").fetchall()
        self.assertEqual([(r[0], r[1]) for r in rows], [('completed', 'agent-offline')])
        self.assertFalse(self.store.service_recovery_budget_status('agent-one', 'web.service')['allowed'])

    def test_reboot_reconnect_and_repeated_journal_do_not_repair_twice(self):
        self.authorize(maximum=1)
        self.repair()
        self.agent = AgentContinuity(self.root, self.profile, 'agent-one', self.token, ledger=self.ledger)
        self.step(4)
        self.assertIn('budget exhausted', self.agent.status)
        self.agent.sync(self.client, self.journal)
        self.agent.state['ack'] = {'sequence': 0, 'hash': '0'*64}
        self.agent.sync(self.client, self.journal)
        self.assertEqual(self.calls, 1)
        self.assertEqual(self.store._connection.execute("SELECT COUNT(*) FROM actions WHERE result_source='agent-offline'").fetchone()[0], 1)

    def test_expired_policy_held(self):
        self.authorize()
        self.outage()
        with patch('sentinel_blue.offline_continuity.verify_policy', side_effect=ValueError('expired offline authority')):
            self.step(2)
        self.assertIn('expired', self.agent.status)
        self.assertEqual(self.calls, 0)

    def test_cooldown_is_durable(self):
        self.authorize()
        self.repair()
        self.agent = AgentContinuity(self.root, self.profile, 'agent-one', self.token, ledger=self.ledger)
        self.step(4)
        self.assertIn('cooldown', self.agent.status)
        self.assertEqual(self.calls, 1)

    def test_unknown_execution_is_never_replayed_and_holds_reconnect(self):
        self.authorize()
        self.outage()
        self.executor.execute.side_effect = RuntimeError('interrupted native operation')
        self.step(2)
        self.step(3)
        self.assertIn('interrupted', self.agent.status)
        self.step(4)
        self.assertIn('Unknown offline outcome', self.agent.status)
        self.assertEqual(self.executor.execute.call_count, 1)
        self.agent.sync(self.client, self.journal)
        self.assertFalse(self.agent.online)
        self.assertFalse(self.app.continuity.ready('agent-one'))
        self.assertIn('unknown', self.app.continuity._row('agent-one')['held'])

    def test_pause_while_controller_unreachable_overrides_policy(self):
        self.authorize()
        self.outage()
        self.ledger.append('continuity_pause', reason='independent operator management path')
        self.step(2)
        self.step(3)
        self.assertEqual(self.calls, 0)
        self.assertIn('Pause', self.agent.status)

    def test_withdrawal_while_controller_unreachable_overrides_policy(self):
        self.authorize()
        self.outage()
        self.ledger.pause('network-withdraw')
        self.step(2)
        self.assertEqual(self.calls, 0)
        self.assertIn('Withdraw', self.agent.status)

    def test_new_epoch_fences_old_controller_even_after_agent_restart(self):
        old = self.app.continuity
        self.authorize()
        self.app.continuity = ControllerContinuity(self.app)
        self.assertFalse(self.app.continuity.ready('agent-one'))
        self.agent.sync(self.client, self.journal)
        self.agent.sync(self.client, self.journal)
        self.agent = AgentContinuity(self.root, self.profile, 'agent-one', self.token, ledger=self.ledger)
        self.client._request.side_effect = lambda m,p,b: old.sync('agent-one', b)
        with self.assertRaisesRegex(ValueError, 'Stale'):
            self.agent.sync(self.client, self.journal)
        with self.assertRaises(ValueError):
            self.agent.accept_online(old.authority)

    def test_same_epoch_different_process_identity_is_rejected(self):
        saved = copy.deepcopy(self.app.continuity.authority)
        import uuid
        self.app.continuity.authority = {**saved, 'holder': str(uuid.uuid4())}
        with self.assertRaisesRegex(ValueError, 'competing'):
            self.agent.sync(self.client, self.journal)

    def test_unapproved_baseline_and_unsupported_action_contract_rejected(self):
        self.store._connection.execute("UPDATE baselines SET status='pending'")
        self.store._connection.commit()
        with self.assertRaisesRegex(ValueError, 'approved'):
            self.authorize()
        self.assertEqual(self.calls, 0)

    def test_changed_required_file_and_ambiguous_service_held(self):
        self.authorize()
        self.outage()
        self.step(2, lambda x: x['integrity'][0].update(sha256='b'*64))
        self.step(3, lambda x: x['services'].append(copy.deepcopy(x['services'][0])))
        self.assertEqual(self.calls, 0)

    def test_clock_reversal_revokes_authority_and_tampered_agent_state_rejected(self):
        # 2.0.16: a clock step no longer stops online work until the agent
        # restarts. It revokes the offline policy and lease, and the same sync
        # re-establishes them from the controller (whose clock must agree).
        self.authorize()
        self.agent.state['last_clock'] = time.time()+100
        revoked = []
        original = self.agent._save
        self.agent._save = lambda: (revoked.append(copy.deepcopy(self.agent.state)), original())[1]
        self.agent.sync(self.client, self.journal)
        self.assertIsNone(revoked[0]['policy'])
        self.assertEqual(revoked[0]['lease_until'], 0)
        self.assertTrue(self.agent.online)
        self.assertIsNotNone(self.agent.state['policy'])
        self.agent.accept_online(self.agent.state['authority'])
        self.agent.path.write_text('{}')
        with self.assertRaises(ValueError):
            AgentContinuity(self.root, self.profile, 'agent-one', self.token, ledger=self.ledger)

    def test_clock_step_while_offline_revokes_policy_until_fresh_sync(self):
        self.authorize()
        self.outage()
        self.agent._wall -= 60  # the wall clock moved 60 s more than monotonic time
        with self.assertRaisesRegex(ValueError, 'Clock discontinuity'):
            self.step(2)
        self.assertIsNone(self.agent.state['policy'])
        self.assertIsNone(AgentContinuity(self.root, self.profile, 'agent-one', self.token,
                                          ledger=self.ledger).state['policy'])
        self.assertEqual(self.step(3), 0)
        self.assertEqual(self.step(4), 0)
        self.assertIn('no pre-authorized', self.agent.status)
        self.assertEqual(self.calls, 0)
        # A restart does not resurrect the revoked policy.
        self.agent = AgentContinuity(self.root, self.profile, 'agent-one', self.token, ledger=self.ledger)
        self.assertEqual(self.step(5), 0)
        self.assertEqual(self.calls, 0)
        # One fresh controller sync restores online work and the signed policy.
        self.agent.sync(self.client, self.journal)
        self.assertTrue(self.agent.online)
        self.assertIsNotNone(self.agent.state['policy'])

    def test_backward_clock_step_cannot_extend_offline_authority(self):
        self.authorize()
        self.outage()
        policy_expiry = self.agent.state['policy']['signed']['expires_at']
        future = policy_expiry + 60
        with patch('sentinel_blue.offline_continuity.time.time', return_value=future):
            self.agent._wall = future - (time.monotonic() - self.agent._monotonic)
            self.agent.state['last_clock'] = future
            self.assertEqual(self.step(2), 0)
        self.assertIn('expired', self.agent.status)
        # Setting the clock back inside the old window revokes, never revives.
        with self.assertRaisesRegex(ValueError, 'Clock discontinuity'):
            self.step(3)
        self.assertIsNone(self.agent.state['policy'])
        self.assertEqual(self.step(4), 0)
        self.assertEqual(self.step(5), 0)
        self.assertEqual(self.calls, 0)

    def test_clock_step_between_sync_and_fetch_refuses_only_that_fetch(self):
        self.authorize()
        self.agent.sync(self.client, self.journal)
        self.agent._wall -= 30
        with self.assertRaisesRegex(ValueError, 'lease'):
            self.agent.accept_online(self.agent.state['authority'])
        self.agent.sync(self.client, self.journal)
        self.agent.accept_online(self.agent.state['authority'])

    def test_journal_tamper_is_rejected(self):
        self.authorize()
        self.repair()
        path = self.agent.journal.events_path
        data = path.read_bytes()
        path.write_bytes(data[:-1])
        with self.assertRaises(RuntimeError):
            self.agent.sync(self.client, self.journal)
