"""Execution-time probe evidence: unknown is neither an outage nor success.

Uses actual temporary files and bounded loopback/thread fixtures. Native service
control is explicitly mocked; these tests do not accept systemd or any product.
"""
import copy
import hashlib
import http.server
import socket
import tempfile
import threading
import time
import unittest
from dataclasses import asdict
from pathlib import Path
from unittest.mock import patch

from sentinel_blue import probes, native_probes
from sentinel_blue.actions import ActionExecutor
from sentinel_blue.controller import ControllerApp
from sentinel_blue.probe_evidence import probe_verdict, matching_probe_health, all_probes_healthy
from sentinel_blue.protocol import ProbeResult
from sentinel_blue.request_deadline import BoundedRequestPool, RequestCapacityUnavailable
from sentinel_blue.service_recovery import check_recovery_observation
from sentinel_blue.service_repair import repair_parameters
from sentinel_blue.store import Store, _require_success_result_contract
from test_service_repair import repair_fixture
from test_store_controller import _promote_integrity_baseline

SPEC = {'kind': 'tcp', 'name': 'health', 'target': '127.0.0.1', 'port': 12345}


def row(healthy=True, executed=True, *, name='health', target='127.0.0.1'):
    return ProbeResult(name, target, healthy, executed=executed)


class ProbeEvidenceTests(unittest.TestCase):
    def test_measured_success_and_failure(self):
        self.assertIs(probe_verdict(row()), True)
        self.assertIs(probe_verdict(row(False)), False)

    def test_unattempted_failure_is_not_down(self):
        self.assertIsNone(probe_verdict(row(False, False)))

    def test_unattempted_success_is_not_healthy(self):
        self.assertIsNone(probe_verdict(row(True, False)))

    def test_legacy_omitted_executed_is_compatible(self):
        self.assertIs(probe_verdict({'healthy': True}), True)
        self.assertIs(probe_verdict({'healthy': False}), False)

    def test_invalid_health_types_are_unknown(self):
        for bad in (None, 0, 1, 'true', 'false', [], {}):
            with self.subTest(value=bad):
                self.assertIsNone(probe_verdict({'healthy': bad, 'executed': True}))

    def test_invalid_executed_types_are_unknown(self):
        for bad in (None, 0, 1, 'true', 'false', [], {}):
            with self.subTest(value=bad):
                self.assertIsNone(probe_verdict({'healthy': True, 'executed': bad}))

    def test_non_records_are_unknown(self):
        for bad in (None, [], 'healthy', 1, object()):
            self.assertIsNone(probe_verdict(bad))

    def test_wire_and_native_rows_agree(self):
        for healthy in (True, False):
            for executed in (True, False):
                item = row(healthy, executed)
                self.assertIs(probe_verdict(item), probe_verdict(asdict(item)))

    def test_exact_batch_rejects_missing_or_extra(self):
        for batch in ([], [row(), row(name='extra')]):
            self.assertFalse(all_probes_healthy([SPEC], batch))

    def test_exact_batch_rejects_wrong_identity(self):
        for batch in ([row(name='other')], [row(target='192.0.2.1')]):
            self.assertFalse(all_probes_healthy([SPEC], batch))

    def test_duplicate_results_cannot_stand_in_for_other_probe(self):
        other = dict(SPEC, name='other')
        self.assertFalse(all_probes_healthy([SPEC, other], [row(), row()]))

    def test_invalid_result_identity_is_unknown(self):
        for bad in ({'name': [], 'target': '127.0.0.1', 'healthy': True}, None):
            self.assertEqual(matching_probe_health([SPEC], [bad], exact=True), [None])

    def test_completion_order_does_not_matter(self):
        other = dict(SPEC, name='other')
        self.assertTrue(all_probes_healthy([SPEC, other], [row(name='other'), row()]))

    def test_telemetry_can_contain_unrelated_rows(self):
        self.assertEqual(matching_probe_health([SPEC], [None, row(name='other'), row()]), [True])

    def test_telemetry_duplicate_is_unknown(self):
        self.assertEqual(matching_probe_health([SPEC], [row(), row()]), [None])

    def test_duplicate_declarations_are_not_distinct_evidence(self):
        self.assertFalse(all_probes_healthy([SPEC, SPEC], [row(), row()]))

    def test_probe_name_defaults_to_target_in_spec(self):
        # 2.0.6: with its port when the port is a separate field, so two
        # unnamed TCP checks of one address are two names (see
        # test_live_findings_206.TwoChecksOfOneAddressAreToldApart).
        spec = dict(SPEC); del spec['name']
        self.assertTrue(all_probes_healthy([spec], [row(name=spec['target'] + ':12345')]))
        self.assertFalse(all_probes_healthy([spec], [row(name=spec['target'])]))
        url = {'kind': 'http', 'target': 'http://127.0.0.1:8080/'}
        self.assertTrue(all_probes_healthy([url], [row(name=url['target'], target=url['target'])]))

    def test_bad_batch_or_budget_is_unknown(self):
        for bad in (None, {}, 'ok', [row()] * 1025):
            self.assertEqual(matching_probe_health([SPEC], bad), [None])
        specs = [dict(SPEC, name=str(n)) for n in range(257)]
        self.assertEqual(matching_probe_health(specs, []), [None] * 257)

    def test_an_empty_contract_proves_nothing_unless_the_caller_says_so(self):
        """No declared transaction is no evidence, so the default answer is no.

        With nothing declared there is nothing to fail, and a caller reading the
        result as health would be claiming something never measured. A caller for
        which "nothing declared" genuinely means "nothing to check" asks for that
        explicitly instead of relying on the subtlety.
        """
        self.assertFalse(all_probes_healthy([], []))
        self.assertTrue(all_probes_healthy([], [], allow_empty=True))
        # Even then, results arriving for an undeclared contract are wrong.
        self.assertFalse(all_probes_healthy([], [row()], allow_empty=True))
        self.assertFalse(all_probes_healthy([], [row()]))
        self.assertFalse(all_probes_healthy([], None))
        # A malformed contract is never a pass, however it is asked for.
        for bad in (None, {}, "ok", 7):
            self.assertFalse(all_probes_healthy(bad, []))
            self.assertFalse(all_probes_healthy(bad, [], allow_empty=True))

    def test_wrong_spec_identity_is_unknown(self):
        self.assertEqual(matching_probe_health([dict(SPEC, name=[])], [row()]), [None])


class RequestCapacityTests(unittest.TestCase):
    def occupy(self):
        release, entered = threading.Event(), threading.Event()
        pool = BoundedRequestPool(1, label='test probe', thread_name='test-1989-probe')
        def operation(budget):
            entered.set(); release.wait(4)
        def occupy_worker():
            try:
                pool.run(operation, 0.2)
            except Exception:
                pass
        thread = threading.Thread(target=occupy_worker)
        thread.start()
        self.addCleanup(thread.join, 5)
        self.addCleanup(release.set)
        self.assertTrue(entered.wait(2), 'the test must actually occupy the pool')
        return pool, release, thread

    def test_saturation_raises_typed_nonadmission(self):
        pool, _, _ = self.occupy()
        called = []
        with self.assertRaises(RequestCapacityUnavailable):
            pool.run(lambda budget: called.append(True), 1)
        self.assertEqual(called, [])

    def test_saturated_check_is_explicitly_unexecuted(self):
        pool, _, _ = self.occupy()
        with patch.object(probes, '_PROBE_REQUESTS', pool), patch.object(probes, '_execute_probe') as execute:
            result = probes.run_probe(SPEC, ['127.0.0.0/8'])
        execute.assert_not_called()
        self.assertFalse(result.executed)
        self.assertIsNone(probe_verdict(result))
        self.assertIn('capacity exhausted', result.detail)

    def test_genuine_connection_refusal_remains_measured_failure(self):
        with socket.socket() as reserved:
            reserved.bind(('127.0.0.1', 0))
            spec = dict(SPEC, port=reserved.getsockname()[1], timeout=1)
            result = probes.run_probe(spec, ['127.0.0.0/8'])
        self.assertTrue(result.executed)
        self.assertIs(probe_verdict(result), False)

    def test_healthy_http_recovers_after_local_pool_is_released(self):
        requests = []
        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                requests.append(self.path)
                self.send_response(200); self.end_headers(); self.wfile.write(b'fixture healthy')
            def log_message(self, *args):
                pass
        server = http.server.HTTPServer(('127.0.0.1', 0), Handler)
        thread = threading.Thread(target=server.serve_forever, kwargs={'poll_interval': 0.02}, daemon=True)
        thread.start()
        try:
            pool, release, occupied = self.occupy()
            spec = {'kind': 'http', 'name': 'web', 'target': f'http://127.0.0.1:{server.server_port}/health', 'timeout': 1}
            with patch.object(probes, '_PROBE_REQUESTS', pool):
                missing = probes.run_probe(spec, ['127.0.0.0/8'])
                self.assertIsNone(probe_verdict(missing))
                self.assertEqual(requests, [], 'no check was admitted')
                release.set(); occupied.join(5)
                healthy = probes.run_probe(spec, ['127.0.0.0/8'])
            self.assertIs(probe_verdict(healthy), True)
            self.assertEqual(requests, ['/health'])
        finally:
            server.shutdown(); server.server_close(); thread.join(3)


class RepairAdmissionTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.target = self.root/'web.conf'; self.target.write_bytes(b'trusted')
        self.profile, self.baseline = repair_fixture(str(self.target))
        self.current = copy.deepcopy(self.baseline)
        self.current.update(sequence=2, observed_at=time.time()-1)
        self.current['probes'][0]['healthy'] = False
        self.params = repair_parameters(self.profile, 'agent-one', 'web.service', self.baseline, self.current)
        self.ex = ActionExecutor(self.root/'state', allow_service_recovery=True, allow_restoration=True,
                                 authorized_networks=['127.0.0.0/8'])
        self.native_state = 'running'; self.transitions = []
        def transition(service, state):
            self.transitions.append(state); self.native_state = state
        for p in (patch.object(self.ex, '_service_state', side_effect=lambda _: self.native_state),
                  patch.object(self.ex, '_set_service_state', side_effect=transition)):
            p.start(); self.addCleanup(p.stop)
        self.spec = self.params['probes'][0]

    def result(self, healthy=False, executed=True, **kw):
        return ProbeResult(self.spec['name'], self.spec['target'], healthy, executed=executed, **kw)

    def execute_with(self, result):
        final = [self.result(True)]
        with patch.object(self.ex.repairs, '_probe', return_value=result), patch.object(
                self.ex, '_wait_for_service_probes', return_value=(final, 3, True)):
            return self.ex.execute('repair_service', self.params, self.current)

    def assert_no_mutation(self, result):
        self.assertFalse(result['success'], result)
        self.assertEqual(self.transitions, [], result)
        self.assertEqual(self.target.read_bytes(), b'trusted')
        self.assertFalse(list(self.ex.state_dir.glob('service-repair-*.json')))

    def test_client_vanished_after_diagnosis_does_not_restart(self):
        self.assert_no_mutation(self.execute_with([self.result(False, False)]))

    def test_contradictory_unattempted_success_does_not_restart(self):
        self.assert_no_mutation(self.execute_with([self.result(True, False)]))

    def test_missing_live_result_does_not_restart(self):
        self.assert_no_mutation(self.execute_with([]))

    def test_wrong_result_identity_does_not_restart(self):
        item = self.result(False); item.name = 'not-the-requested-probe'
        self.assert_no_mutation(self.execute_with([item]))

    def test_extra_live_result_does_not_restart(self):
        self.assert_no_mutation(self.execute_with([self.result(False), self.result(False)]))

    def test_recovered_application_is_not_restarted(self):
        self.assert_no_mutation(self.execute_with([self.result(True)]))

    def test_real_negative_evidence_still_allows_reviewed_repair(self):
        result = self.execute_with([self.result(False, True)])
        self.assertTrue(result['success'], result)
        self.assertEqual(self.transitions, ['stopped', 'running'])

    def test_mixed_failure_and_unknown_holds_whole_local_precheck(self):
        other = dict(self.spec, name='second')
        self.params['probes'].append(other)
        batch = [self.result(False), ProbeResult(other['name'], other['target'], False, executed=False)]
        self.assert_no_mutation(self.execute_with(batch))

    def test_target_client_readiness_checked_before_any_mutation(self):
        with patch('sentinel_blue.actions.dependency_readiness', return_value={'ready': False, 'missing': ['executable mysql']}) as readiness:
            result = self.execute_with([self.result(False)])
        readiness.assert_called_once()
        self.assertIn('mysql', result['message'])
        self.assert_no_mutation(result)

    def test_unknown_dependency_cannot_authorize_repair_from_telemetry(self):
        dependency = {'kind': 'tcp', 'name': 'database', 'target': '127.0.0.1', 'port': 12345}
        self.params['recovery_guard']['dependency_probes'] = [dependency]
        self.current['probes'].append({'name': 'database', 'target': '127.0.0.1', 'healthy': True, 'executed': False})
        with self.assertRaisesRegex(ValueError, 'dependency application health'):
            check_recovery_observation(self.params, self.current)

    def test_dependency_becomes_unavailable_before_execution(self):
        dependency = {'kind': 'tcp', 'name': 'database', 'target': '127.0.0.1', 'port': 12345}
        self.params['recovery_guard']['dependency_probes'] = [dependency]
        self.current['probes'].append({'name': 'database', 'target': '127.0.0.1', 'healthy': True, 'executed': True})
        batch = [ProbeResult('database', '127.0.0.1', True, executed=False)]
        with patch('sentinel_blue.actions.run_probes', return_value=batch):
            result = self.execute_with([self.result(False)])
        self.assert_no_mutation(result)

    def test_unattempted_success_after_repair_triggers_rollback_not_commit(self):
        with patch.object(self.ex.repairs, '_probe', return_value=[self.result(False)]), patch.object(
                self.ex, '_wait_for_service_probes', return_value=([self.result(True, False)], 3, True)):
            result = self.ex.execute('repair_service', self.params, self.current)
        self.assertFalse(result['success'])
        self.assertTrue(result['rolled_back'], result)
        self.assertEqual(self.native_state, 'running')
        self.assertEqual(self.target.read_bytes(), b'trusted')

    def test_stopped_service_missing_client_does_not_consume_native_attempt(self):
        self.native_state = 'stopped'
        with patch('sentinel_blue.actions.dependency_readiness', return_value={'ready': False, 'missing': ['executable mysql']}):
            result = self.ex.execute('restart_service', {'service': 'web.service', 'probes': [self.spec]}, self.current)
        self.assertFalse(result['success'])
        self.assertEqual(self.transitions, [])
        self.assertFalse(list(self.ex.state_dir.glob('service-transaction-*.json')))


class PostconditionTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(); self.addCleanup(temporary.cleanup)
        self.ex = ActionExecutor(Path(temporary.name)/'state', authorized_networks=['127.0.0.0/8'])

    def test_stable_success_requires_executed_results(self):
        with patch('sentinel_blue.actions.run_probes', return_value=[row(True, False)]), patch(
                'sentinel_blue.actions.time.sleep'), patch('sentinel_blue.actions.SERVICE_RECOVERY_MAX_PROBE_ATTEMPTS', 3):
            _, attempts, accepted = self.ex._wait_for_service_probes([SPEC])
        self.assertEqual(attempts, 3); self.assertFalse(accepted)

    def test_stable_success_requires_matching_identity(self):
        with patch('sentinel_blue.actions.run_probes', return_value=[row(name='other')]), patch(
                'sentinel_blue.actions.time.sleep'), patch('sentinel_blue.actions.SERVICE_RECOVERY_MAX_PROBE_ATTEMPTS', 3):
            self.assertFalse(self.ex._wait_for_service_probes([SPEC])[2])

    def test_three_measured_successes_still_pass(self):
        with patch('sentinel_blue.actions.run_probes', return_value=[row()]), patch('sentinel_blue.actions.time.sleep'):
            _, attempts, accepted = self.ex._wait_for_service_probes([SPEC])
        self.assertEqual(attempts, 3); self.assertTrue(accepted)

    def test_unknown_resets_stability_count(self):
        sequence = [[row()], [row(True, False)], [row()], [row()], [row()]]
        with patch('sentinel_blue.actions.run_probes', side_effect=sequence), patch('sentinel_blue.actions.time.sleep'):
            _, attempts, accepted = self.ex._wait_for_service_probes([SPEC])
        self.assertEqual(attempts, 5); self.assertTrue(accepted)

    def test_validate_action_does_not_call_unattempted_result_success(self):
        with patch('sentinel_blue.actions.run_probes', return_value=[row(True, False)]):
            result = self.ex.execute('validate_service', {'probes': [SPEC]}, {})
        self.assertFalse(result['success'])

    def test_validate_action_requires_exact_batch(self):
        with patch('sentinel_blue.actions.run_probes', return_value=[row(name='other')]):
            self.assertFalse(self.ex.execute('validate_service', {'probes': [SPEC]}, {})['success'])

    def test_controller_rejects_unattempted_success_attestation(self):
        with self.assertRaisesRegex(ValueError, 'probe attestations'):
            _require_success_result_contract('validate_service', {'probes': [SPEC]},
                {'success': True, 'probes': [asdict(row(True, False))]})

    def test_controller_accepts_measured_success_attestation(self):
        _require_success_result_contract('validate_service', {'probes': [SPEC]},
            {'success': True, 'probes': [asdict(row())]})

    def test_controller_preserves_legacy_probe_compatibility(self):
        legacy = asdict(row()); del legacy['executed']
        _require_success_result_contract('validate_service', {'probes': [SPEC]},
            {'success': True, 'probes': [legacy]})

    def test_restore_does_not_commit_unattempted_success(self):
        target = self.ex.state_dir.parent/'test.conf'; target.write_bytes(b'trusted')
        digest = hashlib.sha256(b'trusted').hexdigest()
        captured = self.ex.restore_points.capture([{'path': str(target), 'sha256': digest}])
        self.assertTrue(captured['success'], captured)
        target.write_bytes(b'changed')
        item = {'path': str(target), 'baseline_sha256': digest, 'observed_sha256': hashlib.sha256(b'changed').hexdigest(),
                'observed_missing': False, 'baseline_security_descriptor_sha256': '', 'observed_security_descriptor_sha256': ''}
        with patch('sentinel_blue.restoration.run_probes', return_value=[row(True, False)]):
            result = self.ex.restore_points.restore(item, allowed=True, probes=[SPEC])
        self.assertFalse(result['success'], result)
        self.assertTrue(result['rolled_back'], result)
        self.assertEqual(target.read_bytes(), b'changed')


class ControllerEvidenceTests(unittest.TestCase):
    def test_unattempted_probe_is_unverified_and_queues_no_running_repair(self):
        profile, baseline = repair_fixture()
        store = Store(':memory:'); self.addCleanup(store.close)
        app = ControllerApp(store, 't'*32, operator_token='o'*32, event_profile=profile,
                            auto_recover_services=True, auto_restore=True,
                            restoration_probes=profile.services[0]['expected_transactions'])
        app.ingest(baseline); _promote_integrity_baseline(app, store, 'agent-one')
        for sequence in (2, 3, 4):
            current = copy.deepcopy(baseline)
            current.update(sequence=sequence, observed_at=time.time()-1)
            current['probes'][0].update(healthy=False, executed=False, detail='local probe capacity exhausted')
            app.ingest(current)
        self.assertFalse(any(action.action_type == 'repair_service' for action in store.pending_actions('agent-one')))
        self.assertTrue(any(alert['kind'] == 'scoring_check_unavailable' for alert in store.dashboard()['alerts']))


if __name__ == '__main__':
    unittest.main()
