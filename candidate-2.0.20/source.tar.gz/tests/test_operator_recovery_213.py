"""Operator action/undo and repeated-disruption regressions (private fixtures).

Real temp-file repair and undo, signed local HTTP and real Tk widgets. Service
manager transitions and application responses are inert: not native VM acceptance.
"""
import copy
from dataclasses import asdict
import hashlib
import json
import os
from pathlib import Path
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

from sentinel_blue.controller import ControllerApp, make_handler
from sentinel_blue.event_profile import EventProfile
from sentinel_blue.store import Store
from sentinel_blue.operator_recovery import CHOICES
from sentinel_blue.recovery_limits import evaluate_attempts, normalize_attempt_limits
from sentinel_blue.recovery_policy_editor import policy_candidate, save_candidate, PRESETS
from sentinel_blue.service_recovery import recovery_parameters, validate_automatic_recovery
from sentinel_blue.service_repair import repair_parameters, validate_repair_contract
from sentinel_blue.state import ActionJournal
from sentinel_blue.agent import execute_queued_action
from test_service_repair import repair_fixture, damage
from test_autonomous_service_recovery import stopped
from test_store_controller import _promote_integrity_baseline


class OperatorFixture(unittest.TestCase):
    def setUp(self):
        profile, baseline = repair_fixture()
        raw = copy.deepcopy(profile.raw)
        raw['services'][0]['approval_actions'].append('validate_service')
        self.profile = EventProfile.from_dict(raw)
        self.baseline = baseline
        self.store = Store(':memory:'); self.addCleanup(self.store.close)
        self.app = ControllerApp(self.store, 't'*32, operator_token='o'*32, event_profile=self.profile)
        self.app.ingest(baseline); _promote_integrity_baseline(self.app, self.store, 'agent-one')
        self.current = damage(baseline)
        self.app.ingest(self.current)

    def selection(self, choice='repair', action_id=''):
        return {'agent_id': 'agent-one', 'service': 'web.service', 'choice': choice, 'action_id': action_id}

    def review(self, choice='repair', action_id=''):
        return self.app.review_service_action(self.selection(choice, action_id), 'operator')

    def payload(self, review):
        return {'review_id': review['review_id'], 'review_sha256': review['review_sha256'],
                'reason': 'Explicit fixture recovery', 'authorization_code': ''}

    def approve(self, review):
        return self.app.execute_service_action(self.payload(review), 'operator')


class OperatorReviewTests(OperatorFixture):
    def test_review_is_read_only_and_displays_exact_files(self):
        before = self.store._connection.execute('SELECT count(*) FROM actions').fetchone()[0]
        result = self.review()
        self.assertEqual(result['effects']['restore_approved_files'], ['/etc/web.conf'])
        self.assertEqual(result['undo'], 'exact-journal')
        self.assertEqual(before, self.store._connection.execute('SELECT count(*) FROM actions').fetchone()[0])

    def test_explicit_approval_queues_without_an_alert_recommendation(self):
        review = self.review()
        result = self.approve(review)
        action = self.store.get_action(result['action_id'])
        self.assertFalse(action['automated']); self.assertEqual(action['status'], 'queued')
        self.assertEqual(action['action_type'], 'repair_service')
        self.assertIsNone(action['alert_id'])

    def test_duplicate_click_or_lost_reply_returns_same_action(self):
        review = self.review(); first = self.approve(review); second = self.approve(review)
        self.assertEqual(first['action_id'], second['action_id']); self.assertEqual(second['status'], 'already_queued')

    def test_concurrent_approvals_do_not_queue_two_effects(self):
        review = self.review(); outcomes = []
        threads = [threading.Thread(target=lambda: outcomes.append(self.approve(review))) for _ in range(4)]
        for item in threads: item.start()
        for item in threads: item.join()
        self.assertEqual(len(outcomes), 4); self.assertEqual(len({row['action_id'] for row in outcomes}), 1)

    def test_another_principal_cannot_execute_review(self):
        with self.assertRaises(PermissionError):
            self.app.execute_service_action(self.payload(self.review()), 'someone-else')

    def test_expired_review_cannot_execute(self):
        review = self.review()
        self.app._service_action_reviews[review['review_id']]['expires_monotonic'] = time.monotonic()-1
        with self.assertRaises(PermissionError): self.approve(review)

    def test_changed_credential_epoch_invalidates_review(self):
        review = self.review(); self.app.operator_credential_epoch += 1
        with self.assertRaises(PermissionError): self.approve(review)

    def test_tampered_digest_cannot_execute(self):
        review = self.review(); payload = self.payload(review); payload['review_sha256'] = '0'*64
        with self.assertRaises(PermissionError): self.app.execute_service_action(payload, 'operator')

    def test_client_cannot_inject_executable_parameters(self):
        payload = self.payload(self.review()); payload['parameters'] = {'command': 'anything'}
        with self.assertRaises(ValueError): self.app.execute_service_action(payload, 'operator')
        with self.assertRaises(ValueError): self.app.review_service_action(self.selection('shell'), 'operator')

    def test_emergency_stop_between_review_and_approval_refuses_forward_action(self):
        review = self.review(); self.app.emergency_stop()
        with self.assertRaises(PermissionError): self.approve(review)

    def test_new_observation_same_effects_is_accepted(self):
        review = self.review()
        updated = copy.deepcopy(self.current); updated.update(sequence=3, observed_at=time.time())
        self.app.ingest(updated)
        self.assertEqual(self.approve(review)['status'], 'queued')

    def test_new_observation_changed_effects_requires_review_again(self):
        review = self.review()
        updated = copy.deepcopy(self.current); updated.update(sequence=3, observed_at=time.time())
        updated['integrity'][0]['sha256'] = 'f'*64; self.app.ingest(updated)
        with self.assertRaisesRegex(PermissionError, 'changed'): self.approve(review)

    def test_stale_or_wrong_platform_evidence_refuses_review(self):
        for change in ({'observed_at': time.time()-100}, {'platform': 'Windows'}):
            changed = dict(self.current, **change)
            with self.subTest(change=change), patch.object(self.store, 'latest_telemetry_for_agent', return_value=changed):
                with self.assertRaises((ValueError, PermissionError)): self.review()

    def test_unapproved_baseline_refuses_mutation(self):
        with patch.object(self.store, 'baseline_status', return_value='pending'):
            with self.assertRaises(PermissionError): self.review()

    def test_missing_undo_permission_refuses_forward_action(self):
        raw = copy.deepcopy(self.profile.raw); raw['services'][0]['approval_actions'].remove('rollback_service_repair')
        self.app.event_profile = EventProfile.from_dict(raw)
        with self.assertRaisesRegex(PermissionError, 'rollback_service_repair'): self.review()

    def test_check_does_not_capture_or_change_a_baseline(self):
        original = self.store.get_baseline('agent-one')
        review = self.review('check'); action = self.store.get_action(self.approve(review)['action_id'])
        self.assertEqual(action['action_type'], 'validate_service')
        self.assertEqual(review['undo'], 'none'); self.assertEqual(original, self.store.get_baseline('agent-one'))

    def test_start_does_not_silently_expand_to_file_or_startup_repair(self):
        with self.assertRaisesRegex(ValueError, 'start-only'): self.review('start')

    def test_start_clean_stopped_service_uses_exact_undo_journal_path(self):
        current = stopped(self.baseline, 3); current['observed_at'] = time.time()
        self.app.ingest(current)
        review = self.review('start')
        self.assertEqual(review['action_type'], 'repair_service')
        self.assertEqual(review['effects']['restore_approved_files'], [])
        self.assertEqual(review['undo'], 'exact-journal')

    def test_unresolved_repair_and_change_grant_still_hold(self):
        self.store.create_change_grant('agent-one', '/etc/web.conf', 120)
        with self.assertRaises(PermissionError): self.review()

    def test_pending_repair_still_holds_new_review(self):
        self.approve(self.review())
        with self.assertRaises(PermissionError): self.review()

    def test_queued_action_is_not_listed_as_undoable(self):
        action_id = self.approve(self.review())['action_id']
        history = self.app.service_action_history({'agent_id':'agent-one','service':'web.service'})
        item = next(x for x in history['actions'] if x['action_id']==action_id)
        self.assertFalse(item['undo_candidate'])
        with self.assertRaises(ValueError): self.review('undo', action_id)

    def test_review_cache_is_bounded(self):
        for _ in range(128): self.review('check')
        with self.assertRaisesRegex(ValueError, 'capacity'): self.review('check')

    def test_foreign_or_ambiguous_service_selection_rejected(self):
        for change in ({'agent_id':'agent-two'}, {'service':'WEB.SERVICE'}, {'choice':[]}, {'action_id':'../../x'}):
            with self.subTest(change=change), self.assertRaises((ValueError, PermissionError)):
                self.app.review_service_action(dict(self.selection(), **change), 'operator')


class ExactUndoTests(OperatorFixture):
    def setUp(self):
        from test_service_repair import RepairExecutionTests
        self.fixture = RepairExecutionTests('test_file_restore_and_start_commit_together_and_support_exact_undo')
        self.fixture.setUp(); self.addCleanup(self.fixture.doCleanups)
        self.profile, self.baseline, self.current = self.fixture.profile, self.fixture.baseline, self.fixture.current
        self.store = Store(':memory:'); self.addCleanup(self.store.close)
        self.app = ControllerApp(self.store, 't'*32, operator_token='o'*32, event_profile=self.profile)
        self.app.ingest(self.baseline); _promote_integrity_baseline(self.app, self.store, 'agent-one')
        self.app.ingest(self.current)
        self.journal = ActionJournal(self.fixture.root / 'delivery')
        transition = patch.object(self.fixture.executor.repairs, '_transition', side_effect=self.fixture.change_state)
        transition.start(); self.addCleanup(transition.stop)

    def deliver(self, identifier):
        action = next(asdict(x) for x in self.store.pending_actions('agent-one') if x.action_id == identifier)
        latest = self.store.latest_telemetry_for_agent('agent-one')
        result = execute_queued_action(self.journal, self.fixture.executor, action, latest,
                                      {'action_safe': True}, self.profile)
        self.assertEqual(self.app.complete_action({**result, 'action_id':identifier}, 'agent-one'), 'new')
        return result

    def repaired(self):
        identifier = self.approve(self.review())['action_id']
        result = self.deliver(identifier); self.assertTrue(result['success'], result)
        current = copy.deepcopy(self.baseline); current.update(sequence=3, observed_at=time.time())
        self.app.ingest(current)
        return identifier

    def test_gui_api_choice_repair_and_undo_restore_exact_temporary_bytes_and_state(self):
        identifier = self.repaired()
        self.assertEqual(self.fixture.target.read_bytes(), b'trusted')
        self.assertEqual(self.fixture.native_state, 'running')
        undo = self.approve(self.review('undo', identifier))
        result = self.deliver(undo['action_id']); self.assertTrue(result['success'], result)
        self.assertEqual(self.fixture.target.read_bytes(), b'damaged')
        self.assertEqual(self.fixture.native_state, 'stopped')
        with self.assertRaisesRegex(ValueError, 'later'): self.review('undo', identifier)

    def test_later_unhealthy_application_can_undo_completed_repair_without_accepting_new_baseline(self):
        identifier = self.repaired()
        changed = copy.deepcopy(self.baseline); changed.update(sequence=4, observed_at=time.time())
        for probe in changed['probes']:probe['healthy'] = False
        self.app.ingest(changed)
        undo = self.approve(self.review('undo', identifier))
        result = self.deliver(undo['action_id'])
        self.assertTrue(result['success'], result)
        self.assertEqual(self.fixture.target.read_bytes(), b'damaged')
        self.assertEqual(self.fixture.native_state, 'stopped')
        self.assertEqual(self.store.baseline_status('agent-one'), 'approved')

    def test_native_undo_does_not_overwrite_teammate_change_after_review(self):
        identifier = self.repaired(); undo = self.approve(self.review('undo', identifier))
        self.fixture.target.write_bytes(b'new teammate bytes')
        result = self.deliver(undo['action_id']); self.assertFalse(result['success'], result)
        self.assertEqual(self.fixture.target.read_bytes(), b'new teammate bytes')
        self.assertEqual(self.fixture.native_state, 'running')

    def test_observed_changed_file_prevents_even_review_of_undo(self):
        identifier = self.repaired()
        changed = copy.deepcopy(self.baseline); changed.update(sequence=4, observed_at=time.time())
        changed['integrity'][0]['sha256'] = hashlib.sha256(b'new edit').hexdigest()
        self.app.ingest(changed)
        with self.assertRaisesRegex(ValueError, 'third state'): self.review('undo', identifier)

    def test_bad_health_auto_rolls_back_and_is_not_an_undoable_success(self):
        self.fixture.executor._wait_for_service_probes.return_value = (self.fixture.healthy, 4, False)
        identifier = self.approve(self.review())['action_id']; result = self.deliver(identifier)
        self.assertFalse(result['success']); self.assertTrue(result['rolled_back'], result)
        self.assertEqual(self.fixture.target.read_bytes(), b'damaged')
        self.assertEqual(self.fixture.native_state, 'stopped')
        with self.assertRaises(ValueError): self.review('undo', identifier)

    def test_dry_run_never_becomes_undoable_success(self):
        self.fixture.executor.allow_restoration = False
        identifier = self.approve(self.review())['action_id']; result = self.deliver(identifier)
        self.assertTrue(result['dry_run']); self.assertEqual(self.fixture.target.read_bytes(), b'damaged')
        with self.assertRaises(ValueError): self.review('undo', identifier)

    def test_second_undo_review_cannot_enqueue_duplicate_effect(self):
        identifier = self.repaired(); one = self.review('undo', identifier); two = self.review('undo', identifier)
        self.approve(one)
        with self.assertRaisesRegex(ValueError, 'later'): self.approve(two)


class RepeatedDisruptionTests(unittest.TestCase):
    def test_explicit_high_policy_allows_more_than_twelve_verified_recoveries(self):
        events = [(float(100+i*30), True) for i in range(20)]
        self.assertFalse(evaluate_attempts(events, 1000)['allowed'])
        self.assertTrue(evaluate_attempts(events, 1000, PRESETS['Repeated disruption'])['allowed'])

    def test_120_is_still_finite_and_121_rejected(self):
        limits = {'cooldown_seconds':15,'maximum_attempts':120}
        result = evaluate_attempts([(float(i*20),True) for i in range(120)], 2500, limits)
        self.assertFalse(result['allowed']); self.assertEqual(result['retry_at'],3600)
        with self.assertRaises(ValueError): normalize_attempt_limits(dict(limits, maximum_attempts=121))

    def test_failures_do_not_get_high_success_budget(self):
        for maximum in (12,60,120):
            result = evaluate_attempts([(0.,False),(310.,False),(620.,False),(1000.,True)], 1400,
                                       {'cooldown_seconds':15,'maximum_attempts':maximum})
            self.assertFalse(result['allowed']); self.assertEqual(result['failed_attempts_in_window'],3)
            self.assertEqual(result['retry_at'],3600)

    def test_no_clock_nan_or_boolean_acceptance(self):
        for now in (float('nan'),float('inf'),True):
            with self.assertRaises(ValueError): evaluate_attempts([],now)

    def test_per_service_candidate_preserves_authority_and_other_service(self):
        p,b = repair_fixture(); raw = copy.deepcopy(p.raw)
        other = copy.deepcopy(raw['services'][0]); other['service_id']='other.service'; other['host']='agent-two'
        raw['services'].append(other); before=copy.deepcopy(raw)
        candidate, report = policy_candidate(raw, [('agent-one','web.service')], PRESETS['Repeated disruption'])
        self.assertEqual(raw,before); self.assertEqual(candidate['services'][1],EventProfile.from_dict(raw).raw['services'][1])
        self.assertEqual(candidate['scope'],before['scope']); self.assertEqual(candidate['capabilities'],before['capabilities'])
        self.assertEqual(candidate['services'][0]['approval_actions'],before['services'][0]['approval_actions'])
        self.assertEqual(candidate['approval']['status'],'pending'); self.assertFalse(candidate['release']['approved'])
        self.assertFalse(report['applied_to_running_agents'])
        self.assertNotEqual(EventProfile.from_dict(raw).fingerprint,EventProfile.from_dict(candidate).fingerprint)
        with self.assertRaises(ValueError): EventProfile.from_dict(candidate).require_range_ready()

    def test_policy_does_not_infer_missing_repair_or_unknown_target(self):
        p,b=repair_fixture(); raw=copy.deepcopy(p.raw); raw['services'][0].pop('repair_policy')
        for targets in ([('agent-one','web.service')],[('agent-two','web.service')],[]):
            with self.assertRaises(ValueError):policy_candidate(raw,targets,PRESETS['Repeated disruption'])

    def test_save_is_private_and_cannot_overwrite_or_follow_link(self):
        p,b=repair_fixture();candidate,_=policy_candidate(p.raw,[('agent-one','web.service')],PRESETS['Moderate'])
        with tempfile.TemporaryDirectory() as td:
            file=Path(td)/'candidate.json';save_candidate(file,candidate)
            self.assertEqual(file.stat().st_mode & 0o777,0o600)
            old=file.read_bytes()
            with self.assertRaises(FileExistsError):save_candidate(file,candidate)
            link=Path(td)/'link.json';link.symlink_to(file)
            with self.assertRaises(FileExistsError):save_candidate(link,candidate)
            self.assertEqual(file.read_bytes(),old)

    def test_restart_and_repair_both_bind_the_same_explicit_limits(self):
        p,b=repair_fixture();raw=copy.deepcopy(p.raw);raw['services'][0]['repair_policy']['attempt_limits']=PRESETS['Repeated disruption']
        p=EventProfile.from_dict(raw);current=stopped(b)
        restart=recovery_parameters(p,'agent-one','web.service',b,current)
        self.assertEqual(restart['recovery_guard']['attempt_limits'],PRESETS['Repeated disruption'])
        validate_automatic_recovery(p,'agent-one',restart,current)
        repaired=repair_parameters(p,'agent-one','web.service',b,damage(b))
        self.assertEqual(repaired['recovery_guard']['attempt_limits'],restart['recovery_guard']['attempt_limits'])
        validate_repair_contract(p,'agent-one',repaired,damage(b))

    def test_restart_envelope_cannot_increase_or_strip_approved_limits(self):
        p,b=repair_fixture();raw=copy.deepcopy(p.raw);raw['services'][0]['repair_policy']['attempt_limits']=PRESETS['Moderate']
        p=EventProfile.from_dict(raw);current=stopped(b)
        original=recovery_parameters(p,'agent-one','web.service',b,current)
        for change in ('strip','expand'):
            value=copy.deepcopy(original)
            if change=='strip': value['recovery_guard'].pop('attempt_limits')
            else:value['recovery_guard']['attempt_limits']['maximum_attempts']=120
            with self.assertRaisesRegex(ValueError,'attempt limits'):
                validate_automatic_recovery(p,'agent-one',value,current)


if __name__=='__main__':unittest.main()


class SignedActionHTTPTests(OperatorFixture):
    def setUp(self):
        super().setUp()
        from sentinel_blue.controller import ControllerServer
        from sentinel_blue.desktop_control import DesktopClient
        self.server = ControllerServer(('127.0.0.1', 0), make_handler(self.app))
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True); self.thread.start()
        self.addCleanup(self.server.server_close); self.addCleanup(self.thread.join, 3); self.addCleanup(self.server.shutdown)
        self.client = DesktopClient(f'http://127.0.0.1:{self.server.server_port}', 'operator', 1, 'o'*32)

    def test_real_signed_http_review_execute_and_history(self):
        review = self.client.request('/api/v1/service-actions/review', self.selection())
        result = self.client.request('/api/v1/service-actions/execute', self.payload(review))
        again = self.client.request('/api/v1/service-actions/execute', self.payload(review))
        self.assertEqual(result['action_id'], again['action_id'])
        history = self.client.request('/api/v1/service-actions/history', {'agent_id':'agent-one','service':'web.service'})
        self.assertEqual(history['actions'][0]['status'], 'queued')
        self.assertFalse(history['actions'][0]['undo_candidate'])

    def test_unauthenticated_requests_cannot_review_execute_or_read_history(self):
        import http.client
        for ending in ('review', 'execute', 'history'):
            conn = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=5)
            try:
                conn.request('POST', '/api/v1/service-actions/'+ending, body=b'{}', headers={'Content-Type':'application/json'})
                response=conn.getresponse(); response.read(); self.assertEqual(response.status, 401)
            finally:conn.close()

    def test_signed_request_still_cannot_supply_arbitrary_action_parameters(self):
        with self.assertRaisesRegex(RuntimeError, 'HTTP 400'):
            self.client.request('/api/v1/service-actions/review', dict(self.selection(), command='unused'))


class ActionRoleBoundaryTests(unittest.TestCase):
    def test_new_operator_endpoints_keep_dedicated_guest_source_boundary(self):
        from test_management_isolation_212 import HTTPRoleTests, MANAGER, WEB
        from sentinel_blue.desktop_control import DesktopClient
        fixture = HTTPRoleTests('test_management_still_requires_operator_signature')
        fixture.setUp(); self.addCleanup(fixture.doCleanups)
        client = DesktopClient(f'http://127.0.0.1:{fixture.server.server_port}', 'operator', 1, 'o'*48)
        fixture.peer = MANAGER
        self.assertIsInstance(client.dashboard(), dict)
        fixture.peer = WEB
        with patch.object(fixture.server.RequestHandlerClass, '_read_body', side_effect=AssertionError('body must not be read')):
            for ending in ('review', 'execute', 'history'):
                with self.subTest(path=ending), self.assertRaisesRegex(RuntimeError, 'HTTP 403'):
                    client.request('/api/v1/service-actions/'+ending, {})


class NativeBudgetTests(unittest.TestCase):
    def test_native_guard_allows_more_successes_but_preserves_failures_and_unknown_holds(self):
        from test_service_repair import RepairExecutionTests
        from sentinel_blue.state import write_private_json
        fixture = RepairExecutionTests('test_file_restore_and_start_commit_together_and_support_exact_undo')
        fixture.setUp(); self.addCleanup(fixture.doCleanups)
        params = copy.deepcopy(fixture.parameters)
        params['recovery_guard']['attempt_limits'] = PRESETS['Repeated disruption']
        now = time.time()
        for index in range(20):
            write_private_json(fixture.executor.state_dir / f'service-transaction-budget{index}.json', {
                'service':'web.service', 'created_at':now-600-index*20,
                'operation':'restart_service', 'status':'committed'})
        with patch('sentinel_blue.actions.dependency_readiness', return_value={'ready':True}), \
                patch('sentinel_blue.probes.check_local_probe_prerequisites'):
            fixture.executor._service_recovery_preflight(params, skip_paths=(str(fixture.target),))
            original = copy.deepcopy(params); original['recovery_guard']['attempt_limits'] = {'cooldown_seconds':300,'maximum_attempts':3}
            with self.assertRaisesRegex(ValueError, 'hourly_budget'):
                fixture.executor._service_recovery_preflight(original, skip_paths=(str(fixture.target),))
            for index in range(3):
                write_private_json(fixture.executor.state_dir / f'service-transaction-failed{index}.json', {
                    'service':'web.service', 'created_at':now-900-index*100,
                    'operation':'repair_service', 'status':'rolled_back'})
            with self.assertRaisesRegex(ValueError, 'failed_attempt_hourly_budget'):
                fixture.executor._service_recovery_preflight(params, skip_paths=(str(fixture.target),))
            write_private_json(fixture.executor.state_dir / 'service-transaction-unknown.json', {
                'service':'web.service', 'created_at':now-30, 'operation':'repair_service', 'status':'pending'})
            with self.assertRaisesRegex(ValueError, 'unresolved outcome'):
                fixture.executor._service_recovery_preflight(params, skip_paths=(str(fixture.target),))


@unittest.skipUnless(os.environ.get('DISPLAY'), 'Tk display unavailable')
class OperatorActionGUI(unittest.TestCase):
    def setUp(self):
        import tkinter as tk
        from sentinel_blue.desktop import DesktopWindow
        self.backend = ExactUndoTests('test_gui_api_choice_repair_and_undo_restore_exact_temporary_bytes_and_state')
        self.backend.setUp(); self.addCleanup(self.backend.doCleanups)
        self.tmp = tempfile.TemporaryDirectory(prefix='sb213-gui-'); self.addCleanup(self.tmp.cleanup)
        self.root = tk.Tk()
        with patch('sentinel_blue.linux_workspace.local_observation', return_value={'observation':{'complete':True,'listeners':[]},'addresses':['127.0.0.1'],'presence':{}}):
            self.gui = DesktopWindow(self.root, directory=self.tmp.name)
        self.addCleanup(self.close)
        backend = self.backend.app
        class Client:
            def request(self, path, payload):
                if path.endswith('/review'):return backend.review_service_action(payload, 'operator')
                if path.endswith('/execute'):return backend.execute_service_action(payload, 'operator')
                if path.endswith('/history'):return backend.service_action_history(payload)
                raise AssertionError(path)
        self.gui.client = Client()
        def submit(operation, complete, failed):
            try:value=operation()
            except Exception as exc:failed(exc)
            else:complete(value)
        self.gui.submit = submit
        self.gui.services.insert('', 'end', iid='fixture-service', values=('agent-one','web.service'))
        self.gui.services.selection_set('fixture-service')
        self.dialog = self.gui.open_service_actions()
        self.root.update()

    def close(self):
        import tkinter as tk
        self.gui.close()
        try:self.root.destroy()
        except tk.TclError:pass

    def test_actual_widgets_choose_repair_then_review_recorded_undo(self):
        dialog=self.dialog
        dialog.choice.set(CHOICES['repair']);dialog.review_choice()
        self.assertEqual(dialog.review['selection']['choice'],'repair')
        self.assertEqual(str(dialog.approve['state']),'normal')
        dialog.reason.set('Repair the approved fixture and inspect the result')
        with patch.object(self.gui.messagebox,'askyesno',return_value=True):dialog.execute_review()
        identifier=next(iter(dialog.history_rows))
        self.assertEqual(dialog.history_rows[identifier]['status'],'queued')
        self.assertFalse(dialog.history_rows[identifier]['undo_candidate'])
        result=self.backend.deliver(identifier);self.assertTrue(result['success'],result)
        fresh=copy.deepcopy(self.backend.baseline);fresh.update(sequence=3,observed_at=time.time())
        self.backend.app.ingest(fresh)
        dialog.refresh_history();dialog.history.selection_set(identifier);dialog.review_undo()
        self.assertEqual(dialog.review['selection']['choice'],'undo')
        self.assertEqual(str(dialog.approve['text']),'Approve recorded undo')
        self.root.update()
        if destination:=os.environ.get('SB213_SCREENSHOT_DIR'):
            from PIL import ImageGrab
            Path(destination).mkdir(parents=True,exist_ok=True)
            dialog.window.lift();self.root.update()
            x,y=dialog.window.winfo_rootx(),dialog.window.winfo_rooty()
            ImageGrab.grab(bbox=(x,y,x+dialog.window.winfo_width(),y+dialog.window.winfo_height())).save(str(Path(destination)/'action_undo_dialog.png'))
        with patch.object(self.gui.messagebox,'askyesno',return_value=True):dialog.execute_review()
        undo=next(key for key,row in dialog.history_rows.items() if row['action_type']=='rollback_service_repair')
        result=self.backend.deliver(undo);self.assertTrue(result['success'],result)
        self.assertEqual(self.backend.fixture.target.read_bytes(),b'damaged')

    def test_choice_changed_during_review_does_not_enable_wrong_plan(self):
        pending=[]
        self.gui.submit=lambda operation,complete,failed:pending.append((operation,complete,failed))
        self.dialog.choice.set(CHOICES['repair']);self.dialog.review_choice()
        self.dialog.choice.set(CHOICES['start']);self.dialog._invalidate()
        operation,complete,failed=pending[0];complete(operation())
        self.assertIsNone(self.dialog.review)
        self.assertEqual(str(self.dialog.approve['state']),'disabled')

    def test_full_local_work_queue_does_not_wedge_dialog_or_claim_submission(self):
        self.gui.submit = lambda *args: False
        self.dialog.choice.set(CHOICES['repair']); self.dialog.review_choice()
        self.assertFalse(self.dialog.busy)
        self.assertIsNone(self.dialog.review)
        self.assertEqual(str(self.dialog.approve['state']), 'disabled')
        self.assertIn('nothing was submitted', self.dialog.status.get())

    def test_switched_controller_and_closed_window_cannot_run_old_review(self):
        self.dialog.choice.set(CHOICES['repair']);self.dialog.review_choice()
        self.gui.generation += 1
        with patch.object(self.gui.messagebox,'askyesno') as prompt:self.dialog.execute_review()
        prompt.assert_not_called()
        self.dialog.window.destroy();self.assertFalse(self.dialog._current())

    def test_gui_policy_saves_new_private_unapproved_copy_without_live_change(self):
        from sentinel_blue.state import write_private_json
        source=Path(self.tmp.name)/'profile.json';target=Path(self.tmp.name)/'candidate.json'
        write_private_json(source,self.backend.profile.raw)
        self.dialog.policy_source.set(str(source));self.dialog.cooldown.set('15');self.dialog.maximum.set('60')
        with patch.object(self.gui.messagebox,'askyesno',return_value=True), \
                patch.object(self.gui.filedialog,'asksaveasfilename',return_value=str(target)):
            self.dialog.save_policy()
        self.assertTrue(target.exists(),self.dialog.status.get())
        updated=json.loads(target.read_text())
        self.assertEqual(updated['approval']['status'],'pending')
        self.assertEqual(updated['services'][0]['repair_policy']['attempt_limits'],PRESETS['Repeated disruption'])
        self.assertEqual(json.loads(source.read_text()),self.backend.profile.raw)
        self.assertEqual(self.backend.app.event_profile.fingerprint,self.backend.profile.fingerprint)


class AuthorizationAndStoreBudgetTests(OperatorFixture):
    def test_live_high_risk_review_requires_subject_bound_one_use_authorization(self):
        raw=copy.deepcopy(self.profile.raw);raw['environment']='live-competition';raw['competition']='custom';raw['autonomy_mode']='guarded-autonomous'
        for key in ('automatic_vm_replacement','scored_service_migration','network_forks'):raw['capabilities'][key]=False
        self.app.event_profile=EventProfile.from_dict(raw);self.app.autonomy_mode='guarded-autonomous'
        review=self.review();self.assertTrue(review['requires_authorization_code'])
        with self.assertRaises((ValueError,PermissionError)):self.approve(review)
        wrong=self.app.issue_action_authorization({'agent_id':'agent-one','action_type':review['action_type'],'subject':'another-review','ttl_seconds':90})
        payload=self.payload(review);payload['authorization_code']=wrong['authorization_code']
        with self.assertRaises((ValueError,PermissionError)):self.app.execute_service_action(payload,'operator')
        token=self.app.issue_action_authorization({'agent_id':'agent-one','action_type':review['action_type'],'subject':review['review_id'],'ttl_seconds':90})
        payload['authorization_code']=token['authorization_code']
        first=self.app.execute_service_action(payload,'operator');second=self.app.execute_service_action(payload,'operator')
        self.assertEqual(first['action_id'],second['action_id'])

    def test_controller_store_and_agent_budget_agree_on_many_verified_successes(self):
        epoch=time.time()-1600
        for index in range(20):
            when=epoch+index*40
            with patch('time.time',return_value=when):
                identifier=self.store.queue_action('agent-one','restart_service',{'service':'web.service'})
                self.store.pending_actions('agent-one')
                outcome=self.store.complete_action(identifier,{'action_id':identifier,'action_type':'restart_service',
                    'pre_state':{'service':'web.service','desired_state':'stopped'},
                    'success':True,'stable_health':True,'dry_run':False,'message':'fixture verified recovery',
                    'started_at':when,'completed_at':when})
                self.assertEqual(outcome,'new')
        high=self.store.service_recovery_budget_status('agent-one','web.service',PRESETS['Repeated disruption'])
        self.assertTrue(high['allowed'],high);self.assertEqual(high['attempts_in_window'],20)
        self.assertFalse(self.store.service_recovery_budget_status('agent-one','web.service')['allowed'])
        other=self.store.service_recovery_budget_status('agent-one','other.service')
        self.assertTrue(other['allowed']);self.assertEqual(other['attempts_in_window'],0)

    def test_new_post_routes_retain_bounded_json_body_limits(self):
        from sentinel_blue.controller import controller_post_route_limit, CONTROLLER_JSON_REQUEST_BYTES
        for ending in ('review','execute','history'):
            self.assertEqual(controller_post_route_limit('/api/v1/service-actions/'+ending),CONTROLLER_JSON_REQUEST_BYTES)
