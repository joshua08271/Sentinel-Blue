"""Distinct processes in one native logon session retain distinct provenance."""
import copy
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

from sentinel_blue import __version__
from sentinel_blue.auth import derive_enrollment_ticket
from sentinel_blue.controller import ControllerApp
from sentinel_blue.event_profile import EventProfile
from sentinel_blue.recovery_ops import initialize_controller_recovery
from sentinel_blue.store import Store


class SessionAlertContinuityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.database = self.root / 'controller.db'
        self.anchor = self.root / 'recovery.anchor'
        self.key = b'r' * 48
        initialize_controller_recovery(self.database, self.anchor, self.key)
        raw = copy.deepcopy(EventProfile.testing().raw)
        raw['release']['sha256'] = 'a' * 64
        raw['official_identities'] = [{'agent_id': 'agent-one', 'name': 'root', 'class': 'blue-admin'}]
        self.profile = EventProfile.from_dict(raw)
        self.store = Store(self.database)
        self.app = self.controller()
        sample = self.sample(1, [self.session(201), self.session(202)])
        self.token = self.app.enroll(
            {**sample, 'enrollment_nonce': 'b' * 64},
            authenticated_ticket=derive_enrollment_ticket('t' * 64, self.profile.fingerprint, 'agent-one'),
        )['agent_token']

    def tearDown(self):
        self.store.close()
        self.temp.cleanup()

    def controller(self):
        return ControllerApp(
            self.store, 't' * 64, operator_token='o' * 64, operator_credential_epoch=2,
            event_profile=self.profile, recovery_key=self.key, recovery_anchor=self.anchor,
            require_authenticated_recovery=True,
        )

    @staticmethod
    def session(pid, *, started='1000'):
        return {'username': 'owned-lab-admin', 'source': 'unknown', 'session_id': '0',
                'process_id': pid, 'privileged': True, 'interactive': True,
                'process_identity': {'schema': 'sentinel-process-v1', 'platform': 'windows',
                    'process_id': pid, 'boot_id': 'owned-boot', 'start_time': started,
                    'executable_path': r'C:\OwnedLab\worker.exe', 'executable_file_id': '1:2',
                    'user_id': 'S-1-5-21-1-2-3-1001', 'kernel_session_id': '0'}}

    def sample(self, sequence, sessions):
        return {'agent_id': 'agent-one', 'hostname': 'owned-host', 'platform': 'Windows',
                'observed_at': time.time(), 'queued_at': time.time(), 'sequence': sequence,
                'boot_id': 'owned-boot', 'agent_version': __version__,
                'profile_id': self.profile.profile_id, 'profile_fingerprint': self.profile.fingerprint,
                'sessions': sessions}

    def ingest(self, sample):
        return self.app.ingest(sample, 'agent-one', self.token)

    def session_alerts(self):
        return [row for row in self.store.dashboard()['alerts'] if row['kind'] == 'unverified_privileged_session']

    def test_distinct_processes_share_logon_session_without_blocking_new_telemetry(self):
        sessions = [self.session(201), self.session(202), self.session(203)]
        self.ingest(self.sample(1, sessions))
        self.assertEqual(len(self.session_alerts()), 3)
        self.assertEqual(self.store.pending_telemetry_processing(), [])
        self.ingest(self.sample(2, sessions))
        alerts = self.session_alerts()
        self.assertEqual(len(alerts), 3)
        self.assertEqual({row['occurrence_count'] for row in alerts}, {2})
        self.assertEqual(self.store.latest_telemetry_for_agent('agent-one')['sequence'], 2)

    def test_reused_pid_does_not_merge_a_different_process_identity(self):
        self.ingest(self.sample(1, [self.session(201, started='1000')]))
        self.ingest(self.sample(2, [self.session(201, started='2000')]))
        self.assertEqual(len(self.session_alerts()), 2)

    def test_restart_finishes_partial_processing_without_duplicate_occurrences(self):
        sample = self.sample(1, [self.session(201), self.session(202)])
        original = self.store.add_alert
        seen = 0

        def interrupt_after_one(*args, **kwargs):
            nonlocal seen
            seen += 1
            if seen == 2:
                raise OSError('owned fixture interruption')
            return original(*args, **kwargs)

        with patch.object(self.store, 'add_alert', side_effect=interrupt_after_one):
            with self.assertRaisesRegex(OSError, 'owned fixture interruption'):
                self.ingest(sample)
        self.store.close()
        self.store = Store(self.database)
        self.app = self.controller()
        self.app.resume_pending_telemetry()
        self.assertEqual(self.store.pending_telemetry_processing(), [])
        alerts = self.session_alerts()
        self.assertEqual(len(alerts), 2)
        self.assertEqual({row['occurrence_count'] for row in alerts}, {1})
        self.ingest(self.sample(2, [self.session(201), self.session(202)]))
        self.assertEqual({row['occurrence_count'] for row in self.session_alerts()}, {2})

    def test_same_process_conflicting_candidate_still_fails_closed(self):
        original = self.store.add_alert
        captured = []

        def record(*args, **kwargs):
            captured.append((copy.deepcopy(args), copy.deepcopy(kwargs)))
            return original(*args, **kwargs)

        with patch.object(self.store, 'add_alert', side_effect=record):
            self.ingest(self.sample(1, [self.session(201)]))
        args, kwargs = next(row for row in captured if row[0][1].kind == 'unverified_privileged_session')
        args[1].summary += ' conflicting replacement'
        with self.assertRaisesRegex(ValueError, 'conflicting candidates'):
            original(*args, **kwargs)
        self.assertEqual(len(self.session_alerts()), 1)


if __name__ == '__main__':
    unittest.main()
