"""Regressions for defects reproduced in the exact 1.9.84 launcher."""
import contextlib,io,json,logging,os,shutil,stat,subprocess,sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from sentinel_blue import launch_report,recording

class FirstLaunchStorageTests(unittest.TestCase):
    def run_case(self, prior=None):
        with tempfile.TemporaryDirectory() as d:
            home=Path(d);root=home/'.sentinel-blue-desktop'
            if prior is not None:
                root.mkdir(mode=prior);root.chmod(prior)  # Make the unsafe fixture independent of inherited umask.
            env=dict(os.environ);env.pop(recording.ENV,None);env['HOME']=d
            handlers=logging.getLogger().handlers[:]
            oldmask=os.umask(0o022)
            try:
                with patch.dict(os.environ,env,clear=True),patch.object(recording,'_current',None),patch.object(recording,'_startup_error',''):
                    r=recording.initialize(SimpleNamespace(command='desktop'))
                    mode=stat.S_IMODE(root.stat().st_mode)
                    if r:r.close()
                    return r is not None,mode
            finally:
                os.umask(oldmask)
                logging.getLogger().handlers[:]=handlers
    def test_fresh_recording_creates_private_shared_parent(self):
        ok,mode=self.run_case();self.assertTrue(ok);self.assertEqual(mode & 0o777,0o700)
    def test_existing_unsafe_desktop_root_is_not_chmodded_or_trusted(self):
        ok,mode=self.run_case(0o755);self.assertFalse(ok);self.assertEqual(mode&0o777,0o755)
    def test_existing_private_desktop_root_still_works(self):
        ok,mode=self.run_case(0o700);self.assertTrue(ok);self.assertEqual(mode&0o777,0o700)

class VisibleFailureTests(unittest.TestCase):
    def test_control_bytes_cannot_break_helper_arguments(self):
        text=launch_report._clean('bad\x00value\x1b\x07\nagain')
        self.assertTrue(all(c.isprintable() for c in text));self.assertIn('again',text)
    def test_failed_helper_is_not_counted_as_displayed(self):
        run=__import__('unittest.mock',fromlist=['Mock']).Mock(side_effect=[subprocess.CompletedProcess([],1),subprocess.CompletedProcess([],0)])
        with patch.dict(os.environ,{'DISPLAY':':99'}),patch.object(launch_report.shutil,'which',lambda name:'/test/'+name),patch.object(launch_report.subprocess,'run',run),contextlib.redirect_stderr(io.StringIO()):
            self.assertTrue(launch_report.report('test'))
        self.assertEqual(run.call_count,2)
    def test_all_helpers_fail_falls_back(self):
        with patch.dict(os.environ,{'DISPLAY':':99'}),patch.object(launch_report.shutil,'which',lambda name:'/test/'+name),patch.object(launch_report.subprocess,'run',return_value=subprocess.CompletedProcess([],1)),patch.object(launch_report,'_tk_dialog',return_value=False) as tk,contextlib.redirect_stderr(io.StringIO()):
            self.assertFalse(launch_report.report('test'));tk.assert_called_once()
    def test_explicit_detached_child_reports_configuration_failure(self):
        from sentinel_blue import __main__ as cli
        with patch.object(sys,'argv',['sentinel-blue.pyz','desktop','--foreground']),patch.object(cli,'_main',side_effect=ValueError('unsafe private storage')),patch.object(launch_report,'report') as report:
            with self.assertRaises(SystemExit) as error:cli.main()
            self.assertEqual(error.exception.code,2);report.assert_called_once_with('unsafe private storage')
    def test_explicit_detached_child_reports_runtime_failure(self):
        from sentinel_blue import __main__ as cli
        with patch.object(sys,'argv',['sentinel-blue.pyz','desktop','--foreground']),patch.object(cli,'_main',side_effect=RuntimeError('display unavailable')),patch.object(launch_report,'report') as report:
            with self.assertRaises(SystemExit):cli.main()
            self.assertEqual(report.call_args.args[0],'display unavailable')
    def test_cli_controller_errors_are_not_converted_into_gui_prompts(self):
        from sentinel_blue import __main__ as cli
        with patch.object(sys,'argv',['sentinel-blue.pyz','controller']),patch.object(cli,'_main',side_effect=RuntimeError('original')),patch.object(launch_report,'report') as report:
            with self.assertRaises(RuntimeError):cli.main()
            report.assert_not_called()

@unittest.skipUnless(os.name=='posix','POSIX desktop installer')
class InstallerOwnershipTests(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory();self.addCleanup(self.t.cleanup);self.root=Path(self.t.name);self.home=self.root/'home';(self.home/'Desktop').mkdir(parents=True)
        self.folder=self.home/'Downloads'/'Sentinel Blue';self.folder.mkdir(parents=True)
        packaging=Path(__file__).resolve().parents[1]/'packaging/linux-desktop'
        for f in packaging.iterdir():
            if f.is_file():shutil.copyfile(f,self.folder/f.name)
        (self.folder/'sentinel-blue.pyz').write_text('print("fixture")\n')
        self.env=dict(os.environ,HOME=str(self.home),XDG_DATA_HOME=str(self.home/'.local/share'))
        self.entry=self.home/'.local/share/applications/sentinel-blue.desktop';self.receipt=self.home/'.local/share/.sentinel-blue-launcher.json'
    def run_install(self,*args):
        return subprocess.run(['/bin/sh',str(self.folder/'install-linux-launcher.sh'),*args],env=self.env,capture_output=True,text=True,timeout=20)
    def install(self):
        r=self.run_install();self.assertEqual(r.returncode,0,r.stderr);return r
    def test_unowned_existing_entry_is_not_overwritten(self):
        self.entry.parent.mkdir(parents=True);self.entry.write_text('unowned')
        r=self.run_install();self.assertNotEqual(r.returncode,0);self.assertEqual(self.entry.read_text(),'unowned')
    def test_unowned_existing_entry_is_not_removed(self):
        self.entry.parent.mkdir(parents=True);self.entry.write_text('unowned')
        r=self.run_install('--uninstall');self.assertNotEqual(r.returncode,0);self.assertEqual(self.entry.read_text(),'unowned')
    def test_modified_install_is_not_removed(self):
        self.install();self.entry.write_text(self.entry.read_text()+'# teammate\n');before=self.entry.read_bytes()
        r=self.run_install('--uninstall');self.assertNotEqual(r.returncode,0);self.assertEqual(self.entry.read_bytes(),before)
    def test_symlink_entry_does_not_modify_target(self):
        self.entry.parent.mkdir(parents=True);target=self.root/'protected';target.write_text('untouched');self.entry.symlink_to(target)
        r=self.run_install();self.assertNotEqual(r.returncode,0);self.assertEqual(target.read_text(),'untouched')
    def test_receipt_cannot_authorize_outside_path(self):
        self.install();target=self.root/'protected';target.write_text('untouched');v=json.loads(self.receipt.read_text());v['objects'][str(target)]={'sha256':'0'*64,'mode':0o644};self.receipt.write_text(json.dumps(v))
        r=self.run_install('--uninstall');self.assertNotEqual(r.returncode,0);self.assertEqual(target.read_text(),'untouched')
    def test_install_reapply_and_owned_uninstall(self):
        self.install();before=self.entry.read_bytes();self.install();self.assertEqual(self.entry.read_bytes(),before)
        r=self.run_install('--uninstall');self.assertEqual(r.returncode,0,r.stderr);self.assertFalse(self.entry.exists());self.assertFalse(self.receipt.exists());self.assertTrue((self.folder/'sentinel-blue.pyz').exists())
    def test_prepared_partial_install_resumes_only_expected_objects(self):
        self.install();v=json.loads(self.receipt.read_text());v['phase']='prepared';self.receipt.write_text(json.dumps(v));self.entry.unlink();self.install();self.assertTrue(self.entry.exists());self.assertEqual(json.loads(self.receipt.read_text())['phase'],'committed')
    def test_interrupted_uninstall_finishes_without_recreating_objects(self):
        self.install();v=json.loads(self.receipt.read_text());v['phase']='uninstalling';self.receipt.write_text(json.dumps(v));self.entry.unlink();r=self.run_install('--uninstall');self.assertEqual(r.returncode,0,r.stderr);self.assertFalse(self.receipt.exists())
    def test_interrupted_uninstall_is_not_resumed_as_install(self):
        self.install();v=json.loads(self.receipt.read_text());v['phase']='uninstalling';self.receipt.write_text(json.dumps(v));self.entry.unlink();r=self.run_install();self.assertNotEqual(r.returncode,0);self.assertFalse(self.entry.exists())
    def test_relative_data_home_refused(self):
        self.env['XDG_DATA_HOME']='relative';r=self.run_install();self.assertNotEqual(r.returncode,0)
    def test_unsupported_arguments_refused(self):
        r=self.run_install('--remove-everything');self.assertNotEqual(r.returncode,0)
    def test_receipt_has_private_permissions(self):
        self.install();self.assertEqual(stat.S_IMODE(self.receipt.stat().st_mode),0o600)

if __name__=='__main__':unittest.main()
