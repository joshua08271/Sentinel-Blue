"""Actual all-down service provisioning with two owned loopback HTTP processes."""
import copy
import hashlib
import json
import os
from pathlib import Path
import shlex
import signal
import socket
import subprocess
import sys
import tempfile
import unittest

from sentinel_blue.event_profile import EventProfile
from sentinel_blue.probes import run_probe
from sentinel_blue.setup import SetupRunner, compile_plan, plan_digest
from tests.test_setup import fixture


@unittest.skipIf(os.name != 'posix', 'real bash/process fixture')
class ColdStartProcesses(unittest.TestCase):
    def test_two_down_services_install_content_start_and_verify_without_prompts(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            inventory, profile = fixture(root, hosts=2, budget=20)
            raw = copy.deepcopy(profile.raw)
            pids = []
            try:
                for index, host in enumerate(inventory['hosts']):
                    with socket.socket() as sock:
                        sock.bind((host['address'], 0))
                        port = sock.getsockname()[1]
                    service = raw['services'][index]
                    body = 'cold-start-content-' + str(index)
                    probe = {'kind':'http', 'target':f"http://{host['address']}:{port}/index.html",
                             'expected_body':body, 'expected_status':[200], 'timeout':1}
                    service.update(port=port, expected_transactions=[probe])
                    self.assertFalse(run_probe(probe, ['127.0.0.0/8']).healthy)
                    webroot = root / f'web-{index}'
                    pidfile = root / f'pid-{index}'
                    pids.append(pidfile)
                    helper = root / f'create-{index}.py'
                    helper.write_text('import pathlib,subprocess,sys\n'
                        + f'root=pathlib.Path({str(webroot)!r}); root.mkdir()\n'
                        + f'(root/"index.html").write_text({body!r})\n'
                        + f'child=subprocess.Popen({[sys.executable,"-m","http.server",str(port),"--bind",host["address"],"--directory",str(webroot)]!r}, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)\n'
                        + f'pathlib.Path({str(pidfile)!r}).write_text(str(child.pid))\n')
                    check = root / f'check-{index}.sh'
                    check.write_text('test -f ' + shlex.quote(str(webroot/'index.html')) + '\n')
                    apply = root / f'apply-{index}.sh'
                    apply.write_text(shlex.join([sys.executable,str(helper)])+'\n')
                    undo = root / f'undo-{index}.py'
                    undo.write_text('import pathlib,os,signal,shutil\n'
                        + f'root=pathlib.Path({str(webroot)!r}); pidfile=pathlib.Path({str(pidfile)!r})\n'
                        + f'assert (root/"index.html").read_text()=={body!r}\n'
                        + 'pid=int(pidfile.read_text())\n'
                        + 'cmd=pathlib.Path(f"/proc/{pid}/cmdline").read_bytes().split(bytes([0]))\n'
                        + f'assert {str(webroot).encode()!r} in cmd and b"http.server" in cmd\n'
                        + 'os.kill(pid,signal.SIGTERM)\n'
                        + '(root/"index.html").unlink(); root.rmdir(); pidfile.unlink()\n')
                    rollback = root / f'rollback-{index}.sh'
                    rollback.write_text(shlex.join([sys.executable,str(undo)])+'\n')
                    task = inventory['setup']['tasks'][index]
                    task.update(timeout_seconds=12, health_wait_seconds=8,
                        options={phase:{'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
                                 for phase,path in [('check',check),('apply',apply),('rollback',rollback)]})
                profile = EventProfile.from_dict(raw)
                plan = compile_plan(inventory, profile, root)
                report = SetupRunner(plan, profile).execute(root/'state', plan_digest(plan))
                self.assertEqual(report['status'], 'ready', report)
                self.assertTrue(all(row['changed'] for row in report['tasks'].values()))
                before = [p.read_text() for p in pids]
                resumed = SetupRunner(plan, profile).execute(root/'state', plan_digest(plan), resume=True)
                self.assertEqual(resumed['status'], 'ready', resumed)
                self.assertEqual([p.read_text() for p in pids], before)
                for service in raw['services']:
                    self.assertTrue(run_probe(service['expected_transactions'][0], ['127.0.0.0/8']).healthy)
            finally:
                for path in pids:
                    if path.exists():
                        try:
                            os.kill(int(path.read_text()), signal.SIGTERM)
                        except ProcessLookupError:
                            pass
