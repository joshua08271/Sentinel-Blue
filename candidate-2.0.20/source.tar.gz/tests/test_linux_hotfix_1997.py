"""Issues 9-14: real private files/processes with inert native network controls.

Never invokes native systemd, nft, sysctl or route mutations. Native lifecycle
acceptance, remote hosts and Windows are outside these fixtures.
"""
from __future__ import annotations
import base64
import copy
from contextlib import ExitStack
import hashlib
import json
import os
from pathlib import Path
import socket
import stat
import subprocess
import sys
import tempfile
import threading
import time
import types
import unittest
from unittest.mock import patch

from sentinel_blue import actions, collectors, network_native as net, probes
from sentinel_blue import route_check_native as witness, setup_transport as transport
from sentinel_blue.mutation_ledger import MutationLedger
from sentinel_blue.protocol import ProbeResult
from sentinel_blue.withdrawal_router import RouterAdapter
from sentinel_blue.withdrawal_native import semantic

POSIX_ROOT = os.name == 'posix' and hasattr(os, 'geteuid') and os.geteuid() == 0
ROUTE = {'destination': '192.0.2.0/24', 'via': '198.51.100.1', 'interface': 'fixture0'}
ADDRESS = {'interface': 'fixture0', 'address': '198.51.100.2/24'}


class RouterModel:
    def __init__(self, root):
        self.root = root
        self.service = 'sentinel-router-fixture'
        self.table = None
        self.routes = {}
        self.addresses = {}
        self.forwarding = '0'
        self.enabled = set()
        self.active = set()
        self.events = []
        self.hook = None
        self.unit = root / (self.service + '.service')
        self.spec = {'name': 'fixture', 'forwarding': False, 'routes': [], 'addresses': [],
                     'rollback_seconds': 120, 'ruleset': 'table inet sentinel_blue_fixture { }\n'}
        self.units = {self.unit: 'unit fixture\n', root/(self.service+'-rollback.timer'): 'timer fixture\n',
                      root/(self.service+'-rollback.service'): 'rollback fixture\n'}

    def command(self, argv, data=None, **kw):
        self.events.append((list(argv), data))
        if self.hook is not None:
            self.hook(argv, data)
        output, rc = '', 0
        if argv[0] == 'systemctl':
            verb, name = argv[1], argv[-1]
            if verb == 'enable':
                self.enabled.add(name)
                if '--now' in argv:
                    self.active.add(name)
            elif verb == 'disable':
                self.enabled.discard(name)
                self.active.discard(name)
            elif verb == 'is-enabled':
                rc = 0 if name in self.enabled else 1
            elif verb == 'is-active':
                rc = 0 if name in self.active else 1
            elif verb != 'daemon-reload':
                raise AssertionError('Unmodeled service operation')
        elif argv == ['nft', '--file', '-']:
            lines = data.splitlines(keepends=True)
            if lines and lines[0].startswith('delete table'):
                lines = lines[1:]
            self.table = ''.join(lines) or None
        elif argv == ['nft', '--check', '--file', '-']:
            pass
        elif argv[0] == 'sysctl':
            self.forwarding = argv[-1].split('=')[-1]
        elif argv[:5] == ['ip', '-j', '-4', 'route', 'show']:
            output = json.dumps(self.routes.get(argv[-1], []))
        elif argv[:5] == ['ip', '-j', '-4', 'address', 'show']:
            output = json.dumps([{'ifname': argv[-1], 'addr_info': self.addresses.get(argv[-1], [])}])
        elif argv[:3] == ['ip', '-4', 'route']:
            operation, destination, via, interface = argv[3], argv[4], argv[6], argv[8]
            if operation == 'add':
                self.routes[destination] = [{'dst': destination, 'gateway': via, 'dev': interface, 'protocol': 'boot'}]
            elif operation == 'del':
                self.routes.pop(destination, None)
            else:
                raise AssertionError('Unmodeled route operation')
        elif argv[:3] == ['ip', '-4', 'address']:
            operation, cidr, interface = argv[3], argv[4], argv[6]
            address, prefix = cidr.split('/')
            row = {'local': address, 'prefixlen': int(prefix), 'scope': 'global', 'family': 'inet'}
            if operation == 'add':
                self.addresses.setdefault(interface, []).append(row)
            elif operation == 'del':
                self.addresses[interface] = [v for v in self.addresses.get(interface, []) if v != row]
            else:
                raise AssertionError('Unmodeled address operation')
        else:
            raise AssertionError('Unmodeled native operation: '+repr(argv))
        return subprocess.CompletedProcess(argv, rc, output, '')

    def enter(self, stack):
        stack.enter_context(patch.object(net, 'names', return_value=(self.root, self.service, 'sentinel_blue_fixture')))
        stack.enter_context(patch.object(net, 'units', return_value=self.units))
        stack.enter_context(patch.object(net, 'command', side_effect=self.command))
        stack.enter_context(patch.object(net, 'table_data', side_effect=lambda *a, **kw: self.table))
        stack.enter_context(patch.object(net, 'table_fingerprint', side_effect=lambda _: net.digest(self.table) if self.table is not None else None))
        if hasattr(net, 'forwarding_value'):
            stack.enter_context(patch.object(net, 'forwarding_value', side_effect=lambda: self.forwarding))
        stack.enter_context(patch.dict(os.environ, {'SENTINEL_LEDGER_DIR': str(self.root/'ledger')}))

    def state(self):
        return json.loads(net.read(self.root/'state.json'))

    def mutations(self):
        return [a for a, _ in self.events if (a[:3] in (['ip','-4','route'], ['ip','-4','address'])
                 or a == ['nft','--file','-'] or a[0] == 'sysctl')]


@unittest.skipUnless(POSIX_ROOT, 'Private root-owned POSIX fixture')
class RouterOwnership1997(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.root = Path(self.stack.enter_context(tempfile.TemporaryDirectory(prefix='sb-hotfix1997-', dir='/var/lib')))
        self.model = RouterModel(self.root)
        self.model.enter(self.stack)
        self.spec = self.model.spec

    def test_early_failure_preserves_teammate_file_and_never_written_route(self):
        self.spec['routes'] = [ROUTE]
        fired = []
        def hook(argv, data):
            if argv == ['systemctl','daemon-reload'] and not fired:
                fired.append(True)
                self.model.unit.write_text('TEAMMATE\n')
                self.model.routes[ROUTE['destination']] = [{'gateway':ROUTE['via'], 'dev':ROUTE['interface']}]
                raise RuntimeError('controlled early reload failure')
        self.model.hook = hook
        with self.assertRaises((ValueError, RuntimeError)):
            net.run('apply', self.spec, 'helper')
        self.assertEqual(self.model.unit.read_text(), 'TEAMMATE\n')
        self.assertTrue(self.model.routes[ROUTE['destination']])
        self.assertEqual(self.model.mutations(), [])
        self.assertEqual(self.model.state()['status'], 'pending')
        self.assertIn('rollback_hold', self.model.state())

    def test_early_failure_without_conflict_cleans_only_owned_files(self):
        fired = []
        def hook(argv, data):
            if argv == ['systemctl','daemon-reload'] and not fired:
                fired.append(True)
                raise RuntimeError('controlled early failure')
        self.model.hook = hook
        with self.assertRaisesRegex(RuntimeError, 'early failure'):
            net.apply(self.spec, None, 'helper')
        self.assertFalse(self.model.unit.exists())
        self.assertFalse((self.root/'native.py').exists())
        self.assertEqual(self.model.mutations(), [])
        self.assertFalse(any(a[0]=='systemctl' and a[1]=='disable' for a, _ in self.model.events))

    def test_never_written_matching_address_and_route_are_preserved(self):
        self.spec.update(routes=[ROUTE], addresses=[ADDRESS])
        fired = []
        def hook(argv, data):
            if argv == ['systemctl','daemon-reload'] and not fired:
                fired.append(True)
                self.model.routes[ROUTE['destination']] = [{'gateway':ROUTE['via'], 'dev':ROUTE['interface']}]
                self.model.addresses['fixture0'] = [{'local':'198.51.100.2','prefixlen':24}]
                raise RuntimeError('controlled before network installation')
        self.model.hook = hook
        with self.assertRaises(RuntimeError):
            net.apply(self.spec, None, 'helper')
        self.assertTrue(self.model.routes[ROUTE['destination']])
        self.assertTrue(self.model.addresses['fixture0'])
        self.assertEqual(self.model.mutations(), [])

    def test_missing_file_post_receipt_holds_instead_of_deleting(self):
        net.apply(self.spec, None, 'helper')
        state = self.model.state()
        state['changes']['files'][str(self.model.unit)].pop('after')
        count = len(self.model.mutations())
        with self.assertRaisesRegex(ValueError, 'uncertain'):
            net.rollback(self.spec, state)
        self.assertTrue(self.model.unit.exists())
        self.assertEqual(len(self.model.mutations()), count)

    def test_metadata_edit_holds_all_inverse_writes(self):
        net.apply(self.spec, None, 'helper')
        self.model.unit.chmod(0o644)
        count = len(self.model.mutations())
        with self.assertRaisesRegex(ValueError, 'changed'):
            net.rollback(self.spec, self.model.state())
        self.assertEqual(len(self.model.mutations()), count)
        self.assertEqual(stat.S_IMODE(self.model.unit.stat().st_mode), 0o644)

    def test_same_byte_rewrite_is_detected(self):
        net.apply(self.spec, None, 'helper')
        self.model.unit.write_bytes(self.model.unit.read_bytes())
        with self.assertRaisesRegex(ValueError, 'changed'):
            net.rollback(self.spec, self.model.state())
        self.assertTrue(self.model.unit.exists())

    def test_symlink_substitution_is_preserved(self):
        net.apply(self.spec, None, 'helper')
        other = self.root/'outside';other.write_text('OUTSIDE')
        self.model.unit.unlink();self.model.unit.symlink_to(other)
        with self.assertRaises((OSError, ValueError)):
            net.rollback(self.spec, self.model.state())
        self.assertTrue(self.model.unit.is_symlink())
        self.assertEqual(other.read_text(), 'OUTSIDE')

    def test_owned_routes_addresses_and_table_are_reversed(self):
        self.spec.update(routes=[ROUTE], addresses=[ADDRESS], forwarding=True)
        net.apply(self.spec, None, 'helper')
        net.rollback(self.spec, self.model.state())
        self.assertFalse(self.model.routes)
        self.assertFalse(self.model.addresses.get('fixture0'))
        self.assertIsNone(self.model.table)
        self.assertEqual(self.model.forwarding, '0')
        self.assertFalse(self.model.unit.exists())

    def test_preexisting_network_entries_are_not_removed(self):
        self.spec.update(routes=[ROUTE], addresses=[ADDRESS])
        oldroute = [{'gateway':ROUTE['via'],'dev':ROUTE['interface'],'metric':50}]
        oldaddress = [{'local':'198.51.100.2','prefixlen':24,'scope':'global'}]
        self.model.routes[ROUTE['destination']] = copy.deepcopy(oldroute)
        self.model.addresses['fixture0'] = copy.deepcopy(oldaddress)
        net.apply(self.spec, None, 'helper')
        net.rollback(self.spec, self.model.state())
        self.assertEqual(self.model.routes[ROUTE['destination']], oldroute)
        self.assertEqual(self.model.addresses['fixture0'], oldaddress)

    def test_route_metadata_replacement_holds_before_table_rollback(self):
        self.spec['routes'] = [ROUTE]
        net.apply(self.spec, None, 'helper')
        self.model.routes[ROUTE['destination']][0]['metric'] = 123
        count = len(self.model.mutations())
        with self.assertRaisesRegex(ValueError, 'changed'):
            net.rollback(self.spec, self.model.state())
        self.assertEqual(len(self.model.mutations()), count)

    def test_table_edit_is_preserved(self):
        net.apply(self.spec, None, 'helper')
        self.model.table = 'table inet sentinel_blue_fixture { # TEAMMATE\n}\n'
        with self.assertRaisesRegex(ValueError, 'changed'):
            net.rollback(self.spec, self.model.state())
        self.assertIn('TEAMMATE', self.model.table)

    def test_failed_write_after_actual_route_change_is_held_as_ambiguous(self):
        self.spec['routes'] = [ROUTE]
        def hook(argv, data):
            if argv == net.route_argv(ROUTE, 'add'):
                self.model.routes[ROUTE['destination']] = [{'gateway':ROUTE['via'],'dev':ROUTE['interface']}]
                raise RuntimeError('failure after possible mutation')
        self.model.hook = hook
        with self.assertRaisesRegex(ValueError, 'uncertain'):
            net.apply(self.spec, None, 'helper')
        self.assertTrue(self.model.routes)
        self.assertEqual(self.model.state()['changes']['routes'][0]['status'], 'writing')
        self.assertNotIn(net.route_argv(ROUTE,'del'), self.model.mutations())

    def test_file_intent_is_durable_before_install(self):
        real = net.replace_owned_file
        def install(path, value, expected, **kw):
            state = self.model.state()
            self.assertEqual(state['changes']['files'][str(path)]['status'], 'writing')
            return real(path, value, expected, **kw)
        with patch.object(net, 'replace_owned_file', side_effect=install):
            net.apply(self.spec, None, 'helper')

    def test_boundary_change_after_restore_intent_is_not_overwritten(self):
        net.apply(self.spec, None, 'helper')
        state = self.model.state(); real = net.save;fired=[]
        def save(path, value):
            real(path, value)
            if value.get('changes',{}).get('files',{}).get(str(self.model.unit),{}).get('status')=='restoring' and not fired:
                fired.append(True);self.model.unit.write_text('BOUNDARY EDIT')
        with patch.object(net,'save',side_effect=save):
            with self.assertRaisesRegex(ValueError, 'boundary'):
                net.rollback(self.spec,state)
        self.assertEqual(self.model.unit.read_text(),'BOUNDARY EDIT')

    def test_missing_legacy_pending_ownership_holds(self):
        net.apply(self.spec,None,'helper');state=self.model.state();state.pop('changes')
        with self.assertRaisesRegex(ValueError,'ownership'):
            net.rollback(self.spec,state)
        self.assertTrue(self.model.unit.exists())

    def test_completed_rollback_can_be_retried_without_network_writes(self):
        net.apply(self.spec,None,'helper');net.rollback(self.spec,self.model.state())
        count=len(self.model.mutations());net.rollback(self.spec,self.model.state())
        self.assertEqual(len(self.model.mutations()),count)

    def test_update_rollback_preserves_complete_state_and_boot_identity(self):
        net.run('apply',self.spec,'old helper');net.run('commit',self.spec,'old helper')
        old=self.model.state();updated={**self.spec,'ruleset':'table inet sentinel_blue_fixture { # UPDATE\n}\n'}
        net.run('apply',updated,'new helper');net.run('rollback',updated,'new helper')
        self.assertEqual(self.model.state(),old)
        self.assertTrue(net.verify(self.spec,self.model.state()))
        net.run('boot',self.spec,'old helper')
        self.assertEqual((self.root/'native.py').read_text(),'old helper')
        rows=MutationLedger(self.root/'ledger').actions()
        self.assertEqual([row['status'] for row in rows],['committed','cancelled'])

    def test_update_rollback_keeps_prior_withdrawal_usable_without_reboot(self):
        net.run('apply',self.spec,'old helper');net.run('commit',self.spec,'old helper')
        updated={**self.spec,'ruleset':'table inet sentinel_blue_fixture { # UPDATE\n}\n'}
        net.run('apply',updated,'new helper');net.run('rollback',updated,'new helper')
        ledger=MutationLedger(self.root/'ledger')
        action=next(x for x in ledger.actions(include_states=True) if x['status']=='committed')
        after=RouterAdapter(ledger).restore(action['target'],action['before'],action['after'])
        self.assertEqual(semantic(after),semantic(action['before']))
        self.assertFalse(self.model.unit.exists())

    def test_legacy_committed_withdrawal_reconstructs_journal_from_ledger(self):
        net.run('apply',self.spec,'old helper');net.run('commit',self.spec,'old helper')
        state=self.model.state();state.pop('changes');net.save(self.root/'state.json',state)
        ledger=MutationLedger(self.root/'ledger');action=ledger.actions(include_states=True)[0]
        RouterAdapter(ledger).restore(action['target'],action['before'],action['after'])
        self.assertIsNone(self.model.table)

    def test_unauthenticated_boot_still_refused(self):
        net.apply(self.spec,None,'helper');state=self.model.state();state['status']='committed'
        state['ledger_action_id']='does-not-exist';net.save(self.root/'state.json',state)
        with self.assertRaisesRegex(ValueError,'authenticated ownership'):
            net.run('boot',self.spec,'helper')

    def test_boot_audit_does_not_replace_original_withdrawal_prestate(self):
        net.run('apply',self.spec,'old');net.run('commit',self.spec,'old')
        ledger=MutationLedger(self.root/'ledger')
        original_before_hash=ledger.actions()[0]['before_hash']
        net.run('boot',self.spec,'old')
        action=ledger.actions(include_states=True)[0]
        self.assertEqual(action['before_hash'],original_before_hash)
        RouterAdapter(ledger).restore(action['target'],action['before'],action['after'])
        self.assertFalse(self.model.unit.exists())
        self.assertIsNone(self.model.table)

    def test_modified_table_backup_refuses_before_inverse_write(self):
        net.apply(self.spec,None,'helper');state=self.model.state()
        state['before']['table']='table inet sentinel_blue_fixture { # NOT THE BACKUP\n}\n'
        count=len(self.model.mutations())
        with self.assertRaisesRegex(ValueError,'inverse differs'):
            net.rollback(self.spec,state)
        self.assertEqual(len(self.model.mutations()),count)

    def test_modified_file_backup_refuses_before_inverse_write(self):
        net.apply(self.spec,None,'helper');state=self.model.state()
        state['before']['files'][str(self.model.unit)]=base64.b64encode(b'UNTRUSTED').decode()
        count=len(self.model.mutations())
        with self.assertRaisesRegex(ValueError,'inverse differs'):
            net.rollback(self.spec,state)
        self.assertEqual(len(self.model.mutations()),count)

    def test_unknown_service_control_outcome_is_held(self):
        net.apply(self.spec,None,'helper');state=self.model.state()
        state['controls']['timer']='writing';count=len(self.model.mutations())
        with self.assertRaisesRegex(ValueError,'service-control outcome'):
            net.rollback(self.spec,state)
        self.assertEqual(len(self.model.mutations()),count)

    def test_pending_commit_does_not_adopt_metadata_change(self):
        net.run('apply',self.spec,'helper');self.model.unit.chmod(0o644)
        with self.assertRaisesRegex(ValueError,'changed before confirmation'):
            net.run('commit',self.spec,'helper')
        self.assertEqual(self.model.state()['status'],'pending')
        self.assertEqual(MutationLedger(self.root/'ledger').actions()[0]['status'],'applied')

    def test_staged_replace_refuses_symlink_parent(self):
        outside=self.root/'other';outside.mkdir();alias=self.root/'alias';alias.symlink_to(outside)
        with self.assertRaisesRegex(ValueError,'trusted root-owned directories'):
            net.replace_owned_file(alias/'file',b'NEW',None)
        self.assertFalse((outside/'file').exists())

    def test_too_large_prior_state_refuses_before_helper_change(self):
        net.run('apply',self.spec,'old');net.run('commit',self.spec,'old')
        state=self.model.state();state['oversized_fixture']='x'*(4*1024*1024)
        updated={**self.spec,'ruleset':'table inet sentinel_blue_fixture { # UPDATED\n}\n'}
        before=(self.root/'native.py').read_bytes()
        with self.assertRaisesRegex(ValueError,'read limit'):
            net.apply(updated,state,'new')
        self.assertEqual((self.root/'native.py').read_bytes(),before)


class ValidationDeadline1997(unittest.TestCase):
    def setUp(self):
        self.executor=types.SimpleNamespace(authorized_networks=['127.0.0.0/8'],authorized_hosts=[],excluded_hosts=[])
        self.spec={'name':'fixture','kind':'tcp','target':'127.0.0.1','port':12345}
        self.good=ProbeResult('fixture','127.0.0.1',True)

    def run_clock(self,durations,*,grace=5):
        clock=[0.0];calls=[]
        def batch(*a,**kw):
            calls.append((clock[0],kw.get('deadline')))
            clock[0]+=durations[min(len(calls)-1,len(durations)-1)]
            return [self.good]
        timer=types.SimpleNamespace(monotonic=lambda:clock[0],sleep=lambda n:clock.__setitem__(0,clock[0]+n))
        with patch.object(actions,'run_probes',side_effect=batch),patch.object(actions,'time',timer):
            result=actions.ActionExecutor._wait_for_service_probes(self.executor,[self.spec],grace_seconds=grace)
        return result,clock,calls

    def test_late_positive_batch_does_not_satisfy_validation(self):
        result,clock,calls=self.run_clock([2])
        self.assertFalse(result[2]);self.assertGreater(clock[0],5)
        self.assertTrue(all(deadline==5 for _,deadline in calls))
        self.assertTrue(all(start<5 for start,_ in calls))

    def test_on_time_confirmations_pass(self):
        result,clock,calls=self.run_clock([.1])
        self.assertTrue(result[2]);self.assertLess(clock[0],5)
        self.assertEqual(result[1],actions.SERVICE_RECOVERY_HEALTHY_CONFIRMATIONS)

    def test_zero_budget_never_launches_a_batch(self):
        result,clock,calls=self.run_clock([1],grace=0)
        self.assertFalse(result[2]);self.assertEqual(calls,[])

    def test_exact_deadline_is_not_accepted(self):
        result,clock,calls=self.run_clock([5])
        self.assertFalse(result[2]);self.assertEqual(len(calls),1)

    def test_expired_batch_does_not_admit_native_requests(self):
        with patch.object(probes._PROBE_REQUESTS,'run') as run:
            rows=probes.run_probes([self.spec]*32,['127.0.0.0/8'],deadline=time.monotonic()-1)
        run.assert_not_called();self.assertEqual(len(rows),32)
        self.assertTrue(all(not r.healthy and not r.executed for r in rows))

    def test_remaining_batch_budget_caps_each_request_without_timeout_floor(self):
        budgets=[]
        def run(fn,seconds):budgets.append(seconds);return self.good
        with patch.object(probes._PROBE_REQUESTS,'run',side_effect=run):
            result=probes.run_probe({**self.spec,'timeout':15},['127.0.0.0/8'],deadline=time.monotonic()+.06)
        self.assertTrue(result.healthy);self.assertGreater(budgets[0],0);self.assertLessEqual(budgets[0],.06)

    def test_late_pool_result_is_unverified(self):
        deadline=time.monotonic()+.03
        def run(*a):time.sleep(.05);return self.good
        with patch.object(probes._PROBE_REQUESTS,'run',side_effect=run):
            result=probes.run_probe(self.spec,['127.0.0.0/8'],deadline=deadline)
        self.assertFalse(result.healthy);self.assertFalse(result.executed)

    def test_real_bounded_pool_returns_within_batch_budget_when_worker_stalls(self):
        from sentinel_blue.request_deadline import BoundedRequestPool
        release=threading.Event();started=threading.Event()
        pool=BoundedRequestPool(16,label='fixture',thread_name='sb-budget-fixture')
        def stalled(*a,**kw):started.set();release.wait(1);return self.good
        start=time.monotonic()
        try:
            with patch.object(probes,'_PROBE_REQUESTS',pool),patch.object(probes,'_execute_probe',side_effect=stalled):
                rows=probes.run_probes([self.spec]*40,['127.0.0.0/8'],deadline=time.monotonic()+.10)
            elapsed=time.monotonic()-start
            self.assertTrue(started.is_set());self.assertLess(elapsed,.6)
            self.assertEqual(len(rows),40);self.assertTrue(all(not r.healthy for r in rows))
        finally:release.set()

    def test_invalid_batch_deadline_refuses(self):
        for bad in (float('nan'),float('inf'),True,'1'):
            with self.subTest(value=bad),self.assertRaises(ValueError):
                probes.run_probes([self.spec],['127.0.0.0/8'],deadline=bad)


@unittest.skipUnless(POSIX_ROOT,'Root-private POSIX file fixture')
class WitnessReads1997(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='sb-witness1997-',dir='/var/lib')
        self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name);self.path=self.root/'state.json'

    def regular(self,value=b'{"ok":true}'):
        self.path.write_bytes(value);self.path.chmod(0o600)

    def test_fifo_refuses_without_waiting_for_writer(self):
        os.mkfifo(self.path,0o600)
        code='from pathlib import Path;from sentinel_blue.route_check_native import read;read(Path('+repr(str(self.path))+'))'
        child=subprocess.Popen([sys.executable,'-c',code],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        try:
            out,err=child.communicate(timeout=2)
            self.assertNotEqual(child.returncode,0);self.assertIn(b'Untrusted route witness record',err)
        finally:
            if child.poll() is None:child.kill();child.communicate()

    def test_regular_record_works(self):
        self.regular();self.assertEqual(witness.read(self.path),{'ok':True})

    def test_symlink_refuses_without_following(self):
        other=self.root/'other';other.write_text('{}');self.path.symlink_to(other)
        with self.assertRaises(OSError):witness.read(self.path)

    def test_hardlink_refuses(self):
        self.regular();os.link(self.path,self.root/'hardlink')
        with self.assertRaises(ValueError):witness.read(self.path)

    def test_directory_refuses(self):
        self.path.mkdir()
        with self.assertRaises(ValueError):witness.read(self.path)

    def test_permissions_refuse(self):
        self.regular();self.path.chmod(0o644)
        with self.assertRaises(ValueError):witness.read(self.path)

    def test_oversized_record_refuses(self):
        self.regular(b' '*65537)
        with self.assertRaises(ValueError):witness.read(self.path)

    def test_same_bytes_replacement_during_read_refuses(self):
        self.regular();real=os.read;fired=[]
        def read(fd,n):
            value=real(fd,n)
            if not fired:
                fired.append(True);other=self.root/'replacement';other.write_bytes(self.path.read_bytes());other.chmod(0o600);os.replace(other,self.path)
            return value
        with patch.object(witness.os,'read',side_effect=read),self.assertRaisesRegex(ValueError,'changed'):
            witness.read(self.path)

    def test_growth_during_read_cannot_exceed_limit(self):
        self.regular();real=os.read;fired=[]
        def read(fd,n):
            if not fired:
                fired.append(True)
                with self.path.open('ab') as f:f.write(b' '*65537)
            return real(fd,n)
        with patch.object(witness.os,'read',side_effect=read),self.assertRaisesRegex(ValueError,'read limit'):
            witness.read(self.path)


class PrimaryGroups1997(unittest.TestCase):
    def run_case(self,*,enumeration_fails=True,primary=27,member='',query=None):
        user=types.SimpleNamespace(pw_name='fixtureadmin',pw_uid=12345,pw_gid=primary,pw_shell='/bin/bash')
        def group_entries():
            if enumeration_fails:raise OSError('controlled enumeration failure')
            return [types.SimpleNamespace(gr_name='users',gr_gid=100,gr_mem=['fixtureadmin'])]
        def getent(argv,**kw):
            return subprocess.CompletedProcess(argv,0 if argv[-1]=='sudo' else 2,'sudo:x:27:'+member+'\n' if argv[-1]=='sudo' else '', '')
        errors=[]
        with patch.object(collectors,'pwd',types.SimpleNamespace(getpwall=lambda:[user])),patch.object(collectors,'grp',types.SimpleNamespace(getgrall=group_entries)),patch.object(collectors,'_run',side_effect=query or getent):
            result=collectors._linux_accounts(errors)[0]
        return result,errors

    def test_primary_privileged_group_survives_bulk_enumeration_failure(self):
        account,errors=self.run_case()
        self.assertTrue(account.privileged);self.assertIn('sudo',account.groups);self.assertTrue(errors)

    def test_supplementary_membership_survives_bulk_failure(self):
        account,errors=self.run_case(primary=100,member='fixtureadmin')
        self.assertTrue(account.privileged);self.assertIn('sudo',account.groups);self.assertTrue(errors)

    def test_unknown_membership_is_reported_not_silent(self):
        account,errors=self.run_case(primary=100)
        self.assertFalse(account.privileged);self.assertTrue(any('incomplete' in e for e in errors))

    def test_missing_distribution_groups_are_not_errors(self):
        account,errors=self.run_case(enumeration_fails=False)
        self.assertTrue(account.privileged);self.assertEqual(errors,[])

    def test_non_missing_lookup_failure_reports_incomplete_coverage(self):
        account,errors=self.run_case(enumeration_fails=False,query=lambda argv,**kw:subprocess.CompletedProcess(argv,1,'',''))
        self.assertTrue(errors)

    def test_malformed_known_group_is_not_accepted(self):
        account,errors=self.run_case(enumeration_fails=False,query=lambda argv,**kw:subprocess.CompletedProcess(argv,0,'sudo:x:INVALID:fixtureadmin',''))
        self.assertFalse(account.privileged);self.assertTrue(errors)

    def test_query_timeout_does_not_suppress_other_known_group_evidence(self):
        def query(argv,**kw):
            if argv[-1]=='sudo':raise subprocess.TimeoutExpired(argv,1)
            return subprocess.CompletedProcess(argv,0 if argv[-1]=='wheel' else 2,'wheel:x:27:\n' if argv[-1]=='wheel' else '', '')
        account,errors=self.run_case(enumeration_fails=False,query=query)
        self.assertTrue(account.privileged);self.assertIn('wheel',account.groups);self.assertTrue(errors)


@unittest.skipUnless(os.name=='posix','Owned POSIX processes')
class OutputBounds1997(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='sb-output1997-');self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
        self.grace=patch.object(transport,'PROCESS_TERMINATION_GRACE',.05);self.grace.start();self.addCleanup(self.grace.stop)

    def run_output(self,n,**kw):
        return transport.run_process([sys.executable,'-c',f'import sys;sys.stdout.buffer.write(b"x"*{n})'],'',3,log_dir=self.root/'logs',**kw)

    def test_harmless_24_mib_output_is_bounded_and_uncertain(self):
        result=self.run_output(24*1024*1024)
        self.assertTrue(result.uncertain);self.assertTrue(result.output_truncated)
        self.assertEqual(result.failure_reason,'output_limit_exceeded')
        self.assertEqual(result.output_bytes,16*1024*1024)
        self.assertEqual((self.root/'logs'/result.output_log).stat().st_size,16*1024*1024)
        self.assertEqual(result.output_sha256,hashlib.sha256(b'x'*(16*1024*1024)).hexdigest())

    def test_no_output_temporary_file_is_created(self):
        real=transport.tempfile.TemporaryFile;streams=[]
        def temp(*a,**kw):
            value=real(*a,**kw);streams.append(value);return value
        with patch.object(transport.tempfile,'TemporaryFile',side_effect=temp),patch.object(transport,'MAX_COMMAND_OUTPUT_BYTES',4096):
            result=self.run_output(100000)
        self.assertEqual(len(streams),1)  # Only finite stdin, no stdout spool.
        self.assertTrue(result.uncertain);self.assertEqual(result.output_bytes,4096)

    def test_exact_quota_is_complete_not_overflow(self):
        with patch.object(transport,'MAX_COMMAND_OUTPUT_BYTES',65536):result=self.run_output(65536)
        self.assertEqual(result.returncode,0);self.assertFalse(result.uncertain);self.assertFalse(result.output_truncated)

    def test_one_byte_over_quota_is_overflow(self):
        with patch.object(transport,'MAX_COMMAND_OUTPUT_BYTES',65536):result=self.run_output(65537)
        self.assertTrue(result.uncertain);self.assertEqual(result.output_bytes,65536)

    def test_output_bounded_even_without_retained_log(self):
        with patch.object(transport,'MAX_COMMAND_OUTPUT_BYTES',4096):
            result=transport.run_process([sys.executable,'-c','import sys;sys.stdout.buffer.write(b"x"*100000)'],'',3)
        self.assertTrue(result.output_truncated);self.assertEqual(result.output_bytes,4096);self.assertIsNone(result.output_log)

    def test_silent_timeout_remains_uncertain(self):
        result=transport.run_process([sys.executable,'-c','import time;time.sleep(2)'],'',.1)
        self.assertTrue(result.uncertain);self.assertEqual(result.failure_reason,'deadline_exceeded');self.assertLess(result.seconds,1)

    def test_normal_output_retains_private_log_and_exact_digest(self):
        result=self.run_output(300)
        path=self.root/'logs'/result.output_log
        self.assertEqual(path.stat().st_mode&0o777,0o600);self.assertEqual(path.read_bytes(),b'x'*300)
        self.assertEqual(result.output_sha256,hashlib.sha256(b'x'*300).hexdigest());self.assertFalse(result.uncertain)

    def test_stderr_shares_capture_quota(self):
        with patch.object(transport,'MAX_COMMAND_OUTPUT_BYTES',4096):
            result=transport.run_process([sys.executable,'-c','import sys;sys.stderr.buffer.write(b"x"*100000)'],'',3)
        self.assertTrue(result.uncertain);self.assertEqual(result.output_bytes,4096)

    def test_overflow_kills_term_ignoring_descendant_after_leader_exits(self):
        marker=self.root/'late'
        code='import os,sys,signal,time\np=os.fork()\nif p: sys.exit(0)\nsignal.signal(signal.SIGTERM,signal.SIG_IGN)\nos.write(1,b"x"*8000)\ntime.sleep(.4)\nopen('+repr(str(marker))+',"w").write("late")\n'
        with patch.object(transport,'MAX_COMMAND_OUTPUT_BYTES',4096):
            result=transport.run_process([sys.executable,'-c',code],'',2)
        self.assertTrue(result.uncertain);time.sleep(.45);self.assertFalse(marker.exists())

    def test_closed_stdout_but_live_process_is_still_timed_out(self):
        code='import os,time;os.close(1);os.close(2);time.sleep(2)'
        result=transport.run_process([sys.executable,'-c',code],'',.1)
        self.assertTrue(result.uncertain);self.assertLess(result.seconds,1)

    def test_nonzero_exit_without_overflow_is_not_mislabeled(self):
        result=transport.run_process([sys.executable,'-c','import sys;print("fixture");sys.exit(7)'],'',2)
        self.assertEqual(result.returncode,7);self.assertFalse(result.uncertain);self.assertFalse(result.output_truncated)


if __name__=='__main__':unittest.main()
