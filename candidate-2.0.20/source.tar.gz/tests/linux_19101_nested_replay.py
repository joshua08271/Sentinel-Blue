"""Exercise native scoring's own nested capture, with an inert fake ping."""
import os,sys,pathlib,tempfile,time,json,signal,subprocess
from unittest.mock import patch
from sentinel_blue import native_probes as np

def main(output):
 with tempfile.TemporaryDirectory(prefix='sb-nested-capture-') as d:
  root=pathlib.Path(d); pidfile=root/'pid.json';marker=root/'completed'; worker=root/'ping'
  worker.write_text('#!'+sys.executable+'\nimport os,time,pathlib,json\n'
   +'pathlib.Path('+repr(str(pidfile))+').write_text(json.dumps({"pid":os.getpid(),"pgid":os.getpgrp(),"ppid":os.getppid()}))\n'
   +'time.sleep(5.0)\npathlib.Path('+repr(str(marker))+').write_text("harmless fixture finished")\n')
  worker.chmod(0o700);start=time.monotonic()
  try:
   with patch.dict(os.environ,{'PATH':d+':'+os.environ['PATH']}):
    try:np.run_native_probe('icmp',{},'127.0.0.1',3.0); result='success'
    except Exception as e:result=type(e).__name__+':'+str(e)
   elapsed=time.monotonic()-start; pid=json.loads(pidfile.read_text()) if pidfile.exists() else None
   alive=False
   if pid:
    try:os.kill(pid['pid'],0);alive=True
    except ProcessLookupError:pass
   at_return=marker.exists();time.sleep(3.5)
   r={'origin':np.__file__,'outcome':result,'seconds_at_return':elapsed,'child':pid,'child_exists_at_return':alive,'marker_at_return':at_return,'marker_after_return':marker.exists(),'scope':'real run_native_probe and nested captures; fake ping never opens a socket or sends traffic'}
   pathlib.Path(output).write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
  finally:
   if pidfile.exists():
    pid=json.loads(pidfile.read_text())
    try:os.killpg(pid['pgid'],signal.SIGKILL)
    except ProcessLookupError:pass
if __name__=='__main__':main(sys.argv[1])
