"""Issues 26-30: real private files/ledgers/processes; inert native controls.

No target service, network configuration, login, cloud account or online software
source is used. Legacy source is frozen only to check safe upgrade admission.
"""
from contextlib import ExitStack
import copy
import hashlib
import json
import os
from pathlib import Path
import signal
import shlex
import subprocess
import sys
import tempfile
import time
import types
import unittest
import uuid
from unittest.mock import patch

from sentinel_blue import setup_linux_transaction as tx, bounded_capture as cap, native_probes as np
from sentinel_blue.mutation_ledger import MutationLedger
from sentinel_blue.withdrawal import _restore_one
from sentinel_blue.identity_guard import analyze_protected_access, _linux_native_uid_matches
from sentinel_blue.risk import RiskModel
from sentinel_blue.telemetry_diagnostics import normalize_diagnostics, merge_health_diagnostics
from linux_19101_review_cases import setup_fixture, protected_session
from linux_19101_health_replay import replay as health_replay


@unittest.skipUnless(os.name == 'posix' and os.geteuid() == 0, 'root-owned private fixtures')
class ServiceConfirmation19101(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack(); self.addCleanup(self.stack.close)
        self.root,self.path,self.spec,self.token,self.ledger,self.run,self.state = self.stack.enter_context(setup_fixture())

    def rows(self): return self.ledger.actions(include_states=True)
    def claims(self): return list(tx.ROOT.glob('resource-*.json'))
    def initial(self): self.run('apply')
    def committed(self):
        self.run('commit')
        self.assertEqual(self.state()['status'], 'committed')
        self.assertEqual(self.rows()[0]['status'], 'committed')
        self.assertFalse(self.claims())
    def withdraw(self):
        self.ledger.pause('private-withdraw')
        _restore_one(self.ledger, 'setup-'+self.token)
        self.assertEqual(self.path.read_text(),'BEFORE\n')
        self.assertEqual(self.rows()[0]['status'],'undone')
    def stop_commit(self, after=False):
        self.initial(); original = MutationLedger.commit
        def fault(ledger,*a,**kw):
            if after: original(ledger,*a,**kw)
            raise RuntimeError('controlled commit boundary')
        with patch.object(MutationLedger,'commit',new=fault), self.assertRaises(RuntimeError):self.run('commit')
    def stop_publication(self, after=False):
        self.initial(); original = tx.save
        def fault(path,value):
            if path == tx.ROOT/self.token/'state.json' and value.get('status') == 'committed':
                if after: original(path,value)
                raise RuntimeError('controlled native publication')
            return original(path,value)
        with patch.object(tx,'save',side_effect=fault), self.assertRaises(RuntimeError):self.run('commit')
    def rewrite(self):
        other=self.root/'outside';other.write_bytes(self.path.read_bytes());other.chmod(0o644);os.replace(other,self.path)

    def test_clean_apply_commit_and_withdraw(self):
        self.initial(); self.committed(); self.withdraw()
    def test_confirmation_retry_is_idempotent(self):
        self.initial();self.committed();head=self.ledger.head();self.run('commit');self.assertEqual(head,self.ledger.head())
    def test_failure_before_ledger_decision_keeps_applied_state_and_claims(self):
        self.stop_commit();self.assertEqual(self.state()['status'],'applied');self.assertEqual(self.rows()[0]['status'],'applied');self.assertTrue(self.claims());self.committed()
    def test_failure_after_durable_ledger_decision_retries(self):
        self.stop_commit(True);self.assertEqual(self.rows()[0]['status'],'committed');self.assertEqual(self.state()['status'],'applied');self.committed();self.withdraw()
    def test_failure_before_native_publication_retries(self):
        self.stop_publication();self.committed()
    def test_failure_after_native_publication_retries(self):
        self.stop_publication(True);self.committed()
    def test_failure_before_resource_release_retries(self):
        self.initial()
        with patch.object(tx,'release',side_effect=RuntimeError('release')),self.assertRaises(RuntimeError):self.run('commit')
        self.assertTrue(self.claims());self.committed()
    def test_failure_after_partial_resource_release_retries(self):
        self.initial()
        def fault(state,token):self.claims()[0].unlink();raise RuntimeError('partial release')
        with patch.object(tx,'release',side_effect=fault),self.assertRaises(RuntimeError):self.run('commit')
        self.assertTrue(self.claims());self.committed()
    def test_failure_after_resource_release_retries(self):
        self.initial();real=tx.release
        def fault(*a):real(*a);raise RuntimeError('release acknowledgement')
        with patch.object(tx,'release',side_effect=fault),self.assertRaises(RuntimeError):self.run('commit')
        self.assertFalse(self.claims());self.committed()
    def test_missing_publication_acknowledgement_retries(self):
        self.initial();real=MutationLedger.append
        def fault(ledger,kind,**kw):
            if kind=='setup_confirmation_published':raise RuntimeError('acknowledgement')
            return real(ledger,kind,**kw)
        with patch.object(MutationLedger,'append',new=fault),self.assertRaises(RuntimeError):self.run('commit')
        self.committed()
    def test_durable_publication_acknowledgement_is_not_duplicated(self):
        self.initial();real=MutationLedger.append
        def fault(ledger,kind,**kw):
            result=real(ledger,kind,**kw)
            if kind=='setup_confirmation_published':raise RuntimeError('acknowledgement')
            return result
        with patch.object(MutationLedger,'append',new=fault),self.assertRaises(RuntimeError):self.run('commit')
        head=self.ledger.head();self.committed();self.assertEqual(head,self.ledger.head())
    def test_intent_failure_does_not_publish_or_release(self):
        self.initial();real=MutationLedger.append
        def fault(ledger,kind,**kw):
            if kind=='setup_confirmation_intent':raise RuntimeError('intent')
            return real(ledger,kind,**kw)
        with patch.object(MutationLedger,'append',new=fault),self.assertRaises(RuntimeError):self.run('commit')
        self.assertEqual(self.state()['status'],'applied');self.assertEqual(self.rows()[0]['status'],'applied');self.assertTrue(self.claims());self.committed()
    def test_durable_intent_can_be_retried(self):
        self.initial();real=MutationLedger.append
        def fault(ledger,kind,**kw):
            result=real(ledger,kind,**kw)
            if kind=='setup_confirmation_intent':raise RuntimeError('intent acknowledgement')
            return result
        with patch.object(MutationLedger,'append',new=fault),self.assertRaises(RuntimeError):self.run('commit')
        self.committed();self.assertEqual(sum(e['kind']=='setup_confirmation_intent' for e in self.ledger.read()),1)
    def test_before_decision_failure_can_rollback(self):
        self.stop_commit();self.run('rollback');self.assertEqual(self.path.read_text(),'BEFORE\n');self.assertEqual(self.rows()[0]['status'],'cancelled')
    def test_after_decision_pending_rollback_cannot_undo_commit(self):
        self.stop_commit(True)
        with self.assertRaisesRegex(ValueError,'committed'):self.run('rollback')
        self.assertEqual(self.path.read_text(),'AFTER\n');self.committed();self.withdraw()
    def test_unpublished_decision_blocks_fresh_admission(self):
        self.stop_publication()
        with self.assertRaisesRegex(ValueError,'confirmation'):self.run('admit',uuid.uuid4().hex)
        with self.assertRaisesRegex(ValueError,'confirmation'):self.run('apply',uuid.uuid4().hex)
        self.assertEqual(len(self.rows()),1);self.committed()
    def test_changed_file_after_decision_is_not_published(self):
        self.stop_commit(True);self.rewrite()
        with self.assertRaises(ValueError):self.run('commit')
        self.assertEqual(self.path.read_text(),'AFTER\n');self.assertTrue(self.claims())
    def test_changed_metadata_after_decision_is_preserved(self):
        self.stop_commit(True);self.path.chmod(0o600)
        with self.assertRaises(ValueError):self.run('commit')
        self.assertEqual(self.path.stat().st_mode&0o777,0o600)
    def test_altered_lifecycle_record_cannot_be_published(self):
        self.stop_commit(True);state=self.state();state['unexpected']='outside';tx.save(tx.ROOT/self.token/'state.json',state)
        with self.assertRaises(ValueError):self.run('commit')
        self.assertEqual(self.state()['unexpected'],'outside')
    def test_intent_cannot_authorize_another_specification(self):
        self.stop_commit();other=copy.deepcopy(self.spec);other['service']='different.service'
        with self.assertRaises(ValueError):tx.run('commit',other,self.token,'bad',ledger_directory=self.root/'ledger')
        self.assertEqual(self.state()['status'],'applied')
    def test_released_claim_is_never_stolen_back(self):
        self.stop_publication(True)
        p=self.claims()[0];tx.save(p,{'transaction':'b'*32})
        with self.assertRaisesRegex(ValueError,'ownership'):self.run('commit')
        self.assertEqual(tx.read(p),{'transaction':'b'*32})
    def test_unproven_legacy_committed_label_is_not_promoted(self):
        self.initial();state=self.state();state['status']='committed';tx.save(tx.ROOT/self.token/'state.json',state)
        with self.assertRaises(ValueError):self.run('commit')
        self.assertEqual(self.rows()[0]['status'],'applied');self.assertTrue(self.claims())
    def test_native_commit_entry_without_ledger_is_refused(self):
        self.initial()
        # Exact application source is available in the authenticated spec only by
        # its hash; the private _run guard must reject any mismatched source too.
        with self.assertRaises(ValueError):tx._run('commit',self.spec,self.token,'unreviewed')
        self.assertEqual(self.rows()[0]['status'],'applied')

    def test_same_content_replacement_prevents_confirmation(self):
        self.initial();self.rewrite()
        with self.assertRaises(ValueError):self.run('commit')
        self.assertEqual(self.rows()[0]['status'],'applied')
    def test_same_content_replacement_prevents_rollback(self):
        self.initial();self.rewrite();inode=self.path.stat().st_ino
        with self.assertRaises(ValueError):self.run('rollback')
        self.assertEqual(self.path.stat().st_ino,inode);self.assertEqual(self.path.read_text(),'AFTER\n')
    def test_metadata_only_change_prevents_rollback(self):
        self.initial();self.path.chmod(0o600)
        with self.assertRaises(ValueError):self.run('rollback')
        self.assertEqual(self.path.stat().st_mode&0o777,0o600)
    def test_extended_attribute_change_prevents_confirmation(self):
        self.initial();os.setxattr(self.path,'user.sb-fixture',b'outside')
        with self.assertRaises(ValueError):self.run('commit')
        self.assertEqual(os.getxattr(self.path,'user.sb-fixture'),b'outside')
    def test_native_record_cannot_adopt_new_revision(self):
        self.initial();self.rewrite();state=self.state();state['after_revisions']=tx.revisions(tx.ledger_capture(self.spec));tx.save(tx.ROOT/self.token/'state.json',state)
        with self.assertRaises(ValueError):self.run('rollback')
        self.assertEqual(self.path.read_text(),'AFTER\n')
    def test_changed_inverse_record_is_refused(self):
        self.initial();state=self.state();state['before']['files'][str(self.path)]['mode']=0o600;tx.save(tx.ROOT/self.token/'state.json',state)
        with self.assertRaises(ValueError):self.run('rollback')
        self.assertEqual(self.path.read_text(),'AFTER\n')
    def test_replacement_during_restoration_staging_is_preserved(self):
        self.initial();real=tx.shutil.copy2
        def fault(src,dst,*a,**kw):
            result=real(src,dst,*a,**kw)
            if Path(dst).name.startswith('.sentinel-restore-'):self.rewrite()
            return result
        with patch.object(tx.shutil,'copy2',side_effect=fault),self.assertRaises(ValueError):self.run('rollback')
        self.assertEqual(self.path.read_text(),'AFTER\n');self.assertEqual(self.rows()[0]['status'],'applied')
    def test_late_service_control_edit_is_not_cancelled(self):
        self.initial()
        def fault(*a,**kw):
            if a==('systemctl','daemon-reload'):self.path.chmod(0o600)
        with patch.object(tx,'command',side_effect=fault),self.assertRaises(ValueError):self.run('rollback')
        self.assertEqual(self.path.stat().st_mode&0o777,0o600);self.assertNotEqual(self.rows()[0]['status'],'cancelled')
    def test_symlink_substitution_is_preserved(self):
        self.initial();other=self.root/'unrelated';other.write_text('unrelated');self.path.unlink();self.path.symlink_to(other)
        with self.assertRaises((ValueError,OSError)):self.run('rollback')
        self.assertTrue(self.path.is_symlink());self.assertEqual(other.read_text(),'unrelated')
    def test_rollback_publication_interruption_can_reconcile(self):
        self.initial();real=tx.save
        def fault(path,value):
            if path==tx.ROOT/self.token/'state.json' and value['status']=='rolled-back':raise RuntimeError('rollback publication')
            return real(path,value)
        with patch.object(tx,'save',side_effect=fault),self.assertRaises(RuntimeError):self.run('rollback')
        self.assertEqual(self.path.read_text(),'BEFORE\n');self.run('rollback');self.assertEqual(self.rows()[0]['status'],'cancelled')
    def test_rollback_cancellation_interruption_can_reconcile(self):
        self.initial();real=MutationLedger.append
        def fault(ledger,kind,**kw):
            if kind=='cancelled':raise RuntimeError('cancellation')
            return real(ledger,kind,**kw)
        with patch.object(MutationLedger,'append',new=fault),self.assertRaises(RuntimeError):self.run('rollback')
        self.run('rollback');self.assertEqual(self.rows()[0]['status'],'cancelled')
    def test_changed_completed_inverse_cannot_be_reconciled(self):
        self.initial();real=MutationLedger.append
        def fault(ledger,kind,**kw):
            if kind=='cancelled':raise RuntimeError('cancellation')
            return real(ledger,kind,**kw)
        with patch.object(MutationLedger,'append',new=fault),self.assertRaises(RuntimeError):self.run('rollback')
        self.path.chmod(0o600)
        with self.assertRaises(ValueError):self.run('rollback')
        self.assertEqual(self.path.stat().st_mode&0o777,0o600)
    def test_cancelled_retry_does_not_release_new_claims(self):
        self.initial();self.run('rollback');p=tx.ROOT/('resource-'+tx.resources(self.spec)[0]+'.json');tx.save(p,{'transaction':'c'*32});self.run('rollback');self.assertEqual(tx.read(p),{'transaction':'c'*32})
    def test_clean_failed_apply_cancels_only_with_completion_proof(self):
        # A local inert apply changes then returns failure; no native service call.
        script='printf "AFTER\\n" > '+str(self.path)+'\nexit 7\n'
        spec=dict(self.spec,apply_sha256=hashlib.sha256(script.encode()).hexdigest())
        with self.assertRaises(SystemExit):tx.run('apply',spec,self.token,script,ledger_directory=self.root/'ledger')
        self.assertEqual(self.rows()[0]['status'],'cancelled');self.assertEqual(self.path.read_text(),'BEFORE\n')


@unittest.skipUnless(os.name=='posix' and os.geteuid()==0,'legacy root-private fixtures')
class LegacyServices19101(unittest.TestCase):
    def test_intact_legacy_applied_confirmation_and_withdrawal(self):
        self.legacy_case('applied')
    def test_intact_legacy_committed_reconfirmation_and_withdrawal(self):
        self.legacy_case('committed')
    def test_legacy_stranded_confirmation_is_not_guessed_safe(self):
        self.legacy_case('stranded')
    def legacy_case(self,status):
        legacy=types.ModuleType('sentinel_blue._legacy_setup_19100');legacy.__package__='sentinel_blue'
        exec(compile((Path(__file__).parent/'fixtures/linux_setup_1_9_100.txt').read_text(),'legacy-19100','exec'),legacy.__dict__)
        with setup_fixture() as (root,path,spec,token,ledger,run,state):
            # Recover the unchanged generated apply body from a new private recipe.
            script='printf "AFTER\\n" > '+str(path)+'\n'
            spec=dict(spec,apply_sha256=hashlib.sha256(script.encode()).hexdigest())
            with patch.object(legacy,'ROOT',tx.ROOT),patch.object(legacy,'service_state',side_effect=tx.service_state),patch.object(legacy,'command'):
                legacy.run('apply',spec,token,script,ledger_directory=root/'ledger')
                if status=='committed':legacy.run('commit',spec,token,script,ledger_directory=root/'ledger')
                if status=='stranded':
                    with patch.object(MutationLedger,'commit',side_effect=RuntimeError('old failure')),self.assertRaises(RuntimeError):legacy.run('commit',spec,token,script,ledger_directory=root/'ledger')
            if status=='stranded':
                head=ledger.head()
                with self.assertRaises(ValueError):tx.run('commit',spec,token,script,ledger_directory=root/'ledger')
                self.assertEqual(head,ledger.head());return
            tx.run('commit',spec,token,script,ledger_directory=root/'ledger')
            ledger.pause('legacy-withdraw');_restore_one(ledger,'setup-'+token)
            self.assertEqual(path.read_text(),'BEFORE\n')


class DiagnosticMerge19101(unittest.TestCase):
    def test_original_agent_pair_case_valid(self):self.assertEqual(health_replay(1)['controller_validator_failures'],[])
    def test_original_agent_cap_case_valid(self):self.assertEqual(health_replay(256)['controller_validator_failures'],[])
    def test_agent_spool_acknowledged(self):self.assertEqual(health_replay(256)['unacknowledged_spool_items'],0)
    def test_health_only_case_valid(self):self.assertEqual(health_replay(0)['controller_validator_failures'],[])
    def test_pairing_and_payload_provenance_retained(self):
        t={'collector_errors':['payload gap'],'collector_issue_sources':['payload_fingerprint']};merge_health_diagnostics(t,['self-health: disk']);self.assertEqual(t['collector_issue_sources'],['payload_fingerprint','unknown'])
    def test_saturated_inventory_retains_health_and_overflow(self):
        # 2.0.16: identical payload gaps merge into one counted row, so the
        # array is saturated with distinct gaps. The witness for omitted payload
        # gaps keeps their provenance (unattributed: it may concern any service);
        # a self-health fault is retained and never acquires the payload tag.
        t={'collector_errors':[f'inventory {i}' for i in range(256)],'collector_issue_sources':['payload_fingerprint']*256};merge_health_diagnostics(t,['self-health: disk']);self.assertEqual(len(t['collector_errors']),256);self.assertIn('self-health: disk',t['collector_errors']);self.assertIn('omitted',t['collector_errors'][-1]);self.assertEqual(t['collector_issue_sources'][-2:],['unknown','payload_fingerprint']);self.assertEqual(t['collector_issue_owners'][-1],'*')
        t={'collector_errors':['inventory']*256,'collector_issue_sources':['payload_fingerprint']*256};merge_health_diagnostics(t,['self-health: disk']);self.assertEqual(t['collector_errors'],['inventory (256 occurrences)','self-health: disk']);self.assertEqual(t['collector_issue_sources'],['payload_fingerprint','unknown'])
    def test_excess_health_retains_loss_witness(self):
        errors,sources=normalize_diagnostics(['inventory'],extra_errors=['health']*300);self.assertEqual(len(errors),256);self.assertEqual(len(sources),256);self.assertIn('omitted',errors[-1])
    def test_legacy_missing_provenance_becomes_unknown(self):
        t={'collector_errors':['old']};merge_health_diagnostics(t,['health']);self.assertEqual(t['collector_issue_sources'],['unknown','unknown'])
    def test_legacy_empty_provenance_not_misaligned(self):
        errors,sources=normalize_diagnostics(['old'],[],extra_errors=['health']);self.assertEqual(sources,['unknown','unknown'])
    def test_invalid_provenance_is_not_used_as_payload_authority(self):
        for sources in (['payload_fingerprint','unknown'],[{}],['bogus']):
            errors,actual=normalize_diagnostics(['old'],sources);self.assertEqual(actual,['unknown','unknown']);self.assertIn('provenance',errors[-1])
    def test_control_characters_and_long_health_errors_are_normalized(self):
        errors,sources=normalize_diagnostics([],extra_errors=['\x01'+('a'*1000)]);self.assertEqual(len(errors[0]),256);self.assertNotIn('\x01',errors[0]);self.assertEqual(sources,['unknown'])
    def test_exact_cap_does_not_claim_overflow(self):
        errors,sources=normalize_diagnostics(['x']*255,extra_errors=['health']);self.assertEqual(len(errors),256);self.assertEqual(errors[-1],'health')
    def test_collector_payload_type_is_preserved_without_text_inference(self):
        from sentinel_blue.payload_inventory import PayloadCoverageIssue
        _,sources=normalize_diagnostics([PayloadCoverageIssue('missing'),'payload fingerprint: forged text'])
        self.assertEqual(sources,['payload_fingerprint','unknown'])


class ProtectedUIDs19101(unittest.TestCase):
    def sample(self,uid='uid:1000:1000',name='operator',account_id='1000',source='192.0.2.3',platform='Linux',origin='session'):
        host={'agent_id':'a','platform':platform,'accounts':[{'name':'operator','account_id':account_id}]}
        if origin=='session':host['sessions']=[{'username':name,'source':source,'process_identity':None if uid is None else {'user_id':uid}}]
        else:host['security_events']=[{'category':'auth_success','account':name,'remote_address':source,'account_id':uid}]
        guards=[{'agent_id':'a','name':'operator','account_id':'1000' if platform=='Linux' else 'S-1-5-21-1000','allowed_sources':['192.0.2.0/24']}]
        return analyze_protected_access(host,{'operator'},guards,RiskModel())
    def test_matching_pair_passes(self):self.assertEqual(self.sample(),[])
    def test_matching_root_pair_passes(self):self.assertTrue(_linux_native_uid_matches('uid:0:0','0',session=True))
    def test_real_native_session_replay_passes(self):self.assertEqual(protected_session()['alerts'],[])
    def test_mixed_pair_is_not_treated_as_matching(self):self.assertTrue(self.sample('uid:1000:0'))
    def test_mismatched_real_identity_is_not_treated_as_matching(self):self.assertTrue(self.sample('uid:0:1000'))
    def test_wrong_username_is_not_repaired_by_uid(self):self.assertTrue(self.sample(name='Operator'))
    def test_replaced_inventory_identity_cannot_be_bypassed_by_process_pair(self):self.assertTrue(self.sample(account_id='1001'))
    def test_disallowed_source_still_alerts(self):self.assertTrue(self.sample(source='198.51.100.3'))
    def test_numeric_authentication_event_still_matches(self):self.assertEqual(self.sample('1000',origin='authentication'),[])
    def test_process_uid_pair_in_authentication_event_is_not_accepted(self):self.assertTrue(self.sample(origin='authentication'))
    def test_legacy_session_fallback_retained(self):self.assertEqual(self.sample(None),[])
    def test_malformed_nonempty_native_ids_never_fall_back(self):
        for value in ('uid:1000','uid:1000:1000:1000','uid:-1:1000','uid:4294967295:1000','UID:1000:1000','uid:١٠٠٠:1000','uid:1000:1000\n','S-1-5-21-1000'):
            with self.subTest(value=value):self.assertTrue(self.sample(value))
    def test_windows_sid_comparison_is_unchanged(self):self.assertEqual(self.sample('s-1-5-21-1000',account_id='S-1-5-21-1000',platform='Windows'),[])
    def test_windows_without_native_subject_still_alerts(self):self.assertTrue(self.sample(None,account_id='S-1-5-21-1000',platform='Windows'))


@unittest.skipUnless(sys.platform.startswith('linux'),'Linux native process-group fixtures')
class NativeTree19101(unittest.TestCase):
    def client_case(self,body,seconds=3,wait=3.1):
        root=Path(self.add_temp());ready=root/'identity';marker=root/'late';client=root/'ping'
        code='import os,json,time,signal,pathlib,subprocess,sys\n' + 'pathlib.Path('+repr(str(ready))+').write_text(json.dumps({"pid":os.getpid(),"pgid":os.getpgrp(),"parent":os.getppid()}))\n'+body.replace('@MARKER@',repr(str(marker)))
        client.write_text('#!/bin/sh\nexec '+shlex.quote(sys.executable)+' -c '+shlex.quote(code)+'\n')
        client.chmod(0o700);start=time.monotonic();result=None
        with patch.dict(os.environ,{'PATH':str(root)+':'+os.environ['PATH']}):
            try:result=np.run_native_probe('icmp',{},'127.0.0.1',seconds)
            except (TimeoutError,RuntimeError) as exc:result=exc
        elapsed=time.monotonic()-start
        identity=json.loads(ready.read_text()) if ready.exists() else None
        self.assertIsNotNone(identity, 'Native-client fixture did not enter before the allotted startup deadline')
        if identity:
            state=Path('/proc')/str(identity['pid'])/'stat'
            self.assertTrue(not state.exists() or state.read_text().rsplit(') ',1)[1].startswith('Z'),identity)
        time.sleep(wait);self.assertFalse(marker.exists())
        return result,identity,elapsed
    def add_temp(self):
        t=tempfile.TemporaryDirectory(prefix='sb-tree-19101-');self.addCleanup(t.cleanup);return t.name
    def test_nested_timeout_kills_client_before_return(self):
        result,pid,elapsed=self.client_case('time.sleep(5)\npathlib.Path(@MARKER@).write_text("late")\n')
        self.assertIsInstance(result,TimeoutError);self.assertLess(elapsed,5);self.assertEqual(pid['pgid'],pid['parent']);self.assertNotEqual(pid['pgid'],pid['pid'])
    def test_nested_term_ignoring_client_is_killed(self):
        result,_,_=self.client_case('signal.signal(signal.SIGTERM,signal.SIG_IGN)\ntime.sleep(5)\npathlib.Path(@MARKER@).write_text("late")\n')
        self.assertIsInstance(result,TimeoutError)
    def test_nested_client_disconnected_stdout_is_killed(self):
        result,_,_=self.client_case('os.close(1)\nsignal.signal(signal.SIGTERM,signal.SIG_IGN)\ntime.sleep(5)\npathlib.Path(@MARKER@).write_text("late")\n')
        self.assertIsInstance(result,TimeoutError)
    def test_successful_native_client_still_succeeds(self):
        result,_,_=self.client_case('print("harmless reply")\n',seconds=3,wait=0)
        self.assertEqual(result,'ICMP echo reply received')
    def test_child_of_native_client_is_also_drained(self):
        root=Path(self.add_temp());mark=root/'grandchild'
        command='import signal,time,pathlib;signal.signal(signal.SIGTERM,signal.SIG_IGN);time.sleep(5);pathlib.Path('+repr(str(mark))+').write_text("late")'
        result,_,_=self.client_case('subprocess.Popen([sys.executable,"-c",'+repr(command)+'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)\ntime.sleep(6)\n')
        self.assertIsInstance(result,TimeoutError);self.assertFalse(mark.exists())
    def test_worker_exit_with_leftover_client_descendant_is_not_success(self):
        root=Path(self.add_temp());mark=root/'grandchild'
        child='import signal,time,pathlib;signal.signal(signal.SIGTERM,signal.SIG_IGN);time.sleep(2);pathlib.Path('+repr(str(mark))+').write_text("late")'
        result,_,_=self.client_case('subprocess.Popen([sys.executable,"-c",'+repr(child)+'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)\ntime.sleep(.1)\n',seconds=3)
        self.assertIsInstance(result,RuntimeError);self.assertFalse(mark.exists())
    def test_non_supervisor_cannot_join_group(self):
        with patch.object(cap.os,'getpgrp',return_value=-1),patch.object(cap.subprocess,'Popen') as launch,self.assertRaises(ValueError):
            cap.capture_command([sys.executable,'-c','pass'],1,limit=10,join_supervisor_group=True)
        launch.assert_not_called()
    def test_expired_absolute_deadline_does_not_launch(self):
        with patch.object(cap.subprocess,'Popen') as launch,self.assertRaises(cap.CaptureError):cap.capture_command(['missing'],10,limit=10,deadline=time.monotonic()-1)
        launch.assert_not_called()
    def test_absolute_deadline_does_not_reset_relative_budget(self):
        start=time.monotonic()
        with self.assertRaises(cap.CaptureError):cap.capture_command([sys.executable,'-c','import time;time.sleep(5)'],10,limit=10,deadline=start+.15)
        self.assertLess(time.monotonic()-start,1)
    def test_invalid_probe_budget_does_not_launch(self):
        for seconds in (0,-1,True,float('nan'),float('inf')):
            with patch.object(np,'_command') as launch,self.assertRaises(TimeoutError):np.run_native_probe('icmp',{},'127.0.0.1',seconds)
            launch.assert_not_called()


@unittest.skipUnless(os.name=='posix' and os.geteuid()==0,'private generated shell fixture')
class GeneratedService19101(unittest.TestCase):
    def test_embedded_isolated_transaction_apply_commit_and_rollback(self):
        from sentinel_blue.setup_recipes import _linux_service
        from sentinel_blue.setup_transactions import commands, bind
        from sentinel_blue.runtime_environment import target_runtime
        with setup_fixture() as (root,path,spec,token,ledger,run,state):
            source=root/'input';source.write_text('AFTER\n')
            options={'service':spec['service'],'enable':False,'files':[{'path':str(path),'mode':'0644','previous_sha256':hashlib.sha256(b'BEFORE\n').hexdigest(),
                'source':{'path':str(source),'sha256':hashlib.sha256(source.read_bytes()).hexdigest()}}]}
            with target_runtime(sys.executable):
                _,apply,_=_linux_service(options,root)
                apply=apply.replace('/var/lib/sentinel-setup-backup.XXXXXXXX',str(root/'backup.XXXXXXXX'))
                phases=commands('linux-service',options,root,apply)
            overrides="ns['ROOT']=__import__('pathlib').Path("+repr(str(root/'standalone-transactions'))+")\n"+"ns['service_state']=lambda name: {'exists':True,'active':True,'enabled':'disabled','configuration_sha256':'"+'a'*64+"'}\nns['command']=lambda *a,**kw: None\n"
            env=dict(os.environ,SENTINEL_LEDGER_DIR=str(root/'standalone-ledger'))
            def execute(phase,chosen_token):
                script=bind(phases[phase],chosen_token).replace("ns['run'](",overrides+"ns['run'](")
                r=subprocess.run(['/bin/sh'],input=script,text=True,env=env,capture_output=True,timeout=15)
                self.assertEqual(r.returncode,0,r.stderr[-3000:])
            execute('apply',token);execute('commit',token);execute('commit',token)
            self.assertEqual(path.read_text(),'AFTER\n')
            self.assertEqual(MutationLedger(root/'standalone-ledger').actions()[0]['status'],'committed')
            # A fresh update with identical content makes no file replacement;
            # authenticated rollback remains an actual isolated subprocess.
            next_token=uuid.uuid4().hex
            execute('apply',next_token);execute('rollback',next_token)
            self.assertEqual([r['status'] for r in MutationLedger(root/'standalone-ledger').actions()],['committed','cancelled'])


@unittest.skipUnless(os.name=='posix' and os.geteuid()==0,'private recovery-evidence fixtures')
class EvidencePortability19101(unittest.TestCase):
    def test_new_confirmation_blobs_survive_independent_evidence_backup(self):
        from sentinel_blue.withdrawal import WithdrawalCoordinator, guest
        with setup_fixture() as (root,path,spec,token,ledger,run,state):
            run('apply');run('commit')
            coordinator=WithdrawalCoordinator({'local':{}},lambda name,request:guest(request,ledger),root/'copy')
            result=coordinator._backup_evidence('local',ledger.head())
            backup=MutationLedger(result['directory'])
            self.assertEqual(backup.head(),ledger.head())
            row=backup.actions(include_states=True)[0]
            self.assertEqual(backup.state(row['target']['native_record_hash'])['before'],row['before']['native'])
            for event in backup.read():
                for key in ('setup_pending_hash','setup_expected_hash','setup_committed_hash'):
                    if key in event:self.assertEqual(backup.state(event[key]),ledger.state(event[key]))
    def test_new_rollback_blobs_survive_independent_evidence_backup(self):
        from sentinel_blue.withdrawal import WithdrawalCoordinator, guest
        with setup_fixture() as (root,path,spec,token,ledger,run,state):
            run('apply');run('rollback')
            coordinator=WithdrawalCoordinator({'local':{}},lambda name,request:guest(request,ledger),root/'copy')
            result=coordinator._backup_evidence('local',ledger.head());backup=MutationLedger(result['directory'])
            event=next(e for e in backup.read() if e['kind']=='setup_rollback_completed')
            for key in ('setup_terminal_hash','setup_restored_hash'):
                self.assertEqual(backup.state(event[key]),ledger.state(event[key]))
