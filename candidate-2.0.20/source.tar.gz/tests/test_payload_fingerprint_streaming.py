"""Fingerprint large files without weakening snapshot identity or read limits."""
from contextlib import nullcontext
import hashlib
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from sentinel_blue import restoration
from sentinel_blue.payload_inventory import PayloadReadBudget, _fingerprint_error
from tests.test_windows_integrity_budget import MemoryFile


def fingerprint(native, budget, maximum):
    with patch.object(restoration, '_windows_pinned_parent',
                      return_value=nullcontext((1, 'parent', 'fixture'))):
        return restoration._windows_read_file_snapshot(
            Path('fixture'), maximum, native=native, capture_security=False,
            allow_hard_links=True, read_budget=budget, hash_only=True)


class PayloadFingerprintTests(unittest.TestCase):
    def test_large_executable_is_streamed_and_matches_full_digest(self):
        data = b'bounded inert installer fixture\n' * 1_200_000
        self.assertGreater(len(data), 32 * 1024 * 1024)
        native = MemoryFile(data)
        budget = PayloadReadBudget(float('inf'), len(data))
        with patch.object(native, 'read_file', side_effect=AssertionError('must stream')):
            digest, metadata = fingerprint(native, budget, len(data))
        self.assertEqual(digest, hashlib.sha256(data).digest())
        self.assertEqual(metadata['size'], len(data))
        self.assertEqual(budget.remaining_bytes, 0)
        self.assertGreater(native.reads, 32)
        self.assertEqual(native.closed, [7])

    def test_per_file_limit_still_rejects_before_reading(self):
        native = MemoryFile(b'x' * 100)
        with self.assertRaisesRegex(ValueError, 'byte limit'):
            fingerprint(native, PayloadReadBudget(float('inf')), 99)
        self.assertEqual(native.reads, 0)
        self.assertEqual(native.closed, [7])

    def test_aggregate_budget_counts_rejected_snapshot(self):
        budget = PayloadReadBudget(float('inf'), 100)
        with self.assertRaisesRegex(OSError, 'changed during'):
            fingerprint(MemoryFile(b'x' * 80, changed=True), budget, 100)
        self.assertEqual(budget.remaining_bytes, 20)
        with self.assertRaisesRegex(ValueError, 'aggregate byte'):
            fingerprint(MemoryFile(b'y' * 30), budget, 100)

    def test_expired_read_is_rejected_and_handle_closed(self):
        now = [0.0]
        native = MemoryFile(b'x', after_read=lambda: now.__setitem__(0, 5.0))
        with patch('sentinel_blue.payload_inventory.time.monotonic', side_effect=lambda: now[0]):
            with self.assertRaises(TimeoutError):
                fingerprint(native, PayloadReadBudget(4.0), 100)
        self.assertEqual(native.closed, [7])

    def test_reparse_target_remains_rejected(self):
        native = MemoryFile(b'x')
        original = native.file_snapshot
        native.file_snapshot = lambda handle: {
            **original(handle), 'attributes': restoration.WINDOWS_REPARSE_POINT_ATTRIBUTE}
        with self.assertRaisesRegex(ValueError, 'reparse'):
            fingerprint(native, PayloadReadBudget(float('inf')), 100)
        self.assertEqual(native.reads, 0)

    def test_reason_survives_telemetry_truncation(self):
        error = _fingerprint_error('process-payload', 'C:/' + 'installer/' * 40,
                                   ValueError('file exceeds its 33554432 byte limit'))
        self.assertIn('33554432 byte limit', error[:256])
        self.assertLessEqual(len(error), 256)

    @unittest.skipUnless(os.name == 'nt', 'requires native Windows file handles')
    def test_native_large_file_hash_and_handle_release(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory).resolve() / 'large-installer.fixture'
            expected = hashlib.sha256()
            with path.open('wb') as stream:
                for _ in range(40):
                    block = b'X' * (1024 * 1024)
                    stream.write(block)
                    expected.update(block)
            native = restoration._WindowsNativeFileOps()
            digest, _ = restoration._windows_read_file_snapshot(
                path, 64 * 1024 * 1024, native=native, capture_security=False,
                hash_only=True, read_budget=PayloadReadBudget(float('inf')))
            self.assertEqual(digest, expected.digest())
            path.unlink()


if __name__ == '__main__':
    unittest.main()
