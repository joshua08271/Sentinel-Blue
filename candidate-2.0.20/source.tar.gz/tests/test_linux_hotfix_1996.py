"""Linux issues 5-8. Private files/processes/sockets; no native service mutations."""
import base64
from dataclasses import asdict
import errno
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import socket
import stat
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

from sentinel_blue import collectors, linux_service_packs as packs
from sentinel_blue import setup_linux_transaction as tx, network_native as net
from sentinel_blue import mutation_ledger as ledger_module
from sentinel_blue import setup_file_access as access
from sentinel_blue.mutation_ledger import MutationLedger, LedgerError
from sentinel_blue.setup_recipes import _linux_service
from sentinel_blue.service_ports import listener_observation

ROOT_FIXTURE = os.name == 'posix' and hasattr(os, 'geteuid') and os.geteuid() == 0


def completed(stdout='', stderr='', code=0):
    return subprocess.CompletedProcess([], code, stdout, stderr)


class ListenerCoverage(unittest.TestCase):
    def collect(self, tcp=None, udp=None, *, limit=2000):
        def query(argv, **kwargs):
            value = (tcp if argv == ['ss', '-H', '-lnt'] else
                     udp if argv == ['ss', '-H', '-lnu'] else None)
            if value is None:
                raise AssertionError('unexpected listener command: ' + repr(argv))
            if isinstance(value, BaseException):
                raise value
            return value
        errors=[]
        with patch.object(collectors,'_run',side_effect=query), patch.object(collectors,'MAX_LINUX_LISTENERS',limit):
            rows=collectors._linux_listeners(errors)
        observation=listener_observation({'observed_at':10,'listeners':[asdict(x) for x in rows],
                                         'collector_errors':errors},now=10)
        return rows,errors,observation

    def test_text_inventory_preserves_tcp_and_udp_protocols(self):
        rows,errors,obs=self.collect(completed('LISTEN 0 128 127.0.0.1:8000 0.0.0.0:*\n'),
                                   completed('UNCONN 0 0 127.0.0.1:5353 0.0.0.0:*\n'))
        self.assertEqual([(x.protocol,x.port) for x in rows],[('tcp',8000),('udp',5353)])
        self.assertEqual(errors,[]);self.assertTrue(obs['complete'])

    def test_empty_success_is_complete_for_both_protocols(self):
        rows,errors,obs=self.collect(completed(),completed())
        self.assertEqual(rows,[]);self.assertEqual(errors,[]);self.assertTrue(obs['complete'])

    def test_udp_failure_retains_tcp_but_prevents_complete_claim(self):
        rows,errors,obs=self.collect(completed('LISTEN 0 128 *:8000 *:*\n'),completed(code=1))
        self.assertEqual(len(rows),1);self.assertIn('UDP',errors[0]);self.assertFalse(obs['complete'])

    def test_tcp_failure_retains_udp_but_prevents_complete_claim(self):
        rows,errors,obs=self.collect(completed(code=1),completed('UNCONN 0 0 *:5353 *:*\n'))
        self.assertEqual(rows[0].protocol,'udp');self.assertIn('TCP',errors[0]);self.assertFalse(obs['complete'])

    def test_one_transport_timeout_does_not_discard_other(self):
        rows,errors,obs=self.collect(subprocess.TimeoutExpired(['sensitive-placeholder'],1),
                                    completed('UNCONN 0 0 *:5353 *:*\n'))
        self.assertEqual(len(rows),1);self.assertFalse(obs['complete'])
        self.assertNotIn('sensitive-placeholder',str(errors))

    def test_missing_ss_reads_the_kernel_tables_instead(self):
        # 2.0.5: without iproute2 the kernel's own socket tables are read, so a
        # minimal host is not left with incomplete collection forever.
        rows,errors,obs=self.collect(FileNotFoundError(),FileNotFoundError())
        self.assertEqual(errors,[]);self.assertTrue(all(x.protocol in {'tcp','udp'} for x in rows))

    def test_optional_netid_and_ipv6_scope_are_supported(self):
        rows,errors,obs=self.collect(completed('tcp6 LISTEN 0 5 [::1]:8000 [::]:*\n'),
                           completed('udp UNCONN 0 0 [fe80::1%eth0]:5353 [::]:*\n'))
        self.assertEqual([x.address for x in rows],['::1','fe80::1%eth0'])
        self.assertEqual(errors,[]);self.assertTrue(obs['complete'])

    def test_unexpected_protocol_or_state_is_not_silently_dropped(self):
        for row in ('udp UNCONN 0 0 *:53 *:*\n','ESTAB 0 0 *:8000 *:*\n','garbage\n'):
            with self.subTest(row=row):
                rows,errors,obs=self.collect(completed(row),completed())
                self.assertEqual(rows,[]);self.assertTrue(errors);self.assertFalse(obs['complete'])

    def test_invalid_ports_and_bad_rows_block_completeness(self):
        for port in ('0','65536','-1','not-a-port','１２'):
            with self.subTest(port=port):
                rows,errors,obs=self.collect(completed('LISTEN 0 0 *:'+port+' *:*\n'),completed())
                self.assertEqual(rows,[]);self.assertTrue(errors);self.assertFalse(obs['complete'])

    def test_stderr_diagnostic_blocks_completeness_without_echoing_output(self):
        rows,errors,obs=self.collect(completed(stderr='PRIVATE'),completed())
        self.assertFalse(obs['complete']);self.assertNotIn('PRIVATE',str(errors))

    def test_clipping_marks_incomplete_even_with_valid_output(self):
        rows,errors,obs=self.collect(completed('LISTEN 0 1 *:8000 *:*\nLISTEN 0 1 *:8001 *:*\n'),
                          completed('UNCONN 0 0 *:5353 *:*\n'),limit=2)
        self.assertEqual(len(rows),2);self.assertTrue(any('truncated' in e for e in errors));self.assertFalse(obs['complete'])

    @unittest.skipUnless(os.name=='posix' and shutil.which('ss'),'native ss required')
    def test_real_ipv4_tcp_and_udp_sockets_are_visible(self):
        with socket.socket() as tcp, socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as udp:
            tcp.bind(('127.0.0.1',0));tcp.listen();udp.bind(('127.0.0.1',0))
            errors=[];rows=collectors._linux_listeners(errors)
            pairs={(x.protocol,x.port) for x in rows}
            self.assertIn(('tcp',tcp.getsockname()[1]),pairs)
            self.assertIn(('udp',udp.getsockname()[1]),pairs);self.assertEqual(errors,[])

    @unittest.skipUnless(os.name=='posix' and shutil.which('ss') and socket.has_ipv6,'native IPv6 and ss required')
    def test_real_ipv6_tcp_and_udp_sockets_are_visible(self):
        with socket.socket(socket.AF_INET6,socket.SOCK_STREAM) as tcp, socket.socket(socket.AF_INET6,socket.SOCK_DGRAM) as udp:
            try:
                tcp.bind(('::1',0));tcp.listen();udp.bind(('::1',0))
            except OSError as exc:self.skipTest('IPv6 loopback unavailable: '+type(exc).__name__)
            errors=[];rows=collectors._linux_listeners(errors)
            pairs={(x.protocol,x.port) for x in rows}
            self.assertIn(('tcp',tcp.getsockname()[1]),pairs)
            self.assertIn(('udp',udp.getsockname()[1]),pairs);self.assertEqual(errors,[])


class FileAccessContract(unittest.TestCase):
    def test_broker_packs_declare_private_daemon_readable_defaults(self):
        for service in ('redis','mosquitto'):
            with self.subTest(service=service):
                meta={};packs.build(service,{},Path('.'),metadata=meta)
                row=meta['files'][0]
                self.assertEqual((row['mode'],row['create_owner'],row['create_group'],row['readable_by']),
                                 ('0640','root',service,service))

    def test_custom_identity_override_is_part_of_review_metadata(self):
        spec={'create_owner':'root','create_group':'customgroup','readable_by':'customuser'}
        meta={};packs.build('redis',{'file_access':{'/etc/redis/sentinel.conf':spec}},Path('.'),metadata=meta)
        self.assertEqual({k:meta['files'][0][k] for k in spec},spec)

    def test_invalid_or_unknown_access_contracts_are_refused(self):
        for value in (None,[],{'/unrelated':{}},{'/etc/redis/sentinel.conf':{}},
                      {'/etc/redis/sentinel.conf':{'create_owner':'root','create_group':'root','readable_by':'a;id'}},
                      {'/etc/redis/sentinel.conf':{'create_owner':0,'create_group':'root','readable_by':'root'}}):
            with self.subTest(value=value),self.assertRaises(ValueError):
                packs.build('redis',{'file_access':value},Path('.'))

    def test_unknown_reader_for_new_restricted_generic_file_is_refused(self):
        for mode in ('0600','0640'):
            with self.subTest(mode=mode),self.assertRaisesRegex(ValueError,'restricted'):
                _linux_service({'service':'fixture','files':[{'path':'/etc/fixture.conf','previous_sha256':'absent','mode':mode}]},
                               Path('.'),generated_sources={'/etc/fixture.conf':'data'})

    def test_partial_or_injected_generic_contract_is_refused(self):
        for extra in ({'readable_by':'root'}, {'create_owner':'root','create_group':'root','readable_by':[]},
                      {'create_owner':'root','create_group':'root','readable_by':'root\necho bad'}):
            with self.subTest(extra=extra), self.assertRaises(ValueError):
                _linux_service({'service':'fixture','files':[{'path':'/etc/fixture.conf','previous_sha256':'absent','mode':'0640',**extra}]},
                               Path('.'),generated_sources={'/etc/fixture.conf':'data'})

    def test_generated_check_and_apply_both_include_effective_read_probe(self):
        check,apply,_=packs.build('redis',{},Path('.'))
        self.assertIn('sb_file_access check',check)
        self.assertIn('sb_file_access resolve',apply)
        self.assertIn('sb_file_access stage',apply)
        self.assertIn('sb_file_access check',apply)
        for value in (check,apply):
            result=subprocess.run(['/bin/sh','-n'],input=value,text=True,capture_output=True)
            self.assertEqual(result.returncode,0,result.stderr)

    def test_nginx_tls_private_key_keeps_root_only_access_contract(self):
        from sentinel_blue.application_setup import linux_nginx
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            def source(name, value):
                (root/name).write_text(value)
                return {'path':name,'sha256':hashlib.sha256(value.encode()).hexdigest()}
            options={'name':'fixture','listen_address':'127.0.0.1','port':8443,
                     'content':source('content','fixture'),
                     'tls_certificate':source('cert','TEST CERTIFICATE PLACEHOLDER'),
                     'tls_key':source('key','TEST KEY PLACEHOLDER')}
            meta={};check,apply,_=linux_nginx(options,root,metadata=meta)
            key=next(row for row in meta['files'] if row['path'].endswith('/private-key.pem'))
            self.assertEqual((key['mode'],key['create_owner'],key['create_group'],key['readable_by']),
                             ('0600','root','root','root'))
            for script in (check,apply):
                done=subprocess.run(['/bin/sh','-n'],input=script,text=True,capture_output=True)
                self.assertEqual(done.returncode,0,done.stderr)

    def test_transaction_spec_carries_access_metadata(self):
        from sentinel_blue.setup_transactions import commands
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);(root/'input').write_text('data')
            opts={'service':'fixture','files':[{'path':'/etc/fixture.conf','previous_sha256':'absent','mode':'0640',
                'create_owner':'root','create_group':'readers','readable_by':'daemon',
                'source':{'path':'input','sha256':hashlib.sha256(b'data').hexdigest()}}]}
            _,apply,_=_linux_service(opts,root);result=commands('linux-service',opts,root,apply)
            encoded=re.search(r"json.loads\(base64.b64decode\('([^']+)'\)\)",result['apply']).group(1)
            row=json.loads(base64.b64decode(encoded))['files'][0]
            self.assertEqual(row['readable_by'],'daemon');self.assertEqual(row['create_group'],'readers')


@unittest.skipUnless(ROOT_FIXTURE,'private root-owned filesystem and dropped-UID fixtures')
class NativeFileAccess(unittest.TestCase):
    def setUp(self):
        import pwd,grp
        try:self.reader=pwd.getpwnam('nobody');self.group=grp.getgrgid(self.reader.pw_gid).gr_name
        except KeyError:self.skipTest('nobody fixture identity missing')
        self.tmp=tempfile.TemporaryDirectory(prefix='sb196-access-',dir='/var/lib');self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name);self.root.chmod(0o755)
        self.target=self.root/'configuration with spaces.conf'
        self.bin=self.root/'bin';self.bin.mkdir();(self.bin/'systemctl').write_text('#!/bin/sh\ncase "$1" in is-enabled) echo disabled;; esac\nexit 0\n')
        (self.bin/'systemctl').chmod(0o700)
        self.contract={'create_owner':'root','create_group':self.group,'readable_by':self.reader.pw_name}

    def scripts(self, *, validation='', contract=None, mode='0640'):
        previous=hashlib.sha256(self.target.read_bytes()).hexdigest() if self.target.exists() else 'absent'
        opts={'service':'sb-fixture.service','files':[{'path':str(self.target),'previous_sha256':previous,'mode':mode,
                                                   **(self.contract if contract is None else contract)}]}
        check,apply,_=_linux_service(opts,self.root,generated_sources={str(self.target):'SENTINEL PRIVATE DATA\n'},validation_script=validation)
        return check,apply.replace('/var/lib/sentinel-setup-backup.XXXXXXXX',str(self.root/'backup.XXXXXXXX'))

    def execute(self,script):
        return subprocess.run(['/bin/sh'],input=script,text=True,capture_output=True,timeout=15,
             env={**os.environ,'PATH':str(self.bin)+':'+os.environ['PATH']})

    def read_as(self,uid,gid):
        # Independent OS permission check: initialize the private interpreter,
        # then drop IDs before touching the file (never inherit a root-open fd).
        code = 'import os;os.setgroups([]);os.setresgid(%d,%d,%d);os.setresuid(%d,%d,%d);\n' % (gid,gid,gid,uid,uid,uid)
        return subprocess.run([sys.executable,'-I','-S','-c',code+access.READER,str(self.target)],
                              stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=5)

    def test_new_0640_file_is_readable_by_daemon_not_unrelated_identity(self):
        check,apply=self.scripts();result=self.execute(apply)
        self.assertEqual(result.returncode,0,result.stderr)
        info=self.target.stat();self.assertEqual((info.st_uid,info.st_gid,stat.S_IMODE(info.st_mode)),(0,self.reader.pw_gid,0o640))
        self.assertEqual(self.read_as(self.reader.pw_uid,self.reader.pw_gid).returncode,0)
        self.assertNotEqual(self.read_as(65533,65533).returncode,0)
        self.assertEqual(self.execute(check).returncode,0)

    def test_explicit_daemon_owned_0600_contract_is_supported(self):
        contract={**self.contract,'create_owner':self.reader.pw_name}
        _,apply=self.scripts(contract=contract,mode='0600')
        result=self.execute(apply);self.assertEqual(result.returncode,0,result.stderr)
        self.assertEqual(self.target.stat().st_uid,self.reader.pw_uid)
        self.assertEqual(stat.S_IMODE(self.target.stat().st_mode),0o600)

    def test_existing_readable_ownership_and_xattrs_are_preserved(self):
        self.target.write_text('ORIGINAL\n');self.target.chmod(0o640);os.chown(self.target,self.reader.pw_uid,self.reader.pw_gid)
        os.setxattr(self.target,'user.sb196',b'preserved')
        _,apply=self.scripts();result=self.execute(apply)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertEqual((self.target.stat().st_uid,self.target.stat().st_gid),(self.reader.pw_uid,self.reader.pw_gid))
        self.assertEqual(os.getxattr(self.target,'user.sb196'),b'preserved')

    def test_existing_unreadable_file_is_not_chowned_or_made_public(self):
        self.target.write_text('ORIGINAL\n');self.target.chmod(0o640)
        before=tx.fingerprint(self.target);_,apply=self.scripts();result=self.execute(apply)
        self.assertEqual(result.returncode,42,result.stderr)
        self.assertEqual(tx.fingerprint(self.target),before)
        self.assertEqual(self.target.read_text(),'ORIGINAL\n')
        self.assertFalse(list(self.root.glob('.sentinel-setup.*')))

    def test_unknown_user_refuses_before_any_setup_write(self):
        _,apply=self.scripts(contract={**self.contract,'readable_by':'sb196_user_must_not_exist'})
        result=self.execute(apply);self.assertEqual(result.returncode,42)
        self.assertFalse(self.target.exists());self.assertFalse(list(self.root.glob('backup.*')))
        self.assertNotIn('SENTINEL PRIVATE DATA',result.stderr)

    def test_directory_traversal_permissions_are_checked_as_daemon(self):
        self.root.chmod(0o700);_,apply=self.scripts();result=self.execute(apply)
        self.assertEqual(result.returncode,42,result.stderr);self.assertFalse(self.target.exists())
        self.assertFalse(list(self.root.glob('.sentinel-setup.*')))

    def test_failed_validation_removes_owned_new_file(self):
        _,apply=self.scripts(validation='exit 7\n');result=self.execute(apply)
        self.assertEqual(result.returncode,7,result.stderr);self.assertFalse(self.target.exists())

    def test_failed_validation_restores_existing_metadata(self):
        self.target.write_text('ORIGINAL\n');self.target.chmod(0o640);os.chown(self.target,0,self.reader.pw_gid)
        before=tx.fingerprint(self.target);_,apply=self.scripts(validation='exit 7\n');result=self.execute(apply)
        self.assertEqual(result.returncode,7,result.stderr);self.assertEqual(tx.fingerprint(self.target),before)

    def test_teammate_edit_still_causes_rollback_hold(self):
        _,apply=self.scripts(validation='printf "TEAMMATE\\n" > '+shlex.quote(str(self.target))+'\nexit 7\n')
        result=self.execute(apply);self.assertEqual(result.returncode,43,result.stderr)
        self.assertEqual(self.target.read_text(),'TEAMMATE\n')

    def test_idempotent_reapply_does_not_reassign_existing_owner(self):
        self.target.write_text('SENTINEL PRIVATE DATA\n');self.target.chmod(0o640);os.chown(self.target,self.reader.pw_uid,self.reader.pw_gid)
        before=self.target.stat();_,apply=self.scripts();result=self.execute(apply)
        self.assertEqual(result.returncode,0,result.stderr)
        after=self.target.stat();self.assertEqual((before.st_ino,before.st_ctime_ns),(after.st_ino,after.st_ctime_ns))
        self.assertEqual(after.st_uid,self.reader.pw_uid)

    def test_read_probe_does_not_inherit_root_access(self):
        self.target.write_text('SENTINEL PRIVATE DATA\n');self.target.chmod(0o640)
        with self.assertRaisesRegex(ValueError,'unreadable'):
            access.check(self.target,{**self.contract,'mode':'0640'})


@unittest.skipUnless(ROOT_FIXTURE,'private root-owned special-file fixtures')
class SafeFileReaders(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='sb196-reader-',dir='/var/lib');self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name);self.path=self.root/'state.json';self.path.write_text('{"value":1}')
        self.path.chmod(0o600)

    def child(self,statement,*,prelude=''):
        code='from pathlib import Path\nimport os\nfrom sentinel_blue import setup_linux_transaction as tx,network_native as net\np=Path('+repr(str(self.path))+')\n'+prelude+'\n'+statement
        try:return subprocess.run([sys.executable,'-c',code],text=True,capture_output=True,timeout=3)
        except subprocess.TimeoutExpired:self.fail('special-file reader blocked instead of refusing')

    def test_fifo_rejected_by_transaction_and_router_readers(self):
        self.path.unlink();os.mkfifo(self.path,0o600)
        for statement in ('tx.fingerprint(p)','tx.read(p)','net.read(p)'):
            with self.subTest(reader=statement):
                result=self.child(statement);self.assertNotEqual(result.returncode,0);self.assertIn('ValueError',result.stderr)

    def test_fifo_substitution_immediately_before_open_is_rejected(self):
        prelude='''real_open=os.open
changed=False
def swap(path,flags,*args,**kwargs):
    global changed
    if str(path)==str(p) and not changed:
        changed=True;p.unlink();os.mkfifo(p,0o600)
    return real_open(path,flags,*args,**kwargs)
os.open=swap
'''
        for statement in ('tx.fingerprint(p)','net.read(p)'):
            with self.subTest(reader=statement):
                if not stat.S_ISREG(self.path.lstat().st_mode):self.path.unlink();self.path.write_text('{}');self.path.chmod(0o600)
                result=self.child(statement,prelude=prelude)
                self.assertNotEqual(result.returncode,0);self.assertIn('ValueError',result.stderr)

    def test_ledger_capture_rejects_fifo_substituted_after_initial_snapshot(self):
        result=self.child("tx.ledger_capture({'files':[{'path':str(p)}]})",prelude='''before=tx.fingerprint(p)
def substituted(spec):
    p.unlink();os.mkfifo(p,0o600)
    return {'files':{str(p):before},'service':{}}
tx.capture=substituted
''')
        self.assertNotEqual(result.returncode,0);self.assertIn('ValueError',result.stderr)

    def test_symlinks_directories_and_hardlinks_are_refused(self):
        other=self.root/'other';other.write_text('OTHER');other.chmod(0o600)
        for kind in ('symlink','directory','hardlink'):
            self.path.unlink()
            if kind=='symlink':self.path.symlink_to(other)
            elif kind=='directory':self.path.mkdir()
            else:os.link(other,self.path)
            for reader in (tx.fingerprint,net.read):
                with self.subTest(kind=kind,reader=reader.__name__),self.assertRaises((OSError,ValueError)):
                    reader(self.path)
            if kind=='directory':self.path.rmdir();self.path.write_text('{}')
        self.assertEqual(other.read_text(),'OTHER')

    def test_transaction_record_is_decoded_from_validated_descriptor(self):
        with patch.object(Path,'read_text',side_effect=AssertionError('unsafe second open')):
            self.assertEqual(tx.read(self.path),{'value':1})

    def test_ledger_capture_uses_bounded_descriptor_not_path_read_bytes(self):
        with patch.object(tx,'service_state',return_value={}),patch.object(Path,'read_bytes',side_effect=AssertionError('unsafe second open')):
            value=tx.ledger_capture({'service':'fixture','files':[{'path':str(self.path)}]})
        self.assertEqual(base64.b64decode(value['file_evidence'][str(self.path)]['bytes']),b'{"value":1}')
        self.assertEqual(len(value['file_evidence'][str(self.path)]['revision']),4)

    def test_same_file_metadata_change_during_read_is_rejected(self):
        real_read=os.read
        for reader in (tx.fingerprint,net.read):
            self.path.chmod(0o600);changed=False
            def mutate(fd,n):
                nonlocal changed
                result=real_read(fd,n)
                if not changed:changed=True;self.path.chmod(0o640)
                return result
            with self.subTest(reader=reader.__name__),patch.object(os,'read',side_effect=mutate),self.assertRaisesRegex(ValueError,'changed'):
                reader(self.path)

    def test_path_replacement_with_identical_bytes_during_read_is_rejected(self):
        real_read=os.read
        for reader in (tx.fingerprint,net.read):
            changed=False
            def replace(fd,n):
                nonlocal changed
                result=real_read(fd,n)
                if not changed:
                    changed=True;other=self.root/'replacement';other.write_text('{"value":1}');other.chmod(0o600);os.replace(other,self.path)
                return result
            with self.subTest(reader=reader.__name__),patch.object(os,'read',side_effect=replace),self.assertRaisesRegex(ValueError,'changed'):
                reader(self.path)

    def test_oversized_regular_files_are_refused(self):
        with self.path.open('wb') as stream:stream.truncate(4*1024*1024+1)
        for reader in (tx.fingerprint,net.read):
            with self.subTest(reader=reader.__name__),self.assertRaises(ValueError):reader(self.path)

    def test_growth_during_read_does_not_escape_limit(self):
        real_read=os.read;grew=False
        def grow(fd,n):
            nonlocal grew
            data=real_read(fd,n)
            if not grew:
                grew=True
                with self.path.open('ab') as stream:stream.write(b'x'*128)
            return data
        with patch.object(tx,'MAX_FILE',32),patch.object(os,'read',side_effect=grow),self.assertRaisesRegex(ValueError,'limit'):
            tx.fingerprint(self.path)

    def test_absent_fingerprint_stays_none_and_fingerprint_schema_is_unchanged(self):
        self.assertIsNone(tx.fingerprint(self.root/'absent'))
        info=tx.fingerprint(self.path)
        self.assertEqual(set(info),{'sha256','uid','gid','mode','xattrs'})
        self.assertEqual(info['sha256'],hashlib.sha256(b'{"value":1}').hexdigest())
        self.assertEqual(net.read(self.path),b'{"value":1}')


class LedgerDeadline(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='sb196-ledger-');self.addCleanup(self.tmp.cleanup)
        self.directory=Path(self.tmp.name)/'ledger';self.ledger=MutationLedger(self.directory)

    def holder(self, ledger=None, *, hold=None, mutex_only=False):
        ledger=ledger or self.ledger;ready=threading.Event();release=threading.Event()
        def work():
            manager=ledger._mutex if mutex_only else ledger.lock()
            with manager:
                ready.set();release.wait(hold if hold is not None else 3)
        thread=threading.Thread(target=work);thread.start()
        self.addCleanup(thread.join,5);self.addCleanup(release.set)
        self.assertTrue(ready.wait(2));return release,thread

    def test_same_instance_thread_contention_obeys_timeout(self):
        release,thread=self.holder();start=time.monotonic()
        with self.assertRaisesRegex(LedgerError,'in-process mutex'):
            with self.ledger.lock(timeout=.05):pass
        elapsed=time.monotonic()-start;self.assertLess(elapsed,.3)
        self.assertTrue(thread.is_alive());self.assertEqual(self.ledger.contention()['timeouts'],1)
        release.set();thread.join(2)
        with self.ledger.lock(timeout=.1):pass

    def test_distinct_instances_share_the_same_thread_deadline(self):
        other=MutationLedger(self.directory);self.holder(other)
        with self.assertRaisesRegex(LedgerError,'in-process mutex'):
            with self.ledger.lock(timeout=.05):pass

    def test_same_thread_reentrant_acquisition_is_preserved(self):
        other=MutationLedger(self.directory)
        with self.ledger.lock(timeout=0):
            with self.ledger.lock(timeout=0):
                with other.lock(timeout=0):self.assertEqual(self.ledger._local.depth,3)
            self.assertEqual(self.ledger._local.depth,1)
        self.assertEqual(self.ledger._local.depth,0)

    def test_exception_releases_both_lock_layers(self):
        with self.assertRaisesRegex(RuntimeError,'test exception'):
            with self.ledger.lock():raise RuntimeError('test exception')
        with self.ledger.lock(timeout=0):pass

    def test_zero_timeout_is_nonblocking_under_thread_contention(self):
        self.holder();start=time.monotonic()
        with self.assertRaises(LedgerError):
            with self.ledger.lock(timeout=0):pass
        self.assertLess(time.monotonic()-start,.3)

    def test_timeout_values_are_validated_before_locking(self):
        for value in (-1,float('nan'),float('inf'),True,None,'0.1'):
            with self.subTest(value=value),self.assertRaises(ValueError):
                with self.ledger.lock(timeout=value):pass

    def test_timeout_is_not_a_deadline_for_critical_section_work(self):
        with self.ledger.lock(timeout=.05):time.sleep(.08)
        with self.ledger.lock(timeout=0):pass

    def test_thread_contention_is_reported_before_timeout(self):
        self.holder()
        with patch.object(ledger_module,'CONTENTION_WARNING_SECONDS',0),self.assertLogs(ledger_module.LOG,level='WARNING') as logs:
            with self.assertRaises(LedgerError):
                with self.ledger.lock(timeout=.05):pass
        self.assertEqual(self.ledger.contention()['warnings'],1)
        self.assertTrue(any('in-process mutex' in row for row in logs.output))

    @unittest.skipUnless(os.name=='posix','POSIX file-lock fixture')
    def test_os_lock_contention_obeys_deadline(self):
        import fcntl
        fd=os.open(self.directory/'writer.lock',os.O_RDWR);self.addCleanup(os.close,fd)
        fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);start=time.monotonic()
        with self.assertRaisesRegex(LedgerError,'OS file lock'):
            with self.ledger.lock(timeout=.05):pass
        self.assertLess(time.monotonic()-start,.3)
        fcntl.flock(fd,fcntl.LOCK_UN)
        with self.ledger.lock(timeout=0):pass

    @unittest.skipUnless(os.name=='posix','POSIX combined lock fixture')
    def test_thread_and_os_lock_share_one_budget(self):
        import fcntl
        fd=os.open(self.directory/'writer.lock',os.O_RDWR);self.addCleanup(os.close,fd)
        fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
        self.holder(hold=.18,mutex_only=True);start=time.monotonic()
        with self.assertRaisesRegex(LedgerError,'OS file lock'):
            with self.ledger.lock(timeout=.22):pass
        elapsed=time.monotonic()-start
        self.assertLess(elapsed,.33,'time budget reset after in-process mutex')
        self.assertGreaterEqual(elapsed,.20)

    @unittest.skipUnless(os.name=='posix','POSIX unexpected flock error fixture')
    def test_noncontention_os_error_is_not_retried_as_lock_contention(self):
        import fcntl
        with patch.object(fcntl,'flock',side_effect=OSError(errno.EBADF,'test')) as call:
            with self.assertRaises(OSError):
                with self.ledger.lock(timeout=.5):pass
        self.assertEqual(call.call_count,1)
        with self.ledger.lock(timeout=0):pass

    @unittest.skipUnless(os.name=='posix','POSIX named-pipe fixture')
    def test_advisory_holder_description_does_not_block_on_fifo(self):
        fifo=Path(self.tmp.name)/'fifo';os.mkfifo(fifo,0o600)
        code='from pathlib import Path;from sentinel_blue.mutation_ledger import _holder_description;print(_holder_description(Path('+repr(str(fifo))+')))'
        result=subprocess.run([sys.executable,'-c',code],capture_output=True,text=True,timeout=3)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertIn('did not identify',result.stdout)


if __name__=='__main__':unittest.main()
