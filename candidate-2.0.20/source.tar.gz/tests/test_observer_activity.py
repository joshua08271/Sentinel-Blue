"""Defensive observer authorization, real HTTP health and independent activity checks."""
import dataclasses,hashlib,http.client,http.server,json,os,sys,tempfile,threading,time,unittest
from pathlib import Path
from unittest.mock import patch
from sentinel_blue import activity_evidence,recording
from sentinel_blue.observer import ObserverRegistry,contract,contract_digest,send_report,attach_service_health,REPORT_PATH
from sentinel_blue.auth import signature
from sentinel_blue.store import Store
from sentinel_blue.state import write_private_text
from sentinel_blue.controller import ControllerApp,ControllerServer,make_handler
from sentinel_blue.event_profile import EventProfile
from sentinel_blue.probes import run_probe

class ObserverActivityTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name);self.token='o'*48
        write_private_text(self.root/'observer.key',self.token)
        self.entry={'observer_id':'outside-1','runtime_sha256':'a'*64,'key_file':str(self.root/'observer.key'),
            'authorized_networks':['127.0.0.0/8'],'authorized_hosts':['127.0.0.1'],'excluded_hosts':[],
            'interval_seconds':5,'stale_after_seconds':15,'checks':[{'check_id':'web-check','agent_id':'web-host',
                'service_id':'web','probe':{'kind':'http','target':'http://127.0.0.1:12345/','expected_status':[200],'expected_body':'healthy','timeout':1}}]}
        self.store=Store(self.root/'test.db');self.services=[{'host':'web-host','service_id':'web'}]
        self.registry=self.make_registry();activity_evidence.drain()
    def tearDown(self):self.store.close();self.temp.cleanup();activity_evidence.drain()
    def make_registry(self):return ObserverRegistry(self.store,[self.entry],services=self.services,authorized_hosts=['127.0.0.1'])
    def report(self,sequence=1,healthy=True,at=None):
        return {'observer_id':'outside-1','configuration_sha256':contract_digest(contract(self.entry)),
            'runtime_sha256':'a'*64,'observed_at':time.time() if at is None else at,'sequence':sequence,
            'probes':[{'check_id':'web-check','healthy':healthy,'latency_ms':1.2,'reason_code':'probe_passed' if healthy else 'probe_failed'}]}
    def accept(self,payload,registry=None):
        body=json.dumps(payload,separators=(',',':')).encode();stamp=str(time.time())
        return (registry or self.registry).accept(body,{'X-SB-Observer':'outside-1','X-SB-Timestamp':stamp,'X-SB-Signature':signature(self.token,stamp,'POST',REPORT_PATH,body)})
    def test_persistent_replay_guard_and_no_host_agent(self):
        payload=self.report();self.accept(payload);self.assertEqual(self.registry.status()[0]['health'],'healthy')
        self.store.close();self.store=Store(self.root/'test.db');registry=self.make_registry()
        with self.assertRaises(PermissionError):self.accept(payload,registry)
        self.assertEqual(self.store._connection.execute('SELECT COUNT(*) FROM agents').fetchone()[0],0)
        self.assertEqual(self.store._connection.execute('SELECT COUNT(*) FROM actions').fetchone()[0],0)
    def test_external_failure_and_staleness_keep_local_health_separate(self):
        self.accept(self.report(healthy=False));rows=[{'agent_id':'web-host','service':'web','health':'healthy'}]
        attach_service_health(rows,self.registry.status())
        self.assertEqual(rows[0]['health'],'healthy');self.assertEqual(rows[0]['external_health'],'unhealthy')
        self.assertTrue(rows[0]['local_external_disagreement']);self.assertEqual(self.registry.status(now=time.time()+20)[0]['health'],'stale')
    def test_scope_credentials_and_check_binding(self):
        with self.assertRaises(ValueError):contract(dict(self.entry,authorized_hosts=['192.0.2.9']))
        with self.assertRaises(ValueError):ObserverRegistry(self.store,[self.entry],services=self.services,forbidden_tokens=[self.token],authorized_hosts=['127.0.0.1'])
        bad=self.report();bad['probes'][0]['check_id']='different'
        with self.assertRaises(ValueError):self.accept(bad)
        with self.assertRaises(ValueError):self.accept(self.report(at=time.time()-500))
    def test_real_signed_http_report_and_role_separation(self):
        profile=dataclasses.replace(EventProfile.testing(),services=tuple(self.services),authorized_hosts=('127.0.0.1',))
        app=ControllerApp(self.store,'m'*48,operator_token='p'*48,event_profile=profile,observer_entries=[self.entry])
        server=ControllerServer(('127.0.0.1',0),make_handler(app));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            self.assertTrue(send_report({'controller':'http://127.0.0.1:'+str(server.server_port)},self.token,self.report())['accepted'])
            connection=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=3)
            target='/api/v1/agent/actions?agent_id=outside-1';stamp=str(time.time())
            connection.request('GET',target,headers={'X-SB-Agent':'outside-1','X-SB-Timestamp':stamp,'X-SB-Signature':signature(self.token,stamp,'GET',target,b'')})
            response=connection.getresponse();self.assertEqual(response.status,401);response.read();connection.close()
            self.assertEqual(self.store._connection.execute('SELECT COUNT(*) FROM actions').fetchone()[0],0)
        finally:server.shutdown();server.server_close();thread.join(3)
    def test_real_http_wrong_content_with_status200(self):
        state={'body':b'healthy'}
        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):self.send_response(200);self.end_headers();self.wfile.write(state['body'])
            def log_message(self,*args):pass
        server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            spec=dict(self.entry['checks'][0]['probe'],target='http://127.0.0.1:'+str(server.server_port)+'/')
            self.assertTrue(run_probe(spec,['127.0.0.0/8'],authorized_hosts=['127.0.0.1']).healthy)
            state['body']=b'wrong-content';self.assertFalse(run_probe(spec,['127.0.0.0/8'],authorized_hosts=['127.0.0.1']).healthy)
        finally:server.shutdown();server.server_close();thread.join(3)
    def test_journal_read_failure_is_visible(self):
        from sentinel_blue.collectors import _linux_security_events
        import subprocess
        errors=[]
        with patch('sentinel_blue.collectors._run',return_value=subprocess.CompletedProcess([],1,'','')):self.assertEqual(_linux_security_events(errors),[])
        self.assertTrue(errors);self.assertTrue(any(x.get('available') is False for x in activity_evidence.drain()))
    def test_unclassified_audit_access_excludes_command_text(self):
        raw={'MESSAGE':'type=PATH msg=audit(1770000000.123:42) name="/srv/owned/document" pid=123 uid=1000 command="secret-canary-command"','_TRANSPORT':'audit','__REALTIME_TIMESTAMP':'1770000000123000','_BOOT_ID':'owned'}
        row=activity_evidence.linux_audit_row(raw);self.assertEqual(row['path'],'/srv/owned/document');self.assertNotIn('secret-canary',json.dumps(row))
        activity_evidence.capture_audit([row],source='linux-journal',queried=1)
        self.assertTrue(any(x.get('path')=='/srv/owned/document' for x in activity_evidence.drain()))
    def test_bounded_activity_buffer_and_actual_file_change(self):
        for i in range(400):activity_evidence.queue_activity({'kind':'protected_file_change','path':'/owned/'+str(i),'at':time.time()})
        rows=activity_evidence.drain();self.assertLessEqual(len(rows),256);self.assertTrue(any(x.get('lost_values',0)>0 for x in rows))
        from sentinel_blue.change_watch import ChangeWatcher
        path=self.root/'owned-file';path.write_text('before');watcher=ChangeWatcher([str(path)],poll_interval=.1);watcher.start()
        try:
            time.sleep(.2);path.write_text('after');self.assertTrue(watcher.wait(3))
            self.assertTrue(any(x.get('path')==str(path) for x in activity_evidence.drain()))
        finally:watcher.stop()
    def test_verified_review_exposes_unalerted_activity(self):
        from sentinel_blue.recording_review import review
        r=recording.Recorder(self.root/'recording',background=False,free_floor=0)
        try:
            r.emit('controller_observation',{'telemetry':{'agent_id':'web-host','hostname':'owned','activity_evidence':[{'kind':'native_audit','event_id':'owned-event','category':'object_access','path':'/srv/owned/read','actor':'test-user','occurred_at':time.time()}]},'alert_ids':[]})
            r.stop();result=review(r.export());self.assertTrue(result['verified']);self.assertEqual(result['activity_count'],1)
            self.assertFalse(result['activities'][0]['nearby_alert_observed']);self.assertEqual(result['activities'][0]['path'],'/srv/owned/read')
        finally:r.close()

    @unittest.skipUnless(sys.platform.startswith('linux'),'native Linux inotify check')
    def test_directory_inventory_does_not_flood_protected_file_evidence(self):
        from sentinel_blue.change_watch import ChangeWatcher
        paths=[]
        for i in range(24):
            path=self.root/('protected-'+str(i));path.write_text('owned');paths.append(path)
        watcher=ChangeWatcher([str(p) for p in paths],poll_interval=.1);watcher.start()
        try:
            time.sleep(.2);activity_evidence.drain()
            for _ in range(30):
                with os.scandir(self.root) as entries:list(entries)
            time.sleep(.3)
            self.assertFalse(watcher.wait(.1))
            rows=activity_evidence.drain()
            self.assertFalse(any(x.get('kind') in {'protected_file_change','coverage_gap'} for x in rows))
            paths[0].read_text();time.sleep(2.2)
            rows=activity_evidence.drain()
            self.assertTrue(any(x.get('kind')=='protected_file_access' and x.get('path')==str(paths[0]) for x in rows))
            self.assertFalse(watcher.wait(.1))
            paths[0].write_text('changed');self.assertTrue(watcher.wait(3))
        finally:watcher.stop()

    @unittest.skipUnless(sys.platform.startswith('linux'),'native Linux inotify check')
    def test_actual_read_only_access_is_recorded_without_waking_repair(self):
        from sentinel_blue.change_watch import ChangeWatcher
        path=self.root/'read-only-fixture';path.write_text('owned')
        watcher=ChangeWatcher([str(path)],poll_interval=.1);watcher.start()
        try:
            time.sleep(.2);activity_evidence.drain();self.assertEqual(path.read_text(),'owned')
            time.sleep(2.2)
            self.assertFalse(watcher.wait(.1))
            self.assertTrue(any(x.get('kind')=='protected_file_access' and x.get('path')==str(path) for x in activity_evidence.drain()))
        finally:watcher.stop()
