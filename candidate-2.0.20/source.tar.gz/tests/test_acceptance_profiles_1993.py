"""Historical 1.9.93 example/option coverage, corrected in 1.9.94.

Every configuring service retains a DRAFT baseline and update suggestion. A
builder-refused rejected_options case is a read-only negative test, never a
native failed-apply test. invalid_options and observer wiring remain explicitly
pending. A new gate test verifies all templates report those blockers.
The declared optional-key sweep is robustness coverage, not native acceptance.
"""
import inspect
import itertools
import json
import re
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from sentinel_blue import linux_service_packs as packs
from sentinel_blue import pack_acceptance
from sentinel_blue.linux_service_catalog import CATALOG, CONFIGURE
from sentinel_blue.linux_service_packs import build

from test_generated_script_contract import baseline_for

ROOT = Path(__file__).resolve().parents[1]
PROFILE_PATH = ROOT / "examples/acceptance-profile.example.json"
OPTIONS_PATH = ROOT / "examples/acceptance-options.example.json"
HARNESS = ROOT / "tools/service_pack_acceptance.py"

sys.path.insert(0, str(ROOT / "tools"))
from service_pack_acceptance import (            # noqa: E402
    PROFILE_KEYS, REQUIRED_PROFILE_KEYS)

# withdrawal is the operator's own observer wiring: four paths on a machine this
# repository has never seen. The example documents it and cannot supply it.
HOST_WIRING = {"withdrawal", "invalid_options"}

CONFIGURING = sorted(s for s, row in CATALOG.items() if row["capability"] == CONFIGURE)

# Shapes an operator can plausibly type. Unhashable and None matter most: the
# first crashes a set membership, the second crashes a bare `for` loop.
JUNK = (None, "", "x", 0, -1, True, 1.5, [], {}, [1], [None], [[]], {"a": 1},
        ["10.0.0.1"], [{"a": 1}], {"k": None}, "x" * 300, ({"a": 1},), [["a"]])


def sections(path):
    """The shipped examples are keyed by service id, with comments alongside."""
    payload = json.loads(path.read_text(encoding="utf-8"))
    return {k: v for k, v in payload.items() if not k.startswith("_")}


def declared_options():
    """Every option name each pack accepts, read from its own field list."""
    names = {}
    for service_id, builder in packs.BUILDERS.items():
        found = re.search(r"_fields\(options,\s*\{(.*?)\},",
                          inspect.getsource(builder), re.S)
        names[service_id] = sorted(
            part.strip().strip("\"'") for part in found.group(1).split(",")
            if part.strip()) if found else []
    return names


class ProfileCoverageTests(unittest.TestCase):
    """A service with no complete profile can never be accepted on any host."""

    def setUp(self):
        self.profile = sections(PROFILE_PATH)
        self.options = sections(OPTIONS_PATH)
        # The examples' hash-pinned snapshots name files that ship beside them,
        # so the pack resolves them exactly as the harness does at run time.
        self.root = ROOT / "examples"

    def test_every_configuring_service_has_both_a_profile_and_options(self):
        self.assertEqual(sorted(self.profile), CONFIGURING,
                         "a configuring service without a profile cannot earn a receipt")
        self.assertEqual(sorted(self.options), CONFIGURING,
                         "a service without reviewed options has nothing to accept")

    def test_every_profile_carries_everything_the_gate_requires(self):
        """Read from the harness, so a new requirement cannot ship unanswered."""
        for service_id in CONFIGURING:
            entry = self.profile[service_id]
            with self.subTest(service=service_id):
                for key in REQUIRED_PROFILE_KEYS:
                    if key in HOST_WIRING:
                        continue
                    self.assertTrue(entry.get(key), f"{service_id} is missing {key}")
                self.assertTrue(entry.get("config_test") or CATALOG[service_id]["validate_argv"],
                                f"{service_id} has no configuration test from either source")

    def test_the_profile_holds_nothing_the_harness_would_refuse(self):
        for service_id in CONFIGURING:
            with self.subTest(service=service_id):
                unknown = {k for k in self.profile[service_id] if not k.startswith("_")}
                self.assertFalse(unknown - set(PROFILE_KEYS),
                                 "the harness refuses a profile holding keys it does not read")

    def test_every_probe_names_the_program_it_runs(self):
        """A relative name makes the evidence depend on PATH, which no receipt records."""
        for service_id in CONFIGURING:
            for key in ("positive", "denied", "effective", "config_test"):
                spec = self.profile[service_id].get(key)
                if not spec:
                    continue
                with self.subTest(service=service_id, probe=key):
                    argv = spec.get("argv")
                    self.assertIsInstance(argv, list)
                    self.assertTrue(argv)
                    self.assertTrue(all(isinstance(part, str) and part for part in argv))
                    self.assertTrue(argv[0].startswith("/"), f"{argv[0]} is not an absolute path")

    def test_the_reviewed_option_sets_compile(self):
        for service_id in CONFIGURING:
            entry = self.profile[service_id]
            for options in (self.options[service_id], entry["update_options"]):
                with self.subTest(service=service_id):
                    pack_acceptance.pack_contract(service_id, options, self.root)

    def test_an_approved_update_actually_changes_the_pack(self):
        """A step that proves an approved change needs a change to approve."""
        for service_id in CONFIGURING:
            with self.subTest(service=service_id):
                before = pack_acceptance.pack_fingerprint(
                    service_id, self.options[service_id], self.root)
                after = pack_acceptance.pack_fingerprint(
                    service_id, self.profile[service_id]["update_options"], self.root)
                self.assertNotEqual(before, after)

    def test_the_separate_planning_rejection_example_is_really_refused(self):
        """This is planning refusal, explicitly not failed-apply rollback evidence."""
        for service_id in CONFIGURING:
            with self.subTest(service=service_id):
                with self.assertRaises(ValueError):
                    pack_acceptance.pack_contract(
                        service_id, self.profile[service_id]["rejected_options"], self.root)

    def test_the_profile_says_the_probes_are_unverified(self):
        """The one thing this file must never imply is that the probes were run."""
        text = PROFILE_PATH.read_text(encoding="utf-8")
        self.assertIn("NOT VERIFIED", text)
        for service_id in CONFIGURING:
            with self.subTest(service=service_id):
                self.assertIn("DRAFT", self.profile[service_id].get("_review", ""))

    def test_the_withdrawal_wiring_is_documented_where_it_is_missing(self):
        payload = json.loads(PROFILE_PATH.read_text(encoding="utf-8"))
        note = "\n".join(payload.get("_withdrawal", []))
        self.assertIn("runtime_argv", note)
        for field in ("inventory", "event_profile", "directory"):
            self.assertIn(field, note)


class PlanEveryServiceTests(unittest.TestCase):
    """The shipped examples have to work in the tool that reads them."""

    def plan(self, service_id):
        return subprocess.run(
            [sys.executable, str(HARNESS), "--service", service_id, "--plan",
             "--options", str(OPTIONS_PATH), "--profile", str(PROFILE_PATH)],
            capture_output=True, text=True, timeout=180, cwd=str(ROOT))

    def test_every_service_plans_from_the_shipped_examples(self):
        for service_id in CONFIGURING:
            with self.subTest(service=service_id):
                done = self.plan(service_id)
                self.assertEqual(done.returncode, 0, done.stderr)
                self.assertIn("BLOCKED: invalid_options is missing or empty", done.stdout)
                self.assertIn("BLOCKED: withdrawal is missing or empty", done.stdout)
                self.assertIn("reviewed previous_sha256", done.stdout)

    def test_a_package_less_service_still_plans(self):
        """gunicorn wraps an application the operator supplies and declares no package."""
        done = self.plan("gunicorn")
        self.assertEqual(done.returncode, 0, done.stderr)
        self.assertIn("none declared", done.stdout)
        self.assertNotIn("Traceback", done.stderr)


class EveryDeclaredOptionTests(unittest.TestCase):
    """The sweep that would have caught `dnsmasq addresses` four releases ago."""

    def setUp(self):
        self.root = Path(tempfile.mkdtemp(prefix="sentinel-declared-"))

    def test_every_pack_declares_the_options_it_reads(self):
        names = declared_options()
        self.assertEqual(sorted(names), sorted(packs.BUILDERS))
        for service_id, options in names.items():
            with self.subTest(service=service_id):
                self.assertTrue(options, f"{service_id} declares no options to sweep")

    def test_no_declared_option_crashes_on_any_shape(self):
        names = declared_options()
        tried = 0
        for service_id in sorted(names):
            baseline = baseline_for(service_id, self.root)
            for key, value in itertools.product(names[service_id], JUNK):
                tried += 1
                with self.subTest(service=service_id, option=key, value=repr(value)[:20]):
                    try:
                        build(service_id, {**baseline, key: value}, self.root)
                    except ValueError:
                        pass
                    except Exception as exc:      # noqa: BLE001 - that is the point
                        self.fail(f"{service_id}.{key}={value!r} raised "
                                  f"{type(exc).__name__}: {exc}")
        self.assertGreater(tried, 2000)

    def test_the_specific_shapes_that_were_crashing(self):
        """Named so a regression reads as the bug it was, not as a sweep failure."""
        cases = [
            ("dnsmasq", "addresses", ["scored.range.test"]),      # .items() on a list
            ("dovecot", "protocols", None),                       # iterate None
            ("dovecot", "protocols", [[]]),                       # unhashable member
            ("openssh-server", "allow_users", None),
            ("postgresql", "listen_addresses", None),
            ("unbound", "access_control", None),
            ("unbound", "forwarders", None),
        ]
        for service_id, key, value in cases:
            baseline = baseline_for(service_id, self.root)
            with self.subTest(service=service_id, option=key, value=repr(value)):
                with self.assertRaises(ValueError):
                    build(service_id, {**baseline, key: value}, self.root)

    def test_a_null_option_is_refused_rather_than_silently_emptied(self):
        """`"protocols": null` used to mean "no protocols at all", not "the default".

        The default is what the operator read in the documentation; an empty list
        is a Dovecot serving nothing. The two are not the same answer, and the
        pack cannot know which was meant, so it says so.
        """
        baseline = baseline_for("dovecot", self.root)
        with self.assertRaises(ValueError) as caught:
            build("dovecot", {**baseline, "protocols": None}, self.root)
        self.assertIn("remove the option", str(caught.exception))
        # Absence still keeps the documented default.
        build("dovecot", {k: v for k, v in baseline.items() if k != "protocols"}, self.root)

    def test_a_dnsmasq_address_map_still_works(self):
        """The fix must refuse the mistake without refusing the correct shape."""
        baseline = baseline_for("dnsmasq", self.root)
        build("dnsmasq", {**baseline, "addresses": {"scored.range.test": "192.168.10.20"}},
              self.root)


if __name__ == "__main__":
    unittest.main()
