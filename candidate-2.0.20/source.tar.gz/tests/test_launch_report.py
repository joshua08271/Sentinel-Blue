"""Reporting a failed launch to someone who has no terminal to read.

The message is put on screen by whatever helper the desktop provides. That means
handing text that came from an exception to another program, so the two things
worth proving are that it reaches the helper intact as a single argument, and
that it can never be interpreted as a command or as an option.
"""
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from sentinel_blue import launch_report

HELPER = """#!/bin/sh
printf '%s\\n' "$@" > "$RECORD"
exit 0
"""


class MessageTests(unittest.TestCase):
    def test_a_long_message_is_bounded(self):
        text = launch_report._clean("x" * 5000)
        self.assertLessEqual(len(text), launch_report.LIMIT)

    def test_newlines_and_control_characters_collapse_to_one_line(self):
        text = launch_report._clean("first\n\tsecond\r\n   third")
        self.assertEqual(text, "first second third")

    def test_an_empty_message_still_says_something(self):
        self.assertTrue(launch_report._clean("   "))

    def test_the_reason_always_reaches_stderr(self):
        with patch.dict(os.environ, {"DISPLAY": "", "WAYLAND_DISPLAY": ""}, clear=False):
            with patch("sys.stderr", new=__import__("io").StringIO()) as captured:
                shown = launch_report.report("Tk is not installed")
        self.assertFalse(shown)
        self.assertIn("Tk is not installed", captured.getvalue())

    def test_no_helper_is_run_without_a_graphical_session(self):
        with patch.dict(os.environ, {"DISPLAY": "", "WAYLAND_DISPLAY": ""}, clear=False):
            with patch("subprocess.run") as run, patch("sys.stderr", new=__import__("io").StringIO()):
                launch_report.report("no display here")
        run.assert_not_called()


@unittest.skipUnless(os.name == "posix" and Path("/bin/sh").exists(),
                     "the dialog helpers are POSIX programs")
class HelperInvocationTests(unittest.TestCase):
    """A real helper on PATH, so the actual argument list can be inspected."""

    def setUp(self):
        self.root = Path(tempfile.mkdtemp(prefix="sentinel-report-"))
        self.record = self.root / "argv"
        helper = self.root / "zenity"
        helper.write_text(HELPER)
        helper.chmod(0o755)

    def show(self, message):
        environment = {"PATH": str(self.root), "DISPLAY": ":99",
                       "RECORD": str(self.record)}
        with patch.dict(os.environ, environment, clear=False):
            with patch("sys.stderr", new=__import__("io").StringIO()):
                shown = launch_report.report(message)
        arguments = self.record.read_text().splitlines() if self.record.exists() else []
        return shown, arguments

    def test_the_message_arrives_as_one_argument(self):
        shown, arguments = self.show("Tk is not installed; run apt install python3-tk")
        self.assertTrue(shown)
        self.assertIn("Tk is not installed; run apt install python3-tk", arguments)

    def test_shell_metacharacters_are_never_interpreted(self):
        marker = self.root / "executed"
        shown, arguments = self.show(f"boom $(touch {marker}); rm -rf ~ && echo done")
        self.assertTrue(shown)
        self.assertFalse(marker.exists(), "the message reached a shell")
        self.assertIn(f"boom $(touch {marker}); rm -rf ~ && echo done", arguments)

    def test_a_message_that_looks_like_an_option_is_still_text(self):
        shown, arguments = self.show("--version --display=:0")
        self.assertTrue(shown)
        # It follows --text, so the helper reads it as that option's value.
        self.assertEqual(arguments[arguments.index("--text") + 1], "--version --display=:0")

    def test_a_helper_that_is_absent_is_skipped_not_fatal(self):
        (self.root / "zenity").unlink()
        # PATH only removes external helpers, not the importable Tk fallback.
        # A real :99 from Xvfb could otherwise open an unanswerable modal dialog
        # in this unit test. Actual Tk/window behavior has a separate GUI harness.
        with patch.object(launch_report, "_tk_dialog", return_value=False) as dialog:
            shown, _ = self.show("nothing can show this")
        self.assertFalse(shown)
        dialog.assert_called_once()


if __name__ == "__main__":
    unittest.main()
