"""Linux findings 15-20: private files/processes; native network commands modeled.

Does not change host users, services, routes, firewall rules or startup entries.
"""
from __future__ import annotations
import base64
import copy
from contextlib import ExitStack
from dataclasses import asdict
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from sentinel_blue import network_native as net, collectors, payload_inventory
from sentinel_blue import bounded_capture as cap, native_probes, service_pack_checks as checks
from sentinel_blue import analyzers
from sentinel_blue.learning import RiskModel
from sentinel_blue.mutation_ledger import MutationLedger
from sentinel_blue.protocol import ProbeResult
from sentinel_blue.setup import SetupRunner
from sentinel_blue.setup_transport import CommandResult
from sentinel_blue.withdrawal_router import RouterAdapter
from test_linux_hotfix_1997 import RouterModel, POSIX_ROOT, ROUTE


@unittest.skipUnless(POSIX_ROOT, 'Private root-owned Linux fixtures')
class RouterLifecycle1998(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack(); self.addCleanup(self.stack.close)
        self.root = Path(self.stack.enter_context(tempfile.TemporaryDirectory(prefix='sb-1998-', dir='/var/lib')))
        self.model = RouterModel(self.root); self.model.enter(self.stack)
        self.spec = self.model.spec; self.ledger = MutationLedger()

    def rows(self):
        return self.ledger.actions(include_states=True)

    def initial(self):
        net.run('apply', self.spec, 'old helper'); net.run('commit', self.spec, 'old helper')
        return self.model.state()

    def fail_reload_once(self):
        fired = []
        def hook(argv, data):
            if argv == ['systemctl', 'daemon-reload'] and not fired:
                fired.append(True); raise RuntimeError('controlled reload failure')
        self.model.hook = hook

    def update(self):
        return {**self.spec, 'ruleset': 'table inet sentinel_blue_fixture { # UPDATE\n}\n'}

    def test_automatic_initial_rollback_cancels_ledger_immediately(self):
        self.fail_reload_once()
        with self.assertRaisesRegex(RuntimeError, 'controlled reload'):
            net.run('apply', self.spec, 'helper')
        self.assertEqual([r['status'] for r in self.rows()], ['cancelled'])
        self.assertEqual(self.model.state()['status'], 'rolled-back')

    def test_clean_failed_apply_can_retry(self):
        self.test_automatic_initial_rollback_cancels_ledger_immediately()
        net.run('apply', self.spec, 'helper')
        self.assertEqual([r['status'] for r in self.rows()], ['cancelled', 'applied'])

    def test_explicit_retry_of_completed_inverse_is_idempotent(self):
        self.test_automatic_initial_rollback_cancels_ledger_immediately()
        head = self.ledger.head(); events = len(self.model.events)
        net.run('rollback', self.spec, 'helper')
        self.assertEqual(self.ledger.head(), head)
        self.assertEqual(len(self.model.events), events)

    def failed_update(self):
        old = self.initial(); self.fail_reload_once()
        with self.assertRaisesRegex(RuntimeError, 'controlled reload'):
            net.run('apply', self.update(), 'new helper')
        self.assertEqual(self.model.state(), old)
        self.assertEqual([r['status'] for r in self.rows()], ['committed', 'cancelled'])
        self.assertEqual(self.rows()[0]['after'], net.ledger_snapshot(self.spec))

    def test_automatic_update_rollback_rebases_previous_revision(self):
        self.failed_update()
        self.assertTrue(net.verify(self.spec, self.model.state()))

    def test_automatic_update_rollback_preserves_withdrawal(self):
        self.failed_update(); prior = self.rows()[0]
        RouterAdapter(self.ledger).restore(prior['target'], prior['before'], prior['after'])
        self.assertIsNone(self.model.table); self.assertFalse(self.model.unit.exists())

    def test_automatic_update_rollback_preserves_boot_and_original_inverse(self):
        self.failed_update(); before = self.rows()[0]['before_hash']
        net.run('boot', self.spec, 'old helper')
        prior = self.rows()[0]; self.assertEqual(prior['before_hash'], before)
        RouterAdapter(self.ledger).restore(prior['target'], prior['before'], prior['after'])
        self.assertFalse(self.model.unit.exists())

    def test_expired_commit_reconciles_inverse(self):
        net.run('apply', self.spec, 'helper'); state = self.model.state()
        state['expires_monotonic'] = 0; net.save(self.root/'state.json', state)
        with self.assertRaisesRegex(ValueError, 'deadline expired'):
            net.run('commit', self.spec, 'helper')
        self.assertEqual(self.rows()[0]['status'], 'cancelled')

    def test_expired_activate_reconciles_inverse(self):
        net.run('apply', self.spec, 'helper'); state = self.model.state()
        state['expires_monotonic'] = 0; net.save(self.root/'state.json', state)
        with self.assertRaisesRegex(ValueError, 'deadline expired'):
            net.run('activate', self.spec, 'helper')
        self.assertEqual(self.rows()[0]['status'], 'cancelled')

    def test_pending_boot_rollback_reconciles_inverse(self):
        net.run('apply', self.spec, 'helper'); net.run('boot', self.spec, 'helper')
        self.assertEqual(self.rows()[0]['status'], 'cancelled')

    def test_completion_is_durable_before_restored_state_publication(self):
        net.run('apply', self.spec, 'helper'); real = net.save
        def crash(path, value):
            if path == self.root/'state.json' and value.get('status') == 'rolled-back':
                self.assertTrue(any(e['kind'] == 'router_rollback_completed' for e in self.ledger.read()))
                raise RuntimeError('simulated publication interruption')
            return real(path, value)
        with patch.object(net, 'save', side_effect=crash):
            with self.assertRaisesRegex(RuntimeError, 'publication interruption'):
                net._run('rollback', self.spec, 'helper')
        self.assertEqual(self.model.state()['status'], 'pending')
        net.run('rollback', self.spec, 'helper')
        self.assertEqual(self.model.state()['status'], 'rolled-back')
        self.assertEqual(self.rows()[0]['status'], 'cancelled')

    def test_retry_after_prior_rebase_before_cancel(self):
        self.initial(); updated = self.update(); net.run('apply', updated, 'new helper')
        real = MutationLedger.append
        def crash(ledger, kind, **kw):
            if kind == 'cancelled':
                raise RuntimeError('simulated ledger cancellation interruption')
            return real(ledger, kind, **kw)
        with patch.object(MutationLedger, 'append', new=crash):
            with self.assertRaisesRegex(RuntimeError, 'cancellation interruption'):
                net.run('rollback', updated, 'new helper')
        self.assertEqual(self.rows()[0]['after'], net.ledger_snapshot(self.spec))
        net.run('rollback', updated, 'new helper')
        self.assertEqual([r['status'] for r in self.rows()], ['committed', 'cancelled'])

    def test_changed_file_after_completed_inverse_is_not_rebased(self):
        self.initial(); updated = self.update(); net.run('apply', updated, 'new helper')
        net._run('rollback', updated, 'new helper')  # interruption before wrapper reconciliation
        self.model.unit.chmod(0o640)
        with self.assertRaisesRegex(ValueError, 'changed after recorded rollback'):
            net.run('rollback', updated, 'new helper')
        self.assertEqual(self.model.unit.stat().st_mode & 0o777, 0o640)
        self.assertEqual(self.rows()[1]['status'], 'applied')

    def test_changed_lifecycle_after_completion_is_not_replaced(self):
        net.run('apply', self.spec, 'helper'); net._run('rollback', self.spec, 'helper')
        state = self.model.state(); state['outside_annotation'] = 'operator'
        net.save(self.root/'state.json', state)
        with self.assertRaisesRegex(ValueError, 'lifecycle state changed'):
            net.run('rollback', self.spec, 'helper')
        self.assertEqual(self.model.state()['outside_annotation'], 'operator')
        self.assertEqual(self.rows()[0]['status'], 'applied')

    def test_no_completed_event_does_not_authorize_cancellation(self):
        net.run('apply', self.spec, 'helper')
        net.rollback(self.spec, self.model.state())  # no authenticated completion on this low-level call
        self.ledger.append('uncertain', action_id=self.rows()[0]['action_id'])
        with self.assertRaisesRegex(ValueError, 'unresolved ledger'):
            net.run('rollback', self.spec, 'helper')
        self.assertEqual(self.rows()[0]['status'], 'uncertain')

    def test_altered_previous_state_refuses_before_inverse(self):
        self.initial(); updated = self.update(); net.run('apply', updated, 'new helper')
        state = self.model.state(); state['before']['state']['ledger_action_id'] = 'forged'
        net.save(self.root/'state.json', state); before = net.ledger_snapshot(updated)
        with self.assertRaisesRegex(ValueError, 'preceding state differs'):
            net.run('rollback', updated, 'new helper')
        self.assertEqual(before, net.ledger_snapshot(updated))

    def test_failed_final_reload_has_no_success_receipt(self):
        net.run('apply', self.spec, 'helper')
        def hook(argv, data):
            if argv == ['systemctl', 'daemon-reload']:
                raise RuntimeError('final reload failure')
        self.model.hook = hook
        with self.assertRaisesRegex(RuntimeError, 'final reload failure'):
            net.run('rollback', self.spec, 'helper')
        self.assertEqual(self.model.state()['status'], 'pending')
        self.assertFalse(any(e['kind']=='router_rollback_completed' for e in self.ledger.read()))
        self.model.hook = None; net.run('rollback', self.spec, 'helper')
        self.assertEqual(self.rows()[0]['status'], 'cancelled')

    def test_real_setup_runner_reports_clean_rollback_with_released_ownership(self):
        self.fail_reload_once(); result = self.runner_task()
        self.assertEqual(result['status'], 'failed')
        self.assertEqual(result['rollback_status'], 'completed')
        self.assertEqual(self.rows()[0]['status'], 'cancelled')

    def runner_task(self):
        outer = self
        class Transport:
            def execute(self, host, script, seconds):
                try:
                    if script == 'commit':
                        net.run('activate', outer.spec, 'helper')
                    net.run(script, outer.spec, 'helper'); code = 0
                except SystemExit as exc:
                    code = exc.code
                except Exception:
                    code = 1
                return CommandResult(code, 0.0)
        profile = SimpleNamespace(authorized_networks=['127.0.0.0/8'], authorized_hosts=['127.0.0.1'], excluded_hosts=[])
        runner = SetupRunner({'hosts': {'fixture': {'name':'fixture','platform':'linux','transport':'local','address':'127.0.0.1'}}},
             profile, transport=Transport(), probe=lambda spec,*a,**k:ProbeResult(name='fixture-tcp',target=spec['target'],healthy=True,latency_ms=1))
        runner.started_monotonic=time.monotonic();runner.remaining_at_start=60
        return runner._task_transaction({'host':'fixture','recipe':'linux-router','check':'check','apply':'apply',
               'rollback':'rollback','commit':'commit','timeout_seconds':40,'health_wait_seconds':5,
               'probes':[{'kind':'tcp','name':'fixture-tcp','target':'127.0.0.1','port':22}]})

    def test_healthy_router_setup_runner_is_ready(self):
        self.initial(); head = self.ledger.head()
        self.assertEqual(self.runner_task()['status'], 'ready')
        self.assertEqual(self.ledger.head(), head)

    def metadata_conflict(self, change):
        self.initial(); change(); before = net.ledger_snapshot(self.spec); head=self.ledger.head()
        self.assertFalse(net.verify(self.spec, self.model.state()))
        with self.assertRaises(ValueError):
            net.run('apply', self.update(), 'new helper')
        self.assertEqual(before, net.ledger_snapshot(self.spec)); self.assertEqual(head,self.ledger.head())

    def test_committed_permissions_preserved(self):
        self.metadata_conflict(lambda:self.model.unit.chmod(0o640))

    def test_committed_group_preserved(self):
        self.metadata_conflict(lambda:os.chown(self.model.unit,0,65534))

    def test_committed_attributes_preserved(self):
        self.metadata_conflict(lambda:os.setxattr(self.model.unit,'user.sb_fixture',b'operator'))

    def test_same_byte_replacement_preserved(self):
        def replace():
            p=self.root/'replacement';p.write_bytes(self.model.unit.read_bytes());p.chmod(0o600);os.replace(p,self.model.unit)
        self.metadata_conflict(replace)

    def test_same_byte_rewrite_preserved(self):
        self.metadata_conflict(lambda:self.model.unit.write_bytes(self.model.unit.read_bytes()))

    def test_pending_admission_binds_authenticated_prestate(self):
        self.initial(); real=net.ledger_snapshot; counter=[]
        def snapshot(spec):
            state=real(spec)
            if spec==self.update() and not counter:
                counter.append(True);self.model.unit.chmod(0o640)
            return state
        with patch.object(net,'ledger_snapshot',side_effect=snapshot):
            with self.assertRaises(ValueError):
                net.run('apply',self.update(),'new')
        self.assertEqual(self.model.unit.stat().st_mode&0o777,0o640)

    def test_commit_repeat_has_no_duplicate_events_or_commands(self):
        self.initial(); head=self.ledger.head();events=len(self.model.events)
        net.run('commit',self.spec,'helper')
        self.assertEqual(head,self.ledger.head())
        self.assertFalse(any(a[0]=='systemctl' and a[1]!='is-enabled' for a,_ in self.model.events[events:]))

    def test_idempotent_apply_has_no_new_action(self):
        self.initial();head=self.ledger.head();net.run('apply',self.spec,'helper')
        self.assertEqual(head,self.ledger.head())

    def test_repeat_commit_after_metadata_change_refuses(self):
        self.initial();self.model.unit.chmod(0o640)
        with self.assertRaises(ValueError):net.run('commit',self.spec,'helper')
        self.assertEqual(self.rows()[0]['status'],'committed')

    def test_repeat_commit_wrong_spec_refuses(self):
        self.initial()
        with self.assertRaises(ValueError):net.run('commit',self.update(),'helper')

    def test_unresolved_record_blocks_false_healthy_confirmation(self):
        self.initial();prior=self.rows()[0]
        aid=self.ledger.prepare('router-v1',dict(prior['target'],action_id='fixture-pending'),prior['after'],action_id='fixture-pending')
        self.ledger.append('uncertain',action_id=aid)
        with self.assertRaises(ValueError):net.run('commit',self.spec,'helper')
        with self.assertRaises(SystemExit) as error:net.run('check',self.spec,'helper')
        self.assertEqual(error.exception.code,10)

    def test_missing_authentication_still_blocks_confirmation(self):
        self.initial();state=self.model.state();state['ledger_action_id']='unknown';net.save(self.root/'state.json',state)
        with self.assertRaisesRegex(ValueError,'authenticated ownership'):net.run('commit',self.spec,'helper')

    def test_boot_does_not_adopt_teammate_metadata(self):
        self.initial();self.model.unit.chmod(0o640);before=len(self.model.mutations())
        with self.assertRaises(ValueError):net.run('boot',self.spec,'helper')
        self.assertEqual(len(self.model.mutations()),before)


    def test_wrong_spec_boot_does_not_change_ledger_status(self):
        self.initial();head=self.ledger.head()
        with self.assertRaisesRegex(ValueError,'boot configuration is untrusted'):
            net.run('boot',self.update(),'helper')
        self.assertEqual(head,self.ledger.head());self.assertEqual(self.rows()[0]['status'],'committed')

    def legacy_helper(self):
        # Frozen 1.9.97 native-helper source with the unchanged ledger API. This
        # exercises its actual old record shape, not guessed compatibility data.
        import types
        mod = types.ModuleType('sentinel_blue._native_1997_fixture')
        mod.__package__ = 'sentinel_blue'
        raw = (Path(__file__).parent/'fixtures/network_native_1997.py.txt').read_text()
        exec(compile(raw, 'network_native_1997_fixture', 'exec'), mod.__dict__)
        self.stack.enter_context(patch.object(mod,'names',return_value=(self.root,self.model.service,'sentinel_blue_fixture')))
        self.stack.enter_context(patch.object(mod,'units',return_value=self.model.units))
        self.stack.enter_context(patch.object(mod,'command',side_effect=self.model.command))
        self.stack.enter_context(patch.object(mod,'table_data',side_effect=lambda *a,**k:self.model.table))
        self.stack.enter_context(patch.object(mod,'table_fingerprint',side_effect=lambda _:net.digest(self.model.table) if self.model.table is not None else None))
        self.stack.enter_context(patch.object(mod,'forwarding_value',side_effect=lambda:self.model.forwarding))
        return mod

    def test_intact_1997_committed_state_can_update_and_roll_back(self):
        legacy=self.legacy_helper();legacy.run('apply',self.spec,'old helper');legacy.run('commit',self.spec,'old helper')
        old=self.model.state();self.assertNotIn('previous_state_hash',self.rows()[0]['target'])
        updated=self.update();net.run('apply',updated,'new helper');net.run('rollback',updated,'new helper')
        self.assertEqual(self.model.state(),old);self.assertTrue(net.verify(self.spec,old))
        prior=self.rows()[0];RouterAdapter(self.ledger).restore(prior['target'],prior['before'],prior['after'])
        self.assertFalse(self.model.unit.exists())

    def test_1997_pending_state_without_new_proof_holds_before_mutation(self):
        legacy=self.legacy_helper();legacy.run('apply',self.spec,'old helper')
        before=net.ledger_snapshot(self.spec);events=len(self.model.mutations())
        with self.assertRaisesRegex(ValueError,'Legacy router rollback'):
            net.run('rollback',self.spec,'old helper')
        self.assertEqual(net.ledger_snapshot(self.spec),before)
        self.assertEqual(len(self.model.mutations()),events);self.assertEqual(self.rows()[0]['status'],'applied')


class PrivilegeEvidence1998(unittest.TestCase):
    def observe(self,uid='65534 0 0 0',capability='0000000000000000'):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);p=root/'321';p.mkdir()
            (p/'status').write_text('Name:\tfixture\nUid:\t'+uid+'\nPPid:\t1\n'+('CapEff:\t'+capability+'\n' if capability is not None else ''))
            real=Path;errors=[]
            with patch('sentinel_blue.process_identity._linux_namespace_depth',return_value=1),patch.object(collectors,'Path',side_effect=lambda x:root if x=='/proc' else real(x)),patch.object(collectors.os,'readlink',return_value='/tmp/fixture'):
                rows=collectors._linux_processes(errors)
            return rows,errors

    def test_effective_root_and_real_identity_retained(self):
        rows,errors=self.observe();self.assertFalse(errors);r=rows[0]
        self.assertTrue(r.privileged);self.assertEqual((r.real_uid,r.effective_uid),(65534,0))

    def test_effective_root_reaches_temporary_process_analyzer(self):
        rows,errors=self.observe()
        found=analyzers.analyze_processes({'processes':[asdict(r) for r in rows]},{'processes':[]},RiskModel())
        self.assertTrue(found)

    def test_saved_root_is_reported_conservatively(self):
        self.assertTrue(self.observe('65534 65534 0 65534')[0][0].privileged)

    def test_filesystem_root_is_reported(self):
        self.assertTrue(self.observe('65534 65534 65534 0')[0][0].privileged)

    def test_real_root_retained(self):
        self.assertTrue(self.observe('0 65534 65534 65534')[0][0].privileged)

    def test_nonroot_without_capabilities_is_not_root_classified(self):
        self.assertFalse(self.observe('65534 65534 65534 65534')[0][0].privileged)

    def test_effective_capability_is_reported_conservatively(self):
        self.assertTrue(self.observe('65534 65534 65534 65534','0000000000000001')[0][0].privileged)

    def test_invalid_uid_fields_are_incomplete_not_false_negative(self):
        for value in ('','65534','65534 0 x 0','-1 0 0 0','4294967296 0 0 0'):
            with self.subTest(value=value):
                rows,errors=self.observe(value);self.assertFalse(rows);self.assertTrue(errors)

    def test_bad_capability_marks_incomplete_retains_known_root(self):
        rows,errors=self.observe(capability='invalid');self.assertTrue(errors);self.assertTrue(rows[0].privileged)

    @unittest.skipUnless(POSIX_ROOT,'Existing effective-root fixture')
    def test_real_child_with_different_real_and_effective_uid(self):
        proc=subprocess.Popen([sys.executable,'-c',"import os,time;os.setresuid(65534,0,0);print(os.getpid(),flush=True);time.sleep(15)"],stdout=subprocess.PIPE,text=True)
        try:
            self.assertEqual(proc.stdout.readline().strip(),str(proc.pid))
            rows=collectors._linux_processes([]);row=next(r for r in rows if r.process_id==proc.pid)
            self.assertTrue(row.privileged);self.assertEqual((row.real_uid,row.effective_uid),(65534,0))
        finally:
            proc.terminate();proc.wait(timeout=3);proc.stdout.close()


@unittest.skipUnless(POSIX_ROOT,'Private root-owned persistence fixtures')
class PersistenceCoverage1998(unittest.TestCase):
    def collect(self,count=0,units=0,code=0,failure=None,denied=False):
        with tempfile.TemporaryDirectory(dir='/var/lib',prefix='sb-persist1998-') as tmp,ExitStack() as stack:
            root=Path(tmp);d=root/'cron';d.mkdir()
            for i in range(count):(d/f'fixture-{i:04d}').write_text('# benign fixture\n')
            def paths(raw):return d if raw=='/etc/cron.d' else root/'absent'/str(raw).lstrip('/')
            stack.enter_context(patch.object(collectors,'Path',side_effect=paths))
            stack.enter_context(patch.object(collectors.pwd,'getpwall',return_value=[]))
            stack.enter_context(patch.object(payload_inventory,'linux_startup_payloads',return_value=[]))
            stack.enter_context(patch.object(payload_inventory,'linux_process_payloads',return_value=[]))
            stack.enter_context(patch.object(collectors,'_run',side_effect=failure,return_value=subprocess.CompletedProcess([],code,''.join(f'fixture-{i}.service enabled\n' for i in range(units)),'')))
            if denied:
                real=Path.iterdir
                def listing(path):
                    if path==d:raise PermissionError('controlled')
                    return real(path)
                stack.enter_context(patch.object(Path,'iterdir',listing))
            errors=[];rows=collectors._linux_persistence(errors)
            return rows,errors

    def test_directory_overflow_is_explicit(self):
        rows,errors=self.collect(count=1025);self.assertEqual(len(rows),1024);self.assertTrue(any('1024' in e for e in errors))

    def test_exact_directory_limit_is_complete(self):
        rows,errors=self.collect(count=1024);self.assertEqual(len(rows),1024);self.assertFalse(errors)

    def test_empty_missing_sources_are_normal(self):
        rows,errors=self.collect();self.assertFalse(rows);self.assertFalse(errors)

    def test_unit_overflow_is_explicit(self):
        rows,errors=self.collect(units=2049);self.assertEqual(len(rows),2048);self.assertTrue(any('2048' in e for e in errors))

    def test_exact_unit_limit_is_complete(self):
        rows,errors=self.collect(units=2048);self.assertEqual(len(rows),2048);self.assertFalse(errors)

    def test_failed_unit_inventory_is_incomplete(self):
        rows,errors=self.collect(code=1);self.assertTrue(errors)

    def test_timed_out_unit_inventory_is_incomplete(self):
        rows,errors=self.collect(count=1,failure=subprocess.TimeoutExpired('fixture',1))
        self.assertTrue(errors);self.assertEqual(len(rows),1)

    def test_unreadable_directory_is_incomplete(self):
        rows,errors=self.collect(denied=True);self.assertTrue(errors)


@unittest.skipUnless(os.name=='posix','Local Linux native-client capture')
class BoundedNativeClients1998(unittest.TestCase):
    def command(self,script,seconds=3,limit=1024,**kw):
        return cap.capture_command([sys.executable,'-c',script],seconds,limit=limit,**kw)

    def test_normal_output_and_input(self):
        code,data=self.command('import sys;sys.stdout.buffer.write(sys.stdin.buffer.read())',incoming=b'private input')
        self.assertEqual((code,data),(0,b'private input'))

    def test_exact_quota_succeeds(self):
        self.assertEqual(len(self.command('import sys;sys.stdout.buffer.write(b"x"*1024)')[1]),1024)

    def test_one_byte_overflow_refuses(self):
        with self.assertRaises(cap.CaptureError) as exc:self.command('import sys;sys.stdout.buffer.write(b"x"*1025)')
        self.assertEqual(exc.exception.reason,'output_limit_exceeded');self.assertEqual(exc.exception.captured_bytes,1024)

    def test_stderr_uses_same_quota_when_merged(self):
        with self.assertRaises(cap.CaptureError) as exc:self.command('import sys;sys.stderr.buffer.write(b"x"*1025)',merge_stderr=True)
        self.assertEqual(exc.exception.reason,'output_limit_exceeded')

    def test_stderr_discarded_not_spooled(self):
        code,data=self.command('import sys;sys.stderr.buffer.write(b"x"*2000000);print("ok")')
        self.assertEqual((code,data),(0,b'ok\n'))

    def test_no_output_temporary_file(self):
        real=tempfile.TemporaryFile;sizes=[]
        class Input:
            def __init__(self):self.file=real()
            def __enter__(self):return self.file
            def __exit__(self,*args):sizes.append(os.fstat(self.file.fileno()).st_size);self.file.close()
        with patch.object(tempfile,'TemporaryFile',side_effect=lambda:Input()):
            self.assertEqual(len(self.command('import sys;sys.stdout.buffer.write(b"x"*1024)')[1]),1024)
        self.assertEqual(sizes,[0])

    def test_service_pack_limit_is_enforced_during_execution(self):
        with self.assertRaisesRegex(ValueError,'output_limit_exceeded'):
            checks._command([sys.executable,'-c','import sys;sys.stdout.buffer.write(b"x"*(2*1024*1024))'])

    def test_scoring_limit_is_enforced_during_execution(self):
        with self.assertRaisesRegex(RuntimeError,'64 KiB'):
            native_probes._command([sys.executable,'-c','import sys;sys.stdout.buffer.write(b"x"*(2*1024*1024))'],3)

    def test_native_scoring_still_returns_complete_small_output(self):
        self.assertEqual(native_probes._command([sys.executable,'-c','print("1")'],3),b'1\n')

    def test_nonzero_exit_is_not_success(self):
        with self.assertRaisesRegex(RuntimeError,'client failed'):
            native_probes._command([sys.executable,'-c','raise SystemExit(2)'],3)

    def test_capture_preserves_nonzero_exit_for_caller(self):
        self.assertEqual(self.command('print("x");raise SystemExit(7)'),(7,b'x\n'))

    def test_silent_timeout_is_explicit(self):
        start=time.monotonic()
        with self.assertRaises(cap.CaptureError) as exc:self.command('import time;time.sleep(10)',seconds=.15)
        self.assertEqual(exc.exception.reason,'deadline_exceeded');self.assertLess(time.monotonic()-start,3)

    def test_closed_stdout_live_process_times_out(self):
        with self.assertRaises(cap.CaptureError):self.command('import os,time;os.close(1);time.sleep(10)',seconds=.15)

    def test_scoring_timeout_remains_timeout(self):
        with self.assertRaises(TimeoutError):native_probes._command([sys.executable,'-c','import time;time.sleep(10)'],.15)

    def test_invalid_budget_does_not_launch(self):
        for seconds in (0,-1,True,float('nan'),float('inf')):
            with self.subTest(seconds=seconds),patch.object(cap.subprocess,'Popen') as launch:
                with self.assertRaises(cap.CaptureError):self.command('pass',seconds=seconds)
                launch.assert_not_called()

    def test_failure_does_not_echo_arguments_or_output(self):
        token='fixture-secret-do-not-log'
        with self.assertRaises(cap.CaptureError) as exc:self.command('import sys;print('+repr(token+'x'*1025)+')')
        self.assertNotIn(token,str(exc.exception))

    def test_descendant_outliving_leader_is_stopped_on_overflow(self):
        with tempfile.TemporaryDirectory() as tmp:
            mark=Path(tmp)/'late';ready=Path(tmp)/'ready'
            child="import os,signal,time,pathlib;signal.signal(signal.SIGTERM,signal.SIG_IGN);pathlib.Path("+repr(str(ready))+").write_text(str(os.getpid()));time.sleep(1);pathlib.Path("+repr(str(mark))+").write_text('late')"
            # The descendant writes to DEVNULL, so closing the capture pipe cannot
            # terminate it accidentally through BrokenPipe/SIGPIPE.
            parent="import subprocess,sys,os,time,pathlib;subprocess.Popen([sys.executable,'-c',"+repr(child)+"],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)\nwhile not pathlib.Path("+repr(str(ready))+").exists(): time.sleep(.005)\nos.write(1,b'x'*4096);os._exit(0)"
            pid=None
            try:
                with self.assertRaises(cap.CaptureError):self.command(parent)
                pid=int(ready.read_text());status=Path('/proc')/str(pid)/'stat'
                self.assertTrue(not status.exists() or status.read_text().split(') ',1)[1].startswith('Z'))
                time.sleep(1.1);self.assertFalse(mark.exists())
            finally:
                if pid is not None:
                    try:os.kill(pid,9)
                    except ProcessLookupError:pass

    def test_zero_quota_allows_empty_not_nonempty_output(self):
        self.assertEqual(self.command('pass',limit=0),(0,b''))
        with self.assertRaises(cap.CaptureError):self.command('print(1)',limit=0)

    def test_invalid_quota_and_input_refuse_before_launch(self):
        for kw in ({'limit':-1},{'limit':True},{'incoming':'not bytes'}):
            with self.subTest(kw=kw),patch.object(cap.subprocess,'Popen') as launch:
                with self.assertRaises(ValueError):self.command('pass',**kw)
                launch.assert_not_called()

    def test_embedded_service_checker_has_self_contained_capture(self):
        # Execute the generated standalone bootstrap in isolated Python: no installed
        # Sentinel package and no service/control command is admitted by this spec.
        pre,config=checks.check_scripts('fixture',{}, {})
        body=config.split("\n",1)[1].rsplit('SENTINEL_PACK_CHECK',1)[0]
        result=subprocess.run([sys.executable,'-I','-c',body+"\nassert ns['_command']([__import__('sys').executable,'-c','print(123)']).strip()=='123'\n"],capture_output=True,text=True,timeout=5,cwd='/')
        self.assertEqual(result.returncode,0,result.stderr)

if __name__=='__main__':unittest.main()
