"""Admission, persistence and busy-worker regressions for emergency pause."""
import copy
import http.server
import json
import tempfile
import threading
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

from sentinel_blue.desktop_control import DesktopClient
from sentinel_blue.job_control import JobControl, SetupPaused
from sentinel_blue.setup import SetupRunner, compile_plan, plan_digest
from sentinel_blue.setup_transport import CommandResult
from sentinel_blue.state import read_private_json
from tests.test_desktop_workflow import window_without_display
from tests.test_setup import fixture, FixtureTransport, healthy_probe


class PauseTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.control = JobControl(self.root)
        self.control.initialize()
        self.permit = self.control.permit(self.control.admit())

    def test_pause_survives_reopen_and_resume_never_revives_old_permit(self):
        self.control.set_paused(True)
        reopened = JobControl(self.root)
        self.assertTrue(reopened.initialize()['paused'])
        with self.assertRaises(SetupPaused):
            reopened.admit()
        reopened.set_paused(False)
        with self.assertRaises(SetupPaused):
            self.permit.checkpoint()
        reopened.permit(reopened.admit()).checkpoint()

    def test_missing_or_corrupt_control_fails_closed(self):
        self.control.path.write_text('{}')
        with self.assertRaises(SetupPaused):
            self.permit.checkpoint()
        self.control.path.unlink()
        with self.assertRaisesRegex(ValueError, 'missing'):
            JobControl(self.root).initialize()

    def test_native_setup_state_and_output_reopen_under_same_private_policy(self):
        import sys
        from sentinel_blue.credential_vault import private_directory
        from sentinel_blue.setup import _locked_state
        from sentinel_blue.setup_transport import run_process
        parent = self.root/'private-desktop'
        guard = private_directory(parent)
        try:
            with _locked_state(parent/'state'):
                result = run_process([sys.executable, '-c', 'print("owned log fixture")'], '', 10,
                                     log_dir=parent/'state/private-command-output')
            self.assertEqual(result.returncode, 0)
            self.assertTrue((parent/'state/private-command-output'/result.output_log).is_file())
        finally:
            if guard is not None: guard.close()
        # Windows audits every descendant here, including the setup lock and
        # native command log. This catches mkdir(0700)'s extra current-user ACE.
        reopened = private_directory(parent)
        if reopened is not None: reopened.close()

    def test_queued_launch_cannot_cross_pause_then_resume(self):
        from sentinel_blue.desktop_jobs import launch_job
        epoch = self.control.admit()
        self.control.set_paused(True)
        self.control.set_paused(False)
        with patch('sentinel_blue.desktop_jobs.detach') as detached:
            with self.assertRaises(SetupPaused):
                launch_job({'control_epoch': epoch}, self.root/'job')
            detached.assert_not_called()
        self.assertFalse((self.root/'job/job.json').exists())

    def runner(self, transport, checkpoint=None):
        inventory, profile = fixture(self.root, hosts=2, services=True)
        inventory['setup']['max_parallel_hosts'] = 1
        plan = compile_plan(inventory, profile, self.root)
        return SetupRunner(plan, profile, transport=transport, probe=healthy_probe,
                           checkpoint=checkpoint or self.permit.checkpoint), plan

    def test_pause_during_initial_check_admits_no_mutation(self):
        transport = FixtureTransport()
        original = transport.execute
        def execute(host, script, seconds):
            if script.startswith('# check'):
                self.control.set_paused(True)
            return original(host, script, seconds)
        transport.execute = execute
        runner, plan = self.runner(transport)
        report = runner.execute(self.root/'state', plan_digest(plan))
        self.assertEqual(report['status'], 'paused')
        self.assertEqual(transport.applies, [])
        self.assertTrue(all(row['changed'] is False for row in report['tasks'].values()))

    def test_admitted_task_finishes_but_next_host_and_resume_are_held(self):
        transport = FixtureTransport()
        original = transport.execute
        def execute(host, script, seconds):
            if script.startswith('# apply'):
                self.control.set_paused(True)
            return original(host, script, seconds)
        transport.execute = execute
        runner, plan = self.runner(transport)
        report = runner.execute(self.root/'state', plan_digest(plan))
        self.assertEqual(report['status'], 'paused')
        self.assertEqual(transport.applies, ['host-0'])
        self.assertEqual(report['tasks']['host-0']['status'], 'ready')
        self.assertTrue(report['tasks']['host-0']['changed'])
        self.assertEqual(report['tasks']['host-1']['status'], 'paused')
        self.control.set_paused(False)
        with self.assertRaisesRegex(ValueError, 'new plan'):
            SetupRunner(plan, runner.profile, transport=transport).execute(
                self.root/'state', plan_digest(plan), resume=True)

    def test_pause_does_not_interrupt_rollback_of_admitted_failed_task(self):
        transport = FixtureTransport()
        runner, plan = self.runner(transport)
        plan['tasks'][0]['rollback'] = '# owned rollback'
        calls = []
        def execute(host, script, seconds):
            calls.append(script)
            if script.startswith('# apply'):
                self.control.set_paused(True)
                return CommandResult(20, 0)
            return CommandResult(10 if script.startswith('# check') else 0, 0)
        transport.execute = execute
        report = runner.execute(self.root/'state', plan_digest(plan))
        self.assertEqual(report['status'], 'paused')
        self.assertEqual(report['tasks']['host-0']['rollback']['returncode'], 0)
        self.assertEqual(calls.count('# owned rollback'), 1)
        self.assertFalse(report['tasks']['host-1']['changed'])

    def control_worker(self, window):
        thread = threading.Thread(target=window._control_worker)
        thread.start()
        def stop():
            window.worker_stop.set()
            thread.join(3)
            self.assertFalse(thread.is_alive())
        self.addCleanup(stop)

    def wait_control(self, window):
        deadline = time.monotonic()+3
        while window.control_pending and time.monotonic() < deadline:
            window._tick()
            time.sleep(.01)
        self.assertFalse(window.control_pending)

    def test_pause_bypasses_running_operation_and_full_queue(self):
        window = window_without_display(self.root)
        blocker, entered = threading.Event(), threading.Event()
        def blocked():
            entered.set()
            blocker.wait(4)
        window.submit(blocked, lambda _: None)
        worker = threading.Thread(target=window._worker)
        worker.start()
        self.addCleanup(lambda: worker.join(3))
        self.addCleanup(blocker.set)
        self.assertTrue(entered.wait(1))
        for _ in range(4):
            self.assertTrue(window.submit(lambda: None, lambda _: None))
        window.polling = True
        window.client = Mock()
        window.client.request.return_value = {'emergency_stopped': True}
        self.control_worker(window)
        started = time.monotonic()
        window._governance('emergency-stop')
        window._governance('emergency-stop')
        self.wait_control(window)
        self.assertLess(time.monotonic()-started, 1.5)
        self.assertEqual(window.jobs.qsize(), 4)
        self.assertTrue(self.control.read()['paused'])
        window.client.request.assert_called_once_with('/api/v1/governance/emergency-stop', {})
        self.assertIn('Controller pause confirmed', window.footer.get())

    def test_failed_controller_pause_preserves_local_pause_and_reports_unknown(self):
        window = window_without_display(self.root)
        window.polling = True
        window.client = Mock()
        window.client.request.side_effect = TimeoutError('fixture')
        self.control_worker(window)
        with patch('sentinel_blue.recording.emit') as record:
            window._governance('emergency-stop')
            self.wait_control(window)
        from sentinel_blue.recording import sanitize
        evidence = sanitize(next(call.args[1] for call in record.call_args_list if call.args[0] == 'desktop_control_result'))
        self.assertEqual(evidence['local']['status'], 'paused')
        self.assertEqual(evidence['controller'], {'status': 'unconfirmed', 'connected': True, 'error_type': 'TimeoutError'})
        self.assertTrue(self.control.read()['paused'])
        self.assertIn('Controller pause UNCONFIRMED', window.footer.get())
        window._governance('resume')
        self.wait_control(window)
        self.assertTrue(self.control.read()['paused'])

    def test_disconnected_pause_and_queued_close_still_control_detached_work(self):
        window = window_without_display(self.root)
        window._governance('emergency-stop')
        window.close()
        self.control_worker(window)
        deadline = time.monotonic()+2
        while not self.control.read()['paused'] and time.monotonic() < deadline:
            time.sleep(.01)
        self.assertTrue(self.control.read()['paused'])

    def test_false_controller_ack_is_not_reported_as_confirmed(self):
        window = window_without_display(self.root)
        window.polling = True
        window.client = Mock()
        window.client.request.return_value = {'emergency_stopped': False}
        self.control_worker(window)
        window._governance('emergency-stop')
        self.wait_control(window)
        self.assertIn('UNCONFIRMED', window.footer.get())

    def test_opening_pause_blocks_later_deployment_and_activation(self):
        from tests.test_competition_opening import OpeningDeadlineTests
        case = OpeningDeadlineTests()
        case.setUp()
        self.addCleanup(case.tearDown)
        runner = case.runner()
        runner.checkpoint = self.permit.checkpoint
        original = runner.transport.execute
        def execute(host, script, seconds):
            value = original(host, script, seconds)
            if script.startswith('# apply'):
                self.control.set_paused(True)
            return value
        runner.transport.execute = execute
        runner.deploy = Mock()
        with patch.object(type(case.profile), 'verify_release_file'):
            report = runner.execute(case.root/'paused-state', plan_digest(case.plan))
        self.assertEqual(report['status'], 'paused')
        runner.deploy.assert_not_called()
        self.assertNotIn('defense_activation', report['stages'])

    def test_password_transaction_finishes_verification_but_next_identity_is_held(self):
        from sentinel_blue.event_profile import EventProfile
        from sentinel_blue.security_workflow import SecurityCoordinator
        profile = EventProfile.testing()
        host = {'name': 'fixture', 'platform': 'linux'}
        accounts = [{'host': 'fixture', 'name': name, 'account_id': str(i)} for i, name in enumerate(('one', 'two'))]
        plan = {'profile_fingerprint': profile.fingerprint, 'hosts': {'fixture': host},
                'blue_accounts': accounts, 'removals': [], 'budget_seconds': 10}
        vault = SimpleNamespace(data={'entries': {}, 'audit': []}, save=lambda: None)
        calls = []
        def request(host, body, seconds):
            operation, name = body['operation'], body['name']
            calls.append((operation, name))
            if operation == 'account':
                return {'account_id': '0', 'name': name, 'enabled': True, 'dependencies': []}
            if operation == 'set_password':
                self.control.set_paused(True)
                return {'applied': True}
            return {'verified': True}
        coordinator = SecurityCoordinator(plan, profile, vault, SimpleNamespace(request=request),
                                          checkpoint=self.permit.checkpoint)
        report = coordinator.execute(approved_digest=coordinator.digest)
        self.assertEqual(report['status'], 'paused')
        self.assertEqual(calls, [('account','one'), ('set_password','one'), ('verify_password','one')])
        self.assertEqual([r['status'] for r in report['results']], ['verified', 'paused'])

    def test_deployment_admission_stops_before_next_host_transaction(self):
        from sentinel_blue.launcher import execute_plan
        steps = [SimpleNamespace(host=name, transport='local', address='127.0.0.1', options={})
                 for name in ('first', 'second')]
        calls = []
        def deploy(step, *_):
            calls.append(step.host)
            self.control.set_paused(True)
            return {'status': 'staged', 'host': step.host}
        with patch('sentinel_blue.launcher.validate_runtime_package', return_value={'sha256': 'a'*64}), \
                patch('sentinel_blue.launcher._deploy_local', side_effect=deploy):
            results = execute_plan(steps, {'authorized_networks': ['127.0.0.0/8']}, self.root/'unused.pyz',
                'a'*64, 'http://127.0.0.1:8765', 'a'*48, checkpoint=self.permit.checkpoint)
        self.assertEqual(calls, ['first'])
        self.assertEqual([row['status'] for row in results], ['staged', 'paused'])


class ControlNetworkTests(unittest.TestCase):
    def test_real_control_request_bypasses_two_busy_normal_network_slots(self):
        release = threading.Event()
        entered = [threading.Event(), threading.Event()]
        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                index = int(self.path[-1])
                entered[index].set()
                release.wait(4)
                self.reply({})
            def do_POST(self):
                self.rfile.read(int(self.headers.get('Content-Length', 0)))
                self.reply({'emergency_stopped': True})
            def reply(self, data):
                body = json.dumps(data).encode()
                self.send_response(200)
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            def log_message(self, *_): pass
        server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        client = DesktopClient(f'http://127.0.0.1:{server.server_port}', 'operator', 2, 'a'*48)
        workers = [threading.Thread(target=client.request, args=('/fixture/'+str(i),)) for i in range(2)]
        try:
            for worker in workers: worker.start()
            self.assertTrue(all(event.wait(2) for event in entered))
            started = time.monotonic()
            result = client.request('/api/v1/governance/emergency-stop', {})
            self.assertTrue(result['emergency_stopped'])
            self.assertLess(time.monotonic()-started, 1.5)
        finally:
            release.set()
            for worker in workers: worker.join(3)
