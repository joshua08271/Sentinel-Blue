"""2.0.4: faults found by running the guided local flow against a real systemd.

1. A second local session on the same VM could never act. The agent kept its
   controller-authority floor in the host-wide ledger keyed only by agent id,
   so the new session's controller was refused as "competing" forever: no
   restore points, so no baseline, so no restart or repair.
2. One ordinary firewall rule held all recovery. nftables prints a notice on
   stderr for every table iptables-nft owns (ufw, Docker, `iptables -A INPUT
   -m state ...`). The collector read it as a failed query, so telemetry always
   carried a collector error: the baseline could not be approved and every
   restart and repair was held as "incomplete collection".
3. A deleted unit file was planned for repair and then refused by the agent.
   systemd reports a unit with no file as not-found, which the agent read as
   "state changed after diagnosis". The repair that restores that very file is
   now allowed to find it missing, and its rollback removes it again.
4. That refusal reported rolled_back=False, which the setup redo read as a
   failed rollback and held. Only a started repair whose undo failed (now
   marked review_required, a field the result schema already has) holds it.
5. Setup of a service that dies right after starting ended "uncertain", not
   failed: systemd calls a simple unit active the instant it forks, the daemon
   exits, and the after-state setup recorded no longer held. The uncertain
   transaction then held every later setup and all recovery on the host, and
   the setup redo produced exactly that when the damage was beyond setup.
6. A service broken in the seconds after baseline approval was never "seen
   healthy" by the redo, which then waited forever; the approved baseline is
   that proof. The baseline also now waits for custom services to be healthy.
7. Controller recovery backups failed on every host an agent had run on. The
   withdrawal adapter created the ledger's file-restore directory with the
   process umask (0755), and recovery capsules refuse any directory others can
   read, so "Recovery backups are not being written" never cleared.
"""
import copy
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from sentinel_blue.controller import ControllerApp
from sentinel_blue.event_profile import EventProfile
from sentinel_blue.mutation_ledger import MutationLedger
from sentinel_blue.offline_continuity import AgentContinuity, ControllerContinuity
from sentinel_blue.state import ActionJournal
from sentinel_blue.store import Store
from test_autonomous_service_recovery import fixtures


class Deployment:
    """One reviewed deployment: its profile, its controller and its agent state."""

    def __init__(self, root, ledger, profile_id):
        root.mkdir(mode=0o700, parents=True, exist_ok=True)
        profile, _ = fixtures()
        raw = copy.deepcopy(profile.raw)
        raw["profile_id"] = profile_id
        raw["release"]["sha256"] = "a" * 64
        raw["scope"]["controller_ingress_hosts"] = ["127.0.0.1"]
        raw["scope"]["authorized_hosts"] = ["127.0.0.1", "192.0.2.10"]
        raw["scope"]["authorized_networks"] = [*raw["scope"]["authorized_networks"], "127.0.0.1/32"]
        self.profile = EventProfile.from_dict(raw)
        self.store = Store(root / "controller.db")
        self.app = ControllerApp(self.store, "t" * 32, operator_token="o" * 32, event_profile=self.profile)
        from sentinel_blue import __version__
        from sentinel_blue.auth import derive_enrollment_ticket
        self.app.enroll({"agent_id": "agent-one", "hostname": "host", "platform": "Linux",
                         "agent_version": __version__, "profile_id": self.profile.profile_id,
                         "profile_fingerprint": self.profile.fingerprint, "enrollment_nonce": "c" * 64},
                        authenticated_ticket=derive_enrollment_ticket("t" * 32, self.profile.fingerprint, "agent-one"))
        self.store.initialize_recovery_identity()
        self.token = self.store.ensure_agent_secret("agent-one")
        self.app.continuity = ControllerContinuity(self.app)
        self.root, self.ledger = root, ledger
        self.client = Mock()
        self.client._request.side_effect = lambda method, path, body: self.app.continuity.sync("agent-one", body)

    def agent(self, state=None):
        return AgentContinuity(state or self.root / "agent", self.profile, "agent-one", self.token, ledger=self.ledger)

    def close(self):
        self.store.close()


class ANewDeploymentIsNotAStaleController(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.root.chmod(0o700)
        self.ledger = MutationLedger(self.root / "host-ledger")

    def deployment(self, name):
        value = Deployment(self.root / name, self.ledger, name)
        self.addCleanup(value.close)
        return value

    def connect(self, deployment, agent):
        journal = ActionJournal(deployment.root / "journal", profile_fingerprint=deployment.profile.fingerprint)
        agent.sync(deployment.client, journal)
        return agent.sync(deployment.client, journal)

    def test_a_second_local_session_gets_authority(self):
        first = self.deployment("local-first")
        (first.root / "agent").mkdir()
        self.connect(first, first.agent())
        second = self.deployment("local-second")
        (second.root / "agent").mkdir()
        agent = second.agent()
        response = self.connect(second, agent)
        self.assertEqual(agent.state["authority"], second.app.continuity.authority)
        self.assertTrue(response["reconciled"])

    def test_the_same_deployment_is_still_fenced_after_its_agent_state_is_lost(self):
        first = self.deployment("local-first")
        (first.root / "agent").mkdir()
        self.connect(first, first.agent())
        # A second controller for the SAME approved profile, and an agent whose
        # state was wiped: the host ledger's floor still names the first one.
        rival = Deployment(self.root / "rival", self.ledger, "local-first")
        self.addCleanup(rival.close)
        rival.profile = first.profile
        (self.root / "wiped").mkdir(mode=0o700)
        agent = AgentContinuity(self.root / "wiped", first.profile, "agent-one", rival.token, ledger=self.ledger)
        self.assertEqual(agent.state["authority"], first.app.continuity.authority)
        with self.assertRaisesRegex(ValueError, "competing|Stale"):
            self.connect(rival, agent)

    def test_a_floor_recorded_before_this_release_does_not_block_a_new_session(self):
        old = self.deployment("old-release")
        self.ledger.append("continuity_authority", agent_id="agent-one", authority=old.app.continuity.authority)
        new = self.deployment("new-release")
        (new.root / "agent").mkdir()
        agent = new.agent()
        self.assertIsNone(agent.state["authority"])
        self.connect(new, agent)
        self.assertEqual(agent.state["authority"], new.app.continuity.authority)

    def test_floors_are_recorded_with_their_deployment(self):
        first = self.deployment("local-first")
        (first.root / "agent").mkdir()
        self.connect(first, first.agent())
        floors = [e for e in self.ledger.read() if e["kind"] == "continuity_authority"]
        self.assertEqual([e["profile_fingerprint"] for e in floors], [first.profile.fingerprint])



RULESET = """table ip filter {
\tchain INPUT {
\t\ttype filter hook input priority filter; policy accept;
\t\tct state related,established counter packets 0 bytes 0 accept
\t}
}
table ip6 filter {
\tchain INPUT {
\t\ttype filter hook input priority filter; policy accept;
\t}
}
"""
NOTICE = "# Warning: table {} is managed by iptables-nft, do not touch!\n"


def firewall(stdout, stderr, returncode=0):
    from sentinel_blue import collectors
    def run(command, timeout=8.0):
        if command[0] == "nft":
            return subprocess.CompletedProcess(command, returncode, stdout, stderr)
        raise FileNotFoundError(command[0])
    errors = []
    with patch.object(collectors, "_run", side_effect=run):
        state = collectors._linux_firewall(errors)
    return state, errors


class IptablesNftTablesAreNotAFailedQuery(unittest.TestCase):
    def test_the_ownership_notice_is_accepted_for_listed_tables(self):
        state, errors = firewall(RULESET, NOTICE.format("ip filter") + NOTICE.format("ip6 filter"))
        self.assertEqual(errors, [])
        self.assertEqual((state.enabled, state.provider), (True, "nftables"))

    def test_a_notice_for_a_table_that_is_not_listed_is_still_a_diagnostic(self):
        _, errors = firewall(RULESET, NOTICE.format("ip nat"))
        self.assertEqual(errors, ["nftables firewall query has diagnostics; coverage is incomplete",
                                  "Linux firewall inventory unavailable; state is unknown"])

    def test_any_other_stderr_is_still_a_diagnostic(self):
        for stderr in ("Error: Could not process rule: Operation not permitted\n",
                       NOTICE.format("ip filter") + "netlink: Error: cache initialization failed\n",
                       "# Warning: table ip filter is managed by iptables-legacy, do not touch!\n"):
            with self.subTest(stderr=stderr):
                _, errors = firewall(RULESET, stderr)
                self.assertIn("nftables firewall query has diagnostics; coverage is incomplete", errors)

    def test_recovery_is_no_longer_held_by_the_notice(self):
        from sentinel_blue.service_recovery import _fresh
        import time
        _, errors = firewall(RULESET, NOTICE.format("ip filter"))
        _fresh({"observed_at": time.time(), "boot_id": "b", "sequence": 3, "collector_errors": errors}, time.time())

    @unittest.skipUnless(sys.platform.startswith("linux") and hasattr(os, "geteuid") and os.geteuid() == 0
                         and all(shutil.which(tool) for tool in ("unshare", "nft", "iptables")),
                         "needs root, unshare, nft and iptables")
    def test_a_real_state_rule_in_a_private_network_namespace(self):
        """The rule every blue team writes first, in a throwaway namespace."""
        script = (
            "import subprocess, sys, json\n"
            "subprocess.run(['iptables', '-A', 'INPUT', '-m', 'state', '--state', 'ESTABLISHED,RELATED', '-j', 'ACCEPT'], check=True)\n"
            "raw = subprocess.run(['nft', 'list', 'ruleset'], capture_output=True, text=True)\n"
            "from sentinel_blue import collectors\n"
            "errors = []\n"
            "state = collectors._linux_firewall(errors)\n"
            "print(json.dumps({'stderr': raw.stderr, 'errors': errors, 'provider': state.provider, 'enabled': state.enabled}))\n")
        source = str(Path(__file__).resolve().parents[1] / "src")
        result = subprocess.run(["unshare", "-n", sys.executable, "-c", script], capture_output=True, text=True,
                                env={**os.environ, "PYTHONPATH": source}, timeout=60)
        if result.returncode != 0:
            self.skipTest("private network namespace unavailable: " + result.stderr[-200:])
        import json
        value = json.loads(result.stdout)
        self.assertEqual(value["errors"], [], value)
        self.assertEqual((value["provider"], value["enabled"]), ("nftables", True))



class ADeletedUnitFileIsRepaired(unittest.TestCase):
    """The real executor; only systemd is replaced, by a model of a unit with no file."""

    def setUp(self):
        from sentinel_blue.actions import ActionExecutor
        from sentinel_blue.service_repair import repair_parameters
        from test_service_repair import damage, repair_fixture
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name).resolve()
        self.unit = self.root / "web.service"
        self.unit.write_bytes(b"trusted")   # the fixture's baseline pins this content
        self.profile, baseline = repair_fixture(str(self.unit))
        self.executor = ActionExecutor(self.root / "state", allow_restoration=True, allow_service_recovery=True,
                                       authorized_networks=["127.0.0.0/8"])
        self.assertTrue(self.executor.restore_points.capture(baseline["integrity"])["success"])
        self.unit.unlink()
        self.current = damage(baseline)
        self.current["integrity"] = []
        self.current["services"][0].update(state="inactive", start_mode="unknown")
        self.parameters = repair_parameters(self.profile, "agent-one", "web.service", baseline, self.current)
        self.assertTrue(self.parameters["repair"]["restore_files"][0]["observed_missing"])
        self.state, self.events = "stopped", []
        repairs = self.executor.repairs
        for target, name, effect in (
                (self.executor, "_service_state", lambda _: self.state if self.unit.exists() else "unknown"),
                (self.executor, "_set_service_state", self.set_state),
                (repairs, "_unit_properties", lambda _: {} if self.unit.exists() else
                    {"LoadState": "not-found", "ActiveState": "inactive"}),
                (repairs, "_reload_units", lambda: self.events.append(("reload", self.unit.exists()))),
                (self.executor, "_wait_for_service_probes", self.probe)):
            item = patch.object(target, name, side_effect=effect)
            item.start()
            self.addCleanup(item.stop)
        units = patch("sentinel_blue.service_repair_executor.UNIT_DIRECTORIES", (str(self.root) + "/",))
        units.start()
        self.addCleanup(units.stop)
        self.healthy = True

    def set_state(self, _service, desired):
        if not self.unit.exists():
            raise RuntimeError("Unit web.service not found.")
        self.events.append(("state", desired))
        self.state = desired

    def probe(self, specs, **_):
        from sentinel_blue.protocol import ProbeResult
        return [ProbeResult(item["name"], item["target"], self.healthy) for item in specs], 3, self.healthy

    def test_the_unit_file_is_restored_reloaded_and_started(self):
        result = self.executor.execute("repair_service", self.parameters, self.current)
        self.assertTrue(result["success"], result)
        self.assertEqual(self.events, [("reload", True), ("state", "running")])
        self.assertTrue(self.unit.exists())

    def test_a_failed_start_removes_the_unit_file_again(self):
        self.healthy = False
        result = self.executor.execute("repair_service", self.parameters, self.current)
        self.assertFalse(result["success"])
        self.assertTrue(result["rolled_back"], result)
        self.assertNotIn("review_required", result)
        from sentinel_blue.validation import validate_action_result
        validate_action_result(dict(result, action_id="a" * 32))   # the controller must accept it
        self.assertFalse(self.unit.exists())
        self.assertEqual(self.events[-1], ("reload", False))

    def test_a_missing_unit_the_repair_does_not_restore_is_still_refused(self):
        parameters = copy.deepcopy(self.parameters)
        parameters["repair"]["restore_files"][0]["observed_missing"] = False
        with patch.object(self.executor.repairs, "_unit_file_missing", return_value=False):
            result = self.executor.execute("repair_service", self.parameters, self.current)
        self.assertFalse(result["success"])
        self.assertIn("state changed after repair diagnosis", result["message"])
        self.assertEqual((result["rolled_back"], result.get("review_required")), (False, None))
        from sentinel_blue.validation import validate_action_result
        validate_action_result(dict(result, action_id="a" * 32))
        self.assertFalse(self.unit.exists())



class SetupWatchesAStartedServiceStayUp(unittest.TestCase):
    def test_the_apply_waits_before_declaring_the_service_up(self):
        from sentinel_blue.setup_recipes import SETTLE_SECONDS, compile_recipe
        compiled = compile_recipe("linux-service", {"service": "web.service", "enable": True, "unmask": True},
                                  Path("."), "linux")
        apply = compiled[1]
        start = apply.index("systemctl start -- web.service")
        settle = apply.index("while [ \"$sb_settle\" -lt " + str(SETTLE_SECONDS) + " ]")
        self.assertLess(start, settle)
        self.assertLess(settle, apply.index("trap - EXIT"), "a death inside the window still triggers the restore trap")
        self.assertIn("  systemctl is-active --quiet -- web.service\n", apply[settle:])

    @unittest.skipUnless(shutil.which("sh") and shutil.which("sleep"), "needs a POSIX shell")
    def test_a_service_that_dies_after_starting_fails_the_step(self):
        """Run just the settle loop against a service manager that reports one active moment."""
        from sentinel_blue.setup_recipes import compile_recipe
        apply = compile_recipe("linux-service", {"service": "web.service", "enable": True}, Path("."), "linux")[1]
        loop = "sb_started=1\n" + apply[apply.index('if [ "$sb_started" = 1 ]'):apply.index("trap - EXIT")]
        with tempfile.TemporaryDirectory() as temp:
            count = Path(temp) / "calls"
            fake = Path(temp) / "systemctl"
            fake.write_text("#!/bin/sh\nn=$(cat " + str(count) + " 2>/dev/null || echo 0)\n"
                            "echo $((n + 1)) > " + str(count) + "\n[ \"$n\" -lt 1 ]\n")
            fake.chmod(0o755)
            result = subprocess.run(["sh", "-c", "set -eu\n" + loop + "echo settled\n"], capture_output=True, text=True,
                                    env={"PATH": temp + ":/usr/bin:/bin"}, timeout=30)
        self.assertNotEqual(result.returncode, 0)
        self.assertNotIn("settled", result.stdout)


class BaselineIsTheProofOfHealth(unittest.TestCase):
    def test_a_service_broken_right_after_approval_can_be_redone(self):
        from sentinel_blue import setup_redo
        snapshot = {"agents": [{"agent_id": "local-linux", "baseline_status": "approved"}],
                    "service_health": [{"agent_id": "local-linux", "service": "web.service", "health": "unhealthy",
                                        "native_state": "failed", "reason": ""}],
                    "actions": [{"agent_id": "local-linux", "action_type": "repair_service", "status": "failed",
                                 "parameters": {"service": "web.service"}, "created_at": 90, "completed_at": 95,
                                 "result": {"rolled_back": True, "message": "native service did not reach running"}}],
                    "controller": {"governance": {"emergency_stopped": False, "autonomy_mode": "guarded-autonomous"}}}
        state = {"history": [], "missing_since": {}, "unhealthy_since": {}, "seen_healthy": [], "running": None}
        verdict = setup_redo.assess(snapshot, None, state, 100)
        self.assertEqual(verdict["units"]["web.service"]["status"], "eligible")
        snapshot["agents"][0]["baseline_status"] = "pending"
        verdict = setup_redo.assess(snapshot, None, dict(state, seen_healthy=[]), 100)
        self.assertEqual(verdict["units"]["web.service"]["status"], "waiting")

    def test_the_baseline_waits_for_custom_services(self):
        from sentinel_blue.linux_workspace import local_baseline_blockers
        config = {"selection": [], "custom_services": [{"unit": "scoreboard.service"}]}
        snapshot = {"service_health": [{"agent_id": "local-linux", "service": "scoreboard.service",
                                        "native_state": "failed", "health": "unhealthy"}]}
        self.assertEqual(len(local_baseline_blockers(config, snapshot)), 1)
        snapshot["service_health"][0].update(native_state="running", health="healthy")
        self.assertEqual(local_baseline_blockers(config, snapshot), [])



@unittest.skipUnless(os.name == "posix", "POSIX modes")
class LedgerStateStaysPrivate(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.root.chmod(0o700)
        previous = os.umask(0o022)
        self.addCleanup(os.umask, previous)

    def capsule_inventory(self, ledger):
        from sentinel_blue.controller_restore import _tree
        return _tree(ledger.directory, skip_lock=True)

    def test_the_file_restore_state_is_created_private(self):
        from sentinel_blue.withdrawal_native import NativeObjects
        ledger = MutationLedger(self.root / "ledger")
        NativeObjects(ledger)
        self.assertEqual((ledger.directory / "file-restore").stat().st_mode & 0o777, 0o700)
        self.capsule_inventory(ledger)       # a controller backup can include it

    def test_one_left_readable_by_an_earlier_release_is_repaired(self):
        from sentinel_blue.withdrawal_native import NativeObjects
        from sentinel_blue.recovery import RecoveryPathError
        ledger = MutationLedger(self.root / "ledger")
        (ledger.directory / "file-restore").mkdir(mode=0o755)
        (ledger.directory / "file-restore").chmod(0o755)
        with self.assertRaises(RecoveryPathError):
            self.capsule_inventory(ledger)
        NativeObjects(ledger)
        self.capsule_inventory(ledger)


if __name__ == "__main__":
    unittest.main()
