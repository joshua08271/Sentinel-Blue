"""A packaged desktop job must survive its launcher and verify real local work."""
import copy
import hashlib
import http.server
import json
import os
import shlex
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path

from sentinel_blue.desktop_jobs import prepare
from sentinel_blue.event_profile import EventProfile
from sentinel_blue.setup import plan_digest
from sentinel_blue.state import write_private_json
from tools.build_defensive_release import build


DRIVER = '''
import json,os,sys
from pathlib import Path
runtime,job_path,directory=sys.argv[1:]
sys.path.insert(0,runtime)
from sentinel_blue.desktop_jobs import launch_job
job=json.loads(Path(job_path).read_text())
sys.argv[0]=runtime
process,path=launch_job(job,directory)
print(json.dumps({'pid':process.pid,'launcher_session':os.getsid(0),'worker_session':os.getsid(process.pid)}))
'''


@unittest.skipUnless(os.name == 'posix', 'POSIX detached process session')
class DesktopJobProcessTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='sentinel desktop process ')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.runtime = build(self.root/'release')
        self.marker = self.root/'completed'
        marker = self.marker
        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                body = b'healthy' if marker.is_file() else b'pending'
                self.send_response(200)
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            def log_message(self, *_):
                pass
        server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        raw = copy.deepcopy(EventProfile.testing().raw)
        raw['scope'].update(authorized_networks=['127.0.0.0/8'], authorized_hosts=['127.0.0.1'],
                            controller_ingress_hosts=['127.0.0.1'])
        raw['release'].update(sha256=hashlib.sha256(self.runtime.read_bytes()).hexdigest(),
            controller_ca_sha256=hashlib.sha256(b'unused-local-fixture-anchor').hexdigest(),
            cloud_processing=False, external_telemetry_export=False)
        raw['services_confirmed'] = True
        raw['services'] = [{'host': 'local-job', 'service_id': 'marker', 'protocol': 'http',
            'port': server.server_port, 'implementation': 'temporary local marker fixture',
            'dependencies': [], 'required_accounts': [], 'required_files': [], 'required_data': [],
            'credential_source': '', 'expected_transactions': [{'name': 'completion', 'kind': 'http',
                'target': f'http://127.0.0.1:{server.server_port}/', 'expected_body': 'healthy'}],
            'local_checks': [], 'allowed_automatic_actions': [], 'approval_actions': [],
            'backup_method': 'fixture', 'recovery_method': 'fixture', 'rollback_method': 'fixture'}]
        scripts = {
            'check': 'if test -f ' + shlex.quote(str(self.marker)) + '; then exit 0; else exit 10; fi\n',
            'apply': 'set -eu\nsleep 2\nprintf completed > ' + shlex.quote(str(self.marker)) + '\n',
            'rollback': 'set -eu\nif test -f ' + shlex.quote(str(self.marker)) + '; then test "$(cat ' + shlex.quote(str(self.marker)) + ')" = completed; rm -- ' + shlex.quote(str(self.marker)) + '; fi\n',
        }
        options = {}
        for name, script in scripts.items():
            path = self.root/(name+'.sh')
            path.write_bytes(script.encode())
            options[name] = {'path': path.name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
        self.inventory = {'authorized_networks': ['127.0.0.0/8'], 'hosts': [{'name': 'local-job',
            'agent_id': 'local-job', 'address': '127.0.0.1', 'platform': 'linux', 'transport': 'local'}],
            'setup': {'budget_seconds': 20, 'max_parallel_hosts': 1, 'tasks': [{'id': 'local-job',
                'host': 'local-job', 'service_id': 'marker', 'recipe': 'runbook', 'options': options,
                'timeout_seconds': 10, 'health_wait_seconds': 5, 'estimate_seconds': 3}]}}
        write_private_json(self.root/'inventory.json', self.inventory)
        write_private_json(self.root/'profile.json', raw)
        plan, _ = prepare(self.root/'inventory.json', self.root/'profile.json', self.runtime, 'setup', True)
        self.job = {'inventory': str(self.root/'inventory.json'), 'event_profile': str(self.root/'profile.json'),
            'runtime': str(self.runtime), 'kind': 'setup', 'range_deployment': True, 'approved_digest': plan_digest(plan)}
        write_private_json(self.root/'approved-job.json', self.job)

    def run_job(self):
        result = subprocess.run([sys.executable, '-c', DRIVER, str(self.runtime),
            str(self.root/'approved-job.json'), str(self.root/'job')], capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 0, result.stderr)
        launch = json.loads(result.stdout)
        self.assertNotEqual(launch['launcher_session'], launch['worker_session'])
        self.assertFalse(self.marker.exists(), 'Fixture completed before its launcher exited')
        path = self.root/'job'/'result.json'
        deadline = time.monotonic() + 25
        while not path.exists() and time.monotonic() < deadline:
            time.sleep(.05)
        self.assertTrue(path.exists(), 'Detached job did not produce its bounded completion report')
        return json.loads(path.read_text())

    def test_detached_job_survives_launcher_and_holds_untracked_mutation(self):
        report = self.run_job()
        self.assertEqual(report['status'], 'incomplete', report)
        self.assertEqual(report['tasks']['local-job']['status'], 'held')
        self.assertIn('exact durable mutation/rollback contract', report['tasks']['local-job']['reason'])
        self.assertFalse(self.marker.exists())

    def test_changed_reviewed_plan_is_rejected_before_local_work(self):
        self.inventory['setup']['budget_seconds'] = 19
        write_private_json(self.root/'inventory.json', self.inventory)
        report = self.run_job()
        self.assertEqual(report['status'], 'failed')
        self.assertIn('Configuration changed after review', report['reason'])
        self.assertFalse(self.marker.exists())


if __name__ == '__main__':
    unittest.main()
