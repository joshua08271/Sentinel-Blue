"""Actual single-cycle agent with modeled collection/self-health and no network."""
import sys,os,json,pathlib,tempfile,time,copy
from types import SimpleNamespace
from unittest.mock import MagicMock,patch
from contextlib import ExitStack
from sentinel_blue import agent,validation
from sentinel_blue.protocol import Telemetry,FirewallState
from sentinel_blue.state import TelemetrySpool

def replay(error_count=1):
 with tempfile.TemporaryDirectory(prefix='sb-agent-review-') as directory:
  args=SimpleNamespace(log_level='WARNING',agent_id='fixture-agent',event_profile='fixture.json',
   range_deployment=False,expected_package_sha256=None,authorized_network=[],allow_containment=False,
   allow_restoration=False,state_dir=directory,log_file=None,controller='https://127.0.0.1:8765',
   token=None,token_file=None,reenroll=False,ca_file=None,spool_limit=8,probe_config=None,
   quarantine_ttl=300,change_watch_interval=1,once=True,interval=5)
  profile=MagicMock();profile.raw={};profile.assert_inventory_networks=MagicMock();profile.release={'sha256':''};profile.profile_id='fixture';profile.fingerprint='b'*64
  profile.authorized_networks=profile.authorized_hosts=profile.excluded_hosts=()
  client=MagicMock();client.agent_token='a'*64;client.actions.return_value=[]
  lock=MagicMock();lock.acquire.return_value=lock;watcher=MagicMock()
  sample=Telemetry(agent_id=args.agent_id,hostname='fixture',platform='Linux',observed_at=time.time(),
    firewall=FirewallState(None),collector_errors=['fixture inventory incomplete']*error_count,
    collector_issue_sources=['unknown']*error_count,boot_id='fixture-boot')
  # Establish that the supplied collection is itself wire-valid before agent augmentation.
  valid_before=bool(validation.validate_telemetry(sample.as_dict()))
  attempted=[];failures=[]
  def upload(payload):
   attempted.append(copy.deepcopy(payload))
   try:validation.validate_telemetry(payload)
   except validation.ValidationError as exc:
    failures.append(str(exc));raise
  client.telemetry.side_effect=upload
  health={'healthy':False,'action_safe':False,'errors':['self-health: state volume has only 8388608 free bytes'],
          'critical_errors':['self-health: state volume has only 8388608 free bytes']}
  with ExitStack() as stack:
   values={'configure_agent_logging':None,'load_event_profile':profile,'AgentProcessLock':lock,
    'AgentClient':client,'load_agent_credentials':('', 'a'*64,None),'ActionExecutor':MagicMock(),
    'ChangeWatcher':watcher,'assess_agent_health':health,'refresh_windows_state_health':None,
    'refresh_recovery_health':None,'systemd_notify':None,'collect':sample}
   for name,value in values.items():stack.enter_context(patch.object(agent,name,return_value=value))
   stack.enter_context(patch.object(agent.atexit,'register'))
   logger=stack.enter_context(patch.object(agent,'LOG'))
   agent._run_with_windows_state_guard(args,None)
  pending=TelemetrySpool(directory).pending()
  return {'collection_valid_before_agent_merge':valid_before,'upload_attempts':len(attempted),
   'errors_after_merge':len(attempted[0]['collector_errors']) if attempted else None,
   'sources_after_merge':len(attempted[0]['collector_issue_sources']) if attempted else None,
   'controller_validator_failures':failures,'unacknowledged_spool_items':len(pending),
   'agent_cycle_error_logged':logger.error.called,
   'scope':'actual once-mode agent and real spool; modeled collection/self-health, upload uses real controller validator'}

def main(output):
 result={'origin':agent.__file__,'one_collector_error':replay(1),'diagnostic_limit':replay(256),'no_collector_errors_control':replay(0)}
 pathlib.Path(output).write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':main(sys.argv[1])
