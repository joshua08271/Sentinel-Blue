"""A native start must remain removable without adopting somebody else's edits."""
import copy
import os
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch

from sentinel_blue import controller_boot as boot
from sentinel_blue.mutation_ledger import MutationLedger, OwnershipConflict
from sentinel_blue.withdrawal_native import NativeObjects, object_target


UNIT = 'sentinel-blue-controller.service'
INVOCATION = 'a' * 32


class InvocationProofTests(unittest.TestCase):
    def proof(self, *, environment=INVOCATION, **changes):
        fields = {'MainPID': str(os.getpid()), 'InvocationID': INVOCATION,
                  'ActiveState': 'active', 'SubState': 'running', **changes}
        env = {} if environment is None else {'INVOCATION_ID': environment}
        with patch.dict(os.environ, env, clear=True), patch.object(boot.sys, 'platform', 'linux'), \
             patch.object(boot.subprocess, 'run', return_value=types.SimpleNamespace(
                 stdout='\n'.join(k+'='+v for k, v in fields.items()))) as command, \
             patch('sentinel_blue.process_identity.inspect_process_identity', return_value={'kernel': 'identity'}):
            result = boot._systemd_invocation()
            return result, command.call_count

    def test_native_pid_and_invocation_are_both_proven(self):
        proof, count = self.proof()
        self.assertEqual(proof, {'service': UNIT, 'invocation_id': INVOCATION,
                                 'process': {'kernel': 'identity'}})
        self.assertEqual(count, 1)

    def test_environment_cannot_impersonate_another_process(self):
        with self.assertRaises(OwnershipConflict):
            self.proof(MainPID=str(os.getpid()+1))

    def test_stale_invocation_and_transitioning_unit_are_refused(self):
        for change in ({'InvocationID': 'b'*32}, {'ActiveState': 'activating'}, {'SubState': 'dead'}):
            with self.subTest(change=change), self.assertRaises(OwnershipConflict):
                self.proof(**change)

    def test_invalid_invocation_is_refused(self):
        for value in ('', '0'*32, 'untrusted'):
            with self.subTest(value=value), self.assertRaises(OwnershipConflict):
                self.proof(environment=value)

    def test_direct_legacy_use_does_not_claim_a_service(self):
        self.assertEqual(self.proof(environment=None), (None, 0))


class NativeStartOwnershipTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.ledger = MutationLedger(self.root/'ledger')
        self.config = self.root/'controller-config.json'
        self.target = object_target(files=['/etc/systemd/system/'+UNIT,
            str(self.root/'controller-boot-binding.json')], services=[UNIT])
        self.before = {'files': {p: None for p in self.target['files']},
            'services': {UNIT: {'exists': False, 'active': False, 'enabled': '',
                'configuration': '', 'configuration_sha256': '', 'revision': '0'}},
            'tasks': {}, 'persistence': {}}
        self.installed = {'files': {p: {'bytes': 'exact', 'metadata': {'mode': 384},
            'revision': [1, index, 10, 10]} for index, p in enumerate(self.target['files'])},
            'services': {UNIT: {'exists': True, 'active': False, 'enabled': 'enabled',
                'configuration': 'exact unit', 'configuration_sha256': 'a'*64, 'revision': '0'}},
            'tasks': {}, 'persistence': {}}
        self.current = copy.deepcopy(self.installed)
        self.current['services'][UNIT].update(active=True, revision='100')
        self.proof = {'service': UNIT, 'invocation_id': INVOCATION, 'process': {'pid': 1234, 'start': '10'}}
        self.fake_native = types.SimpleNamespace(snapshot=lambda target: copy.deepcopy(self.current))
        native_type = patch('sentinel_blue.withdrawal_native.NativeObjects', return_value=self.fake_native)
        factory = native_type.start()
        factory.name = NativeObjects.name
        self.addCleanup(native_type.stop)
        invocation = patch.object(boot, '_systemd_invocation', return_value=self.proof)
        self.invocation = invocation.start()
        self.addCleanup(invocation.stop)

    def register(self, *, ownership='sentinel_artifact', context=None, target=None):
        action_id = self.ledger.prepare(NativeObjects.name, target or self.target, self.before,
            ownership=ownership, context={'controller_boot': True} if context is None else context)
        self.ledger.commit(action_id, self.installed, {'success': True})
        return action_id

    def refuse_unchanged_ledger(self, exception=OwnershipConflict):
        head = self.ledger.head()
        with self.assertRaises(exception):
            boot._record_native_start(self.ledger, self.config)
        self.assertEqual(self.ledger.head(), head)

    def test_started_registration_is_removable_and_original_inverse_is_preserved(self):
        action_id = self.register()
        boot._record_native_start(self.ledger, self.config)
        row = self.ledger.actions(include_states=True)[0]
        self.assertEqual(row['before'], self.before)
        self.assertEqual(row['after'], self.current)
        event = self.ledger.read()[-1]
        self.assertEqual((event['kind'], event['action_id']), ('rebased', action_id))
        self.assertEqual(event['invocation'], self.proof)
        self.assertEqual(self.ledger.state(event['prior_expected_after']), self.installed)
        self.assertTrue(boot.status(self.ledger)['registrations'][0]['removable'])
        # A repeated observation is not another mutation or a new rollback base.
        head = self.ledger.head()
        boot._record_native_start(self.ledger, self.config)
        self.assertEqual(self.ledger.head(), head)

    def test_new_native_invocation_updates_guard_after_restart(self):
        self.register()
        boot._record_native_start(self.ledger, self.config)
        self.current['services'][UNIT]['revision'] = '200'
        self.invocation.return_value = {**self.proof, 'invocation_id': 'b'*32}
        boot._record_native_start(self.ledger, self.config)
        row = self.ledger.actions(include_states=True)[0]
        self.assertEqual(row['after'], self.current)
        self.assertEqual(row['before'], self.before)
        self.assertEqual(len([e for e in self.ledger.read() if e['kind']=='rebased']), 2)

    def test_same_bytes_file_rewrite_is_not_adopted(self):
        self.register()
        self.current['files'][self.target['files'][0]]['revision'][2] += 1
        self.refuse_unchanged_ledger()

    def test_changed_binding_is_not_adopted(self):
        self.register()
        self.current['files'][str(self.root/'controller-boot-binding.json')]['bytes'] = 'teammate'
        self.refuse_unchanged_ledger()

    def test_service_configuration_and_startup_mode_changes_are_not_adopted(self):
        self.register()
        for field, value in (('enabled', 'disabled'), ('configuration', 'teammate'),
                             ('configuration_sha256', 'b'*64), ('active', False), ('exists', False)):
            with self.subTest(field=field):
                old = self.current['services'][UNIT][field]
                self.current['services'][UNIT][field] = value
                self.refuse_unchanged_ledger()
                self.current['services'][UNIT][field] = old

    def test_preexisting_service_is_never_claimed(self):
        self.before['services'][UNIT]['exists'] = True
        self.register()
        self.refuse_unchanged_ledger()

    def test_preexisting_file_is_never_claimed(self):
        self.before['files'][self.target['files'][0]] = {'bytes': 'teammate'}
        self.register()
        self.refuse_unchanged_ledger()

    def test_configuration_ownership_is_not_removable_artifact_ownership(self):
        self.register(ownership='configuration')
        self.refuse_unchanged_ledger()

    def test_unrelated_registration_context_is_not_claimed(self):
        self.register(context={'installation': True})
        self.refuse_unchanged_ledger()

    def test_missing_registration_is_not_created(self):
        self.refuse_unchanged_ledger()

    def test_other_service_target_is_not_claimed(self):
        self.register(target=object_target(files=self.target['files'], services=['other.service']))
        self.refuse_unchanged_ledger()

    def test_newer_overlapping_action_is_not_overwritten(self):
        self.register()
        other = self.ledger.prepare(NativeObjects.name, self.target, self.installed,
                                    ownership='configuration')
        self.ledger.commit(other, self.current, {'success': True})
        self.refuse_unchanged_ledger()

    def test_withdrawal_pause_prevents_append(self):
        self.register()
        self.ledger.pause('review')
        self.refuse_unchanged_ledger(ValueError)

    def test_pause_rechecked_before_durable_record(self):
        self.register()
        with patch.object(self.ledger, 'paused', side_effect=[False, True]):
            self.refuse_unchanged_ledger(ValueError)

    def test_process_or_object_change_during_proof_is_refused(self):
        self.register()
        self.invocation.side_effect = [self.proof, {**self.proof, 'process': {'pid': 1234, 'start': '11'}}]
        self.refuse_unchanged_ledger()
        self.invocation.side_effect = None
        original = copy.deepcopy(self.current)
        changed = copy.deepcopy(original)
        changed['services'][UNIT]['revision'] = '201'
        self.fake_native.snapshot = unittest.mock.Mock(side_effect=[original, changed])
        self.refuse_unchanged_ledger()

    def test_no_invocation_proof_leaves_original_guard_unchanged(self):
        self.register()
        self.invocation.return_value = None
        head = self.ledger.head()
        boot._record_native_start(self.ledger, self.config)
        self.assertEqual(self.ledger.head(), head)
        # 2.0.6 (found live): a registration whose unit only started or stopped
        # since it was recorded is still exactly what Sentinel installed, and
        # removing it (stop, disable, delete) stays possible. The unproven
        # start itself is still not recorded: the ledger head is unchanged.
        entry = boot.status(self.ledger)['registrations'][0]
        self.assertTrue(entry['matches_record'] and entry['removable'], entry)


if __name__ == '__main__':
    unittest.main()
