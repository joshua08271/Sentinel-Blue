"""Safety contracts plus real filesystem/process/crash checks for withdrawal."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from sentinel_blue.mutation_ledger import MutationLedger, LedgerError, OwnershipConflict, digest
from sentinel_blue.withdrawal import guest, inventory, WithdrawalCoordinator
from sentinel_blue.withdrawal_native import NativeObjects, object_target


class LedgerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.ledger = MutationLedger(self.root / 'ledger', host='alpha')
        self.native = NativeObjects(self.ledger)
        self.file = self.root / 'application.conf'

    def tearDown(self):
        self.tmp.cleanup()

    def change(self, contents, *, key='a', ownership='configuration', dependencies=()):
        target = object_target(files=[str(self.file)])
        self.ledger.mutate(self.native.name, target, lambda: self.file.write_text(contents),
                           snapshot=self.native.snapshot, action_id=key,
                           ownership=ownership, dependencies=dependencies)
        return target

    def test_exact_configuration_undo_keeps_unrelated_file(self):
        self.file.write_text('original')
        other = self.root / 'teammate.conf'
        other.write_text('teammate')
        self.change('sentinel')
        self.ledger.pause('emergency')
        receipt = guest({'operation': 'undo', 'action_id': 'a'}, self.ledger)
        self.assertEqual(receipt['status'], 'undone')
        self.assertEqual(self.file.read_text(), 'original')
        self.assertEqual(other.read_text(), 'teammate')

    def test_teammate_change_is_preserved_and_reported(self):
        self.file.write_text('original')
        self.change('sentinel')
        self.file.write_text('teammate')
        self.ledger.pause('emergency')
        report = inventory(self.ledger)
        self.assertTrue(report['actions'][0]['another_actor_modified'])
        with self.assertRaises(OwnershipConflict):
            guest({'operation': 'undo', 'action_id': 'a'}, self.ledger)
        self.assertEqual(self.file.read_text(), 'teammate')

    def test_same_bytes_after_third_party_edit_conflict(self):
        self.change('sentinel')
        self.file.write_text('teammate')
        self.file.write_text('sentinel')
        self.ledger.pause('emergency')
        self.assertIn('conflict', inventory(self.ledger)['actions'][0])

    def test_metadata_only_edit_conflicts(self):
        self.change('sentinel')
        self.file.chmod(0o400)
        self.ledger.pause('emergency')
        self.assertIn('conflict', inventory(self.ledger)['actions'][0])

    def test_prepare_is_durable_before_side_effect(self):
        target = object_target(files=[str(self.file)])
        def operation():
            check = MutationLedger(self.ledger.directory)
            self.assertEqual(check.actions()[0]['status'], 'prepared')
            self.assertEqual(check.state(check.actions()[0]['before_hash'])['files'][str(self.file)], None)
            return self.file.write_text('after')
        self.ledger.mutate(self.native.name, target, operation, snapshot=self.native.snapshot)

    def test_failed_prepare_never_mutates(self):
        target = object_target(files=[str(self.file)])
        with patch.object(self.ledger, 'append', side_effect=OSError('disk full')):
            with self.assertRaises(OSError):
                self.ledger.mutate(self.native.name, target, lambda: self.file.write_text('bad'), snapshot=self.native.snapshot)
        self.assertFalse(self.file.exists())

    def test_prepared_crash_is_not_replayed(self):
        directory = self.root / 'child-ledger'
        script = "from sentinel_blue.mutation_ledger import MutationLedger;import os; l=MutationLedger(os.environ['CASE_LEDGER']);l.prepare('native-objects-v1',{'objects':['file:x']},None,action_id='interrupted');os._exit(7)"
        env = dict(os.environ, CASE_LEDGER=str(directory))
        result = subprocess.run([sys.executable, '-c', script], env=env, capture_output=True)
        self.assertEqual(result.returncode, 7, result.stderr)
        recovered = MutationLedger(directory)
        self.assertFalse(recovered.pause('withdraw')['drained'])
        with self.assertRaises(OwnershipConflict):
            guest({'operation': 'undo', 'action_id': 'interrupted'}, recovered)

    def test_commit_survives_abrupt_process_exit(self):
        directory = self.root / 'child-ledger'
        script = "from sentinel_blue.mutation_ledger import MutationLedger;import os;l=MutationLedger(os.environ['CASE_LEDGER']);l.prepare('test',{},'before',action_id='a');l.commit('a','after',{'success':True});os._exit(0)"
        result = subprocess.run([sys.executable, '-c', script], env=dict(os.environ, CASE_LEDGER=str(directory)), capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(MutationLedger(directory).actions(include_states=True)[0]['after'], 'after')

    def test_pause_prevents_new_mutation(self):
        self.ledger.pause('withdraw')
        with self.assertRaises(LedgerError):
            self.change('bad')
        self.assertFalse(self.file.exists())

    def test_rewrite_event_fails_authentication(self):
        self.change('after')
        path = self.ledger.events_path
        data = path.read_bytes().replace(b'"sequence":1', b'"sequence":9')
        path.write_bytes(data)
        with self.assertRaises(LedgerError):
            MutationLedger(self.ledger.directory)

    def test_truncated_suffix_fails_local_anchor(self):
        self.change('after')
        lines = self.ledger.events_path.read_bytes().splitlines(keepends=True)
        self.ledger.events_path.write_bytes(lines[0])
        with self.assertRaises(LedgerError):
            MutationLedger(self.ledger.directory)

    def test_torn_append_fails_closed(self):
        self.change('after')
        with self.ledger.events_path.open('ab') as stream:
            stream.write(b'{"torn":')
        with self.assertRaises(LedgerError):
            MutationLedger(self.ledger.directory)

    def test_missing_head_fails_closed(self):
        self.change('after')
        self.ledger.head_path.unlink()
        with self.assertRaises(LedgerError):
            MutationLedger(self.ledger.directory)

    def test_forged_head_fails_authentication(self):
        self.change('after')
        self.ledger.head_path.write_text(json.dumps({'sequence': 0, 'hash': '0'*64, 'mac': '0'*64}))
        with self.assertRaises(LedgerError):
            MutationLedger(self.ledger.directory)

    def test_modified_exact_state_blob_prevents_undo(self):
        self.change('after')
        row = self.ledger.actions()[0]
        (self.ledger.blobs / row['before_hash']).write_text('{}')
        with self.assertRaises(LedgerError):
            self.ledger.actions(include_states=True)

    def test_committed_actions_cannot_be_replayed(self):
        self.change('after')
        with self.assertRaises(LedgerError):
            self.change('second')
        self.assertEqual(self.file.read_text(), 'after')

    def test_pinned_remote_head_detects_full_suffix_rollback(self):
        self.change('after')
        pinned = self.ledger.head()
        old = MutationLedger(self.root / 'different')
        with self.assertRaises(LedgerError):
            old.read(pinned)

    def test_multi_process_append_is_serialized(self):
        script = "from sentinel_blue.mutation_ledger import MutationLedger;import os;l=MutationLedger(os.environ['CASE_LEDGER']);[l.append('test',number=i) for i in range(10)]"
        children = [subprocess.Popen([sys.executable, '-c', script], env=dict(os.environ, CASE_LEDGER=str(self.ledger.directory)), stdout=subprocess.PIPE, stderr=subprocess.PIPE) for _ in range(4)]
        for child in children:
            _, errors = child.communicate(timeout=30)
            self.assertEqual(child.returncode, 0, errors)
        self.assertEqual(len(self.ledger.read()), 40)


class CoordinatorTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.hosts = {'alpha': {}, 'beta': {}}
        self.ledgers = {x: MutationLedger(self.root / x, host=x) for x in self.hosts}
        self.calls = []
        self.checks = [{'healthy': True, 'external': True}]
        self.coordinator = WithdrawalCoordinator(self.hosts, self.request, self.root / 'report', verify=lambda: self.checks)

    def tearDown(self):
        self.tmp.cleanup()

    def request(self, host, request):
        self.calls.append((host, request['operation'], request.get('action_id')))
        return guest(request, self.ledgers[host])

    def change(self, host, key, before='before', after='after', ownership='configuration', dependencies=()):
        file = self.root / (host + '-' + key)
        if before is not None:
            file.write_text(before)
        native = NativeObjects(self.ledgers[host])
        self.ledgers[host].mutate(native.name, object_target(files=[str(file)]), lambda: file.write_text(after),
                                  snapshot=native.snapshot, action_id=key, ownership=ownership, dependencies=dependencies)
        return file

    def test_network_dependency_order_and_external_gate(self):
        a = self.change('alpha', 'router')
        b = self.change('beta', 'application', dependencies=['alpha/router'])
        review = self.coordinator.review('restore-withdraw')
        self.assertEqual(review['order'], ['beta/application', 'alpha/router'])
        result = self.coordinator.execute(review, review['review_digest'])
        self.assertEqual(result['status'], 'complete')
        self.assertEqual(a.read_text(), 'before')
        self.assertEqual(b.read_text(), 'before')
        first_undo = next(i for i, x in enumerate(self.calls) if x[1] == 'undo')
        self.assertEqual({x[0] for x in self.calls[:first_undo] if x[1] == 'inventory'}, {'alpha', 'beta'})

    def test_remove_keeps_configuration_and_only_removes_owned_files(self):
        config = self.change('alpha', 'configuration')
        artifact = self.change('beta', 'sentinel.pyz', before=None, ownership='sentinel_artifact')
        review = self.coordinator.review('remove')
        result = self.coordinator.execute(review, review['review_digest'])
        self.assertEqual(result['status'], 'complete')
        self.assertEqual(config.read_text(), 'after')
        self.assertFalse(artifact.exists())

    def test_unreachable_host_blocks_network_undo(self):
        file = self.change('alpha', 'config')
        original = self.coordinator.request
        def request(name, value):
            if name == 'beta':
                raise OSError('unreachable')
            return original(name, value)
        self.coordinator.request = request
        review = self.coordinator.review('restore-withdraw')
        self.assertEqual(self.coordinator.execute(review, review['review_digest'])['status'], 'held')
        self.assertEqual(file.read_text(), 'after')

    def test_external_failure_retains_installation_and_evidence(self):
        file = self.change('alpha', 'sentinel.pyz', before=None, ownership='sentinel_artifact')
        self.change('beta', 'config')
        self.checks = [{'healthy': False, 'external': True}]
        review = self.coordinator.review('restore-withdraw')
        result = self.coordinator.execute(review, review['review_digest'])
        self.assertEqual(result['status'], 'held')
        self.assertTrue(file.exists())
        self.assertTrue((self.root / 'report' / 'result.json').exists())

    def test_local_validation_cannot_claim_external_success(self):
        file = self.change('alpha', 'sentinel.pyz', before=None, ownership='sentinel_artifact')
        self.checks = [{'healthy': True, 'external': False}]
        review = self.coordinator.review('restore-withdraw')
        self.assertEqual(self.coordinator.execute(review, review['review_digest'])['status'], 'held')
        self.assertTrue(file.exists())

    def test_changed_review_digest_rejected(self):
        self.change('alpha', 'config')
        review = self.coordinator.review('remove')
        review['mode'] = 'restore-withdraw'
        with self.assertRaises(LedgerError):
            self.coordinator.execute(review, review['review_digest'])

    def test_conflicted_child_blocks_dependency_undo(self):
        a = self.change('alpha', 'router')
        b = self.change('beta', 'app', dependencies=['alpha/router'])
        b.write_text('teammate')
        review = self.coordinator.review('restore-withdraw')
        result = self.coordinator.execute(review, review['review_digest'])
        self.assertEqual(result['status'], 'partial')
        self.assertEqual(a.read_text(), 'after')
        self.assertEqual(b.read_text(), 'teammate')

    def test_completed_withdrawal_receipt_is_idempotent(self):
        self.change('alpha', 'file', before=None, ownership='sentinel_artifact')
        review = self.coordinator.review('remove')
        result = self.coordinator.execute(review, review['review_digest'])
        calls = len(self.calls)
        self.assertEqual(self.coordinator.execute(review, review['review_digest']), result)
        self.assertEqual(calls, len(self.calls))




class OrderedHistoryTests(unittest.TestCase):
    setUp = LedgerTests.setUp
    tearDown = LedgerTests.tearDown
    change = LedgerTests.change

    def test_two_committed_file_edits_reverse_without_false_conflict(self):
        self.file.write_text('original')
        self.change('first', key='a')
        self.change('second', key='b')
        self.ledger.pause('withdraw')
        report = inventory(self.ledger)
        self.assertNotIn('conflict', report['actions'][0])
        with self.assertRaises(OwnershipConflict):
            guest({'operation': 'undo', 'action_id': 'a'}, self.ledger)
        guest({'operation': 'undo', 'action_id': 'b'}, self.ledger)
        guest({'operation': 'undo', 'action_id': 'a'}, self.ledger)
        self.assertEqual(self.file.read_text(), 'original')

    def test_teammate_version_between_two_sentinel_edits_survives(self):
        self.file.write_text('original')
        self.change('first', key='a')
        self.file.write_text('teammate')
        self.change('second', key='b')
        self.ledger.pause('withdraw')
        inventory(self.ledger)
        guest({'operation': 'undo', 'action_id': 'b'}, self.ledger)
        with self.assertRaises(OwnershipConflict):
            guest({'operation': 'undo', 'action_id': 'a'}, self.ledger)
        self.assertEqual(self.file.read_text(), 'teammate')

    def test_teammate_same_bytes_revision_before_later_edit_is_not_adopted(self):
        self.file.write_text('original')
        self.change('first', key='a')
        self.file.write_text('teammate')
        self.file.write_text('first')
        self.change('second', key='b')
        self.ledger.pause('withdraw')
        inventory(self.ledger)
        guest({'operation': 'undo', 'action_id': 'b'}, self.ledger)
        with self.assertRaises(OwnershipConflict):
            guest({'operation': 'undo', 'action_id': 'a'}, self.ledger)
        self.assertEqual(self.file.read_text(), 'first')

    def test_unexecuted_review_can_be_cancelled_without_resetting_history(self):
        self.change('after')
        head = self.ledger.head()
        self.ledger.pause('review')
        self.ledger.cancel_review('review')
        self.assertFalse(self.ledger.paused())
        self.ledger.read(head)
        self.assertEqual(self.file.read_text(), 'after')

    def test_review_cannot_resume_after_inverse_admission(self):
        self.change('after')
        self.ledger.pause('review')
        self.ledger.append('undo_prepared', action_id='a')
        with self.assertRaises(LedgerError):
            self.ledger.cancel_review('review')
        self.assertTrue(self.ledger.paused())

    def test_uncertain_undo_cannot_be_replayed(self):
        self.change('after')
        self.ledger.pause('withdraw')
        self.ledger.append('undo_prepared', action_id='a')
        with self.assertRaises(OwnershipConflict):
            guest({'operation': 'undo', 'action_id': 'a'}, self.ledger)
        self.assertEqual(self.file.read_text(), 'after')

    def test_symlink_substitution_never_deletes_teammate_target(self):
        self.change('after')
        teammate = self.root / 'teammate'
        teammate.write_text('safe')
        self.file.unlink()
        self.file.symlink_to(teammate)
        self.ledger.pause('withdraw')
        self.assertIn('conflict', inventory(self.ledger)['actions'][0])
        self.assertEqual(teammate.read_text(), 'safe')

    def test_live_owned_process_is_stopped_with_native_identity(self):
        from sentinel_blue.process_identity import inspect_process_identity
        child = subprocess.Popen([sys.executable, '-c', 'import time;time.sleep(45)'])
        try:
            identity = inspect_process_identity(child.pid)
            target = {'identity': identity, 'role': 'agent', 'objects': ['process:' + digest(identity)]}
            key = self.ledger.prepare('sentinel-process-v1', target, None, ownership='sentinel_process')
            self.ledger.commit(key, {'identity': identity}, {'success': True})
            self.ledger.pause('withdraw')
            result = guest({'operation': 'undo', 'action_id': key}, self.ledger)
            self.assertEqual(result['status'], 'undone')
            child.wait(timeout=3)
            self.assertIsNotNone(child.returncode)
        finally:
            if child.poll() is None:
                child.terminate()
                child.wait(timeout=5)

    def test_reused_pid_is_left_untouched(self):
        from sentinel_blue.withdrawal_native import OwnedProcess
        from sentinel_blue.process_identity import inspect_process_identity
        child = subprocess.Popen([sys.executable, '-c', 'import time;time.sleep(10)'])
        try:
            real = inspect_process_identity(child.pid)
            changed = dict(real, start_time=str(int(real['start_time']) + 1))
            with patch('sentinel_blue.process_identity.inspect_process_identity', return_value=changed), patch('sentinel_blue.process_identity.signal_verified_process') as signal:
                self.assertIsNone(OwnedProcess().restore({'identity': real}, None, {'identity': real}))
                signal.assert_not_called()
        finally:
            child.terminate()
            child.wait(timeout=5)

    def test_runtime_file_mutations_are_wired_to_ledger(self):
        from sentinel_blue import mutation_tracking
        from sentinel_blue.restoration import RestorePointStore
        with patch.dict(os.environ, {'SENTINEL_LEDGER_DIR': str(self.ledger.directory)}), patch.object(mutation_tracking, '_ENABLED', True):
            store = RestorePointStore(self.root / 'agent-state')
            store._atomic_write(self.file, b'owned', 0o600, expected_current=None)
            self.assertEqual(self.ledger.actions()[0]['adapter'], 'native-objects-v1')
            self.ledger.pause('withdraw')
            guest({'operation': 'undo', 'action_id': self.ledger.actions()[0]['action_id']}, self.ledger)
            self.assertFalse(self.file.exists())

    def test_interrupted_install_does_not_restore_over_later_actor(self):
        from sentinel_blue import mutation_tracking
        from sentinel_blue.launcher import _publish_local_transaction
        destination = self.root/'installation'
        destination.mkdir()
        target = destination/'sentinel-blue.pyz'
        target.write_text('prior installation')
        staged = self.root/'staged.pyz'
        staged.write_text('new installation')
        def interrupted(_path):
            target.write_text('teammate update after installation')
            raise OSError('simulated fsync failure after another actor wrote')
        with patch.dict(os.environ, {'SENTINEL_LEDGER_DIR': str(self.ledger.directory)}), patch.object(mutation_tracking, '_ENABLED', True), patch('sentinel_blue.launcher._fsync_directory', side_effect=interrupted):
            with self.assertRaisesRegex(RuntimeError, 'ownership review'):
                _publish_local_transaction(destination, {'sentinel-blue.pyz': (staged, 0o600)})
        self.assertEqual(target.read_text(), 'teammate update after installation')
        self.assertEqual(self.ledger.actions()[0]['status'], 'uncertain')
        self.assertTrue(list(destination.glob('.sentinel-rollback-*')))

    def test_native_suspend_resume_closes_temporary_control(self):
        from sentinel_blue import mutation_tracking
        from sentinel_blue.process_identity import inspect_process_identity, signal_verified_process
        child = subprocess.Popen([sys.executable, '-c', 'import time;time.sleep(45)'])
        try:
            identity = inspect_process_identity(child.pid)
            with patch.dict(os.environ, {'SENTINEL_LEDGER_DIR': str(self.ledger.directory)}), patch.object(mutation_tracking, '_ENABLED', True):
                signal_verified_process(child.pid, identity, 'suspend')
                signal_verified_process(child.pid, identity, 'resume')
            rows = self.ledger.actions()
            self.assertEqual([x['status'] for x in rows], ['undone', 'cancelled'])
        finally:
            child.terminate()
            child.wait(timeout=5)


class EvidenceGateTests(unittest.TestCase):
    setUp = CoordinatorTests.setUp
    tearDown = CoordinatorTests.tearDown
    request = CoordinatorTests.request
    change = CoordinatorTests.change

    def test_corrupt_recovery_transfer_blocks_all_undo(self):
        file = self.change('alpha', 'config')
        review = self.coordinator.review('restore-withdraw')
        original = self.coordinator.request
        def broken(name, request):
            result = original(name, request)
            if request['operation'] == 'evidence':
                result['sha256'] = '0'*64
            return result
        self.coordinator.request = broken
        with self.assertRaises(LedgerError):
            self.coordinator.execute(review, review['review_digest'])
        self.assertEqual(file.read_text(), 'after')

    def test_edit_after_review_is_preserved(self):
        file = self.change('alpha', 'config')
        review = self.coordinator.review('restore-withdraw')
        file.write_text('teammate after review')
        with self.assertRaises(OwnershipConflict):
            self.coordinator.execute(review, review['review_digest'])
        self.assertEqual(file.read_text(), 'teammate after review')

    def test_recovery_copy_contains_verified_exact_pre_state(self):
        self.change('alpha', 'config')
        review = self.coordinator.review('restore-withdraw')
        result = self.coordinator.execute(review, review['review_digest'])
        for entry in result['recovery_copies']:
            archived = MutationLedger(entry['directory'])
            archived.read(entry['head'])
            for action in archived.actions(include_states=True):
                self.assertIn('before', action)


if __name__ == "__main__":
    unittest.main()
