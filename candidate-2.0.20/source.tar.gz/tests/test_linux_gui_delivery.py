"""Regression checks for local GUI planning and non-JSON service forms."""
import copy
import hashlib
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch, Mock

from sentinel_blue.linux_service_forms import (SCHEMAS, parse_value, display_value,
    response_explanation, snapshot_file)
from sentinel_blue.linux_workspace import prepare_workspace, default_probe, session_arguments
from sentinel_blue.event_profile import load_event_profile
from sentinel_blue.desktop_jobs import prepare
from sentinel_blue.setup import plan_digest
from sentinel_blue.state import read_private_json
from sentinel_blue.linux_service_catalog import CATALOG, CONFIGURE


class FormTests(unittest.TestCase):
    def test_every_configurable_service_has_a_form(self):
        self.assertEqual(set(SCHEMAS), {key for key, row in CATALOG.items() if row['capability'] == CONFIGURE})

    def test_list_and_mapping_fields_round_trip(self):
        for kind, value in [('list', ['alice', 'bob']), ('mapping', {'host.test': '10.0.0.1'}),
                            ('backends', [{'address': '::1', 'port': 8080}]),
                            ('records', [{'name': '@', 'type': 'MX', 'value': 'mail.test', 'priority': 10}])]:
            self.assertEqual(parse_value(kind, display_value(kind, value)), value)

    def test_duplicate_map_keys_are_not_silently_overwritten(self):
        with self.assertRaises(ValueError): parse_value('mapping', 'a = one\na = two')

    def test_wrong_numeric_input_is_rejected(self):
        for value in ('3.5', '-1', '$(id)', ' ３ '):
            with self.subTest(value=value), self.assertRaises(ValueError): parse_value('int', value)

    def test_selected_source_is_copied_privately_and_pinned(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); source = root/'source.html'; source.write_text('hello')
            result = snapshot_file(source, root/'workspace')
            source.write_text('changed later')
            self.assertEqual(Path(result['path']).read_text(), 'hello')
            self.assertEqual(result['sha256'], hashlib.sha256(b'hello').hexdigest())
            self.assertEqual(Path(result['path']).stat().st_mode & 0o777, 0o600)

    def test_binary_or_oversized_source_refused(self):
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp)/'bad'; source.write_bytes(b'x\0x')
            with self.assertRaises(ValueError): snapshot_file(source, tmp)
            source.write_bytes(b'x'*(1024*1024+1))
            with self.assertRaises(ValueError): snapshot_file(source, tmp)

    def test_reasons_and_response_are_explicit(self):
        why, response = response_explanation({'kind':'alert','detail':{'reason':'Service stopped','recommended_action':'restart_service'}})
        self.assertEqual(why, 'Service stopped'); self.assertIn('restart service', response)
        for kind in ('baseline', 'outcome', 'external-check'):
            why, response = response_explanation({'kind': kind, 'detail': {}})
            self.assertTrue(why and response)

    def test_udp_services_are_not_given_fake_tcp_checks(self):
        for sid in ('chrony', 'isc-dhcp-server', 'rsyslog'):
            with self.subTest(service=sid), self.assertRaises(ValueError): default_probe(sid, {})

    def test_tls_site_needs_a_real_tls_check(self):
        with self.assertRaises(ValueError): default_probe('nginx', {'port':443, 'tls_certificate': {'path':'cert'}})


class WorkspaceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.runtime = self.root/'sentinel.pyz'; self.runtime.write_bytes(b'fixture runtime')

    def workspace(self, **kw):
        return prepare_workspace(self.root/'sessions', self.runtime, ['openssh-server'], {}, {}, **kw)

    def test_preparation_does_not_execute_host_commands(self):
        with patch('subprocess.Popen') as popen, patch('subprocess.run') as run:
            cfg, plan = self.workspace()
        popen.assert_not_called(); run.assert_not_called()
        self.assertEqual(len(plan['tasks']), 1)
        self.assertEqual(plan['tasks'][0]['recipe'], 'linux-service')
        profile = load_event_profile(cfg['event_profile'])
        self.assertEqual(profile.services[0]['service_id'], 'ssh.service')
        self.assertEqual(plan['tasks'][0]['service_key'], ['local-linux', 'ssh.service'])

    def test_generated_scope_is_exact_and_not_competition_authority(self):
        cfg, _ = self.workspace()
        profile = load_event_profile(cfg['event_profile'])
        self.assertEqual(profile.raw['scope']['authorized_networks'], ['127.0.0.1/32'])
        self.assertEqual(cfg['autonomy'], 'approval-based')
        self.assertEqual(profile.autonomy_mode, 'guarded-autonomous')
        self.assertEqual(profile.raw['allowed_automatic_actions'], ['capture_restore_point'])
        self.assertFalse(profile.action_allowed('restart_service', automated=True))
        self.assertNotIn('--auto-recover-services', session_arguments(cfg)[0])
        self.assertFalse(profile.allows('account_disabling'))
        with self.assertRaises(ValueError): profile.require_live_ready()
        profile.require_range_ready()

    def test_plan_is_rechecked_by_original_engine(self):
        cfg, plan = self.workspace()
        prepared, _ = prepare(cfg['inventory'], cfg['event_profile'], str(self.runtime), 'setup', True)
        self.assertEqual(plan_digest(plan), plan_digest(prepared))
        self.runtime.write_bytes(b'changed runtime')
        with self.assertRaises(ValueError): prepare(cfg['inventory'], cfg['event_profile'], str(self.runtime), 'setup', True)

    def test_remote_probe_cannot_escape_local_scope(self):
        for target in ('192.168.1.8', 'http://192.168.1.8/'):
            with self.subTest(target=target), self.assertRaises(ValueError):
                self.workspace(checks={'openssh-server': {'kind':'http' if target.startswith('http') else 'tcp','target':target,'port':22}})

    def test_enrollment_ticket_is_bound_to_exact_profile_and_agent(self):
        from sentinel_blue.auth import derive_enrollment_ticket
        cfg, _ = self.workspace(); d = Path(cfg['directory'])
        master = read_private_json(d/'master.json')['token']
        ticket = read_private_json(d/'enrollment.json')['token']
        profile = load_event_profile(cfg['event_profile'])
        self.assertEqual(ticket, derive_enrollment_ticket(master, profile.fingerprint, 'local-linux'))
        self.assertNotEqual(master, ticket)

    def test_secrets_never_appear_in_session_arguments_or_settings(self):
        cfg, _ = self.workspace(); d = Path(cfg['directory'])
        arguments = repr(session_arguments(cfg)); settings = repr(cfg)
        for secret in (read_private_json(d/'master.json')['token'], (d/'operator.txt').read_text()):
            self.assertNotIn(secret, arguments); self.assertNotIn(secret, settings)
        self.assertEqual((d/'operator.txt').stat().st_mode & 0o777, 0o600)

    def test_automatic_mode_is_narrow_and_explicit(self):
        cfg, _ = self.workspace(autonomy='guarded-autonomous')
        profile = load_event_profile(cfg['event_profile'])
        self.assertEqual(profile.autonomy_mode, 'guarded-autonomous')
        self.assertTrue(profile.allows('guarded_autonomy'))
        self.assertFalse(profile.allows('account_disabling'))
        self.assertIn('--auto-recover-services', session_arguments(cfg)[0])

    def test_missing_package_watch_hints_do_not_block_local_recovery(self):
        present = self.root/'installed.conf'; present.write_text('reviewed config')
        alias = self.root/'alias.conf'; alias.symlink_to(present)
        missing = self.root/'uninstalled-package.conf'
        with patch('sentinel_blue.collectors.integrity_watch_paths', return_value=[str(present), str(alias), str(missing)]):
            cfg, _ = self.workspace(autonomy='guarded-autonomous')
        files = load_event_profile(cfg['event_profile']).services[0]['required_files']
        self.assertEqual(files.count(str(present)), 1)
        self.assertNotIn(str(alias), files)
        self.assertNotIn(str(missing), files)

    def test_each_selected_service_has_its_own_configuration_guard(self):
        from sentinel_blue.linux_workspace import local_baseline_files
        ssh = self.root/'ssh.conf'; ssh.write_text('ssh')
        nginx = self.root/'nginx.conf'; nginx.write_text('nginx')
        rows = {sid: dict(CATALOG[sid], config_paths=[str(path)])
                for sid, path in [('openssh-server', ssh), ('nginx', nginx)]}
        fragment = {'tasks': [
            {'id':'sentinel-openssh-server','service_id':'ssh.service','recipe':'linux-service'},
            {'id':'sentinel-nginx','service_id':'nginx.service','recipe':'linux-service'}]}
        with patch.dict(CATALOG, rows), patch('sentinel_blue.collectors.integrity_watch_paths', return_value=[str(ssh), str(nginx)]):
            files = local_baseline_files(fragment, self.root)
        self.assertIn(str(ssh), files['ssh.service'])
        self.assertIn(str(nginx), files['nginx.service'])
        self.assertFalse(set(files['ssh.service']) & set(files['nginx.service']))

    def test_generated_service_files_are_collected_before_baseline_approval(self):
        source = self.root/'index.html'; source.write_text('local test')
        options = {'nginx': {'name':'scope-test','listen_address':'127.0.0.1','port':18081,
                   'content':{'path':str(source),'sha256':hashlib.sha256(source.read_bytes()).hexdigest()}}}
        cfg, _ = prepare_workspace(self.root/'sessions', self.runtime, ['nginx'], options, {})
        expected = {'/etc/nginx/conf.d/sentinel-scope-test.conf',
                    '/var/lib/sentinel-blue-apps/scope-test/www/index.html'}
        files = set(load_event_profile(cfg['event_profile']).services[0]['required_files'])
        self.assertTrue(expected <= files)
        self.assertEqual(set(read_private_json(Path(cfg['directory'])/'probes.json')['protected_paths']), files)
        self.assertEqual(set(cfg['baseline_capture_paths']), files)

    def test_wrong_autonomy_value_refused(self):
        with self.assertRaises(ValueError): self.workspace(autonomy='unrestricted')

    def test_new_listener_after_review_holds_setup_with_a_response(self):
        import time
        from sentinel_blue.linux_workspace import require_available_local_ports
        inventory = {'setup': {'tasks':[{'id':'sentinel-nginx','recipe':'linux-nginx'}]}}
        snapshot = {'observed_at':time.time(), 'complete':True, 'listeners':[]}
        config = {'inventory':'fixture', 'options':{'nginx':{'port':18081}}, 'reviewed_port_observation':snapshot}
        current = {'presence':{'nginx':'running'}, 'observation':dict(snapshot, listeners=[{'protocol':'tcp','port':18081}])}
        with patch('sentinel_blue.linux_workspace.read_private_json', return_value=inventory), patch('sentinel_blue.linux_workspace.local_observation', return_value=current):
            with self.assertRaisesRegex(ValueError, 'TCP 18081 is now occupied.*Choose another port'):
                require_available_local_ports(config)
            config['reviewed_port_observation'] = current['observation']
            require_available_local_ports(config)
            current['presence']['nginx'] = 'installed'
            with self.assertRaises(ValueError): require_available_local_ports(config)

    def test_incomplete_current_port_inventory_holds_setup(self):
        from sentinel_blue.linux_workspace import require_available_local_ports
        inventory = {'setup': {'tasks':[{'id':'sentinel-nginx','recipe':'linux-nginx'}]}}
        current = {'presence':{}, 'observation':{'complete':False,'listeners':[]}}
        with patch('sentinel_blue.linux_workspace.read_private_json', return_value=inventory), patch('sentinel_blue.linux_workspace.local_observation', return_value=current):
            with self.assertRaisesRegex(ValueError, 'inventory is incomplete.*Refresh'):
                require_available_local_ports({'inventory':'fixture'})

    def test_baseline_approval_can_capture_but_cannot_restore_host_files(self):
        from sentinel_blue.controller import ControllerApp
        from sentinel_blue.store import Store
        from tests.test_baseline_promotion import telemetry, capture_result
        cfg, _ = self.workspace()
        profile = load_event_profile(cfg['event_profile'])
        store = Store(':memory:')
        self.addCleanup(store.close)
        app = ControllerApp(store, 'e'*32, operator_token='o'*32, event_profile=profile)
        path = '/etc/hosts'
        sample = telemetry('local-linux', [{'path':path, 'sha256':'a'*64, 'size':11, 'modified_at':1}])
        sample.update(profile_id=profile.profile_id, profile_fingerprint=profile.fingerprint,
                      agent_version=profile.release['version'])
        app.ingest(sample)
        result = app.approve_baseline('local-linux')
        self.assertTrue(result['promotion_pending'])
        action = store.pending_actions('local-linux')[0]
        from dataclasses import asdict
        from sentinel_blue.validation import canonical_action_envelope_sha256
        receipt = capture_result(action)
        receipt['action_envelope_sha256'] = canonical_action_envelope_sha256(asdict(action))
        app.complete_action(receipt, 'local-linux')
        self.assertEqual(store.baseline_status('local-linux'), 'approved')
        self.assertFalse(profile.action_allowed('restart_service', automated=True))
        self.assertFalse(app._service_manifest_policy('local-linux', 'restore_integrity', {'path':path}, automated=False)[0])
        self.assertFalse(app._service_manifest_policy('local-linux', 'capture_restore_point', {'files':[{'path':'/unreviewed/file'}]}, automated=True)[0])

    def test_withdrawal_runs_the_selected_local_package(self):
        import zipfile
        from sentinel_blue.withdrawal import coordinator_from_files
        with zipfile.ZipFile(self.runtime, 'w') as archive:
            archive.writestr('__main__.py', 'import sys,json\nassert sys.argv[1:]==["withdraw-guest"]\nr=json.load(sys.stdin)\nprint("SENTINEL_WITHDRAW_RESULT="+json.dumps({"success":True,"result":{"operation":r["operation"],"bundled_runtime_used":True}}))\n')
        cfg, _ = self.workspace()
        coordinator = coordinator_from_files(cfg['inventory'], cfg['event_profile'], self.root/'withdrawal', range_deployment=True)
        result = coordinator.request('local-linux', {'operation':'inventory'})
        self.assertEqual(result, {'operation':'inventory', 'bundled_runtime_used':True})

    def test_first_start_uses_authenticated_mode_and_resume(self):
        from sentinel_blue.linux_workspace import activate_reviewed_session
        cfg, _ = self.workspace()
        profile = load_event_profile(cfg['event_profile'])
        client = Mock()
        client.dashboard.return_value = {'controller':{'governance':{'profile_fingerprint':profile.fingerprint}}}
        client.request.return_value = {'emergency_stopped':False}
        activate_reviewed_session(cfg, client, lambda: None)
        self.assertEqual([call.args for call in client.request.call_args_list], [
            ('/api/v1/governance/mode', {'mode':'guarded-autonomous'}),
            ('/api/v1/governance/resume', {})])

    def test_pause_during_startup_prevents_resume(self):
        from sentinel_blue.linux_workspace import activate_reviewed_session
        from sentinel_blue.job_control import JobControl, SetupPaused
        cfg, _ = self.workspace()
        profile = load_event_profile(cfg['event_profile'])
        control = JobControl(self.root/'controls'); control.initialize()
        permit = control.permit(control.admit())
        client = Mock()
        client.dashboard.return_value = {'controller':{'governance':{'profile_fingerprint':profile.fingerprint}}}
        def request(path, payload):
            if path.endswith('/mode'):
                control.set_paused(True)
            return {'emergency_stopped':True}
        client.request.side_effect = request
        with self.assertRaises(SetupPaused):
            activate_reviewed_session(cfg, client, permit.checkpoint)
        self.assertEqual([call.args[0] for call in client.request.call_args_list], [
            '/api/v1/governance/mode', '/api/v1/governance/emergency-stop'])

    def test_wrong_controller_profile_cannot_be_activated(self):
        from sentinel_blue.linux_workspace import activate_reviewed_session
        cfg, _ = self.workspace()
        client = Mock()
        client.dashboard.return_value = {'controller':{'governance':{'profile_fingerprint':'a'*64}}}
        with self.assertRaises(ValueError):
            activate_reviewed_session(cfg, client, lambda: None)
        client.request.assert_not_called()

    def test_prepared_workspace_does_not_overwrite_previous_workspace(self):
        a, _ = self.workspace(); b, _ = self.workspace()
        self.assertNotEqual(a['directory'], b['directory'])
        self.assertTrue(Path(a['event_profile']).is_file())

    def test_baseline_cannot_accept_probe_success_with_pre_setup_service_state(self):
        from sentinel_blue.linux_workspace import client_for
        cfg, _ = self.workspace()
        client = client_for(cfg)
        row = {'kind':'baseline', 'id':'local-linux', 'choices':['approve']}
        sample = {'agents':[{'agent_id':'local-linux', 'baseline_status':'pending',
                             'baseline_readiness':{'ready':True,'blockers':[]}}],
                  'service_health':[{'agent_id':'local-linux','service':'ssh.service',
                                     'native_state':'inactive','health':'unhealthy','passed_checks':1}]}
        with patch.object(client, 'request', return_value=sample) as request:
            with self.assertRaisesRegex(ValueError, 'Baseline approval is held'):
                client.decide(row, 'approve')
            self.assertEqual([c.args[0] for c in request.call_args_list], ['/api/v1/dashboard'])
            self.assertFalse(sample['agents'][0]['baseline_readiness']['ready'])
            reason, response = response_explanation({'kind':'baseline','detail':sample['agents'][0]})
            self.assertIn('waiting', reason)
            self.assertIn('fresh service checks', response)
        sample['service_health'][0].update(native_state='running', health='healthy')
        with patch.object(client, 'request', side_effect=[sample, {'promotion_pending':True}]) as request:
            self.assertTrue(client.decide(row, 'approve')['promotion_pending'])
            self.assertEqual(request.call_args.args, ('/api/v1/agents/local-linux/baseline/approve', {}))

    def test_baseline_requires_every_selected_service_to_be_fresh(self):
        from sentinel_blue.linux_workspace import local_baseline_blockers
        cfg = {'selection':['openssh-server','nginx']}
        healthy = {'agent_id':'local-linux','service':'ssh.service','native_state':'running','health':'healthy'}
        for rows in ([healthy], [healthy, dict(healthy,service='nginx.service',health='stale')],
                     [healthy, dict(healthy,service='nginx.service',native_state='unknown')]):
            with self.subTest(rows=rows):
                self.assertTrue(local_baseline_blockers(cfg, {'service_health':rows}))
        self.assertFalse(local_baseline_blockers(cfg, {'service_health':[healthy,dict(healthy,service='nginx.service')]}))


if __name__ == '__main__': unittest.main()
