import copy
import hashlib
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

from sentinel_blue.competition_catalog import bind_catalog
from sentinel_blue.launcher import _linux_unit
from sentinel_blue.opening import OpeningRunner
from sentinel_blue.setup import compile_plan
from sentinel_blue.setup_recipes import compile_recipe
from tests.test_setup import fixture


class ColdStartPrerequisites(unittest.TestCase):
    def test_every_declared_host_and_transaction_is_required(self):
        with tempfile.TemporaryDirectory() as folder:
            inventory, profile = fixture(Path(folder))
            plan = compile_plan(inventory, profile, Path(folder))
            rows = bind_catalog('declared-services', None, plan)
            self.assertEqual({row['host'] for row in rows}, {'host-0', 'host-1'})
            self.assertEqual(len(rows), 2)
            with self.assertRaisesRegex(ValueError, 'subsets'):
                bind_catalog('declared-services', {}, plan)
            plan['uncovered_services'] = [['host-1', 'database']]
            with self.assertRaisesRegex(ValueError, 'coverage'):
                bind_catalog('declared-services', None, plan)

    def test_empty_transactions_cannot_be_a_complete_cold_start(self):
        plan = {'tasks': [{'id': 'web', 'host': 'host-0',
                          'service_key': ['host-0', 'web'], 'probes': []}]}
        with self.assertRaisesRegex(ValueError, 'transactions'):
            bind_catalog('declared-services', None, plan)

    def test_new_linux_unit_is_loaded_before_enabling(self):
        with tempfile.TemporaryDirectory() as folder:
            source = Path(folder) / 'service'
            source.write_bytes(b'[Service]\nExecStart=/usr/bin/true\n')
            _, apply, _ = compile_recipe('linux-service', {
                'service': 'sentinel-cold-fixture.service', 'enable': True,
                'files': [{'path': '/etc/systemd/system/sentinel-cold-fixture.service',
                           'source': {'path': str(source), 'sha256': hashlib.sha256(source.read_bytes()).hexdigest()},
                           'previous_sha256': 'absent'}]}, Path(folder), 'linux')
            self.assertLess(apply.index('systemctl daemon-reload'), apply.index('systemctl enable --'))

    def test_selected_linux_interpreter_survives_service_restart(self):
        unit = _linux_unit('https://127.0.0.1:8765', '/opt/sentinel/sentinel.pyz',
            '/var/lib/sentinel', ['127.0.0.0/8'], False, False, 60,
            python_executable='python3.13')
        self.assertIn('ExecStart=python3.13 ', unit)
        self.assertNotIn('/usr/bin/python3 ', unit)

    def test_windows_runtime_requires_pinned_pre_staged_release(self):
        options = {'version': '3.13.15', 'sha256': 'a' * 64,
                   'install_directory': r'C:\ProgramData\SentinelPython'}
        check, apply, rollback = compile_recipe('windows-python', options, Path('.'), 'windows')
        self.assertNotIn('https://', apply)
        self.assertNotIn('Start-Process', apply)
        self.assertIn('Offline prerequisite missing', apply)
        self.assertIn('exit 25', apply)
        self.assertIn('platform.python_version()', check)
        self.assertIsNone(rollback)
        for field, value in [('version', '3.10.1'), ('sha256', ''),
                             ('install_directory', r'C:\Windows'),
                             ('install_directory', r'C:\ProgramData\..\Windows')]:
            with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                compile_recipe('windows-python', options | {field: value}, Path('.'), 'windows')
        with self.assertRaises(ValueError):
            compile_recipe('windows-python', options | {'url': 'https://example.test'}, Path('.'), 'windows')
        with self.assertRaises(ValueError):
            compile_recipe('windows-python', options, Path('.'), 'linux')

    def test_installed_runtime_is_not_service_readiness(self):
        with tempfile.TemporaryDirectory() as folder:
            inventory, profile = fixture(Path(folder), hosts=1)
            inventory['hosts'][0].update(platform='windows', transport='local')
            inventory['setup']['tasks'][0].update(recipe='windows-python', options={
                'version': '3.13.15', 'sha256': 'a' * 64,
                'install_directory': r'C:\ProgramData\SentinelPython'})
            with self.assertRaisesRegex(ValueError, 'cannot establish service readiness'):
                compile_plan(inventory, profile, Path(folder))

    def test_connection_gap_retries_reads_without_activation(self):
        plan = {'expected_agents': ['host-0']}
        replies = iter([ConnectionError('startup'), {'complete': True}])
        calls = []
        def dashboard(*args):
            calls.append(args)
            reply = next(replies)
            if isinstance(reply, Exception):
                raise reply
            return reply
        runner = OpeningRunner(plan, None, None, dashboard=dashboard)
        with patch('sentinel_blue.opening.assess_defender', return_value={'ready': True}):
            result = runner.wait_for_defender(time.monotonic() + 1, time.time())
        self.assertTrue(result['ready'])
        self.assertEqual(len(calls), 2)

    def test_connection_failure_expires_without_resetting_deadline(self):
        runner = OpeningRunner({'expected_agents': ['host-0']}, None, None,
                               dashboard=lambda *_: (_ for _ in ()).throw(ConnectionError()))
        result = runner.wait_for_defender(time.monotonic() + .3, time.time())
        self.assertFalse(result['ready'])
        self.assertEqual(result['readiness_checks'], 1)
