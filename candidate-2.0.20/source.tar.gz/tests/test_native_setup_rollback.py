"""A failed owned unit replacement must restore the running original service."""
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
import uuid

from sentinel_blue.setup_recipes import compile_recipe


@unittest.skipUnless(os.name == 'posix' and Path('/run/systemd/system').is_dir()
                     and os.geteuid() == 0, 'requires root on a native systemd host')
class NativeSetupRollback(unittest.TestCase):
    def test_approved_service_refreshes_replaced_executable_once(self):
        name = 'sentinel-runtime-refresh-' + uuid.uuid4().hex[:12] + '.service'
        target = Path('/etc/systemd/system') / name
        def systemctl(*arguments):
            return subprocess.run(['systemctl', *arguments], capture_output=True, text=True, timeout=25)
        with tempfile.TemporaryDirectory(prefix='sentinel-runtime-refresh-', dir='/var/lib') as folder:
            executable = Path(folder) / 'sleeper'
            shutil.copy2('/usr/bin/sleep', executable)
            owned = False
            try:
                with target.open('x') as stream:
                    owned = True
                    stream.write('[Service]\nType=exec\nExecStart=' + str(executable) + ' 3600\n')
                target.chmod(0o644)
                self.assertEqual(systemctl('daemon-reload').returncode, 0)
                self.assertEqual(systemctl('start', name).returncode, 0)
                original_pid = systemctl('show', '--property=MainPID', '--value', name).stdout.strip()
                replacement = Path(folder) / 'replacement'
                shutil.copy2('/usr/bin/sleep', replacement)
                os.replace(replacement, executable)
                self.assertEqual(os.stat('/proc/' + original_pid + '/exe').st_nlink, 0)
                check, apply, _ = compile_recipe('linux-service', {
                    'service': name, 'enable': False, 'refresh_replaced_executable': True
                }, Path(folder), 'linux')
                self.assertEqual(subprocess.run(['sh', '-c', check], capture_output=True).returncode, 10)
                repaired = subprocess.run(['sh', '-c', apply], capture_output=True, text=True, timeout=60)
                self.assertEqual(repaired.returncode, 0, repaired.stderr)
                new_pid = systemctl('show', '--property=MainPID', '--value', name).stdout.strip()
                self.assertNotEqual(new_pid, original_pid)
                self.assertGreater(os.stat('/proc/' + new_pid + '/exe').st_nlink, 0)
                self.assertEqual(subprocess.run(['sh', '-c', check], capture_output=True).returncode, 0)
                self.assertEqual(subprocess.run(['sh', '-c', apply], capture_output=True, timeout=60).returncode, 0)
                self.assertEqual(systemctl('show', '--property=MainPID', '--value', name).stdout.strip(), new_pid)
            finally:
                if owned:
                    systemctl('stop', name)
                    target.unlink(missing_ok=True)
                    systemctl('daemon-reload')
                    systemctl('reset-failed', name)

    def test_failed_replacement_restores_loaded_unit_and_running_service(self):
        name = 'sentinel-cold-rollback-' + uuid.uuid4().hex[:12] + '.service'
        target = Path('/etc/systemd/system') / name
        original = '[Unit]\nDescription=Temporary setup transaction test\n[Service]\nType=exec\nExecStart=/usr/bin/sleep 3600\n'
        broken = original.replace('/usr/bin/sleep 3600', '/sentinel-blue-test-command-does-not-exist')
        def systemctl(*arguments):
            return subprocess.run(['systemctl', *arguments], capture_output=True, text=True, timeout=25)
        with tempfile.TemporaryDirectory(prefix='sentinel-cold-rollback-', dir='/var/lib') as folder:
            owned = False
            try:
                with target.open('x') as stream:
                    owned = True
                    stream.write(original)
                target.chmod(0o644)
                self.assertEqual(systemctl('daemon-reload').returncode, 0)
                self.assertEqual(systemctl('start', name).returncode, 0)
                self.assertEqual(systemctl('is-active', '--quiet', name).returncode, 0)
                source = Path(folder) / 'replacement.service'
                source.write_text(broken)
                _, apply, _ = compile_recipe('linux-service', {
                    'service': name, 'enable': False,
                    'files': [{'path': str(target), 'previous_sha256': hashlib.sha256(original.encode()).hexdigest(),
                        'source': {'path': str(source), 'sha256': hashlib.sha256(source.read_bytes()).hexdigest()}}]
                }, Path(folder), 'linux')
                result = subprocess.run(['sh', '-c', apply], capture_output=True, text=True, timeout=60)
                self.assertNotEqual(result.returncode, 0, 'The invalid replacement must fail')
                self.assertEqual(target.read_text(), original, 'The original unit file must be restored')
                self.assertEqual(systemctl('is-active', '--quiet', name).returncode, 0,
                                 'Rollback must reload the restored unit and recover its running service')
            finally:
                if owned:
                    systemctl('stop', name)
                    target.unlink(missing_ok=True)
                    systemctl('daemon-reload')
                    systemctl('reset-failed', name)


if __name__ == '__main__':
    unittest.main()
