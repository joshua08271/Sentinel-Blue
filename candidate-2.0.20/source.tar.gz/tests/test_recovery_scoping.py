import copy
import time
import unittest
from dataclasses import asdict

from sentinel_blue.controller import ControllerApp
from sentinel_blue.event_profile import EventProfile
from sentinel_blue.service_recovery import _fresh
from sentinel_blue.service_repair import repair_parameters, validate_repair_contract
from sentinel_blue.store import Store
from sentinel_blue.validation import validate_telemetry, ValidationError
from test_service_repair import repair_fixture, damage
from test_store_controller import _promote_integrity_baseline


class RecoveryScopingTests(unittest.TestCase):
    def scoped(self):
        profile, baseline = repair_fixture()
        raw = copy.deepcopy(profile.raw)
        raw['services'][0]['repair_policy']['allow_unrelated_payload_errors'] = True
        return EventProfile.from_dict(raw), baseline

    def observation(self, baseline, sequence=2):
        value = damage(baseline, sequence)
        value.update(collector_errors=['unrelated installer fingerprint failed'],
                     collector_issue_sources=['payload_fingerprint'])
        return value

    def test_default_still_holds_incomplete_collection(self):
        profile, baseline = repair_fixture()
        with self.assertRaisesRegex(ValueError, 'incomplete'):
            repair_parameters(profile, 'agent-one', 'web.service', baseline, self.observation(baseline))

    def test_explicit_policy_queues_and_agent_revalidates_repair(self):
        profile, baseline = self.scoped()
        store = Store(':memory:')
        self.addCleanup(store.close)
        app = ControllerApp(store, 't'*32, operator_token='o'*32, event_profile=profile,
                            auto_recover_services=True, auto_restore=True,
                            restoration_probes=profile.services[0]['expected_transactions'])
        app.ingest(baseline)
        _promote_integrity_baseline(app, store, 'agent-one')
        app.ingest(self.observation(baseline, 2))
        self.assertFalse(any(x.action_type == 'repair_service' for x in store.pending_actions('agent-one')))
        current = self.observation(baseline, 3)
        app.ingest(current)
        actions = [asdict(x) for x in store.pending_actions('agent-one') if x.action_type == 'repair_service']
        self.assertEqual(len(actions), 1)
        validate_repair_contract(profile, 'agent-one', actions[0]['parameters'], current)
        self.assertEqual(store.latest_telemetry()[0]['collector_errors'], current['collector_errors'])

    def test_critical_unknown_or_unclassified_error_still_blocks(self):
        profile, baseline = self.scoped()
        for sources in ([], ['unknown'], ['payload_fingerprint', 'unknown']):
            current = self.observation(baseline)
            current['collector_issue_sources'] = sources
            if len(sources) == 2:
                current['collector_errors'].append('required-file read failed')
            with self.subTest(sources=sources), self.assertRaisesRegex(ValueError, 'incomplete'):
                repair_parameters(profile, 'agent-one', 'web.service', baseline, current)

    def test_expired_evidence_and_missing_required_account_still_block(self):
        profile, baseline = self.scoped()
        current = self.observation(baseline)
        current['observed_at'] = time.time() - 100
        with self.assertRaisesRegex(ValueError, 'fresh'):
            repair_parameters(profile, 'agent-one', 'web.service', baseline, current)
        current = self.observation(baseline)
        current['accounts'] = []
        with self.assertRaises(ValueError):
            repair_parameters(profile, 'agent-one', 'web.service', baseline, current)

    def test_envelope_cannot_grant_a_scope_absent_from_agent_profile(self):
        approved, baseline = self.scoped()
        default, _ = repair_fixture()
        current = self.observation(baseline)
        parameters = repair_parameters(approved, 'agent-one', 'web.service', baseline, current)
        with self.assertRaises(ValueError):
            validate_repair_contract(default, 'agent-one', parameters, current)

    def test_provenance_must_be_complete_and_well_formed(self):
        _, baseline = self.scoped()
        for sources in (['other'], [True], [{}], ['payload_fingerprint', 'unknown']):
            current = self.observation(baseline)
            current['collector_issue_sources'] = sources
            with self.subTest(sources=sources), self.assertRaises(ValidationError):
                validate_telemetry(current)


if __name__ == '__main__':
    unittest.main()
