import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

from sentinel_blue.launcher import _windows_python_process, _windows_task_action, _windows_enrollment_command


@unittest.skipUnless(os.name == 'nt' and shutil.which('powershell.exe'),
                     'requires native Windows PowerShell')
class WindowsNativeProcessTests(unittest.TestCase):
    def invoke_child(self, exit_code):
        with tempfile.TemporaryDirectory(prefix='sentinel native ') as directory:
            root = Path(directory)
            child = root / 'child with spaces.py'
            child.write_text('import json,sys\nprint(json.dumps(sys.argv[2:]))\n'
                             'print("ordinary diagnostic", file=sys.stderr)\n'
                             'sys.exit(int(sys.argv[1]))\n')
            values = ['', 'space value', "apostrophe's value", 'quote"value', 'tail\\']
            script = root / 'run.ps1'
            script.write_text("$ErrorActionPreference='Stop'\n$rollback='" +
                              str(root).replace("'", "''") + "'\n" +
                              _windows_python_process(sys.executable,
                                  [str(child), str(exit_code), *values]) + '\nexit 0\n',
                              encoding='utf-8-sig')
            result = subprocess.run(['powershell.exe', '-NoLogo', '-NoProfile',
                                     '-NonInteractive', '-File', str(script)],
                                    text=True, capture_output=True, timeout=30)
            self.assertEqual(json.loads((root / 'python.stdout').read_text()), values)
            self.assertEqual((root / 'python.stderr').read_text().strip(), 'ordinary diagnostic')
            return result

    def test_successful_stderr_and_quoted_arguments_do_not_fail(self):
        self.assertEqual(self.invoke_child(0).returncode, 0)

    def test_nonzero_native_exit_still_fails(self):
        result = self.invoke_child(7)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('exit code 7', result.stderr)

    def test_task_action_preserves_scope_identity_and_quoted_paths(self):
        with tempfile.TemporaryDirectory(prefix='sentinel task ') as directory:
            root = Path(directory)
            child = root / 'argument receiver.py'
            child.write_text('import json,sys\nprint(json.dumps(sys.argv[1:]))\n')
            values = ['--authorized-network', '10.78.0.0/16', '--agent-id', 'windows',
                      '--state-dir', str(root / 'state with spaces'), "apostrophe's value", 'quote"value']
            script = root / 'task.ps1'
            script.write_text("$ErrorActionPreference='Stop'\n$rollback='" +
                str(root).replace("'", "''") + "'\n" +
                _windows_task_action(sys.executable, [str(child), *values]) + "\n" +
                "$p=Start-Process -FilePath $action.Execute -ArgumentList $action.Arguments "
                "-Wait -PassThru -NoNewWindow -RedirectStandardOutput (Join-Path $rollback 'task.stdout') "
                "-RedirectStandardError (Join-Path $rollback 'task.stderr')\nexit $p.ExitCode\n",
                encoding='utf-8-sig')
            result = subprocess.run(['powershell.exe', '-NoLogo', '-NoProfile', '-NonInteractive',
                                     '-File', str(script)], text=True, capture_output=True, timeout=30)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads((root / 'task.stdout').read_text()), values)

    def assert_enrollment_arguments(self, existing):
        with tempfile.TemporaryDirectory(prefix='sentinel identity ') as directory:
            root = Path(directory)
            (root / 'state').mkdir()
            identity = root / 'state' / 'identity.json'
            if existing:
                identity.write_text('existing fixture identity')
            child = root / 'argument receiver.py'
            child.write_text('import json,sys\nprint(json.dumps(sys.argv[1:]))\n')
            ticket = str(root / 'staged ticket.json')
            script = root / 'enroll.ps1'
            script.write_text("$ErrorActionPreference='Stop'\n$root='" + str(root).replace("'", "''") +
                "'\n$rollback=$root\n" + _windows_enrollment_command(sys.executable,
                    [str(child), '--agent-id', 'windows'], ticket) + '\nexit 0\n', encoding='utf-8-sig')
            result = subprocess.run(['powershell.exe', '-NoLogo', '-NoProfile', '-NonInteractive',
                '-File', str(script)], text=True, capture_output=True, timeout=30)
            self.assertEqual(result.returncode, 0, result.stderr)
            expected = ['--agent-id', 'windows'] + ([] if existing else ['--token-file', ticket]) + ['--once']
            self.assertEqual(json.loads((root / 'python.stdout').read_text()), expected)
            if existing:
                self.assertEqual(identity.read_text(), 'existing fixture identity')

    def test_fresh_identity_uses_bootstrap_ticket(self):
        self.assert_enrollment_arguments(False)

    def test_existing_identity_does_not_request_reenrollment(self):
        self.assert_enrollment_arguments(True)
