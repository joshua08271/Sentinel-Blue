"""A missing scoring client is not a down service (Linux, competition scoring).

The scored transactions that decide a competition round — "SQL Access", "SMB
Login", "SSH Login", "Dynamic DNS" — run through native clients: `mysql`, `psql`,
`smbclient`, `paramiko`, `nsupdate`. If the client is not installed on the host
running the check, the check cannot be attempted.

It used to be reported as `healthy=False`, indistinguishable from the database
actually being down. Measured before the fix, on a host without the mysql client
and a service that was running perfectly:

    probe healthy        : False
    diagnosis            : local_application_unhealthy
    services table       : unhealthy
    automatic recovery   : restarts the healthy service

So a defect in the checker drove repeated restarts of a working service and
burned its recovery budget. `native_probes.dependency_readiness` already carried
the right principle in its docstring — "an absent client is not a down service" —
but only the observer preflight honoured it.

A check that was never attempted now reports `executed=False`, which reads as
missing evidence everywhere: unverified rather than unhealthy, held rather than
restarted, and named in `doctor` before the event starts.
"""

import shutil
import tempfile
import time
import unittest
from dataclasses import asdict
from unittest.mock import patch

from sentinel_blue import native_probes
from sentinel_blue.desktop_control import service_rows
from sentinel_blue.detection import detect
from sentinel_blue.diagnostics import doctor
from sentinel_blue.native_probes import (
    SCORING_BINARIES, SCORING_MODULES, ProbeUnavailable, dependency_readiness, missing_clients)
from sentinel_blue.probes import _execute_probe
from sentinel_blue.protocol import ProbeResult
from sentinel_blue.risk import KIND_FEATURES
from sentinel_blue.service_repair import (
    diagnose_service, probe_health, repair_parameters, unavailable_transactions)
from sentinel_blue.validation import validate_action_result, validate_telemetry

from test_autonomous_service_recovery import fixtures
from test_service_manifest_policy import profile_for

SQL = {"name": "sql-access", "kind": "mysql", "target": "127.0.0.1", "host": "127.0.0.1",
       "username": "scoring", "database": "scored", "password_file": "/nonexistent/pw"}


class _Budget:
    def remaining(self):
        return 5.0

    def attach(self, connection):
        pass


def probe_row(name="sql-access", target="127.0.0.1", *, healthy=False, executed=False,
              detail="scoring client is not installed: executable mysql"):
    return {"name": name, "target": target, "healthy": healthy, "latency_ms": 1.0,
            "detail": detail, "executed": executed}


class ClientInventoryTests(unittest.TestCase):
    """One definition of what each transaction needs, shared by every consumer."""

    def test_the_scored_kinds_each_name_their_client(self):
        self.assertEqual(SCORING_BINARIES["mysql"], "mysql")
        self.assertEqual(SCORING_BINARIES["postgres"], "psql")
        self.assertEqual(SCORING_BINARIES["dns-update"], "nsupdate")
        self.assertEqual(SCORING_MODULES["ssh-login"], "paramiko")
        self.assertEqual(SCORING_MODULES["smb"], "smbprotocol")

    def test_an_absent_binary_is_named(self):
        with patch.object(native_probes.shutil, "which", return_value=None):
            self.assertEqual(missing_clients("mysql"), ["executable mysql"])

    def test_a_present_binary_reports_nothing(self):
        with patch.object(native_probes.shutil, "which", return_value="/usr/bin/mysql"):
            self.assertEqual(missing_clients("mysql"), [])

    def test_a_kind_that_needs_no_client_reports_nothing(self):
        for kind in ("tcp", "http", "https", "dns", "smtp", "tls"):
            with self.subTest(kind=kind):
                self.assertEqual(missing_clients(kind), [])

    def test_the_observer_preflight_uses_the_same_definition(self):
        with patch.object(native_probes.shutil, "which", return_value=None):
            readiness = dependency_readiness([{"kind": "mysql"}])
        self.assertFalse(readiness["ready"])
        self.assertIn("executable mysql", readiness["missing"])


class UnattemptedProbeTests(unittest.TestCase):
    def test_a_missing_client_marks_the_check_unattempted(self):
        with patch.object(native_probes.shutil, "which", return_value=None):
            result = _execute_probe(SQL, ["127.0.0.0/8"], budget=_Budget())
        self.assertFalse(result.executed, "the check never contacted the service")
        self.assertFalse(result.healthy)
        self.assertIn("mysql", result.detail)

    def test_the_operator_is_told_which_client_is_missing(self):
        # The previous message was "scoring transaction failed (FileNotFoundError)",
        # which names nothing an operator can install.
        with patch.object(native_probes.shutil, "which", return_value=None):
            result = _execute_probe(SQL, ["127.0.0.0/8"], budget=_Budget())
        self.assertIn("not installed", result.detail)
        self.assertNotIn("FileNotFoundError", result.detail)

    def test_a_real_connection_failure_is_still_a_failure(self):
        # Nothing is listening on this port: that IS evidence about the service.
        spec = {"name": "tcp-check", "kind": "tcp", "target": "127.0.0.1", "port": 9}
        result = _execute_probe(spec, ["127.0.0.0/8"], budget=_Budget())
        self.assertTrue(result.executed, "a refused connection was still attempted")
        self.assertFalse(result.healthy)

    def test_a_probe_result_defaults_to_executed(self):
        self.assertTrue(ProbeResult(name="x", target="y", healthy=True).executed)

    def test_probe_unavailable_is_distinct_from_a_failed_transaction(self):
        self.assertTrue(issubclass(ProbeUnavailable, RuntimeError))


class TelemetryShapeTests(unittest.TestCase):
    def sample(self, probes):
        return {"agent_id": "agent-one", "hostname": "h", "platform": "Linux",
                "observed_at": time.time(), "boot_id": "b", "sequence": 1,
                "collector_errors": [], "probes": probes}

    def test_the_flag_round_trips(self):
        result = validate_telemetry(self.sample([probe_row()]))
        self.assertFalse(result["probes"][0]["executed"])

    def test_an_older_agent_is_treated_as_having_run_its_checks(self):
        row = probe_row()
        del row["executed"]
        self.assertTrue(validate_telemetry(self.sample([row]))["probes"][0]["executed"])

    def test_an_action_result_accepts_the_flag(self):
        result = validate_action_result({
            "action_id": "a" * 32, "action_type": "restart_service", "success": True,
            "started_at": time.time() - 1, "completed_at": time.time(), "message": "",
            "probes": [probe_row(executed=False)]})
        self.assertFalse(result["probes"][0]["executed"])


class EvidenceIsMissingNotNegativeTests(unittest.TestCase):
    """The behaviour that made this worth fixing."""

    def fixture(self, probes):
        profile, baseline = fixtures()
        manifest = dict(profile.services[0], expected_transactions=[SQL])
        # The fixture models an approved automatic repair and its required inverse.
        manifest["approval_actions"] = [*manifest["approval_actions"], "rollback_service_repair"]
        manifest["repair_policy"] = {"restore_files": ["/etc/web.conf"],
                                     "restart_unhealthy": True, "validation_timeout_seconds": 5}
        manifest["allowed_automatic_actions"] = [*manifest["allowed_automatic_actions"],
                                                 "repair_service"]
        profile = profile_for([manifest])
        baseline["probes"] = [probe_row(healthy=True, executed=True, detail="ok")]
        current = dict(baseline, sequence=2, observed_at=time.time() - 1, probes=probes)
        current["services"] = [dict(baseline["services"][0], state="running")]
        return profile, baseline, current

    def test_an_unattempted_check_is_unknown_not_false(self):
        _profile, _baseline, current = self.fixture([probe_row()])
        self.assertEqual(probe_health([SQL], current), [None])

    def test_an_attempted_failure_is_still_false(self):
        _profile, _baseline, current = self.fixture([probe_row(executed=True, detail="refused")])
        self.assertEqual(probe_health([SQL], current), [False])

    def test_diagnosis_reports_missing_evidence_not_an_unhealthy_application(self):
        profile, baseline, current = self.fixture([probe_row()])
        codes = [item["code"] for item in
                 diagnose_service(profile, "agent-one", "web.service", baseline, current)["findings"]]
        self.assertIn("transaction_evidence_missing", codes)
        self.assertNotIn("local_application_unhealthy", codes)

    def test_recovery_does_not_restart_a_healthy_service(self):
        # This is the regression that mattered: a defect in the checker used to
        # queue a restart of a service that was running correctly.
        profile, baseline, current = self.fixture([probe_row()])
        with self.assertRaises(ValueError):
            repair_parameters(profile, "agent-one", "web.service", baseline, current)

    def test_a_genuinely_failing_transaction_still_repairs(self):
        profile, baseline, current = self.fixture(
            [probe_row(executed=True, detail="connection refused")])
        parameters = repair_parameters(profile, "agent-one", "web.service", baseline, current)
        self.assertEqual(parameters["service"], "web.service")

    def test_the_service_reads_unverified_rather_than_unhealthy(self):
        profile, _baseline, current = self.fixture([probe_row()])
        row = service_rows(profile.services, {"agent-one": current},
                           [{"agent_id": "agent-one", "enabled": True}])[0]
        self.assertEqual(row["health"], "unverified")

    def test_the_table_names_the_missing_client_instead_of_misdirecting(self):
        # "check probe name and target" would send an operator nowhere useful.
        profile, _baseline, current = self.fixture([probe_row()])
        row = service_rows(profile.services, {"agent-one": current},
                           [{"agent_id": "agent-one", "enabled": True}])[0]
        self.assertIn("mysql", row["reason"])
        self.assertNotIn("check probe name and target", row["reason"])

    def test_a_genuinely_absent_probe_row_keeps_its_own_guidance(self):
        profile, _baseline, current = self.fixture([])
        row = service_rows(profile.services, {"agent-one": current},
                           [{"agent_id": "agent-one", "enabled": True}])[0]
        self.assertIn("check probe name and target", row["reason"])

    def test_unavailable_transactions_matches_only_declared_checks(self):
        _profile, _baseline, current = self.fixture([probe_row(name="something-else")])
        self.assertEqual(unavailable_transactions([SQL], current), [])
        self.assertEqual(len(unavailable_transactions([SQL], {"probes": [probe_row()]})), 1)


class UnavailableAlertTests(unittest.TestCase):
    def candidates(self, probes):
        telemetry = {"agent_id": "agent-one", "platform": "Linux", "observed_at": time.time(),
                     "accounts": [], "sessions": [], "services": [], "integrity": [],
                     "processes": [], "persistence": [], "listeners": [], "security_events": [],
                     "collector_errors": [], "probes": probes}
        return detect(telemetry, None, set())

    def test_an_unattempted_check_raises_its_own_alert(self):
        found = [c for c in self.candidates([probe_row()])
                 if c.kind == "scoring_check_unavailable"]
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0].severity, "high")
        self.assertIn("not known to be down", found[0].summary)
        self.assertIn("mysql", found[0].evidence["transactions"][0]["detail"])

    def test_an_attempted_failure_does_not_raise_it(self):
        self.assertNotIn("scoring_check_unavailable",
                         [c.kind for c in self.candidates([probe_row(executed=True)])])

    def test_older_telemetry_raises_nothing(self):
        row = probe_row()
        del row["executed"]
        self.assertNotIn("scoring_check_unavailable", [c.kind for c in self.candidates([row])])

    def test_malformed_probe_rows_never_raise_an_exception(self):
        for probes in ("unavailable", [None, 7], [{}]):
            with self.subTest(probes=probes):
                self.assertIsInstance(self.candidates(probes), list)

    def test_the_alert_kind_is_known_to_the_risk_model(self):
        self.assertIn("scoring_check_unavailable", KIND_FEATURES)


class DoctorPreflightTests(unittest.TestCase):
    """Catch this before the event, not at scoring time."""

    def names(self, report):
        return {check["name"]: check for check in report["checks"]}

    def test_every_scoring_client_is_reported(self):
        checks = self.names(doctor(tempfile.mkdtemp(prefix="sentinel-doctor-")))
        for kind in ("mysql", "postgres", "dns-update", "ssh-login", "smb"):
            with self.subTest(kind=kind):
                self.assertIn(f"scoring-client:{kind}", checks)

    def test_an_absent_client_is_a_warning_not_a_hard_failure(self):
        # Most hosts legitimately run none of these transactions.
        with patch.object(native_probes.shutil, "which", return_value=None):
            checks = self.names(doctor(tempfile.mkdtemp(prefix="sentinel-doctor-")))
        entry = checks["scoring-client:mysql"]
        self.assertFalse(entry["passed"])
        self.assertFalse(entry["required"])
        self.assertIn("not installed", entry["detail"])

    def test_a_present_client_passes(self):
        with patch.object(native_probes.shutil, "which", return_value="/usr/bin/mysql"), \
                patch.object(native_probes.importlib.util, "find_spec", return_value=object()):
            checks = self.names(doctor(tempfile.mkdtemp(prefix="sentinel-doctor-")))
        self.assertTrue(checks["scoring-client:mysql"]["passed"])


if __name__ == "__main__":
    unittest.main()
