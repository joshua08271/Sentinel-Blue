"""Owned rollback boundaries, conflict protection and actual bound HTTP probes."""
import copy
import hashlib
import http.server
import json
import os
from pathlib import Path
import shlex
import socket
import tempfile
import threading
import time
import unittest
import uuid
from unittest.mock import patch

from sentinel_blue.event_profile import EventProfile
from sentinel_blue.probes import run_probe
from sentinel_blue.protocol import ProbeResult
from sentinel_blue.recording import sanitize
from sentinel_blue.route_verification import compile_paths
from sentinel_blue.setup import SetupRunner, compile_plan, plan_digest
from sentinel_blue.setup_transport import CommandResult
from tests.test_setup import fixture, FixtureTransport


class RollbackSchedulerTests(unittest.TestCase):
    def run_case(self, *, failed_rollback=False, uncertain_apply=False, raising_probe=False, no_time=False):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            inventory, profile = fixture(root, hosts=1, budget=4)
            plan = compile_plan(inventory, profile, root)
            task = plan['tasks'][0]
            task.update(timeout_seconds=3, health_wait_seconds=.1)
            class Transport(FixtureTransport):
                def execute(self, host, script, seconds):
                    if script.startswith('# rollback'):
                        self.events.append((host['name'], 'rollback'))
                        self.rollback_allowance = seconds
                        return CommandResult(None if failed_rollback else 0, 0, failed_rollback)
                    if script.startswith('# apply') and uncertain_apply:
                        self.events.append((host['name'], 'apply'))
                        return CommandResult(None, 0, True)
                    if script.startswith('# apply') and no_time:
                        self.apply_allowance = seconds
                        time.sleep(seconds + .01)
                        self.ready.add(host['name'])
                        return CommandResult(0, seconds + .01)
                    return super().execute(host, script, seconds)
            transport = Transport()
            def probe(*args, **kwargs):
                if raising_probe:
                    raise OSError('owned read failed')
                return ProbeResult('external', 'fixture', False, 1)
            report = SetupRunner(plan, profile, transport=transport, probe=probe).execute(root/'state', plan_digest(plan))
            return report['tasks']['host-0'], transport

    def test_successful_apply_external_failure_invokes_reviewed_rollback(self):
        row, transport = self.run_case()
        self.assertEqual(row['status'], 'failed')
        self.assertEqual(row['rollback_status'], 'completed')
        self.assertEqual([kind for _, kind in transport.events].count('rollback'), 1)

    def test_failed_rollback_stays_uncertain(self):
        row, _ = self.run_case(failed_rollback=True)
        self.assertEqual(row['status'], 'uncertain')
        self.assertEqual(row['rollback_status'], 'unconfirmed')

    def test_unknown_apply_is_not_rolled_back_or_replayed(self):
        row, transport = self.run_case(uncertain_apply=True)
        self.assertEqual(row['status'], 'uncertain')
        self.assertNotIn('rollback', [kind for _, kind in transport.events])

    def test_probe_exception_still_uses_owned_rollback(self):
        row, _ = self.run_case(raising_probe=True)
        self.assertEqual(row['rollback_status'], 'completed')

    def test_apply_cannot_consume_the_entire_recovery_allowance(self):
        row, transport = self.run_case(no_time=True)
        self.assertEqual(row['rollback_status'], 'completed')
        self.assertGreater(transport.rollback_allowance, .25)
        self.assertLess(transport.apply_allowance, 3)

    def test_custom_scored_runbook_requires_an_explicit_rollback(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            inventory, profile = fixture(root, hosts=1)
            del inventory['setup']['tasks'][0]['options']['rollback']
            with self.assertRaisesRegex(ValueError, 'reviewed rollback'):
                compile_plan(inventory, profile, root)

    def test_builtin_service_commands_have_durable_bound_recovery(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            inventory, profile = fixture(root, hosts=1)
            raw = copy.deepcopy(profile.raw)
            raw['services'][0]['service_id'] = 'sample'
            inventory['setup']['tasks'][0].update(recipe='linux-service', service_id='sample', options={'service': 'sample', 'enable': True})
            task = compile_plan(inventory, EventProfile.from_dict(raw), root)['tasks'][0]
            self.assertTrue(task['owned_transaction'])
            self.assertTrue(all(task[key] for key in ('admit', 'apply', 'rollback', 'commit')))

    def test_unresolved_prior_transaction_blocks_even_already_healthy_task(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            inventory, profile = fixture(root, hosts=1)
            plan = compile_plan(inventory, profile, root)
            task = plan['tasks'][0]
            task['admit'] = '# admission\nexit 42'
            class Transport(FixtureTransport):
                def execute(self, host, script, seconds):
                    if script.startswith('# admission'):
                        return CommandResult(42, 0)
                    raise AssertionError('Readiness/mutation must remain held')
            row = SetupRunner(plan, profile, transport=Transport()).execute(root/'state', plan_digest(plan))['tasks']['host-0']
            self.assertEqual(row['status'], 'uncertain')
            self.assertFalse(row['changed'])


class RoutedProbeTests(unittest.TestCase):
    @unittest.skipUnless(os.name == 'posix' and os.geteuid() == 0, 'requires a root-owned witness fixture')
    def test_empty_native_witness_is_not_reported_as_armed(self):
        from sentinel_blue import route_check_native as native
        # Native nft 1.0.9 diagnostic: the old nested create command returned
        # success but installed this table without any chain or counter rules.
        empty = {'nftables': [{'table': {'family': 'inet', 'name': 'owned-test', 'handle': 190}}]}
        flow = {'router_name': 'owned', 'source': '10.201.1.1', 'destination': '10.201.2.1',
                'source_port': 41419, 'destination_port': 48272, 'in_interface': 'owned0', 'out_interface': 'owned1'}
        with tempfile.TemporaryDirectory(prefix='sentinel-route-unit-', dir='/var/lib') as directory:
            root = Path(directory)
            with patch.object(native, 'ROOT', root), patch.object(native, 'command'), \
                    patch.object(native, 'inspect_table', side_effect=[None, empty]):
                with self.assertRaisesRegex(ValueError, 'witness is incomplete'):
                    native.run('arm', flow, uuid.uuid4().hex, 'owned helper source')

    def settings(self):
        options = {'name': 'fixture', 'forward': [{'source': '10.79.1.0/24', 'destination': '10.79.2.0/24',
                   'protocol': 'tcp', 'port': 8080, 'in_interface': 'eth0', 'out_interface': 'eth1'}],
                   'path_checks': [{'probe_index': 0, 'source_address': '10.79.1.4', 'in_interface': 'eth0', 'out_interface': 'eth1'}]}
        probe = [{'kind': 'http', 'target': 'http://10.79.2.5:8080/', 'expected_body': 'ready'}]
        raw = copy.deepcopy(EventProfile.testing().raw)
        raw['scope']['authorized_networks'] = ['10.79.0.0/16']
        raw['scope']['authorized_hosts'] = ['10.79.1.4', '10.79.2.4', '10.79.2.5']
        return options, probe, EventProfile.from_dict(raw)

    def test_reachability_without_declared_router_path_is_rejected(self):
        options, probes, profile = self.settings()
        options.pop('path_checks')
        with self.assertRaisesRegex(ValueError, 'path_checks'):
            compile_paths(options, probes, '10.79.2.4', profile)

    def test_route_witness_cannot_use_local_router_or_unapproved_endpoint(self):
        for source in ['127.0.0.1', '10.79.2.4', '10.79.1.8']:
            with self.subTest(source=source):
                options, probes, profile = self.settings()
                options['path_checks'][0]['source_address'] = source
                with self.assertRaises(ValueError):
                    compile_paths(options, probes, '10.79.2.4', profile)

    def test_route_witness_must_match_forwarding_interfaces_and_port(self):
        options, probes, profile = self.settings()
        self.assertEqual(compile_paths(options, probes, '10.79.2.4', profile)['0']['destination_port'], 8080)
        options['path_checks'][0]['out_interface'] = 'eth2'
        with self.assertRaisesRegex(ValueError, 'forwarding rule'):
            compile_paths(options, probes, '10.79.2.4', profile)

    def test_real_http_probe_uses_the_reserved_source_port(self):
        peers = []
        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                peers.append(self.client_address)
                self.send_response(200); self.end_headers(); self.wfile.write(b'owned-ready')
            def log_message(self, *_): pass
        server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        worker = threading.Thread(target=server.serve_forever, daemon=True); worker.start()
        try:
            with socket.socket() as reservation:
                reservation.bind(('127.0.0.1', 0)); source = reservation.getsockname()
            result = run_probe({'kind': 'http', 'target': f'http://127.0.0.1:{server.server_port}/', 'expected_body': 'owned-ready'},
                               ['127.0.0.0/8'], source_address=source)
            self.assertTrue(result.healthy, result.detail)
            self.assertEqual(peers, [source])
        finally:
            server.shutdown(); server.server_close(); worker.join(timeout=3)


@unittest.skipUnless(os.name == 'posix' and os.geteuid() == 0, 'requires root-owned filesystem fixtures')
class DurableLinuxFilesystemTests(unittest.TestCase):
    def setUp(self):
        from sentinel_blue import setup_linux_transaction as native
        self.native = native
        self.temp = tempfile.TemporaryDirectory(prefix='sentinel-tx-unit-', dir='/var/lib')
        self.root = Path(self.temp.name)
        self.target = self.root/'owned.conf'; self.target.write_text('before'); self.target.chmod(0o640)
        self.initial = native.fingerprint(self.target)
        self.apply = 'set -eu\nprintf after > ' + shlex.quote(str(self.target)) + '\nchmod 0644 ' + shlex.quote(str(self.target)) + '\n'
        self.spec = {'version': 1, 'recipe': 'linux-service', 'service': 'owned-test.service',
                     'apply_sha256': hashlib.sha256(self.apply.encode()).hexdigest(),
                     'files': [{'path': str(self.target), 'sha256': hashlib.sha256(b'after').hexdigest(),
                                'previous_sha256': hashlib.sha256(b'before').hexdigest(), 'mode': '0644'}]}
        self.token = uuid.uuid4().hex
        self.directory_patch = patch.object(native, 'ROOT', self.root/'transactions'); self.directory_patch.start()
        self.service_patch = patch.object(native, 'service_state', return_value={'exists': True, 'active': True, 'enabled': 'disabled', 'configuration_sha256': 'a'*64}); self.service_patch.start()
        self.command_patch = patch.object(native, 'command'); self.command_patch.start()

    def tearDown(self):
        self.command_patch.stop(); self.service_patch.stop(); self.directory_patch.stop(); self.temp.cleanup()

    def run_phase(self, phase, token=None):
        self.native.run(phase, self.spec, token or self.token, self.apply, ledger_directory=self.root/'ledger')

    def test_backup_survives_apply_and_restores_bytes_and_metadata(self):
        self.run_phase('apply')
        self.assertEqual(self.target.read_text(), 'after')
        self.run_phase('rollback')
        self.assertEqual(self.native.fingerprint(self.target), self.initial)
        self.run_phase('rollback')
        self.run_phase('admit', uuid.uuid4().hex)

    def test_intervening_edit_is_preserved_and_blocks_new_admission(self):
        self.run_phase('apply'); self.target.write_text('operator edit')
        with self.assertRaisesRegex(ValueError, 'changed after apply'):
            self.run_phase('rollback')
        self.assertEqual(self.target.read_text(), 'operator edit')
        with self.assertRaisesRegex(ValueError, 'earlier transaction'):
            self.run_phase('admit', uuid.uuid4().hex)

    def test_committed_transaction_cannot_be_rolled_back_or_replayed(self):
        self.run_phase('apply'); self.run_phase('commit')
        self.run_phase('admit', uuid.uuid4().hex)
        with self.assertRaisesRegex(ValueError, 'committed'):
            self.run_phase('rollback')
        with self.assertRaisesRegex(ValueError, 'replayed'):
            self.run_phase('apply')

    def test_corrupt_backup_is_rejected_before_any_restoration(self):
        self.run_phase('apply')
        backup = self.native.ROOT/self.token/'file-0'; backup.write_text('damaged')
        with self.assertRaisesRegex(ValueError, 'backup integrity'):
            self.run_phase('rollback')
        self.assertEqual(self.target.read_text(), 'after')


if __name__ == '__main__':
    unittest.main()
