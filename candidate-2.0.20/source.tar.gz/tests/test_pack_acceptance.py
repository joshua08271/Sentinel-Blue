"""Acceptance receipts: what a host may claim about a service pack, and when.

The reason this exists is that `native_tested: False` was the only thing the
catalog could ever say. Proving a pack on a lab host left no trace, so the next
person had to take it on trust — and trust is exactly what a competition tool
should not be asking for.

A receipt is therefore evidence and not permission, and these tests hold it to
that. It grants nothing. It describes one pack built from one set of options
against one product version on one host with one runtime, and the moment any of
those stops matching it must stop counting. Every uncertainty — an unreadable
file, a missing step, a clock that disagrees — has to resolve to "untested",
because the expensive mistake here is a pack that looks proven and is not.
"""
import json
import unittest
import tempfile
from datetime import timedelta
from pathlib import Path

from sentinel_blue import pack_acceptance as acceptance
from sentinel_blue.linux_service_catalog import CATALOG, CONFIGURE

OPTIONS = {"bind_address": "127.0.0.1"}


def passing_results(*, optional="skipped"):
    results = {name: {"verdict": "passed", "detail": "proven on the lab host"}
               for name in acceptance.REQUIRED}
    results.update({name: {"verdict": optional, "detail": "needs a second host"}
                    for name in acceptance.OPTIONAL})
    return results


class MatrixTests(unittest.TestCase):
    def test_the_matrix_covers_the_lifecycle_a_pack_is_judged_on(self):
        """Not a checklist of conveniences: each of these can only fail on a host."""
        for name in ("apply", "config-test", "positive-transaction", "denied-transaction",
                     "identical-reapply", "approved-update", "outside-edit-refused",
                     "interrupted-setup", "rollback", "withdrawal"):
            with self.subTest(step=name):
                self.assertIn(name, acceptance.REQUIRED)

    def test_every_step_says_what_it_asks(self):
        for step in acceptance.MATRIX:
            with self.subTest(step=step["id"]):
                self.assertTrue(step["asks"].strip())
                self.assertIsInstance(step["required"], bool)

    def test_step_ids_are_unique(self):
        self.assertEqual(len(acceptance.STEPS), len(set(acceptance.STEPS)))


class FingerprintTests(unittest.TestCase):
    def setUp(self):
        self.root = Path(tempfile.mkdtemp(prefix="sentinel-fp-"))

    def test_the_same_pack_and_options_fingerprint_the_same(self):
        first = acceptance.pack_fingerprint("redis", OPTIONS, self.root)
        second = acceptance.pack_fingerprint("redis", dict(OPTIONS), self.root)
        self.assertEqual(first, second)

    def test_changing_a_reviewed_option_changes_the_fingerprint(self):
        other = acceptance.pack_fingerprint("redis", {"bind_address": "127.0.0.2"}, self.root)
        self.assertNotEqual(acceptance.pack_fingerprint("redis", OPTIONS, self.root), other)

    def test_different_services_fingerprint_differently(self):
        self.assertNotEqual(
            acceptance.pack_fingerprint("redis", OPTIONS, self.root),
            acceptance.pack_fingerprint("mariadb", OPTIONS, self.root))

    def test_a_host_key_does_not_carry_the_machine_id(self):
        key = acceptance.host_key("dead-beef-machine-id")
        self.assertNotIn("dead-beef", key)
        self.assertEqual(key, acceptance.host_key("dead-beef-machine-id"))
        self.assertNotEqual(key, acceptance.host_key("a-different-machine"))


class ReceiptTests(unittest.TestCase):
    def setUp(self):
        self.state = Path(tempfile.mkdtemp(prefix="sentinel-state-"))
        self.root = Path(tempfile.mkdtemp(prefix="sentinel-pack-"))
        self.fingerprint = acceptance.pack_fingerprint("redis", OPTIONS, self.root)
        self.runtime = acceptance.runtime_fingerprint()

    def record(self, **overrides):
        arguments = dict(options=OPTIONS, results=passing_results(),
                         product_version="redis 7.0.15", fingerprint=self.fingerprint,
                         runtime=self.runtime, operator="lab")
        arguments.update(overrides)
        receipt = acceptance.build_receipt("redis", **arguments)
        acceptance.write(self.state, receipt)
        return receipt

    def state_of(self, **overrides):
        arguments = dict(fingerprint=self.fingerprint, runtime=self.runtime, product_version="redis 7.0.15")
        arguments.update(overrides)
        return acceptance.status(self.state, "redis", **arguments)

    # --- what makes a receipt ------------------------------------------------

    def test_without_a_receipt_a_pack_is_untested(self):
        answer = self.state_of()
        self.assertEqual(answer["state"], "untested")
        self.assertFalse(answer["native_tested"])

    def test_a_complete_run_is_accepted_and_names_the_product_version(self):
        self.record()
        answer = self.state_of()
        self.assertEqual(answer["state"], "accepted")
        self.assertTrue(answer["native_tested"])
        self.assertIn("redis 7.0.15", answer["reason"])

    def test_a_receipt_is_refused_when_a_required_step_did_not_pass(self):
        for verdict in ("failed", "skipped"):
            with self.subTest(verdict=verdict):
                results = passing_results()
                results["denied-transaction"] = {"verdict": verdict, "detail": "no profile"}
                with self.assertRaises(ValueError) as error:
                    acceptance.build_receipt(
                        "redis", options=OPTIONS, results=results,
                        product_version="redis 7.0.15", fingerprint=self.fingerprint,
                        runtime=self.runtime, operator="lab")
                self.assertIn("denied-transaction", str(error.exception))

    def test_optional_steps_may_be_skipped(self):
        receipt = acceptance.build_receipt(
            "redis", options=OPTIONS, results=passing_results(),
            product_version="redis 7.0.15", fingerprint=self.fingerprint,
            runtime=self.runtime, operator="lab")
        self.assertEqual(receipt["steps"]["reboot-survives"]["verdict"], "skipped")

    def test_a_receipt_records_who_and_what_it_covers(self):
        receipt = self.record()
        self.assertEqual(receipt["operator"], "lab")
        self.assertEqual(receipt["options"], OPTIONS)
        self.assertEqual(receipt["pack_fingerprint"], self.fingerprint)
        self.assertEqual(receipt["unit"], CATALOG["redis"]["unit"])

    def test_an_adoption_only_service_cannot_be_accepted(self):
        with self.assertRaises(ValueError):
            acceptance.build_receipt(
                "docker", options={}, results=passing_results(),
                product_version="27.0", fingerprint=self.fingerprint,
                runtime=self.runtime, operator="lab")

    def test_a_receipt_needs_a_product_version_and_an_operator(self):
        for missing in ("product_version", "operator"):
            with self.subTest(field=missing):
                with self.assertRaises(ValueError):
                    self.record(**{missing: "   "})

    # --- what makes it stop counting ----------------------------------------

    def test_changed_options_make_an_earlier_acceptance_stale(self):
        self.record()
        other = acceptance.pack_fingerprint("redis", {"bind_address": "127.0.0.2"}, self.root)
        answer = self.state_of(fingerprint=other)
        self.assertEqual(answer["state"], "stale")
        self.assertFalse(answer["native_tested"])
        self.assertIn("changed", answer["reason"])

    def test_a_different_runtime_makes_it_stale(self):
        self.record()
        answer = self.state_of(runtime="a" * 64)
        self.assertEqual(answer["state"], "stale")
        self.assertFalse(answer["native_tested"])

    def test_a_receipt_from_another_host_does_not_count_here(self):
        receipt = self.record()
        receipt["host_key"] = "0" * 32
        acceptance.write(self.state, receipt)
        answer = self.state_of()
        self.assertEqual(answer["state"], "stale")
        self.assertIn("different host", answer["reason"])

    def test_an_acceptance_expires(self):
        self.record()
        later = acceptance._now() + timedelta(days=acceptance.MAXIMUM_AGE_DAYS + 1)
        answer = acceptance.status(self.state, "redis", fingerprint=self.fingerprint,
                                   runtime=self.runtime, moment=later)
        self.assertEqual(answer["state"], "stale")
        self.assertFalse(answer["native_tested"])

    def test_a_receipt_dated_in_the_future_is_not_trusted(self):
        self.record()
        earlier = acceptance._now() - timedelta(days=30)
        answer = acceptance.status(self.state, "redis", fingerprint=self.fingerprint,
                                   runtime=self.runtime, moment=earlier)
        self.assertEqual(answer["state"], "stale")

    def test_a_tampered_receipt_that_drops_a_step_stops_counting(self):
        receipt = self.record()
        del receipt["steps"]["rollback"]
        acceptance.write(self.state, receipt)
        answer = self.state_of()
        self.assertEqual(answer["state"], "untested")
        self.assertIn("rollback", answer["reason"])

    def test_unreadable_or_foreign_receipts_read_as_untested(self):
        target = acceptance.path_for(self.state, "redis")
        target.parent.mkdir(parents=True, exist_ok=True)
        for content in ("", "not json at all", json.dumps({"schema": 99}),
                        json.dumps({"schema": 1, "service_id": "mariadb"}),
                        json.dumps(["a list"])):
            with self.subTest(content=content[:20]):
                target.write_text(content)
                self.assertEqual(self.state_of()["state"], "untested")

    def test_a_receipt_name_cannot_escape_its_directory(self):
        for bad in ("../../etc/passwd", "a/b", "", "."):
            with self.subTest(name=bad):
                with self.assertRaises(ValueError):
                    acceptance.path_for(self.state, bad)

    # --- what a receipt is not ----------------------------------------------

    def test_the_catalog_row_still_reports_native_tested_false(self):
        """A receipt is a property of this host, never of the shipped catalog."""
        self.record()
        self.assertFalse(CATALOG["redis"]["native_tested"])
        from sentinel_blue.linux_service_catalog import support_summary
        self.assertEqual(support_summary()["native_tested"], 0)

    def test_an_acceptance_changes_only_what_is_reported(self):
        """The pack builds and refuses identically with a receipt in place."""
        from sentinel_blue.linux_service_packs import build
        before = build("redis", OPTIONS, self.root)
        self.record()
        self.assertEqual(build("redis", OPTIONS, self.root), before)
        with self.assertRaises(ValueError):
            build("redis", {"bind_address": "10.0.0.5"}, self.root)


class SummaryTests(unittest.TestCase):
    def setUp(self):
        self.state = Path(tempfile.mkdtemp(prefix="sentinel-summary-"))
        self.root = Path(tempfile.mkdtemp(prefix="sentinel-summary-pack-"))

    def test_an_empty_host_says_plainly_that_nothing_is_proven(self):
        summary = acceptance.summary(self.state)
        self.assertEqual(summary["accepted"], [])
        self.assertIn("none of the", summary["statement"])
        self.assertIn("not an accepted setup capability", summary["statement"])

    def test_the_summary_counts_only_configuring_services(self):
        configuring = {sid for sid, row in CATALOG.items() if row["capability"] == CONFIGURE}
        self.assertEqual(acceptance.summary(self.state)["total"], len(configuring))

    def test_an_accepted_pack_is_named_and_the_rest_are_still_unproven(self):
        fingerprint = acceptance.pack_fingerprint("redis", OPTIONS, self.root)
        acceptance.write(self.state, acceptance.build_receipt(
            "redis", options=OPTIONS, results=passing_results(),
            product_version="redis 7.0.15", fingerprint=fingerprint,
            runtime=acceptance.runtime_fingerprint(), operator="lab"))
        summary = acceptance.summary(self.state, contexts={"redis": {"options": OPTIONS, "root": str(self.root), "product_version": "redis 7.0.15"}})
        self.assertEqual(summary["accepted"], ["redis"])
        self.assertIn("unproven here", summary["statement"])

    def test_the_catalog_summary_reports_what_this_host_has_proven(self):
        from sentinel_blue.linux_service_catalog import support_summary
        fingerprint = acceptance.pack_fingerprint("redis", OPTIONS, self.root)
        acceptance.write(self.state, acceptance.build_receipt(
            "redis", options=OPTIONS, results=passing_results(),
            product_version="redis 7.0.15", fingerprint=fingerprint,
            runtime=acceptance.runtime_fingerprint(), operator="lab"))
        summary = support_summary(self.state, contexts={"redis": {"options": OPTIONS, "root": str(self.root), "product_version": "redis 7.0.15"}})
        self.assertEqual(summary["accepted_here"], ["redis"])
        self.assertIn("redis", summary["statement"])
        self.assertIn("not support", summary["statement"])
        # And the shipped fact is unchanged.
        self.assertEqual(summary["native_tested"], 0)


class HarnessTests(unittest.TestCase):
    """The runner itself: what it refuses, and what it promises before it acts.

    The harness edits real configuration, restarts real services and forces a
    failure mid-apply. Everything below is about making that impossible to do by
    accident, and reviewable before it happens.
    """

    TOOL = Path(__file__).resolve().parents[1] / "tools/service_pack_acceptance.py"

    def invoke(self, *arguments):
        import subprocess
        import sys
        return subprocess.run([sys.executable, str(self.TOOL), *arguments],
                              capture_output=True, text=True, timeout=120)

    def test_the_harness_exists_where_the_documentation_says(self):
        self.assertTrue(self.TOOL.is_file())

    def test_it_refuses_to_run_without_being_told_the_host_is_disposable(self):
        done = self.invoke("--service", "redis", "--run")
        self.assertNotEqual(done.returncode, 0)
        self.assertIn("--host-is-disposable", done.stderr)
        self.assertIn("destroy", done.stderr)

    def test_it_refuses_a_service_that_is_not_in_the_catalog(self):
        done = self.invoke("--service", "not-a-service", "--plan")
        self.assertNotEqual(done.returncode, 0)
        self.assertIn("not a catalog service", done.stderr)

    def test_it_refuses_an_adoption_only_service(self):
        """There is no generated configuration to accept, so there is no acceptance."""
        done = self.invoke("--service", "docker", "--plan")
        self.assertNotEqual(done.returncode, 0)
        self.assertIn("adoption-only", done.stderr)

    def test_planning_changes_nothing_and_needs_no_privilege(self):
        done = self.invoke("--service", "redis", "--plan")
        self.assertEqual(done.returncode, 0, done.stderr)
        self.assertIn("Acceptance plan", done.stdout)

    def test_the_plan_lists_every_step_of_the_matrix(self):
        done = self.invoke("--service", "bind9", "--plan")
        for step in acceptance.STEPS:
            with self.subTest(step=step):
                self.assertIn(step, done.stdout)

    def test_the_plan_prints_the_commands_before_any_of_them_run(self):
        done = self.invoke("--service", "bind9", "--plan")
        self.assertIn("Commands, in order:", done.stdout)
        # The product's own configuration test, taken from the catalog.
        self.assertIn("named-checkconf", done.stdout)

    def test_the_plan_says_when_no_receipt_could_be_earned(self):
        """Without transaction probes the run is pointless, and it says so first."""
        done = self.invoke("--service", "redis", "--plan")
        self.assertIn("no receipt would be written", done.stdout)

    def test_incomplete_run_is_refused_on_both_native_and_sandbox_hosts(self):
        """A valid native host still cannot run without reviewed options."""
        done = self.invoke("--service", "redis", "--run", "--host-is-disposable")
        self.assertNotEqual(done.returncode, 0)
        self.assertTrue(
            any(word in done.stderr for word in ("systemd", "root", "Debian-family", "Linux only", "needs --options")),
            done.stderr)

    def test_simulated_non_systemd_host_is_refused_before_execution(self):
        from contextlib import redirect_stderr
        import io
        from types import SimpleNamespace
        from unittest.mock import patch
        from tools import service_pack_acceptance as runner
        error = io.StringIO()
        with patch.object(runner.os, 'name', 'posix'), \
             patch.object(runner.os, 'geteuid', return_value=0, create=True), \
             patch.object(runner.pack_acceptance, 'platform_identity', return_value={'id': 'debian'}), \
             patch.object(runner.shutil, 'which', return_value='/usr/bin/systemctl'), \
             patch.object(runner.Path, 'read_text', return_value='python\n'), \
             redirect_stderr(error):
            with self.assertRaises(SystemExit):
                runner.check_host(SimpleNamespace(host_is_disposable=True))
        self.assertIn('container stand-in cannot accept a unit', error.getvalue())


if __name__ == "__main__":
    unittest.main()
