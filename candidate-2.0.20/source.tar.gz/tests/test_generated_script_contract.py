"""The two properties every service pack owes, checked without a real service.

A pack's whole output is text that will be executed on a competition host. Two
things can be established here, and only here, because nothing installed in this
sandbox is the real product:

**The script it generates must be executable shell.** A generated script with a
syntax error does not fail in review; it fails on the host, in the middle of an
event, after the plan was approved. `sh -n` costs nothing and answers it.

**Every malformed option must be refused with a stated reason.** The desktop's
parameter dialog reports a correction only for ValueError, TypeError, KeyError
and OSError, so a pack that lets an AttributeError escape leaves the operator
staring at a button that appears to do nothing. Anything but ValueError here is
a defect, whatever the input.

Neither test says a pack works. `native_tested` stays False until the pack has
run against the real product on the target platform.
"""
import hashlib
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

from sentinel_blue.linux_service_packs import BUILDERS, build

# One reviewed, valid option set per pack. These are the shapes an operator is
# meant to supply; the packs are built from them and the output is checked.
BASELINE = {
    "apache2": {"server_name": "scored.range.test", "document_root": "/srv/scored"},
    "bind9": {"mode": "create-owned", "zone": "range.test", "soa_mname": "ns1.range.test",
              "records": [{"name": "www", "type": "A", "value": "192.168.10.20"}]},
    "chrony": {"sources": ["time.range.test"], "allow": ["192.168.10.0/24"]},
    "dnsmasq": {},
    "dovecot": {},
    "gunicorn": {"application": "scored.wsgi:app", "working_directory": "/srv/scored",
                 "user": "scored"},
    "haproxy": {"backends": [{"address": "192.168.10.20", "port": 8080}]},
    "isc-dhcp-server": {"subnet": "192.168.10.0", "netmask": "255.255.255.0",
                        "range_start": "192.168.10.10", "range_end": "192.168.10.50",
                        "routers": ["192.168.10.1"], "dns_servers": ["192.168.10.1"],
                        "authorized": True},
    "mariadb": {"bind_address": "127.0.0.1"},
    "mosquitto": {},
    "nfs-server": {"export_path": "/srv/share", "clients": ["192.168.10.0/24"]},
    "openssh-server": {"allow_groups": ["blue"]},
    "postfix": {"myhostname": "mail.range.test", "mydomain": "range.test",
                "mynetworks": ["192.168.10.0/24"]},
    "postgresql": {"config_directory": "/etc/postgresql/17/main",
                   "allowed_networks": ["192.168.10.0/24"]},
    "redis": {"bind_address": "127.0.0.1"},
    "rsyslog": {"forward_to": "192.168.10.9"},
    "samba": {"share": "scored", "path": "/srv/scored", "valid_users": ["blue"]},
    "unbound": {},
    "vsftpd": {"local_enable": True, "previous_sha256": "b" * 64},
}

# Postfix merges into the operator's real main.cf, so its baseline needs a
# hash-pinned snapshot of that file rather than a literal value.
MAIN_CF = "smtpd_banner = $myhostname ESMTP\ninet_interfaces = all\n"

# Values an operator can plausibly type that are the wrong shape. A single
# string where a list belongs is the common one: JSON makes it easy and
# iterating it yields characters rather than entries.
MALFORMED = (
    "a-single-string",
    7,
    True,
    [],
    ["a-string"],
    [7],
    [None],
    [[]],
    [{"unexpected": "object"}],
    {"unexpected": "object"},
    {"nested": {"deeper": [1]}},
)


def baseline_for(service_id, root):
    options = dict(BASELINE[service_id])
    if service_id == "postfix":
        (root / "main.cf").write_text(MAIN_CF)
        options["main_config"] = {"path": "main.cf",
                                  "sha256": hashlib.sha256(MAIN_CF.encode()).hexdigest()}
    return options


class GeneratedScriptSyntaxTests(unittest.TestCase):
    """What a pack would send to a host has to be runnable there."""

    @classmethod
    def setUpClass(cls):
        cls.shells = [name for name in ("sh", "bash") if shutil.which(name)]

    def setUp(self):
        self.root = Path(tempfile.mkdtemp(prefix="sentinel-script-"))

    def scripts(self, service_id):
        check, apply, rollback = build(service_id, baseline_for(service_id, self.root), self.root)
        return {"check": check, "apply": apply, "rollback": rollback}

    def test_every_pack_has_a_reviewed_baseline(self):
        """A new pack without a baseline would silently skip both properties."""
        self.assertEqual(sorted(BUILDERS), sorted(BASELINE))

    def test_every_generated_script_is_valid_shell(self):
        if not self.shells:
            self.skipTest("no shell available to parse with")
        for service_id in sorted(BASELINE):
            for phase, script in self.scripts(service_id).items():
                if not script:
                    continue
                for shell in self.shells:
                    with self.subTest(service=service_id, phase=phase, shell=shell):
                        done = subprocess.run([shell, "-n"], input=script, text=True,
                                              capture_output=True)
                        self.assertEqual(done.returncode, 0, done.stderr)

    def test_the_embedded_preflight_validator_compiles(self):
        """The check payload is executed by python3 on the host, not here."""
        marker = "SENTINEL_PACK_CHECK"
        found = 0
        for service_id in sorted(BASELINE):
            for phase, script in self.scripts(service_id).items():
                if not script or marker not in script:
                    continue
                for chunk in script.split(f"<<'{marker}'\n")[1:]:
                    body = chunk.split(f"\n{marker}")[0]
                    found += 1
                    with self.subTest(service=service_id, phase=phase):
                        compile(body, "embedded-check", "exec")
        self.assertGreater(found, 0, "no embedded validator was generated at all")

    def test_a_generated_script_never_carries_an_unexpanded_placeholder(self):
        for service_id in sorted(BASELINE):
            for phase, script in self.scripts(service_id).items():
                if not script:
                    continue
                with self.subTest(service=service_id, phase=phase):
                    self.assertNotIn("{}", script)
                    self.assertNotIn("None", script)


class MalformedOptionTests(unittest.TestCase):
    """Garbage in any option is refused with a reason, never an internal error."""

    def setUp(self):
        self.root = Path(tempfile.mkdtemp(prefix="sentinel-malformed-"))

    def test_every_option_of_every_pack_refuses_garbage_cleanly(self):
        # Every option name any pack accepts. A pack that does not accept one
        # refuses it as unknown, which is itself a clean refusal.
        names = sorted({name for options in BASELINE.values() for name in options}
                       | {"previous_sha256", "previous_files", "activation", "main_config",
                          "manager", "file_modes", "existing_dependencies"})
        for service_id in sorted(BASELINE):
            baseline = baseline_for(service_id, self.root)
            for name in names:
                for value in MALFORMED:
                    options = {**baseline, name: value}
                    with self.subTest(service=service_id, option=name, value=repr(value)[:30]):
                        try:
                            build(service_id, options, self.root)
                        except ValueError:
                            pass
                        except Exception as exc:      # noqa: BLE001 - that is the point
                            self.fail(f"{service_id}.{name}={value!r} raised "
                                      f"{type(exc).__name__}: {exc}")

    def test_a_list_option_refuses_a_bare_string_by_name(self):
        """The message has to name the option, not describe a Python type error."""
        cases = [("chrony", "sources"), ("openssh-server", "allow_groups"),
                 ("samba", "valid_users"), ("nfs-server", "clients"),
                 ("haproxy", "backends"), ("isc-dhcp-server", "routers")]
        for service_id, name in cases:
            with self.subTest(service=service_id, option=name):
                options = {**baseline_for(service_id, self.root), name: "one-entry"}
                with self.assertRaises(ValueError) as error:
                    build(service_id, options, self.root)
                self.assertIn("list", str(error.exception))

    def test_a_haproxy_backend_states_the_shape_it_wants(self):
        """The natural mistake is a list of "host:port" strings."""
        options = {"backends": ["192.168.10.20:8080"]}
        with self.assertRaises(ValueError) as error:
            build("haproxy", options, self.root)
        self.assertIn("address", str(error.exception))


if __name__ == "__main__":
    unittest.main()
