"""2.0.17: the next five autonomy blockers from the 2.0.15 review.

6. The GUI's local session ended when either child exited, and a controller
   left without its supervisor blocked starting the session again.
7. One action result the controller refused (signed 409) held every later
   action on that agent for good.
8. An automatic Linux start had a fixed 5 s to validate, then was rolled back.
9. Recovery refused telemetry from an agent whose clock differed from a
   separate controller's, and continuity refused any difference over 5 s.
11. Once an unknown outcome was reconciled as executed, that service was never
    restarted automatically again.
"""
import copy
import hashlib
import json
import os
import signal
import subprocess
import sys
import tempfile
import textwrap
import threading
import time
import types
import unittest
from dataclasses import asdict
from pathlib import Path
from unittest.mock import MagicMock, patch
from urllib.error import HTTPError

import sentinel_blue.agent as agent_module
from sentinel_blue.actions import ActionExecutor
from sentinel_blue.agent import (ActionResultOutbox, AgentClient, deliver_pending_action_results,
                                 execute_queued_action, process_controller_actions)
from sentinel_blue.controller import AGENT_CLOCK_WINDOW_SECONDS, ControllerApp, ControllerServer, make_handler
from sentinel_blue.event_profile import EventProfile
from sentinel_blue.journaled_recovery import LEGACY_START_VALIDATION_SECONDS, start_plan
from sentinel_blue.policy import validate_action_parameters
from sentinel_blue.protocol import ProbeResult
from sentinel_blue.service_automation import LocalAutomation, snapshot
from sentinel_blue.service_recovery import START_VALIDATION_SECONDS, recovery_parameters
from sentinel_blue.state import ActionJournal, read_private_json, write_private_json
from sentinel_blue.store import Store
from sentinel_blue.validation import canonical_action_envelope_sha256, validate_action_request
from test_autonomous_service_recovery import fixtures, stopped
from test_store_controller import _promote_integrity_baseline

SOURCE = str(Path(__file__).resolve().parents[1] / "src")


def controller(profile=None, baseline=None, **options):
    if profile is None:
        profile, baseline = fixtures()
    store = Store(":memory:")
    app = ControllerApp(store, "t" * 32, operator_token="o" * 32, event_profile=profile,
                        auto_recover_services=True, **options)
    app.ingest(baseline)
    _promote_integrity_baseline(app, store, "agent-one")
    return app, store, profile, baseline


def outage(app, baseline, sequence, observed_at):
    for step, age in ((sequence, 1.0), (sequence + 1, 0.5)):
        sample = stopped(baseline, step)
        sample["observed_at"] = observed_at - age
        app.ingest(sample)


def recoveries(store):
    return [dict(row) for row in store._connection.execute(
        "SELECT action_id, status, alert_id FROM actions WHERE action_type IN ('restart_service','repair_service') "
        "ORDER BY created_at").fetchall()]


def skewed_time(skew):
    names = {name: getattr(time, name) for name in dir(time) if not name.startswith("__")}
    names["time"] = lambda: time.time() + skew
    return types.SimpleNamespace(**names)


# ---------------------------------------------------------------- bug 6 ---

class FakeChild:
    count = 0

    def __init__(self, arguments):
        FakeChild.count += 1
        self.pid = 100000 + FakeChild.count
        self.arguments = list(arguments)
        self.returncode = None
        self.terminated = False

    def poll(self):
        return self.returncode

    def exit(self, code=-9):
        self.returncode = code

    def terminate(self):
        self.terminated = True
        self.returncode = 0 if self.returncode is None else self.returncode

    kill = terminate

    def wait(self, timeout=None):
        return self.returncode


class SessionHarness(unittest.TestCase):
    """Runs the real session runner with fake children and a fake controller client."""

    fake_identity = True

    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)
        root.chmod(0o700)
        self.directory = root / "session"
        self.directory.mkdir(mode=0o700)
        self.runtime = root / "runtime.pyz"
        self.runtime.write_bytes(b"fixture runtime")
        self.config = {"session_id": "s" * 32, "directory": str(self.directory), "event_profile": str(root / "p.json"),
                       "runtime_sha256": hashlib.sha256(b"fixture runtime").hexdigest(), "autonomy": "approval-based"}
        write_private_json(self.directory / "session.json", self.config)
        self.spawned, self.refusal, self.fingerprint = [], None, "f" * 64
        self.dashboard_error = self.admission_error = None

        def admission():
            if self.admission_error is not None:
                error, self.admission_error = self.admission_error, None
                raise error
            return self.refusal
        client = MagicMock()
        client.dashboard.side_effect = lambda: (_ for _ in ()).throw(self.dashboard_error) if self.dashboard_error else {}

        def detach(arguments):
            child = FakeChild(arguments)
            self.spawned.append(child)
            return child

        for target, value in (
            ("sentinel_blue.desktop_jobs.detach", detach),
            ("sentinel_blue.linux_workspace.client_for", lambda config: client),
            ("sentinel_blue.linux_workspace.session_arguments", lambda config: (["controller"], ["agent"])),
            ("sentinel_blue.event_profile.load_event_profile",
             lambda path: types.SimpleNamespace(fingerprint=self.fingerprint)),
            ("sentinel_blue.mutation_tracking.admission_refusal", admission),
            ("sentinel_blue.setup_redo.tick", lambda *a, **k: None),
            ("sentinel_blue.linux_workspace.CHILD_RESTART_DELAY", 0.05),
            ("sentinel_blue.linux_workspace.MAX_CHILD_RESTART_DELAY", 0.2),
            ("signal.signal", lambda *a: None),
        ):
            patcher = patch(target, value)
            patcher.start()
            self.addCleanup(patcher.stop)
        if self.fake_identity:
            patcher = patch("sentinel_blue.process_identity.inspect_process_identity",
                            MagicMock(side_effect=OSError("fixture process")))
            patcher.start()
            self.addCleanup(patcher.stop)
        argv = patch.object(sys, "argv", [str(self.runtime)])
        argv.start()
        self.addCleanup(argv.stop)
        self.result = {}

    def start(self):
        from sentinel_blue.linux_workspace import run_session
        thread = threading.Thread(target=lambda: self.result.update(code=run_session(
            types.SimpleNamespace(session=str(self.directory / "session.json")))), daemon=True)
        thread.start()
        self.thread = thread
        self.wait(lambda: self.status().get("state") == "running" or not thread.is_alive())

    def status(self):
        try:
            return read_private_json(self.directory / "session-status.json", 4096)
        except (OSError, ValueError):
            return {}

    def wait(self, predicate, seconds=10):
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            if predicate():
                return True
            time.sleep(0.02)
        self.fail("condition not reached; status " + json.dumps(self.status()))

    def live(self, role):
        return [c for c in self.spawned if c.arguments == [role] and c.returncode is None]

    def stop(self):
        write_private_json(self.directory / "stop-session.json", {"session_id": self.config["session_id"]})
        self.thread.join(10)
        self.assertFalse(self.thread.is_alive())
        (self.directory / "stop-session.json").unlink(missing_ok=True)


class SessionRunnerTests(SessionHarness):
    """Bug 6: the local session restarts a child that exits and never gives up."""

    def test_an_exited_agent_or_supervisor_is_restarted_and_the_session_keeps_running(self):
        self.start()
        for role, label in (("agent", "agent"), ("controller", "controller supervisor"), ("agent", "agent")):
            (old,) = self.live(role)
            old.exit(-9)
            self.wait(lambda: len(self.live(role)) == 1 and self.live(role)[0] is not old)
            self.wait(lambda: f"Restarted the {label}" in self.status().get("reason", ""))
            self.assertEqual(self.status()["state"], "running")
        self.assertIn("agent 2, controller supervisor 1", self.status()["reason"])
        self.stop()
        self.assertEqual(self.result["code"], 0)
        self.assertEqual(self.status()["state"], "stopped")
        self.assertTrue(all(c.returncode is not None for c in self.spawned))

    def test_restart_delay_doubles_and_is_capped_without_giving_up(self):
        from sentinel_blue import linux_workspace as workspace
        with patch.object(workspace, "CHILD_RESTART_DELAY", 2.0), patch.object(workspace, "MAX_CHILD_RESTART_DELAY", 60.0):
            self.assertEqual([workspace.child_restart_delay(n) for n in range(1, 9)], [2, 4, 8, 16, 32, 60, 60, 60])
            # A child that keeps dying within seconds of starting is restarted
            # every five minutes after ten such exits in a row.
            self.assertEqual(workspace.child_restart_delay(20, 9), 60)
            self.assertEqual(workspace.child_restart_delay(20, 10), 300)

    def test_a_crash_loop_slows_down_and_a_busy_ledger_only_delays_a_restart(self):
        from sentinel_blue.mutation_ledger import LedgerBusy
        with patch("sentinel_blue.linux_workspace.RAPID_EXITS_BEFORE_SLOWDOWN", 2), \
                patch("sentinel_blue.linux_workspace.CRASH_LOOP_DELAY", 0.4), \
                patch("sentinel_blue.linux_workspace.LEDGER_BUSY_RETRY_SECONDS", 0.2):
            self.start()
            for attempt in range(2):
                (old,) = self.live("agent")
                if attempt == 1:
                    self.admission_error = LedgerBusy("ledger lock stayed held for 60s")
                old.exit(1)
                if attempt == 1:
                    self.wait(lambda: "in a row" in self.status().get("reason", ""))
                    self.wait(lambda: "host change ledger" in self.status().get("reason", ""))
                self.wait(lambda: len(self.live("agent")) == 1 and self.live("agent")[0] is not old)
            self.assertEqual(self.status()["state"], "running")
            self.stop()
        self.assertEqual(self.result["code"], 0)

    def test_withdrawal_pause_ends_the_session_instead_of_restarting(self):
        self.start()
        self.refusal = "Emergency withdrawal has paused this runtime; re-enrollment requires human review."
        (agent,) = self.live("agent")
        agent.exit(0)
        self.thread.join(10)
        self.assertEqual(self.result["code"], 2)
        self.assertEqual(self.status()["state"], "failed")
        self.assertIn("Emergency withdrawal", self.status()["reason"])
        self.assertEqual([c.arguments for c in self.spawned], [["controller"], ["agent"]])
        self.assertTrue(self.spawned[0].terminated)

    def test_a_changed_profile_or_runtime_is_a_hold_not_a_restart(self):
        for change in ("profile", "runtime"):
            with self.subTest(change=change):
                self.spawned.clear()
                self.fingerprint = "f" * 64
                self.runtime.write_bytes(b"fixture runtime")
                self.start()
                if change == "profile":
                    self.fingerprint = "e" * 64
                else:
                    self.runtime.write_bytes(b"changed runtime")
                self.live("controller")[0].exit(1)
                self.thread.join(10)
                self.assertEqual(self.result["code"], 2)
                self.assertIn("not restarted", self.status()["reason"])
                self.assertEqual(len(self.spawned), 2)
                (self.directory / "session-status.json").unlink()

    def test_controller_exit_before_readiness_still_fails_the_start(self):
        self.dashboard_error = OSError("not ready")
        from sentinel_blue.linux_workspace import run_session
        thread = threading.Thread(target=lambda: self.result.update(code=run_session(
            types.SimpleNamespace(session=str(self.directory / "session.json")))), daemon=True)
        thread.start()
        self.wait(lambda: bool(self.spawned))
        self.spawned[0].exit(1)
        thread.join(10)
        self.assertEqual(self.result["code"], 2)
        self.assertIn("Controller exited before readiness", self.status()["reason"])


PIDFD = unittest.skipUnless(sys.platform.startswith("linux") and hasattr(os, "pidfd_open"), "Linux pidfd required")


class Sleepers:
    def sleeper(self, *, ignore_term=False, executable=None):
        code = ("import signal, time; signal.signal(signal.SIGTERM, signal.SIG_IGN); time.sleep(120)"
                if ignore_term else "import time; time.sleep(120)")
        command = [executable, "120"] if executable else [sys.executable, "-c", code]
        child = subprocess.Popen(command, start_new_session=True)
        self.children.append(child)
        time.sleep(0.2)
        return child

    def reap(self):
        for child in self.children:
            if child.poll() is None:
                child.kill()
            child.wait(5)


class PreviousSessionProcessTests(Sleepers, unittest.TestCase):
    """Bug 6: processes a killed runner left behind are retired by verified identity."""

    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.directory = Path(temp.name)
        self.directory.chmod(0o700)
        self.config = {"session_id": "s" * 32}
        self.children = []
        self.addCleanup(self.reap)

    @PIDFD
    def test_verified_processes_are_stopped_and_a_reused_pid_is_not_signalled(self):
        from sentinel_blue.linux_workspace import (_record_children, read_previous_session_processes,
                                                   retire_previous_session_processes)
        from sentinel_blue.process_identity import inspect_process_identity
        agent, supervisor, stranger = self.sleeper(), self.sleeper(), self.sleeper()
        mismatched = inspect_process_identity(stranger.pid)
        mismatched["start_time"] = str(int(mismatched["start_time"]) + 1)   # the PID now names another process
        _record_children(self.directory, self.config, {"agent": inspect_process_identity(agent.pid)},
                         [("controller", inspect_process_identity(supervisor.pid)), ("agent", mismatched)])
        pending = read_previous_session_processes(self.directory, self.config)
        self.assertEqual(len(pending), 3)
        stopped_rows = retire_previous_session_processes(pending)
        self.assertEqual(sorted(row["role"] for row in stopped_rows), ["agent", "controller"])
        self.assertEqual(pending, [])
        self.assertEqual(agent.wait(5), -signal.SIGTERM)
        self.assertEqual(supervisor.wait(5), -signal.SIGTERM)
        self.assertIsNone(stranger.poll())

    @PIDFD
    def test_a_process_whose_executable_was_replaced_is_still_recognised(self):
        from sentinel_blue.linux_workspace import retire_previous_session_processes
        from sentinel_blue.process_identity import inspect_process_identity
        binary = self.directory / "sleep"
        binary.write_bytes(Path("/bin/sleep").read_bytes())
        binary.chmod(0o700)
        child = self.sleeper(executable=str(binary))
        identity = inspect_process_identity(child.pid)
        binary.unlink()                                   # e.g. the runtime was extracted again
        self.assertTrue(inspect_process_identity(child.pid)["executable_path"].endswith(" (deleted)"))
        pending = [("agent", identity)]
        self.assertEqual([row["role"] for row in retire_previous_session_processes(pending)], ["agent"])
        self.assertEqual(child.wait(5), -signal.SIGTERM)

    @PIDFD
    def test_a_process_that_does_not_stop_stays_pending(self):
        from sentinel_blue.linux_workspace import retire_previous_session_processes
        from sentinel_blue.process_identity import inspect_process_identity
        stubborn = self.sleeper(ignore_term=True)
        pending = [("agent", inspect_process_identity(stubborn.pid))]
        with patch("sentinel_blue.linux_workspace.ORPHAN_STOP_SECONDS", 0.5), \
                self.assertRaisesRegex(RuntimeError, "did not stop"):
            retire_previous_session_processes(pending)
        self.assertEqual(len(pending), 1)

    def test_a_record_from_another_session_or_role_is_refused(self):
        from sentinel_blue.linux_workspace import read_previous_session_processes
        self.assertEqual(read_previous_session_processes(self.directory, self.config), [])
        for record, message in (({"session_id": "other", "children": {}}, "not this session"),
                                ({"session_id": self.config["session_id"], "children": {"shell": {}}}, "unknown process role"),
                                ({"session_id": self.config["session_id"], "children": {"agent": {"pid": 1}}}, "malformed")):
            write_private_json(self.directory / "session-processes.json", record)
            with self.subTest(message=message), self.assertRaisesRegex(RuntimeError, message):
                read_previous_session_processes(self.directory, self.config)


@PIDFD
class SessionRecordTests(Sleepers, SessionHarness):
    """Bug 6 (review finding): a start that fails never forgets the processes left behind."""

    fake_identity = False

    def setUp(self):
        super().setUp()
        self.children = []
        self.addCleanup(self.reap)

    def record(self):
        return read_private_json(self.directory / "session-processes.json")

    def leftover(self, **options):
        from sentinel_blue.linux_workspace import _record_children
        from sentinel_blue.process_identity import inspect_process_identity
        child = self.sleeper(**options)
        _record_children(self.directory, self.config, {"agent": inspect_process_identity(child.pid)})
        return child

    def run_once(self):
        """Start the session and wait for a start that fails to finish."""
        self.start()
        if self.status().get("state") != "running":
            self.thread.join(20)

    def test_a_refused_start_keeps_the_record_and_the_next_start_retires_the_process(self):
        old = self.leftover()
        before = self.record()
        self.refusal = "Emergency withdrawal review is in progress."
        self.run_once()
        self.assertEqual(self.result["code"], 2)
        self.assertEqual(self.record(), before)
        self.assertIsNone(old.poll())
        self.refusal = None
        self.start()
        self.assertEqual(self.status()["state"], "running")
        self.assertEqual(old.wait(5), -signal.SIGTERM)
        self.assertIn("left by an earlier run", self.status()["reason"])
        self.assertEqual(self.record()["previous"], [])
        self.stop()

    def test_a_process_that_does_not_stop_is_still_recorded_for_the_next_start(self):
        stubborn = self.leftover(ignore_term=True)
        with patch("sentinel_blue.linux_workspace.ORPHAN_STOP_SECONDS", 0.5):
            self.run_once()
        self.assertEqual(self.result["code"], 2)
        self.assertIn("did not stop", self.status()["reason"])
        self.assertEqual([row["identity"]["process_id"] for row in self.record()["previous"]], [stubborn.pid])
        self.assertEqual(self.spawned, [])
        stubborn.kill()
        stubborn.wait(5)
        self.start()
        self.assertEqual(self.status()["state"], "running")
        self.assertEqual(self.record()["previous"], [])
        self.stop()

    def test_a_foreign_record_is_refused_on_every_start_and_kept(self):
        write_private_json(self.directory / "session-processes.json", {"session_id": "other", "children": {}})
        for _ in range(2):
            self.run_once()
            self.assertEqual(self.result["code"], 2)
            self.assertIn("not this session", self.status()["reason"])
            self.assertEqual(self.record()["session_id"], "other")
        self.assertEqual(self.spawned, [])


@unittest.skipIf(os.name == "nt", "POSIX parent watch")
class SupervisorParentWatchTests(unittest.TestCase):
    """Bug 6: a supervised controller stops once its supervisor has died."""

    SUPERVISOR = textwrap.dedent("""
        import sys, time
        sys.path.insert(0, sys.argv[1])
        from sentinel_blue.controller_supervisor import OwnedController
        child = OwnedController([sys.executable, "-c", sys.argv[2], sys.argv[1], sys.argv[3]])
        print(child.process.pid, flush=True)
        time.sleep(120)
    """)
    CHILD = textwrap.dedent("""
        import json, os, sys, threading, time
        sys.path.insert(0, sys.argv[1])
        from sentinel_blue.controller_supervisor import expected_supervisor_pid, watch_supervisor
        expected = expected_supervisor_pid()
        marker = sys.argv[2]
        def orphaned():
            with open(marker, "w") as handle:
                json.dump({"expected": expected, "parent": os.getppid(),
                           "inherited": "SENTINEL_SUPERVISOR_PID" in os.environ}, handle)
            os._exit(0)
        watch_supervisor(expected, threading.Event(), interval=0.05, on_orphaned=orphaned)
        time.sleep(120)
    """)

    def test_controller_child_stops_when_its_supervisor_is_killed(self):
        with tempfile.TemporaryDirectory() as temp:
            marker = Path(temp) / "orphaned.json"
            supervisor = subprocess.Popen([sys.executable, "-c", self.SUPERVISOR, SOURCE, self.CHILD, str(marker)],
                                          stdout=subprocess.PIPE, text=True)
            try:
                child_pid = int(supervisor.stdout.readline())
                time.sleep(0.3)
                self.assertFalse(marker.exists())
                supervisor.kill()
                supervisor.wait(5)
                deadline = time.monotonic() + 10
                while not marker.exists() and time.monotonic() < deadline:
                    time.sleep(0.05)
                record = json.loads(marker.read_text())
                self.assertEqual(record["expected"], supervisor.pid)
                self.assertNotEqual(record["parent"], supervisor.pid)
                self.assertFalse(record["inherited"])
            finally:
                supervisor.stdout.close()
                if supervisor.poll() is None:
                    supervisor.kill()
                    supervisor.wait(5)
                try:
                    os.kill(child_pid, signal.SIGKILL)
                except (OSError, UnboundLocalError):
                    pass

    def test_controller_refuses_to_start_when_its_supervisor_is_already_gone(self):
        from sentinel_blue import controller as controller_module
        with patch.dict(os.environ, {"SENTINEL_SUPERVISOR_PID": str(os.getppid() + 1 if os.getppid() > 1 else 2)}):
            with self.assertRaisesRegex(RuntimeError, "supervisor exited before this controller started"):
                controller_module.run(types.SimpleNamespace(supervisor_child=True))
            self.assertNotIn("SENTINEL_SUPERVISOR_PID", os.environ)

    def test_unsupervised_and_matching_parents_are_not_orphans(self):
        from sentinel_blue.controller_supervisor import expected_supervisor_pid, supervisor_gone
        with patch.dict(os.environ, {"SENTINEL_SUPERVISOR_PID": str(os.getppid())}):
            expected = expected_supervisor_pid()
        self.assertEqual(expected, os.getppid())
        self.assertFalse(supervisor_gone(expected))
        self.assertFalse(supervisor_gone(None))
        with patch.dict(os.environ, {"SENTINEL_SUPERVISOR_PID": "not-a-pid"}):
            self.assertIsNone(expected_supervisor_pid())


# ---------------------------------------------------------------- bug 7 ---

class RefusedResultTests(unittest.TestCase):
    """Bug 7: a result the controller refused no longer holds all later work."""

    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)
        self.profile = EventProfile.testing()
        self.journal = ActionJournal(root / "delivery", profile_fingerprint=self.profile.fingerprint)
        self.outbox = ActionResultOutbox(self.journal)
        now = time.time()
        self.result = {"action_type": "snapshot", "success": False, "message": "fixture",
                       "started_at": now, "completed_at": now}

    def enqueue(self, action_id):
        self.journal.remember(action_id, dict(self.result, action_id=action_id), "a" * 64, expires_at=time.time() + 300)
        self.outbox.enqueue(action_id, dict(self.result, action_id=action_id))

    class Client:
        def __init__(self, status=None):
            self.status, self.fetches, self.offered = status, 0, []

        def result(self, action_id, value):
            self.offered.append(action_id)
            if self.status is None:
                raise OSError("controller unreachable")
            error = HTTPError("https://controller/api/v1/agent/result", self.status, "refused", {}, None)
            error.sentinel_blue_verified = True
            raise error

        def actions(self):
            self.fetches += 1
            return []

    def fetch(self, client):
        executor = MagicMock()
        return process_controller_actions(client, self.outbox, self.journal, executor, {"boot_id": "b"},
                                          {"action_safe": True}, self.profile)

    def test_refused_result_is_kept_and_offered_but_new_work_continues(self):
        self.enqueue("refused-one")
        client = self.Client(409)
        base = time.time()
        for cycle in range(6):
            deliver_pending_action_results(client, self.outbox, now=base + 3601 * (cycle + 1))
        self.assertEqual(len(client.offered), 6)                  # still offered every cycle
        record = self.outbox.delivery_record("refused-one")
        self.assertEqual((record["state"], record["last_status"]), ("reconciliation", 409))
        self.assertTrue(self.outbox.has_unacknowledged())
        self.assertEqual(self.outbox.refused(), ["refused-one"])
        self.assertFalse(self.outbox.holds_new_leases())
        self.fetch(client)
        self.assertEqual(client.fetches, 1)

    def test_a_result_still_on_its_way_holds_new_work(self):
        self.enqueue("refused-one")
        base = time.time()
        for cycle in range(4):
            deliver_pending_action_results(self.Client(409), self.outbox, now=base + 3601 * (cycle + 1))
        self.assertEqual(self.outbox.refused(), ["refused-one"])
        self.assertFalse(self.outbox.holds_new_leases())
        # A result not yet refused four times (here the controller is
        # unreachable) keeps holding new leases exactly as before.
        self.enqueue("unreachable")
        deliver_pending_action_results(self.Client(None), self.outbox, now=base + 99999)
        self.assertTrue(self.outbox.holds_new_leases())
        client = self.Client(409)
        self.fetch(client)
        self.assertEqual(client.fetches, 0)

    def test_a_404_keeps_holding_because_the_controller_has_no_record(self):
        # A signed 404 means the controller has no row for the action (for
        # example after a database restore), so nothing there holds it.
        self.enqueue("unknown-to-controller")
        base = time.time()
        for cycle in range(6):
            deliver_pending_action_results(self.Client(404), self.outbox, now=base + 3601 * (cycle + 1))
        self.assertEqual(self.outbox.refused(), [])
        self.assertTrue(self.outbox.holds_new_leases())

    def test_a_transport_failure_while_re_offering_does_not_rearm_the_hold(self):
        self.enqueue("refused-one")
        base = time.time()
        for cycle in range(4):
            deliver_pending_action_results(self.Client(409), self.outbox, now=base + 3601 * (cycle + 1))
        self.assertFalse(self.outbox.holds_new_leases())
        deliver_pending_action_results(self.Client(None), self.outbox, now=base + 3601 * 5)     # unreachable
        unavailable = self.Client(503)
        deliver_pending_action_results(unavailable, self.outbox, now=base + 3601 * 6)            # server error
        self.assertEqual(self.outbox.delivery_record("refused-one")["last_status"], 409)
        self.assertFalse(self.outbox.holds_new_leases())
        # A signed decision that the controller has no record does re-arm it.
        deliver_pending_action_results(self.Client(404), self.outbox, now=base + 3601 * 7)
        self.assertTrue(self.outbox.holds_new_leases())

    def test_only_signed_refusals_count_towards_releasing(self):
        self.enqueue("once")
        base = time.time()
        deliver_pending_action_results(self.Client(409), self.outbox, now=base + 3601)
        for cycle in range(5):
            deliver_pending_action_results(self.Client(None), self.outbox, now=base + 3601 * (cycle + 2))
        record = self.outbox.delivery_record("once")
        self.assertEqual((record["state"], record["reconciliation_attempts"], record["last_status"]),
                         ("reconciliation", 1, 409))
        self.assertTrue(self.outbox.holds_new_leases())

    def test_fewer_than_four_refusals_still_hold(self):
        self.enqueue("once")
        deliver_pending_action_results(self.Client(409), self.outbox, now=time.time() + 3601)
        self.assertEqual(self.outbox.refused(), [])
        self.assertTrue(self.outbox.holds_new_leases())


class RefusedResultContinuityTests(unittest.TestCase):
    """Bug 7 with continuity: after the operator reconciles, work resumes (it never did before)."""

    def setUp(self):
        from test_offline_authority import OfflineAuthorityTests
        holder = OfflineAuthorityTests("run")
        holder.setUp()
        self.addCleanup(holder.doCleanups)
        self.f = holder

    def test_reconciled_action_releases_the_agent_despite_a_refused_result(self):
        f = self.f
        secret = f.store.agent_secret("agent-one")
        now = time.time()
        for sequence in (2, 3):
            sample = stopped(f.baseline, sequence)
            sample.update(observed_at=now - 1 + sequence * 0.1, queued_at=now)
            f.app.ingest(sample, "agent-one", secret)
        (action,) = [asdict(a) for a in f.app.pending_actions_for_agent("agent-one")
                     if asdict(a)["action_type"] == "restart_service"]
        f.agent.sync(f.client, f.journal)
        self.assertFalse(f.agent.online)
        self.assertEqual(f.app.continuity._row("agent-one")["held"], "unknown action outcome")
        # The operator reconciles the delivered restart; the agent's late result
        # is then refused (signed 409) on every delivery attempt.
        with patch("time.time", return_value=now + 400):
            f.store.pending_actions("agent-one")
        f.app.reconcile_action_outcome(action["action_id"], "executed")
        late = dict(action_type="restart_service", success=True, message="late", started_at=now, completed_at=now,
                    action_envelope_sha256=canonical_action_envelope_sha256(action))
        self.assertEqual(f.app.complete_action(dict(late, action_id=action["action_id"]), "agent-one"), "conflict")
        outbox = ActionResultOutbox(f.journal)
        f.journal.remember(action["action_id"], dict(late, action_id=action["action_id"]), "b" * 64, expires_at=now + 300)
        outbox.enqueue(action["action_id"], dict(late, action_id=action["action_id"]))
        client = RefusedResultTests.Client(409)
        for cycle in range(4):
            deliver_pending_action_results(client, outbox, now=now + 3601 * (cycle + 1))
        self.assertFalse(outbox.holds_new_leases())
        f.agent.sync(f.client, f.journal)
        self.assertTrue(f.agent.online)
        self.assertEqual(f.app.continuity._row("agent-one")["held"], "")


# ---------------------------------------------------------------- bug 8 ---

class VirtualClock:
    def __init__(self):
        self.now = 1000.0

    def monotonic(self):
        return self.now

    def sleep(self, seconds):
        self.now += max(0.0, seconds)


class StartValidationWindowTests(unittest.TestCase):
    """Bug 8: an automatic start is validated for the manifest's window, not a fixed 5 s."""

    def guarded(self, repair_policy=None):
        profile, baseline = fixtures()
        if repair_policy is not None:
            raw = copy.deepcopy(profile.raw)
            raw["services"][0]["repair_policy"] = repair_policy
            raw["services"][0]["approval_actions"].append("rollback_service")
            profile = EventProfile.from_dict(raw)
        current = stopped(baseline, 2)
        current["observed_at"] = time.time() - 1
        return recovery_parameters(profile, "agent-one", "web.service", baseline, current)

    def test_window_comes_from_the_signed_guard(self):
        parameters = self.guarded()
        self.assertEqual(parameters["recovery_guard"]["validation_timeout_seconds"], START_VALIDATION_SECONDS)
        self.assertEqual(start_plan(parameters)["repair"]["validation_timeout_seconds"], 30)
        policy = {"restore_files": [], "restart_unhealthy": False, "validation_timeout_seconds": 90}
        parameters = self.guarded(policy)
        self.assertEqual(start_plan(parameters)["repair"]["validation_timeout_seconds"], 90)
        # A guard signed by 2.0.16 has no window: its journal still verifies with 5 s.
        legacy = copy.deepcopy(parameters)
        del legacy["recovery_guard"]["validation_timeout_seconds"]
        self.assertEqual(start_plan(legacy)["repair"]["validation_timeout_seconds"], LEGACY_START_VALIDATION_SECONDS)

    def test_agent_refuses_a_window_that_differs_from_its_manifest(self):
        from sentinel_blue.service_recovery import validate_automatic_recovery
        profile, baseline = fixtures()
        raw = copy.deepcopy(profile.raw)
        raw["services"][0]["repair_policy"] = {"restore_files": [], "restart_unhealthy": False,
                                               "validation_timeout_seconds": 90}
        profile = EventProfile.from_dict(raw)
        current = stopped(baseline, 2)
        current["observed_at"] = time.time() - 1
        parameters = recovery_parameters(profile, "agent-one", "web.service", baseline, current)
        with patch("sentinel_blue.service_recovery.check_restart_target"):
            validate_automatic_recovery(profile, "agent-one", parameters, current)
            for window in (30, 120):
                changed = copy.deepcopy(parameters)
                changed["recovery_guard"]["validation_timeout_seconds"] = window
                with self.subTest(window=window), self.assertRaisesRegex(ValueError, "validation window differs"):
                    validate_automatic_recovery(profile, "agent-one", changed, current)
            legacy = copy.deepcopy(parameters)
            del legacy["recovery_guard"]["validation_timeout_seconds"]
            validate_automatic_recovery(profile, "agent-one", legacy, current)

    def test_window_is_bounded_by_the_action_policy(self):
        parameters = self.guarded()
        for window in (4, 121, 5.5, True, "30"):
            candidate = copy.deepcopy(parameters)
            candidate["recovery_guard"]["validation_timeout_seconds"] = window
            with self.subTest(window=window), self.assertRaisesRegex(ValueError, "validation window"):
                validate_action_parameters("restart_service", candidate)
        for window in (5, 120):
            candidate = copy.deepcopy(parameters)
            candidate["recovery_guard"]["validation_timeout_seconds"] = window
            validate_action_parameters("restart_service", candidate)

    def run_start(self, healthy_after):
        clock = VirtualClock()
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp).resolve()
            target = root / "web.conf"
            target.write_bytes(b"trusted")
            profile, baseline = fixtures(str(target))
            app, store, _, _ = controller(profile, baseline)
            self.addCleanup(store.close)
            executor = ActionExecutor(root / "state", allow_service_recovery=True, allow_restoration=False,
                                      profile_fingerprint=profile.fingerprint)
            state = {"native": "stopped", "since": None, "log": []}

            def transition(service, desired):
                state["log"].append(desired)
                state["native"] = desired
                state["since"] = clock.now if desired == "running" else None

            spec = profile.services[0]["expected_transactions"][0]

            def probes(specs, *args, **kwargs):
                clock.sleep(0.2)
                up = (healthy_after is not None and state["since"] is not None
                      and clock.now - state["since"] >= healthy_after)
                return [ProbeResult(spec["name"], spec["target"], up)]

            with patch.object(executor, "_service_state", side_effect=lambda _: state["native"]), \
                 patch.object(executor, "_set_service_state", side_effect=transition), \
                 patch.object(executor.repairs, "_transition", side_effect=transition), \
                 patch("sentinel_blue.actions.run_probes", side_effect=probes), \
                 patch("sentinel_blue.actions.time", types.SimpleNamespace(
                     time=time.time, monotonic=clock.monotonic, sleep=clock.sleep)), \
                 patch("sentinel_blue.probes.check_local_probe_prerequisites", return_value=None), \
                 patch("sentinel_blue.actions.dependency_readiness", return_value={"ready": True, "missing": []}):
                outage(app, baseline, 2, time.time())
                LocalAutomation(executor.state_dir, profile, "agent-one").accept(snapshot(store, profile, "agent-one"))
                envelope = asdict(app.pending_actions_for_agent("agent-one")[0])
                started = clock.now
                result = execute_queued_action(ActionJournal(root / "delivery"), executor, envelope,
                                               store.latest_telemetry_for_agent("agent-one"), {"action_safe": True},
                                               profile)
            return result, state["log"], clock.now - started

    def test_a_service_that_needs_six_seconds_is_kept_running(self):
        result, transitions, _ = self.run_start(6.0)
        self.assertTrue(result["success"], result["message"])
        self.assertEqual(transitions, ["running"])

    def test_a_service_that_never_becomes_healthy_is_still_rolled_back(self):
        result, transitions, elapsed = self.run_start(None)
        self.assertFalse(result["success"])
        self.assertTrue(result.get("rolled_back"))
        self.assertEqual(transitions, ["running", "stopped"])
        self.assertGreaterEqual(elapsed, 29)          # the whole 30 s window was used
        self.assertLess(elapsed, 45)


# ---------------------------------------------------------------- bug 9 ---

class AgentClockOffsetTests(unittest.TestCase):
    """Bug 9: controller-side freshness is judged on the agent's own clock, erring towards "older"."""

    def test_offset_errs_towards_older_samples(self):
        app, store, _, _ = controller()
        self.addCleanup(store.close)
        self.assertEqual(app.agent_clock_offset("agent-one"), 0.0)
        now = 5000.0
        # One-way request timestamps are lower bounds: delay only lowers them.
        app.note_agent_clock("agent-one", now + 30, now)
        app.note_agent_clock("agent-one", now + 1 - 100, now + 1)          # a request held back 130 s
        self.assertAlmostEqual(app.agent_clock_offset("agent-one", now + 2), 30.0)
        for bad in (float("nan"), float("inf"), now + 2 + 301):
            app.note_agent_clock("agent-one", bad, now + 2)
        self.assertAlmostEqual(app.agent_clock_offset("agent-one", now + 2), 30.0)
        # A lower bound that says "behind" is not trusted on its own.
        later = now + AGENT_CLOCK_WINDOW_SECONDS + 10
        app.note_agent_clock("agent-one", later - 120, later)
        self.assertEqual(app.agent_clock_offset("agent-one", later), 0.0)
        # The agent's round-trip report is an upper bound: it is used.
        app.note_agent_clock_bounds("agent-one", -120.2, -119.8, later)
        self.assertAlmostEqual(app.agent_clock_offset("agent-one", later), -119.8)
        self.assertAlmostEqual(app.agent_now("agent-one", later), later - 119.8)
        # Reports that are malformed, too wide or out of range are ignored,
        # and a report expires with the window.
        for low, high in ((1.0, 0.0), (-10.0, 70.0), (-400.0, -399.0), (float("nan"), 1.0)):
            app.note_agent_clock_bounds("agent-one", low, high, later + 1)
        self.assertAlmostEqual(app.agent_clock_offset("agent-one", later + 1), -119.8)
        self.assertEqual(app.agent_clock_offset("agent-one", later + AGENT_CLOCK_WINDOW_SECONDS + 1), 0.0)

    def test_evidence_that_disagrees_uses_the_larger_difference(self):
        app, store, _, _ = controller()
        self.addCleanup(store.close)
        now = 5000.0
        app.note_agent_clock_bounds("agent-one", -3.0, -1.0, now)
        app.note_agent_clock("agent-one", now + 20, now)                     # e.g. the clock just stepped forward
        self.assertAlmostEqual(app.agent_clock_offset("agent-one", now), 20.0)

    def test_provable_difference_is_reported_and_an_unclear_one_is_not(self):
        app, store, _, _ = controller()
        self.addCleanup(store.close)
        now = time.time()
        self.assertIsNone(app.agent_clock_differs("agent-one", now))
        app.note_agent_clock("agent-one", now - 50, now)                     # may just be a slow request
        self.assertIsNone(app.agent_clock_differs("agent-one", now))
        app.note_agent_clock_bounds("agent-one", -0.5, 6.0, now)            # a slow round trip: unclear
        self.assertIsNone(app.agent_clock_differs("agent-one", now))
        app.note_agent_clock_bounds("agent-one", -30.2, -29.8, now)
        self.assertAlmostEqual(app.agent_clock_differs("agent-one", now), -30.0)
        app.note_agent_clock("agent-one", now + 7, now)
        app.note_agent_clock_bounds("agent-one", 6.8, 7.2, now)
        self.assertAlmostEqual(app.agent_clock_differs("agent-one", now), 7.0)

    def test_restart_is_queued_for_an_agent_clock_ahead_or_behind(self):
        for skew in (30.0, 120.0, -120.0):
            with self.subTest(skew=skew):
                app, store, _, baseline = controller()
                self.addCleanup(store.close)
                now = time.time()
                if skew > 0:
                    app.note_agent_clock("agent-one", now + skew, now)
                else:
                    app.note_agent_clock_bounds("agent-one", skew - 0.2, skew + 0.2, now)
                outage(app, baseline, 2, time.time() + skew)
                self.assertEqual([row["status"] for row in recoveries(store)], ["queued"])

    def test_skew_does_not_make_a_stale_sample_fresh(self):
        app, store, _, baseline = controller()
        self.addCleanup(store.close)
        app.note_agent_clock("agent-one", time.time() + 30, time.time())
        outage(app, baseline, 2, time.time() + 30 - 120)          # 2 minutes old on the agent's clock
        self.assertEqual(recoveries(store), [])
        self.assertIn("fresh", app.service_recovery_planner.status()[0]["status"])

    def test_delayed_requests_cannot_make_a_stale_sample_fresh(self):
        # Review finding: every request arrives 200 s late while the clocks
        # agree. The one-way bound says "200 s behind"; that alone is not
        # trusted, and the agent's round trip includes the delay as well.
        for report in (None, (-0.1, 200.1)):
            with self.subTest(report=report):
                app, store, _, baseline = controller()
                self.addCleanup(store.close)
                now = time.time()
                app.note_agent_clock("agent-one", now - 200, now)
                if report:
                    app.note_agent_clock_bounds("agent-one", *report, now)
                outage(app, baseline, 2, now - 200)                     # collected 200 s ago
                self.assertEqual(recoveries(store), [])

    def test_signed_http_requests_and_continuity_measure_the_agent_clock(self):
        from sentinel_blue import offline_continuity as continuity_module
        from sentinel_blue.mutation_ledger import MutationLedger
        from sentinel_blue.offline_continuity import AgentContinuity, ControllerContinuity
        for skew in (30, -120):
            with self.subTest(skew=skew), tempfile.TemporaryDirectory() as temp:
                root = Path(temp)
                root.chmod(0o700)
                app, store, profile, baseline = controller()
                self.addCleanup(store.close)
                store.initialize_recovery_identity()
                app.continuity = ControllerContinuity(app)
                server = ControllerServer(("127.0.0.1", 0), make_handler(app))
                thread = threading.Thread(target=server.serve_forever, daemon=True)
                thread.start()
                self.addCleanup(server.server_close)
                self.addCleanup(server.shutdown)
                token = store.ensure_agent_secret("agent-one")
                client = AgentClient(f"http://127.0.0.1:{server.server_port}", "", "agent-one", agent_token=token,
                                     profile_id=profile.profile_id, profile_fingerprint=profile.fingerprint)
                shifted, real = skewed_time(skew), continuity_module.time
                request = client._request

                def exchange(*args, **kwargs):
                    continuity_module.time = real       # the controller thread answers on its own clock
                    try:
                        return request(*args, **kwargs)
                    finally:
                        continuity_module.time = shifted
                client._request = exchange
                with patch.object(agent_module, "time", shifted), patch.object(continuity_module, "time", shifted):
                    agent = AgentContinuity(root, profile, "agent-one", token, ledger=MutationLedger(root / "ledger"))
                    journal = ActionJournal(root / "journal", profile_fingerprint=profile.fingerprint)
                    agent.sync(client, journal)
                    agent.sync(client, journal)          # carries the bounds measured by the first sync
                    for sequence in (2, 3):
                        sample = stopped(baseline, sequence)
                        sample["observed_at"] = agent_module.time.time() - 0.5
                        client.telemetry(sample)
                    actions = client.actions()
                self.assertAlmostEqual(app.agent_clock_offset("agent-one"), skew, delta=2)
                self.assertGreaterEqual(app.agent_clock_offset("agent-one"), skew - 0.01)
                self.assertEqual([a["action_type"] for a in actions], ["restart_service"])
                validate_action_request(actions[0], expected_agent_id="agent-one", expected_profile_id=profile.profile_id,
                                        expected_profile_fingerprint=profile.fingerprint,
                                        expected_autonomy_mode=profile.autonomy_mode, require_binding=True,
                                        now=time.time() + skew)

    def test_post_crash_gate_places_the_sample_on_the_controller_clock(self):
        app, store, _, baseline = controller()
        self.addCleanup(store.close)
        app._recovery_fresh_after = time.time() - 5
        sample = stopped(baseline, 9)
        sample["observed_at"] = time.time() + 60 - 1               # collected after the restart, agent 60 s ahead
        app.ingest(sample)
        self.assertFalse(app._post_recovery_observation("agent-one"))
        app.note_agent_clock("agent-one", time.time() + 60, time.time())
        self.assertTrue(app._post_recovery_observation("agent-one"))
        before = stopped(baseline, 10)
        before["observed_at"] = time.time() + 60 - 30               # collected before the restart
        app.ingest(before)
        self.assertFalse(app._post_recovery_observation("agent-one"))


class SkewedContinuityTests(unittest.TestCase):
    """Bug 9: continuity takes online work from a skewed controller; offline authority still needs agreement."""

    def setUp(self):
        from test_offline_authority import OfflineAuthorityTests
        holder = OfflineAuthorityTests("run")
        holder.setUp()
        self.addCleanup(holder.doCleanups)
        self.f = holder

    def skewed_agent(self, skew, *, delay=0.0, agent=None):
        """An agent whose clock is `skew` s off; `delay` s pass (on its clock) while the controller answers."""
        from sentinel_blue import offline_continuity as module
        from sentinel_blue.offline_continuity import AgentContinuity
        f = self.f
        # Both clocks advance by `elapsed`; the agent's is also `skew` off.
        clock = self.__dict__.setdefault("_clock_state", {"elapsed": 0.0})   # continues across calls
        names = {name: getattr(time, name) for name in dir(time) if not name.startswith("__")}
        shifted = types.SimpleNamespace(**names)
        shifted.time = lambda: time.time() + skew + clock["elapsed"]
        shifted.monotonic = lambda: time.monotonic() + clock["elapsed"]
        controller_clock = types.SimpleNamespace(**names)
        controller_clock.time = lambda: time.time() + clock["elapsed"]
        patcher = patch.object(module, "time", shifted)
        patcher.start()
        self.addCleanup(patcher.stop)

        def controller_side(method, path, body):
            module.time = controller_clock         # the controller answers on its own clock
            try:
                return f.app.continuity.sync("agent-one", body)
            finally:
                module.time = shifted
                clock["elapsed"] += delay          # the reply takes `delay` seconds to arrive
        f.client._request.side_effect = controller_side
        if agent is None:
            directory = f.root / f"skewed-{skew}-{delay}"
            directory.mkdir(mode=0o700)
            agent = AgentContinuity(directory, f.profile, "agent-one", f.token, ledger=f.ledger)
        agent.sync(f.client, f.journal)
        agent.sync(f.client, f.journal)
        patcher.stop()
        return agent, shifted

    def test_skewed_agent_is_online_with_a_lease_on_its_own_clock_and_no_offline_policy(self):
        self.f.authorize()
        for skew in (30, -120):
            with self.subTest(skew=skew):
                agent, clock = self.skewed_agent(skew)
                self.assertTrue(agent.online, agent.status)
                self.assertAlmostEqual(agent.state["lease_until"] - clock.time(), 30, delta=3)
                self.assertIsNone(agent.state["policy"])
                self.assertIn("offline authority held", agent.status)
                low, high = agent.clock_bound
                self.assertTrue(low <= skew <= high and high - low < 1)
                # The second sync reported the first one's bounds.
                self.assertAlmostEqual(self.f.app.agent_clock_offset("agent-one"), skew, delta=1)

    def test_small_skew_keeps_offline_authority_and_large_skew_is_refused(self):
        self.f.authorize()
        agent, _ = self.skewed_agent(3)
        self.assertTrue(agent.online)
        self.assertIsNotNone(agent.state["policy"])
        with self.assertRaisesRegex(ValueError, "stale continuity"):
            self.skewed_agent(260)

    def test_a_slow_sync_keeps_the_policy_already_held_but_cannot_bring_a_new_one(self):
        # Review finding: on one clock a 6 s reply made the difference look
        # like 6 s and dropped a valid policy.
        f = self.f
        f.authorize()
        held = copy.deepcopy(f.agent.state["policy"])
        self.assertIsNotNone(held)
        agent, _ = self.skewed_agent(0, delay=6.0, agent=f.agent)
        self.assertTrue(agent.online, agent.status)
        self.assertEqual(agent.state["policy"], held)
        self.assertNotIn("offline authority held", agent.status)
        # A policy the agent does not already hold is not taken on an unclear clock ...
        agent.state["policy"] = None
        agent._save()
        agent, _ = self.skewed_agent(0, delay=6.0, agent=agent)
        self.assertIsNone(agent.state["policy"])
        # ... and a revocation always applies.
        agent, _ = self.skewed_agent(0, agent=agent)
        self.assertIsNotNone(agent.state["policy"])
        f.app.continuity.revoke()
        self.assertIsNotNone(agent.state["policy"])
        agent, _ = self.skewed_agent(0, delay=6.0, agent=agent)
        self.assertIsNone(agent.state["policy"])

    def test_a_clock_step_during_the_sync_is_refused(self):
        f = self.f
        f.authorize()
        from sentinel_blue import offline_continuity as module
        real = module.time
        shifted = types.SimpleNamespace(**{name: getattr(time, name) for name in dir(time) if not name.startswith("__")})
        step = {"wall": 0.0}
        shifted.time = lambda: time.time() + step["wall"]

        def controller_side(method, path, body):
            module.time = real
            try:
                return f.app.continuity.sync("agent-one", body)
            finally:
                module.time = shifted
                step["wall"] = 3.0                  # the wall clock jumps; monotonic time does not
        f.client._request.side_effect = controller_side
        with patch.object(module, "time", shifted), self.assertRaisesRegex(ValueError, "Clock changed"):
            f.agent.sync(f.client, f.journal)
        self.assertIsNone(f.agent.clock_bound)

    def test_a_small_backward_step_during_the_sync_is_refused_once_and_then_clears(self):
        # Review finding: a 0.3 s step back stored an inverted report that
        # the controller refused on every later sync.
        f = self.f
        from sentinel_blue import offline_continuity as module
        real = module.time
        state = {"wall": 0.0}
        shifted = types.SimpleNamespace(**{name: getattr(time, name) for name in dir(time) if not name.startswith("__")})
        shifted.time = lambda: time.time() + state["wall"]

        def controller_side(method, path, body):
            module.time = real
            try:
                return f.app.continuity.sync("agent-one", body)
            finally:
                module.time = shifted
                if state.get("step"):
                    state["wall"] -= state.pop("step")
        f.client._request.side_effect = controller_side
        with patch.object(module, "time", shifted):
            state["step"] = 0.3
            with self.assertRaisesRegex(ValueError, "Clock changed"):
                f.agent.sync(f.client, f.journal)
            self.assertIsNone(f.agent.clock_bound)
            for _ in range(2):
                f.agent.sync(f.client, f.journal)
                self.assertTrue(f.agent.online, f.agent.status)
            low, high = f.agent.clock_bound
            self.assertLessEqual(low, high)

    def test_slow_local_preparation_is_not_a_clock_change(self):
        f = self.f
        f.authorize()
        from sentinel_blue import offline_continuity as module
        state = {"elapsed": 0.0}
        shifted = types.SimpleNamespace(**{name: getattr(time, name) for name in dir(time) if not name.startswith("__")})
        shifted.time = lambda: time.time() + state["elapsed"]
        shifted.monotonic = lambda: time.monotonic() + state["elapsed"]
        head = f.agent.ledger.head

        def slow_head():
            state["elapsed"] += 2.0                 # e.g. another process held the host ledger
            return head()
        with patch.object(module, "time", shifted), patch.object(f.agent.ledger, "head", side_effect=slow_head):
            f.client._request.side_effect = lambda method, path, body: f.app.continuity.sync("agent-one", body)
            f.agent.sync(f.client, f.journal)
        self.assertTrue(f.agent.online, f.agent.status)
        self.assertIsNotNone(f.agent.state["policy"])

    def test_controller_ignores_an_unusable_clock_report(self):
        f = self.f
        f.agent.clock_bound = [1.0, 0.0]
        f.agent.sync(f.client, f.journal)
        self.assertTrue(f.agent.online, f.agent.status)
        self.assertEqual(f.app.agent_clock_offset("agent-one"), 0.0)

    def test_controller_refuses_offline_authorization_for_a_skewed_agent(self):
        f = self.f
        f.app.note_agent_clock_bounds("agent-one", -45.3, -44.9)
        with self.assertRaisesRegex(ValueError, "agreement within 5 s"):
            f.authorize()


# --------------------------------------------------------------- bug 11 ---

class ReconciledRecoveryTests(unittest.TestCase):
    """Bug 11: an executed reconcile no longer blocks later automatic restarts."""

    def unknown_restart(self):
        app, store, profile, baseline = controller()
        self.addCleanup(store.close)
        t0 = time.time()
        with patch("time.time", return_value=t0):
            outage(app, baseline, 2, t0)
            store.pending_actions("agent-one")
        with patch("time.time", return_value=t0 + 400):
            store.pending_actions("agent-one")
        (row,) = recoveries(store)
        self.assertEqual(row["status"], "outcome_unknown")
        return app, store, baseline, row, t0

    def alert(self, store, alert_id):
        return dict(store._connection.execute("SELECT status, decision FROM alerts WHERE alert_id=?",
                                              (alert_id,)).fetchone())

    def test_executed_reconcile_closes_the_alert_and_a_later_outage_restarts(self):
        app, store, baseline, row, t0 = self.unknown_restart()
        result = app.reconcile_action_outcome(row["action_id"], "executed")
        self.assertTrue(result["alert_closed"])
        self.assertEqual(self.alert(store, row["alert_id"]), {"status": "decided", "decision": "automatic_service_recovery"})
        t1 = t0 + 7200
        with patch("time.time", return_value=t1):
            outage(app, baseline, 10, t1)
        rows = recoveries(store)
        self.assertEqual([r["status"] for r in rows], ["reconciled", "queued"])
        self.assertNotEqual(rows[1]["alert_id"], row["alert_id"])

    def test_alert_left_open_by_an_earlier_release_is_closed_on_the_next_outage(self):
        app, store, baseline, row, t0 = self.unknown_restart()
        app.reconcile_action_outcome(row["action_id"], "executed")
        # How a 2.0.16 reconcile left it: the alert stayed open.
        store._connection.execute("UPDATE alerts SET status='open', decision=NULL, decided_at=NULL WHERE alert_id=?",
                                  (row["alert_id"],))
        store._connection.commit()
        t1 = t0 + 7200
        with patch("time.time", return_value=t1):
            outage(app, baseline, 10, t1)                # closes the alert the old reconcile left open
        with patch("time.time", return_value=t1 + 30):
            outage(app, baseline, 20, t1 + 30)           # a new alert and a new restart
        self.assertEqual(self.alert(store, row["alert_id"])["status"], "decided")
        self.assertEqual([r["status"] for r in recoveries(store)], ["reconciled", "queued"])
        audit = store._connection.execute(
            "SELECT COUNT(*) FROM audit_log WHERE operation='close_alert_of_reconciled_recovery'").fetchone()[0]
        self.assertEqual(audit, 1)

    def test_corrupt_parameters_are_quarantined_under_the_action_and_the_alert_stays_open(self):
        app, store, baseline, row, t0 = self.unknown_restart()
        store._connection.execute("UPDATE actions SET parameters_json='{broken' WHERE action_id=?", (row["action_id"],))
        store._connection.commit()
        result = app.reconcile_action_outcome(row["action_id"], "executed")
        self.assertFalse(result["alert_closed"])
        self.assertEqual(self.alert(store, row["alert_id"])["status"], "open")
        keys = [r[0] for r in store._connection.execute("SELECT row_key FROM json_quarantine WHERE table_name='actions'")]
        self.assertEqual(keys, [row["action_id"]])
        status = store._connection.execute("SELECT status FROM actions WHERE action_id=?", (row["action_id"],)).fetchone()[0]
        self.assertEqual(status, "outcome_unknown")

    def test_not_executed_reconcile_is_unchanged(self):
        app, store, baseline, row, t0 = self.unknown_restart()
        result = app.reconcile_action_outcome(row["action_id"], "not_executed")
        self.assertFalse(result.get("alert_closed", False))
        self.assertEqual(self.alert(store, row["alert_id"])["status"], "open")


if __name__ == "__main__":
    unittest.main()
