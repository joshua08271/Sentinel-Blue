"""Retention protects evidence and cannot strand maintenance in a transaction."""
from contextlib import closing
import sqlite3
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import test_baseline_promotion as promotion
import test_session_alert_continuity as continuity
from sentinel_blue.controller import maintenance_loop
from sentinel_blue.protocol import AlertCandidate
from sentinel_blue.recovery_ops import verify_controller_backup
from sentinel_blue.store import Store


DAY = 86400


def add_alert(store, name, *, closed=True):
    alert_id = store.add_alert(
        "retention-host",
        AlertCandidate("retention-fixture", name, name, "info", 0.5,
                       {"fixture": name}, "Review fixture", "observe"),
    )
    if closed:
        store.decide_alert(alert_id, "observe")
    return alert_id


def row_ids(store, table, column):
    return {row[0] for row in store._connection.execute(
        f"SELECT {column} FROM {table}"
    )}


def run_cycles(app, times, *, backups="unused-backups"):
    clock = SimpleNamespace(index=0)
    stop = MagicMock()
    stop.is_set.side_effect = lambda: clock.index >= len(times)
    stop.wait.side_effect = lambda _: setattr(clock, "index", clock.index + 1)
    with patch("sentinel_blue.controller.time.time",
               side_effect=lambda: times[min(clock.index, len(times) - 1)]):
        maintenance_loop(app, 90, 30, backups, 3600, 3, 5, stop)
    return stop


def maintenance_app():
    return SimpleNamespace(
        store=MagicMock(), resume_pending_telemetry=MagicMock(),
        monitor_stale_agents=MagicMock(), create_recovery_backup=MagicMock(),
        recovery_key=b"fixture-key", recovery_anchor=Path("unused-anchor"),
        maintenance_heartbeat=0.0,
        # Scheduled-backup health reporting; the loop calls these every cycle.
        record_backup_outcome=MagicMock(), monitor_backup_health=MagicMock(),
    )


class RetentionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.store = Store(self.root / "retention.db")
        self.store.register_agent("retention-host", "fixture", "Linux")

    def tearDown(self):
        self.store.close()
        self.temp.cleanup()

    def test_linked_alert_and_learning_evidence_survive_pruning_and_backup(self):
        fixture = continuity.SessionAlertContinuityTests()
        fixture.setUp()
        self.addCleanup(fixture.tearDown)
        fixture.ingest(fixture.sample(1, [fixture.session(201)]))
        alert = fixture.session_alerts()[0]
        lineage = fixture.store.alert_learning_lineage(alert["alert_id"])
        fixture.store.decide_alert_with_learning_label(
            alert["alert_id"], "observe", 0,
            occurrence_id=lineage["creation_occurrence_id"],
            reviewer_principal_id="retention-reviewer", label_source="unit-test",
        )
        disposable = add_alert(fixture.store, "old-unlinked")
        tables = ("telemetry_observations", "alert_occurrences",
                  "alert_lineage", "learning_labels")
        before = {
            table: [tuple(row) for row in fixture.store._connection.execute(
                f"SELECT * FROM {table} ORDER BY 1")]
            for table in tables
        }
        self.assertEqual(len(before["learning_labels"]), 1)
        with patch("sentinel_blue.store.time.time",
                   return_value=time.time() + 31 * DAY):
            result = fixture.store.prune(30)
        self.assertEqual(result["alerts"], 1)
        self.assertIsNone(fixture.store.get_alert(disposable))
        self.assertIsNotNone(fixture.store.get_alert(alert["alert_id"]))
        for table in tables:
            after = [tuple(row) for row in fixture.store._connection.execute(
                f"SELECT * FROM {table} ORDER BY 1")]
            self.assertEqual(after, before[table], table)
        self.assertFalse(fixture.store._connection.in_transaction)
        self.assertEqual(fixture.store._connection.execute(
            "PRAGMA foreign_key_check").fetchall(), [])
        backups = fixture.root / "retention-backups"
        backups.mkdir(mode=0o700)
        saved = fixture.app.create_recovery_backup(backups)
        verified = verify_controller_backup(saved["bundle"], fixture.anchor, fixture.key)
        self.assertTrue(verified["verified"])
        with closing(sqlite3.connect(Path(saved["bundle"]) / "controller.db")) as database:
            self.assertEqual(database.execute(
                "SELECT COUNT(*) FROM learning_labels").fetchone()[0], 1)

    def test_baseline_capture_receipt_is_retained_after_expiry(self):
        fixture = promotion.BaselinePromotionTests()
        fixture.setUp()
        self.addCleanup(fixture.tearDown)
        sample, approval, action = fixture._begin()
        fixture.app.complete_action(promotion.capture_result(action), "promotion-agent")
        before = fixture.store.latest_baseline_promotion("promotion-agent")
        with patch("sentinel_blue.store.time.time",
                   return_value=time.time() + 31 * DAY):
            fixture.store.prune(30)
        self.assertEqual(fixture.store.latest_baseline_promotion("promotion-agent"), before)
        self.assertIsNotNone(fixture.store.get_action(action.action_id))
        self.assertEqual(fixture.store.get_baseline("promotion-agent"), sample)
        self.assertEqual(fixture.store.baseline_status("promotion-agent"), "approved")
        self.assertEqual(fixture.store._connection.execute(
            "PRAGMA foreign_key_check").fetchall(), [])

    def test_only_old_unreferenced_closed_records_expire(self):
        old = time.time() - 40 * DAY
        with patch("sentinel_blue.store.time.time", return_value=old):
            disposable = add_alert(self.store, "disposable")
            undecided = add_alert(self.store, "open", closed=False)
            recent_decision = add_alert(self.store, "recent-decision", closed=False)
            recent_observation = add_alert(self.store, "recent-observation")
            active_parent = add_alert(self.store, "active-action-parent", closed=False)
            active_action = self.store.queue_action(
                "retention-host", "observe", {}, alert_id=active_parent)
            self.store.decide_alert(active_parent, "observe")
            finished_parent = add_alert(self.store, "finished-parent", closed=False)
            finished_action = self.store.queue_action(
                "retention-host", "observe", {}, alert_id=finished_parent)
            self.store.decide_alert(finished_parent, "observe")
            recent_parent = add_alert(self.store, "recent-completion-parent", closed=False)
            recent_action = self.store.queue_action(
                "retention-host", "observe", {}, alert_id=recent_parent)
            self.store.decide_alert(recent_parent, "observe")
        self.store.decide_alert(recent_decision, "observe")
        self.store._connection.execute(
            "UPDATE alerts SET last_observed_at=? WHERE alert_id=?",
            (time.time(), recent_observation),
        )
        for action_id, completed_at in (
            (finished_action, old + 1), (recent_action, time.time())
        ):
            self.store._connection.execute(
                "UPDATE actions SET status='completed', completed_at=? WHERE action_id=?",
                (completed_at, action_id),
            )
        self.store._connection.commit()
        result = self.store.prune(30)
        self.assertEqual(result["alerts"], 2)
        self.assertEqual(result["actions"], 1)
        self.assertEqual(row_ids(self.store, "alerts", "alert_id"),
                         {undecided, recent_decision, recent_observation,
                          active_parent, recent_parent})
        self.assertEqual(row_ids(self.store, "actions", "action_id"),
                         {active_action, recent_action})
        self.assertNotIn(disposable, row_ids(self.store, "alerts", "alert_id"))
        self.assertFalse(self.store._connection.in_transaction)
        repeated = self.store.prune(30)
        self.assertEqual(repeated["alerts"], 0)
        self.assertEqual(repeated["actions"], 0)

    def test_failed_prune_rolls_back_all_deletions_and_allows_new_work(self):
        with patch("sentinel_blue.store.time.time",
                   return_value=time.time() - 40 * DAY):
            alert = add_alert(self.store, "rollback")
            event = self.store.add_external_event("fixture", "old event", "info")
        with patch.object(self.store, "_prune_resolved_quarantine_locked",
                          side_effect=sqlite3.OperationalError("fixture storage failure")):
            with self.assertRaisesRegex(sqlite3.OperationalError, "fixture storage failure"):
                self.store.prune(30)
        self.assertFalse(self.store._connection.in_transaction)
        self.assertIsNotNone(self.store.get_alert(alert))
        self.assertIn(event, row_ids(self.store, "external_events", "event_id"))
        add_alert(self.store, "work-after-failure")
        backup = self.store.backup(self.root / "after-failure.db")
        with closing(sqlite3.connect(backup)) as database:
            self.assertEqual(database.execute("PRAGMA integrity_check").fetchone()[0], "ok")
            self.assertEqual(database.execute(
                "SELECT COUNT(*) FROM external_events WHERE event_id=?", (event,)
            ).fetchone()[0], 1)

    def test_interruption_also_rolls_back(self):
        with patch("sentinel_blue.store.time.time",
                   return_value=time.time() - 40 * DAY):
            alert = add_alert(self.store, "interrupt")
        with patch.object(self.store, "_prune_resolved_quarantine_locked",
                          side_effect=KeyboardInterrupt):
            with self.assertRaises(KeyboardInterrupt):
                self.store.prune(30)
        self.assertFalse(self.store._connection.in_transaction)
        self.assertIsNotNone(self.store.get_alert(alert))

    def test_nested_prune_neither_commits_nor_rolls_back_caller_work(self):
        self.store._connection.execute("BEGIN IMMEDIATE")
        self.store._connection.execute(
            "INSERT INTO external_events VALUES('pending','fixture','pending','info',0)")
        with self.assertRaises(sqlite3.OperationalError):
            self.store.prune(30)
        self.assertTrue(self.store._connection.in_transaction)
        self.assertIn("pending", row_ids(self.store, "external_events", "event_id"))
        self.store._connection.rollback()
        self.assertNotIn("pending", row_ids(self.store, "external_events", "event_id"))


class MaintenanceRetentionTests(unittest.TestCase):
    def test_failed_real_cleanup_still_produces_verified_backup(self):
        fixture = continuity.SessionAlertContinuityTests()
        fixture.setUp()
        self.addCleanup(fixture.tearDown)
        backups = fixture.root / "maintenance-backups"
        backups.mkdir(mode=0o700)
        # Keep this regression about storage and housekeeping, not host liveness.
        with patch.object(fixture.app, "resume_pending_telemetry"), patch.object(
            fixture.app, "monitor_stale_agents"
        ), patch.object(fixture.store, "mark_stale_dispatched_actions"), patch.object(
            fixture.store, "_prune_resolved_quarantine_locked",
            side_effect=sqlite3.OperationalError("fixture cleanup failure"),
        ), self.assertLogs("sentinel_blue.controller", level="ERROR") as logs:
            run_cycles(fixture.app, [time.time()], backups=str(backups))
        bundles = list(backups.glob("*.sbbackup"))
        self.assertEqual(len(bundles), 1)
        self.assertTrue(verify_controller_backup(
            bundles[0], fixture.anchor, fixture.key)["verified"])
        self.assertFalse(fixture.store._connection.in_transaction)
        self.assertGreater(fixture.app.maintenance_heartbeat, 0)
        self.assertTrue(any("retention cleanup failed" in row for row in logs.output))

    def test_failed_cleanup_retries_after_backoff_and_does_not_block_progress(self):
        app = maintenance_app()
        app.store.prune.side_effect = sqlite3.OperationalError("fixture cleanup failure")
        with patch("sentinel_blue.recovery_ops.prune_recovery_backups"), self.assertLogs(
            "sentinel_blue.controller", level="ERROR"
        ):
            run_cycles(app, [10000, 10005, 10065])
        self.assertEqual(app.store.prune.call_count, 2)
        self.assertEqual(app.resume_pending_telemetry.call_count, 3)
        app.create_recovery_backup.assert_called_once()
        self.assertGreater(app.maintenance_heartbeat, 0)

    def test_successful_cleanup_retains_hourly_schedule(self):
        app = maintenance_app()
        with patch("sentinel_blue.recovery_ops.prune_recovery_backups"):
            run_cycles(app, [10000, 10065, 13600])
        self.assertEqual(app.store.prune.call_count, 2)
        self.assertEqual(app.create_recovery_backup.call_count, 2)

    def test_backup_cleanup_failure_does_not_create_duplicate_new_backups(self):
        app = maintenance_app()
        with patch("sentinel_blue.recovery_ops.prune_recovery_backups",
                   side_effect=OSError("fixture backup cleanup failure")), self.assertLogs(
            "sentinel_blue.controller", level="ERROR"
        ):
            run_cycles(app, [10000, 10005])
        app.create_recovery_backup.assert_called_once()
        self.assertGreater(app.maintenance_heartbeat, 0)

    def test_backup_creation_failure_is_visible_without_stopping_core_progress(self):
        app = maintenance_app()
        app.create_recovery_backup.side_effect = OSError("fixture backup write failure")
        with self.assertLogs("sentinel_blue.controller", level="ERROR") as logs:
            run_cycles(app, [10000])
        app.store.prune.assert_called_once()
        self.assertGreater(app.maintenance_heartbeat, 0)
        self.assertTrue(any("backup maintenance failed" in row for row in logs.output))

    def test_core_failure_still_withholds_maintenance_heartbeat(self):
        app = maintenance_app()
        app.resume_pending_telemetry.side_effect = RuntimeError("fixture core failure")
        with self.assertLogs("sentinel_blue.controller", level="ERROR"):
            run_cycles(app, [10000])
        self.assertEqual(app.maintenance_heartbeat, 0)
        app.create_recovery_backup.assert_not_called()


if __name__ == "__main__":
    unittest.main()
