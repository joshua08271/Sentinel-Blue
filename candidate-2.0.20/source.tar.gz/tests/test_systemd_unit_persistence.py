"""Timer, socket and path unit persistence (issue #16, Linux).

A .timer, .socket or .path unit starts its payload without ever being a
.service, so removing only the unit file left systemd still holding the loaded,
enabled unit. These targets are stopped and disabled natively first, exactly as a
service unit is, and restored the same way.
"""
import os
import shutil
import tempfile
import unittest
from pathlib import Path

from sentinel_blue.persistence_security import (
    PersistenceRemediator, SYSTEMD_KINDS, fingerprint, validate_target)
from sentinel_blue.security_native import NativeSecurityBackend


UNIT_FILE = (b"[Unit]\nDescription=team maintenance\n\n"
             b"[Timer]\nOnCalendar=*-*-* *:00:00\nUnit=maintenance.service\n\n"
             b"[Install]\nWantedBy=timers.target\n")


class SystemdUnitValidationTests(unittest.TestCase):
    def target(self, unit, path=None):
        return {'kind': 'systemd-unit', 'path': path or f'/etc/systemd/system/{unit}', 'unit': unit}

    def test_activation_units_are_accepted(self):
        for unit in ('evil.timer', 'backdoor.socket', 'watcher.path', 'user@.timer', 'a-b_c.socket'):
            with self.subTest(unit=unit):
                self.assertEqual(validate_target(self.target(unit))['unit'], unit)

    def test_service_units_keep_their_own_kind(self):
        with self.assertRaises(ValueError):
            validate_target(self.target('evil.service'))
        service = {'kind': 'systemd-service', 'path': '/etc/systemd/system/evil.service',
                   'service': 'evil.service'}
        self.assertEqual(validate_target(service)['service'], 'evil.service')

    def test_unsafe_unit_names_are_refused(self):
        for unit in ('evil', 'evil.timer;rm -rf /', '../evil.timer', 'evil.timer\n', '', 'evil.mount'):
            with self.subTest(unit=unit), self.assertRaises(ValueError):
                validate_target(self.target(unit))

    def test_unexpected_fields_are_refused(self):
        with self.assertRaises(ValueError):
            validate_target({**self.target('evil.timer'), 'service': 'evil.service'})

    def test_both_systemd_kinds_are_recognized_together(self):
        self.assertEqual(set(SYSTEMD_KINDS), {'systemd-service', 'systemd-unit'})


class _StubNative:
    """Records the native sequence; systemd itself is not available in tests."""

    def __init__(self, state=None):
        self.calls = []
        self.state = state or {'FragmentPath': None, 'ActiveState': 'active', 'UnitFileState': 'enabled'}
        self.absent = False

    def persistence_snapshot(self, target):
        self.calls.append(('snapshot', NativeSecurityBackend._unit_name(target)))
        return dict(self.state)

    def persistence_remove(self, target, expected):
        self.calls.append(('remove', NativeSecurityBackend._unit_name(target), expected['UnitFileState']))
        self.absent = True

    def persistence_absent(self, target):
        self.calls.append(('absent', NativeSecurityBackend._unit_name(target)))
        return self.absent

    def persistence_restore(self, target, before):
        self.calls.append(('restore', NativeSecurityBackend._unit_name(target), before['ActiveState']))
        self.absent = False

    def reload_systemd(self):
        self.calls.append(('reload',))


@unittest.skipIf(os.name == 'nt', 'POSIX unit files')
class SystemdUnitRemediationTests(unittest.TestCase):
    def setUp(self):
        self.state = Path(tempfile.mkdtemp(prefix='sentinel-unit-state-'))
        self.addCleanup(shutil.rmtree, self.state, True)
        os.chmod(self.state, 0o700)
        self.host = Path(tempfile.mkdtemp(prefix='sentinel-unit-host-'))
        self.addCleanup(shutil.rmtree, self.host, True)
        self.unit_file = self.host / 'evil.timer'
        self.unit_file.write_bytes(UNIT_FILE)
        self.native = _StubNative()
        self.remediator = PersistenceRemediator(self.state, native=self.native)
        self.addCleanup(self.remediator.close)
        self.target = {'kind': 'systemd-unit', 'path': str(self.unit_file), 'unit': 'evil.timer'}

    def test_the_unit_is_stopped_before_its_file_is_removed(self):
        snapshot = self.remediator.snapshot(self.target)
        result = self.remediator.remove(self.target, fingerprint(snapshot), operation_id='unit-op-0001')
        self.assertEqual(result['status'], 'quarantined')
        self.assertFalse(self.unit_file.exists(), 'the unit file is removed')
        order = [call[0] for call in self.native.calls]
        self.assertLess(order.index('remove'), order.index('reload'),
                        'systemd must stop and disable the unit before the daemon reload')
        self.assertIn(('remove', 'evil.timer', 'enabled'), self.native.calls)
        self.assertIn(('reload',), self.native.calls)

    def test_quarantine_is_only_confirmed_when_systemd_agrees(self):
        self.native.absent = False

        class StubbornNative(_StubNative):
            def persistence_remove(self, target, expected):
                self.calls.append(('remove', 'evil.timer', expected['UnitFileState']))
                self.absent = False  # systemd still holds the unit

        self.native = StubbornNative()
        self.remediator.native = self.native
        snapshot = self.remediator.snapshot(self.target)
        result = self.remediator.remove(self.target, fingerprint(snapshot), operation_id='unit-op-0002')
        self.assertEqual(result['status'], 'uncertain')
        self.assertTrue(result['review_required'])

    def test_removal_is_refused_when_the_unit_file_changed_after_review(self):
        snapshot = self.remediator.snapshot(self.target)
        digest = fingerprint(snapshot)
        self.unit_file.write_bytes(UNIT_FILE + b'# edited by a teammate\n')
        with self.assertRaises(ValueError):
            self.remediator.remove(self.target, digest, operation_id='unit-op-0003')
        self.assertTrue(self.unit_file.exists())

    def test_restore_puts_the_unit_file_back(self):
        snapshot = self.remediator.snapshot(self.target)
        self.remediator.remove(self.target, fingerprint(snapshot), operation_id='unit-op-0004')
        self.assertFalse(self.unit_file.exists())
        restored = self.remediator.restore('unit-op-0004')
        self.assertEqual(restored['status'], 'restored')
        self.assertEqual(self.unit_file.read_bytes(), UNIT_FILE)

    def test_a_socket_unit_uses_the_same_path(self):
        socket_file = self.host / 'backdoor.socket'
        socket_file.write_bytes(b'[Socket]\nListenStream=4444\n')
        target = {'kind': 'systemd-unit', 'path': str(socket_file), 'unit': 'backdoor.socket'}
        snapshot = self.remediator.snapshot(target)
        result = self.remediator.remove(target, fingerprint(snapshot), operation_id='unit-op-0005')
        self.assertEqual(result['status'], 'quarantined')
        self.assertIn(('remove', 'backdoor.socket', 'enabled'), self.native.calls)


class NativeUnitNameTests(unittest.TestCase):
    def test_each_kind_reports_its_own_unit_field(self):
        self.assertEqual(NativeSecurityBackend._unit_name(
            {'kind': 'systemd-service', 'service': 'a.service'}), 'a.service')
        self.assertEqual(NativeSecurityBackend._unit_name(
            {'kind': 'systemd-unit', 'unit': 'a.timer'}), 'a.timer')


if __name__ == '__main__':
    unittest.main()
