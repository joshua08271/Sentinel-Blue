import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from sentinel_blue.launcher import DeploymentStep, _deploy_winrm


class WinRMCredentialFileTests(unittest.TestCase):
    def deploy(self, root, credential):
        (root/'profile.json').write_text('{"fixture":true}')
        (root/'ca.crt').write_text('fixture public trust anchor')
        step = DeploymentStep('windows', '192.0.2.10', 'windows', 'winrm', 'install-agent', [],
                              {'credential_file': str(credential), 'agent_id': 'windows'})
        with patch('sentinel_blue.launcher._powershell_executable', return_value='powershell.exe'), \
             patch('sentinel_blue.launcher._validated_probe_config', return_value=None), \
             patch('sentinel_blue.launcher._validated_event_profile', return_value=root/'profile.json'), \
             patch('sentinel_blue.launcher._validated_controller_ca', return_value=root/'ca.crt'), \
             patch('sentinel_blue.launcher._run', return_value='') as command:
            result = _deploy_winrm(step, root/'sentinel-blue.pyz', 'a'*64,
                                   'https://192.0.2.11:8765', 'fixture-only-token', ['192.0.2.0/24'])
            return result, command.call_args.args[0]

    def test_utf16_exported_credentials_reach_native_import_unchanged(self):
        # A benign serialized object is enough to exercise file validation.
        # Native credential decryption remains Import-Clixml's responsibility.
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            credential = root/'credential.xml'
            data = '<Objs Version="1.1.0.1" xmlns="http://schemas.microsoft.com/powershell/2004/01" />'.encode('utf-16')
            credential.write_bytes(data)
            result, command = self.deploy(root, credential)
            self.assertEqual(result['status'], 'deployed')
            self.assertEqual(credential.read_bytes(), data)
            import base64
            script = base64.b64decode(command[-1]).decode('utf-16le')
            self.assertIn('Import-Clixml -LiteralPath', script)
            self.assertIn(str(credential), script)

    def test_oversized_credentials_are_rejected_before_remote_execution(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            credential = root/'credential.xml'
            credential.write_bytes(b'x'*65537)
            with self.assertRaisesRegex(ValueError, 'size limit'):
                self.deploy(root, credential)

    def test_symlink_credentials_are_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            target = root/'original.xml'; target.write_bytes(b'<Objs/>')
            link = root/'credential.xml'
            try:
                link.symlink_to(target)
            except OSError:
                self.skipTest('symlink creation is unavailable')
            with self.assertRaisesRegex(ValueError, 'non-symlink'):
                self.deploy(root, link)
