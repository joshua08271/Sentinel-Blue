"""Boot registrations written before ledger pinning must still start."""
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch

from sentinel_blue import controller_boot


SCHEMA2 = {
    'schema': 2, 'runtime': '/private/sentinel-blue.pyz', 'config': '/private/controller-config.json',
    'ledger_directory': '/private/ledger', 'python': ['/usr/bin/python3'],
    'arguments': ['--event-profile', '/private/profile.json'], 'files': {'/private/profile.json': 'a' * 64},
    'profile_fingerprint': 'b' * 64,
}


def _legacy(value):
    legacy = {key: item for key, item in value.items() if key != 'ledger_directory'}
    legacy['schema'] = 1
    return legacy


class ControllerBootBindingCompatibilityTests(unittest.TestCase):
    def _run(self, saved, *, ledger_directory, current=None, paused=False):
        """Run controller-boot-run against a saved registration receipt."""
        calls = []
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            root.chmod(0o700)
            config = root / 'controller-config.json'
            config.write_text('{}')
            config.chmod(0o600)
            receipt = root / 'controller-boot-binding.json'
            receipt.write_text(json.dumps(saved))
            receipt.chmod(0o600)
            produced = dict(current or SCHEMA2)

            def fake_binding(_config, _runtime, *, ledger_directory=None):
                return {**produced, 'ledger_directory': str(ledger_directory)}

            ledger = types.SimpleNamespace(paused=lambda: paused)
            args = types.SimpleNamespace(command='controller-boot-run', config=str(config),
                                         runtime=SCHEMA2['runtime'], ledger_directory=ledger_directory)
            with patch.object(controller_boot, 'binding', fake_binding), \
                 patch('sentinel_blue.mutation_ledger.MutationLedger', return_value=ledger), \
                 patch('sentinel_blue.mutation_ledger.default_directory', return_value='/private/ledger'), \
                 patch.object(controller_boot.subprocess, 'call',
                              lambda command, env=None: calls.append((command, env)) or 0):
                return controller_boot.run(args), calls

    def test_legacy_registration_without_pinned_ledger_still_boots(self):
        # The pre-pinning startup command passes no --ledger-directory at all.
        code, calls = self._run(_legacy(SCHEMA2), ledger_directory=None)
        self.assertEqual(code, 0)
        self.assertEqual(len(calls), 1)
        command, environment = calls[0]
        self.assertEqual(command[:3], ['/usr/bin/python3', SCHEMA2['runtime'], 'controller'])
        self.assertEqual(environment['SENTINEL_LEDGER_DIR'], '/private/ledger')

    def test_legacy_registration_still_refuses_changed_inputs(self):
        changed = {**SCHEMA2, 'arguments': ['--event-profile', '/private/other.json']}
        with self.assertRaises(ValueError) as error:
            self._run(_legacy(SCHEMA2), ledger_directory=None, current=changed)
        self.assertIn('reviewed rebinding', str(error.exception))

    def test_legacy_registration_still_respects_withdraw(self):
        with self.assertRaises(ValueError) as error:
            self._run(_legacy(SCHEMA2), ledger_directory=None, paused=True)
        self.assertIn('Withdraw', str(error.exception))

    def test_pinned_registration_requires_its_exact_ledger(self):
        with self.assertRaises(ValueError) as error:
            self._run(SCHEMA2, ledger_directory=None)
        self.assertIn('--ledger-directory', str(error.exception))
        code, calls = self._run(SCHEMA2, ledger_directory='/private/ledger')
        self.assertEqual((code, len(calls)), (0, 1))
        with self.assertRaises(ValueError):
            self._run(SCHEMA2, ledger_directory='/private/other-ledger')

    def test_relative_and_unknown_schema_are_refused(self):
        with self.assertRaises(ValueError):
            self._run(SCHEMA2, ledger_directory='private/ledger')
        with self.assertRaises(ValueError) as error:
            self._run({**SCHEMA2, 'schema': 3}, ledger_directory='/private/ledger')
        self.assertIn('Unsupported controller boot binding', str(error.exception))


if __name__ == '__main__':
    unittest.main()
