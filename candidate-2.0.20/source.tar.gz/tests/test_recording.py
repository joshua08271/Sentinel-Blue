"""Real process, disk, HTTP, privacy and evidence-integrity regression checks."""
import http.server
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch
import zipfile
from sentinel_blue import recording
from sentinel_blue.recording import Recorder, inspect_bundle, sanitize, make_session_bundle

class RecordingTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.recorders = []
    def tearDown(self):
        for recorder in self.recorders: recorder.close()
        self.temp.cleanup()
    def recorder(self, name='evidence', **kw):
        recorder = Recorder(self.root/name, background=False, free_floor=0, **kw)
        self.recorders.append(recorder)
        return recorder
    def test_start_stop_and_explicit_restart(self):
        r=self.recorder(); first=r.start()['session_id']
        r.emit('test',{'status':'passed'})
        self.assertEqual(r.start()['session_id'],first)
        r.stop();r.close(); reopened=self.recorder()
        self.assertEqual(reopened.status()['state'],'stopped')
        self.assertFalse(reopened.emit('should_not_appear'))
        self.assertNotEqual(reopened.start()['session_id'],first)
    def test_automatic_snapshots_are_shared_and_stop_forces_current_evidence(self):
        first=self.recorder();first.emit('first_sample',{'state':'observed'})
        path=first.export(automatic=True);original=path.read_bytes()
        second=self.recorder();second.emit('later_sample',{'state':'observed'})
        self.assertEqual(second.export(automatic=True).read_bytes(),original)
        self.assertGreater(second.status()['events'],inspect_bundle(path)['events'])
        third=self.recorder();third.emit('short_worker_result',{'status':'passed'});third.close()
        self.assertEqual(path.read_bytes(),original)
        with first.connection:
            first.connection.execute('UPDATE snapshot_schedule SET finished=?,duration=?',
                (recording.time.time()-61,20))
        self.assertEqual(second.export(automatic=True).read_bytes(),original)
        with first.connection:
            first.connection.execute('UPDATE snapshot_schedule SET finished=?',(recording.time.time()-181,))
        self.assertEqual(inspect_bundle(second.export(automatic=True))['event_counts']['later_sample'],1)
        first.emit('at_stop',{'state':'observed'});first.stop()
        final=inspect_bundle(second.export(automatic=True))
        self.assertEqual(final['event_counts']['at_stop'],1)
        self.assertEqual(final['event_counts']['short_worker_result'],1)
        self.assertIsNotNone(final['stopped_at'])
    def test_actual_process_crash_keeps_committed_events(self):
        directory=self.root/'child'
        code=('import os,sys;sys.path.insert(0,sys.argv[2]);from sentinel_blue.recording import Recorder;'
              'r=Recorder(sys.argv[1],background=False,free_floor=0);'
              'r.emit("before_crash",{"status":"committed"});os._exit(7)')
        module_root=str(Path(recording.__file__).parents[1])
        if '.pyz' in recording.__file__: module_root=recording.__file__.split('.pyz')[0]+'.pyz'
        result=subprocess.run([sys.executable,'-c',code,str(directory),module_root],timeout=30,capture_output=True)
        self.assertEqual(result.returncode,7,result.stderr.decode(errors='replace'))
        r=self.recorder('child'); m=inspect_bundle(r.export())
        self.assertEqual(m['event_counts']['before_crash'],1)
        self.assertIsNone(m['stopped_at'])
        self.assertEqual(m['event_counts']['component_start'],2)
        self.assertFalse(m['collection_complete'])
    def test_secrets_are_excluded_at_rest_and_in_export(self):
        secret='secret-canary-8fb792239a';r=self.recorder()
        r.emit('observation',{'password':secret,'credentials':{'x':secret},'authorization':secret,
             'command_line':secret,'stdout':secret,'private_key':secret,'message':secret,'reason':secret,
             'unknown':secret,'services':[{'name':'owned-http','state':'running'}],
             'target':'https://example.invalid/?token='+secret,'errors':[secret]})
        path=r.export()
        with zipfile.ZipFile(path) as z: data=b''.join(z.read(x) for x in z.namelist())
        self.assertNotIn(secret.encode(),data)
        self.assertNotIn(secret.encode(),r.path.read_bytes())
        self.assertIn(b'owned-http',data)
        self.assertGreater(inspect_bundle(path)['omitted_values'],0)
    def test_capacity_loss_is_durable_and_old_events_remain(self):
        r=self.recorder(maximum_events=5)
        for _ in range(20):r.emit('sample',{'status':'observed'})
        r.stop();m=inspect_bundle(r.export())
        self.assertEqual(m['events'],5);self.assertGreater(m['dropped_events'],0)
        r.close();r=self.recorder(maximum_events=5)
        self.assertEqual(r.status()['dropped_events'],m['dropped_events'])
        previous=r.export();data=previous.read_bytes()
        r.start()
        self.assertEqual(r.status()['dropped_events'],0)
        self.assertEqual(previous.read_bytes(),data)
        self.assertEqual(inspect_bundle(previous)['dropped_events'],m['dropped_events'])
    def test_weekly_sessions_reuse_capacity_and_preserve_verified_archives(self):
        r=self.recorder(maximum_events=7)
        old=[]
        for week in range(4):
            r.start()
            for n in range(3):self.assertTrue(r.emit('weekly',{'sequence':n}))
            r.stop();path=r.export();old.append((path,path.read_bytes()))
        for path,data in old:
            self.assertEqual(path.read_bytes(),data)
            self.assertEqual(inspect_bundle(path)['event_counts']['weekly'],3)
        self.assertEqual(r.status()['archived_sessions'],3)
        self.assertEqual(r.errors,0)
    def test_corrupt_previous_export_does_not_discard_the_journal(self):
        r=self.recorder();r.emit('must_survive',{'state':'recorded'});r.stop()
        path=r.export();path.write_bytes(b'damaged evidence')
        with self.assertRaises(zipfile.BadZipFile):r.start()
        self.assertEqual(r.status()['state'],'stopped')
        path.unlink()
        repaired=r.export()
        self.assertEqual(inspect_bundle(repaired)['event_counts']['must_survive'],1)
        self.assertEqual(r.status()['archived_sessions'],0)
    def test_large_collections_report_truncation(self):
        value=sanitize({'services':[{'name':'owned','state':'running'}]*1100})
        self.assertEqual(value['services'][-1],{'omitted':'list_limit','items':76})
        r=self.recorder();r.emit('large',{'services':[{'name':'x'*500,'path':'p'*500}]*1000})
        with zipfile.ZipFile(r.export()) as z: events=[json.loads(x) for x in z.read('events.jsonl').splitlines()]
        self.assertEqual(events[-1]['data']['services'][-1]['omitted'],'event_size_limit')
        self.assertGreater(len(events[-1]['data']['services']),1)
    def test_large_native_inventory_retains_probe_and_action_outcomes(self):
        r=self.recorder()
        # Inventory comes first, as it did in the failing real Azure sample.
        telemetry={'services':[{'name':'s'*500,'path':'p'*500,'state':'running'}]*1000,
                   'probes':[{'name':'owned-http','healthy':False}],
                   'collector_errors':[], 'agent_id':'owned','boot_id':'boot','sequence':7}
        r.emit('controller_observation',{'telemetry':telemetry,
            'result':{'success':False,'rolled_back':True,'stable_health':False}})
        with zipfile.ZipFile(r.export()) as z:
            raw=z.read('events.jsonl').splitlines()[-1]
            event=json.loads(raw)['data']
        self.assertLess(len(raw),recording.MAX_EVENT)
        self.assertEqual(event['telemetry']['probes'],telemetry['probes'])
        self.assertEqual(event['telemetry']['sequence'],7)
        self.assertTrue(event['result']['rolled_back'])
        self.assertEqual(event['telemetry']['services'][-1]['omitted'],'event_size_limit')
        self.assertGreater(inspect_bundle(r.export())['omitted_values'],0)
    def test_stopped_export_is_immutable_and_chunks_match(self):
        import base64
        r=self.recorder()
        for n in range(100):r.emit('sample',{'sequence':n,'state':'running'})
        r.stop();path=r.export();first=path.read_bytes()
        self.assertTrue(r.status()['export_ready']);self.assertEqual(r.export().read_bytes(),first)
        output=b''
        while len(output)<len(first):
            output+=base64.b64decode(r.chunk(r.status()['session_id'],len(output))['data'])
        self.assertEqual(output,first)
        with self.assertRaises(ValueError):r.chunk('../escape',0)
    def test_damaged_and_truncated_archives_are_rejected(self):
        r=self.recorder();path=r.export()
        with zipfile.ZipFile(path) as z: members={n:z.read(n) for n in z.namelist()}
        original=members['events.jsonl']
        for bad in (original.replace(b'component_start',b'component_other'),original.splitlines(keepends=True)[0]):
            members['events.jsonl']=bad; altered=self.root/'changed.zip'
            with zipfile.ZipFile(altered,'w') as z:
                for n,data in members.items():z.writestr(n,data)
            with self.assertRaises(ValueError):inspect_bundle(altered)
    def test_concurrent_writers_share_one_ordered_session(self):
        a,b=self.recorder(),self.recorder()
        threads=[threading.Thread(target=lambda r=r:[r.emit('concurrent',{'sequence':n}) for n in range(80)]) for r in (a,b)]
        for t in threads:t.start()
        for t in threads:t.join()
        m=inspect_bundle(a.export())
        self.assertEqual(m['event_counts']['concurrent'],160)
        self.assertEqual(m['dropped_events'],0);self.assertEqual(a.errors+b.errors,0)
    def test_one_bundle_combines_local_and_controller(self):
        a,b=self.recorder('local'),self.recorder('controller')
        a.emit('setup_result',{'status':'ready'});b.emit('controller_observation',{'services':[{'name':'owned','state':'running'}]})
        a.stop();b.stop();path=make_session_bundle(self.root/'portable'/'session.zip',[a.export(),b.export()])
        with zipfile.ZipFile(path) as z:
            self.assertEqual(len(json.loads(z.read('session.json'))['recordings']),2)
            self.assertEqual(set(z.namelist()),{'session.json','recording-1.zip','recording-2.zip'})
        self.assertTrue(inspect_bundle(path)['verified'])
    def test_spool_loss_counts_survive_restart(self):
        from sentinel_blue.state import TelemetrySpool
        r=self.recorder()
        with patch.object(recording,'_current',r):
            spool=TelemetrySpool(self.root/'agent',max_items=2)
            for n in range(5):spool.enqueue({'sequence':n,'agent_id':'owned'})
            self.assertEqual(spool.loss_counts['spool_dropped'],3)
            self.assertEqual(TelemetrySpool(self.root/'agent',max_items=2).loss_counts['spool_dropped'],3)
        self.assertEqual(inspect_bundle(r.export())['event_counts']['spool_dropped'],3)
    def test_disk_failure_is_visible_and_does_not_break_defense(self):
        r=self.recorder()
        with patch('sentinel_blue.recording.shutil.disk_usage',side_effect=OSError('fixture disk unavailable')):
            self.assertFalse(r.emit('sample'))
        self.assertEqual(r.status()['storage_errors_this_process'],1)
        self.assertTrue(r.emit('recovered',{'status':'healthy'}))
        self.assertEqual(inspect_bundle(r.export())['storage_errors_this_process'],1)
    def test_export_publishers_are_serialized_across_recorders(self):
        from sentinel_blue.state import AgentProcessLock
        first,second=self.recorder(),self.recorder()
        with AgentProcessLock(first.export_directory):
            with self.assertRaises(recording.ExportBusy):second.export(wait_seconds=0)
            self.assertTrue(second.emit('while_exporting',{'state':'running'}))
        first.stop()
        exported=second.export()
        data=exported.read_bytes()
        self.assertEqual(first.export().read_bytes(),data)
        self.assertIsNotNone(inspect_bundle(exported)['stopped_at'])
        self.assertEqual(first.errors+second.errors,0)
    def test_another_writers_failures_are_in_the_manifest(self):
        first,second=self.recorder(),self.recorder()
        with patch('sentinel_blue.recording.shutil.disk_usage',side_effect=OSError('fixture')):
            self.assertFalse(second.emit('lost'))
        self.assertTrue(second.emit('resumed'))
        manifest=inspect_bundle(first.export())
        self.assertEqual(first.errors,0)
        self.assertEqual(manifest['storage_errors_all_sources'],1)
    def test_authenticated_controller_start_stop_and_download(self):
        from sentinel_blue.controller import ControllerApp,make_handler
        from sentinel_blue.event_profile import EventProfile
        from sentinel_blue.store import Store
        from sentinel_blue.desktop_control import DesktopClient
        r=Recorder(self.root/'http',background=True,free_floor=0);self.recorders.append(r)
        store=Store(':memory:');self.addCleanup(store.close)
        app=ControllerApp(store,'enrollment-test-key-value',event_profile=EventProfile.testing(),
            operator_token='operator-fixture-key-unique-value',operator_credential_epoch=1)
        server=http.server.ThreadingHTTPServer(('127.0.0.1',0),make_handler(app))
        threading.Thread(target=server.serve_forever,daemon=True).start()
        self.addCleanup(server.server_close);self.addCleanup(server.shutdown)
        with patch.object(recording,'_current',r):
            client=DesktopClient(f'http://127.0.0.1:{server.server_port}','operator',1,'operator-fixture-key-unique-value')
            status=client.request('/api/v1/recording/start',{})
            r.emit('owned_service_check',{'healthy':True})
            import secrets
            for _ in range(5):
                r.emit('large_transfer', {'services':[{'name':secrets.token_hex(240)} for _ in range(300)]})
            downloaded=client.save_recording(self.root/'download')
            self.assertGreater(downloaded.stat().st_size,recording.CHUNK)
            m=inspect_bundle(downloaded)
            self.assertEqual(m['session_id'],status['session_id'])
            self.assertEqual(m['event_counts']['owned_service_check'],1)
            from urllib.request import urlopen
            from urllib.error import HTTPError
            with self.assertRaises(HTTPError) as denied:urlopen(f'http://127.0.0.1:{server.server_port}/api/v1/recording/status',timeout=5)
            self.assertEqual(denied.exception.code,401)

if __name__=='__main__':unittest.main()
