"""An active request owns telemetry derivation until it completes or fails."""
from concurrent.futures import ThreadPoolExecutor
import threading
import unittest
from unittest.mock import patch

import test_session_alert_continuity as continuity
from sentinel_blue.controller import detect


class TelemetryProcessingSerializationTests(unittest.TestCase):
    def test_background_resume_does_not_reenter_active_derivation(self):
        fixture = continuity.SessionAlertContinuityTests()
        fixture.setUp()
        self.addCleanup(fixture.tearDown)
        sample = fixture.sample(1, [fixture.session(201)])
        entered = threading.Event()
        release = threading.Event()
        replay_entered = threading.Event()
        pending_observed = threading.Event()
        calls = []
        pending = fixture.store.pending_telemetry_processing

        def slow_detect(*args, **kwargs):
            calls.append(args[0]['sequence'])
            if len(calls) == 1:
                entered.set()
                if not release.wait(5):
                    raise TimeoutError('owned derivation barrier')
            else:
                replay_entered.set()
            return detect(*args, **kwargs)

        def read_pending(*args, **kwargs):
            result = pending(*args, **kwargs)
            if result:
                pending_observed.set()
            return result

        with ThreadPoolExecutor(max_workers=2) as pool, patch(
            'sentinel_blue.controller.detect', side_effect=slow_detect
        ), patch.object(fixture.store, 'pending_telemetry_processing', side_effect=read_pending):
            request = pool.submit(fixture.ingest, sample)
            try:
                self.assertTrue(entered.wait(3))
                recovery = pool.submit(fixture.app.resume_pending_telemetry)
                self.assertTrue(pending_observed.wait(3))
                overlapped = replay_entered.wait(.25)
            finally:
                release.set()
            request.result(timeout=5)
            recovery.result(timeout=5)
        self.assertFalse(overlapped, 'background maintenance reentered an active request')
        self.assertEqual(calls, [1])
        self.assertEqual(fixture.store.pending_telemetry_processing(), [])
        self.assertEqual(len(fixture.session_alerts()), 1)
        self.assertEqual(fixture.session_alerts()[0]['occurrence_count'], 1)


if __name__ == '__main__':
    unittest.main()
