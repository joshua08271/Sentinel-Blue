"""The Linux desktop launcher, exercised the way a person actually arrives at it.

Someone downloads the folder, double-clicks, and either the window opens or they
are told why. Every step of that has a way to fail silently, and a silent failure
is the whole problem being solved here: a launch from an icon has no terminal, so
anything written to stderr is discarded and the program appears to do nothing.

So these tests run the real shell scripts, in a temporary HOME, from a folder
whose name contains a space, with the executable bit cleared exactly as a browser
download leaves it. Interpreter behaviour is supplied by stub `python3` scripts,
which is what lets the refusal paths be checked on a machine that has a perfectly
good Python. The dialog helpers are not required: the reason is always written to
stderr as well, and that is what is asserted.
"""
import os
import shutil
import subprocess
import tempfile
import unittest
import xml.etree.ElementTree as ElementTree
from configparser import RawConfigParser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PACKAGING = ROOT / "packaging/linux-desktop"
LAUNCHER = PACKAGING / "sentinel-blue"
INSTALLER = PACKAGING / "install-linux-launcher.sh"
ENTRY = PACKAGING / "sentinel-blue.desktop"
ICON = PACKAGING / "sentinel-blue.svg"

# A stub interpreter answers the launcher's two questions and then records the
# command line it was asked to run.
STUB = """#!/bin/sh
case "$*" in
  *version_info*) exit {version} ;;
  *"import cryptography"*) exit {crypto} ;;
esac
printf '%s\\n' "$@" > "$EXEC_RECORD"
exit 0
"""


def posix_shell():
    return os.name == "posix" and Path("/bin/sh").exists()


@unittest.skipUnless(posix_shell(), "the Linux launcher needs a POSIX shell")
class LauncherScriptTests(unittest.TestCase):
    """What the launcher does before the runtime can speak for itself."""

    def setUp(self):
        self.root = Path(tempfile.mkdtemp(prefix="sentinel-launcher-"))
        # A space in the path is the classic thing that breaks a desktop entry.
        self.folder = self.root / "Sentinel Blue 1.9.84"
        self.folder.mkdir()
        for source in (LAUNCHER, INSTALLER, ENTRY, ICON, PACKAGING / "install-linux-launcher.py"):
            shutil.copy(source, self.folder / source.name)
        (self.folder / "sentinel-blue.pyz").write_text("# stands in for the runtime\n")
        # Exactly what a browser download leaves: nothing is executable.
        for item in self.folder.iterdir():
            item.chmod(0o644)
        self.tools = self.root / "tools"
        self.tools.mkdir()
        for name in ("dirname", "sed", "id", "chmod", "mkdir", "cp", "rm", "ls"):
            found = shutil.which(name)
            if found:
                (self.tools / name).symlink_to(found)

    def stub_python(self, *, version=0, crypto=0, name="python3"):
        path = self.tools / name
        path.write_text(STUB.format(version=version, crypto=crypto))
        path.chmod(0o755)
        return path

    def launch(self, *, record=None):
        environment = {
            "PATH": str(self.tools),
            "HOME": str(self.root),
            # No DISPLAY: the dialog helpers are skipped and stderr still carries
            # the reason, which is what this asserts.
            "EXEC_RECORD": str(record) if record else str(self.root / "unused"),
        }
        return subprocess.run(["/bin/sh", str(self.folder / "sentinel-blue")],
                              env=environment, capture_output=True, text=True, timeout=60)

    def test_the_shipped_shell_parses(self):
        for script in (LAUNCHER, INSTALLER):
            for shell in ("sh", "bash", "dash"):
                if not shutil.which(shell):
                    continue
                with self.subTest(script=script.name, shell=shell):
                    done = subprocess.run([shell, "-n", str(script)],
                                          capture_output=True, text=True)
                    self.assertEqual(done.returncode, 0, done.stderr)

    def test_no_python_at_all_names_the_package_to_install(self):
        done = self.launch()
        self.assertNotEqual(done.returncode, 0)
        self.assertIn("apt install python3", done.stderr)

    def test_a_python_older_than_the_minimum_is_named_as_such(self):
        self.stub_python(version=1)
        done = self.launch()
        self.assertNotEqual(done.returncode, 0)
        self.assertIn("3.11 or newer", done.stderr)

    def test_a_newer_named_python_is_preferred_over_an_old_default(self):
        """python3 being old is not a refusal when python3.12 is installed."""
        self.stub_python(version=1)
        self.stub_python(name="python3.12")
        record = self.root / "execed"
        done = self.launch(record=record)
        self.assertEqual(done.returncode, 0, done.stderr)
        self.assertIn("sentinel-blue.pyz", record.read_text())

    def test_missing_cryptography_is_named_with_both_ways_to_install_it(self):
        self.stub_python(crypto=1)
        done = self.launch()
        self.assertNotEqual(done.returncode, 0)
        self.assertIn("cryptography", done.stderr)
        self.assertIn("apt install python3-cryptography", done.stderr)

    def test_a_launcher_without_its_runtime_says_so(self):
        (self.folder / "sentinel-blue.pyz").unlink()
        self.stub_python()
        done = self.launch()
        self.assertNotEqual(done.returncode, 0)
        self.assertIn("same folder", done.stderr)

    def test_a_working_setup_runs_the_runtime_beside_the_launcher(self):
        self.stub_python()
        record = self.root / "execed"
        done = self.launch(record=record)
        self.assertEqual(done.returncode, 0, done.stderr)
        self.assertEqual(record.read_text().strip(),
                         str(self.folder / "sentinel-blue.pyz"))


@unittest.skipUnless(posix_shell(), "the Linux installer needs a POSIX shell")
class InstallerTests(unittest.TestCase):
    """Registering the application, from a folder as the browser left it."""

    def setUp(self):
        self.root = Path(tempfile.mkdtemp(prefix="sentinel-install-"))
        self.home = self.root / "home"
        (self.home / "Desktop").mkdir(parents=True)
        self.folder = self.home / "Downloads" / "Sentinel Blue 1.9.84"
        self.folder.mkdir(parents=True)
        for source in (LAUNCHER, INSTALLER, ENTRY, ICON, PACKAGING / "install-linux-launcher.py"):
            shutil.copy(source, self.folder / source.name)
        (self.folder / "sentinel-blue.pyz").write_text("# stands in for the runtime\n")
        for item in self.folder.iterdir():
            item.chmod(0o644)
        self.data = self.home / ".local/share"
        self.entry = self.data / "applications/sentinel-blue.desktop"

    def install(self, *arguments):
        environment = dict(os.environ)
        environment.update(HOME=str(self.home), XDG_DATA_HOME=str(self.data))
        return subprocess.run(["/bin/sh", "install-linux-launcher.sh", *arguments],
                              cwd=self.folder, env=environment,
                              capture_output=True, text=True, timeout=120)

    def parsed_entry(self):
        parser = RawConfigParser(interpolation=None)
        parser.optionxform = str
        parser.read_string(self.entry.read_text())
        return parser["Desktop Entry"]

    def test_installing_registers_a_valid_application_entry(self):
        done = self.install()
        self.assertEqual(done.returncode, 0, done.stderr)
        self.assertTrue(self.entry.is_file())
        entry = self.parsed_entry()
        self.assertEqual(entry["Type"], "Application")
        self.assertEqual(entry["Terminal"], "false")
        self.assertTrue(entry["Name"])
        self.assertTrue(entry["Icon"])

    def test_the_entry_points_at_the_launcher_through_a_path_with_a_space(self):
        self.install()
        import shlex
        arguments = shlex.split(self.parsed_entry()["Exec"])
        self.assertEqual(arguments[0], "/bin/sh")
        self.assertEqual(len(arguments), 2)
        target = Path(arguments[1])
        self.assertTrue(target.is_absolute())
        self.assertEqual(target, self.folder / "sentinel-blue")
        self.assertTrue(target.is_file())

    def test_installing_restores_the_executable_bit_a_download_strips(self):
        for name in ("sentinel-blue", "sentinel-blue.pyz"):
            self.assertFalse(os.access(self.folder / name, os.X_OK))
        self.install()
        for name in ("sentinel-blue", "sentinel-blue.pyz"):
            with self.subTest(name=name):
                self.assertTrue(os.access(self.folder / name, os.X_OK))

    def test_the_icon_is_installed_and_is_well_formed(self):
        self.install()
        installed = self.data / "icons/hicolor/scalable/apps/sentinel-blue.svg"
        self.assertTrue(installed.is_file())
        ElementTree.parse(installed)      # raises if it is not valid XML

    def test_a_desktop_icon_is_placed_when_there_is_a_desktop(self):
        self.install()
        self.assertTrue((self.home / "Desktop/sentinel-blue.desktop").is_file())

    def test_installing_twice_is_the_same_as_installing_once(self):
        self.install()
        first = self.entry.read_text()
        second = self.install()
        self.assertEqual(second.returncode, 0, second.stderr)
        self.assertEqual(self.entry.read_text(), first)

    def test_uninstall_removes_everything_it_added_and_nothing_else(self):
        self.install()
        done = self.install("--uninstall")
        self.assertEqual(done.returncode, 0, done.stderr)
        self.assertFalse(self.entry.exists())
        self.assertFalse((self.data / "icons/hicolor/scalable/apps/sentinel-blue.svg").exists())
        self.assertFalse((self.home / "Desktop/sentinel-blue.desktop").exists())
        # The download itself is never touched.
        for name in ("sentinel-blue", "sentinel-blue.pyz", "install-linux-launcher.sh"):
            self.assertTrue((self.folder / name).is_file())

    def test_uninstall_on_a_clean_machine_is_not_an_error(self):
        done = self.install("--uninstall")
        self.assertEqual(done.returncode, 0, done.stderr)

    def test_the_installer_refuses_when_it_is_not_beside_the_runtime(self):
        (self.folder / "sentinel-blue.pyz").unlink()
        done = self.install()
        self.assertNotEqual(done.returncode, 0)
        self.assertIn("sentinel-blue.pyz", done.stderr)


if __name__ == "__main__":
    unittest.main()
