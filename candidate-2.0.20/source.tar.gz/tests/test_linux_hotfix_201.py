"""2.0.1 regression tests for Linux findings 31-36.

Real private files/ledgers/inert subprocesses and local sockets. Native services,
provider faults and approval inputs are modeled. No online source is accessed.
"""
from contextlib import ExitStack
from dataclasses import asdict
import base64
import copy
import hashlib
import json
import os
from pathlib import Path
import socket
import struct
import subprocess
import sys
import tempfile
import time
import unittest
import uuid
from unittest.mock import patch

from sentinel_blue import collectors as c, native_probes as np, setup_linux_transaction as tx
from sentinel_blue.analyzers import analyze_services
from sentinel_blue.detection import detect
from sentinel_blue.mutation_ledger import MutationLedger
from sentinel_blue.posix_security import security_digest
from sentinel_blue.restoration import RestorePointStore
from sentinel_blue.risk import RiskModel
from sentinel_blue.service_repair import port_conflict_findings, restart_futility, repair_parameters
from linux_19101_review_cases import setup_fixture
from linux_201_review_cases import (corrected_spec, worker_isolation, nonconflicting_loopback,
                                   readonly_admission, case_services, integrity_permissions, interfaces)


@unittest.skipUnless(os.name == 'posix' and os.geteuid() == 0, 'private root-owned fixtures')
class Admission201(unittest.TestCase):
    def setUp(self):
        self.stack=ExitStack(); self.addCleanup(self.stack.close)
        self.root,self.path,self.spec,self.token,self.ledger,self.run,self.state=self.stack.enter_context(setup_fixture())
    def test_wrong_previous_hash_has_no_action_or_native_mutation(self):
        self.path.write_text('TEAM_PREEXISTING\n')
        with self.assertRaisesRegex(ValueError,'before/after'):self.run('apply')
        self.assertEqual(self.path.read_text(),'TEAM_PREEXISTING\n')
        self.assertFalse(self.ledger.actions());self.assertFalse((tx.ROOT/self.token).exists())
        self.assertFalse(list(tx.ROOT.glob('resource-*')));tx.command.assert_not_called()
    def test_corrected_plan_reuses_the_same_ledger(self):
        self.path.write_text('TEAM_PREEXISTING\n')
        with self.assertRaises(ValueError):self.run('apply')
        spec,script=corrected_spec(self.root,self.path)
        tx.run('apply',spec,uuid.uuid4().hex,script,ledger_directory=self.root/'ledger')
        self.assertEqual(self.path.read_text(),'AFTER\n')
        self.assertEqual([r['status'] for r in self.ledger.actions()],['applied'])
    def test_missing_expected_existing_file_refuses_before_prepare(self):
        self.path.unlink()
        with self.assertRaisesRegex(ValueError,'absent'):self.run('apply')
        self.assertFalse(self.ledger.actions());self.assertFalse((tx.ROOT/self.token).exists())
    def test_resource_claim_refusal_does_not_create_another_action(self):
        with tx.transaction_lock():
            tx.save(tx.ROOT/('resource-'+tx.resources(self.spec)[0]+'.json'),{'transaction':'f'*32})
        with self.assertRaisesRegex(ValueError,'owns'):self.run('apply')
        self.assertFalse(self.ledger.actions());self.assertEqual(len(list(tx.ROOT.glob('resource-*'))),1)
    def test_existing_native_token_refuses_before_prepare(self):
        with tx.transaction_lock():
            (tx.ROOT/self.token).mkdir(mode=0o700)
        with self.assertRaisesRegex(ValueError,'replayed'):self.run('apply')
        self.assertFalse(self.ledger.actions())
    def test_replaying_applied_token_keeps_original_action(self):
        self.run('apply');head=self.ledger.head()
        with self.assertRaises(ValueError):self.run('apply')
        self.assertEqual(self.ledger.head(),head);self.assertEqual(self.ledger.actions()[0]['status'],'applied')
    def test_race_after_durable_prepare_stays_uncertain(self):
        real=MutationLedger.prepare
        def replace(ledger,*a,**kw):
            value=real(ledger,*a,**kw);self.path.write_text('OUTSIDE\n');return value
        with patch.object(MutationLedger,'prepare',new=replace), self.assertRaisesRegex(ValueError,'authenticated admission'):
            self.run('apply')
        self.assertEqual(self.path.read_text(),'OUTSIDE\n')
        self.assertEqual(self.ledger.actions()[0]['status'],'uncertain')
        self.assertFalse((tx.ROOT/self.token).exists())
    def test_paused_ledger_still_refuses_admission(self):
        self.ledger.pause('fixture')
        with self.assertRaisesRegex(ValueError,'paused'):self.run('apply')
        self.assertFalse(self.ledger.actions())
    def test_untrusted_file_permissions_refuse_without_action(self):
        self.path.chmod(0o666)
        with self.assertRaises(ValueError):self.run('apply')
        self.assertFalse(self.ledger.actions());self.assertEqual(self.path.stat().st_mode&0o777,0o666)
    def test_unresolved_historical_action_is_not_cleared(self):
        token=uuid.uuid4().hex
        target={'spec':self.spec,'token':token,'objects':['service:'+self.spec['service']]}
        self.ledger.prepare('setup-linux-v1',target,tx.ledger_capture(self.spec),action_id='setup-'+token)
        self.ledger.append('uncertain',action_id='setup-'+token,reason='old-unknown')
        with self.assertRaises(ValueError):self.run('apply')
        self.assertEqual([r['status'] for r in self.ledger.actions()],['uncertain'])


class WorkerIsolation201(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        package=str(Path(np.__file__).parent.parent)
        cls.rows={r['variant']:r for r in worker_isolation(package)['cases']}
    def test_clean_native_scoring_still_runs(self):
        self.assertTrue(self.rows['clean']['success']);self.assertTrue(self.rows['clean']['native_client_ran'])
    def test_invalid_pythonhome_is_ignored_by_worker(self):
        self.assertEqual(self.rows['invalid_home']['parent_isolated'],1)
        self.assertTrue(self.rows['invalid_home']['success']);self.assertTrue(self.rows['invalid_home']['native_client_ran'])
    def test_ambient_sitecustomize_is_not_executed(self):
        self.assertTrue(self.rows['ambient_site']['success']);self.assertFalse(self.rows['ambient_site']['ambient_marker'])
    def test_worker_argv_and_environment_are_explicit(self):
        with patch.object(np,'python_command',return_value=['/fixture/python']), patch.object(np,'missing_clients',return_value=[]), \
             patch.object(np,'_command',return_value=b'{"healthy":true,"detail":"fixture"}') as run, \
             patch.dict(os.environ,{'PYTHONHOME':'/invalid','PYTHONPATH':'/invalid','PYTHONSTARTUP':'/invalid','TCL_LIBRARY':'/local/tcl'}):
            self.assertEqual(np.run_native_probe('icmp',{},'127.0.0.1',2),'fixture')
        argv=run.call_args.args[0];kw=run.call_args.kwargs
        self.assertEqual(argv[:4],['/fixture/python','-I','-B','-c'])
        self.assertFalse(any(k.upper().startswith('PYTHON') for k in kw['env']))
        self.assertEqual(kw['env']['TCL_LIBRARY'],'/local/tcl');self.assertTrue(kw['supervise_tree'])
    def test_isolated_flags_are_not_duplicated(self):
        with patch.object(np,'python_command',return_value=['/fixture/python','-I','-B']), patch.object(np,'missing_clients',return_value=[]), \
             patch.object(np,'_command',return_value=b'{"healthy":true,"detail":"fixture"}') as run:
            np.run_native_probe('icmp',{},'127.0.0.1',2)
        argv=run.call_args.args[0];self.assertEqual(argv.count('-I'),1);self.assertEqual(argv.count('-B'),1)
    def test_missing_client_never_launches_worker(self):
        with patch.object(np,'missing_clients',return_value=['ping']), patch.object(np,'_command') as run, self.assertRaises(np.ProbeUnavailable):
            np.run_native_probe('icmp',{},'127.0.0.1',2)
        run.assert_not_called()


class ServiceNames201(unittest.TestCase):
    def pair(self,platform='Linux'):
        before={'platform':platform,'services':[{'name':'Worker.service','state':'running','start_mode':'enabled','restart_count':0,'result':'success'},
                                               {'name':'worker.service','state':'running','start_mode':'enabled','restart_count':0,'result':'success'}]}
        after=copy.deepcopy(before);after['services'][0].update(start_mode='masked',restart_count=7,result='exit-code')
        return before,after
    def kinds(self,before,after):return {r.kind for r in analyze_services(after,before,RiskModel())}
    def test_linux_both_row_orders_keep_both_alerts(self):
        for reverse in (False,True):
            b,a=self.pair()
            if reverse:b['services'].reverse();a['services'].reverse()
            with self.subTest(reverse=reverse):self.assertEqual(self.kinds(b,a),{'service_startup_disabled','service_restart_loop'})
    def test_linux_alert_evidence_keeps_original_case(self):
        b,a=self.pair();self.assertTrue(all(r.evidence['service']=='Worker.service' for r in analyze_services(a,b,RiskModel())))
    def test_unknown_platform_preserves_names(self):
        b,a=self.pair('');self.assertEqual(len(self.kinds(b,a)),2)
    def test_current_linux_overrides_windows_baseline(self):
        b,a=self.pair();b['platform']='Windows';self.assertEqual(len(self.kinds(b,a)),2)
    def test_windows_same_name_different_case_matches(self):
        b,a=self.pair('Windows Server');b['services']=b['services'][:1];a['services']=a['services'][:1];a['services'][0]['name']='WORKER.SERVICE'
        self.assertEqual(len(self.kinds(b,a)),2)
    def test_windows_baseline_used_if_platform_omitted(self):
        b,a=self.pair('Windows');b['services']=b['services'][:1];a['services']=a['services'][:1];a.pop('platform');a['services'][0]['name']='WORKER.SERVICE'
        self.assertEqual(len(self.kinds(b,a)),2)
    def test_linux_distinct_only_name_not_adopted_as_previous(self):
        b,a=self.pair();b['services']=b['services'][:1];a['services']=a['services'][:1];a['services'][0]['name']='WORKER.SERVICE'
        self.assertFalse(self.kinds(b,a))
    def test_unchanged_case_distinct_units_produce_no_alert(self):
        b,a=self.pair();self.assertFalse(self.kinds(b,copy.deepcopy(b)))


@unittest.skipUnless(os.name == 'posix' and os.geteuid()==0,'POSIX private permission fixtures')
class FileSecurity201(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='sb-security-201-',dir='/var/lib');self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.path=self.root/'fixture.conf';self.path.write_text('nonsecret fixture\n');self.path.chmod(0o600)
    def sample(self):
        return asdict(c._posix_integrity_item(self.path,c._IntegrityBudget()))
    def alert(self,before,after):
        baseline={'agent_id':'fixture','platform':'Linux','integrity':[before]}
        return next(r for r in detect(dict(baseline,integrity=[after]),baseline,set(),RiskModel()) if r.kind=='critical_file_changed')
    def test_mode_change_updates_security_not_content_digest(self):
        before=self.sample();self.path.chmod(0o644);after=self.sample();a=self.alert(before,after)
        self.assertEqual(before['sha256'],after['sha256']);self.assertNotEqual(before['security_descriptor_sha256'],after['security_descriptor_sha256'])
        self.assertEqual(a.evidence['change_types'],['security_metadata']);self.assertEqual(a.recommended_action,'restore_integrity')
    def test_owner_change_updates_security(self):
        before=self.sample();os.chown(self.path,65534,-1);after=self.sample();self.assertTrue(self.alert(before,after).evidence['security_metadata_changed'])
    def test_group_change_updates_security(self):
        before=self.sample();os.chown(self.path,-1,65534);self.assertNotEqual(before['security_descriptor_sha256'],self.sample()['security_descriptor_sha256'])
    def test_xattr_add_modify_remove_observed(self):
        before=self.sample();os.setxattr(self.path,'user.sb_test',b'one');one=self.sample();os.setxattr(self.path,'user.sb_test',b'two');two=self.sample();os.removexattr(self.path,'user.sb_test');last=self.sample()
        self.assertNotEqual(before['security_descriptor_sha256'],one['security_descriptor_sha256']);self.assertNotEqual(one['security_descriptor_sha256'],two['security_descriptor_sha256']);self.assertEqual(last['security_descriptor_sha256'],before['security_descriptor_sha256'])
    def test_acl_change_with_same_mode_and_bytes_is_observed(self):
        def acl(uid):
            return struct.pack('<I',2)+b''.join(struct.pack('<HHI',tag,perm,ident) for tag,perm,ident in [(1,6,0xffffffff),(2,4,uid),(4,0,0xffffffff),(16,4,0xffffffff),(32,0,0xffffffff)])
        os.setxattr(self.path,'system.posix_acl_access',acl(65534));before=self.sample();mode=self.path.stat().st_mode
        os.setxattr(self.path,'system.posix_acl_access',acl(65533));after=self.sample()
        self.assertEqual(self.path.stat().st_mode,mode);self.assertEqual(before['sha256'],after['sha256']);self.assertTrue(self.alert(before,after).evidence['security_metadata_changed'])
    def test_timestamps_are_not_security_metadata(self):
        before=self.sample();os.utime(self.path,ns=(1000000000,2000000000));after=self.sample()
        self.assertEqual(before['security_descriptor_sha256'],after['security_descriptor_sha256'])
    def test_canonical_attribute_order_and_encodings(self):
        meta={'mode':0o600,'uid':0,'gid':0,'xattrs':{'user.a':'YQ==','user.b':'Yg=='}}
        reverse=dict(meta,xattrs=dict(reversed(list(meta['xattrs'].items()))))
        self.assertEqual(security_digest(meta),security_digest(reverse))
    def test_malformed_security_metadata_refused(self):
        base={'mode':0o600,'uid':0,'gid':0,'xattrs':{}}
        for changed in ({'uid':-1},{'gid':True},{'mode':0o10000},{'xattrs':{'a':'not-base64'}},{'xattrs':None}):
            with self.subTest(changed=changed),self.assertRaises(ValueError):security_digest(dict(base,**changed))
    def test_xattr_read_failure_is_incomplete_not_fabricated_digest(self):
        with patch.object(c,'_integrity_paths',return_value=[self.path]), patch.object(c.os,'listxattr',side_effect=PermissionError('fixture unavailable')):
            errors=[];rows=c._integrity('linux',errors)
        self.assertFalse(rows);self.assertTrue(errors)
    def test_attribute_overflow_is_rejected(self):
        with patch.object(c.os,'listxattr',return_value=['user.a'+str(i) for i in range(129)]),self.assertRaisesRegex(ValueError,'count'):
            self.sample()
    def test_attribute_change_during_read_is_not_published(self):
        real=c.capture_xattrs;count=0
        def mutate(*args):
            nonlocal count
            value=real(*args);count+=1
            if count==1:os.setxattr(self.path,'user.changed',b'outside')
            return value
        with patch.object(c,'capture_xattrs',side_effect=mutate),self.assertRaisesRegex(ValueError,'changed'):self.sample()
    def test_monitor_and_restorepoint_use_identical_security_schema(self):
        os.setxattr(self.path,'user.fixture',b'x');sample=self.sample();_,meta=RestorePointStore._read_target(self.path)
        self.assertEqual(sample['security_descriptor_sha256'],RestorePointStore._metadata_security_descriptor_sha256(meta))
    def test_security_bound_capture_and_restore_roundtrip(self):
        old=self.sample();store=RestorePointStore(self.root/'restore')
        receipt=store.capture([old]);self.assertTrue(receipt['success'],receipt)
        self.path.chmod(0o644);new=self.sample()
        value=store.restore({'path':str(self.path),'baseline_sha256':old['sha256'],'observed_sha256':new['sha256'],
                             'baseline_security_descriptor_sha256':old['security_descriptor_sha256'],
                             'observed_security_descriptor_sha256':new['security_descriptor_sha256'],'observed_missing':False},allowed=True)
        self.assertTrue(value['success'],value);self.assertEqual(self.path.stat().st_mode&0o777,0o600)
    def test_legacy_empty_security_is_review_not_automatic_restore(self):
        after=self.sample();before=dict(after,security_descriptor_sha256='');alert=self.alert(before,after)
        self.assertTrue(alert.evidence['security_baseline_upgrade']);self.assertEqual(alert.recommended_action,'snapshot')
    def test_missing_current_security_cannot_recommend_restore(self):
        before=self.sample();after=dict(before,security_descriptor_sha256='');alert=self.alert(before,after)
        self.assertEqual(alert.recommended_action,'snapshot');self.assertTrue(alert.evidence['security_observation_unverified'])
    def test_new_evidence_requires_review_in_legacy_repair_contract(self):
        from test_service_repair import repair_fixture,damage
        profile,baseline=repair_fixture(str(self.path));baseline['integrity']=[dict(self.sample(),security_descriptor_sha256='')]
        now=damage(baseline);now['integrity'][0]['security_descriptor_sha256']=self.sample()['security_descriptor_sha256']
        now['observed_at']=time.time()
        with self.assertRaisesRegex(ValueError,'explicit baseline review'):repair_parameters(profile,'agent-one','web.service',baseline,now)


class InterfaceCoverage201(unittest.TestCase):
    def collect(self,rows=None,*,reply=None):
        if reply is None:reply=subprocess.CompletedProcess(['ip'],0,json.dumps(rows),'')
        with patch.object(c,'_run',return_value=reply):
            errors=[];items=c._linux_interfaces(errors)
        return items,errors
    def row(self,name='eth0',addresses=None):
        return {'ifname':name,'addr_info':addresses if addresses is not None else [{'local':'192.0.2.1','prefixlen':24,'family':'inet'}]}
    def test_known_empty_inventory_is_not_fallback(self):
        with patch.object(c,'_fallback_interfaces') as fallback:
            self.assertEqual(self.collect([]),([],[]))
        fallback.assert_not_called()
    def test_valid_ipv4_ipv6_and_empty_addresses(self):
        items,errors=self.collect([self.row(addresses=[{'local':'127.0.0.1','prefixlen':8},{'local':'::1','prefixlen':128}]),self.row('eth1',[])])
        self.assertFalse(errors);self.assertEqual(items[0].addresses,['127.0.0.1/8','::1/128']);self.assertFalse(items[1].addresses)
    def test_provider_failure_retains_names_and_incomplete_label(self):
        with patch.object(c.socket,'if_nameindex',return_value=[(2,'eth0')]),patch.object(c.socket,'getaddrinfo',return_value=[]):
            items,errors=self.collect(reply=subprocess.CompletedProcess(['ip'],1,'','failure'))
        self.assertEqual(items[0].name,'eth0');self.assertTrue(any('mapping incomplete' in e for e in errors))
    def test_provider_timeout_retains_partial_diagnostics(self):
        with patch.object(c,'_run',side_effect=subprocess.TimeoutExpired(['ip'],15)),patch.object(c,'_fallback_interfaces',return_value=[]):
            errors=[];c._linux_interfaces(errors)
        self.assertTrue(any('TimeoutExpired' in e for e in errors))
    def test_malformed_provider_shapes_are_incomplete(self):
        for raw in ('{}','null','1','[','"str"'):
            with self.subTest(raw=raw),patch.object(c,'_fallback_interfaces',return_value=[]):
                _,errors=self.collect(reply=subprocess.CompletedProcess(['ip'],0,raw,''));self.assertTrue(errors)
    def test_exact_interface_limit_is_complete(self):
        items,errors=self.collect([self.row('eth'+str(i)) for i in range(512)]);self.assertEqual(len(items),512);self.assertFalse(errors)
    def test_interface_overflow_is_reported(self):
        items,errors=self.collect([self.row('eth'+str(i)) for i in range(513)]);self.assertEqual(len(items),512);self.assertTrue(any('512' in e for e in errors))
    def test_address_overflow_is_reported(self):
        items,errors=self.collect([self.row(addresses=[{'local':'192.0.2.'+str(i)} for i in range(1,66)])]);self.assertEqual(len(items[0].addresses),64);self.assertTrue(any('64-address' in e for e in errors))
    def test_missing_address_list_is_unknown_not_known_empty(self):
        items,errors=self.collect([{'ifname':'eth0'}]);self.assertEqual(len(items),1);self.assertTrue(errors)
    def test_bad_rows_and_addresses_do_not_discard_good_rows(self):
        items,errors=self.collect([None,{},self.row(addresses=[{'local':'bad'},{'local':'::1','prefixlen':129},{'local':'192.0.2.1','family':'inet6'},{'local':'127.0.0.1','prefixlen':8}])])
        self.assertEqual(items[0].addresses,['127.0.0.1/8']);self.assertTrue(errors)
    def test_duplicate_interface_is_reported(self):
        items,errors=self.collect([self.row(),self.row()]);self.assertEqual(len(items),1);self.assertTrue(errors)
    def test_success_with_stderr_is_not_full_coverage(self):
        _,errors=self.collect(reply=subprocess.CompletedProcess(['ip'],0,json.dumps([self.row()]),'diagnostic'));self.assertTrue(errors)
    def test_fallback_limits_are_visible(self):
        with patch.object(c.socket,'if_nameindex',return_value=[(i,'eth'+str(i)) for i in range(513)]),patch.object(c.socket,'getaddrinfo',return_value=[]):
            errors=[];rows=c._fallback_interfaces(errors)
        self.assertEqual(len(rows),512);self.assertTrue(errors)


class BindOverlap201(unittest.TestCase):
    def findings(self,address='127.0.0.1',listener='127.0.0.1',*,protocol='tcp',kind='tcp',port=8080,extra=None):
        spec={'kind':kind,'target':address,'port':port}
        row={'protocol':protocol,'address':listener,'port':port,'process':'fixture'}
        if extra:row.update(extra)
        return port_conflict_findings('fixture.service',{'expected_transactions':[spec]},{'listeners':[row]})
    def test_real_distinct_loopback_binds_allow_same_port(self):
        value=nonconflicting_loopback();self.assertTrue(value['both_addresses_listened_simultaneously']);self.assertEqual(value['repair_plan'],'success');self.assertFalse(value['restart_futility'])
    def test_specific_matching_endpoint_still_holds(self):
        rows=self.findings();self.assertEqual(rows[0]['code'],'listening_port_occupied');self.assertTrue(restart_futility(rows))
    def test_ipv4_wildcard_overlaps_ipv4(self):
        self.assertTrue(restart_futility(self.findings(listener='0.0.0.0')))
    def test_ipv6_wildcard_overlaps_ipv6(self):
        self.assertTrue(restart_futility(self.findings(address='::1',listener='::',protocol='tcp6')))
    def test_distinct_loopback_is_advisory_not_definitive(self):
        rows=self.findings(listener='127.0.0.2');self.assertEqual(rows[0]['code'],'listener_bind_overlap_unverified');self.assertFalse(restart_futility(rows));self.assertEqual(rows[0]['evidence']['expected_address'],'127.0.0.1')
    def test_specific_different_families_do_not_overlap(self):
        self.assertFalse(self.findings(listener='::1',protocol='tcp6'))
    def test_unknown_ipv6_dualstack_mode_is_not_proven_overlap(self):
        rows=self.findings(listener='::',protocol='tcp6');self.assertEqual(rows[0]['evidence']['endpoint_overlap'],'unknown');self.assertFalse(restart_futility(rows))
    def test_unspecified_family_wildcard_is_advisory(self):
        self.assertFalse(restart_futility(self.findings(listener='*')))
    def test_ipv4_mapped_address_keeps_observed_overlap(self):
        self.assertTrue(restart_futility(self.findings(listener='::ffff:127.0.0.1',protocol='tcp6')))
    def test_udp_cannot_block_tcp(self):self.assertFalse(self.findings(protocol='udp'))
    def test_udp_dns_uses_udp_not_tcp(self):
        self.assertTrue(self.findings(protocol='udp',kind='dns'));self.assertFalse(self.findings(protocol='tcp',kind='dns'))
    def test_icmp_never_infers_tcp_bind(self):self.assertFalse(self.findings(kind='icmp'))
    def test_malformed_listener_never_proves_conflict(self):
        for change in ({'address':None},{'address':42},{'port':True},{'protocol':None}):
            with self.subTest(change=change):self.assertFalse(self.findings(extra=change))
    def test_later_actual_overlap_not_hidden_by_first_advisory(self):
        rows=[{'address':a,'protocol':'tcp','port':8080} for a in ['127.0.0.2','127.0.0.1']]
        value=port_conflict_findings('s',{'expected_transactions':[{'kind':'tcp','target':'127.0.0.1','port':8080}]},{'listeners':rows})
        self.assertEqual(value[0]['code'],'listening_port_occupied')
    def test_same_port_distinct_declared_endpoints_retained(self):
        manifest={'expected_transactions':[{'kind':'tcp','target':a,'port':8080} for a in ['127.0.0.1','127.0.0.2']]}
        value=port_conflict_findings('s',manifest,{'listeners':[{'protocol':'tcp','port':8080,'address':'0.0.0.0'}]})
        self.assertEqual(len(value),2)
    def test_socket_activation_stays_non_futile(self):
        value=self.findings(extra={'process':'users:(("systemd",pid=1,fd=8))'})
        self.assertEqual(value[0]['code'],'socket_activation_holds_port');self.assertFalse(restart_futility(value))
    def test_false_collision_does_not_enter_execution_gate(self):
        from test_service_repair import repair_fixture,damage
        from sentinel_blue.service_repair import validate_repair_contract
        profile,base=repair_fixture();current=damage(base);current['observed_at']=time.time();current['listeners']=[{'protocol':'tcp','port':8765,'address':'127.0.0.2'}]
        plan=repair_parameters(profile,'agent-one','web.service',base,current)
        validate_repair_contract(profile,'agent-one',plan,current)


class SecurityMigration201(unittest.TestCase):
    def host(self):
        return {'agent_id':'security-migration','hostname':'local-fixture','platform':'Linux',
                'observed_at':time.time()-3,'boot_id':'fixture-boot','sequence':1,
                'accounts':[],'sessions':[],'services':[],'interfaces':[],'collector_errors':[],
                'integrity':[{'path':'/etc/fixture-security.conf','sha256':'a'*64,'size':1,'modified_at':1,
                              'security_descriptor_sha256':'b'*64}]}
    def controller_case(self,legacy=False):
        from sentinel_blue.controller import ControllerApp
        from sentinel_blue.store import Store
        from test_store_controller import _promote_integrity_baseline
        store=Store(':memory:');self.addCleanup(store.close)
        app=ControllerApp(store,'t'*32,operator_token='o'*32,auto_restore=True,
                          allow_unprobed_restoration=True,restore_confirmations=1)
        baseline=self.host()
        if legacy:baseline['integrity'][0]['security_descriptor_sha256']=''
        app.ingest(baseline);_promote_integrity_baseline(app,store,baseline['agent_id'])
        current=copy.deepcopy(baseline);current.update(observed_at=time.time(),sequence=2)
        current['integrity'][0]['security_descriptor_sha256']='b'*64 if legacy else ''
        app.ingest(current)
        alerts=[a for a in store.dashboard()['alerts'] if a['kind']=='critical_file_changed']
        self.assertTrue(alerts);self.assertEqual(alerts[0]['recommended_action'],'snapshot')
        self.assertFalse(any(a.action_type=='restore_integrity' for a in store.pending_actions(baseline['agent_id'])))
        return alerts[0]
    def test_controller_does_not_restore_on_missing_current_metadata(self):
        alert=self.controller_case();self.assertEqual(alert['evidence']['automation_hold'],'observed_security_metadata_unverified')
    def test_controller_legacy_baseline_requires_explicit_promotion(self):
        alert=self.controller_case(True);self.assertEqual(alert['evidence']['automation_hold'],'baseline_security_metadata_unapproved')
    def test_security_digest_survives_wire_normalization(self):
        from sentinel_blue.validation import validate_telemetry
        value=self.host();normalized=validate_telemetry(json.loads(json.dumps(value)))
        self.assertEqual(normalized['integrity'][0]['security_descriptor_sha256'],'b'*64)


@unittest.skipUnless(os.name == 'posix' and os.geteuid()==0,'private root-owned integration')
class SecurityApproval201(unittest.TestCase):
    def test_actual_capture_receipt_promotes_and_permission_change_restores(self):
        from sentinel_blue.actions import ActionExecutor
        from sentinel_blue.controller import ControllerApp
        from sentinel_blue.store import Store
        from test_store_controller import _dispatch_baseline_capture
        with tempfile.TemporaryDirectory(prefix='sb-integrated-201-',dir='/var/lib') as tmp:
            root=Path(tmp);target=root/'fixture.conf';target.write_text('private nonsecret\n');target.chmod(0o600)
            baseline={'agent_id':'security-file','hostname':'local-fixture','platform':'Linux',
                      'boot_id':'security-boot','sequence':1,'observed_at':time.time()-2,
                      'accounts':[],'sessions':[],'services':[],'interfaces':[],'collector_errors':[],
                      'integrity':[asdict(c._posix_integrity_item(target,c._IntegrityBudget()))]}
            store=Store(':memory:');self.addCleanup(store.close)
            app=ControllerApp(store,'t'*32,operator_token='o'*32,auto_restore=True,
                              allow_unprobed_restoration=True,restore_confirmations=1)
            executor=ActionExecutor(root/'agent',allow_restoration=True)
            app.ingest(baseline);_,action=_dispatch_baseline_capture(app,baseline['agent_id'])
            result=executor.execute(action.action_type,action.parameters,baseline)
            self.assertTrue(result['success'],result)
            self.assertEqual(result['capture_receipts'][0]['security_descriptor_sha256'],baseline['integrity'][0]['security_descriptor_sha256'])
            self.assertEqual(app.complete_action(dict(result,action_id=action.action_id),baseline['agent_id']),'new')
            self.assertEqual(store.baseline_status(baseline['agent_id']),'approved')
            target.chmod(0o644);current=copy.deepcopy(baseline);current.update(sequence=2,observed_at=time.time())
            current['integrity']=[asdict(c._posix_integrity_item(target,c._IntegrityBudget()))]
            app.ingest(current)
            actions=[a for a in store.pending_actions(baseline['agent_id']) if a.action_type=='restore_integrity']
            self.assertEqual(len(actions),1)
            result=executor.execute(actions[0].action_type,actions[0].parameters,current)
            self.assertTrue(result['success'],result);self.assertEqual(target.stat().st_mode&0o777,0o600)
