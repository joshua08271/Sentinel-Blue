"""Independent regression checks for R87-01..08.

Local filesystem and inotify tests use only TemporaryDirectory fixtures. Runtime
orchestration uses explicit doubles except for the real ledger/withdrawal test,
whose release gate and outside verifier are explicitly mocked. None certifies a
native service product, Windows, reboot, or a multi-host range.
"""
import contextlib
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import struct
import stat
import sys
import tempfile
import unittest
from unittest import mock
from datetime import timedelta

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from sentinel_blue import pack_acceptance as pa
from sentinel_blue.linux_service_catalog import CATALOG,entry
from acceptance_steps import Acceptance,Runtime
from acceptance_snapshot import SnapshotError,snapshot_paths
from acceptance_host import WriteWatch,stage_edit,restore_edit
from service_pack_acceptance import Executor,Report,probe_verdict
from test_pack_acceptance import passing_results
from test_acceptance_walk import walk,FakeHost,FakeRuntime,OPTIONS,PROFILE,INVENTORY


class ReceiptBindingTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.fp=pa.pack_fingerprint('redis',OPTIONS,self.root)
        self.runtime=pa.runtime_fingerprint()
        self.receipt=pa.build_receipt('redis',options=OPTIONS,results=passing_results(),
            product_version='observed-redis-7',fingerprint=self.fp,runtime=self.runtime,operator='SYNTHETIC TEST')
        pa.write(self.root,self.receipt)
        self.context={'redis':{'options':OPTIONS,'root':str(self.root),'product_version':'observed-redis-7'}}

    def test_current_context_matches_but_receipt_alone_never_counts(self):
        self.assertEqual(pa.summary(self.root,['redis'])['accepted'],[])
        self.assertEqual(pa.summary(self.root,['redis'],contexts=self.context)['accepted'],['redis'])

    def test_default_summary_rejects_old_runtime_without_explicit_arguments(self):
        self.receipt['runtime']='a'*64;pa.write(self.root,self.receipt)
        result=pa.summary(self.root,['redis'])
        self.assertEqual(result['accepted'],[]);self.assertEqual(result['stale'],['redis'])

    def test_current_options_change_invalidates_summary(self):
        self.context['redis']['options']={'bind_address':'127.0.0.2'}
        self.assertEqual(pa.summary(self.root,['redis'],contexts=self.context)['stale'],['redis'])

    def test_current_product_change_invalidates_summary(self):
        self.context['redis']['product_version']='observed-redis-8'
        self.assertEqual(pa.summary(self.root,['redis'],contexts=self.context)['stale'],['redis'])

    def test_missing_current_product_is_untested(self):
        self.context['redis'].pop('product_version')
        self.assertEqual(pa.summary(self.root,['redis'],contexts=self.context)['untested'],['redis'])

    def test_malformed_nested_steps_never_raise_or_count(self):
        for bad in ([],None,42,'passed',{'rollback':[]},{'apply':{'verdict':[]}}, {'extra':{}}):
            with self.subTest(value=bad):
                body=copy.deepcopy(self.receipt);body['steps']=bad;pa.write(self.root,body)
                result=pa.summary(self.root,['redis'],contexts=self.context)
                self.assertEqual(result['accepted'],[])
                self.assertFalse(result['states']['redis']['native_tested'])

    def test_malformed_other_fields_never_count(self):
        for name,bad in [('platform',[]),('options',[]),('product_version',{}),('runtime',3),
                         ('pack_fingerprint',True),('host_key',[]),('unit',None),('operator','')]:
            with self.subTest(field=name):
                value=copy.deepcopy(self.receipt);value[name]=bad;pa.write(self.root,value)
                self.assertEqual(pa.summary(self.root,['redis'],contexts=self.context)['accepted'],[])

    def test_legacy_schema_is_not_promoted(self):
        self.receipt['schema']=1;pa.write(self.root,self.receipt)
        self.assertEqual(pa.summary(self.root,['redis'],contexts=self.context)['accepted'],[])

    def test_expiration_is_exact_not_rounded_to_days(self):
        t=pa._parse_stamp(self.receipt['recorded_at'])+timedelta(days=180,seconds=1)
        self.assertEqual(pa.status(self.root,'redis',fingerprint=self.fp,runtime=self.runtime,
            product_version='observed-redis-7',moment=t)['state'],'stale')

    def test_platform_change_is_stale(self):
        self.receipt['platform']['version_id']='different';pa.write(self.root,self.receipt)
        self.assertEqual(pa.summary(self.root,['redis'],contexts=self.context)['stale'],['redis'])

    def test_doctor_does_not_claim_historical_receipt_current(self):
        from sentinel_blue.diagnostics import doctor
        row=next(c for c in doctor(self.root)['checks'] if c['name']=='service-pack-acceptance')
        self.assertIn('no current configuration/product context',row['detail'])

    def test_runtime_fingerprint_does_not_hash_invoking_test_script(self):
        with mock.patch.object(sys.modules['__main__'],'__file__',str(self.root/'unrelated.py'),create=True):
            (self.root/'unrelated.py').write_text('unrelated')
            self.assertEqual(pa.runtime_fingerprint(),self.runtime)

    def test_catalog_static_flags_unchanged(self):
        self.assertTrue(all(row['native_tested'] is False for row in CATALOG.values()))


class NativeSnapshotTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.tree=self.root/'data';self.tree.mkdir()
        self.file=self.tree/'important';self.file.write_text('original')

    def snap(self):return snapshot_paths([str(self.tree)])[str(self.tree)]

    def test_real_directory_child_content_change_is_detected(self):
        first=self.snap();self.file.write_text('modified');self.assertNotEqual(first,self.snap())

    def test_real_directory_child_deletion_is_detected(self):
        first=self.snap();self.file.unlink();self.assertNotEqual(first,self.snap())

    def test_real_directory_child_creation_is_detected(self):
        first=self.snap();(self.tree/'new').write_text('new');self.assertNotEqual(first,self.snap())

    def test_permissions_change_is_detected(self):
        first=self.snap();self.file.chmod(0o400);self.assertNotEqual(first,self.snap())

    def test_absent_file_is_not_directory_or_error(self):
        missing=str(self.root/'absent')
        self.assertEqual(snapshot_paths([missing])[missing],{'type':'absent'})
        self.assertEqual(self.snap()['type'],'directory')

    def test_io_error_is_not_absence(self):
        with mock.patch('acceptance_snapshot.os.open',side_effect=PermissionError('fixture')):
            with self.assertRaises((SnapshotError,PermissionError)):self.snap()

    def test_byte_budget_does_not_claim_unchanged(self):
        with self.assertRaises(SnapshotError):snapshot_paths([str(self.tree)],max_bytes=2)

    def test_entry_budget_does_not_claim_unchanged(self):
        with self.assertRaises(SnapshotError):snapshot_paths([str(self.tree)],max_entries=1)

    def test_depth_budget_does_not_claim_unchanged(self):
        nested=self.tree/'nested';nested.mkdir();(nested/'child').write_text('x')
        with self.assertRaises(SnapshotError):snapshot_paths([str(self.tree)],max_depth=0)

    def test_symlinked_parent_is_not_followed(self):
        link=self.root/'linked';link.symlink_to(self.tree,target_is_directory=True)
        with self.assertRaises(SnapshotError):snapshot_paths([str(link/'important')])

    def test_fifo_cannot_hang_capture(self):
        os.mkfifo(self.tree/'fifo')
        with self.assertRaises(SnapshotError):self.snap()

    def test_same_directory_contents_compare_equal(self):
        self.assertEqual(self.snap(),self.snap())


class NativeWriteAndEditTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.file=self.root/'owned.conf';self.file.write_text('original')

    def test_native_write_is_seen_even_when_bytes_are_restored(self):
        with WriteWatch([str(self.file)]) as watch:
            self.file.write_text('temporary invalid');self.file.write_text('original')
            self.assertEqual(watch.changed_paths(),[str(self.file)])

    def test_native_no_write_stays_empty(self):
        with WriteWatch([str(self.file)]) as watch:
            self.file.read_text();self.assertEqual(watch.changed_paths(),[])

    def test_unrelated_write_does_not_count(self):
        with WriteWatch([str(self.file)]) as watch:
            (self.root/'other').write_text('unrelated');self.assertEqual(watch.changed_paths(),[])

    def test_queue_overflow_is_incomplete_evidence(self):
        with WriteWatch([str(self.file)]) as watch:
            with mock.patch('acceptance_host.os.read',return_value=struct.pack('iIII',-1,0x4000,0,0)):
                with self.assertRaises(SnapshotError):watch.changed_paths()

    def test_atomic_replace_is_observed(self):
        with WriteWatch([str(self.file)]) as watch:
            new=self.root/'staged';new.write_text('new');new.replace(self.file)
            self.assertEqual(watch.changed_paths(),[str(self.file)])

    def test_owned_outside_edit_cleanup_preserves_original(self):
        self.file.chmod(0o600)
        before=snapshot_paths([str(self.file)])
        token=stage_edit(str(self.file),'\n# fixture\n',self.root/'private')
        self.assertIn('# fixture',self.file.read_text());self.assertTrue(restore_edit(token))
        self.assertEqual(snapshot_paths([str(self.file)]),before)

    def test_deleting_edited_file_refuses_cleanup(self):
        token=stage_edit(str(self.file),'\n# fixture\n',self.root/'private');self.file.unlink()
        with self.assertRaises(SnapshotError):restore_edit(token)
        self.assertFalse(self.file.exists());self.assertTrue(Path(token['backup']).exists())

    def test_changed_edited_file_refuses_cleanup(self):
        token=stage_edit(str(self.file),'\n# fixture\n',self.root/'private');self.file.write_text('third party')
        with self.assertRaises(SnapshotError):restore_edit(token)
        self.assertEqual(self.file.read_text(),'third party')


class AcceptanceJudgeTests(unittest.TestCase):
    def test_reapply_restart_with_unchanged_files_now_fails(self):
        with contextlib.redirect_stdout(io.StringIO()):report,*_=walk(runtime_fail=('reapply-restart',))
        self.assertEqual(report.results['identical-reapply']['verdict'],'failed')

    def test_outside_edit_deleted_file_now_fails(self):
        with contextlib.redirect_stdout(io.StringIO()):report,*_=walk(runtime_fail=('outside-delete',))
        self.assertEqual(report.results['outside-edit-refused']['verdict'],'failed')
        self.assertNotEqual(report.results['rollback']['verdict'],'passed')

    def test_failed_apply_without_observed_write_now_fails(self):
        with contextlib.redirect_stdout(io.StringIO()):report,*_=walk(runtime_fail=('no-write',))
        self.assertEqual(report.results['interrupted-setup']['verdict'],'failed')

    def test_builder_rejection_cannot_pass_interruption(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);inv=root/'inventory.json';inv.write_text(json.dumps(INVENTORY))
            host=FakeHost(files={'/fixture/config':'existing'})
            a=Acceptance(service_id='redis',row=entry('redis'),options=OPTIONS,profile=PROFILE,
                executor=host,runtime=mock.Mock(),workdir=root,inventory=inv,report=Report('redis'),fingerprint='a'*64)
            a.applied_ok=True;a.all_owned=['/fixture/config'];a.build_inventory=mock.Mock(side_effect=ValueError('plan refused'))
            with contextlib.redirect_stdout(io.StringIO()):a.interrupted_setup()
            self.assertEqual(a.report.results['interrupted-setup']['verdict'],'failed')
            a.runtime.apply.assert_not_called()

    def test_plan_rejection_cannot_pass_interruption(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);host=FakeHost(files={'/fixture/config':'existing'})
            rt=mock.Mock();rt.plan.return_value=({'returncode':1},None)
            a=Acceptance(service_id='redis',row=entry('redis'),options=OPTIONS,profile=PROFILE,
                executor=host,runtime=rt,workdir=root,inventory=None,report=Report('redis'),fingerprint='a'*64)
            a.applied_ok=True;a.all_owned=['/fixture/config'];a.build_inventory=mock.Mock(return_value=root/'unused')
            with contextlib.redirect_stdout(io.StringIO()):a.interrupted_setup()
            self.assertEqual(a.report.results['interrupted-setup']['verdict'],'failed');rt.apply.assert_not_called()

    def test_nginx_contract_uses_production_adapter(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);content=root/'page';content.write_text('exact website')
            opts={'name':'test','listen_address':'127.0.0.1','port':18088,
                  'content':{'path':str(content),'sha256':hashlib.sha256(content.read_bytes()).hexdigest()}}
            contract=pa.pack_contract('nginx',opts,root)
            self.assertEqual(contract['recipe'],'linux-nginx')
            self.assertIn('/etc/nginx/conf.d/sentinel-test.conf',[f['path'] for f in contract['files']])
            self.assertEqual(len(pa.pack_fingerprint('nginx',opts,root)),64)
            self.assertNotEqual(pa.pack_fingerprint('nginx',opts,root),pa.pack_fingerprint('nginx',{**opts,'port':18089},root))

    def test_probe_infrastructure_failure_is_not_denied_access(self):
        for extra in ({'returncode':-1},{'returncode':127,'infrastructure_error':True}, {'returncode':1,'truncated':True}):
            with self.subTest(extra=extra):
                ok,_=probe_verdict({'stdout':'','stderr':'','returncode':0,**extra},{'expect_failure':True})
                self.assertFalse(ok)

    def test_missing_effective_query_cannot_be_replaced_by_syntax_check(self):
        profile=copy.deepcopy(PROFILE);profile.pop('effective')
        with contextlib.redirect_stdout(io.StringIO()):report,*_=walk(profile=profile)
        self.assertEqual(report.results['effective-settings']['verdict'],'skipped')

    def test_missing_lifecycle_fields_fail_closed(self):
        ex=Executor()
        with mock.patch.object(ex,'run',return_value={'returncode':0,'stdout':'ActiveState=active\n'}):
            with self.assertRaises(SnapshotError):ex.service_state('test')

    def test_unrelated_setup_scope_is_refused(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);inv=root/'inventory.json'
            body=copy.deepcopy(INVENTORY);body['hosts'].append(dict(body['hosts'][0],name='other'));inv.write_text(json.dumps(body))
            a=Acceptance(service_id='redis',row=entry('redis'),options=OPTIONS,profile=PROFILE,executor=mock.Mock(),
                runtime=mock.Mock(),workdir=root,inventory=inv,report=Report('redis'),fingerprint='a'*64)
            with self.assertRaises(ValueError):a.build_inventory(OPTIONS,'copy.json')


class RealWithdrawalRoutingTests(unittest.TestCase):
    """Real parser/coordinator/ledger/files; only release gate & outside health are mocked."""
    def run_case(self, *, external=True, conflict=False, unexpected=False):
        from sentinel_blue import __main__ as cli,withdrawal
        from sentinel_blue.mutation_ledger import MutationLedger
        from sentinel_blue.withdrawal_native import NativeObjects,object_target
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup);root=Path(temp.name)
        ledger=MutationLedger(root/'ledger',host='lab')
        native=NativeObjects(ledger);file=root/'app.conf';file.write_text('original')
        target=object_target(files=[str(file)])
        ledger.mutate(native.name,target,lambda:file.write_text('sentinel'),snapshot=native.snapshot,
                      action_id='setup-test',ownership='configuration')
        if conflict:file.write_text('teammate')
        def request(name,args):return withdrawal.guest(args,ledger)
        coordinator=withdrawal.WithdrawalCoordinator({'lab':{}},request,root/'withdraw',
            verify=lambda:[{'healthy':True,'external':True}] if external else [])
        calls=[]
        class LocalCommandRouter:
            def run(self,argv,**kwargs):
                calls.append(argv)
                args=cli.parser().parse_args(argv[2:]);out=io.StringIO()
                try:
                    with mock.patch('sentinel_blue.event_profile.load_event_profile'),\
                         mock.patch.object(withdrawal,'coordinator_from_files',return_value=coordinator),\
                         contextlib.redirect_stdout(out):
                        rc=withdrawal.run(args)
                    return {'returncode':rc,'stdout':out.getvalue(),'stderr':''}
                except Exception as exc:
                    return {'returncode':2,'stdout':out.getvalue(),'stderr':str(exc)}
        rt=Runtime(LocalCommandRouter(),['python','fixture.pyz'],event_profile='fixture-profile.json')
        result=rt.withdraw('inventory.json',root/'withdraw',allowed_actions=set() if unexpected else {'setup-test'},expected_hosts=['lab'])
        return result,file,calls,ledger

    def test_actual_review_then_digest_execution_restores_real_file(self):
        result,file,calls,ledger=self.run_case()
        self.assertEqual(result['returncode'],0,result)
        self.assertEqual(file.read_text(),'original')
        self.assertEqual(len(calls),2)
        self.assertIn('--approved-digest',calls[1])
        self.assertEqual(calls[0][calls[0].index('--mode')+1],'restore-withdraw')
        self.assertEqual(ledger.actions()[0]['status'],'undone')

    def test_without_external_verification_no_acceptance(self):
        result,file,calls,ledger=self.run_case(external=False)
        self.assertNotEqual(result['returncode'],0)
        self.assertEqual(json.loads(result['stdout'])['status'],'held')

    def test_conflicting_real_file_is_not_overwritten(self):
        result,file,calls,ledger=self.run_case(conflict=True)
        self.assertNotEqual(result['returncode'],0)
        self.assertEqual(file.read_text(),'teammate')
        self.assertFalse(any('--approved-digest' in c for c in calls))
        self.assertTrue(any('--cancel-review' in c for c in calls))

    def test_unrelated_action_is_never_approved(self):
        result,file,calls,ledger=self.run_case(unexpected=True)
        self.assertNotEqual(result['returncode'],0)
        self.assertEqual(file.read_text(),'sentinel')
        self.assertFalse(any('--approved-digest' in c for c in calls))

    def test_remove_cannot_be_requested_as_rollback(self):
        rt=Runtime(mock.Mock(),['python','fixture.pyz'],event_profile='profile')
        with self.assertRaises(ValueError):rt.withdraw('i','d',mode='remove')
        rt.executor.run.assert_not_called()

    def test_review_only_zero_exit_is_not_completion(self):
        from sentinel_blue.mutation_ledger import digest
        review={'mode':'restore-withdraw','hosts':{'lab':{'inventory':{'actions':[]}}},'conflicts':[]}
        review['review_digest']=digest(review)
        ex=mock.Mock();ex.run.side_effect=[{'returncode':0,'stdout':json.dumps(review),'stderr':''},
                                         {'returncode':0,'stdout':json.dumps(review),'stderr':''}]
        result=Runtime(ex,['python','fixture.pyz'],event_profile='p').withdraw('i','d',expected_hosts=['lab'])
        self.assertNotEqual(result['returncode'],0)



class ReceiptAndDataHardeningTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)

    def test_unsafe_existing_receipt_directory_is_not_chmodded(self):
        folder=self.root/'acceptance';folder.mkdir(mode=0o755);folder.chmod(0o755)
        with self.assertRaises(ValueError):pa.write(self.root,{'service_id':'redis'})
        self.assertEqual(stat.S_IMODE(folder.stat().st_mode),0o755)

    def test_symlinked_receipt_directory_is_not_followed(self):
        target=self.root/'outside';target.mkdir();target.chmod(0o755)
        (self.root/'acceptance').symlink_to(target,target_is_directory=True)
        with self.assertRaises(ValueError):pa.write(self.root,{'service_id':'redis'})
        self.assertEqual(list(target.iterdir()),[])
        self.assertEqual(stat.S_IMODE(target.stat().st_mode),0o755)

    def test_missing_timestamp_never_raises(self):
        row=pa.build_receipt('redis',options=OPTIONS,results=passing_results(),
            fingerprint=pa.pack_fingerprint('redis',OPTIONS,self.root),runtime=pa.runtime_fingerprint(),
            product_version='fixture',operator='SYNTHETIC')
        row.pop('recorded_at');pa.write(self.root,row)
        self.assertEqual(pa.status(self.root,'redis')['state'],'untested')

    def test_forged_catalog_unit_never_counts(self):
        row=pa.build_receipt('redis',options=OPTIONS,results=passing_results(),
            fingerprint=pa.pack_fingerprint('redis',OPTIONS,self.root),runtime=pa.runtime_fingerprint(),
            product_version='fixture',operator='SYNTHETIC')
        row['unit']='unrelated.service';pa.write(self.root,row)
        self.assertEqual(pa.status(self.root,'redis')['state'],'untested')

    def test_nested_symlink_data_is_explicitly_incomplete(self):
        data=self.root/'data';data.mkdir();nested=data/'nested';nested.mkdir()
        target=self.root/'target';target.write_text('not traversed')
        (nested/'link').symlink_to(target)
        state=snapshot_paths([str(data)])[str(data)]
        self.assertEqual(state['symlink_count'],1)
        instance=Acceptance(service_id='redis',row={**entry('redis'),'data_paths':[str(data)]},
            options=OPTIONS,profile={},executor=Executor(),runtime=None,workdir=self.root,
            inventory=None,report=Report('redis'),fingerprint='a'*64)
        with self.assertRaises(SnapshotError):instance.data_snapshot()


class NewPrivateDirectoryTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.root.chmod(0o2700)

    def test_new_receipt_directory_clears_inherited_setgid_only_on_new_object(self):
        row=pa.build_receipt('redis',options=OPTIONS,results=passing_results(),
            fingerprint=pa.pack_fingerprint('redis',OPTIONS,self.root),runtime=pa.runtime_fingerprint(),
            product_version='fixture',operator='SYNTHETIC')
        pa.write(self.root,row)
        self.assertEqual(stat.S_IMODE((self.root/'acceptance').stat().st_mode),0o700)
        self.assertEqual(stat.S_IMODE(self.root.stat().st_mode),0o2700)
        self.assertEqual(pa.read(self.root,'redis'),row)

    def test_new_fixture_backup_is_private_below_setgid_parent(self):
        file=self.root/'config';file.write_text('original')
        token=stage_edit(str(file),'\n# test edit\n',self.root/'private')
        self.assertEqual(stat.S_IMODE((self.root/'private').stat().st_mode),0o700)
        self.assertEqual(stat.S_IMODE(self.root.stat().st_mode),0o2700)
        self.assertTrue(restore_edit(token));self.assertEqual(file.read_text(),'original')


if __name__ == "__main__":
    unittest.main()
