import copy
import json
import os
from pathlib import Path
import shutil
import tempfile
import unittest

from sentinel_blue.controller_restore import create_capsule, verify_capsule, restore_capsule
from sentinel_blue.recovery_ops import initialize_controller_recovery, controller_recovery_status
from sentinel_blue.mutation_ledger import MutationLedger, LedgerError
from sentinel_blue.store import Store
from sentinel_blue.event_profile import EventProfile


class RestoreWorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.root.chmod(0o700)
        self.db, self.anchor = self.root / 'controller.db', self.root / 'anchor'
        self.key = b'r' * 32
        self.profile = EventProfile.testing()
        self.profile_path = self.root / 'profile.json'
        self.profile_path.write_text(json.dumps(self.profile.raw))
        self.profile_path.chmod(0o600)
        self.backups = self.root / 'backups'
        self.backups.mkdir(mode=0o700)
        self.ledger = MutationLedger(self.root / 'ledger')
        self.ledger.append('fixture_owned_state', note='preserve exact chain')
        initialize_controller_recovery(self.db, self.anchor, self.key)
        self.store = Store(self.db)
        self.store.activate_release_binding(profile_id=self.profile.profile_id,
                    profile_fingerprint=self.profile.fingerprint, agent_version='1.9.74',
                    release_sha256='a' * 64, strict=True)
        self.store.load_governance(profile_fingerprint=self.profile.fingerprint,
                    default_mode='observe', strict=False, allowed_modes={'observe'})
        self.addCleanup(self.store.close)

    def backup(self):
        return create_capsule(self.store, self.backups, self.anchor, self.key,
                              artifacts={'event_profile': self.profile_path}, ledger_directory=self.ledger.directory)

    def restore(self, capsule, **kwargs):
        return restore_capsule(capsule['capsule'], self.db, self.anchor, self.key,
                               release_sha256='a' * 64, profile_fingerprint=self.profile.fingerprint,
                               ledger_directory=self.ledger.directory,
                               receipt_directory=self.root / 'receipt', **kwargs)

    def loss(self):
        self.store.close()
        self.db.unlink()

    def test_lost_database_and_ledger_complete_restore_is_paused(self):
        backup = self.backup()
        original = self.ledger.head()
        self.loss()
        shutil.rmtree(self.ledger.directory)
        result = self.restore(backup)
        self.assertEqual(result['phase'], 'complete')
        self.assertTrue(result['held'])
        self.assertEqual(MutationLedger(self.ledger.directory).head(), original)
        status = controller_recovery_status(self.db, self.anchor, self.key)
        self.assertTrue(status['ready'])
        self.assertEqual(status['recovery_generation'], 2)
        db = Store(self.db)
        try:
            self.assertTrue(json.loads(db._connection.execute("SELECT state_value FROM controller_state WHERE state_key='governance'").fetchone()[0])['emergency_stopped'])
        finally:
            db.close()
        self.assertEqual(self.restore(backup)['phase'], 'complete')

    def test_corrupt_database_preserved_before_recovery(self):
        backup = self.backup()
        self.loss()
        self.db.write_bytes(b'corrupted owned database')
        self.db.chmod(0o600)
        result = self.restore(backup)
        self.assertEqual(Path(result['preserved_database']).read_bytes(), b'corrupted owned database')

    def test_each_durable_crash_boundary_resumes_without_duplicate_generation(self):
        for boundary in ('prepared', 'anchor_pending', 'database_replaced', 'ledger_reconciled', 'anchor_committed'):
            with self.subTest(boundary=boundary):
                fixture = RestoreWorkflowTests('run')
                fixture.setUp()
                try:
                    backup = fixture.backup()
                    fixture.loss()
                    def crash(phase):
                        if phase == boundary:
                            raise InterruptedError('simulated crash')
                    with self.assertRaises(InterruptedError):
                        fixture.restore(backup, failpoint=crash)
                    self.assertEqual(fixture.restore(backup)['phase'], 'complete')
                    self.assertEqual(controller_recovery_status(fixture.db, fixture.anchor, fixture.key)['recovery_generation'], 2)
                finally:
                    fixture.doCleanups()

    def test_newer_valid_database_is_not_overwritten(self):
        backup = self.backup()
        self.store._connection.execute("INSERT INTO controller_state VALUES ('newer_valid','true',0)")
        self.store._connection.commit()
        self.store.close()
        before = self.db.read_bytes()
        with self.assertRaisesRegex(ValueError, 'different valid'):
            self.restore(backup)
        self.assertEqual(self.db.read_bytes(), before)

    def test_stale_backup_rejected(self):
        stale = self.backup()
        self.backup()
        self.loss()
        with self.assertRaisesRegex(ValueError, 'latest'):
            self.restore(stale)

    def test_capsule_wrong_release_profile_environment_rejected(self):
        backup = self.backup()
        for release, profile, key in [('b'*64, self.profile.fingerprint, self.key),
                                     ('a'*64, 'b'*64, self.key), ('a'*64, self.profile.fingerprint, b'x'*32)]:
            with self.subTest(release=release, profile=profile):
                with self.assertRaises(ValueError):
                    verify_capsule(backup['capsule'], self.anchor, key, release_sha256=release, profile_fingerprint=profile)

    def test_tampered_and_missing_input_rejected(self):
        backup = self.backup()
        path = Path(backup['capsule']) / 'inputs/event_profile'
        original = path.read_bytes()
        path.write_bytes(original + b' ')
        with self.assertRaisesRegex(ValueError, 'tampered'):
            self.restore(backup)
        path.unlink()
        with self.assertRaises(ValueError):
            self.restore(backup)

    def test_newer_withdrawal_chain_is_preserved(self):
        backup = self.backup()
        self.ledger.pause('partial-network-withdrawal')
        latest = self.ledger.head()
        self.loss()
        result = self.restore(backup)
        self.assertTrue(result['ledger_paused_after'])
        self.assertFalse(result['ready_for_observation'])
        self.assertEqual(self.ledger.head(), latest)

    def test_changed_ledger_key_and_truncated_chain_rejected(self):
        backup = self.backup()
        self.loss()
        self.ledger.events_path.write_bytes(b'')
        with self.assertRaises(LedgerError):
            self.restore(backup)

    def test_missing_anchor_is_never_fabricated(self):
        backup = self.backup()
        self.loss()
        self.anchor.unlink()
        with self.assertRaises(ValueError):
            self.restore(backup)
        self.assertFalse(self.anchor.exists())
