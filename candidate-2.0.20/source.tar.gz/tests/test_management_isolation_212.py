"""Dedicated-role regressions. Synthetic addresses, private fixtures only.

HTTP tests use real loopback HTTP with a controlled peer-address fixture; they
prove route/authentication behavior, not physical VM or network segmentation.
"""
import copy
import hashlib
import http.client
import json
import os
from pathlib import Path
import shutil
import socket
import tempfile
import threading
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import zipfile

from sentinel_blue import control_plane as cp, management_workspace as mw
from sentinel_blue.event_profile import EventProfile
from sentinel_blue.state import read_private_json, write_private_json, read_private_text
from test_service_manifest_policy import service_manifest

MANAGER='192.0.2.10'; WEB='192.0.2.11'; DB='192.0.2.12'


def fixture_profile():
    raw=copy.deepcopy(EventProfile.testing().raw)
    raw['scope']={'authorized_networks':['192.0.2.0/24','127.0.0.1/32'],
        'authorized_hosts':[MANAGER,WEB,DB,'127.0.0.1'],
        'controller_ingress_hosts':[MANAGER,WEB,DB,'127.0.0.1'],
        'excluded_hosts':[], 'approved_deployment_paths':['/tmp','/var/lib/sentinel-blue']}
    raw['services']=[service_manifest(host='web',expected_transactions=[{'name':'web','kind':'tcp','target':WEB,'port':80}]),
                     service_manifest('db.service',host='db',expected_transactions=[{'name':'db','kind':'tcp','target':DB,'port':5432}])]
    raw['services_confirmed']=True
    raw['deployment']['approved_routes']=['ssh','signed-bootstrap']
    raw['control_plane']={'mode':cp.MODE,'controller_address':MANAGER,'controller_port':8765,
        'operator_ingress_hosts':[MANAGER,'127.0.0.1'], 'agent_addresses':{'web':WEB,'db':DB},
        'separate_host_confirmed':True,'authorization_reference':'disposable isolated fixture'}
    return raw


def inventory():
    return {'authorized_networks':['192.0.2.0/24','127.0.0.1/32'], 'hosts':[
        {'name':'web','agent_id':'web','address':WEB,'platform':'linux','transport':'ssh','python':'/usr/bin/python3'},
        {'name':'db','agent_id':'db','address':DB,'platform':'linux','transport':'ssh','python':'/usr/bin/python3'}],
        'setup':{'tasks':[]}}


class ContractTests(unittest.TestCase):
    def test_legacy_profile_is_unchanged(self):
        p=EventProfile.testing()
        self.assertIsNone(cp.contract(p))
        self.assertTrue(cp.request_allowed(p,'GET','/',WEB))
        cp.validate_startup(p,'controller',SimpleNamespace())

    def test_explicit_contract_is_fingerprinted(self):
        p=fixture_profile(); first=EventProfile.from_dict(p)
        p['control_plane']['controller_port']=8766
        self.assertNotEqual(first.fingerprint,EventProfile.from_dict(p).fingerprint)

    def test_missing_confirmation_rejected(self):
        p=fixture_profile();p['control_plane']['separate_host_confirmed']=False
        with self.assertRaises(ValueError):EventProfile.from_dict(p)

    def test_same_controller_and_agent_address_rejected(self):
        p=fixture_profile();p['control_plane']['agent_addresses']['web']=MANAGER
        with self.assertRaises(ValueError):EventProfile.from_dict(p)

    def test_guest_cannot_be_operator(self):
        p=fixture_profile();p['control_plane']['operator_ingress_hosts'].append(WEB)
        with self.assertRaises(ValueError):EventProfile.from_dict(p)

    def test_duplicate_guest_address_rejected(self):
        p=fixture_profile();p['control_plane']['agent_addresses']['db']=WEB
        with self.assertRaises(ValueError):EventProfile.from_dict(p)

    def test_unsafe_role_addresses_rejected(self):
        for value in ('0.0.0.0','127.0.0.2','169.254.1.1','224.0.0.1','255.255.255.255','::1','2001:db8::1','host.invalid'):
            with self.subTest(value=value),self.assertRaises(ValueError):cp.address(value)

    def test_unknown_schema_or_agent_path_rejected(self):
        p=fixture_profile();p['control_plane']['extra']='unknown'
        with self.assertRaises(ValueError):EventProfile.from_dict(p)
        p=fixture_profile();p['control_plane']['agent_addresses']['../bad']=WEB
        with self.assertRaises(ValueError):EventProfile.from_dict(p)

    def test_management_scope_cannot_be_invented(self):
        p=fixture_profile();p['scope']['authorized_hosts'].remove(MANAGER)
        p['scope']['controller_ingress_hosts'].remove(MANAGER)
        with self.assertRaises(ValueError):EventProfile.from_dict(p)

    def test_external_controller_permission_required(self):
        p=fixture_profile();p['capabilities']['external_controller']=False
        with self.assertRaises(ValueError):EventProfile.from_dict(p)

    def test_service_check_cannot_point_at_management(self):
        p=fixture_profile();p['services'][0]['expected_transactions'][0]['target']=MANAGER
        with self.assertRaisesRegex(ValueError,'service endpoint'):EventProfile.from_dict(p)

    def test_no_unknown_or_controller_service_host(self):
        p=fixture_profile();p['services'][0]['host']='controller'
        with self.assertRaises(ValueError):EventProfile.from_dict(p)

    def test_inventory_cannot_target_management(self):
        p=EventProfile.from_dict(fixture_profile()); inv=inventory()
        cp.validate_inventory(inv,p,complete=True)
        inv['hosts'][0]['address']=MANAGER
        with self.assertRaises(ValueError):cp.validate_inventory(inv,p)

    def test_inventory_no_local_or_missing_identity(self):
        p=EventProfile.from_dict(fixture_profile()); inv=inventory()
        inv['hosts'][0]['transport']='local'
        with self.assertRaises(ValueError):cp.validate_inventory(inv,p)
        inv=inventory();inv['hosts'].pop()
        with self.assertRaises(ValueError):cp.validate_inventory(inv,p,complete=True)

    def test_controller_startup_checks_real_role_placement(self):
        p=EventProfile.from_dict(fixture_profile()); a=SimpleNamespace(bind=MANAGER,port=8765,syslog_bind=None)
        cp.validate_startup(p,'controller',a,observed_addresses={MANAGER})
        for own in ({WEB},{MANAGER,WEB},set()):
            with self.subTest(own=own),self.assertRaises(ValueError):cp.validate_startup(p,'controller',a,observed_addresses=own)
        a.bind='0.0.0.0'
        with self.assertRaises(ValueError):cp.validate_startup(p,'controller',a,observed_addresses={MANAGER})

    def test_agent_startup_checks_peer_and_placement(self):
        p=EventProfile.from_dict(fixture_profile());a=SimpleNamespace(agent_id='web',controller=f'https://{MANAGER}:8765')
        cp.validate_startup(p,'agent',a,observed_addresses={WEB})
        for own in ({DB},{MANAGER},{MANAGER,WEB}):
            with self.subTest(own=own),self.assertRaises(ValueError):cp.validate_startup(p,'agent',a,observed_addresses=own)
        for origin in (f'http://{MANAGER}:8765',f'https://{DB}:8765',f'https://{MANAGER}:8766',f'https://{MANAGER}:8765/?x=y'):
            a.controller=origin
            with self.subTest(origin=origin),self.assertRaises(ValueError):cp.validate_startup(p,'agent',a,observed_addresses={WEB})

    def test_guest_routes_are_scoped_to_own_identity(self):
        p=EventProfile.from_dict(fixture_profile())
        for route in ('/api/v1/agent/enroll','/api/v1/agent/telemetry','/api/v1/agent/actions','/api/v1/agent/results'):
            self.assertTrue(cp.request_allowed(p,'POST',route,WEB,'web'))
            self.assertFalse(cp.request_allowed(p,'POST',route,WEB,'db'))
            self.assertFalse(cp.request_allowed(p,'POST',route,MANAGER,'web'))
            self.assertFalse(cp.request_allowed(p,'POST',route,'192.0.2.99','web'))

    def test_guest_management_routes_refused(self):
        p=EventProfile.from_dict(fixture_profile())
        for route in ('/','/api/v1/dashboard','/api/v1/operator/auth-info','/api/v1/readiness',
                      '/api/v1/governance/emergency-stop','/api/v1/recording/chunk','/api/v1/observer/report'):
            self.assertFalse(cp.request_allowed(p,'GET',route,WEB,'web'))
            self.assertTrue(cp.request_allowed(p,'GET',route,MANAGER))
        self.assertTrue(cp.request_allowed(p,'GET','/api/v1/health',WEB))
        self.assertFalse(cp.request_allowed(p,'GET','/api/v1/health','192.0.2.99'))


class WorkspaceTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='sb212-');self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.runtime=self.root/'app.pyz'
        with zipfile.ZipFile(self.runtime,'w') as z:z.writestr('__main__.py','print("fixture")')
        p=fixture_profile();p.pop('control_plane')
        self.profile=EventProfile.from_dict(p)
        self.own=patch('sentinel_blue.control_plane.local_addresses',return_value={MANAGER})
        self.own.start();self.addCleanup(self.own.stop)

    def prepare(self):
        return mw.prepare(self.root/'work',self.runtime,inventory(),self.profile,MANAGER,8765,['127.0.0.1'],
                          confirmed=True,authorization_reference='fixture authorized management host')

    def finalized(self):
        config=self.prepare();path=Path(config['directory'])/'role.json'
        return path,mw.finalize(path,range_operator='fixture-operator')

    def test_prepare_never_starts_or_grants_live_approval(self):
        with patch('subprocess.Popen') as launch:
            config=self.prepare()
        launch.assert_not_called();d=Path(config['directory'])
        self.assertFalse((d/'master.json').exists())
        self.assertFalse((d/'controller.db').exists())
        self.assertEqual(load(d/'candidate-profile.json').approval['status'],'pending')
        self.assertFalse(load(d/'candidate-profile.json').release['approved'])

    def test_finalize_separates_secret_material(self):
        path,config=self.finalized();d=path.parent
        master=read_private_json(d/'master.json')['token'].encode();operator=(d/'operator.txt').read_bytes();key=(d/'recovery.key').read_bytes()
        tokens=[]
        for export in config['exports']:
            meta,profile,data=mw.read_join(export)
            self.assertEqual(set(data),set(mw.JOIN_FILES))
            combined=b'\n'.join(data.values())
            for secret in (master,operator,key,(d/'controller.key').read_bytes()):self.assertNotIn(secret,combined)
            self.assertEqual(meta['profile_fingerprint'],profile.fingerprint)
            tokens.append(json.loads(data['enrollment.json'])['token'])
            self.assertEqual(os.stat(export).st_mode&0o777,0o600)
        self.assertEqual(len(tokens),len(set(tokens)))
        self.assertTrue((d/'EXPORTS-SHA256.txt').is_file())

    def test_finalize_never_regenerates_issued_credentials(self):
        path,_=self.finalized();before=(path.parent/'master.json').read_bytes()
        with self.assertRaises(ValueError):mw.finalize(path,range_operator='second')
        self.assertEqual((path.parent/'master.json').read_bytes(),before)

    def test_modified_candidate_not_implicitly_approved(self):
        config=self.prepare();d=Path(config['directory'])
        raw=read_private_json(d/'candidate-profile.json');raw['control_plane']['controller_port']=8766
        write_private_json(d/'candidate-profile.json',raw)
        with self.assertRaises(ValueError):mw.finalize(d/'role.json',range_operator='fixture')
        self.assertFalse((d/'master.json').exists())

    def test_external_approval_cannot_change_topology(self):
        config=self.prepare();d=Path(config['directory']);raw=read_private_json(d/'candidate-profile.json')
        raw['control_plane']['controller_port']=8766;raw['approval']={'status':'range-only','approved_by':'fixture'}
        write_private_json(self.root/'approval.json',raw)
        with self.assertRaises(ValueError):mw.finalize(d/'role.json',approved_profile=self.root/'approval.json')

    def test_range_operator_cannot_approve_live_candidate(self):
        raw=copy.deepcopy(self.profile.raw);raw['environment']='live-competition';raw['competition']='custom';raw['autonomy_mode']='guarded-autonomous'
        for key in ('automatic_vm_replacement','scored_service_migration','network_forks'):
            raw['capabilities'][key]=False
        self.profile=EventProfile.from_dict(raw);config=self.prepare()
        with self.assertRaisesRegex(ValueError,'live profile'):mw.finalize(Path(config['directory'])/'role.json',range_operator='fixture')

    def test_role_builds_controller_without_local_agent(self):
        path,_=self.finalized();config,argv=mw.role_arguments(path)
        self.assertEqual(argv[0],'controller');self.assertIn('--supervise',argv);self.assertNotIn('agent',argv)
        self.assertIn(str(path.parent/'backups'),argv)
        self.assertNotIn('--auto-restore',argv)
        self.assertEqual(mw.connection(path)['principal'],'management-operator')

    def test_import_does_not_copy_management_secrets(self):
        path,config=self.finalized();package=next(x for x in config['exports'] if '/web.' in x)
        with patch('sentinel_blue.control_plane.local_addresses',return_value={WEB}):
            agent=mw.import_agent(self.root/'guests',self.runtime,package,expected_sha256=mw._digest(package))
            d=Path(agent['directory']);_,argv=mw.role_arguments(d/'role.json')
            self.assertEqual(argv[0],'agent')
            self.assertNotIn('--operator-token-file',argv);self.assertNotIn('--recovery-key-file',argv)
            self.assertFalse((d/'master.json').exists());self.assertFalse((d/'operator.txt').exists());self.assertFalse((d/'controller.db').exists())
            with self.assertRaises(ValueError):mw.connection(d/'role.json')

    def test_import_wrong_host_or_checksum_fails_before_writes(self):
        _,config=self.finalized();package=config['exports'][0]
        with self.assertRaises(ValueError):mw.import_agent(self.root/'bad',self.runtime,package,expected_sha256='0'*64)
        self.assertFalse((self.root/'bad').exists())
        with self.assertRaises(ValueError):mw.import_agent(self.root/'bad',self.runtime,package,expected_sha256=mw._digest(package))
        self.assertFalse((self.root/'bad').exists())

    def test_export_malicious_member_or_duplicate_rejected(self):
        _,config=self.finalized();package=config['exports'][0]
        for name in ('../controller.key','operator.txt','enrollment.json'):
            target=self.root/('bad-'+str(len(name))+'.zip');shutil.copyfile(package,target)
            with zipfile.ZipFile(target,'a') as z:z.writestr(name,b'foreign')
            with self.assertRaises(ValueError):mw.read_join(target)

    def test_export_profile_binding_and_probes_checked(self):
        _,config=self.finalized();package=config['exports'][0]
        with zipfile.ZipFile(package) as z:original={n:z.read(n) for n in z.namelist()}
        for name,content in [('controller-ca.crt',b'fake certificate'),('probes.json',b'{"probes":[],"protected_paths":["/etc/shadow"]}')]:
            data=dict(original);data[name]=content;target=self.root/'altered.zip'
            with zipfile.ZipFile(target,'w') as z:
                for n,b in data.items():z.writestr(n,b)
            with self.assertRaises(ValueError):mw.read_join(target)

    def test_hash_and_import_use_one_snapshot(self):
        _,config=self.finalized();package=config['exports'][0];digest=mw._digest(package)
        actual=mw._join_bytes
        def swapped(path):
            data=actual(path)
            Path(path).write_bytes(b'changed-after-read')
            return data
        with patch.object(mw,'_join_bytes',side_effect=swapped) as read, patch(
                'sentinel_blue.control_plane.local_addresses',return_value={DB}):
            # Exports are sorted db, web. The original db bytes, not the changed
            # pathname, are used by both verification and decoding.
            config=mw.import_agent(self.root/'single-read',self.runtime,package,expected_sha256=digest)
        self.assertEqual(config['agent_id'],'db');self.assertEqual(read.call_count,1)

    def test_finalize_holds_exclusive_role_lock(self):
        from sentinel_blue.state import AgentProcessLock
        config=self.prepare();path=Path(config['directory'])/'role.json'
        lock=AgentProcessLock(path.parent).acquire()
        try:
            with self.assertRaises((RuntimeError,ValueError,OSError)):
                mw.finalize(path,range_operator='fixture')
        finally:lock.close()
        self.assertFalse((path.parent/'master.json').exists())

    def test_join_rejects_fifo_and_symlink_without_blocking(self):
        _,config=self.finalized();package=Path(config['exports'][0])
        link=self.root/'join-link';link.symlink_to(package)
        with self.assertRaises((OSError,ValueError)):mw.read_join(link)
        fifo=self.root/'join-fifo';os.mkfifo(fifo)
        with self.assertRaises((OSError,ValueError)):mw.read_join(fifo)

    def test_symlink_parent_rejected(self):
        (self.root/'alias').symlink_to(self.root/'somewhere')
        with self.assertRaises(ValueError):mw.prepare(self.root/'alias',self.runtime,inventory(),self.profile,MANAGER,
            confirmed=True,authorization_reference='fixture')

    def test_existing_windows_and_local_profile_remain_outside_opt_in(self):
        cp.validate_inventory({'hosts':[{'platform':'windows','address':MANAGER}]},EventProfile.testing())
        with patch('sentinel_blue.control_plane.local_addresses',side_effect=AssertionError('must not inspect')):
            cp.validate_startup(EventProfile.testing(),'agent',SimpleNamespace())


def load(path):
    from sentinel_blue.event_profile import load_event_profile
    return load_event_profile(path)


class HTTPRoleTests(unittest.TestCase):
    def profile_raw(self):
        return fixture_profile()

    def setUp(self):
        from sentinel_blue.controller import ControllerApp, make_handler, ControllerServer
        from sentinel_blue.store import Store
        self.store=Store(':memory:');self.addCleanup(self.store.close)
        self.app=ControllerApp(self.store,'m'*48,operator_token='o'*48,event_profile=EventProfile.from_dict(self.profile_raw()))
        base=make_handler(self.app)
        class Handler(base):
            def setup(handler):
                super().setup()
                handler.client_address=(self.peer,handler.client_address[1])
        self.server=ControllerServer(('127.0.0.1',0),Handler)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.addCleanup(self.server.server_close);self.addCleanup(self.thread.join,2);self.addCleanup(self.server.shutdown)
        self.peer=WEB
    def request(self,path,headers=None,method='GET',body=None):
        c=http.client.HTTPConnection('127.0.0.1',self.server.server_address[1],timeout=5)
        try:
            c.request(method,path,body=body,headers=headers or {});r=c.getresponse();return r.status,r.read()
        finally:c.close()
    def test_guest_cannot_fetch_dashboard_readiness_or_auth_info(self):
        for path in ('/api/v1/dashboard','/api/v1/readiness','/api/v1/operator/auth-info','/'):
            self.assertEqual(self.request(path)[0],403)
    def test_forwarded_header_cannot_grant_operator_access(self):
        self.assertEqual(self.request('/api/v1/dashboard',{'X-Forwarded-For':MANAGER})[0],403)
    def test_management_still_requires_operator_signature(self):
        self.peer=MANAGER
        self.assertEqual(self.request('/api/v1/dashboard')[0],401)
        self.assertEqual(self.request('/api/v1/operator/auth-info')[0],200)
    def test_agent_signature_still_required_for_own_route(self):
        self.assertEqual(self.request('/api/v1/agent/actions?agent_id=web',{'X-SB-Agent':'web'})[0],401)
        self.assertEqual(self.request('/api/v1/agent/actions?agent_id=db',{'X-SB-Agent':'db'})[0],403)
    def test_guest_management_post_rejected_before_body_reader(self):
        with patch.object(self.server.RequestHandlerClass,'_read_body',side_effect=AssertionError('must reject before body')):
            status,_=self.request('/api/v1/governance/emergency-stop',method='POST',body=b'{}')
        self.assertEqual(status,403)
    def test_unknown_peer_health_rejected(self):
        self.peer='192.0.2.99';self.assertEqual(self.request('/api/v1/health')[0],403)
        self.peer=WEB;self.assertEqual(self.request('/api/v1/health')[0],200)



class SignedIsolationTests(HTTPRoleTests):
    def profile_raw(self):
        # Set release binding before ControllerApp initializes its persistent
        # authority, exactly as the real prepared workspace does.
        raw=fixture_profile()
        raw['release'].update(sha256='a'*64,controller_ca_sha256='b'*64)
        return raw

    def client(self,aid,peer):
        from sentinel_blue.agent import AgentClient
        from sentinel_blue.auth import derive_enrollment_ticket
        self.peer=peer
        p=self.app.event_profile
        client=AgentClient(f'http://127.0.0.1:{self.server.server_port}',
            derive_enrollment_ticket(self.app.token,p.fingerprint,aid),aid,
            profile_id=p.profile_id,profile_fingerprint=p.fingerprint)
        client.enroll(aid,'Linux')
        return client

    def test_two_agents_have_distinct_tokens_and_independent_delivery(self):
        web=self.client('web',WEB);db=self.client('db',DB)
        self.assertNotEqual(web.agent_token,db.agent_token)
        self.assertEqual(db.actions(),[])
        self.peer=WEB;self.assertEqual(web.actions(),[])
        del web  # No more requests from the failed/disconnected client.
        self.peer=DB;self.assertEqual(db.actions(),[])
        self.assertIsNotNone(self.store.agent_http_auth_snapshot('web'))
        self.assertIsNotNone(self.store.agent_http_auth_snapshot('db'))

    def test_valid_operator_key_is_still_denied_from_defended_peer(self):
        from sentinel_blue.desktop_control import DesktopClient
        client=DesktopClient(f'http://127.0.0.1:{self.server.server_port}','operator',1,'o'*48)
        self.peer=MANAGER
        self.assertIsInstance(client.dashboard(),dict)
        self.peer=WEB
        with self.assertRaisesRegex(RuntimeError,'403'):client.dashboard()

    def test_other_agent_token_does_not_override_peer_binding(self):
        db=self.client('db',DB)
        self.peer=WEB
        with self.assertRaises((ValueError,RuntimeError)):db.actions()


@unittest.skipUnless(os.name=='posix' and os.environ.get('DISPLAY'),'Tk display unavailable')
class IsolationGUI(unittest.TestCase):
    def test_new_dialog_opens_without_starting_a_process(self):
        import tkinter as tk
        from sentinel_blue.desktop import DesktopWindow
        with tempfile.TemporaryDirectory(prefix='sb212-gui-') as td:
            root=tk.Tk();app=None
            try:
                with patch('sentinel_blue.linux_workspace.local_observation',return_value={'observation':{'complete':True,'listeners':[]},'addresses':[MANAGER],'presence':{}}):
                    app=DesktopWindow(root,directory=td)
                    with patch('subprocess.Popen') as spawn:
                        app.dedicated_management()
                        root.update()
                    spawn.assert_not_called()
                    dialogs=[x for x in root.winfo_children() if isinstance(x,tk.Toplevel)]
                    self.assertTrue(dialogs)
                    self.assertIn('Dedicated',dialogs[0].title())
                    dialogs[0].destroy()
            finally:
                if app:app.close()
                try:root.destroy()
                except tk.TclError:pass


class RoleProcessTests(unittest.TestCase):
    def test_stop_uses_exact_identity_not_pid_only(self):
        from sentinel_blue import management_role as role
        identity={'process_id':12345,'fixture':'identity'}
        with patch.object(role,'status',return_value={'alive':True,'identity':identity}),patch.object(role,'signal_verified_process') as signal:
            result=role.stop('/private/role.json')
        signal.assert_called_once_with(12345,identity,'terminate')
        self.assertEqual(result['state'],'stop-requested')

    def test_stale_role_is_not_signaled(self):
        from sentinel_blue import management_role as role
        with patch.object(role,'status',return_value={'alive':False}),patch.object(role,'signal_verified_process') as signal:
            with self.assertRaises(ValueError):role.stop('/private/role.json')
        signal.assert_not_called()

    def test_duplicate_start_is_not_retried(self):
        from sentinel_blue import management_role as role
        with patch.object(role,'role_arguments',return_value=({'directory':'/private'},[])),patch.object(role,'status',return_value={'alive':True}),patch('sentinel_blue.desktop_jobs.detach') as launch:
            with self.assertRaises(ValueError):role.start('/private/role.json')
        launch.assert_not_called()

if __name__ == '__main__':
    unittest.main()
