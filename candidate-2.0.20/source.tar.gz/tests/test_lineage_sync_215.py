"""2.0.15 regressions for the 2.0.14 review findings R214-01, R214-01b, R214-02, R214-03.

Real on-disk SQLite, real private agent state files, real signed loopback HTTP
and the vendor's own offline-authority fixture. Native service transitions and
probes remain the inert fixtures of test_automatic_undo_214; this is not a live
VM, reboot or competition exercise.
"""
import copy
import json
import os
from pathlib import Path
import stat
import tarfile
import tempfile
import threading
import time
from types import SimpleNamespace
import unittest
import uuid
from unittest.mock import patch
from urllib.error import HTTPError

from sentinel_blue.agent import AgentClient
from sentinel_blue.controller import ControllerApp, ControllerServer, make_handler
from sentinel_blue.desktop_control import DesktopClient
from sentinel_blue.event_profile import EventProfile
from sentinel_blue.service_automation import (
    LocalAutomation, REPORT_PARAMETER, agent_report, controller_refusal, empty, migrate_lineage,
    parse_report, record_report, snapshot, sync_status, update, update_with_details)
from sentinel_blue.store import Store
from test_autonomous_service_recovery import fixtures
from test_automatic_undo_214 import AutomaticStartFixture

SOURCE_ROOT = Path(__file__).resolve().parents[1]
REAL_LINUX = 'Linux 6.18.44-fc-v37'  # what collectors.py reports: system + release


def reapproved(profile, *, drop=None, add_second=False):
    raw = copy.deepcopy(profile.raw)
    raw['services'][0]['approval_actions'].append('rollback_service_repair')
    if add_second:
        second = copy.deepcopy(raw['services'][0]); second['service_id'] = 'second.service'
        raw['services'].append(second)
    if drop:
        raw['services'] = [s for s in raw['services'] if s['service_id'] != drop]
    return EventProfile.from_dict(raw)


def with_second(profile):
    raw = copy.deepcopy(profile.raw)
    second = copy.deepcopy(raw['services'][0]); second['service_id'] = 'second.service'
    raw['services'].append(second)
    return EventProfile.from_dict(raw)


def audits(store, operation):
    return [json.loads(r['detail_json']) for r in store._connection.execute(
        'SELECT detail_json FROM audit_log WHERE operation=? ORDER BY created_at', (operation,)).fetchall()]


class Rig:
    """A controller over the preserved database plus the agent's preserved state."""

    def __init__(self, root, profile, baseline):
        self.store = Store(root / 'controller.db')
        self.app = ControllerApp(self.store, 't' * 32, operator_token='o' * 32, event_profile=profile)
        fresh = copy.deepcopy(baseline); fresh['observed_at'] = time.time()
        fresh['sequence'] = int(time.time() * 1000) % 1_000_000_000
        self.app.ingest(fresh)
        self.server = ControllerServer(('127.0.0.1', 0), make_handler(self.app))
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True); self.thread.start()
        url = f'http://127.0.0.1:{self.server.server_port}'
        self.client = AgentClient(url, '', 'agent-one', agent_token=self.store.ensure_agent_secret('agent-one'),
                                  profile_id=profile.profile_id, profile_fingerprint=profile.fingerprint)
        self.client.service_automation = LocalAutomation(root / 'agent', profile, 'agent-one')
        self.gui = DesktopClient(url, 'operator', 1, 'o' * 32)

    def close(self):
        self.server.shutdown(); self.server.server_close(); self.thread.join(3); self.store.close()


@unittest.skipUnless(os.environ.get('DISPLAY'), 'Tk display unavailable')
class StaleControllerGUI(unittest.TestCase):
    """Real Tk callbacks: the History / undo tab shows the agent floor, and Pause re-synchronizes."""

    def setUp(self):
        from test_automatic_undo_214 import AutomationGUIControls
        holder = AutomationGUIControls('test_cancel_and_missing_reason_do_not_change_automation')
        holder.setUp(); self.addCleanup(holder.doCleanups)
        self.f = holder.f

    def test_dialog_shows_agent_floor_and_pause_resynchronizes(self):
        backend = self.f.backend
        record_report(backend.app, 'agent-one', {REPORT_PARAMETER: [json.dumps(
            {'revision': 6, 'behind': True, 'held': {'web.service': time.time()}, 'latches': {}, 'truncated': False})]})
        dialog = self.f.dialog; dialog.refresh_history()
        text = dialog.automation_status.get()
        self.assertIn('AGENT HOLDS AUTOMATIC RECOVERY', text); self.assertIn('revision 6', text)
        dialog.reason.set('Reviewed after controller restore')
        with patch.object(self.f.gui.messagebox, 'askyesno', return_value=True):
            dialog.change_automation(True)
        state = snapshot(backend.store, backend.profile, 'agent-one')
        self.assertEqual(state['revision'], 7); self.assertTrue(state['services']['web.service']['paused'])
        self.assertIn('Re-synchronized', dialog.status.get())
        self.assertNotIn('AGENT HOLDS', dialog.automation_status.get())
        self.assertIn('PAUSED', dialog.automation_status.get())


class ProfileLineageTests(unittest.TestCase):
    """R214-01: a re-approved profile must not strand agents or break the dashboard."""

    def setUp(self):
        td = tempfile.TemporaryDirectory(prefix='sb215-lineage-'); self.addCleanup(td.cleanup)
        self.root = Path(td.name); (self.root / 'agent').mkdir(mode=0o700)
        self.p1, self.baseline = fixtures()

    def rig(self, profile):
        rig = Rig(self.root, profile, self.baseline); self.addCleanup(rig.close)
        return rig

    def local_file(self):
        return json.loads((self.root / 'agent' / 'service-automation.json').read_text())

    def test_agent_that_never_paused_keeps_polling_after_reapproval(self):
        first = self.rig(self.p1)
        self.assertEqual(first.client.actions(), [])
        self.assertEqual(self.local_file()['snapshot']['profile_fingerprint'], self.p1.fingerprint)
        first.close()
        p2 = reapproved(self.p1); self.assertNotEqual(p2.fingerprint, self.p1.fingerprint)
        second = self.rig(p2)
        self.assertEqual(second.client.actions(), [])
        self.assertEqual(self.local_file()['snapshot']['profile_fingerprint'], p2.fingerprint)
        self.assertIsNone(LocalAutomation(self.root / 'agent', p2, 'agent-one').refusal(
            'restart_service', {'service': 'web.service'}))

    def test_paused_service_and_undo_latch_are_carried_into_the_new_lineage(self):
        first = self.rig(self.p1)
        txn = str(uuid.uuid4())
        update(first.store, self.p1, 'agent-one', 'web.service', True, 'operator undo hold', transaction_id=txn)
        first.client.actions()
        first.client.service_automation.latch('web.service', txn)
        old = snapshot(first.store, self.p1, 'agent-one')
        first.close()
        p2 = reapproved(self.p1)
        second = self.rig(p2)
        carried = snapshot(second.store, p2, 'agent-one')
        # The revision is kept (no move past any agent floor without an operator decision).
        self.assertEqual(carried['revision'], old['revision'])
        self.assertNotEqual(carried['profile_fingerprint'], old['profile_fingerprint'])
        self.assertEqual(carried['services'], old['services'])
        record = audits(second.store, 'migrate_service_automation_lineage')[-1]
        self.assertEqual(record['paused_services_carried'], ['web.service'])
        self.assertEqual(second.client.actions(), [])
        local = LocalAutomation(self.root / 'agent', p2, 'agent-one')
        self.assertEqual(local.read()['latches']['web.service']['transaction_id'], txn)
        self.assertIn('undo', local.refusal('restart_service', {'service': 'web.service'}))
        # The whole-controller surfaces keep working, per agent.
        self.assertIn('actions', second.gui.dashboard())
        row = next(r for r in second.app.setup_redo_policy()['services'] if r['service'] == 'web.service')
        self.assertTrue(any('paused' in hold for hold in row['holds']))
        paused = second.app.set_service_automation({'agent_id': 'agent-one', 'service': 'web.service', 'paused': True,
            'reason': 'confirm the hold under the new profile', 'expected_revision': carried['revision']}, 'operator')
        self.assertEqual(paused['service_automation']['revision'], carried['revision'] + 1)
        self.assertIsNone(paused['resynchronization']['resynchronized_from_agent_floor'])

    def test_service_no_longer_approved_is_dropped_with_audit_evidence(self):
        p1 = with_second(self.p1)
        first = self.rig(p1)
        update(first.store, p1, 'agent-one', 'web.service', True, 'hold web')
        update(first.store, p1, 'agent-one', 'second.service', True, 'hold second')
        first.client.actions()
        first.client.service_automation.latch('second.service', str(uuid.uuid4()))
        first.close()
        p2 = reapproved(p1, drop='second.service')
        second = self.rig(p2)
        self.assertEqual(set(snapshot(second.store, p2, 'agent-one')['services']), {'web.service'})
        self.assertEqual(audits(second.store, 'migrate_service_automation_lineage')[-1]['services_no_longer_approved'],
                         ['second.service'])
        self.assertEqual(second.client.actions(), [])
        data = LocalAutomation(self.root / 'agent', p2, 'agent-one').read()
        self.assertEqual(set(data['snapshot']['services']), {'web.service'})
        self.assertEqual(data['latches'], {})
        self.assertTrue(data['snapshot']['services']['web.service']['paused'])

    def test_unreadable_record_holds_only_its_agent_and_is_never_replaced(self):
        first = self.rig(self.p1)
        update(first.store, self.p1, 'agent-one', 'web.service', True, 'hold before corruption')
        first.store._connection.execute(
            "UPDATE controller_state SET state_value='{' WHERE state_key='service_automation:agent-one'")
        first.store._connection.commit()
        first.close()
        second = self.rig(reapproved(self.p1))
        value = second.store._connection.execute(
            "SELECT state_value FROM controller_state WHERE state_key='service_automation:agent-one'").fetchone()[0]
        self.assertEqual(value, '{')
        self.assertIn('actions', second.gui.dashboard())
        row = next(r for r in second.app.service_recovery_status({}) if r['service'] == 'web.service')
        self.assertIn('unreadable', row['status'])
        policy = second.app.setup_redo_policy()
        self.assertTrue(any('unreadable' in h for r in policy['services'] for h in r['holds']))
        with self.assertRaises(HTTPError) as raised:
            second.client.actions()
        self.assertEqual(raised.exception.code, 409)


class UnreadableStateDoesNotBreakIngest(AutomaticStartFixture):
    def test_automatic_planning_is_held_without_failing_telemetry(self):
        update(self.store, self.profile, 'agent-one', 'web.service', False, 'recorded decision')
        self.store._connection.execute(
            "UPDATE controller_state SET state_value='[]' WHERE state_key='service_automation:agent-one'")
        self.store._connection.commit()
        for seq in (2, 3):
            self.app.ingest(__import__('test_autonomous_service_recovery').stopped(self.baseline, seq))
        self.assertFalse([a for a in self.store.dashboard()['actions'] if a['action_type'] == 'restart_service'])
        self.assertTrue(any('unreadable' in d.get('reason', '') for d in audits(self.store, 'hold_automatic_recovery')))


class StaleControllerTests(AutomaticStartFixture):
    """R214-01b: a controller behind the agent's floor holds automation only."""

    def setUp(self):
        super().setUp()
        self.server = ControllerServer(('127.0.0.1', 0), make_handler(self.app))
        thread = threading.Thread(target=self.server.serve_forever, daemon=True); thread.start()
        self.addCleanup(self.server.server_close); self.addCleanup(thread.join, 3); self.addCleanup(self.server.shutdown)
        self.client = AgentClient(f'http://127.0.0.1:{self.server.server_port}', '', 'agent-one',
                                  agent_token=self.store.ensure_agent_secret('agent-one'),
                                  profile_id=self.profile.profile_id, profile_fingerprint=self.profile.fingerprint)
        self.client.service_automation = self.local

    def advance_floor(self):
        for paused in (True, False, True, False):
            update(self.store, self.profile, 'agent-one', 'web.service', paused, 'operator decision before restore')
            self.client.actions()
        self.assertEqual(self.local.read()['snapshot']['revision'], 4)
        # The controller database is restored from a backup taken before them.
        self.store._connection.execute("DELETE FROM controller_state WHERE state_key='service_automation:agent-one'")
        self.store._connection.commit()

    def test_manual_work_still_delivered_and_automatic_recovery_held(self):
        self.advance_floor()
        manual = self.store.queue_action('agent-one', 'validate_service', {
            'service': 'web.service', 'probes': copy.deepcopy(self.profile.services[0]['expected_transactions'])},
            automated=False)
        delivered = self.client.actions()
        self.assertEqual([a['action_id'] for a in delivered], [manual])
        self.assertEqual(self.local.read()['snapshot']['revision'], 4)
        self.assertEqual(self.local.sync(), {'schema': 1, 'controller_revision': 0, 'floor_revision': 4})
        self.assertIn('durable floor', self.local.refusal('restart_service', {'service': 'web.service'}))
        self.assertIsNone(self.local.refusal('validate_service', {'service': 'web.service'}))
        # The controller sees the floor on the signed poll and shows/holds it.
        control = snapshot(self.store, self.profile, 'agent-one')
        status = sync_status(self.app, 'agent-one', control)
        self.assertTrue(status['behind']); self.assertEqual(status['agent_floor_revision'], 4)
        self.assertIn('durable floor', controller_refusal(self.app, 'agent-one', 'restart_service', {'service': 'web.service'}))
        row = next(r for r in self.app.service_recovery_status({}) if r['service'] == 'web.service')
        self.assertIn('Agent holds automatic recovery', row['status'])
        history = self.app.service_action_history({'agent_id': 'agent-one', 'service': 'web.service'})
        self.assertTrue(history['automation_sync']['behind']); self.assertFalse(history['automatic_recovery_enabled'])
        # Planning does not queue automatic work the agent would refuse.
        for seq in (5, 6):
            self.fresh_stopped(seq)
        self.assertFalse([a for a in self.store.dashboard()['actions']
                          if a['action_type'] == 'restart_service' and a['status'] == 'queued'])

    def test_one_explicit_operator_decision_resynchronizes(self):
        self.advance_floor()
        self.client.actions()
        result = self.app.set_service_automation({'agent_id': 'agent-one', 'service': 'web.service', 'paused': True,
            'reason': 'reviewed after controller restore', 'expected_revision': 0}, 'operator')
        self.assertEqual(result['service_automation']['revision'], 5)
        self.assertEqual(result['resynchronization']['resynchronized_from_agent_floor'], 4)
        self.assertEqual(self.client.actions(), [])
        self.assertIsNone(self.local.sync())
        self.assertEqual(self.local.read()['snapshot']['revision'], 5)
        self.assertFalse(sync_status(self.app, 'agent-one', snapshot(self.store, self.profile, 'agent-one'))['behind'])
        self.resume(); self.client.actions()
        self.assertIsNone(self.local.refusal('restart_service', {'service': 'web.service'}))

    def test_restored_controller_cannot_silently_unpause(self):
        update(self.store, self.profile, 'agent-one', 'web.service', True, 'hold that the backup never saw')
        self.client.actions()
        self.store._connection.execute("DELETE FROM controller_state WHERE state_key='service_automation:agent-one'")
        self.store._connection.commit()
        update(self.store, self.profile, 'agent-one', 'web.service', False, 'restored controller says resumed')
        self.assertEqual(snapshot(self.store, self.profile, 'agent-one')['revision'], 1)
        self.client.actions()  # equal revision, conflicting content
        self.assertIsNotNone(self.local.sync())
        self.assertTrue(self.local.read()['snapshot']['services']['web.service']['paused'])
        self.assertIsNotNone(self.local.refusal('restart_service', {'service': 'web.service'}))

    def test_undo_approval_after_restore_carries_holds_and_matches_latch(self):
        for paused in (True, False):
            update(self.store, self.profile, 'agent-one', 'web.service', paused, 'decision before restore')
        self.client.actions()
        identifier, _ = self.forward()
        self.client.actions()
        self.store._connection.execute("DELETE FROM controller_state WHERE state_key='service_automation:agent-one'")
        self.store._connection.commit()
        floor = self.local.read()['snapshot']['revision']
        self.client.actions()
        undo_id, result = self.undo(identifier)
        self.assertTrue(result['success'], result)
        state = snapshot(self.store, self.profile, 'agent-one')
        self.assertGreater(state['revision'], floor)
        self.assertTrue(state['services']['web.service']['paused'])
        self.assertTrue(audits(self.store, 'resynchronize_service_automation'))
        latch = self.local.read()['latches']['web.service']['transaction_id']
        self.assertEqual(state['services']['web.service']['transaction_id'], latch)
        self.assertIsNone(self.local.sync())


class TwoServiceRestoreTests(unittest.TestCase):
    """Review of the first 2.0.15 candidate: a restored controller must never drop another service's pause.

    Real signed loopback HTTP, the on-disk controller database and the agent's
    preserved state directory. `second.service` is paused before the restore;
    the backup does not know that pause.
    """

    def setUp(self):
        td = tempfile.TemporaryDirectory(prefix='sb215-restore-'); self.addCleanup(td.cleanup)
        self.root = Path(td.name); (self.root / 'agent').mkdir(mode=0o700)
        base, self.baseline = fixtures(); self.profile = with_second(base)
        self.rig = self.start(self.profile)
        update(self.rig.store, self.profile, 'agent-one', 'second.service', True, 'operator hold the backup never saw')
        self.rig.client.actions()
        self.assertTrue(self.held('second.service'))
        self.rig.store._connection.execute("DELETE FROM controller_state WHERE state_key='service_automation:agent-one'")
        self.rig.store._connection.commit()

    def start(self, profile):
        rig = Rig(self.root, profile, self.baseline); self.addCleanup(rig.close)
        return rig

    def local(self, profile=None):
        return LocalAutomation(self.root / 'agent', profile or self.profile, 'agent-one')

    def held(self, service, profile=None):
        return self.local(profile).refusal('restart_service', {'service': service}) is not None

    def decide(self, rig, service, paused, reason):
        control = snapshot(rig.store, rig.app.event_profile, 'agent-one')
        if paused:
            return rig.app.set_service_automation({'agent_id': 'agent-one', 'service': service, 'paused': True,
                'reason': reason, 'expected_revision': control['revision']}, 'operator')
        # The signed Resume API additionally requires an approved baseline and
        # fresh evidence (covered by test_automatic_undo_214); this fixture has
        # none, so call the same persistence step the API uses after its checks.
        state, details = update_with_details(rig.store, rig.app.event_profile, 'agent-one', service, False, reason,
                                             expected_revision=control['revision'],
                                             report=agent_report(rig.app, 'agent-one'))
        return {'service_automation': state, 'resynchronization': details}

    def test_resync_right_after_the_first_post_restore_poll_carries_the_hold(self):
        self.rig.client.actions()  # the first poll after the restore
        status = sync_status(self.rig.app, 'agent-one', snapshot(self.rig.store, self.profile, 'agent-one'))
        self.assertTrue(status['behind']); self.assertEqual(status['agent_held'], ['second.service'])
        result = self.decide(self.rig, 'web.service', True, 'reviewed after restore')
        self.assertEqual(result['resynchronization']['carried_forward'], ['second.service'])
        self.rig.client.actions()
        self.assertIsNone(self.local().sync())
        self.assertTrue(self.held('second.service'))

    def test_profile_reapprovals_after_restore_do_not_move_past_the_floor(self):
        profile = self.profile
        for _ in range(2):
            self.rig.close()
            profile = reapproved(profile)
            self.rig = self.start(profile)
            self.rig.client.actions()
            self.assertTrue(self.held('second.service', profile))
            self.assertIsNotNone(self.local(profile).sync())

    def test_decisions_on_another_service_do_not_move_past_the_floor(self):
        self.rig.close()
        self.rig = self.start(self.profile)  # restarted controller: no floor report yet
        for paused in (True, False, True):
            self.decide(self.rig, 'web.service', paused, 'unrelated operator decision')
        self.assertGreater(snapshot(self.rig.store, self.profile, 'agent-one')['revision'],
                           self.local().read()['snapshot']['revision'])
        self.rig.client.actions()
        self.assertTrue(self.held('second.service'))
        self.assertIsNotNone(self.local().sync())
        # The agent enforces this at once; the controller learns it from the next signed report.
        self.rig.client.actions()
        self.assertTrue(sync_status(self.rig.app, 'agent-one',
                                    snapshot(self.rig.store, self.profile, 'agent-one'))['behind'])
        self.decide(self.rig, 'web.service', False, 'reviewed; re-synchronize')
        self.rig.client.actions()
        self.assertIsNone(self.local().sync())
        self.assertTrue(self.held('second.service'))

    def test_explicit_resume_of_a_held_service_is_honoured_and_not_recarried(self):
        self.rig.client.actions()
        self.decide(self.rig, 'second.service', False, 'reviewed resume of the held service')
        # Another decision before the agent polls again must not re-pause it.
        result = self.decide(self.rig, 'web.service', True, 'another reviewed decision')
        self.assertNotIn('second.service', result['resynchronization']['carried_forward'])
        self.rig.client.actions()
        self.assertIsNone(self.local().sync())
        self.assertFalse(self.held('second.service'))

    def test_resume_in_flight_while_agent_reports_a_gap_is_not_recarried(self):
        self.rig.client.actions(); self.rig.client.actions()  # the agent now reports behind=True
        self.assertTrue(agent_report(self.rig.app, 'agent-one')['behind'])
        self.decide(self.rig, 'second.service', False, 'reviewed resume of the held service')
        self.rig.client.actions()  # its report predates this response: still lists the hold
        self.assertIn('second.service', agent_report(self.rig.app, 'agent-one')['held'])
        result = self.decide(self.rig, 'web.service', True, 'another reviewed decision')
        self.assertEqual(result['resynchronization']['carried_forward'], [])
        self.rig.client.actions()
        self.assertIsNone(self.local().sync())
        self.assertFalse(self.held('second.service'))

    def test_undo_latch_lost_by_restore_is_cleared_by_one_explicit_resume(self):
        txn = str(uuid.uuid4())
        self.local().latch('second.service', txn)  # recorded undo on the agent; the backup never saw it
        self.rig.close(); self.rig = self.start(self.profile)  # restored controller restarted while offline
        self.decide(self.rig, 'second.service', True, 'operator re-pauses after restore')
        self.decide(self.rig, 'web.service', True, 'another reviewed decision')
        self.rig.client.actions()
        self.assertIsNone(self.local().sync())
        control = snapshot(self.rig.store, self.profile, 'agent-one')
        self.assertEqual(sync_status(self.rig.app, 'agent-one', control)['latched'], ['second.service'])
        self.decide(self.rig, 'second.service', False, 'reviewed resume after undo')
        self.assertEqual(snapshot(self.rig.store, self.profile, 'agent-one')['services']['second.service']['transaction_id'], txn)
        self.rig.client.actions()
        self.assertNotIn('second.service', self.local().read()['latches'])
        self.assertFalse(self.held('second.service'))
        self.assertIsNone(controller_refusal(self.rig.app, 'agent-one', 'restart_service', {'service': 'second.service'}))

    def test_resume_is_not_repaused_after_a_lost_response(self):
        self.rig.client.actions()
        stale = {k: [v] for k, v in self.local().report()}
        self.decide(self.rig, 'second.service', False, 'reviewed resume of the held service')
        self.rig.client.actions()
        self.assertFalse(self.held('second.service'))
        record_report(self.rig.app, 'agent-one', stale)  # a report built before that response
        result = self.decide(self.rig, 'web.service', True, 'another reviewed decision')
        self.assertEqual(result['resynchronization']['carried_forward'], [])
        self.assertFalse(snapshot(self.rig.store, self.profile, 'agent-one')['services']['second.service']['paused'])

    def test_resume_is_not_repaused_after_a_controller_restart(self):
        self.rig.client.actions()
        self.decide(self.rig, 'second.service', False, 'reviewed resume of the held service')
        self.rig.close(); self.rig = self.start(self.profile)
        self.rig.client.actions()
        result = self.decide(self.rig, 'web.service', True, 'another reviewed decision')
        self.assertEqual(result['resynchronization']['carried_forward'], [])
        self.rig.client.actions()
        self.assertFalse(self.held('second.service'))

    def test_redo_gate_holds_on_the_first_reconnect_report(self):
        self.rig.close(); self.rig = self.start(self.profile)
        self.decide(self.rig, 'web.service', True, 'decision while the agent is away')
        self.decide(self.rig, 'web.service', False, 'another decision while the agent is away')
        self.rig.client.actions()  # first report after reconnect: not yet behind on the agent
        row = next(r for r in self.rig.app.setup_redo_policy()['services'] if r['service'] == 'second.service')
        self.assertTrue(row['holds'])

    def test_resume_supersedes_a_pause_recorded_by_a_controller_with_a_later_clock(self):
        self.rig.client.actions()
        pause_time = self.local().read()['snapshot']['services']['second.service']['updated_at']
        with patch('sentinel_blue.service_automation.time.time', return_value=pause_time - 3600):
            self.decide(self.rig, 'second.service', False, 'reviewed resume on a controller with a slow clock')
        self.rig.client.actions()
        self.assertIsNone(self.local().sync())
        self.assertFalse(self.held('second.service'))

    def test_equal_revision_without_the_hold_is_behind_on_the_first_report(self):
        update(self.rig.store, self.profile, 'agent-one', 'web.service', True, 'backup one decision behind')
        self.rig.close(); self.rig = self.start(self.profile)
        floor = self.local().read()['snapshot']['revision']
        while snapshot(self.rig.store, self.profile, 'agent-one')['revision'] < floor:
            self.decide(self.rig, 'web.service', True, 'decision while the agent is away')
        self.assertEqual(snapshot(self.rig.store, self.profile, 'agent-one')['revision'], floor)
        self.rig.client.actions()
        self.assertTrue(sync_status(self.rig.app, 'agent-one', snapshot(self.rig.store, self.profile, 'agent-one'))['behind'])
        row = next(r for r in self.rig.app.setup_redo_policy()['services'] if r['service'] == 'second.service')
        self.assertTrue(row['holds'])
        self.assertTrue(self.held('second.service'))

    def test_manual_work_flows_throughout(self):
        manual = self.rig.store.queue_action('agent-one', 'validate_service', {
            'service': 'web.service', 'probes': copy.deepcopy(self.profile.services[0]['expected_transactions'])},
            automated=False)
        self.assertEqual([a['action_id'] for a in self.rig.client.actions()], [manual])
        self.assertTrue(self.held('second.service'))


class ReportAndCarryTests(unittest.TestCase):
    """Floor reports are bounded, scoped and carry every agent-held service forward."""

    def setUp(self):
        td = tempfile.TemporaryDirectory(prefix='sb215-report-'); self.addCleanup(td.cleanup)
        self.root = Path(td.name); (self.root / 'agent').mkdir(mode=0o700)
        base, _ = fixtures(); self.profile = with_second(base)
        self.store = Store(self.root / 'controller.db'); self.addCleanup(self.store.close)
        self.app = SimpleNamespace(store=self.store, event_profile=self.profile)
        self.local = LocalAutomation(self.root / 'agent', self.profile, 'agent-one')

    def report(self):
        return record_report(self.app, 'agent-one', {k: [v] for k, v in self.local.report()})

    def test_resync_carries_other_holds_and_latch_transaction(self):
        txn = str(uuid.uuid4())
        for _ in range(2):
            update(self.store, self.profile, 'agent-one', 'second.service', True, 'hold second', transaction_id=txn)
        self.local.accept(snapshot(self.store, self.profile, 'agent-one'))
        self.local.latch('second.service', txn)
        self.store._connection.execute('DELETE FROM controller_state'); self.store._connection.commit()
        self.assertEqual(self.local.accept(snapshot(self.store, self.profile, 'agent-one')), 'behind')
        report = self.report()
        self.assertEqual(list(report['held']), ['second.service']); self.assertEqual(report['latches'], {'second.service': txn})
        state, details = update_with_details(self.store, self.profile, 'agent-one', 'web.service', True, 'reviewed',
                                             report=agent_report(self.app, 'agent-one'))
        self.assertEqual(state['revision'], 3); self.assertEqual(details['carried_forward'], ['second.service'])
        self.assertEqual(state['services']['second.service']['transaction_id'], txn)
        self.assertTrue(state['services']['second.service']['paused'])
        self.assertEqual(self.local.accept(state), 'current')
        self.assertIn('second.service', self.local.read()['latches'])
        cleared = update(self.store, self.profile, 'agent-one', 'second.service', False, 'explicit resume')
        self.local.accept(cleared)
        self.assertNotIn('second.service', self.local.read()['latches'])

    def test_truncated_report_pauses_every_other_approved_service(self):
        report = {'revision': 7, 'behind': True, 'held': {}, 'latches': {}, 'truncated': True}
        values = {REPORT_PARAMETER: [json.dumps(report)]}
        record_report(self.app, 'agent-one', values)
        state, details = update_with_details(self.store, self.profile, 'agent-one', 'web.service', False, 'reviewed',
                                             report=agent_report(self.app, 'agent-one'))
        self.assertEqual(state['revision'], 8); self.assertEqual(details['carried_forward'], ['second.service'])
        self.assertFalse(state['services']['web.service']['paused'])

    def test_malformed_or_foreign_reports_are_bounded(self):
        self.assertIsNone(record_report(self.app, 'agent-one', {REPORT_PARAMETER: ['{']}))
        self.assertIsNone(record_report(self.app, 'agent-one', {REPORT_PARAMETER: [json.dumps(
            {'revision': 2**62, 'behind': True, 'held': {}, 'latches': {}, 'truncated': False})]}))
        value = parse_report(self.profile, 'agent-one', {REPORT_PARAMETER: [json.dumps(
            {'revision': 1, 'behind': True, 'held': {'foreign.service': 1.0, 'web.service': 2.0},
             'latches': {'foreign.service': 'x'}, 'truncated': False})]})
        self.assertEqual(value['held'], {'web.service': 2.0}); self.assertEqual(value['latches'], {})
        self.assertIsNone(record_report(self.app, 'agent-one', {REPORT_PARAMETER: [json.dumps(
            {'revision': 1, 'behind': True, 'held': ['web.service'], 'latches': {}, 'truncated': False})]}))
        self.assertIsNone(parse_report(self.profile, 'agent-one', {}))

    def test_in_step_agent_always_reports_its_holds(self):
        self.local.accept(update(self.store, self.profile, 'agent-one', 'web.service', True, 'hold'))
        report = json.loads(dict(self.local.report())[REPORT_PARAMETER])
        state = snapshot(self.store, self.profile, 'agent-one')
        self.assertEqual(report, {'revision': 1, 'behind': False, 'latches': {}, 'truncated': False,
                                  'held': {'web.service': state['services']['web.service']['updated_at']}})
        # In step: the controller is not behind and keeps planning normally.
        record_report(self.app, 'agent-one', {REPORT_PARAMETER: [json.dumps(report)]})
        self.assertFalse(sync_status(self.app, 'agent-one', snapshot(self.store, self.profile, 'agent-one'))['behind'])

    def test_corrupt_sync_record_holds_automation(self):
        self.local.sync_path.write_text('{'); self.local.sync_path.chmod(0o600)
        with self.assertRaises(ValueError):
            self.local.refusal('restart_service', {'service': 'web.service'})

    def test_restart_does_not_forget_the_gap(self):
        update(self.store, self.profile, 'agent-one', 'web.service', True, 'first hold')
        update(self.store, self.profile, 'agent-one', 'web.service', True, 'second hold')
        self.local.accept(snapshot(self.store, self.profile, 'agent-one'))
        self.local.accept(empty(self.profile, 'agent-one'))
        reopened = LocalAutomation(self.root / 'agent', self.profile, 'agent-one')
        self.assertIn('durable floor', reopened.refusal('restart_service', {'service': 'second.service'}))


class OfflineRealPlatformTests(unittest.TestCase):
    """R214-02: the offline gates use the collector's real "Linux <release>" value."""

    def fixture(self):
        import test_offline_authority as toa
        original = toa.fixtures

        def patched(*a, **k):
            profile, baseline = original(*a, **k)
            baseline['platform'] = REAL_LINUX
            return profile, baseline
        with patch.object(toa, 'fixtures', patched):
            f = toa.OfflineAuthorityTests('test_no_policy_means_monitoring_only'); f.setUp()
        self.addCleanup(f.doCleanups)
        return f

    def intents(self, f):
        return [e for e in f.agent.journal.read() if e['kind'] == 'offline_intent']

    def test_undo_latch_stops_offline_before_intent_or_allowance(self):
        f = self.fixture(); f.authorize()
        LocalAutomation(f.executor.state_dir, f.profile, 'agent-one').latch('web.service', str(uuid.uuid4()))
        f.outage(); f.step(2); f.step(3)
        self.assertEqual(f.calls, 0); self.assertEqual(self.intents(f), [])
        self.assertIn('paused', f.agent.status.lower())

    def test_controller_refuses_offline_authority_for_paused_service(self):
        f = self.fixture()
        update(f.store, f.profile, 'agent-one', 'web.service', True, 'held before offline authorization')
        with self.assertRaisesRegex(ValueError, 'paused'):
            f.authorize()

    def test_stale_controller_gap_also_holds_offline(self):
        f = self.fixture(); f.authorize()
        local = LocalAutomation(f.executor.state_dir, f.profile, 'agent-one')
        local.accept(update(f.store, f.profile, 'agent-one', 'web.service', False, 'recorded resume'))
        local.accept(empty(f.profile, 'agent-one'))
        f.outage(); f.step(2); f.step(3)
        self.assertEqual(f.calls, 0); self.assertEqual(self.intents(f), [])


class ReleaseModeTests(unittest.TestCase):
    """R214-03: lab scripts stay executable in the source tree and every archive."""

    def test_source_scripts_are_executable_for_the_owner(self):
        from tools.build_linux_gui_delivery import EXECUTABLE_SOURCES
        for name in EXECUTABLE_SOURCES:
            mode = (SOURCE_ROOT / name).stat().st_mode
            # The installer deliberately extracts with umask 077. Both the
            # 0755 distribution source and 0700 private installation must run.
            self.assertEqual(mode & stat.S_IXUSR, stat.S_IXUSR, name)

    def test_build_refuses_lost_modes_and_archive_preserves_them(self):
        from tools.build_linux_gui_delivery import EXECUTABLE_SOURCES, archive_tree, check_executable_sources
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / 'source'
            for name in EXECUTABLE_SOURCES:
                target = root / name; target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text('#!/bin/sh\n'); target.chmod(0o755)
            check_executable_sources(root)
            archive = Path(td) / 'a.tar.gz'; archive_tree(root, archive)
            with tarfile.open(archive) as tar:
                modes = {m.name: m.mode for m in tar.getmembers()}
            self.assertTrue(all(modes[name] == 0o755 for name in EXECUTABLE_SOURCES), modes)
            (root / EXECUTABLE_SOURCES[0]).chmod(0o644)
            with self.assertRaisesRegex(ValueError, 'executable mode'):
                check_executable_sources(root)


if __name__ == '__main__':
    unittest.main()
