"""Exercise desktop job scheduling without requiring a graphical display."""
import queue
import tempfile
import threading
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

from sentinel_blue.desktop import DesktopWindow
from sentinel_blue.job_control import JobControl
from sentinel_blue.state import write_private_json


class Value:
    def __init__(self, value=''):
        self.value = value

    def set(self, value):
        self.value = value

    def get(self):
        return self.value


def window_without_display(root):
    window = DesktopWindow.__new__(DesktopWindow)
    window.directory = root
    window.closed = False
    window.generation = 0
    window.events = queue.SimpleQueue()
    window.jobs = queue.Queue(maxsize=4)
    window.job_control = JobControl(root)
    window.job_control.initialize()
    window.control_jobs = queue.SimpleQueue()
    window.control_revision = 0
    window.control_pending = set()
    window.worker_stop = threading.Event()
    window.lock_requested = threading.Event()
    window.credentials = Mock()
    window.root = Mock()
    window.root.winfo_children.return_value = []
    window.tk = SimpleNamespace(Toplevel=type('TestToplevel', (), {}))
    window.tick_timer = None
    window.guard = None
    window.footer = Value()
    window.operator_key = Value()
    window.vault_pass = Value()
    window.status = Value()
    window.summary = Value()
    window.governance = Value()
    window.setup_governance = Value()
    window.notify = Value(False)
    window.notebook = Mock()
    window.tabs = {'Connection': object()}
    for name in ('credential_list', 'services', 'reviews'):
        tree = Mock()
        tree.get_children.return_value = ()
        setattr(window, name, tree)
    window.client = None
    window.polling = False
    window.next_poll = 0
    window.job_path = None
    window.job_process = None
    window.job_outcome_unknown = False
    window.setup_starting = False
    window.controller_starting = False
    window.background_controller = None
    window.start_setup = Mock()
    window._setup_report = Mock()
    window.popup = Mock()
    window.messagebox = Mock()
    window.messagebox.askyesno.return_value = True
    window.filedialog = Mock()
    window._setup_values = Mock(return_value={'kind': 'setup', 'inventory': 'fixture'})
    window.plan = (window._setup_values(), {'tasks': []})
    return window


class DesktopWorkflowTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        self.window = window_without_display(self.root)

    def start_worker(self):
        thread = threading.Thread(target=self.window._worker, daemon=True)
        thread.start()
        def stop():
            self.window.worker_stop.set()
            thread.join(3)
            self.assertFalse(thread.is_alive(), 'Desktop worker did not finish')
        self.addCleanup(stop)
        return thread

    def pump_until(self, predicate):
        deadline = time.monotonic() + 3
        while not predicate() and time.monotonic() < deadline:
            self.window._tick()
            time.sleep(.01)
        self.assertTrue(predicate())

    def test_repeated_setup_click_launches_only_one_job(self):
        self.window.execute_setup()
        self.window.execute_setup()
        self.assertEqual(self.window.jobs.qsize(), 1)
        self.assertTrue(self.window.setup_starting)
        process = Mock()
        process.poll.return_value = None
        job_path = self.root/'job'/'job.json'
        with patch('sentinel_blue.desktop.launch_job', return_value=(process, job_path)) as launch:
            self.start_worker()
            self.pump_until(lambda: self.window.job_path is not None)
            self.window.execute_setup()
            self.assertEqual(launch.call_count, 1)
            self.assertFalse(self.window.setup_starting)
            self.assertIsNone(self.window.plan)

    def test_full_queue_does_not_leave_setup_marked_as_launching(self):
        for _ in range(4):
            self.assertTrue(self.window.submit(lambda: None, lambda _: None))
        self.window.execute_setup()
        self.assertFalse(self.window.setup_starting)
        self.assertEqual(self.window.jobs.qsize(), 4)
        self.window.start_setup.configure.assert_called_with(state='normal')

    def test_launch_failure_requires_new_review_and_refresh_keeps_running(self):
        with patch('sentinel_blue.desktop.launch_job', side_effect=OSError('fixture launch failed')):
            self.window.execute_setup()
            self.start_worker()
            self.pump_until(lambda: not self.window.setup_starting)
        self.assertIsNone(self.window.plan)
        self.assertIsNone(self.window.job_path)
        self.assertIn('fixture launch failed', self.window.footer.get())
        self.window.root.after.assert_called()

    def test_repeated_controller_click_launches_only_one_process(self):
        config = self.root/'controller.json'
        write_private_json(config, {'controller_arguments': ['--fixture']})
        self.window.filedialog.askopenfilename.return_value = str(config)
        self.window.launch_controller()
        self.window.launch_controller()
        self.assertEqual(self.window.jobs.qsize(), 1)
        process = Mock()
        process.poll.return_value = None
        with patch('sentinel_blue.desktop.start_controller', return_value=process) as launch:
            self.start_worker()
            self.pump_until(lambda: self.window.background_controller is process)
            self.window.launch_controller()
            self.assertEqual(launch.call_count, 1)

    def test_dead_worker_is_unknown_and_never_retried(self):
        self.window.job_path = self.root/'job.json'
        self.window.job_process = SimpleNamespace(poll=lambda: 3, returncode=3)
        self.window.notify.set(True)
        self.window._poll_background_job()
        self.window._poll_background_job()
        self.window.execute_setup()
        self.assertTrue(self.window.job_outcome_unknown)
        self.assertEqual(self.window.jobs.qsize(), 0)
        self.window.popup.assert_called_once()
        self.assertIn('outcome_unknown', self.window._setup_report.call_args.args[0])
        self.assertIsNotNone(self.window.job_path)
        # A later valid completion report can still settle the observation.
        write_private_json(self.root/'result.json', {'status': 'ready'})
        self.window._poll_background_job()
        self.assertIsNone(self.window.job_path)
        self.assertFalse(self.window.job_outcome_unknown)

    def test_invalid_worker_report_cannot_stop_window_updates(self):
        self.window.job_path = self.root/'job.json'
        self.window.job_process = SimpleNamespace(poll=lambda: 2, returncode=2)
        write_private_json(self.root/'result.json', {'status': None})
        self.window._tick()
        self.assertTrue(self.window.job_outcome_unknown)
        self.window.root.after.assert_called()

    def test_failed_completion_callback_does_not_stop_refresh(self):
        done = Mock(side_effect=ValueError('fixture callback failure'))
        self.window.events.put(('done', (0, done, False), {}))
        self.window._tick()
        self.assertIn('Window update failed', self.window.footer.get())
        self.window.root.after.assert_called()

    def test_lock_clears_pending_credential_work_even_when_queue_is_full(self):
        pending = Mock()
        for _ in range(4):
            self.window.submit(pending, pending)
        self.window.events.put(('done', (0, pending, False), 'old credential result'))
        self.window.lock()
        self.start_worker()
        self.pump_until(lambda: self.window.credentials.lock.called and self.window.jobs.empty())
        pending.assert_not_called()
        self.assertFalse(self.window.lock_requested.is_set())

    def test_close_finishes_admitted_work_then_locks_vault_and_stops_worker(self):
        started, finish, completed = threading.Event(), threading.Event(), threading.Event()
        def operation():
            started.set()
            finish.wait(3)
            completed.set()
        self.window.submit(operation, Mock(), preserve=True)
        thread = self.start_worker()
        self.assertTrue(started.wait(2))
        self.window.close()
        self.assertTrue(thread.is_alive())
        self.assertFalse(self.window.submit(Mock(), Mock()))
        finish.set()
        thread.join(2)
        self.assertTrue(completed.is_set())
        self.assertFalse(thread.is_alive())
        self.window.credentials.lock.assert_called()
        self.assertTrue(self.window.events.empty())


if __name__ == '__main__':
    unittest.main()
