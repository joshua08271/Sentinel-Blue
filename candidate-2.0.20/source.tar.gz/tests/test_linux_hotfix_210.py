"""SB209 review regressions: private SQLite/files and signed loopback fixtures.

No native service is deployed. Optional parsers and native checkzone only
validate generated text. The wheel test builds in a disposable source copy.
"""
from __future__ import annotations

import copy
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
import tomllib
import unittest
from types import SimpleNamespace
from unittest.mock import patch
import zipfile

from sentinel_blue import setup_redo
from sentinel_blue.desktop_recovery import RecoveryControls
from sentinel_blue.linux_service_packs import BANNER, _bind9
from sentinel_blue.redo_governance import CHECK_PATH
from sentinel_blue.state import write_private_json
import test_linux_hotfix_209 as prior
import test_setup_redo_203 as old_redo
from test_service_repair import damage


class RetentionUsesGovernanceClassification(unittest.TestCase):
    def fixture(self):
        value = prior.HistoryArchivalKeepsUnresolvedEvidence()
        value.setUp()
        self.addCleanup(value.doCleanups)
        return value

    def maintain(self, value, mode):
        if mode == 'prune':
            value.store.prune(retention_days=1)
        else:
            for _ in range(20):
                value.manager.maintain()

    def malformed(self, mode, column, raw):
        value = self.fixture()
        prior.insert_repair(value.store, 'bad', 'web.service', prior.CLEAN,
                            age=40 * 86400, agent='agent-one')
        prior.insert_repair(value.store, 'clean', 'db.service', prior.CLEAN,
                            age=40 * 86400, agent='agent-one')
        value.store._connection.execute(f'UPDATE actions SET {column}=? WHERE action_id=?', (raw, 'bad'))
        value.store._connection.commit()
        pair = ('agent-one', 'web.service')
        before = value.store.setup_redo_holds([pair])[pair]
        self.assertIn('unreadable', ' '.join(before))
        self.maintain(value, mode)
        self.assertIn('bad', value.ids())
        self.assertNotIn('clean', value.ids(), 'safe retention must still work')
        self.assertEqual(value.store.setup_redo_holds([pair])[pair], before)

    def test_archive_keeps_malformed_and_nonobject_metadata(self):
        for column in ('parameters_json', 'result_json'):
            for raw in ('{bad', '[]', 'null', '17', '"not an object"'):
                with self.subTest(column=column, raw=raw):
                    self.malformed('archive', column, raw)

    def test_prune_keeps_malformed_and_nonobject_metadata(self):
        for column in ('parameters_json', 'result_json'):
            for raw in ('{bad', '[]', 'null', '17', '"not an object"'):
                with self.subTest(column=column, raw=raw):
                    self.malformed('prune', column, raw)

    def test_cache_is_invalidated_by_changed_parameters(self):
        value = self.fixture()
        prior.insert_repair(value.store, 'changed', 'web.service', prior.CLEAN, age=40 * 86400, agent='agent-one')
        pair = ('agent-one', 'web.service')
        self.assertEqual(value.store.setup_redo_holds([pair])[pair], [])
        value.store._connection.execute("UPDATE actions SET parameters_json='[]' WHERE action_id='changed'")
        value.store._connection.commit()
        self.assertIn('unreadable', ' '.join(value.store.setup_redo_holds([pair])[pair]))
        with value.store._lock:
            pins, overflow = value.store.redo_evidence_pins_locked()
        self.assertEqual(pins, {'changed'})
        self.assertFalse(overflow)

    def test_unreadable_pin_overflow_keeps_all_failed_repairs(self):
        for mode in ('archive', 'prune'):
            with self.subTest(mode=mode):
                value = self.fixture()
                for name in ('bad1', 'bad2', 'clean'):
                    prior.insert_repair(value.store, name, 'web.service', prior.CLEAN,
                                        age=40 * 86400, agent='agent-one')
                value.store._connection.execute("UPDATE actions SET parameters_json='[]' WHERE action_id IN ('bad1','bad2')")
                value.store._connection.commit()
                with patch('sentinel_blue.store.REDO_EVIDENCE_PIN_LIMIT', 1):
                    self.maintain(value, mode)
                self.assertEqual(value.ids(), {'bad1', 'bad2', 'clean'})

    def test_receipted_failure_with_changed_metadata_remains_held_and_retained(self):
        value = self.fixture()
        prior.insert_repair(value.store, 'receipt', 'web.service', prior.DIRTY, age=40 * 86400, agent='agent-one')
        value.store.record_verified_redo_recovery('agent-one', 'web.service', time.time(), 'e' * 64)
        pair = ('agent-one', 'web.service')
        self.assertEqual(value.store.setup_redo_holds([pair])[pair], [])
        value.store._connection.execute("UPDATE actions SET parameters_json='[]' WHERE action_id='receipt'")
        value.store._connection.commit()
        self.maintain(value, 'archive')
        self.assertIn('receipt', value.ids())
        self.assertIn('unreadable', ' '.join(value.store.setup_redo_holds([pair])[pair]))
        self.assertEqual(value.store._connection.execute('SELECT COUNT(*) FROM redo_recovery_receipts').fetchone()[0], 1)


class ManualRedoKeepsServiceIsolation(prior.LiveController):
    def break_both(self):
        self.app.set_autonomy_mode('approval-based')
        self.break_web()
        current = damage(self.base, 3)
        current['observed_at'] = time.time()
        current['services'][1]['state'] = 'stopped'
        current['probes'][1]['healthy'] = False
        self.app.ingest(current)

    def safe_partial(self, status, result):
        self.break_both()
        prior.insert_repair(self.store, 'held-db', 'db.service', result, status=status)
        entry = setup_redo.manual_redo(self.workspace, None, client=self.client, launcher=self.launcher)
        self.assertEqual(entry['units'], ['web.service'])
        self.assertEqual(self.launched[0]['only_services'], [['local-linux', 'web.service']])
        self.assertIn('db.service', entry['excluded'])
        persisted = setup_redo.load_state(self.workspace)
        self.assertEqual(persisted['history'][-1]['excluded'], entry['excluded'])
        self.assertIn('db.service', persisted['last'])
        check = self.client.request(CHECK_PATH, {'profile_fingerprint': self.profile.fingerprint,
                                               'services': [['local-linux', 'db.service']], 'automated': False})
        self.assertFalse(check['allowed'], 'excluded service must remain held')

    def test_dirty_other_service_is_excluded(self):
        self.safe_partial('failed', prior.DIRTY)

    def test_unknown_other_service_is_excluded(self):
        self.safe_partial('outcome_unknown', None)

    def test_in_progress_other_service_is_excluded(self):
        self.safe_partial('queued', None)

    def test_all_held_services_launch_nothing(self):
        self.break_both()
        for unit in ('web.service', 'db.service'):
            prior.insert_repair(self.store, unit, unit, prior.DIRTY)
        with self.assertRaisesRegex(ValueError, 'No services can be redone'):
            setup_redo.manual_redo(self.workspace, None, client=self.client, launcher=self.launcher)
        self.assertEqual(self.launched, [])

    def test_host_wide_unreadable_hold_launches_nothing(self):
        self.break_both()
        prior.insert_repair(self.store, 'bad-host', 'db.service', prior.CLEAN, parameters=[])
        with self.assertRaisesRegex(ValueError, 'unreadable'):
            setup_redo.manual_redo(self.workspace, None, client=self.client, launcher=self.launcher)
        self.assertEqual(self.launched, [])

    def test_timer_hold_is_overridable_but_dirty_hold_is_not(self):
        self.break_both()
        prior.insert_repair(self.store, 'db-dirty', 'db.service', prior.DIRTY)
        now = time.time()
        state = setup_redo.load_state(self.workspace)
        state['unhealthy_since'] = {'web.service': now - 400}
        state['history'] = [{'at': now - 700 - i, 'unit': 'web.service'} for i in range(3)]
        setup_redo.save_state(self.workspace, state)
        verdict = setup_redo.assess(self.client.dashboard(), self.record, copy.deepcopy(state), time.time())
        self.assertEqual(verdict['units']['web.service']['hold_kind'], 'hourly_limit')
        entry = setup_redo.manual_redo(self.workspace, None, client=self.client, launcher=self.launcher)
        self.assertEqual(entry['units'], ['web.service'])
        self.assertIn('db.service', entry['excluded'])

    def test_fresh_controller_rejection_still_prevents_launch(self):
        self.break_both()
        snapshot = self.client.dashboard()
        self.app.emergency_stopped = True
        with patch.object(self.client, 'dashboard', return_value=snapshot):
            with self.assertRaises(Exception):
                setup_redo.manual_redo(self.workspace, None, client=self.client, launcher=self.launcher)
        self.assertEqual(self.launched, [])

    def test_no_covered_service_never_launches_a_wildcard(self):
        self.break_both()
        write_private_json(self.root / 'inventory.json', {'hosts': [], 'setup': {'tasks': []}})
        with self.assertRaisesRegex(ValueError, 'no task'):
            setup_redo.manual_redo(self.workspace, None, client=self.client, launcher=self.launcher)
        self.assertEqual(self.launched, [])


class HourlyRedoIsPerService(unittest.TestCase):
    NOW = 1_800_000_000.0

    def verdict(self, history, *, scope='local', target='db.service', agent='local-linux'):
        record = {'scope': scope, 'original_job': '/no-such-sentinel-fixture/job.json'}
        state = {'history': history, 'seen_healthy': [target], 'unhealthy_since': {target: self.NOW - 400}}
        snapshot = {'controller': {'governance': {'emergency_stopped': False, 'autonomy_mode': 'approval-based'}},
                    'agents': [{'agent_id': agent, 'baseline_status': 'approved'}],
                    'service_health': [{'agent_id': agent, 'service': target.split('/')[-1],
                                        'health': 'unhealthy', 'native_state': 'failed'}]}
        return setup_redo.assess(snapshot, record, state, self.NOW)['units'][target]

    def history(self, unit, members=None, age=700):
        return [dict(at=self.NOW - age - i, unit=unit, **({'units': members} if members is not None else {}))
                for i in range(3)]

    def test_other_service_does_not_consume_hourly_budget(self):
        self.assertEqual(self.verdict(self.history('web.service', ['web.service']))['status'], 'eligible')

    def test_same_service_still_hits_hourly_limit(self):
        self.assertEqual(self.verdict(self.history('db.service'))['hold_kind'], 'hourly_limit')

    def test_scoped_batch_only_counts_its_members(self):
        history = self.history('*', ['web.service', 'mail.service'])
        self.assertEqual(self.verdict(history)['status'], 'eligible')
        self.assertEqual(self.verdict(history, target='web.service')['hold_kind'], 'hourly_limit')

    def test_legacy_and_explicit_wildcards_remain_global(self):
        for members in (None, ['*'], [], ['web.service', 5]):
            with self.subTest(members=members):
                self.assertEqual(self.verdict(self.history('*', members))['hold_kind'], 'hourly_limit')

    def test_same_name_on_another_host_has_separate_budget(self):
        history = self.history('host-a/db.service', ['host-a/db.service'])
        self.assertEqual(self.verdict(history, scope='network', target='host-b/db.service', agent='host-b')['status'], 'eligible')
        self.assertEqual(self.verdict(history, scope='network', target='host-a/db.service', agent='host-a')['hold_kind'], 'hourly_limit')

    def test_expired_history_does_not_count(self):
        self.assertEqual(self.verdict(self.history('db.service', age=3600))['status'], 'eligible')

    def test_short_cooldown_still_applies_only_to_covered_service(self):
        history = self.history('web.service', age=100)
        self.assertEqual(self.verdict(history)['status'], 'eligible')
        self.assertEqual(self.verdict(history, target='web.service')['status'], 'waiting')


class GeneratedBindZone(unittest.TestCase):
    def zone(self):
        files, _ = _bind9({'mode': 'create-owned', 'zone': 'range.test', 'soa_mname': 'ns1.range.test',
                          'records': [{'name': 'ns1', 'type': 'A', 'value': '192.0.2.10'},
                                      {'name': 'www', 'type': 'A', 'value': '192.0.2.20'},
                                      {'name': 'ipv6', 'type': 'AAAA', 'value': '2001:db8::1'}]})
        return files['/etc/bind/sentinel-range.test.zone']

    def test_zone_specific_marker_does_not_change_other_formats(self):
        self.assertTrue(self.zone().startswith('; Managed by Sentinel Blue.'))
        self.assertTrue(BANNER.startswith('# Managed by Sentinel Blue.'))
        self.assertNotIn('# Managed', self.zone())

    @unittest.skipUnless(importlib.util.find_spec('dns'), 'optional dnspython parser not installed')
    def test_independent_parser_accepts_exact_generated_text(self):
        import dns.zone
        zone = dns.zone.from_text(self.zone(), origin='range.test')
        self.assertEqual(len(zone.nodes), 4)
        self.assertEqual(zone.get_rdataset('www', 'A')[0].address, '192.0.2.20')

    @unittest.skipUnless(shutil.which('named-checkzone'), 'native named-checkzone not installed')
    def test_native_checkzone_accepts_exact_generated_text(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'range.zone'
            path.write_text(self.zone())
            run = subprocess.run([shutil.which('named-checkzone'), 'range.test', str(path)],
                                 capture_output=True, text=True, timeout=30)
            self.assertEqual(run.returncode, 0, run.stdout + run.stderr)


class WheelContainsWindowsHelpers(unittest.TestCase):
    def test_package_data_explicitly_includes_powershell(self):
        root = Path(__file__).resolve().parents[1]
        data = tomllib.loads((root / 'pyproject.toml').read_text())
        self.assertIn('*.ps1', data['tool']['setuptools']['package-data']['sentinel_blue'])

    @unittest.skipUnless(importlib.util.find_spec('setuptools') and importlib.util.find_spec('pip'),
                         'native wheel build requires setuptools and pip')
    def test_actual_wheel_resources_compile_windows_transaction(self):
        root = Path(__file__).resolve().parents[1]
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            source = tmp / 'source'
            source.mkdir()
            shutil.copy2(root / 'pyproject.toml', source / 'pyproject.toml')
            shutil.copytree(root / 'src', source / 'src', ignore=shutil.ignore_patterns('__pycache__', '*.egg-info'))
            env = dict(os.environ, PIP_NO_INDEX='1', PIP_DISABLE_PIP_VERSION_CHECK='1', PYTHONDONTWRITEBYTECODE='1')
            run = subprocess.run([sys.executable, '-m', 'pip', 'wheel', '--no-deps', '--no-build-isolation',
                                  '--no-index', '--wheel-dir', str(tmp / 'wheel'), str(source)],
                                 env=env, capture_output=True, text=True, timeout=90)
            self.assertEqual(run.returncode, 0, run.stdout + run.stderr)
            wheels = list((tmp / 'wheel').glob('*.whl'))
            self.assertEqual(len(wheels), 1)
            with zipfile.ZipFile(wheels[0]) as archive:
                for name in ('setup_windows_transaction.ps1', 'mutation_ledger_windows.ps1'):
                    self.assertEqual(archive.read('sentinel_blue/' + name),
                                     (root / 'src/sentinel_blue' / name).read_bytes())
            script = ('from pathlib import Path; import sentinel_blue; '
                      'from sentinel_blue.setup_transactions import commands; '
                      'commands("windows-service", {"service":"Spooler"}, Path("."), "Write-Output test"); '
                      'print(sentinel_blue.__file__)')
            env['PYTHONPATH'] = str(wheels[0])
            probe = subprocess.run([sys.executable, '-B', '-c', script], cwd=tmp, env=env,
                                   capture_output=True, text=True, timeout=30)
            self.assertEqual(probe.returncode, 0, probe.stdout + probe.stderr)
            self.assertIn('.whl', probe.stdout)


class ManualRedoDisplaysExclusions(unittest.TestCase):
    def test_gui_displays_each_exclusion_and_started_service(self):
        messages, displays = [], []
        entry = {'units': ['web.service'], 'job': '/fixture/job.json',
                 'excluded': {'db.service': 'incomplete rollback'}}
        window = SimpleNamespace(_redo_workspace=lambda: '/fixture', client=object(), snapshot={'present': True},
                                 job_path=None, setup_starting=False, root=None, note=messages.append,
                                 _recovery_display=displays.append,
                                 messagebox=SimpleNamespace(askyesno=lambda *a, **k: True),
                                 submit=lambda work, done, failed: done(entry))
        RecoveryControls.redo_local_setup(window)
        self.assertIn('web.service', messages[-1])
        self.assertIn('db.service', messages[-1])
        self.assertIn('incomplete rollback', displays[-1])


if __name__ == '__main__':
    unittest.main()
