"""2.0.3: services on the network, described by an operator's event profile,
get the same repair a guided local setup grants — written to a new file."""
import argparse
import contextlib
import copy
import io
import json
import tempfile
import unittest
from pathlib import Path

from sentinel_blue.controller import ControllerApp
from sentinel_blue.event_profile import EventProfile
from sentinel_blue.repair_grants import grant_file, grant_repair, report_text, run
from sentinel_blue.store import Store
from test_service_repair import damage, repair_fixture
from test_store_controller import _promote_integrity_baseline

REPAIR_ACTIONS = {"repair_service", "rollback_service_repair"}


def written_without_repair():
    """The repair fixture as a profile author who never heard of repair wrote it."""
    profile, baseline = repair_fixture()
    raw = copy.deepcopy(profile.raw)
    service = raw["services"][0]
    service.pop("repair_policy")
    service["allowed_automatic_actions"] = [a for a in service["allowed_automatic_actions"] if a not in REPAIR_ACTIONS]
    service["approval_actions"] = [a for a in service["approval_actions"] if a not in REPAIR_ACTIONS]
    return raw, baseline


def second_service(raw, service_id, files, data=()):
    service = copy.deepcopy(raw["services"][0])
    service.pop("repair_policy", None)
    service.update(service_id=service_id, required_files=list(files), required_data=list(data), port=9000)
    raw["services"].append(service)
    return service


class GrantedProfilesRepair(unittest.TestCase):
    def test_a_profile_without_repair_is_given_a_working_one(self):
        raw, baseline = written_without_repair()
        before = copy.deepcopy(raw)
        granted, report = grant_repair(raw)
        self.assertEqual(raw, before, "the input is never changed")
        manifest = granted["services"][0]
        self.assertEqual(manifest["repair_policy"], {"restore_files": ["/etc/web.conf"], "restart_unhealthy": True,
                                                     "validation_timeout_seconds": 30,
                                                     "restore_start_mode": "enabled", "unmask": True})
        self.assertIn("repair_service", manifest["approval_actions"])
        self.assertNotIn("repair_service", manifest["allowed_automatic_actions"])
        self.assertEqual([row["service"] for row in report["granted"]], ["agent-one/web.service"])

        profile = EventProfile.from_dict(granted)
        store = Store(":memory:")
        self.addCleanup(store.close)
        app = ControllerApp(store, "t" * 32, operator_token="o" * 32, event_profile=profile,
                            auto_recover_services=False, auto_restore=False,
                            restoration_probes=profile.services[0]["expected_transactions"])
        app.ingest(baseline)
        _promote_integrity_baseline(app, store, "agent-one")
        app.ingest(damage(baseline, 2))
        offers = [row for row in store.dashboard()["alerts"]
                  if row["kind"] == "service_repair_required" and row["status"] == "open"]
        self.assertEqual(len(offers), 1)
        self.assertEqual(app.decision(offers[0]["alert_id"], "approve")["status"], "queued")
        queued = [item for item in store.pending_actions("agent-one") if item.action_type == "repair_service"]
        self.assertEqual(queued[0].parameters["repair"]["restore_files"][0]["path"], "/etc/web.conf")

    def test_automatic_repair_is_granted_only_when_asked(self):
        raw, _ = written_without_repair()
        granted, _ = grant_repair(raw, automatic=True)
        self.assertIn("repair_service", granted["services"][0]["allowed_automatic_actions"])
        self.assertIn("repair_service", granted["allowed_automatic_actions"])
        EventProfile.from_dict(granted)

    def test_shared_data_and_identity_files_stay_alert_only(self):
        raw, _ = written_without_repair()
        raw["services"][0]["required_files"] = ["/etc/web.conf", "/etc/shared.conf", "/etc/shadow",
                                                "/srv/site/index.html"]
        raw["services"][0]["required_data"] = ["/srv/site"]
        second_service(raw, "api.service", ["/etc/shared.conf", "/etc/api.conf"])
        granted, report = grant_repair(raw)
        web, api = granted["services"]
        self.assertEqual(web["repair_policy"]["restore_files"], ["/etc/web.conf"])
        self.assertEqual(api["repair_policy"]["restore_files"], ["/etc/api.conf"])
        withheld = {row["path"]: row["reason"] for row in report["granted"][0]["withheld"]}
        self.assertIn("shared with api.service", withheld["/etc/shared.conf"])
        self.assertIn("data", withheld["/srv/site/index.html"])
        self.assertIn("monitored", withheld["/etc/shadow"])
        self.assertIn("alert only: /etc/shadow", report_text(report))

    def test_the_repair_limit_is_respected(self):
        raw, _ = written_without_repair()
        raw["services"][0]["required_files"] = [f"/etc/web/{index:02}.conf" for index in range(20)]
        granted, report = grant_repair(raw)
        self.assertEqual(len(granted["services"][0]["repair_policy"]["restore_files"]), 16)
        self.assertEqual(len(report["granted"][0]["withheld"]), 4)

    def test_an_existing_policy_is_kept_and_a_service_without_files_is_skipped(self):
        profile, _ = repair_fixture()
        raw = copy.deepcopy(profile.raw)
        second_service(raw, "api.service", [])
        granted, report = grant_repair(raw)
        self.assertEqual(granted["services"][0]["repair_policy"], raw["services"][0]["repair_policy"])
        self.assertNotIn("repair_policy", granted["services"][1])
        self.assertEqual([row["service"] for row in report["kept"]], ["agent-one/web.service"])
        self.assertEqual([row["service"] for row in report["skipped"]], ["agent-one/api.service"])

    def test_windows_hosts_restore_automatic_start_without_a_mask(self):
        raw, _ = written_without_repair()
        granted, _ = grant_repair(raw, windows_hosts=["agent-one"])
        policy = granted["services"][0]["repair_policy"]
        self.assertEqual(policy["restore_start_mode"], "auto")
        self.assertNotIn("unmask", policy)

    def test_only_named_services_are_granted(self):
        raw, _ = written_without_repair()
        second_service(raw, "api.service", ["/etc/api.conf"])
        granted, _ = grant_repair(raw, only=["agent-one/api.service"])
        self.assertNotIn("repair_policy", granted["services"][0])
        self.assertIn("repair_policy", granted["services"][1])

    def test_capabilities_the_event_turned_off_stay_off_unless_asked(self):
        raw, _ = written_without_repair()
        raw["capabilities"]["in_place_repair"] = False
        granted, report = grant_repair(raw)
        self.assertFalse(granted["capabilities"]["in_place_repair"])
        self.assertTrue(any("in_place_repair" in text for text in report["warnings"]))
        enabled, _ = grant_repair(raw, enable_capabilities=True)
        self.assertTrue(enabled["capabilities"]["in_place_repair"])

    def test_a_service_without_a_loopback_check_is_warned_about(self):
        raw, _ = written_without_repair()
        raw["services"][0]["expected_transactions"] = [{"name": "remote", "kind": "tcp", "target": "10.0.0.5", "port": 80}]
        _, report = grant_repair(raw)
        self.assertTrue(any("127.0.0.1" in text for text in report["warnings"]))


class GrantFiles(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        raw, _ = written_without_repair()
        self.source = self.root / "event.json"
        self.source.write_text(json.dumps(raw))

    def test_the_original_is_never_overwritten(self):
        original = self.source.read_bytes()
        with self.assertRaisesRegex(ValueError, "new file"):
            grant_file(self.source, self.source)
        existing = self.root / "taken.json"
        existing.write_text("{}")
        with self.assertRaisesRegex(ValueError, "already exists"):
            grant_file(self.source, existing)
        report = grant_file(self.source, self.root / "event.repair.json")
        self.assertEqual(self.source.read_bytes(), original)
        self.assertEqual(len(report["granted"]), 1)
        EventProfile.from_dict(json.loads((self.root / "event.repair.json").read_text()))

    def test_the_command(self):
        args = argparse.Namespace(event_profile=str(self.source), output=str(self.root / "out.json"),
                                  automatic=True, windows_host=[], service=[], enable_capabilities=False, json=True)
        out, err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            self.assertEqual(run(args), 0)
            self.assertIn("repair_service", json.loads((self.root / "out.json").read_text())["allowed_automatic_actions"])
            self.assertEqual(run(args), 2, "a second run refuses to overwrite its own output")
        self.assertEqual(json.loads(out.getvalue())["granted"][0]["service"], "agent-one/web.service")
        self.assertIn("already exists", err.getvalue())


if __name__ == "__main__":
    unittest.main()
