"""Controlled loopback TLS/process tests. No service-manager or VM claims."""
import datetime
import ipaddress
import json
import os
from pathlib import Path
import select
import signal
import subprocess
import sys
import tempfile
import threading
import time
import unittest


def serve(root):
    from sentinel_blue.controller import ControllerApp, ControllerServer, make_handler
    from sentinel_blue.event_profile import load_event_profile
    from sentinel_blue.offline_continuity import ControllerContinuity
    from sentinel_blue.store import Store
    import ssl
    profile = load_event_profile(root / 'profile.json')
    store = Store(root / 'controller.db')
    app = ControllerApp(store, 't'*32, operator_token='o'*32, event_profile=profile)
    app.continuity = ControllerContinuity(app)
    server = ControllerServer(('127.0.0.1', 0), make_handler(app), event_profile=profile)
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    context.load_cert_chain(root / 'cert.pem', root / 'key.pem')
    server.enable_tls(context)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    print(json.dumps({'port': server.server_port, 'authority': app.continuity.authority}), flush=True)
    sys.stdin.readline()
    server.shutdown()
    server.server_close()
    store.close()


class LiveContinuityTests(unittest.TestCase):
    def setUp(self):
        from test_offline_authority import OfflineAuthorityTests
        self.fixture = OfflineAuthorityTests('run')
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)
        self.root = self.fixture.root
        (self.root / 'profile.json').write_text(json.dumps(self.fixture.profile.raw))
        (self.root / 'profile.json').chmod(0o600)
        self.fixture.store.close()
        from cryptography import x509
        from cryptography.x509.oid import NameOID
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, 'sentinel-owned-loopback')])
        now = datetime.datetime.now(datetime.timezone.utc)
        cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key())
                .serial_number(x509.random_serial_number()).not_valid_before(now-datetime.timedelta(minutes=1))
                .not_valid_after(now+datetime.timedelta(hours=1))
                .add_extension(x509.SubjectAlternativeName([x509.IPAddress(ipaddress.ip_address('127.0.0.1'))]), critical=False)
                .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True).sign(key, hashes.SHA256()))
        for filename, data in [('cert.pem', cert.public_bytes(serialization.Encoding.PEM)),
                               ('key.pem', key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))]:
            path = self.root / filename
            path.write_bytes(data)
            path.chmod(0o600)
        self.children = []
        self.addCleanup(self.cleanup_children)

    def cleanup_children(self):
        for child in self.children:
            if child.poll() is None:
                child.kill()
                child.wait(timeout=10)
            child.stdin.close()
            child.stdout.close()
            child.stderr.close()

    def start(self):
        script = "import sys,json;sys.path[:0]=json.loads(sys.argv[1]);from pathlib import Path;from test_continuity_live import serve;serve(Path(sys.argv[2]))"
        child = subprocess.Popen([sys.executable, '-c', script, json.dumps(sys.path), str(self.root)],
                                 stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        self.children.append(child)
        if os.name == 'posix':
            ready, _, _ = select.select([child.stdout], [], [], 20)
            self.assertTrue(ready, 'TLS fixture readiness timed out')
        line = child.stdout.readline()
        if not line:
            self.fail('TLS fixture exited: ' + child.stderr.read()[-1000:])
        identity = json.loads(line)
        from sentinel_blue.agent import AgentClient
        client = AgentClient('https://127.0.0.1:' + str(identity['port']), '', 'agent-one',
                             agent_token=self.fixture.token, ca_file=str(self.root / 'cert.pem'),
                             profile_id=self.fixture.profile.profile_id,
                             profile_fingerprint=self.fixture.profile.fingerprint)
        client.continuity = self.fixture.agent
        return child, client, identity

    def test_real_tls_clean_shutdown_crash_restart_and_stale_response_fence(self):
        child, client, first = self.start()
        agent = self.fixture.agent
        agent.sync(client, self.fixture.journal)
        agent.sync(client, self.fixture.journal)
        self.assertEqual(agent.state['authority'], first['authority'])
        child.stdin.write('stop\n')
        child.stdin.flush()
        self.assertEqual(child.wait(timeout=10), 0)
        with self.assertRaises(Exception):
            agent.sync(client, self.fixture.journal)
        self.assertFalse(agent.online)
        child, client, second = self.start()
        agent.sync(client, self.fixture.journal)
        agent.sync(client, self.fixture.journal)
        self.assertGreater(second['authority']['epoch'], first['authority']['epoch'])
        child.kill()  # Only our disposable process, never a PID recovered from disk.
        child.wait(timeout=10)
        with self.assertRaises(Exception):
            agent.sync(client, self.fixture.journal)
        child, client, third = self.start()
        agent.sync(client, self.fixture.journal)
        agent.sync(client, self.fixture.journal)
        self.assertGreater(third['authority']['epoch'], second['authority']['epoch'])
        with self.assertRaises(ValueError):
            agent.accept_online(first['authority'])
        self.assertEqual(self.fixture.calls, 0)

    def test_real_tls_forged_credential_and_malformed_journal_cannot_gain_authority(self):
        child, client, identity = self.start()
        token = client.agent_token
        client.agent_token = 'x' * 64
        with self.assertRaises(Exception):
            self.fixture.agent.sync(client, self.fixture.journal)
        client.agent_token = token
        # Clear only the transport retry timer to exercise a second independent
        # malformed request. No mutation or authorization gate is bypassed.
        client._retry_at = 0
        with self.assertRaises(Exception):
            client._request('POST', '/api/v1/agent/continuity', {'nonce': 'a'*32, 'events': ['hostile']})
        self.assertEqual(self.fixture.calls, 0)
