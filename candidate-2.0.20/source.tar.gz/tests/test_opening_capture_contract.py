"""Opening inputs must authorize baseline capture before any host changes."""
import copy
import hashlib
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from sentinel_blue.launcher import DeploymentStep
from sentinel_blue.opening import OpeningRunner, _probe_config_bindings
from sentinel_blue.setup import plan_digest
from sentinel_blue.state import write_private_json
from test_service_manifest_policy import profile_for, service_manifest
import test_competition_opening as opening_cases


class OpeningCaptureContractTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.config = self.root/'probes.json'
        self.path = '/etc/host-state.conf'
        write_private_json(self.config, {'protected_paths':[self.path], 'probes':[]})
        self.step = DeploymentStep('host', '192.0.2.10', 'linux', 'local', 'setup', [],
                                   {'agent_id':'agent-one','probe_config':str(self.config)})
        self.manifest = service_manifest(automatic=['capture_restore_point','restart_service'])

    def bind(self, manifests=None, profile=None):
        return _probe_config_bindings([self.step], profile or profile_for(manifests or [self.manifest]), 'range-autonomous')

    def test_undeclared_observed_baseline_path_is_rejected_before_execution(self):
        with self.assertRaisesRegex(ValueError,'baseline capture.*authorized manifest'):
            self.bind()

    def test_declared_baseline_data_does_not_expand_service_restart_prerequisites(self):
        self.manifest['required_data'] = [self.path]
        profile = profile_for([self.manifest])
        binding = self.bind(profile=profile)
        self.assertEqual(binding['host']['sha256'],hashlib.sha256(self.config.read_bytes()).hexdigest())
        from sentinel_blue.service_recovery import recovery_contract
        self.assertEqual(recovery_contract(profile,'agent-one','web.service')['files'],['/etc/web.conf'])

    def test_host_action_and_ambiguous_path_contracts_are_rejected(self):
        self.manifest['required_data'] = [self.path]
        for change in ('host','action','duplicate','global'):
            with self.subTest(change=change):
                rows=[copy.deepcopy(self.manifest)]
                if change=='host':rows[0]['host']='another-agent'
                if change=='action':rows[0]['allowed_automatic_actions']=['restart_service']
                if change=='duplicate':rows.append(copy.deepcopy(rows[0]))
                profile=profile_for(rows,automatic_actions=['restart_service'] if change=='global' else None)
                with self.assertRaisesRegex(ValueError,'baseline capture'):
                    self.bind(profile=profile)

    def test_windows_paths_match_the_same_exact_case_insensitive_contract(self):
        write_private_json(self.config, {'protected_paths':[r'C:\Config\Host.json']})
        self.manifest['required_data']=[r'c:\config\host.json']
        self.assertIn('host',self.bind())

    def test_probe_content_changes_the_approved_plan_digest(self):
        self.manifest['required_data']=[self.path]
        before=plan_digest({'probe_config_bindings':self.bind()})
        write_private_json(self.config, {'protected_paths':[self.path], 'probes':[{'kind':'http','target':'http://192.0.2.10/','expected_body':'changed'}]})
        self.assertNotEqual(before,plan_digest({'probe_config_bindings':self.bind()}))

    def test_changed_configuration_is_held_before_state_or_transport_mutations(self):
        case=opening_cases.OpeningDeadlineTests('test_complete_opening_includes_prior_upload_time_and_refuses_replay')
        case.setUp()
        self.addCleanup(case.tearDown)
        self.manifest['required_data']=[self.path]
        case.plan['probe_config_bindings']=self.bind()
        approved=plan_digest(case.plan)
        write_private_json(self.config, {'protected_paths':[]})
        with patch.object(type(case.profile),'verify_release_file'):
            with self.assertRaisesRegex(ValueError,'probe configuration changed after plan approval'):
                case.runner().execute(case.root/'state',approved)
        self.assertFalse((case.root/'state').exists())
        self.assertEqual(case.transport.applies,[])


if __name__=='__main__':
    unittest.main()
