import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import time
import unittest
from unittest.mock import patch


class RecoveryAcceptanceEdges(unittest.TestCase):
    def fixture(self):
        from test_controller_restore_workflow import RestoreWorkflowTests
        fixture = RestoreWorkflowTests('run')
        fixture.setUp()
        self.addCleanup(fixture.doCleanups)
        return fixture

    def test_queued_at_backup_is_unknown_after_restore_not_assumed_unexecuted(self):
        f = self.fixture()
        f.store.register_agent('agent-one', 'host', 'Linux')
        f.store._connection.execute("INSERT INTO actions(action_id,agent_id,action_type,parameters_json,status,created_at) VALUES('old-work','agent-one','restart_service','{}','queued',?)", (time.time(),))
        f.store._connection.commit()
        saved = f.backup()
        f.loss()
        result = f.restore(saved)
        db = sqlite3.connect(f.db)
        try:
            self.assertEqual(db.execute("SELECT status FROM actions WHERE action_id='old-work'").fetchone()[0], 'outcome_unknown')
        finally:
            db.close()
        self.assertEqual(result['reconciliation']['agents_pending_reconciliation'], ['agent-one'])

    def test_orphan_wal_preserved_when_database_is_lost(self):
        f = self.fixture()
        saved = f.backup()
        f.loss()
        path = Path(str(f.db) + '-wal')
        path.write_bytes(b'owned orphan WAL evidence')
        path.chmod(0o600)
        result = f.restore(saved)
        self.assertFalse(path.exists())
        preserved = f.root / 'receipt' / result['work_directory'] / 'preserved-wal'
        self.assertEqual(preserved.read_bytes(), b'owned orphan WAL evidence')

    def test_preparation_crash_can_retry_without_discarding_partial_material(self):
        f = self.fixture()
        saved = f.backup()
        f.loss()
        from sentinel_blue import controller_restore
        original = controller_restore._stage_state
        def crash(*args, **kwargs):
            original(*args, **kwargs)
            raise InterruptedError('preparation interrupted before receipt publication')
        with patch.object(controller_restore, '_stage_state', side_effect=crash):
            with self.assertRaises(InterruptedError):
                f.restore(saved)
        result = f.restore(saved)
        self.assertEqual(result['phase'], 'complete')
        self.assertEqual(len(list((f.root / 'receipt').glob('candidate-*'))), 2)

    def test_complete_capsule_failure_does_not_advance_protected_anchor(self):
        f = self.fixture()
        from sentinel_blue.recovery import load_anchor
        before = load_anchor(f.anchor, f.key)
        with patch('sentinel_blue.controller_restore._signed', side_effect=OSError('simulated storage loss')):
            with self.assertRaises(OSError):
                f.backup()
        self.assertEqual(load_anchor(f.anchor, f.key), before)

    def test_rejected_backup_has_authenticated_durable_receipt(self):
        f = self.fixture()
        saved = f.backup()
        path = Path(saved['capsule']) / 'inputs/event_profile'
        path.write_bytes(path.read_bytes() + b' ')
        with self.assertRaises(ValueError):
            f.restore(saved)
        from sentinel_blue.controller_restore import verify_receipts
        result = verify_receipts(f.root / 'receipt', f.key)
        self.assertEqual(len(result['rejections']), 1)
        self.assertIn('tampered', result['rejections'][0]['reason'])

    def test_unrelated_valid_database_is_not_overwritten(self):
        f = self.fixture()
        saved = f.backup()
        f.loss()
        db = sqlite3.connect(f.db)
        db.execute('CREATE TABLE teammate(id INTEGER)')
        db.commit()
        db.close()
        f.db.chmod(0o600)
        original = f.db.read_bytes()
        with self.assertRaisesRegex(ValueError, 'identity/schema'):
            f.restore(saved)
        self.assertEqual(f.db.read_bytes(), original)

    def test_actual_process_exit_after_database_replace_resumes(self):
        f = self.fixture()
        saved = f.backup()
        f.loss()
        script = """
import os,sys,json
sys.path[:0]=json.loads(sys.argv[1])
from sentinel_blue.controller import ControllerDatabaseLock
from sentinel_blue.controller_restore import restore_capsule
args=json.loads(sys.argv[2])
with ControllerDatabaseLock(args['database']):
    restore_capsule(args.pop('capsule'), key=b'r'*32, failpoint=lambda phase: os._exit(73) if phase=='database_replaced' else None, **args)
"""
        args = dict(capsule=saved['capsule'], database=str(f.db), anchor_path=str(f.anchor),
                    release_sha256='a'*64, profile_fingerprint=f.profile.fingerprint,
                    ledger_directory=str(f.ledger.directory), receipt_directory=str(f.root/'receipt'))
        result = subprocess.run([sys.executable, '-c', script, json.dumps(sys.path), json.dumps(args)], capture_output=True, text=True, timeout=30)
        self.assertEqual(result.returncode, 73, result.stderr[-500:])
        self.assertEqual(f.restore(saved)['phase'], 'complete')

    def test_capsule_pruning_keeps_latest_and_two_complete_copies(self):
        f = self.fixture()
        copies = [f.backup() for _ in range(4)]
        from sentinel_blue.controller_restore import prune_capsules
        removed = prune_capsules(f.backups, f.anchor, f.key, keep=2, maximum_bytes=0)
        self.assertEqual(len(removed), 2)
        self.assertTrue(Path(copies[-1]['capsule']).exists())
        self.assertTrue(Path(copies[-2]['capsule']).exists())


class ContinuityAcceptanceEdges(unittest.TestCase):
    def fixture(self):
        from test_offline_authority import OfflineAuthorityTests
        fixture = OfflineAuthorityTests('run')
        fixture.setUp()
        self.addCleanup(fixture.doCleanups)
        return fixture

    def test_pause_retains_explicit_online_emergency_rollback(self):
        f = self.fixture()
        f.app.emergency_stop()
        f.agent.sync(f.client, f.journal)
        f.agent.accept_online(f.app.continuity.authority, [{'action_type': 'rollback_service'}])
        with self.assertRaisesRegex(ValueError, 'Pause'):
            f.agent.accept_online(f.app.continuity.authority, [{'action_type': 'restart_service'}])
        f.ledger.pause('withdraw')
        with self.assertRaises(ValueError):
            f.agent.accept_online(f.app.continuity.authority, [{'action_type': 'rollback_service'}])

    def test_protected_epoch_floor_survives_rollback_of_signed_state_file(self):
        f = self.fixture()
        old = f.agent.path.read_bytes()
        from sentinel_blue.offline_continuity import ControllerContinuity, AgentContinuity
        f.app.continuity = ControllerContinuity(f.app)
        f.agent.sync(f.client, f.journal)
        floor = dict(f.agent.state['authority'])
        f.agent.path.write_bytes(old)
        restored = AgentContinuity(f.root, f.profile, 'agent-one', f.token, ledger=f.ledger)
        self.assertEqual(restored.state['authority'], floor)
        self.assertTrue(restored.state['paused'])
        self.assertIsNone(restored.state['policy'])

    def test_restored_ack_floor_requests_complete_retained_offline_prefix(self):
        f = self.fixture()
        f.authorize()
        f.repair()
        original = f.app.continuity._row('agent-one')
        f.agent.sync(f.client, f.journal)
        from sentinel_blue.offline_continuity import put_state
        with f.store._lock:
            f.store._connection.execute("DELETE FROM controller_state WHERE state_key LIKE 'continuity_event:%'")
            f.store._connection.execute("DELETE FROM actions WHERE result_source='agent-offline'")
            put_state(f.store, 'continuity_agent:agent-one', original)
            f.store._connection.commit()
        f.agent.sync(f.client, f.journal)
        self.assertEqual(f.agent.state['ack']['sequence'], 0)
        self.assertFalse(f.agent.online)
        f.agent.sync(f.client, f.journal)
        self.assertTrue(f.agent.online)
        self.assertEqual(f.calls, 1)

    def test_relay_observer_is_not_a_changing_authority_participant(self):
        f = self.fixture()
        f.store.register_agent('sentinel-relay-probes', 'relay', 'virtual')
        self.assertTrue(f.app.continuity.ready('agent-one'))

    def test_valid_signature_does_not_extend_expired_offline_policy(self):
        f = self.fixture()
        f.authorize()
        from sentinel_blue import recovery
        policy = dict(f.agent.state['policy']['signed'])
        policy.update(created_at=time.time()-1000, expires_at=time.time()-1)
        f.agent.state['policy'] = recovery.sign_payload(policy, f.agent.key, purpose='offline-policy')
        f.outage()
        f.step(2)
        self.assertIn('expired', f.agent.status)
        self.assertEqual(f.calls, 0)
