"""Queued-restart target revalidation; no native service-manager acceptance.

Real scoped profiles, envelopes, SQLite journals and temporary files exercise
agent/executor admission. Service controls are explicit mocks. Clock fixtures
exercise elapsed preflight without sleeping ninety seconds.
"""
import copy
import hashlib
import math
import tempfile
import time
import unittest
from dataclasses import asdict
from pathlib import Path
from unittest.mock import MagicMock, patch

from sentinel_blue.actions import ActionExecutor
from sentinel_blue.agent import execute_queued_action
from sentinel_blue.event_profile import EventProfile
from sentinel_blue.protocol import ProbeResult
from sentinel_blue.service_recovery import (
    RECOVERY_FRESHNESS_SECONDS, check_recovery_deadline, check_restart_target,
    recovery_parameters, validate_automatic_recovery,
)
from sentinel_blue.service_repair import repair_parameters
from sentinel_blue.state import ActionJournal
from sentinel_blue.store import Store
from test_autonomous_service_recovery import fixtures, stopped
from test_service_repair import repair_fixture

SPEC = {'name': 'health', 'kind': 'http', 'target': 'http://127.0.0.1:18876/health'}


def queued_fixture(path='/etc/web.conf'):
    profile, baseline = fixtures(path)
    raw = copy.deepcopy(profile.raw)
    raw['services'][0]['expected_transactions'] = [SPEC]
    raw['services'][0]['required_data'] = ['/srv/business/data']
    profile = EventProfile.from_dict(raw)
    current = stopped(baseline)
    plan = recovery_parameters(profile, 'agent-one', 'web.service', baseline, current)
    latest = copy.deepcopy(current)
    latest.update(sequence=3, observed_at=time.time())
    return profile, baseline, plan, latest


def volume(mount='/srv/business', **kwargs):
    return {'mount_point': mount, 'total_bytes': 104857600, 'free_bytes': 52428800,
            'total_inodes': 1000, 'free_inodes': 900, 'read_only': False, **kwargs}


class QueuedTargetContractTests(unittest.TestCase):
    def setUp(self):
        self.profile, self.baseline, self.plan, self.latest = queued_fixture()

    def validate(self):
        return validate_automatic_recovery(self.profile, 'agent-one', self.plan, self.latest)

    def test_unchanged_stopped_target_remains_admitted(self):
        self.validate()

    def test_disabled_target_after_planning_is_held(self):
        self.latest['services'][0]['start_mode'] = 'disabled'
        with self.assertRaisesRegex(ValueError, 'disabled or masked'):
            self.validate()

    def test_masked_target_after_planning_is_held(self):
        self.latest['services'][0]['start_mode'] = 'masked'
        with self.assertRaisesRegex(ValueError, 'disabled or masked'):
            self.validate()

    def test_runtime_mask_after_planning_is_held(self):
        self.latest['services'][0]['start_mode'] = 'masked-runtime'
        with self.assertRaisesRegex(ValueError, 'disabled or masked'):
            self.validate()

    def test_missing_target_is_held(self):
        self.latest['services'] = []
        with self.assertRaisesRegex(ValueError, 'missing or ambiguous'):
            self.validate()

    def test_duplicate_target_is_held(self):
        self.latest['services'] *= 2
        with self.assertRaisesRegex(ValueError, 'missing or ambiguous'):
            self.validate()

    def test_malformed_target_collection_is_held(self):
        for value in (None, {}, 'stopped', [None]):
            with self.subTest(value=value):
                self.latest['services'] = value
                with self.assertRaises(ValueError):
                    self.validate()

    def test_unknown_or_transitional_state_is_held(self):
        for state in ('unknown', 'activating', 'deactivating', 'reloading', ''):
            with self.subTest(state=state):
                self.latest['services'][0]['state'] = state
                with self.assertRaisesRegex(ValueError, 'confirmed stopped'):
                    self.validate()

    def test_start_limit_is_held(self):
        self.latest['services'][0].update(result='start-limit-hit', state='failed')
        with self.assertRaisesRegex(ValueError, 'failure state'):
            self.validate()

    def test_oom_verdict_is_held(self):
        self.latest['services'][0].update(result='oom-kill')
        with self.assertRaisesRegex(ValueError, 'memory'):
            self.validate()

    def test_native_resource_failure_is_held(self):
        self.latest['services'][0].update(result='resources')
        with self.assertRaisesRegex(ValueError, 'resources'):
            self.validate()

    def test_native_loop_is_held(self):
        self.latest['services'][0].update(substate='auto-restart')
        with self.assertRaisesRegex(ValueError, 'loop'):
            self.validate()

    def test_port_conflict_is_held(self):
        self.latest['listeners'] = [{'port': 18876, 'address': '127.0.0.1', 'protocol': 'tcp', 'process': 'fixture,pid=222'}]
        with self.assertRaisesRegex(ValueError, 'listening port'):
            self.validate()

    def test_socket_activation_is_not_newly_misclassified(self):
        self.latest['listeners'] = [{'port': 18876, 'address': '127.0.0.1', 'protocol': 'tcp', 'process': 'systemd,pid=1,fd=4'}]
        self.validate()

    def test_unrelated_port_is_not_a_blocker(self):
        self.latest['listeners'] = [{'port': 18877, 'address': '127.0.0.1', 'protocol': 'tcp', 'process': 'fixture,pid=222'}]
        self.validate()

    def test_business_data_volume_full_is_held(self):
        self.latest['filesystems'] = [volume(free_bytes=0)]
        with self.assertRaisesRegex(ValueError, 'no room'):
            self.validate()

    def test_business_data_inode_exhaustion_is_held(self):
        self.latest['filesystems'] = [volume(free_inodes=0)]
        with self.assertRaisesRegex(ValueError, 'inodes'):
            self.validate()

    def test_business_data_readonly_is_held(self):
        self.latest['filesystems'] = [volume(read_only=True)]
        with self.assertRaisesRegex(ValueError, 'read.only'):
            self.validate()

    def test_unrelated_full_volume_is_not_a_blocker(self):
        self.latest['filesystems'] = [volume('/unrelated', free_bytes=0)]
        self.validate()

    def test_absent_capacity_telemetry_keeps_legacy_contract(self):
        self.latest.pop('filesystems', None)
        self.validate()

    def test_old_native_result_on_running_target_is_validation_only(self):
        self.latest['services'][0].update(state='running', result='oom-kill', start_mode='disabled')
        self.validate()

    def test_historical_restart_count_is_not_an_invented_new_loop(self):
        self.latest['services'][0].update(restart_count=400, substate='dead')
        self.validate()

    def test_guard_boot_and_sequence_binding_is_retained(self):
        for field, value in (('boot_id', 'another-boot'), ('sequence', 1)):
            with self.subTest(field=field):
                bad = copy.deepcopy(self.latest); bad[field] = value
                with self.assertRaises(ValueError):
                    validate_automatic_recovery(self.profile, 'agent-one', self.plan, bad)

    def test_original_plan_is_not_mutated_by_revalidation(self):
        before = copy.deepcopy(self.plan)
        self.validate()
        self.assertEqual(before, self.plan)

    def test_manual_unguarded_restart_does_not_gain_automatic_authority(self):
        with self.assertRaisesRegex(ValueError, 'exact manifest'):
            validate_automatic_recovery(self.profile, 'agent-one', {'service': 'web.service', 'probes': [SPEC]}, self.latest)

    def test_changed_manifest_probe_still_refused(self):
        # Queued envelopes are serialized copies, not aliases to profile lists.
        self.plan = copy.deepcopy(self.plan)
        self.plan['probes'][0]['target'] = 'http://127.0.0.1:18877/'
        with self.assertRaisesRegex(ValueError, 'exact manifest'):
            self.validate()

    def test_windows_disabled_contract_logic_is_held_not_native_acceptance(self):
        self.latest['platform'] = 'Windows'
        self.latest['services'][0]['start_mode'] = 'Disabled'
        with self.assertRaisesRegex(ValueError, 'disabled or masked'):
            self.validate()


class QueuedTargetExecutionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.target = self.root/'web.conf'; self.target.write_bytes(b'trusted')
        self.profile, self.baseline, self.plan, self.latest = queued_fixture(str(self.target))
        self.ex = ActionExecutor(self.root/'state', allow_service_recovery=True)
        self.state = 'stopped'; self.transitions = []
        def change(_service, desired):
            self.transitions.append(desired); self.state = desired
        for item in (patch.object(self.ex, '_service_state', side_effect=lambda _: self.state),
                     patch.object(self.ex, '_set_service_state', side_effect=change),
                     patch.object(self.ex, '_wait_for_service_probes', return_value=([ProbeResult(SPEC['name'], SPEC['target'], True)], 3, True))):
            item.start(); self.addCleanup(item.stop)

    def execute_queued(self):
        store = Store(':memory:'); self.addCleanup(store.close)
        store.queue_action('agent-one', 'restart_service', self.plan, automated=True,
                           profile_id=self.profile.profile_id, profile_fingerprint=self.profile.fingerprint,
                           autonomy_mode=self.profile.autonomy_mode)
        action = asdict(store.pending_actions('agent-one')[0])
        journal = ActionJournal(self.root/'journal')
        result = execute_queued_action(journal, self.ex, action, self.latest, {'action_safe': True}, self.profile)
        return result, action, journal

    def assert_untouched(self, result):
        self.assertFalse(result['success'], result)
        self.assertEqual(self.transitions, [])
        self.assertEqual(self.target.read_bytes(), b'trusted')
        self.assertEqual(list((self.root/'state').glob('service-transaction-*.json')), [])

    def test_agent_refuses_late_disabled_target_without_executor_mutation(self):
        self.latest['services'][0]['start_mode'] = 'disabled'
        self.assert_untouched(self.execute_queued()[0])

    def test_agent_refuses_late_data_fault_without_executor_mutation(self):
        self.latest['filesystems'] = [volume(read_only=True)]
        self.assert_untouched(self.execute_queued()[0])

    def test_agent_refuses_late_port_fault_without_executor_mutation(self):
        self.latest['listeners'] = [{'port': 18876, 'address': '127.0.0.1', 'protocol': 'tcp', 'process': 'fixture,pid=222'}]
        self.assert_untouched(self.execute_queued()[0])

    def test_same_refused_envelope_is_not_silently_retried_when_target_recovers(self):
        self.latest['services'][0]['start_mode'] = 'disabled'
        result, action, journal = self.execute_queued()
        self.latest['services'][0]['start_mode'] = 'enabled'
        again = execute_queued_action(journal, self.ex, action, self.latest, {'action_safe': True}, self.profile)
        self.assertEqual(again, result)
        self.assertEqual(self.transitions, [])

    def test_genuine_unchanged_outage_can_still_start(self):
        result, _, _ = self.execute_queued()
        self.assertTrue(result['success'], result)
        self.assertEqual(self.transitions, ['running'])

    def test_service_that_recovered_itself_is_only_validated(self):
        self.latest['services'][0]['state'] = 'running'; self.state = 'running'
        self.latest['services'][0]['result'] = 'start-limit-hit'
        result, _, _ = self.execute_queued()
        self.assertTrue(result['success'], result)
        self.assertEqual(self.transitions, [])

    def test_direct_executor_does_not_bypass_late_disabled_target(self):
        self.latest['services'][0]['start_mode'] = 'disabled'
        self.assert_untouched(self.ex.execute('restart_service', self.plan, self.latest))

    def test_direct_executor_checks_bound_configuration_volume(self):
        self.latest['filesystems'] = [volume(str(self.root), free_bytes=0)]
        self.assert_untouched(self.ex.execute('restart_service', self.plan, self.latest))

    def test_target_stopped_after_running_observation_requires_new_diagnosis(self):
        self.latest['services'][0]['state'] = 'running'; self.state = 'stopped'
        result = self.ex.execute('restart_service', self.plan, self.latest)
        self.assert_untouched(result)
        self.assertIn('stopped after', result['message'])

    def test_disabled_guard_is_checked_even_before_dry_run_dispatch(self):
        self.ex.allow_service_recovery = False
        self.latest['services'][0]['start_mode'] = 'disabled'
        self.assert_untouched(self.ex.execute('restart_service', self.plan, self.latest))

    def test_slow_native_file_preflight_cannot_admit_stale_restart(self):
        now = time.time(); self.plan['recovery_guard']['observed_at'] = now-1
        self.latest['observed_at'] = now
        real_read = self.ex.restore_points._read_target
        clock = [now]
        def slow_read(path):
            result = real_read(path); clock[0] += 95; return result
        with patch('time.time', side_effect=lambda: clock[0]), patch.object(self.ex.restore_points, '_read_target', side_effect=slow_read):
            result = self.ex.execute('restart_service', self.plan, self.latest)
        self.assert_untouched(result)
        self.assertIn('expired during preflight', result['message'])

    def test_already_running_service_does_not_create_restart_journal(self):
        self.state = 'running'
        result, _, _ = self.execute_queued()
        self.assertTrue(result['success'], result)
        self.assertEqual(self.transitions, [])
        self.assertEqual(list((self.root/'state').glob('service-transaction-*.json')), [])


class RecoveryDeadlineTests(unittest.TestCase):
    def test_exact_boundary_remains_admitted(self):
        check_recovery_deadline({'recovery_guard': {'observed_at': 1000}}, now=1090)

    def test_expired_guard_is_refused(self):
        with self.assertRaisesRegex(ValueError, 'expired'):
            check_recovery_deadline({'recovery_guard': {'observed_at': 1000}}, now=1090.001)

    def test_future_guard_is_refused(self):
        with self.assertRaises(ValueError):
            check_recovery_deadline({'recovery_guard': {'observed_at': 1000}}, now=999)

    def test_invalid_clock_or_guard_is_refused(self):
        for value in (True, None, '1000', math.inf, math.nan):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    check_recovery_deadline({'recovery_guard': {'observed_at': value}}, now=1000)
        with self.assertRaises(ValueError):
            check_recovery_deadline({'recovery_guard': {'observed_at': 1000}}, now=math.nan)

    def test_unguarded_operator_action_is_not_reinterpreted(self):
        check_recovery_deadline({'service': 'web.service'}, now=1000)

    def test_slow_running_repair_precheck_holds_before_mutation(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory); target=root/'web.conf'; target.write_bytes(b'trusted')
            profile, baseline=repair_fixture(str(target)); current=copy.deepcopy(baseline)
            now=time.time(); current.update(sequence=2, observed_at=now-1); current['probes'][0]['healthy']=False
            plan=repair_parameters(profile,'agent-one','web.service',baseline,current)
            ex=ActionExecutor(root/'state',allow_service_recovery=True,allow_restoration=True, authorized_networks=['127.0.0.0/8'])
            clock=[now]
            def delayed(specs):
                clock[0]+=95
                return [ProbeResult(spec['name'],spec['target'],False) for spec in specs]
            with patch('time.time',side_effect=lambda:clock[0]),patch.object(ex,'_service_state',return_value='running'),patch.object(ex,'_set_service_state') as change,patch.object(ex.repairs,'_probe',side_effect=delayed):
                result=ex.execute('repair_service',plan,current)
            self.assertFalse(result['success'],result); self.assertIn('expired during preflight',result['message'])
            change.assert_not_called(); self.assertEqual(target.read_bytes(),b'trusted')
            self.assertEqual(list((root/'state').glob('service-repair-*.json')),[])


if __name__ == '__main__':
    unittest.main()
