"""Review-only private fixtures; no native service/network mutations."""
from __future__ import annotations
from contextlib import contextmanager, ExitStack
from dataclasses import asdict
import copy, hashlib, json, os, pathlib, shlex, subprocess, sys, tempfile, time, uuid
from unittest.mock import patch
from sentinel_blue import setup_linux_transaction as tx
from sentinel_blue.setup_recipes import _linux_service
from sentinel_blue.mutation_ledger import MutationLedger
from sentinel_blue.withdrawal import _restore_one

@contextmanager
def setup_fixture():
    with ExitStack() as stack:
        root=pathlib.Path(stack.enter_context(tempfile.TemporaryDirectory(prefix='sb-review-1999-',dir='/var/lib')))
        target=root/'owned.conf'; target.write_text('BEFORE\n'); target.chmod(0o644)
        bin=root/'bin'; bin.mkdir(); ctl=bin/'systemctl'
        ctl.write_text('#!/bin/sh\ncase "$1" in is-enabled) echo disabled;; esac\nexit 0\n');ctl.chmod(0o700)
        options={'service':'sb-review-fixture.service','enable':False,'files':[{'path':str(target),'mode':'0644','previous_sha256':hashlib.sha256(b'BEFORE\n').hexdigest()}]}
        _, script, _=_linux_service(options,root,generated_sources={str(target):'AFTER\n'})
        script=script.replace('/var/lib/sentinel-setup-backup.XXXXXXXX',str(root/'backup.XXXXXXXX'))
        spec={'version':1,'recipe':'linux-service','service':options['service'],'apply_sha256':hashlib.sha256(script.encode()).hexdigest(),
            'files':[{'path':str(target),'mode':'0644','previous_sha256':hashlib.sha256(b'BEFORE\n').hexdigest(),'sha256':hashlib.sha256(b'AFTER\n').hexdigest()}]}
        stack.enter_context(patch.object(tx,'ROOT',root/'transactions'))
        stack.enter_context(patch.object(tx,'service_state',return_value={'exists':True,'active':True,'enabled':'disabled','configuration_sha256':'a'*64}))
        stack.enter_context(patch.object(tx,'command'))
        stack.enter_context(patch.dict(os.environ,{'PATH':str(bin)+':'+os.environ['PATH']}))
        token=uuid.uuid4().hex; ledger=MutationLedger(root/'ledger')
        def run(phase,chosen_token=None):return tx.run(phase,spec,chosen_token or token,script,ledger_directory=root/'ledger')
        def state():return tx.read(tx.ROOT/token/'state.json')
        yield root,target,spec,token,ledger,run,state

def outcome(fn):
    try:fn();return 'success'
    except BaseException as e:return type(e).__name__+':'+str(e)

def setup_confirmation():
    with setup_fixture() as (root,target,spec,token,ledger,run,state):
        run('apply')
        with patch.object(MutationLedger,'commit',side_effect=RuntimeError('injected transient ledger commit failure')):
            first=outcome(lambda:run('commit'))
        statuses=[r['status'] for r in ledger.actions()]
        retry=outcome(lambda:run('commit')); rollback=outcome(lambda:run('rollback'))
        fresh=outcome(lambda:run('apply',uuid.uuid4().hex))
        ledger.pause('review-withdraw')
        withdrawal=outcome(lambda:_restore_one(ledger,'setup-'+token))
        return dict(first=first,native_state=state()['status'],ledger_statuses=statuses,retry_commit=retry,rollback=rollback,new_transaction_apply=fresh,withdrawal=withdrawal,contents=target.read_text())

def setup_revision():
    results={}
    for phase in ('rollback','commit'):
        with setup_fixture() as (root,target,spec,token,ledger,run,state):
            run('apply');old=tx.ledger_capture(spec)
            replacement=root/'teammate-replacement';replacement.write_bytes(target.read_bytes());replacement.chmod(0o644);os.replace(replacement,target)
            current=tx.ledger_capture(spec)
            result=outcome(lambda:run(phase))
            results[phase]=dict(revision_changed=old['file_evidence']!=current['file_evidence'],native_capture_unchanged=old['native']==current['native'],operation=result,contents_after=target.read_text(),ledger_statuses=[r['status'] for r in ledger.actions()],native_state=state()['status'])
    return results

def protected_session():
    from sentinel_blue import collectors as c
    from sentinel_blue.identity_guard import analyze_protected_access
    from sentinel_blue.process_identity import inspect_process_identity
    from sentinel_blue.risk import RiskModel
    import pwd
    user=pwd.getpwuid(os.getuid()).pw_name; uid=str(os.getuid())
    proc=subprocess.Popen([sys.executable,'-c','import time;time.sleep(10)'])
    try:
        identity=inspect_process_identity(proc.pid)
        fake=f'{user} pts/9 2026-09-21 16:00 . {proc.pid} (192.0.2.7)\n'
        with patch.object(c,'_run',return_value=subprocess.CompletedProcess(['who','-u'],0,fake,'')):
            errors=[]; sessions=c._linux_sessions({user},errors)
        host={'agent_id':'review-host','platform':'Linux','accounts':[{'name':user,'account_id':uid,'enabled':True,'privileged':True}], 'sessions':[asdict(s) for s in sessions]}
        guard=[{'agent_id':'review-host','name':user,'account_id':uid,'allowed_sources':['192.0.2.7/32']}]
        alerts=analyze_protected_access(host,{user},guard,RiskModel())
        comparison=copy.deepcopy(host);comparison['sessions'][0]['process_identity']=None
        fallback=analyze_protected_access(comparison,{user},guard,RiskModel())
        return {'actual_process_identity_uid':identity['user_id'],'expected_account_id':uid,'collector_errors':errors,'sessions':host['sessions'],'alerts':[asdict(x) for x in alerts],'alerts_without_process_identity':[asdict(x) for x in fallback], 'scope':'real harmless child identity; who peer/tty rows and authorized guard modeled'}
    finally:
        proc.terminate();proc.wait(timeout=4)

def main():
    results={'module_origin':tx.__file__,'setup_confirmation':setup_confirmation(),'setup_revision':setup_revision(),'protected_session':protected_session()}
    pathlib.Path(sys.argv[1]).write_text(json.dumps(results,indent=2)); print(json.dumps(results,indent=2))
if __name__=='__main__':main()
