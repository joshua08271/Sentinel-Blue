"""R208 (independent 2.0.8 review) regressions. Real private files, SQLite and
signed loopback controller HTTP; native process launch is inert. No VM mutation."""
from __future__ import annotations

import copy
import json
import tempfile
import threading
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from sentinel_blue import desktop_jobs, setup_redo
from sentinel_blue.controller import OPERATOR_EMERGENCY_REPLAY_RESERVE, OPERATOR_REPLAY_MARKERS
from sentinel_blue.event_profile import EventProfile
from sentinel_blue.job_control import JobControl, SetupPaused
from sentinel_blue.redo_governance import CHECK_PATH, POLICY_MAX_AGE, WorkerGuard, prepare_guard, snapshot_hold
from sentinel_blue.setup import PAUSE_POLL_SECONDS, SetupRunner, compile_plan, plan_digest
from sentinel_blue.state import write_private_json
from sentinel_blue.store import REDO_HOLD_BOUND, Store
from redo_gate_fixture import live_client
from test_service_repair import damage, repair_fixture
from test_setup import FixtureTransport, fixture as setup_fixture, healthy_probe
from test_store_controller import _promote_integrity_baseline

DIRTY = {'success': False, 'rolled_back': False, 'review_required': True, 'errors': ['start', 'rollback']}
CLEAN = {'success': False, 'rolled_back': True, 'errors': ['start failed']}


def insert_repair(store, name, service, result, *, status='failed', age=1000, agent='local-linux', parameters=None):
    at = time.time() - age
    store._connection.execute(
        "INSERT INTO actions(action_id,agent_id,action_type,parameters_json,status,created_at,completed_at,result_json) "
        "VALUES(?,?,?,?,?,?,?,?)",
        (name, agent, 'repair_service', json.dumps({'service': service} if parameters is None else parameters),
         status, at - 5, at, None if result is None else json.dumps(result)))
    store._connection.commit()


def two_service_profile(path):
    profile, base = repair_fixture(str(path))
    raw = copy.deepcopy(profile.raw)
    web = raw['services'][0]
    web['host'] = 'local-linux'
    db = copy.deepcopy(web)
    db['service_id'] = 'db.service'
    db['expected_transactions'] = [{'name': 'local-db', 'kind': 'http', 'target': 'http://127.0.0.1:8766/health'}]
    db['repair_policy'] = dict(db['repair_policy'], restore_files=[])   # one owner per restored file
    raw['services'].append(db)
    base['agent_id'] = 'local-linux'
    base['observed_at'] = time.time()
    base['services'].append({'name': 'db.service', 'state': 'running'})
    base['probes'].append({'name': 'local-db', 'target': 'http://127.0.0.1:8766/health', 'healthy': True})
    return EventProfile.from_dict(raw), base


class LiveController(unittest.TestCase):
    """A local workspace with an approved setup record and a real signed controller."""

    def setUp(self):
        temp = tempfile.TemporaryDirectory(prefix='sb209-')
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        target = self.root / 'target'
        target.mkdir()
        self.path = target / 'web.conf'
        self.path.write_bytes(b'trusted')
        self.path.chmod(0o600)
        self.profile, self.base = two_service_profile(self.path)
        self.app, self.store, self.client = live_client(self, self.profile, self.base)
        write_private_json(self.root / 'profile.json', self.profile.raw)
        self.workspace = self.root / 'session'
        self.workspace.mkdir(mode=0o700)
        original = self.root / 'jobs/original/job.json'
        original.parent.mkdir(mode=0o700, parents=True)
        write_private_json(original, {'kind': 'setup'})
        write_private_json(original.parent / 'result.json', {'status': 'passed'})
        write_private_json(self.root / 'inventory.json', {
            'hosts': [{'name': 'local-linux', 'address': '127.0.0.1'}],
            'setup': {'tasks': [{'id': 't-web', 'host': 'local-linux', 'service_id': 'web.service'},
                                {'id': 't-db', 'host': 'local-linux', 'service_id': 'db.service'}]}})
        self.record = setup_redo.record_approved_setup(self.workspace, {
            'kind': 'setup', 'inventory': str(self.root / 'inventory.json'),
            'event_profile': str(self.root / 'profile.json'), 'runtime': str(self.root / 'sb.pyz'),
            'range_deployment': True, 'approved_digest': 'a' * 64}, job_root=self.root / 'jobs', job_path=original)
        self.launched = []

    def launcher(self, job, directory):
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / 'job.json'
        write_private_json(path, job)
        self.launched.append(job)
        return None, path

    def break_web(self):
        state = setup_redo.load_state(self.workspace)
        state['seen_healthy'] = ['web.service', 'db.service']
        setup_redo.save_state(self.workspace, state)
        self.path.write_bytes(b'damaged')
        current = damage(self.base, 2)
        current['observed_at'] = time.time()
        self.app.ingest(current)


class ManualRedoUsesLiveGovernance(LiveController):
    """R208-01: the operator-started redo was always refused as 'stale'."""

    def test_manual_redo_with_real_controller_launches(self):
        self.break_web()
        self.app.set_autonomy_mode('approval-based')
        entry = setup_redo.manual_redo(self.workspace, None, client=self.client, launcher=self.launcher)
        self.assertEqual(entry['units'], ['web.service'])
        self.assertTrue(Path(self.launched[0]['redo_guard_file']).is_file())

    def test_repeated_manual_redo_is_never_refused_as_stale(self):
        self.break_web()
        for _ in range(5):
            verdict = setup_redo.assess(self.client.dashboard(), self.record, setup_redo.load_state(self.workspace),
                                        time.time())
            self.assertNotIn('fresh complete', verdict['units']['web.service']['reason'])

    def test_manual_redo_still_honours_observe_mode(self):
        self.break_web()
        self.app.set_autonomy_mode('observe')
        with self.assertRaisesRegex(ValueError, 'governance'):
            setup_redo.manual_redo(self.workspace, None, client=self.client, launcher=self.launcher)
        self.assertFalse(self.launched)

    def test_all_healthy_manual_redo_explains_itself(self):
        with self.assertRaisesRegex(ValueError, 'nothing to redo'):
            setup_redo.manual_redo(self.workspace, None, client=self.client, launcher=self.launcher)
        self.assertFalse(self.launched)

    def test_client_stamps_local_receipt_time(self):
        before = time.time()
        value = self.client.dashboard()
        self.assertTrue(before <= value['client_received_at'] <= time.time())


class FreshnessIsJudgedOnOneClock(unittest.TestCase):
    """R208-01: a GUI whose clock differs from the controller's is not permanently held."""

    def snapshot(self, observed, received=None):
        value = {'controller': {'governance': {'emergency_stopped': False, 'autonomy_mode': 'guarded-autonomous',
                                               'profile_fingerprint': 'f' * 64},
                                'setup_redo_policy': {'complete': True, 'observed_at': observed,
                                                      'profile_fingerprint': 'f' * 64,
                                                      'services': [{'agent_id': 'a', 'service': 's', 'holds': []}]}}}
        if received is not None:
            value['client_received_at'] = received
        return value

    def test_controller_clock_ahead_is_not_stale_when_received_now(self):
        now = 1_800_000_000.0
        self.assertIsNone(snapshot_hold(self.snapshot(now + 600, received=now), 'a', 's', now))

    def test_controller_clock_behind_is_not_stale_when_received_now(self):
        now = 1_800_000_000.0
        self.assertIsNone(snapshot_hold(self.snapshot(now - 600, received=now), 'a', 's', now))

    def test_old_receipt_is_still_stale(self):
        now = 1_800_000_000.0
        self.assertIn('fresh', snapshot_hold(self.snapshot(now, received=now - POLICY_MAX_AGE - 1), 'a', 's', now))

    def test_unstamped_snapshot_keeps_the_bounded_same_host_check(self):
        now = 1_800_000_000.0
        self.assertIsNone(snapshot_hold(self.snapshot(now + 1), 'a', 's', now))
        self.assertIn('fresh', snapshot_hold(self.snapshot(now + 60), 'a', 's', now))
        self.assertIn('fresh', snapshot_hold(self.snapshot(now - POLICY_MAX_AGE - 1), 'a', 's', now))


class HoldsArePerService(LiveController):
    """R208-02: one service's unresolved repair no longer holds every service on the host."""

    def check(self, service):
        return self.client.request(CHECK_PATH, {'profile_fingerprint': self.profile.fingerprint,
                                                'services': [['local-linux', service]], 'automated': False})

    def policy(self):
        return {row['service']: row['holds'] for row in
                self.client.dashboard()['controller']['setup_redo_policy']['services']}

    def test_dirty_rollback_holds_only_its_service(self):
        insert_repair(self.store, 'dirty-db', 'db.service', DIRTY)
        self.assertEqual(self.policy()['web.service'], [])
        self.assertIn('roll back', ' '.join(self.policy()['db.service']))
        self.assertTrue(self.check('web.service')['allowed'])
        self.assertFalse(self.check('db.service')['allowed'])

    def test_queued_repair_of_other_service_does_not_make_redo_wait(self):
        insert_repair(self.store, 'queued-db', 'db.service', None, status='queued')
        self.assertEqual(self.policy()['web.service'], [])
        self.assertEqual(self.policy()['db.service'], ['a repair is in progress'])

    def test_unknown_outcome_is_scoped_to_its_service(self):
        insert_repair(self.store, 'unknown-db', 'db.service', None, status='outcome_unknown')
        self.assertEqual(self.policy()['web.service'], [])
        self.assertIn('unknown', self.policy()['db.service'][0])

    def test_repair_without_a_service_holds_the_whole_host(self):
        insert_repair(self.store, 'unscoped', None, DIRTY, parameters={})
        self.assertTrue(all(self.policy().values()))

    def test_unreadable_repair_holds_the_whole_host(self):
        self.store._connection.execute(
            "INSERT INTO actions(action_id,agent_id,action_type,parameters_json,status,created_at,completed_at,result_json) "
            "VALUES('bad','local-linux','repair_service','{not json','failed',1,2,'{}')")
        self.store._connection.commit()
        for holds in self.policy().values():
            self.assertIn('unreadable', ' '.join(holds))

    def test_maintenance_grant_still_holds_every_service_on_the_host(self):
        self.app.authorize_change({'agent_id': 'local-linux', 'path': str(self.path), 'ttl_seconds': 600})
        for holds in self.policy().values():
            self.assertIn('change grant', ' '.join(holds))
        self.assertFalse(self.check('web.service')['allowed'])

    def test_verified_receipt_releases_only_matching_failure(self):
        insert_repair(self.store, 'dirty-web', 'web.service', DIRTY)
        insert_repair(self.store, 'dirty-db', 'db.service', DIRTY)
        count = self.store.record_verified_redo_recovery('local-linux', 'web.service', time.time(), 'e' * 64)
        self.assertEqual(count, 1)
        self.assertEqual(self.policy()['web.service'], [])
        self.assertTrue(self.policy()['db.service'])

    def test_changed_failure_row_is_reclassified(self):
        insert_repair(self.store, 'row', 'web.service', CLEAN)
        self.assertEqual(self.policy()['web.service'], [])
        self.store._connection.execute("UPDATE actions SET result_json=? WHERE action_id='row'", (json.dumps(DIRTY),))
        self.store._connection.commit()
        self.assertIn('roll back', ' '.join(self.policy()['web.service']))

    def plan(self, *, with_host_task):
        tasks = [{'id': 't-web', 'host': 'local-linux', 'service_key': ['local-linux', 'web.service'],
                  'requires': ['t-pkg'] if with_host_task else []},
                 {'id': 't-db', 'host': 'local-linux', 'service_key': ['local-linux', 'db.service'], 'requires': []}]
        if with_host_task:
            tasks.append({'id': 't-pkg', 'host': 'local-linux', 'service_key': None, 'requires': []})
        return {'hosts': {'local-linux': {'address': '127.0.0.1', 'agent_id': 'local-linux'}}, 'tasks': tasks}

    def guard(self, plan):
        pairs = [['local-linux', 'web.service']]
        reference = prepare_guard(self.client, self.root / 'job', pairs, False, self.profile)
        return WorkerGuard({'redo_guard_file': reference, 'only_services': pairs}, self.profile, plan)

    def test_worker_scope_is_the_services_its_tasks_touch(self):
        self.assertEqual(self.guard(self.plan(with_host_task=False)).request['services'],
                         [['local-linux', 'web.service']])

    def test_host_level_dependency_still_takes_the_whole_host(self):
        self.assertEqual(self.guard(self.plan(with_host_task=True)).request['services'],
                         [['local-linux', 'db.service'], ['local-linux', 'web.service']])

    def test_worker_is_not_held_by_an_unrelated_service(self):
        insert_repair(self.store, 'dirty-db', 'db.service', DIRTY)
        self.guard(self.plan(with_host_task=False)).checkpoint()
        with self.assertRaisesRegex(SetupPaused, 'roll back'):
            self.guard(self.plan(with_host_task=True))


class WorkerPollingIsBounded(unittest.TestCase):
    """R208-03: the scheduling loop no longer signs ~4 controller requests a second."""

    def run_plan(self, delay, checkpoint):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            inventory, profile = setup_fixture(root, hosts=1, budget=int(delay) + 60)
            inventory['setup']['tasks'][0]['timeout_seconds'] = int(delay) + 30
            plan = compile_plan(inventory, profile, root)
            transport = FixtureTransport()
            transport.delay = delay
            return SetupRunner(plan, profile, transport=transport, probe=healthy_probe,
                               checkpoint=checkpoint).execute(root / 'state', plan_digest(plan))

    def test_idle_poll_rate_is_bounded(self):
        calls = []
        report = self.run_plan(6.0, lambda: calls.append(time.monotonic()))
        self.assertEqual(report['status'], 'ready')
        # task admission + pre-apply + one poll per PAUSE_POLL_SECONDS (+ start/end)
        self.assertLessEqual(len(calls), 6.0 / PAUSE_POLL_SECONDS + 6)

    def test_pause_before_apply_still_prevents_mutation_and_is_reported(self):
        state = {'n': 0}
        def checkpoint():
            state['n'] += 1
            if state['n'] >= 2:
                raise SetupPaused('operator paused')
        report = self.run_plan(1.0, checkpoint)
        self.assertEqual(report['status'], 'paused')

    def test_once_paused_the_loop_stops_asking(self):
        calls = []
        def checkpoint():
            calls.append(1)
            raise SetupPaused('held')
        runner = SetupRunner({'tasks': [], 'hosts': {}}, None, checkpoint=checkpoint)
        for _ in range(50):
            self.assertTrue(runner.paused())
        self.assertEqual(len(calls), 1)


class EmergencyStopHasAReservedReplayAllowance(unittest.TestCase):
    """R208-03: ordinary operator traffic can no longer lock out Emergency Stop."""

    def test_emergency_stop_survives_ordinary_replay_exhaustion(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / 'web.conf'
            path.write_bytes(b'x')
            path.chmod(0o600)
            profile, base = repair_fixture(str(path))
            base['observed_at'] = time.time()
            app, store, client = live_client(self, profile, base)
            request = {'profile_fingerprint': profile.fingerprint, 'services': [['agent-one', 'web.service']],
                       'automated': True}
            for _ in range(OPERATOR_REPLAY_MARKERS):
                client.request(CHECK_PATH, request)
            with self.assertRaisesRegex(RuntimeError, '503'):
                client.dashboard()
            self.assertIs(client.request('/api/v1/governance/emergency-stop', {})['emergency_stopped'], True)
            self.assertTrue(app.emergency_stopped)
            with self.assertRaisesRegex(RuntimeError, '503'):
                client.request('/api/v1/governance/resume', {})
            self.assertGreater(OPERATOR_EMERGENCY_REPLAY_RESERVE, 0)


class NoOrphanConnectionMaterial(LiveController):
    """R208-04: a refused or finished redo leaves no copy of the operator key."""

    def eligible(self):
        state = setup_redo.load_state(self.workspace)
        state['seen_healthy'] = ['web.service']
        state['unhealthy_since'] = {'web.service': time.time() - 400}
        setup_redo.save_state(self.workspace, state)

    def guards(self):
        return list((self.root / 'jobs').glob('job-redo-*/redo-control.json'))

    def test_paused_setup_writes_no_connection_file(self):
        self.break_web()
        JobControl(self.root / 'jobs').initialize()
        JobControl(self.root / 'jobs').set_paused(True)
        with patch.object(desktop_jobs, 'detach', side_effect=AssertionError('no worker may start')):
            for _ in range(3):
                self.eligible()
                verdict = setup_redo.tick(self.workspace, self.client.dashboard(), client=self.client)
                self.assertIn('paused', verdict['last'])
        self.assertEqual(self.guards(), [])

    def test_failed_launch_removes_connection_file(self):
        self.break_web()
        def failing(job, directory):
            raise OSError('disk full')
        with self.assertRaises(OSError):
            setup_redo.launch_redo(self.workspace, self.record, setup_redo.load_state(self.workspace),
                                   ['web.service'], 'test', launcher=failing, client=self.client)
        self.assertEqual(self.guards(), [])

    def test_finished_worker_removes_its_connection_file(self):
        job_dir = self.root / 'jobs' / 'job-redo-finished'
        reference = prepare_guard(self.client, job_dir, [['local-linux', 'web.service']], False, self.profile)
        write_private_json(job_dir / 'job.json', {'kind': 'setup', 'redo': True, 'redo_guard_file': reference})
        with patch.object(desktop_jobs, '_run', return_value=2):
            self.assertEqual(desktop_jobs.run(SimpleNamespace(job=str(job_dir / 'job.json'))), 2)
        self.assertFalse(Path(reference).exists())

    def test_worker_cleanup_touches_only_its_own_directory(self):
        other = self.root / 'elsewhere'
        other.mkdir(mode=0o700)
        foreign = other / 'redo-control.json'
        foreign.write_text('{}')
        job_dir = self.root / 'jobs' / 'job-redo-foreign'
        job_dir.mkdir(mode=0o700, parents=True)
        write_private_json(job_dir / 'job.json', {'kind': 'setup', 'redo': True, 'redo_guard_file': str(foreign)})
        with patch.object(desktop_jobs, '_run', return_value=2):
            desktop_jobs.run(SimpleNamespace(job=str(job_dir / 'job.json')))
        self.assertTrue(foreign.exists())


class UnresolvedEvidenceRetentionAndBound(unittest.TestCase):
    """R208-05 and R208-07: retention keeps unresolved evidence; the bound counts only it."""

    def setUp(self):
        temp = tempfile.TemporaryDirectory(prefix='sb209-store-')
        self.addCleanup(temp.cleanup)
        self.store = Store(str(Path(temp.name) / 'controller.db'))
        self.addCleanup(self.store.close)

    def holds(self):
        return self.store.setup_redo_holds([('local-linux', 'web.service')])[('local-linux', 'web.service')]

    def bulk(self, count, result, prefix):
        at = time.time() - 1000
        self.store._connection.executemany(
            "INSERT INTO actions(action_id,agent_id,action_type,parameters_json,status,created_at,completed_at,result_json) "
            "VALUES(?,?,?,?,?,?,?,?)",
            [(f'{prefix}{i}', 'local-linux', 'repair_service', json.dumps({'service': 'web.service'}), 'failed',
              at + i, at + i + 1, json.dumps(result)) for i in range(count)])
        self.store._connection.commit()

    def test_many_clean_failures_never_hold(self):
        self.bulk(REDO_HOLD_BOUND + 1, CLEAN, 'clean')
        self.assertEqual(self.holds(), [])

    def test_unresolved_overflow_still_fails_closed(self):
        self.bulk(REDO_HOLD_BOUND + 1, DIRTY, 'dirty')
        self.assertIn('exceeds the bounded governance query', ' '.join(self.holds()))

    def test_prune_keeps_unresolved_and_expires_clean_failures(self):
        insert_repair(self.store, 'dirty', 'web.service', DIRTY, age=40 * 86400)
        insert_repair(self.store, 'clean', 'web.service', CLEAN, age=40 * 86400)
        insert_repair(self.store, 'unreadable', 'web.service', None, age=40 * 86400)
        self.store._connection.execute("UPDATE actions SET result_json='{bad' WHERE action_id='unreadable'")
        self.store._connection.commit()
        self.store.prune(30)
        remaining = {row[0] for row in self.store._connection.execute('SELECT action_id FROM actions')}
        self.assertEqual(remaining, {'dirty', 'unreadable'})
        self.assertIn('roll back', ' '.join(self.holds()))

    def test_prune_keeps_every_failed_repair_on_pin_overflow(self):
        insert_repair(self.store, 'clean', 'web.service', CLEAN, age=40 * 86400)
        with patch.object(Store, 'redo_evidence_pins_locked', return_value=(set(), True)):
            self.store.prune(30)
        self.assertEqual(self.store._connection.execute('SELECT COUNT(*) FROM actions').fetchone()[0], 1)


class HistoryArchivalKeepsUnresolvedEvidence(unittest.TestCase):
    """R208-07: production history archival no longer releases a dirty rollback hold."""

    def setUp(self):
        import test_session_alert_continuity as continuity
        from sentinel_blue.history_storage import HistoryPolicy, HistoryStorage, MIB
        self.fixture = continuity.SessionAlertContinuityTests()
        self.fixture.setUp()
        self.addCleanup(self.fixture.tearDown)
        self.store = self.fixture.store
        root = self.fixture.root / 'history'
        root.mkdir(mode=0o700)
        policy = HistoryPolicy(database_max_bytes=32 * MIB, archive_max_bytes=16 * MIB, archive_max_files=2,
                               minimum_free_bytes=8 * MIB, backup_max_bytes=32 * MIB, minimum_online_seconds=60)
        self.manager = HistoryStorage(self.store, root, self.fixture.key, policy)

    def ids(self):
        return {row[0] for row in self.store._connection.execute(
            "SELECT action_id FROM actions WHERE action_type='repair_service'")}

    def test_dirty_failure_survives_archival_and_clean_one_is_archived(self):
        insert_repair(self.store, 'dirty-old', 'web.service', DIRTY, age=40 * 86400, agent='agent-one')
        insert_repair(self.store, 'clean-old', 'web.service', CLEAN, age=40 * 86400, agent='agent-one')
        for _ in range(20):
            self.manager.maintain()
        self.assertEqual(self.ids(), {'dirty-old'})
        holds = self.store.setup_redo_holds([('agent-one', 'web.service')])[('agent-one', 'web.service')]
        self.assertIn('roll back', ' '.join(holds))

    def test_receipted_failure_is_still_retained_as_evidence(self):
        insert_repair(self.store, 'dirty-old', 'web.service', DIRTY, age=40 * 86400, agent='agent-one')
        self.store.record_verified_redo_recovery('agent-one', 'web.service', time.time(), 'e' * 64)
        for _ in range(10):
            self.manager.maintain()
        self.assertEqual(self.ids(), {'dirty-old'})

    def test_pin_overflow_keeps_every_failed_repair_online(self):
        insert_repair(self.store, 'clean-old', 'web.service', CLEAN, age=40 * 86400, agent='agent-one')
        with patch.object(Store, 'redo_evidence_pins_locked', return_value=(set(), True)):
            for _ in range(10):
                self.manager.maintain()
        self.assertEqual(self.ids(), {'clean-old'})


class OperatorVerifiedRecoveryLabel(unittest.TestCase):
    """R208-06: operator verification is not recorded as a setup-redo resolution."""

    def test_decision_label_names_the_source(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / 'web.conf'
            path.write_bytes(b'trusted')
            path.chmod(0o600)
            profile, base = repair_fixture(str(path))
            base['observed_at'] = time.time()
            app, store, client = live_client(self, profile, base)
            _promote_integrity_baseline(app, store, 'agent-one')
            decisions = []
            original = store.resolve_repaired_incident
            def record(*args, **kwargs):
                decisions.append(kwargs.get('decision'))
                return original(*args, **kwargs)
            current = copy.deepcopy(base)
            current.update(sequence=2, observed_at=time.time())
            app.ingest(current)
            with patch.object(store, 'resolve_repaired_incident', side_effect=record):
                app.close_recovered_incident('agent-one', 'web.service', 'operator_verified_recovery')
                app.close_recovered_incident('agent-one', 'web.service', 'setup_redo')
            self.assertEqual(decisions, ['resolved_by_operator_verified_recovery', 'resolved_by_setup_redo'])


class VerifyRedoHoldsReportsEveryService(unittest.TestCase):
    """R208-06: one refused verification no longer hides the others' results."""

    def test_one_failure_does_not_abort_the_report(self):
        from sentinel_blue.desktop_recovery import RecoveryControls
        answers = {'a.service': RuntimeError('HTTP 409'), 'b.service': {'closed': 1, 'reconciled_redo_holds': 1}}
        class Client:
            def dashboard(self):
                return {'controller': {'setup_redo_policy': {'services': [
                    {'agent_id': 'h', 'service': name, 'holds': ['a repair did not roll back cleanly']}
                    for name in answers]}}}
            def request(self, target, payload):
                value = answers[payload['service']]
                if isinstance(value, Exception):
                    raise value
                return value
        captured = {}
        window = SimpleNamespace(client=Client(), note=lambda text: None,
                                 messagebox=SimpleNamespace(askyesno=lambda *a, **k: True), root=None,
                                 _recovery_display=None,
                                 _recovery_work=lambda work, display: captured.setdefault('report', work()))
        RecoveryControls.verify_redo_recovery(window)
        report = {row['service']: row for row in captured['report']}
        self.assertIn('not verified', report['a.service']['reason'])
        self.assertEqual(report['b.service']['reconciled_redo_holds'], 1)


if __name__ == '__main__':
    unittest.main()
