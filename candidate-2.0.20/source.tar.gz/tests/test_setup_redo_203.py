"""2.0.3: when repair cannot fix a service, the approved setup runs again."""
import json
import os
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path

from sentinel_blue import setup_redo
from sentinel_blue.job_control import SetupPaused
from sentinel_blue.state import write_private_json

DIGEST = "a" * 64
NOW = 1_800_000_000.0


def health(unit="web.service", state="healthy", native="running", reason=""):
    return {"agent_id": "local-linux", "service": unit, "health": state, "native_state": native, "reason": reason}


def repair(unit="web.service", status="failed", rolled_back=True, completed=NOW - 30, created=NOW - 60,
           rollback_failed=None, errors=None):
    result = {"success": status == "completed", "rolled_back": rolled_back,
              "message": "coordinated service repair held or failed: start failed"}
    if rollback_failed:
        result["review_required"] = True
    if errors is not None:
        result["errors"] = errors
    return {"agent_id": "local-linux", "action_type": "repair_service", "parameters": {"service": unit},
            "status": status, "created_at": created, "completed_at": completed, "result": result}


def snapshot(rows, actions=(), emergency=False):
    return {"service_health": list(rows), "actions": list(actions),
            "controller": {"governance": {"emergency_stopped": emergency, "autonomy_mode": "guarded-autonomous"}}}


class Workspace(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.workspace = self.root / "session"
        self.workspace.mkdir()
        original = self.root / "desktop" / "job-original" / "job.json"
        original.parent.mkdir(parents=True)
        write_private_json(original, {"kind": "setup"})
        write_private_json(original.parent / "result.json", {"status": "passed"})
        self.original = original
        # The approved inventory: a setup task for each service the tests break
        # (2.0.6 redoes only services an approved task covers).
        write_private_json(self.root / "inventory.json", {
            "hosts": [{"name": "local-linux", "address": "127.0.0.1"}],
            "setup": {"tasks": [{"id": f"t-{unit}", "host": "local-linux", "service_id": unit}
                                for unit in ("web.service", "a.service", "b.service", "c.service")]}})
        self.record = setup_redo.record_approved_setup(
            self.workspace, {"kind": "setup", "inventory": str(self.root / "inventory.json"),
                             "event_profile": str(self.root / "profile.json"), "runtime": str(self.root / "sb.pyz"),
                             "range_deployment": True, "approved_digest": DIGEST, "control_epoch": "e" * 32},
            job_root=self.root / "desktop", job_path=original)
        self.launched = []

    def launcher(self, job, directory):
        directory.mkdir(parents=True)
        path = directory / "job.json"
        write_private_json(path, job)
        self.launched.append((job, path))
        return None, path

    def seen_healthy(self, unit="web.service"):
        setup_redo.tick(self.workspace, snapshot([health(unit)]), now=NOW - 400, launcher=self.launcher)


class ApprovedRecord(Workspace):
    def test_the_record_keeps_only_what_was_approved(self):
        record = setup_redo.load_record(self.workspace)
        self.assertEqual(record["approved_digest"], DIGEST)
        self.assertNotIn("control_epoch", record, "a redo is admitted by the current Setup pause state")

    def test_a_malformed_record_is_refused(self):
        for change in ({"approved_digest": "zz"}, {"kind": "opening"}, {"inventory": "relative.json"},
                       {"range_deployment": "yes"}, {"extra": 1}):
            with self.subTest(change=change):
                write_private_json(self.workspace / setup_redo.RECORD, {**self.record, **change})
                with self.assertRaises(ValueError):
                    setup_redo.load_record(self.workspace)

    def test_no_record_means_no_redo(self):
        (self.workspace / setup_redo.RECORD).unlink()
        verdict = setup_redo.assess(snapshot([health()]), None, setup_redo.load_state(self.workspace), NOW)
        self.assertIn("no approved local setup", verdict["blocked"])


class WhenARedoIsDue(Workspace):
    def verdict(self, rows, actions=(), *, now=NOW, emergency=False):
        state = setup_redo.load_state(self.workspace)
        result = setup_redo.assess(snapshot(rows, actions, emergency), self.record, state, now)
        setup_redo.save_state(self.workspace, state)
        return result

    def test_a_repair_that_failed_and_rolled_back(self):
        self.seen_healthy()
        row = self.verdict([health(state="unhealthy", native="failed")], [repair()])["units"]["web.service"]
        self.assertEqual(row["status"], "eligible")
        self.assertIn("rolled back", row["reason"])

    def test_a_repair_that_did_not_roll_back_is_held(self):
        self.seen_healthy()
        row = self.verdict([health(state="unhealthy", native="failed")],
                           [repair(rolled_back=False, rollback_failed=True)])["units"]["web.service"]
        self.assertEqual(row["status"], "held")

    def test_a_repair_held_before_it_changed_anything_is_not_a_failed_rollback(self):
        """Found live: a repair refused at the agent's preflight reports rolled_back=False."""
        self.seen_healthy()
        row = self.verdict([health(state="unhealthy", native="failed")],
                           [repair(rolled_back=False, rollback_failed=False)])["units"]["web.service"]
        self.assertEqual(row["status"], "eligible")
        self.assertIn("could not be applied", row["reason"])

    def test_results_from_older_agents_are_read_by_their_errors(self):
        self.seen_healthy()
        held_early = repair(rolled_back=False, errors=["service state changed after repair diagnosis"])
        undo_failed = repair(rolled_back=False, errors=["start failed", "child restoration rollback did not complete"])
        self.assertEqual(self.verdict([health(state="unhealthy")], [held_early])["units"]["web.service"]["status"], "eligible")
        self.assertEqual(self.verdict([health(state="unhealthy")], [undo_failed])["units"]["web.service"]["status"], "held")

    def test_an_unknown_outcome_is_held_and_a_running_repair_is_waited_for(self):
        self.seen_healthy()
        unknown = self.verdict([health(state="unhealthy")], [repair(status="outcome_unknown")])["units"]["web.service"]
        self.assertEqual(unknown["status"], "held")
        queued = self.verdict([health(state="unhealthy")], [repair(status="dispatched")])["units"]["web.service"]
        self.assertEqual(queued["status"], "waiting")

    def test_a_fault_setup_cannot_fix_is_held(self):
        self.seen_healthy()
        row = self.verdict([health(state="unhealthy", native="failed",
                                   reason="another process holds its declared port (80)")], [repair()])["units"]["web.service"]
        self.assertEqual(row["status"], "held")
        self.assertIn("setup cannot fix", row["reason"])

    def test_a_missing_unit_is_confirmed_before_redo(self):
        self.seen_healthy()
        first = self.verdict([health(state="unhealthy", native="unknown")], now=NOW)["units"]["web.service"]
        self.assertEqual(first["status"], "waiting")
        later = self.verdict([health(state="unhealthy", native="unknown")], now=NOW + 61)["units"]["web.service"]
        self.assertEqual(later["status"], "eligible")
        self.assertIn("no longer present", later["reason"])

    def test_a_service_repair_could_not_fix_for_three_minutes(self):
        self.seen_healthy()
        self.assertEqual(self.verdict([health(state="unhealthy", native="failed")], now=NOW)["units"]["web.service"]["status"],
                         "waiting")
        self.assertEqual(self.verdict([health(state="unhealthy", native="failed")], now=NOW + 181)["units"]["web.service"]["status"],
                         "eligible")

    def test_a_service_never_seen_healthy_is_left_to_setup(self):
        row = self.verdict([health(state="unhealthy", native="failed")], [repair()])["units"]["web.service"]
        self.assertEqual(row["status"], "waiting")

    def test_emergency_stop_blocks(self):
        self.assertIn("emergency", self.verdict([health()], emergency=True)["blocked"])

    def test_the_approved_setup_still_running_blocks(self):
        (self.original.parent / "result.json").unlink()
        self.assertIn("still running", self.verdict([health()])["blocked"])


class TheSessionLoop(Workspace):
    def broken(self, now=NOW):
        return setup_redo.tick(self.workspace, snapshot([health(state="unhealthy", native="failed")], [repair()]),
                               now=now, launcher=self.launcher)

    def test_guarded_mode_launches_the_approved_plan_once(self):
        self.seen_healthy()
        verdict = self.broken()
        self.assertEqual(len(self.launched), 1)
        job, path = self.launched[0]
        # 2.0.6: only the service being redone (and what it requires) runs.
        self.assertEqual(job, {"kind": "setup", "inventory": self.record["inventory"],
                               "event_profile": self.record["event_profile"], "runtime": self.record["runtime"],
                               "range_deployment": True, "approved_digest": DIGEST, "redo": True,
                               "only_services": [["local-linux", "web.service"]]})
        self.assertTrue(path.parent.name.startswith("job-redo-"))
        self.assertEqual(path.parent.parent, Path(self.record["job_root"]), "shares the desktop's Setup pause")
        self.assertEqual(verdict["launched"]["units"], ["web.service"])
        again = self.broken(NOW + 5)
        self.assertIn("already running", again["blocked"])
        self.assertEqual(len(self.launched), 1)
        write_private_json(path.parent / "result.json", {"status": "passed"})
        finished = self.broken(NOW + 20)
        self.assertIn("finished: passed", finished["last"])
        self.assertEqual(finished["units"]["web.service"]["status"], "waiting", "the per-service cooldown holds")
        self.assertEqual(len(self.launched), 1)

    def test_at_most_three_an_hour_per_service(self):
        self.seen_healthy()
        for index in range(3):
            unit = "web.service"
            state = setup_redo.load_state(self.workspace)
            state["history"].append({"at": NOW - 700 - index, "unit": unit, "units": [unit], "reason": "", "job": ""})
            setup_redo.save_state(self.workspace, state)
        verdict = self.broken()
        self.assertEqual(verdict["units"]["web.service"]["status"], "held")
        self.assertEqual(self.launched, [])

    def test_approval_mode_only_keeps_evidence(self):
        self.seen_healthy()
        verdict = setup_redo.tick(self.workspace, snapshot([health(state="unhealthy", native="failed")], [repair()]),
                                  now=NOW, automatic=False, launcher=self.launcher)
        self.assertEqual(verdict["units"]["web.service"]["status"], "eligible")
        self.assertEqual(self.launched, [])

    def test_a_failed_original_setup_is_not_redone_automatically(self):
        write_private_json(self.original.parent / "result.json", {"status": "failed"})
        self.seen_healthy()
        verdict = self.broken()
        self.assertEqual(self.launched, [])
        self.assertIn("did not finish successfully", verdict["blocked"])

    def test_a_paused_setup_is_reported_not_fatal(self):
        self.seen_healthy()
        def paused(job, directory):
            raise SetupPaused("Setup is paused")
        verdict = setup_redo.tick(self.workspace, snapshot([health(state="unhealthy", native="failed")], [repair()]),
                                  now=NOW, launcher=paused)
        self.assertIn("redo not started: Setup is paused", verdict["last"])


class OperatorRedo(Workspace):
    def test_the_operator_can_redo_inside_the_cooldown(self):
        self.seen_healthy()
        state = setup_redo.load_state(self.workspace)
        state["history"].append({"at": NOW - 10, "unit": "web.service", "units": ["web.service"], "reason": "", "job": ""})
        setup_redo.save_state(self.workspace, state)
        entry = setup_redo.manual_redo(self.workspace, snapshot([health(state="unhealthy", native="failed")]),
                                       now=NOW, launcher=self.launcher)
        self.assertEqual(entry["units"], ["web.service"])
        self.assertEqual(entry["reason"], "operator requested")

    def test_hard_holds_still_apply(self):
        self.seen_healthy()
        with self.assertRaisesRegex(ValueError, "roll back"):
            setup_redo.manual_redo(self.workspace, snapshot([health(state="unhealthy")],
                                                            [repair(rolled_back=False, rollback_failed=True)]),
                                   now=NOW, launcher=self.launcher)
        with self.assertRaisesRegex(ValueError, "emergency"):
            setup_redo.manual_redo(self.workspace, snapshot([health()], emergency=True), now=NOW, launcher=self.launcher)
        self.assertEqual(self.launched, [])

    def test_status_text_names_each_service(self):
        self.seen_healthy()
        text = setup_redo.status_text(self.workspace, snapshot([health(state="unhealthy", native="failed")], [repair()]), now=NOW)
        self.assertIn("web.service: eligible", text)


try:
    import test_desktop_job_process as _job_process   # a module, so its own tests are not collected twice
except ImportError:          # the packaged-runtime fixture needs the build tools
    _job_process = None

REDO_DRIVER = '''
import json,sys
runtime,workspace,connection=sys.argv[1:]
sys.path.insert(0,runtime)
sys.argv[0]=runtime
from sentinel_blue import setup_redo
record=setup_redo.load_record(workspace)
from sentinel_blue.desktop_control import DesktopClient
from sentinel_blue.state import read_private_json
from pathlib import Path
client=DesktopClient(**read_private_json(Path(connection)))
entry=setup_redo.launch_redo(workspace,record,setup_redo.load_state(workspace),['local-job/marker'],'fixture',client=client)

print(json.dumps(entry))
'''

if _job_process is not None:
    class RedoRunsTheApprovedPlan(_job_process.DesktopJobProcessTests):
        """A real detached worker, from the built release, runs the redo."""
        test_detached_job_survives_launcher_and_holds_untracked_mutation = None
        test_changed_reviewed_plan_is_rejected_before_local_work = None

        def redo(self):
            workspace = self.root / "session"
            workspace.mkdir(exist_ok=True)
            setup_redo.record_approved_setup(workspace, self.job, job_root=self.root / "desktop",
                                             job_path=self.root / "desktop" / "job-original" / "job.json", scope='network')
            from redo_gate_fixture import live_client
            from sentinel_blue.event_profile import load_event_profile
            _, _, client = live_client(self, load_event_profile(self.root/'profile.json'))
            connection = self.root/'fixture-connection.json'
            write_private_json(connection, {'origin':client.origin,'principal':client.principal,'epoch':client.epoch,'token':client.token,'ca_file':client.ca_file})
            result = subprocess.run([sys.executable, "-c", REDO_DRIVER, str(self.runtime), str(workspace), str(connection)],
                                    capture_output=True, text=True, timeout=15)
            self.assertEqual(result.returncode, 0, result.stderr)
            path = Path(json.loads(result.stdout)["job"]).parent / "result.json"
            deadline = time.monotonic() + 25
            while not path.exists() and time.monotonic() < deadline:
                time.sleep(.05)
            self.assertTrue(path.exists())
            return json.loads(path.read_text())

        def test_the_redo_is_the_approved_plan(self):
            report = self.redo()
            # Exactly what the approved setup does with this fixture: the plan
            # verifies, and its untracked runbook is held rather than applied.
            self.assertEqual(report["status"], "incomplete", report)
            self.assertEqual(report["tasks"]["local-job"]["status"], "held")

        def test_a_plan_changed_since_approval_is_not_redone(self):
            self.inventory["setup"]["budget_seconds"] = 19
            write_private_json(self.root / "inventory.json", self.inventory)
            report = self.redo()
            self.assertEqual(report["status"], "failed")
            self.assertIn("Configuration changed after review", report["reason"])
            self.assertFalse(self.marker.exists())


if __name__ == "__main__":
    unittest.main()
