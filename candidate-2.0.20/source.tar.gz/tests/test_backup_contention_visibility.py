"""A silent stall becomes a visible one (ledger contention, scheduled backups).

Found while fixing the supervisor smoke test: a second Sentinel process on the
same host shares the machine-wide mutation ledger, and whoever loses the race
blocks. Two things were wrong, and neither was the wait itself.

  1. Every lock timeout blamed withdrawal — "a mutation is still active;
     withdrawal has not drained this host" — whatever the real cause. An
     operator reading that goes and looks at Withdraw, which is not the problem.
  2. When the blocked caller was the scheduled recovery backup, the failure went
     to a log file and nowhere else. Nothing on the dashboard, no alert. During
     an event nobody reads controller logs, so recovery capsules are assumed to
     exist right up until the moment they are needed and are not there.

These tests cover both, and defend the rule that the monitor must never be able
to break the loop it monitors.
"""

import multiprocessing
import os
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from sentinel_blue import controller as controller_module
from sentinel_blue.controller import (
    BACKUP_FAILURE_ALERT_COUNT, BACKUP_OVERDUE_INTERVALS, CONTROLLER_AGENT_ID,
    INTERNAL_AGENT_IDS, _note_backup, maintenance_loop)
from sentinel_blue.mutation_ledger import (
    CONTENTION_WARNING_SECONDS, LedgerError, MutationLedger, _holder_description)
from sentinel_blue.risk import KIND_FEATURES

import test_session_alert_continuity as continuity


def _hold(directory, ready, release):
    """Hold the ledger lock in a genuinely separate process."""
    ledger = MutationLedger(Path(directory))
    with ledger.lock():
        ready.set()
        release.wait(30)


class LedgerHolderIdentityTests(unittest.TestCase):
    def setUp(self):
        self.root = Path(tempfile.mkdtemp(prefix="sentinel-lock-"))
        self.addCleanup(lambda: __import__("shutil").rmtree(self.root, True))
        os.chmod(self.root, 0o700)
        self.ledger = MutationLedger(self.root / "ledger")
        self.lock_path = self.root / "ledger" / "writer.lock"

    def test_the_holder_records_itself_for_the_next_waiter(self):
        with self.ledger.lock():
            description = _holder_description(self.lock_path)
        self.assertIn(f"process {os.getpid()}", description)

    def test_an_unwritten_lock_file_says_so_instead_of_guessing(self):
        self.lock_path.write_bytes(b"")
        self.assertEqual(_holder_description(self.lock_path),
                         "the holding process did not identify itself")

    def test_a_tampered_lock_file_never_raises_and_never_misleads(self):
        for content in (b"{", b"[]", b'{"pid": "root"}', b'{"pid": -1}',
                        b'{"pid": 4, "host": ' + b'"x"' * 400 + b"}", b"\x00\xff"):
            with self.subTest(content=content[:24]):
                self.lock_path.write_bytes(content)
                description = _holder_description(self.lock_path)
                self.assertIsInstance(description, str)
                self.assertLessEqual(len(description), 200)

    def test_a_missing_lock_file_is_not_an_error(self):
        self.assertIn("did not identify itself",
                      _holder_description(self.root / "absent.lock"))

    def test_the_holder_record_is_bounded(self):
        with self.ledger.lock():
            pass
        self.assertLessEqual(self.lock_path.stat().st_size, 512)


class LedgerContentionTests(unittest.TestCase):
    """Two real processes, one ledger."""

    def setUp(self):
        self.root = Path(tempfile.mkdtemp(prefix="sentinel-contend-"))
        self.addCleanup(lambda: __import__("shutil").rmtree(self.root, True))
        os.chmod(self.root, 0o700)
        self.directory = self.root / "ledger"
        # Build the waiting ledger before the contender starts: the constructor
        # takes the lock itself, so building it afterwards would absorb the very
        # contention under test.
        self.waiter = MutationLedger(self.directory)

    def contended(self):
        context = multiprocessing.get_context("spawn")
        ready, release = context.Event(), context.Event()
        holder = context.Process(target=_hold, args=(str(self.directory), ready, release))
        holder.start()
        self.addCleanup(holder.join, 30)
        self.addCleanup(release.set)
        if not ready.wait(30):
            self.skipTest("the contending process did not start")
        return release

    def test_a_timeout_names_contention_rather_than_blaming_withdrawal(self):
        self.contended()
        ledger = self.waiter
        with self.assertRaises(LedgerError) as error:
            with ledger.lock(timeout=0.5):
                pass
        message = str(error.exception)
        self.assertIn("stayed locked", message)
        self.assertIn("SENTINEL_LEDGER_DIR", message)
        self.assertIn("process ", message, "the message must name who holds it")
        # The old message asserted a cause it could not know.
        self.assertNotIn("withdrawal has not drained this host", message)
        self.assertEqual(ledger.contention()["timeouts"], 1)

    def test_the_wait_is_bounded_by_its_timeout(self):
        self.contended()
        ledger = self.waiter
        started = time.monotonic()
        with self.assertRaises(LedgerError):
            with ledger.lock(timeout=0.5):
                pass
        self.assertLess(time.monotonic() - started, 10.0)

    def test_the_lock_is_acquired_once_the_holder_releases(self):
        release = self.contended()
        release.set()
        ledger = self.waiter
        with ledger.lock(timeout=20):
            pass
        self.assertEqual(ledger.contention()["timeouts"], 0)

    def test_a_long_wait_is_warned_about_while_it_is_still_only_a_wait(self):
        self.contended()
        ledger = self.waiter
        with patch("sentinel_blue.mutation_ledger.CONTENTION_WARNING_SECONDS", 0.0):
            with self.assertLogs("sentinel_blue.mutation_ledger", level="WARNING") as logs:
                with self.assertRaises(LedgerError):
                    with ledger.lock(timeout=0.4):
                        pass
        self.assertTrue(any("Waiting" in row and "SENTINEL_LEDGER_DIR" in row
                            for row in logs.output))
        self.assertEqual(ledger.contention()["warnings"], 1)

    def test_an_uncontended_lock_is_silent(self):
        ledger = self.waiter
        with ledger.lock():
            pass
        self.assertEqual(ledger.contention(), {"warnings": 0, "timeouts": 0})

    def test_the_warning_threshold_is_below_the_default_timeout(self):
        self.assertLess(CONTENTION_WARNING_SECONDS, 60)


class BackupHealthStateTests(unittest.TestCase):
    def setUp(self):
        self.fixture = continuity.SessionAlertContinuityTests()
        self.fixture.setUp()
        self.addCleanup(self.fixture.tearDown)
        self.app = self.fixture.app

    def fail(self, count, *, start=10_000.0, interval=60.0):
        for index in range(count):
            self.app.record_backup_outcome(
                False, reason=OSError("fixture backup failure"),
                interval=interval, now=start + index * interval)

    def test_a_fresh_controller_reports_no_backup_history(self):
        status = self.app.backup_status(now=10_000.0)
        self.assertFalse(status["configured"])
        self.assertIsNone(status["last_success_at"])
        self.assertEqual(status["consecutive_failures"], 0)

    def test_a_success_is_recorded_and_clears_the_failure_run(self):
        self.fail(3)
        self.app.record_backup_outcome(True, interval=60.0, now=10_500.0)
        status = self.app.backup_status(now=10_500.0)
        self.assertEqual(status["consecutive_failures"], 0)
        self.assertEqual(status["last_success_at"], 10_500.0)
        self.assertEqual(status["state"], "healthy")
        self.assertEqual(status["last_error"], "")

    def test_repeated_failures_become_a_failing_state(self):
        self.app.record_backup_outcome(True, interval=60.0, now=10_000.0)
        self.fail(BACKUP_FAILURE_ALERT_COUNT, start=10_400.0)
        status = self.app.backup_status(now=10_500.0)
        self.assertEqual(status["state"], "failing")
        self.assertGreater(status["seconds_since_success"], 60.0 * BACKUP_OVERDUE_INTERVALS)

    def test_one_failure_inside_the_schedule_is_not_an_alarm(self):
        self.app.record_backup_outcome(True, interval=60.0, now=10_000.0)
        self.app.record_backup_outcome(False, reason=OSError("one slow cycle"),
                                       interval=60.0, now=10_030.0)
        self.assertEqual(self.app.backup_status(now=10_030.0)["state"], "healthy")

    def test_the_recorded_reason_is_bounded_and_printable(self):
        self.app.record_backup_outcome(
            False, reason=OSError("x" * 900 + "\x00\x07bad"), interval=60.0, now=10_000.0)
        detail = self.app.backup_status(now=10_000.0)["last_error"]
        self.assertLessEqual(len(detail), 300)
        self.assertTrue(detail.isprintable())

    def test_an_empty_reason_still_says_something(self):
        self.app.record_backup_outcome(False, reason=None, interval=60.0, now=10_000.0)
        self.assertTrue(self.app.backup_status(now=10_000.0)["last_error"])

    def test_backup_health_reaches_the_dashboard(self):
        self.fail(BACKUP_FAILURE_ALERT_COUNT)
        status = self.app.dashboard()["controller"]["recovery_backups"]
        self.assertEqual(status["consecutive_failures"], BACKUP_FAILURE_ALERT_COUNT)
        self.assertIn("fixture backup failure", status["last_error"])


class BackupAlertTests(unittest.TestCase):
    def setUp(self):
        self.fixture = continuity.SessionAlertContinuityTests()
        self.fixture.setUp()
        self.addCleanup(self.fixture.tearDown)
        self.app = self.fixture.app

    def drive_to_failing(self):
        self.app.record_backup_outcome(True, interval=60.0, now=10_000.0)
        for index in range(BACKUP_FAILURE_ALERT_COUNT):
            self.app.record_backup_outcome(
                False, reason=LedgerError("the mutation ledger stayed locked"),
                interval=60.0, now=10_400.0 + index)

    def test_a_failing_backup_raises_one_alert_an_operator_can_see(self):
        self.drive_to_failing()
        alert_id = self.app.monitor_backup_health(now=10_500.0)
        self.assertIsNotNone(alert_id)
        alert = self.app.store.get_alert(alert_id)
        self.assertEqual(alert["kind"], "recovery_backup_failing")
        self.assertEqual(alert["severity"], "high")
        self.assertIn("SENTINEL_LEDGER_DIR", alert["recommendation"])

    def test_the_alert_is_raised_once_per_failure_run(self):
        self.drive_to_failing()
        self.assertIsNotNone(self.app.monitor_backup_health(now=10_500.0))
        self.assertIsNone(self.app.monitor_backup_health(now=10_600.0))
        self.assertIsNone(self.app.monitor_backup_health(now=99_999.0))

    def test_recovery_rearms_the_alert(self):
        self.drive_to_failing()
        self.assertIsNotNone(self.app.monitor_backup_health(now=10_500.0))
        self.app.record_backup_outcome(True, interval=60.0, now=10_600.0)
        self.assertIsNone(self.app.monitor_backup_health(now=10_600.0))
        for index in range(BACKUP_FAILURE_ALERT_COUNT):
            self.app.record_backup_outcome(False, reason=OSError("again"),
                                           interval=60.0, now=11_000.0 + index)
        self.assertIsNotNone(self.app.monitor_backup_health(now=11_100.0))

    def test_a_healthy_controller_raises_nothing(self):
        self.app.record_backup_outcome(True, interval=60.0, now=10_000.0)
        self.assertIsNone(self.app.monitor_backup_health(now=10_030.0))

    def test_an_unconfigured_backup_schedule_raises_nothing(self):
        # No backup directory means no schedule to miss.
        self.assertIsNone(self.app.monitor_backup_health(now=10_000.0))

    def test_the_alert_kind_is_known_to_the_risk_model(self):
        self.assertIn("recovery_backup_failing", KIND_FEATURES)

    def test_the_controller_identity_is_reserved(self):
        # Alerts about the controller itself must not be attributable to, or
        # spoofable by, an enrolled host.
        self.assertIn(CONTROLLER_AGENT_ID, INTERNAL_AGENT_IDS)


class MonitorCannotBreakTheLoopTests(unittest.TestCase):
    """The monitor for a silent stall must not be able to cause one."""

    def app(self, **overrides):
        base = dict(
            store=MagicMock(), resume_pending_telemetry=MagicMock(),
            monitor_stale_agents=MagicMock(), create_recovery_backup=MagicMock(),
            recovery_key=b"k", recovery_anchor=Path("unused"), maintenance_heartbeat=0.0,
            record_backup_outcome=MagicMock(), monitor_backup_health=MagicMock(),
        )
        base.update(overrides)
        return SimpleNamespace(**base)

    def run_once(self, app, backups=None):
        stop = MagicMock()
        stop.is_set.side_effect = [False, True]
        with patch("sentinel_blue.recovery_ops.prune_recovery_backups"), \
                patch.object(controller_module.time, "time", return_value=10_000.0):
            maintenance_loop(app, 60.0, 30, backups, 60.0, 5, 5.0, stop)

    def test_a_raising_monitor_does_not_stop_maintenance(self):
        app = self.app(monitor_backup_health=MagicMock(side_effect=RuntimeError("boom")))
        with self.assertLogs("sentinel_blue.controller", level="ERROR"):
            self.run_once(app)
        app.resume_pending_telemetry.assert_called_once()
        self.assertGreater(app.maintenance_heartbeat, 0)

    def test_a_raising_recorder_does_not_fail_a_good_backup(self):
        recorded = MagicMock(side_effect=RuntimeError("boom"))
        app = self.app(record_backup_outcome=recorded)
        with self.assertLogs("sentinel_blue.controller", level="ERROR"):
            self.run_once(app, backups="/tmp/does-not-need-to-exist")
        app.create_recovery_backup.assert_called_once()
        self.assertGreater(app.maintenance_heartbeat, 0)

    def test_an_older_app_without_the_methods_still_maintains(self):
        app = self.app()
        del app.record_backup_outcome
        del app.monitor_backup_health
        self.run_once(app)
        app.resume_pending_telemetry.assert_called_once()
        self.assertGreater(app.maintenance_heartbeat, 0)

    def test_note_backup_swallows_everything(self):
        _note_backup(SimpleNamespace(), True)
        broken = SimpleNamespace(record_backup_outcome=MagicMock(side_effect=OSError("x")))
        with self.assertLogs("sentinel_blue.controller", level="ERROR"):
            _note_backup(broken, False, reason=OSError("y"))


if __name__ == "__main__":
    unittest.main()
