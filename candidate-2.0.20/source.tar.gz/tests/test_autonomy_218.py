"""2.0.18: the stale stop request, and bugs 12 and 13 of the 2.0.15 autonomy review.

* A stop request left behind by a stopped or failed local session stopped every
  later start of that session right after it became ready.
* 12. An undo that failed without changing anything was still marked
  review_required, so Resume of that service was refused forever, and no
  reconciliation could clear it.
* 13. An automatic restart that expired before any agent received it was
  counted as a failed attempt, so three agent outages used up the hourly
  failure budget.
"""
import copy
import json
import threading
import time
import types
import unittest
from dataclasses import asdict
from pathlib import Path
from unittest.mock import MagicMock, patch

from sentinel_blue.controller import ControllerServer, make_handler
from sentinel_blue.desktop_control import DesktopClient, verification_rows
from sentinel_blue.service_automation import snapshot
from sentinel_blue.state import read_private_json, write_private_json
from test_autonomous_service_recovery import stopped
from test_automatic_undo_214 import AutomaticStartFixture
from test_autonomy_217 import SessionHarness, controller, outage, recoveries


# ------------------------------------------------------- stale stop request ---

class StopRequestTests(SessionHarness):
    """A stop request stops only the runner it names, and only once."""

    def launch(self, launch_id=None, *, wait=True):
        from sentinel_blue.linux_workspace import run_session
        self.result = {}
        before = self.status().get("run_id")
        thread = threading.Thread(target=lambda: self.result.update(code=run_session(
            types.SimpleNamespace(session=str(self.directory / "session.json"), launch_id=launch_id))), daemon=True)
        thread.start()
        self.thread = thread
        if wait:
            self.wait(lambda: not thread.is_alive() or (self.status().get("run_id") != before
                                                        and self.status().get("state") in {"running", "stopped", "failed"}))

    def request(self):
        path = self.directory / "stop-session.json"
        return read_private_json(path) if path.exists() else None

    def still_running(self, seconds=1.0):
        time.sleep(seconds)
        return self.thread.is_alive() and self.status().get("state") == "running"

    def end(self):
        from sentinel_blue.linux_workspace import request_running_session_stop
        request_running_session_stop(self.config)
        self.thread.join(10)
        self.assertFalse(self.thread.is_alive())
        self.assertEqual(self.result["code"], 0)
        self.assertIsNone(self.request())

    def test_a_stop_for_the_current_run_stops_it_and_does_not_stop_the_next_start(self):
        from sentinel_blue.linux_workspace import request_running_session_stop
        self.launch()
        run = self.status()["run_id"]
        request_running_session_stop(self.config)
        self.assertEqual(self.request(), {"session_id": self.config["session_id"], "run_id": run})
        self.thread.join(10)
        self.assertEqual((self.result["code"], self.status()["state"]), (0, "stopped"))
        self.assertIsNone(self.request())                    # honoured, so removed
        self.launch()                                        # before 2.0.18 this start stopped right away
        self.assertNotEqual(self.status()["run_id"], run)
        self.assertTrue(self.still_running())
        self.end()

    def test_a_stop_left_for_a_runner_that_is_gone_is_removed_as_stale(self):
        from sentinel_blue.linux_workspace import request_session_stop
        request_session_stop(self.config, run_id="a" * 32)                    # its runner was killed
        self.launch()
        self.assertTrue(self.still_running())
        self.assertIsNone(self.request())
        self.end()

    def test_a_failed_launch_cannot_stop_a_later_launch(self):
        from sentinel_blue.linux_workspace import request_session_stop
        request_session_stop(self.config, launch_id="b" * 32)                # the GUI's failure path
        self.launch(launch_id="c" * 32)
        self.assertTrue(self.still_running())
        self.assertIsNone(self.request())
        self.end()

    def test_a_stop_for_this_launch_is_honoured_even_before_readiness(self):
        from sentinel_blue.linux_workspace import request_session_stop
        self.dashboard_error = OSError("not ready yet")
        self.launch(launch_id="d" * 32, wait=False)
        self.wait(lambda: len(self.spawned) == 1)
        request_session_stop(self.config, launch_id="d" * 32)
        self.thread.join(10)
        self.assertFalse(self.thread.is_alive())
        self.assertEqual(self.result["code"], 0)
        self.assertEqual([c.arguments for c in self.spawned], [["controller"]])
        self.assertTrue(self.spawned[0].terminated)
        self.assertIsNone(self.request())

    def test_an_unscoped_request_stops_the_running_session_once(self):
        self.launch()
        write_private_json(self.directory / "stop-session.json", {"session_id": self.config["session_id"]})
        self.thread.join(10)
        self.assertEqual(self.result["code"], 0)
        self.assertIsNone(self.request())
        self.launch()
        self.assertTrue(self.still_running())
        self.end()

    def test_an_unscoped_request_left_from_before_the_start_is_stale(self):
        # e.g. written by the 2.0.17 GUI's Stop, which named no runner
        write_private_json(self.directory / "stop-session.json", {"session_id": self.config["session_id"]})
        self.launch()
        self.assertTrue(self.still_running())
        self.assertIsNone(self.request())
        self.end()

    def test_a_stop_this_launch_received_before_its_runner_started_is_honoured(self):
        from sentinel_blue.linux_workspace import request_session_stop
        request_session_stop(self.config, launch_id="9" * 32)      # the GUI's failure path won the race
        self.launch(launch_id="9" * 32)
        self.thread.join(10)
        self.assertEqual(self.result["code"], 0)
        self.assertIsNone(self.request())

    def test_a_request_for_another_session_is_ignored_and_kept(self):
        write_private_json(self.directory / "stop-session.json", {"session_id": "other", "run_id": "e" * 32})
        self.launch()
        self.assertTrue(self.still_running())
        self.assertEqual(self.request()["session_id"], "other")
        self.end_other()

    def end_other(self):
        from sentinel_blue.linux_workspace import request_running_session_stop
        request_running_session_stop(self.config)
        self.thread.join(10)
        self.assertEqual(self.result["code"], 0)

    def test_request_helpers_validate_identifiers(self):
        from sentinel_blue.linux_workspace import request_running_session_stop, request_session_stop, run_session
        for bad in ("short", "G" * 32, 7):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                request_session_stop(self.config, run_id=bad)
        write_private_json(self.directory / "session-status.json", {"state": "running", "run_id": "not-a-run"})
        request_running_session_stop(self.config)
        self.assertEqual(self.request(), {"session_id": self.config["session_id"]})
        with self.assertRaisesRegex(ValueError, "launch identifier"):
            run_session(types.SimpleNamespace(session=str(self.directory / "session.json"), launch_id="x"))

    def test_the_runner_command_accepts_a_launch_id(self):
        from sentinel_blue.__main__ import parser
        args = parser().parse_args(["linux-desktop-session", "--session", "s.json", "--launch-id", "f" * 32])
        self.assertEqual(args.launch_id, "f" * 32)

    def test_the_run_is_announced_only_after_leftover_requests_are_cleared(self):
        # Otherwise a Stop naming the new run could be written, and then
        # removed with the leftovers.
        import sentinel_blue.linux_workspace as lw
        real, seen = lw._take_stop_request, []

        def checked(directory, config, run_id, launch_id, *, starting=False):
            if starting:
                seen.append(self.status().get("run_id") != run_id)
            return real(directory, config, run_id, launch_id, starting=starting)
        with patch.object(lw, "_take_stop_request", checked):
            self.launch()
        self.assertEqual(seen, [True])
        self.end()

    def test_a_stop_for_the_new_run_during_readiness_is_honoured(self):
        from sentinel_blue.linux_workspace import request_running_session_stop
        request_running_session_stop(self.config)                  # a leftover, unscoped
        self.dashboard_error = OSError("not ready yet")
        self.launch(wait=False)
        self.wait(lambda: self.status().get("state") == "starting" and len(self.spawned) == 1)
        request_running_session_stop(self.config)                  # names the new run
        self.thread.join(10)
        self.assertFalse(self.thread.is_alive())
        self.assertEqual(self.result["code"], 0)
        self.assertIsNone(self.request())

    def test_a_request_naming_this_run_is_never_treated_as_stale(self):
        from sentinel_blue.linux_workspace import _take_stop_request, request_session_stop
        for starting in (True, False):
            with self.subTest(starting=starting):
                request_session_stop(self.config, run_id="7" * 32)
                self.assertTrue(_take_stop_request(self.directory, self.config, "7" * 32, None, starting=starting))
                self.assertIsNone(self.request())

    def test_a_stop_written_while_a_stale_request_is_removed_is_not_lost(self):
        import sentinel_blue.linux_workspace as lw
        run = "8" * 32
        real = lw._classify_stop
        # (1) The Stop lands between the read and the removal: the Stop,
        # not the stale request, is what gets taken, and it is honoured.
        calls = []

        def first(request, config, run_id, launch_id):
            calls.append(1)
            if len(calls) == 1:
                lw.request_session_stop(self.config, run_id=run)
            return real(request, config, run_id, launch_id)
        lw.request_session_stop(self.config, launch_id="2" * 32)
        with patch.object(lw, "_classify_stop", first):
            self.assertTrue(lw._take_stop_request(self.directory, self.config, run, None))
        self.assertIsNone(self.request())
        # (2) The Stop lands after the stale request was set aside: it stays
        # for the next check.
        calls.clear()

        def second(request, config, run_id, launch_id):
            calls.append(1)
            if len(calls) == 2:
                lw.request_session_stop(self.config, run_id=run)
            return real(request, config, run_id, launch_id)
        lw.request_session_stop(self.config, launch_id="2" * 32)
        with patch.object(lw, "_classify_stop", second):
            self.assertFalse(lw._take_stop_request(self.directory, self.config, run, None))
        self.assertEqual(self.request(), {"session_id": self.config["session_id"], "run_id": run})
        self.assertTrue(lw._take_stop_request(self.directory, self.config, run, None))
        self.assertIsNone(self.request())
        self.assertEqual(list(self.directory.glob(".stop-session.json.*")), [])

    def test_another_sessions_request_swapped_in_is_put_back(self):
        import sentinel_blue.linux_workspace as lw
        real, calls = lw._classify_stop, []

        def swap(request, config, run_id, launch_id):
            calls.append(1)
            if len(calls) == 1:
                write_private_json(self.directory / "stop-session.json", {"session_id": "other"})
            return real(request, config, run_id, launch_id)
        lw.request_session_stop(self.config, launch_id="2" * 32)
        with patch.object(lw, "_classify_stop", swap):
            self.assertFalse(lw._take_stop_request(self.directory, self.config, "8" * 32, None))
        self.assertEqual(self.request(), {"session_id": "other"})

    def test_a_request_set_aside_by_a_runner_that_died_is_cleared_at_start(self):
        write_private_json(self.directory / f".stop-session.json.{'3' * 32}.taken", {"session_id": self.config["session_id"]})
        self.launch()
        self.assertTrue(self.still_running(0.3))
        self.assertEqual(list(self.directory.glob(".stop-session.json.*")), [])
        self.end()


class GuiStartTests(SessionHarness):
    """The GUI's real start path against the real runner (fake controller and agent)."""

    def start_from_gui(self):
        import sentinel_blue.linux_workspace as lw
        from sentinel_blue.linux_desktop_setup import LinuxSetupControls
        runner = {}

        class Process:
            def __init__(self, thread):
                self.thread = thread

            def poll(self):
                return None if self.thread.is_alive() else runner.get("code", 0)

        def detach(arguments):
            if arguments[0] == "linux-desktop-session":
                launch = arguments[arguments.index("--launch-id") + 1]

                def run():
                    time.sleep(0.3)             # interpreter start and runtime hash
                    try:
                        runner["code"] = lw.run_session(types.SimpleNamespace(session=arguments[2], launch_id=launch))
                    except Exception:
                        runner["code"] = 1      # as the command line reports an error
                thread = threading.Thread(target=run, daemon=True)
                thread.start()
                runner["thread"] = thread
                return Process(thread)
            from test_autonomy_217 import FakeChild
            child = FakeChild(arguments)
            self.spawned.append(child)
            return child
        statuses = []
        gui = types.SimpleNamespace(local_wizard_busy=False, local_selection_digest="d", generation=0,
                                    local_workspace=dict(self.config), note=statuses.append,
                                    local_status=types.SimpleNamespace(set=statuses.append),
                                    job_control=MagicMock(), directory=self.directory.parent)
        gui._local_selection = lambda: "d"
        outcome = {}

        def submit(work, ready, failed, preserve=False):
            try:
                outcome["ready"] = work()
            except Exception as exc:
                outcome["failed"] = exc
            return True
        gui.submit = submit
        with patch("sentinel_blue.desktop_jobs.detach", detach), \
                patch.object(lw, "require_available_local_ports", lambda config: None), \
                patch("os.geteuid", lambda: 0):
            LinuxSetupControls.start_local_session(gui, lambda: None)
        self.runner = runner
        return outcome

    def stop_runner(self):
        from sentinel_blue.linux_workspace import request_running_session_stop
        request_running_session_stop(self.config)
        self.runner["thread"].join(10)
        self.assertFalse(self.runner["thread"].is_alive())

    def test_a_status_left_by_an_earlier_run_does_not_fail_the_next_start(self):
        for previous in ("failed", "running"):
            with self.subTest(previous=previous):
                write_private_json(self.directory / "session-status.json", {
                    "state": previous, "reason": "OLD: the previous run's reason", "run_id": "a" * 32,
                    "session_id": self.config["session_id"], "updated_at": time.time() - 600})
                outcome = self.start_from_gui()
                self.assertNotIn("failed", outcome, outcome)
                self.assertEqual(self.status()["state"], "running")
                self.assertTrue(self.runner["thread"].is_alive())
                self.stop_runner()

    def test_a_runner_that_refuses_before_any_status_is_reported_with_its_exit_status(self):
        write_private_json(self.directory / "session-status.json", {
            "state": "failed", "reason": "OLD: the previous run's reason", "run_id": "a" * 32,
            "session_id": self.config["session_id"], "updated_at": time.time() - 600})
        self.runtime.write_bytes(b"a changed runtime")          # the runner refuses before taking the lock
        outcome = self.start_from_gui()
        self.runner["thread"].join(10)
        self.assertEqual(str(outcome["failed"]), "The local session exited before readiness (exit status 1).")

    def test_a_start_that_finds_its_session_already_running_uses_it(self):
        # A second Start while a runner holds the session: the new runner
        # exits, and the running session is used, as before 2.0.18.
        from sentinel_blue.linux_workspace import run_session
        first = {}
        thread = threading.Thread(target=lambda: first.update(code=run_session(
            types.SimpleNamespace(session=str(self.directory / "session.json"), launch_id=None))), daemon=True)
        thread.start()
        self.wait(lambda: self.status().get("state") == "running")
        outcome = self.start_from_gui()
        self.assertIn("ready", outcome, outcome)
        self.assertEqual(self.runner["code"], 2)                 # the lock holder kept the session
        from sentinel_blue.linux_workspace import request_running_session_stop
        request_running_session_stop(self.config)
        thread.join(10)
        self.assertEqual(first["code"], 0)


# ------------------------------------------------------------------ bug 12 ---

class FailedUndoTests(AutomaticStartFixture):
    """Bug 12: only an undo that began changing the host holds Resume, and a review can clear it."""

    def queue_undo(self, identifier):
        review = self.app.review_service_action({'agent_id': 'agent-one', 'service': 'web.service',
                                                 'choice': 'undo', 'action_id': identifier}, 'operator')
        return self.app.execute_service_action({'review_id': review['review_id'],
            'review_sha256': review['review_sha256'], 'reason': 'Undo this witnessed automatic start',
            'authorization_code': ''}, 'operator')['action_id']

    def failed_after_it_began(self):
        identifier, _ = self.forward()
        inverse = self.queue_undo(identifier)

        def refuse_stop(service, state):
            raise OSError("systemctl stop timed out")      # the undo had begun: its journal is undo_prepared
        with patch.object(self.executor.repairs, "_transition", side_effect=refuse_stop):
            result = self.deliver(inverse)
        return inverse, result

    def sample_after(self, sequence, **changes):
        sample = copy.deepcopy(self.baseline)
        sample.update(sequence=sequence, observed_at=time.time(), **changes)
        self.app.ingest(sample)
        return sample

    def test_an_undo_refused_before_changing_anything_does_not_hold_resume(self):
        identifier, _ = self.forward()
        inverse = self.queue_undo(identifier)
        self.native = 'stopped'                                  # the service stopped before the undo ran
        result = self.deliver(inverse)
        self.assertFalse(result['success'])
        self.assertNotIn('review_required', result)
        self.assertIn('the undo changed nothing', result['message'])
        self.assertEqual(self.transitions[-1], ('web.service', 'running'))   # only the forward start
        self.assertTrue(snapshot(self.store, self.profile, 'agent-one')['services']['web.service']['paused'])
        history = self.app.service_action_history({'agent_id': 'agent-one', 'service': 'web.service'})['actions']
        self.assertEqual(next(r for r in history if r['action_id'] == identifier)['undo_status'], 'Failed')
        self.fresh_stopped(6)
        self.resume()
        self.local.accept(snapshot(self.store, self.profile, 'agent-one'))
        self.assertEqual(self.local.read()['latches'], {})
        self.assertFalse(self.local.read()['snapshot']['services']['web.service']['paused'])
        self.assertEqual([r for r in verification_rows(self.store.dashboard()) if r['kind'] == 'undo-review'], [])

    def test_an_undo_that_failed_after_it_began_holds_resume_until_reviewed_with_evidence(self):
        identifier, _ = self.forward()
        inverse = self.queue_undo(identifier)
        with patch.object(self.executor.repairs, "_transition", side_effect=OSError("systemctl stop timed out")):
            result = self.deliver(inverse)
        self.assertFalse(result['success'])
        self.assertIs(result['review_required'], True)
        reported = self.store.get_action(inverse)
        self.fresh_stopped(6)
        with self.assertRaisesRegex(PermissionError, 'failed inverse.*Alerts & verification tab: action ' + inverse):
            self.resume()
        history = self.app.service_action_history({'agent_id': 'agent-one', 'service': 'web.service'})['actions']
        self.assertEqual(next(r for r in history if r['action_id'] == identifier)['undo_status'], 'Held')
        # The GUI offers the review.
        rows = [r for r in verification_rows(self.store.dashboard()) if r['kind'] == 'undo-review']
        self.assertEqual([(r['id'], r['choices']) for r in rows], [(inverse, ['reviewed'])])
        # Evidence 1: an observation from before the failure is not enough.
        failed_at = self.store.get_action(inverse)['completed_at']
        old = stopped(self.baseline, 7); old['observed_at'] = failed_at - 1
        self.app.ingest(old)
        with self.assertRaisesRegex(RuntimeError, 'after the failed undo'):
            self.app.reconcile_action_outcome(inverse, 'reviewed')
        # Evidence 2: the agent still reports an interrupted change.
        self.sample_after(8, collector_errors=['self-health: one or more interrupted service changes require review'])
        with self.assertRaisesRegex(RuntimeError, 'still reports'):
            self.app.reconcile_action_outcome(inverse, 'reviewed')
        self.assertIsNone(self.store.undo_review(inverse))
        # Evidence 3: a clean observation after the agent finished its own recovery.
        self.sample_after(9)
        reviewed = self.app.reconcile_action_outcome(inverse, 'reviewed')
        self.assertEqual(reviewed['completion'], 'new')
        # The agent's result is kept exactly as reported; the review is kept beside it.
        self.assertEqual(self.store.get_action(inverse), reported)
        review = self.store.undo_review(inverse)
        self.assertEqual((review['resolution'], review['evidence']['sequence']), ('reviewed', 9))
        self.assertEqual(self.app.reconcile_action_outcome(inverse, 'reviewed')['completion'], 'exact_retry')
        audit = self.store._connection.execute(
            "SELECT COUNT(*) FROM audit_log WHERE operation='reconcile_failed_undo' AND subject=?", (inverse,)).fetchone()[0]
        self.assertEqual(audit, 1)
        history = self.app.service_action_history({'agent_id': 'agent-one', 'service': 'web.service'})['actions']
        self.assertEqual(next(r for r in history if r['action_id'] == identifier)['undo_status'], 'Reviewed')
        self.assertEqual([r for r in verification_rows(self.store.dashboard()) if r['kind'] == 'undo-review'], [])
        # A later undo still cannot be layered over the failed one.
        with self.assertRaisesRegex(ValueError, 'later service action'):
            self.queue_undo(identifier)
        self.fresh_stopped(10)
        self.resume()

    def test_the_agent_finishes_the_undo_and_a_stopped_linux_unit_is_accepted(self):
        inverse, _ = self.failed_after_it_began()
        self.assertFalse(self.executor.allow_restoration)       # restart permission alone, as the start had
        report = self.executor.refresh_service_recovery()
        self.assertTrue(report['healthy'], report)
        self.assertEqual(self.native, 'stopped')                  # the undo is finished
        def attempt(state, platform='Linux', record=False):
            sample = copy.deepcopy(self.baseline)
            sample['services'][0]['state'] = state
            sample.update(sequence=self.sequence, observed_at=time.time(), platform=platform)
            self.sequence += 1
            self.app.ingest(sample)
            if record:
                return self.app.reconcile_action_outcome(inverse, 'reviewed')['completion']
            with patch.object(self.store, 'reconcile_failed_undo', return_value={'completion': 'accepted'}):
                return self.app.reconcile_action_outcome(inverse, 'reviewed')['completion']
        self.sequence = 20
        # How systemd reports a stopped unit (the Linux collector never says "stopped").
        self.assertEqual(attempt('failed'), 'accepted')
        for state, platform in (('activating', 'Linux'), ('unknown', 'Linux'), ('inactive', 'Windows')):
            with self.subTest(state=state, platform=platform), self.assertRaisesRegex(RuntimeError, 'not known'):
                attempt(state, platform)
        self.assertEqual(attempt('inactive', record=True), 'new')

    def test_the_agent_cannot_finish_a_repair_undo_without_restoration_permission(self):
        # Only a start journal (restart authority) is finished with restart
        # permission alone; a journal written under repair authority still
        # needs restoration permission, as before.
        identifier, forward = self.forward()
        inverse = self.queue_undo(identifier)
        with patch.object(self.executor.repairs, "_transition", side_effect=OSError("systemctl stop timed out")):
            self.deliver(inverse)
        repairs = self.executor.repairs
        path = repairs._path(forward['pre_state']['transaction_id'])
        record = repairs._read(path)
        self.assertEqual((record['status'], record['origin_action']), ('undo_prepared', 'restart_service'))
        record['origin_action'] = 'repair_service'
        repairs._write(record)
        report = self.executor.refresh_service_recovery()
        self.assertFalse(report['healthy'])
        self.assertIn('requires current local repair permissions', report['unresolved'][0]['reason'])
        self.assertEqual(self.native, 'running')                  # nothing was changed
        self.executor.allow_restoration = True
        self.assertTrue(self.executor.refresh_service_recovery()['healthy'])
        self.assertEqual(self.native, 'stopped')

    def test_a_truncated_diagnostic_list_is_not_evidence(self):
        from sentinel_blue.telemetry_diagnostics import merge_health_diagnostics, restore_point_issues
        inverse, _ = self.failed_after_it_began()
        sample = copy.deepcopy(self.baseline)
        sample['collector_errors'] = []
        merge_health_diagnostics(sample, ['self-health: one or more interrupted service changes require review'])
        merge_health_diagnostics(sample, restore_point_issues({'lost': [f'/srv/app/f{i}.conf' for i in range(300)]}))
        self.assertFalse(any('self-health:' in error for error in sample['collector_errors']))   # dropped
        sample.update(sequence=30, observed_at=time.time())
        self.app.ingest(sample)
        with self.assertRaisesRegex(RuntimeError, 'truncated'):
            self.app.reconcile_action_outcome(inverse, 'reviewed')
        self.assertIsNone(self.store.undo_review(inverse))

    def test_the_agents_result_is_still_acknowledged_after_a_review(self):
        # The controller stored the result but the agent never got the
        # acknowledgement; it offers the same result again after the review.
        inverse, result = self.failed_after_it_began()
        self.sample_after(9)
        self.app.reconcile_action_outcome(inverse, 'reviewed')
        self.assertEqual(self.app.complete_action(dict(result, action_id=inverse), 'agent-one'), 'exact_retry')

    def test_the_review_is_offered_however_many_actions_follow(self):
        import uuid
        inverse, _ = self.failed_after_it_began()
        database = self.store._connection
        for n in range(150):              # later work on other hosts; only the count and order matter
            database.execute(
                "INSERT INTO actions(action_id, agent_id, action_type, parameters_json, status, created_at, automated, "
                "risk, expires_at, profile_id, profile_fingerprint, autonomy_mode, result_json, result_source, "
                "completed_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (str(uuid.uuid4()), 'agent-two', 'validate_service', '{"service":"x"}', 'completed',
                 time.time() + 1 + n / 1000, 1, 'low', time.time() + 300, '', '', '',
                 '{"message":"ok","success":true}', 'agent', time.time()))
        database.commit()
        dashboard = self.store.dashboard()
        self.assertNotIn(inverse, [a['action_id'] for a in dashboard['actions']])
        self.assertEqual([r['id'] for r in verification_rows(dashboard) if r['kind'] == 'undo-review'], [inverse])

    def test_review_is_only_for_failed_undos(self):
        identifier, _ = self.forward()
        with self.assertRaisesRegex(RuntimeError, 'not a failed undo'):
            self.app.reconcile_action_outcome(identifier, 'reviewed')
        with self.assertRaisesRegex(RuntimeError, 'not a failed undo'):
            self.store.reconcile_failed_undo(identifier, {})
        self.assertIsNone(self.app.reconcile_action_outcome('missing-action', 'reviewed'))
        with self.assertRaisesRegex(ValueError, 'executed or not_executed'):
            self.store.reconcile_action_outcome(identifier, 'reviewed')
        for bad in ('', 'x' * 129, 7):
            with self.subTest(bad=bad), self.assertRaisesRegex(ValueError, 'identity'):
                self.app.reconcile_action_outcome(bad, 'reviewed')

    def test_review_through_the_signed_operator_route(self):
        inverse, _ = self.failed_after_it_began()
        server = ControllerServer(('127.0.0.1', 0), make_handler(self.app))
        thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
        self.addCleanup(server.server_close); self.addCleanup(server.shutdown)
        client = DesktopClient(f'http://127.0.0.1:{server.server_port}', 'operator', 1, 'o' * 32)
        row = {'kind': 'undo-review', 'id': inverse, 'host': 'agent-one', 'choices': ['reviewed'], 'detail': {}}
        with self.assertRaisesRegex(Exception, '409|after the failed undo'):
            client.decide(row, 'reviewed')
        self.sample_after(9)
        self.assertEqual(client.decide(row, 'reviewed')['resolution'], 'reviewed')
        with self.assertRaisesRegex(ValueError, 'Invalid verification choice'):
            client.decide(row, 'executed')


# ------------------------------------------------------------------ bug 13 ---

class NeverDeliveredRestartTests(unittest.TestCase):
    """Bug 13: a restart no agent ever received spends no recovery budget."""

    def setUp(self):
        self.app, self.store, self.profile, self.baseline = controller()
        self.addCleanup(self.store.close)
        self.sequence = 2

    def episode(self, at):
        with patch("time.time", return_value=at):
            outage(self.app, self.baseline, self.sequence, at)
        self.sequence += 2

    def budget(self, at):
        return self.store._service_recovery_budget_status_locked("agent-one", "web.service", at, None)

    def test_expired_undelivered_restarts_do_not_use_the_failure_budget(self):
        t0 = time.time()
        for episode in range(4):
            base = t0 + episode * 310
            self.episode(base)
            with patch("time.time", return_value=base + 301):
                self.store.pending_actions("agent-one")          # no agent polled; it expires
        rows = recoveries(self.store)
        self.assertEqual([r['status'] for r in rows], ['failed'] * 4)
        budget = self.budget(t0 + 4 * 310)
        self.assertTrue(budget['allowed'], budget)
        self.assertEqual((budget['attempts_in_window'], budget['failed_attempts_in_window']), (0, 0))
        self.episode(t0 + 4 * 310 + 5)
        self.assertEqual(recoveries(self.store)[-1]['status'], 'queued')

    def test_a_delivered_restart_still_holds_until_its_outcome_is_known(self):
        t0 = time.time()
        self.episode(t0)
        with patch("time.time", return_value=t0 + 1):
            self.store.pending_actions("agent-one")              # the agent received it ...
        with patch("time.time", return_value=t0 + 400):
            self.store.pending_actions("agent-one")              # ... and never reported
        self.assertEqual(recoveries(self.store)[0]['status'], 'outcome_unknown')
        self.assertEqual(self.budget(t0 + 400)['reason'], 'service_recovery_prior_outcome_unresolved')

    def test_a_restart_that_ran_and_failed_still_counts(self):
        t0 = time.time()
        self.episode(t0)
        (action,) = [asdict(a) for a in self.app.pending_actions_for_agent("agent-one")]
        result = {"action_type": "restart_service", "success": False, "message": "service did not start",
                  "started_at": t0 + 2, "completed_at": t0 + 3}
        self.assertEqual(self.app.complete_action(dict(result, action_id=action["action_id"]), "agent-one"), "new")
        budget = self.budget(t0 + 10)
        self.assertFalse(budget['allowed'])
        self.assertEqual(budget['failed_attempts_in_window'], 1)

    def test_an_expired_operator_restart_is_unchanged(self):
        # A restart that is not automatic and expired still counts, exactly as
        # before: like the Pause exclusion, this one covers automatic restarts.
        t0 = time.time()
        self.episode(t0)
        self.store._connection.execute("UPDATE actions SET automated=0")
        self.store._connection.commit()
        with patch("time.time", return_value=t0 + 301):
            self.store.pending_actions("agent-one")
        self.assertEqual(self.budget(t0 + 302)['failed_attempts_in_window'], 1)


class UnreviewedUndoRetentionTests(unittest.TestCase):
    """An unreviewed failed undo holds Resume, so retention never removes it."""

    from test_history_storage import HistoryStorageTests as _history
    setUp = _history.setUp
    age = _history.age

    def failed_undo(self, *, review_required, age_days=40):
        import uuid
        identifier = str(uuid.uuid4())
        created = time.time() - age_days * 86400
        result = {"action_type": "rollback_service_repair", "success": False, "message": "undo failed",
                  **({"review_required": True} if review_required else {})}
        self.store._connection.execute(
            "INSERT INTO actions(action_id, agent_id, action_type, parameters_json, status, created_at, automated, "
            "risk, expires_at, profile_id, profile_fingerprint, autonomy_mode, result_json, result_source, "
            "completed_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (identifier, 'agent-one', 'rollback_service_repair', '{"service":"web.service"}', 'failed', created, 0,
             'high', created + 300, '', '', '', json.dumps(result, separators=(',', ':'), sort_keys=True),
             'agent', created + 5))
        self.store._connection.commit()
        return identifier

    def kept(self, identifier):
        return self.store.get_action(identifier) is not None

    def test_history_archiving_keeps_an_unreviewed_failed_undo(self):
        waiting = self.failed_undo(review_required=True)
        ordinary = self.failed_undo(review_required=False)
        self.age()
        self.assertTrue(self.kept(waiting))
        self.assertFalse(self.kept(ordinary))
        self.assertEqual([item['action_id'] for item in self.store.failed_undos_awaiting_review()], [waiting])
        # Once reviewed, it follows ordinary retention.
        self.store._connection.execute(
            "INSERT INTO controller_state(state_key, state_value, updated_at) VALUES(?, ?, ?)",
            ('undo_review:' + waiting, json.dumps({'action_id': waiting, 'resolution': 'reviewed'}), time.time()))
        self.store._connection.commit()
        self.age()
        self.assertFalse(self.kept(waiting))

    def test_pruning_keeps_an_unreviewed_failed_undo(self):
        waiting = self.failed_undo(review_required=True)
        ordinary = self.failed_undo(review_required=False)
        self.store._connection.execute(
            "UPDATE actions SET result_json='not json' WHERE action_id=?", (ordinary,))  # never raises in SQL
        self.store._connection.commit()
        removed = self.store.prune(retention_days=30)
        self.assertTrue(self.kept(waiting))
        self.assertGreaterEqual(removed['actions'], 1)
        self.assertIsNone(self.store._connection.execute(
            "SELECT 1 FROM actions WHERE action_id=?", (ordinary,)).fetchone())


class NeverDeliveredLaterWorkTests(AutomaticStartFixture):
    """A restart or repair no agent received is not later work for undo or setup redo."""

    def later(self, identifier, *, delivered):
        # A later automatic action on the same service that expired unleased
        # (or, for the control case, was leased once).
        from sentinel_blue.store import ACTION_AUTHORIZATION_EXPIRED_RESULT
        import uuid
        row = dict(self.store._connection.execute("SELECT * FROM actions WHERE action_id=?", (identifier,)).fetchone())
        row.update(action_id=str(uuid.uuid4()), created_at=row['created_at'] + 30, status='failed',
                   attempts=1 if delivered else 0, dispatched_at=(row['created_at'] + 31) if delivered else None,
                   result_source='controller', result_json=ACTION_AUTHORIZATION_EXPIRED_RESULT,
                   completed_at=row['created_at'] + 330, automated=1)
        columns = ', '.join(row)
        self.store._connection.execute(f"INSERT INTO actions({columns}) VALUES({', '.join('?' * len(row))})",
                                       tuple(row.values()))
        self.store._connection.commit()
        return row['action_id']

    def review_undo(self, identifier):
        return self.app.review_service_action({'agent_id': 'agent-one', 'service': 'web.service',
                                               'choice': 'undo', 'action_id': identifier}, 'operator')

    def test_an_expired_undelivered_restart_does_not_block_undo(self):
        identifier, _ = self.forward()
        self.later(identifier, delivered=False)
        review = self.review_undo(identifier)
        self.assertTrue(review['review_id'] and review['review_sha256'])

    def test_a_delivered_later_restart_still_blocks_undo(self):
        identifier, _ = self.forward()
        self.later(identifier, delivered=True)
        with self.assertRaisesRegex(ValueError, 'later service action'):
            self.review_undo(identifier)

    def test_setup_redo_looks_past_a_repair_no_agent_received(self):
        from sentinel_blue.setup_redo import _latest_repairs
        from sentinel_blue.store import ACTION_AUTHORIZATION_EXPIRED_RESULT
        from sentinel_blue.json_codec import strict_json_loads
        expired = strict_json_loads(ACTION_AUTHORIZATION_EXPIRED_RESULT, max_bytes=4096)
        failed = {'action_id': 'ran', 'agent_id': 'agent-one', 'action_type': 'repair_service', 'created_at': 1,
                  'status': 'failed', 'automated': True, 'attempts': 1, 'dispatched_at': 1.5,
                  'result_source': 'agent', 'parameters': {'service': 'web.service'},
                  'result': {'success': False, 'review_required': True}}
        unleased = dict(failed, action_id='expired', created_at=2, attempts=0, dispatched_at=None,
                        result_source='controller', result=expired)
        self.assertEqual(_latest_repairs({'actions': [failed, unleased]}, 'agent-one')['web.service']['action_id'], 'ran')
        leased = dict(unleased, attempts=1, dispatched_at=2.5)
        self.assertEqual(_latest_repairs({'actions': [failed, leased]}, 'agent-one')['web.service']['action_id'], 'expired')

    def test_the_dashboard_carries_the_delivery_fields_it_needs(self):
        identifier, _ = self.forward()
        row = next(a for a in self.store.dashboard()['actions'] if a['action_id'] == identifier)
        for key in ('attempts', 'dispatched_at', 'result_source', 'automated', 'result'):
            self.assertIn(key, row)


if __name__ == "__main__":
    unittest.main()
