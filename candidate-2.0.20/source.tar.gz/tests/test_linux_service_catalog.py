"""The Linux competition service catalog, its packs, and the GUI chooser.

The provisioning roadmap's central rule is that a named recipe is not an accepted
setup capability. These tests exist to keep that rule true in code: the catalog
distinguishes what the code can do from what has been proven, the packs refuse
every shortcut that would make a scored check pass by weakening a service, and
the chooser cannot become a second execution path around plan approval.

Nothing here has been run against a real BIND, MariaDB, Postfix or vsftpd. The
catalog says so on every row, and one of these tests fails if that ever silently
changes.
"""

import json
import tempfile
import unittest
from pathlib import Path

from sentinel_blue import linux_service_catalog as catalog
from sentinel_blue.desktop_services import (
    ServiceSelectionPanel, catalog_presence, display_rows, host_units, installed_state,
    selection_report, service_plan, summary_line)
from sentinel_blue.linux_service_catalog import (
    ADOPT, CATALOG, CONFIGURE, FAMILIES, MANAGERS, catalog_rows, conflicting, entry,
    missing_requirements, packages_for, support_summary)
from sentinel_blue.linux_service_packs import BUILDERS, WHOLE_FILE_PACKS, build, pack_ids
from sentinel_blue.setup_recipes import RECIPES, compile_recipe


class CatalogShapeTests(unittest.TestCase):
    def test_the_catalog_covers_the_competition_families(self):
        # The service families a Linux competition host actually runs.
        for family in ("dns", "web", "database", "mail", "transfer", "sharing",
                       "directory", "time", "dhcp", "access", "proxy", "cache",
                       "broker", "logging", "runtime", "container", "printing"):
            with self.subTest(family=family):
                self.assertTrue(catalog_rows(family=family), f"no services for {family}")

    def test_the_services_named_as_gaps_in_the_roadmap_are_present(self):
        # BIND/DNS, MySQL/MariaDB, Postfix and vsftpd are the four the roadmap
        # calls out by name as explicitly open application gaps.
        for service_id in ("bind9", "mariadb", "postfix", "vsftpd"):
            with self.subTest(service_id=service_id):
                self.assertIn(service_id, CATALOG)

    def test_every_row_is_well_formed(self):
        for service_id, row in CATALOG.items():
            with self.subTest(service_id=service_id):
                self.assertTrue(catalog.SERVICE_ID.fullmatch(service_id))
                self.assertIn(row["capability"], catalog.CAPABILITIES)
                self.assertTrue(row["label"] and row["unit"] and row["family"])
                self.assertIsInstance(row["ports"], list)
                self.assertTrue(set(row["packages"]) <= set(MANAGERS))

    def test_nothing_claims_to_be_native_tested(self):
        # If a pack is ever proven on a real host, this test is the reminder to
        # record the evidence rather than flip a flag quietly.
        untested = [row["id"] for row in CATALOG.values() if not row["native_tested"]]
        self.assertEqual(len(untested), len(CATALOG))
        self.assertEqual(support_summary()["native_tested"], 0)
        self.assertIn("a catalog row is not support", support_summary()["statement"])

    def test_conflicting_services_are_declared_both_ways_or_detected(self):
        for pair in (("bind9", "dnsmasq"), ("nginx", "apache2"), ("postfix", "exim4")):
            with self.subTest(pair=pair):
                self.assertTrue(conflicting(list(pair)), f"{pair} should conflict")

    def test_dependencies_point_at_real_services(self):
        for row in CATALOG.values():
            for needed in row["requires"]:
                with self.subTest(service_id=row["id"], requires=needed):
                    self.assertIn(needed, CATALOG)
            for other in row["conflicts"]:
                with self.subTest(service_id=row["id"], conflicts=other):
                    self.assertIn(other, CATALOG)

    def test_data_paths_are_never_configuration_paths(self):
        # A pack writes configuration; it must never be pointed at data.
        for row in CATALOG.values():
            with self.subTest(service_id=row["id"]):
                self.assertFalse(set(row["config_paths"]) & set(row["data_paths"]))

    def test_stateful_services_declare_the_data_they_must_preserve(self):
        for service_id in ("mariadb", "postgresql", "postfix", "dovecot", "samba", "bind9"):
            with self.subTest(service_id=service_id):
                self.assertTrue(CATALOG[service_id]["data_paths"],
                                "a stateful service must name what setup preserves")

    def test_packages_are_named_per_manager_or_refused(self):
        self.assertEqual(packages_for("nginx", "apt"), ["nginx"])
        self.assertEqual(packages_for("apache2", "dnf"), ["httpd"])
        with self.assertRaises(ValueError):
            packages_for("nginx", "brew")
        with self.assertRaises(ValueError):
            packages_for("not-a-service", "apt")

    def test_an_unknown_service_is_refused_not_invented(self):
        for value in ("", "nope", "../etc", None, 7):
            with self.subTest(value=value), self.assertRaises(ValueError):
                entry(value)

    def test_missing_requirements_are_reported(self):
        self.assertEqual(missing_requirements(["dovecot"]),
                         [{"service": "dovecot", "requires": "postfix"}])
        self.assertEqual(missing_requirements(["dovecot", "postfix"]), [])


class PackSafetyTests(unittest.TestCase):
    """Every shortcut that would make a scored check pass by weakening a service."""

    def setUp(self):
        self.root = Path(tempfile.mkdtemp(prefix="sentinel-pack-"))

    def refused(self, service_id, options):
        with self.assertRaises(ValueError) as error:
            build(service_id, options, self.root)
        return str(error.exception)

    def test_anonymous_ftp_write_is_never_generated(self):
        self.assertIn("anonymous write", self.refused(
            "vsftpd", {"anonymous_enable": True, "write_enable": True,
                       "previous_sha256": "a" * 64}))

    def test_an_open_mail_relay_is_never_generated(self):
        self.assertIn("open relay", self.refused(
            "postfix", {"myhostname": "mail.range.test", "mydomain": "range.test",
                        "mynetworks": ["0.0.0.0/0"]}))

    def test_an_unauthenticated_exposed_cache_is_refused(self):
        self.assertIn("unauthenticated", self.refused("redis", {"bind_address": "10.0.0.5"}))
        # Loopback without a password is fine; nothing outside can reach it.
        build("redis", {"bind_address": "127.0.0.1"}, self.root)

    def test_an_anonymous_exposed_broker_is_refused(self):
        self.assertIn("unauthenticated", self.refused(
            "mosquitto", {"bind_address": "10.0.0.5", "allow_anonymous": True}))

    def test_exporting_nfs_to_every_network_is_refused(self):
        self.assertIn("every network", self.refused(
            "nfs-server", {"export_path": "/srv/nfs", "clients": ["0.0.0.0/0"]}))

    def test_a_share_or_export_always_names_who_may_use_it(self):
        self.assertIn("permitted clients", self.refused(
            "nfs-server", {"export_path": "/srv/nfs", "clients": []}))
        self.assertIn("permitted users", self.refused(
            "samba", {"share": "scored", "path": "/srv/scored", "valid_users": []}))

    def test_postgres_trust_authentication_is_never_generated(self):
        self.assertIn("auth_method", self.refused("postgresql", {"auth_method": "trust"}))

    def test_dhcp_requires_explicit_event_authorization(self):
        # Enabling DHCP on a shared segment affects every host on it.
        self.assertIn("authorized=true", self.refused(
            "isc-dhcp-server", {"subnet": "10.0.0.0", "netmask": "255.255.255.0",
                                "range_start": "10.0.0.10", "range_end": "10.0.0.20"}))

    def test_a_dhcp_range_must_lie_in_its_own_subnet(self):
        self.assertIn("inside its own subnet", self.refused(
            "isc-dhcp-server", {"authorized": True, "subnet": "10.0.0.0",
                                "netmask": "255.255.255.0", "range_start": "10.9.0.10",
                                "range_end": "10.9.0.20"}))

    def test_a_whole_file_pack_refuses_an_unreviewed_overwrite(self):
        # vsftpd has no configuration directory, so the caller must state the
        # exact digest it expects to replace.
        self.assertIn("previous_sha256", self.refused("vsftpd", {"local_enable": True}))
        build("vsftpd", {"local_enable": True, "previous_sha256": "b" * 64}, self.root)

    def test_an_adoption_only_service_cannot_be_configured(self):
        self.assertIn("adoption-only", self.refused("docker", {}))
        self.assertIn("adoption-only", self.refused("slapd", {}))

    def test_unknown_options_are_refused_rather_than_ignored(self):
        self.assertIn("unknown chrony option", self.refused(
            "chrony", {"sources": ["time.range.test"], "surprise": 1}))

    def test_nginx_keeps_its_established_adapter(self):
        self.assertIn("linux-nginx", self.refused("nginx", {}))


class PackOutputTests(unittest.TestCase):
    def setUp(self):
        self.root = Path(tempfile.mkdtemp(prefix="sentinel-pack-out-"))

    def metadata(self, service_id, options):
        meta = {}
        build(service_id, options, self.root, metadata=meta)
        return meta

    def test_every_configure_service_has_a_builder(self):
        configure = {row["id"] for row in CATALOG.values() if row["capability"] == CONFIGURE}
        # nginx keeps its own adapter; every other configure service has a pack.
        self.assertEqual(sorted(configure - {"nginx"}), pack_ids())

    def test_a_pack_writes_a_drop_in_not_the_operators_main_file(self):
        meta = self.metadata("openssh-server", {"allow_groups": ["blue"]})
        paths = [row["path"] for row in meta["files"]]
        self.assertEqual(paths, ["/etc/ssh/sshd_config.d/60-sentinel.conf"])
        self.assertNotIn("/etc/ssh/sshd_config", paths)

    def test_a_pack_carries_the_products_own_configuration_test(self):
        check, apply, _rollback = build("samba", {
            "share": "scored", "path": "/srv/scored", "valid_users": ["blue"]}, self.root)
        self.assertIn("testparm", apply)

    def test_a_pack_reports_the_data_it_will_not_touch(self):
        meta = self.metadata("mariadb", {"bind_address": "127.0.0.1"})
        self.assertIn("/var/lib/mysql", meta["data_preserved"])

    def test_a_pack_reports_that_it_is_not_native_tested(self):
        self.assertIs(self.metadata("chrony", {"sources": ["time.range.test"]})["native_tested"],
                      False)

    def test_generated_files_are_marked_as_sentinel_owned(self):
        for service_id, options in (("unbound", {}), ("rsyslog", {"forward_to": "10.0.0.9"}),
                                    ("haproxy", {"backends": [{"address": "10.0.0.5",
                                                               "port": 8080}]})):
            with self.subTest(service_id=service_id):
                meta = self.metadata(service_id, options)
                self.assertTrue(meta["files"])

    def test_secret_bearing_configuration_is_not_world_readable(self):
        meta = self.metadata("openssh-server", {"allow_users": ["blue"]})
        self.assertEqual(meta["files"][0]["mode"], "0640")

    def test_the_recipe_compiles_through_the_ordinary_path(self):
        check, apply, rollback = compile_recipe(
            "linux-service-pack",
            {"catalog_id": "unbound", "interface": "127.0.0.1"}, self.root, "linux")
        self.assertTrue(check and apply)
        # Like every linux-service task, a pack carries its restore path inside
        # its own apply script rather than as a separate rollback script.
        self.assertIsNone(rollback)
        self.assertIn("sb_restore", apply)
        self.assertIn("linux-service-pack", RECIPES)

    def test_a_pack_is_refused_on_a_non_linux_host(self):
        with self.assertRaises(ValueError):
            compile_recipe("linux-service-pack", {"catalog_id": "unbound"},
                           self.root, "windows")

    def test_a_pack_must_name_its_catalog_service(self):
        with self.assertRaises(ValueError):
            compile_recipe("linux-service-pack", {"interface": "127.0.0.1"}, self.root, "linux")

    def test_a_pack_earns_the_same_durable_ownership_contract(self):
        from sentinel_blue.setup_transactions import commands
        options = {"catalog_id": "samba", "share": "scored", "path": "/srv/scored",
                   "valid_users": ["blue"]}
        _check, apply, _rollback = compile_recipe("linux-service-pack", options,
                                                  self.root, "linux")
        self.assertIsNotNone(commands("linux-service-pack", options, self.root, apply,
                                      context={"task_id": "t1"}))

    def test_whole_file_packs_are_the_declared_exception(self):
        # Growing this set silently would mean quietly replacing more operator
        # configuration, so it is asserted rather than assumed.
        self.assertEqual(WHOLE_FILE_PACKS, {"vsftpd"})


class HostPresenceTests(unittest.TestCase):
    def telemetry(self, services):
        return {"services": [{"name": name, "state": state} for name, state in services]}

    def test_a_running_unit_is_reported_running(self):
        presence = catalog_presence(self.telemetry([("nginx.service", "running")]))
        self.assertEqual(presence["nginx"], "running")

    def test_an_installed_but_stopped_unit_is_distinguished_from_absent(self):
        presence = catalog_presence(self.telemetry([("named.service", "inactive")]))
        self.assertEqual(presence["bind9"], "installed")
        self.assertEqual(presence["postfix"], "absent")

    def test_no_inventory_is_unknown_not_absent(self):
        # Installing over an unknown state is how existing configuration is lost.
        self.assertEqual(catalog_presence({}), {})
        self.assertEqual(installed_state("nginx", {})["state"], "unknown")

    def test_presence_is_bounded_to_the_catalog(self):
        presence = catalog_presence(self.telemetry(
            [(f"unrelated-{index}.service", "running") for index in range(500)]))
        self.assertEqual(set(presence), set(CATALOG))

    def test_malformed_service_rows_never_raise(self):
        for value in ({"services": "unavailable"}, {"services": [None, 7]}, {}):
            with self.subTest(value=value):
                self.assertIsInstance(host_units(value), dict)


class SelectionTests(unittest.TestCase):
    def test_a_clean_selection_is_ready(self):
        report = selection_report(["nginx", "mariadb"])
        self.assertTrue(report["ready"])
        self.assertEqual(report["blocking"], [])

    def test_conflicting_choices_block_the_plan(self):
        report = selection_report(["bind9", "dnsmasq"])
        self.assertFalse(report["ready"])
        self.assertTrue(any("cannot both own" in item for item in report["blocking"]))

    def test_a_missing_dependency_blocks_the_plan(self):
        report = selection_report(["dovecot"])
        self.assertTrue(any("depends on" in item for item in report["blocking"]))

    def test_an_unknown_service_blocks_the_plan(self):
        self.assertTrue(any("not in the catalog" in item
                            for item in selection_report(["nope"])["blocking"]))

    def test_adoption_only_choices_are_warned_about_not_hidden(self):
        report = selection_report(["docker"])
        self.assertTrue(report["ready"])
        self.assertTrue(any("no configuration is generated" in item
                            for item in report["warnings"]))

    def test_preserved_data_is_always_stated(self):
        report = selection_report(["mariadb"])
        self.assertIn("/var/lib/mysql", report["data_preserved"])

    def test_required_scoring_clients_are_listed(self):
        self.assertIn("mysql", selection_report(["mariadb"])["clients_required"])

    def test_a_manager_without_a_reviewed_package_name_blocks(self):
        report = selection_report(["gunicorn"], manager="apt")
        self.assertTrue(report["ready"], "gunicorn declares no packages at all")
        report = selection_report(["nginx"], manager="apt")
        self.assertEqual(report["packages"]["nginx"], ["nginx"])

    def test_the_summary_never_claims_tested_support(self):
        line = summary_line(selection_report(["nginx"]))
        self.assertIn("none native-tested", line)
        self.assertNotIn("supported", line)

    def test_an_empty_selection_says_so(self):
        self.assertEqual(summary_line(selection_report([])), "No services selected.")

    def test_display_rows_never_use_the_word_supported(self):
        for row in display_rows():
            with self.subTest(service_id=row["id"]):
                self.assertNotIn("supported", row["capability_label"].casefold())
                self.assertEqual(row["tested"], "not native-tested")


class ServicePlanTests(unittest.TestCase):
    def test_a_selection_becomes_ordinary_reviewable_tasks(self):
        plan = service_plan(["nginx", "mariadb"], "agent-one")
        self.assertEqual({task["host"] for task in plan["tasks"]}, {"agent-one"})
        self.assertEqual(sorted(task["service_id"] for task in plan["tasks"]),
                         ["mariadb", "nginx"])

    def test_dependencies_become_task_ordering(self):
        plan = service_plan(["dovecot", "postfix"], "agent-one")
        dovecot = next(task for task in plan["tasks"] if task["id"] == "sentinel-dovecot")
        self.assertIn("sentinel-postfix", dovecot["requires"])

    def test_a_service_without_supplied_options_is_adopted_not_configured(self):
        # Selecting a service does not by itself authorize writing its config.
        plan = service_plan(["mariadb"], "agent-one")
        self.assertEqual(plan["tasks"][0]["recipe"], "linux-service")

    def test_supplied_options_produce_a_configuration_pack(self):
        plan = service_plan(["mariadb"], "agent-one",
                            options={"mariadb": {"bind_address": "127.0.0.1"}})
        task = plan["tasks"][0]
        self.assertEqual(task["recipe"], "linux-service-pack")
        self.assertEqual(task["options"]["catalog_id"], "mariadb")

    def test_a_blocked_selection_never_becomes_a_plan(self):
        with self.assertRaises(ValueError):
            service_plan(["bind9", "dnsmasq"], "agent-one")
        with self.assertRaises(ValueError):
            service_plan([], "agent-one")

    def test_the_plan_carries_the_untested_statement_for_the_reviewer(self):
        notes = service_plan(["nginx"], "agent-one")["review_notes"]
        self.assertIs(notes["native_tested"], False)
        self.assertIn("not support", notes["statement"])

    def test_the_plan_is_data_not_execution(self):
        # A plan fragment must contain no commands; the engine compiles those
        # only after review and approval.
        text = json.dumps(service_plan(["nginx"], "agent-one"))
        for marker in ("systemctl", "apt-get", "#!/bin", "set -eu"):
            with self.subTest(marker=marker):
                self.assertNotIn(marker, text)


class PanelContractTests(unittest.TestCase):
    """The chooser must not become a second execution path."""

    def test_the_panel_offers_no_apply(self):
        actions = {name for name in dir(ServiceSelectionPanel) if not name.startswith("_")}
        for forbidden in ("apply", "execute", "run", "install", "start"):
            with self.subTest(forbidden=forbidden):
                self.assertNotIn(forbidden, actions)
        # 2.0.3: the custom-service form edits the selection like toggle() does.
        self.assertEqual(actions, {"COLUMNS", "clear", "observe", "refresh", "report", "toggle",
                                   "add_custom", "edit_custom", "save_custom", "remove_custom"})


if __name__ == "__main__":
    unittest.main()


class _Recorder:
    """A stand-in Tk widget that accepts the real construction calls.

    The desktop bugs worth catching here are ordering ones — a widget built
    before the attribute it reads — and those reproduce without a display.
    """

    def __init__(self, *args, **kwargs):
        self.kwargs = kwargs
        self.children = []
        self.rows = {}
        self.text = ""
        self._selection = ()
        self.bindings = {}

    def __call__(self, *args, **kwargs):
        child = _Recorder(*args, **kwargs)
        self.children.append(child)
        return child

    def pack(self, **_kwargs):
        return None

    def heading(self, *_args, **_kwargs):
        return None

    def column(self, *_args, **_kwargs):
        return None

    def bind(self, sequence, handler):
        self.bindings[sequence] = handler

    def insert(self, *args, iid=None, values=None, **_kwargs):
        # Text.insert(index, text) and Treeview.insert(parent, index, iid=, values=)
        # share a name; the stub tells them apart the way Tk does, by shape.
        if iid is None and values is None:
            self.text += str(args[-1])
        else:
            self.rows[iid] = values

    def delete(self, *identities):
        if identities and identities[0] == "1.0":
            self.text = ""
        else:
            for identity in identities:
                self.rows.pop(identity, None)

    def get_children(self):
        return tuple(self.rows)

    def exists(self, identity):
        return identity in self.rows

    def selection(self):
        return self._selection

    def selection_set(self, identity):
        self._selection = (identity,)

    def configure(self, **_kwargs):
        return None

    def see(self, *_args):
        return None

    def xview(self, *_args):
        return None

    def yview(self, *_args):
        return None

    def set(self, *_args):
        return None

    def winfo_exists(self):
        return True


class _Variable:
    def __init__(self, value=""):
        self._value = value

    def get(self):
        return self._value

    def set(self, value):
        self._value = value


class _Tk:
    StringVar = _Variable
    BooleanVar = _Variable
    Text = _Recorder


class _Ttk:
    Frame = _Recorder
    Label = _Recorder
    Button = _Recorder
    Combobox = _Recorder
    Treeview = _Recorder
    Labelframe = _Recorder
    Scrollbar = _Recorder


class PanelBehaviourTests(unittest.TestCase):
    """The panel's own code path, without a display."""

    def panel(self):
        return ServiceSelectionPanel(_Recorder(), (_Tk, _Ttk))

    def test_the_panel_builds_and_lists_every_service(self):
        panel = self.panel()
        self.assertEqual(set(panel.tree.rows), set(CATALOG))

    def test_selecting_a_service_marks_it_and_updates_the_summary(self):
        panel = self.panel()
        panel.tree.selection_set("nginx")
        panel.toggle()
        self.assertEqual(panel.selection, ["nginx"])
        self.assertEqual(panel.tree.rows["nginx"][0], "yes")
        self.assertIn("1 selected", panel.summary.get())

    def test_selecting_twice_deselects(self):
        panel = self.panel()
        panel.tree.selection_set("nginx")
        panel.toggle()
        panel.toggle()
        self.assertEqual(panel.selection, [])

    def test_a_conflicting_pair_is_shown_as_blocking(self):
        panel = self.panel()
        for service_id in ("bind9", "dnsmasq"):
            panel.tree.selection_set(service_id)
            panel.toggle()
        self.assertIn("blocking", panel.summary.get())
        self.assertIn("BLOCKING", panel.detail.text)

    def test_filtering_by_family_narrows_the_list(self):
        panel = self.panel()
        panel.family.set("dns")
        panel.refresh()
        self.assertEqual(set(panel.tree.rows), {"bind9", "unbound", "dnsmasq"})

    def test_a_filtered_out_selection_is_not_lost(self):
        panel = self.panel()
        panel.tree.selection_set("nginx")
        panel.toggle()
        panel.family.set("dns")
        panel.refresh()
        self.assertEqual(panel.selection, ["nginx"])

    def test_observing_a_host_updates_what_is_installed(self):
        panel = self.panel()
        panel.observe({"nginx": "running"})
        self.assertEqual(panel.tree.rows["nginx"][4], "running")

    def test_clearing_removes_every_selection(self):
        panel = self.panel()
        panel.tree.selection_set("nginx")
        panel.toggle()
        panel.clear()
        self.assertEqual(panel.selection, [])
        self.assertIn("No services selected", panel.summary.get())

    def test_the_panel_never_says_supported(self):
        panel = self.panel()
        panel.tree.selection_set("mariadb")
        panel.toggle()
        self.assertNotIn("supported", (panel.summary.get() + panel.detail.text).casefold())

    def test_toggling_with_no_row_selected_is_harmless(self):
        panel = self.panel()
        self.assertEqual(panel.toggle(), "break")
        self.assertEqual(panel.selection, [])
