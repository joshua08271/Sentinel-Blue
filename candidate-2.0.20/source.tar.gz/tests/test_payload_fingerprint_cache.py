"""The payload fingerprint cache must save work without weakening detection.

Issue #22: re-reading every running executable on every collection dominated
collection time, and a slow collection delays recovery.
"""
import hashlib
import os
import shutil
import tempfile
import time
import unittest
from pathlib import Path

from sentinel_blue import payload_inventory
from sentinel_blue.payload_inventory import (
    FINGERPRINTS, fingerprint_references, linux_process_payloads)
from sentinel_blue.restoration import RestorePointStore


@unittest.skipIf(os.name == 'nt', 'POSIX payload fingerprint path')
class PayloadFingerprintCacheTests(unittest.TestCase):
    def setUp(self):
        FINGERPRINTS.reset()
        self.addCleanup(FINGERPRINTS.reset)
        self.directory = tempfile.mkdtemp(prefix='sentinel-fingerprint-')
        self.addCleanup(shutil.rmtree, self.directory, True)
        os.chmod(self.directory, 0o755)
        self.target = Path(self.directory) / 'service'
        self.target.write_bytes(b'original payload')

    def fingerprint(self):
        errors = []
        items = fingerprint_references([str(self.target)], errors, kind='process-payload')
        self.assertEqual(errors, [])
        self.assertEqual(len(items), 1)
        return items[0].sha256

    def test_unchanged_file_is_not_read_again(self):
        first = self.fingerprint()
        self.assertEqual(first, hashlib.sha256(b'original payload').hexdigest())
        self.assertEqual((FINGERPRINTS.hits, FINGERPRINTS.misses), (0, 1))
        self.assertEqual(self.fingerprint(), first)
        self.assertEqual((FINGERPRINTS.hits, FINGERPRINTS.misses), (1, 1))

    def test_rewritten_content_is_detected(self):
        first = self.fingerprint()
        self.target.write_bytes(b'tampered payload')
        second = self.fingerprint()
        self.assertNotEqual(second, first)
        self.assertEqual(second, hashlib.sha256(b'tampered payload').hexdigest())

    def test_same_size_rewrite_with_restored_modification_time_is_detected(self):
        # The classic evasion: overwrite in place, then put the timestamps back.
        original = self.target.stat()
        first = self.fingerprint()
        self.target.write_bytes(b'0riginal payl0ad')  # identical length
        os.utime(self.target, ns=(original.st_atime_ns, original.st_mtime_ns))
        self.assertEqual(self.target.stat().st_size, original.st_size)
        self.assertEqual(self.target.stat().st_mtime_ns, original.st_mtime_ns)
        second = self.fingerprint()
        self.assertNotEqual(second, first, 'an in-place rewrite must not reuse a cached fingerprint')
        self.assertEqual(second, hashlib.sha256(b'0riginal payl0ad').hexdigest())

    def test_replacement_by_rename_is_detected(self):
        first = self.fingerprint()
        replacement = Path(self.directory) / 'replacement'
        replacement.write_bytes(b'replaced payload')
        os.replace(replacement, self.target)
        self.assertNotEqual(self.fingerprint(), first)

    def test_permission_or_owner_change_invalidates_the_entry(self):
        self.fingerprint()
        hits = FINGERPRINTS.hits
        os.chmod(self.target, 0o700)
        self.fingerprint()
        self.assertEqual(FINGERPRINTS.hits, hits, 'a metadata change must miss the cache')

    def test_entries_are_revalidated_on_a_rotating_schedule(self):
        self.fingerprint()
        with FINGERPRINTS._lock:
            entry = FINGERPRINTS._entries[str(self.target)]
            entry['verified_at'] = time.time() - payload_inventory.FINGERPRINT_REVALIDATE_SECONDS - 1
            stale_identity = entry['identity']
        self.fingerprint()
        self.assertEqual(FINGERPRINTS.revalidations, 1)
        with FINGERPRINTS._lock:
            refreshed = FINGERPRINTS._entries[str(self.target)]
        self.assertEqual(refreshed['identity'], stale_identity)
        self.assertGreater(refreshed['verified_at'], time.time() - 60)

    def test_expired_entries_beyond_the_per_pass_budget_keep_their_value(self):
        paths = []
        for index in range(payload_inventory.FINGERPRINT_REVALIDATIONS_PER_PASS + 3):
            path = Path(self.directory) / f'program{index}'
            path.write_bytes(f'payload {index}'.encode())
            paths.append(str(path))
        errors = []
        fingerprint_references(paths, errors, kind='process-payload')
        self.assertEqual(errors, [])
        with FINGERPRINTS._lock:
            for entry in FINGERPRINTS._entries.values():
                entry['verified_at'] = time.time() - payload_inventory.FINGERPRINT_REVALIDATE_SECONDS - 1
        items = fingerprint_references(paths, errors, kind='process-payload')
        self.assertEqual(len(items), len(paths), 'every file still reports a fingerprint')
        self.assertEqual(FINGERPRINTS.revalidations, payload_inventory.FINGERPRINT_REVALIDATIONS_PER_PASS)

    def test_backwards_clock_does_not_park_an_entry(self):
        self.fingerprint()
        with FINGERPRINTS._lock:
            FINGERPRINTS._entries[str(self.target)]['verified_at'] = time.time() + 86_400
        self.fingerprint()
        self.assertEqual(FINGERPRINTS.revalidations, 1)

    def test_cache_is_bounded(self):
        limit = payload_inventory.MAX_CACHED_FINGERPRINTS
        with FINGERPRINTS._lock:
            for index in range(limit + 25):
                FINGERPRINTS._entries[f'/synthetic/{index}'] = {
                    'identity': (index,), 'fingerprint': 'a' * 64, 'verified_at': time.time()}
            while len(FINGERPRINTS._entries) > limit:
                FINGERPRINTS._entries.pop(next(iter(FINGERPRINTS._entries)))
        FINGERPRINTS.store('/synthetic/new', (1,), 'b' * 64, time.time())
        with FINGERPRINTS._lock:
            self.assertLessEqual(len(FINGERPRINTS._entries), limit)
            self.assertIn('/synthetic/new', FINGERPRINTS._entries)

    def test_symlinks_are_never_cached_or_fingerprinted(self):
        link = Path(self.directory) / 'link'
        link.symlink_to(self.target)
        errors = []
        items = fingerprint_references([str(link)], errors, kind='process-payload')
        self.assertEqual(items, [])
        with FINGERPRINTS._lock:
            self.assertNotIn(str(link), FINGERPRINTS._entries)

    def test_restoration_reads_never_use_the_cache(self):
        self.fingerprint()
        self.target.write_bytes(b'freshly written bytes')
        data, _metadata = RestorePointStore._read_target(self.target, maximum=4096)
        self.assertEqual(data, b'freshly written bytes')

    def test_cached_entries_still_report_the_owner(self):
        first_items = fingerprint_references([str(self.target)], [], kind='process-payload')
        second_items = fingerprint_references([str(self.target)], [], kind='process-payload')
        self.assertEqual(second_items[0].owner, first_items[0].owner)
        self.assertEqual(second_items[0].owner, str(os.stat(self.target).st_uid))

    def test_a_cache_hit_does_not_consume_the_read_budget(self):
        payload = os.urandom(1024) * 64  # 64 KiB
        self.target.write_bytes(payload)
        errors = []
        fingerprint_references([str(self.target)], errors, kind='process-payload')
        started = time.monotonic()
        items = fingerprint_references([str(self.target)], errors, kind='process-payload')
        self.assertLess(time.monotonic() - started, 0.05)
        self.assertEqual(items[0].sha256, hashlib.sha256(payload).hexdigest())
        self.assertEqual(errors, [])


@unittest.skipIf(os.name == 'nt', 'Linux /proc payload inventory')
class ReplacedRunningExecutableTests(unittest.TestCase):
    """A swapped service binary leaves the process on the old unlinked inode."""

    def setUp(self):
        FINGERPRINTS.reset()
        self.addCleanup(FINGERPRINTS.reset)
        self.directory = tempfile.mkdtemp(prefix='/tmp/sentinel-replaced-')
        self.addCleanup(shutil.rmtree, self.directory, True)
        os.chmod(self.directory, 0o755)
        self.proc = Path(tempfile.mkdtemp(prefix='sentinel-proc-'))
        self.addCleanup(shutil.rmtree, self.proc, True)

    def _process(self, exe_target, pid='4242'):
        entry = self.proc / pid
        entry.mkdir()
        os.symlink(exe_target, entry / 'exe')
        (entry / 'cmdline').write_bytes(b'')
        return entry

    def test_replacement_at_the_path_is_still_fingerprinted(self):
        executable = Path(self.directory) / 'scored-service'
        executable.write_bytes(b'replacement bytes')
        self._process(f'{executable} (deleted)')
        errors = []
        items = linux_process_payloads(errors, proc_root=self.proc)
        self.assertTrue(any('unlinked' in str(error) for error in errors),
                        'the missing running image must still be reported')
        fingerprints = {item.name: item.sha256 for item in items}
        self.assertEqual(fingerprints.get(str(executable)),
                         hashlib.sha256(b'replacement bytes').hexdigest())

    def test_missing_path_reports_only_the_coverage_gap(self):
        self._process(f'{self.directory}/never-existed (deleted)')
        errors = []
        items = linux_process_payloads(errors, proc_root=self.proc)
        self.assertTrue(any('unlinked' in str(error) for error in errors))
        self.assertEqual(items, [])

    def test_a_directory_at_that_path_is_not_fingerprinted(self):
        replaced = Path(self.directory) / 'as-directory'
        replaced.mkdir()
        self._process(f'{replaced} (deleted)')
        errors = []
        items = linux_process_payloads(errors, proc_root=self.proc)
        self.assertEqual(items, [])


class CollectionPressureSignalTests(unittest.TestCase):
    """Issue #22: the cost of collection must be visible before it blocks recovery."""

    BASE = {'agent_id': 'agent-a', 'platform': 'linux', 'accounts': [], 'services': [],
            'probes': [], 'integrity': []}

    def _pressure(self, seconds):
        from sentinel_blue.detection import detect
        telemetry = dict(self.BASE)
        if seconds is not None:
            telemetry['collection_seconds'] = seconds
        return [c for c in detect(telemetry, None, set()) if c.kind == 'collection_pressure']

    def test_a_fast_collection_raises_nothing(self):
        self.assertEqual(self._pressure(1.5), [])

    def test_slower_than_the_interval_is_reported(self):
        from sentinel_blue.detection import COLLECTION_PRESSURE_SECONDS
        alerts = self._pressure(COLLECTION_PRESSURE_SECONDS + 1)
        self.assertEqual(len(alerts), 1)
        self.assertEqual(alerts[0].severity, 'medium')
        self.assertIn('collection_seconds', alerts[0].evidence)

    def test_approaching_the_freshness_window_is_high_severity(self):
        from sentinel_blue.detection import COLLECTION_PRESSURE_CRITICAL_SECONDS
        alerts = self._pressure(COLLECTION_PRESSURE_CRITICAL_SECONDS + 1)
        self.assertEqual(alerts[0].severity, 'high')
        self.assertIn('stale evidence', alerts[0].summary)

    def test_an_older_agent_without_the_field_is_unaffected(self):
        self.assertEqual(self._pressure(None), [])

    def test_a_malformed_value_is_ignored(self):
        for value in ('slow', None, [], {}):
            with self.subTest(value=value):
                telemetry = {**self.BASE, 'collection_seconds': value}
                from sentinel_blue.detection import detect
                self.assertEqual([c for c in detect(telemetry, None, set())
                                  if c.kind == 'collection_pressure'], [])

    def test_the_collector_reports_its_own_cost(self):
        from sentinel_blue import collectors
        from sentinel_blue.validation import validate_telemetry
        telemetry = collectors.collect('pressure-test', authorized_networks=['127.0.0.0/8'],
                                       authorized_hosts=['127.0.0.1'], excluded_hosts=[],
                                       integrity_paths=[]).as_dict()
        self.assertIsInstance(telemetry['collection_seconds'], float)
        self.assertGreater(telemetry['collection_seconds'], 0)
        self.assertEqual(validate_telemetry(telemetry)['collection_seconds'],
                         telemetry['collection_seconds'])

    def test_validation_tolerates_a_bad_value_without_dropping_the_sample(self):
        from sentinel_blue.validation import validate_telemetry
        telemetry = {'agent_id': 'agent-a', 'hostname': 'h', 'platform': 'linux',
                     'observed_at': time.time(), 'collection_seconds': 'not-a-number'}
        self.assertEqual(validate_telemetry(telemetry)['collection_seconds'], 0.0)


if __name__ == '__main__':
    unittest.main()
