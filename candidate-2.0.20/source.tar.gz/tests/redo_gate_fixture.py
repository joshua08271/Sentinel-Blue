"""Local authenticated test controller; no native service actions are executed."""
import copy
import threading
import time
from sentinel_blue.controller import ControllerApp, ControllerServer, make_handler
from sentinel_blue.desktop_control import DesktopClient
from sentinel_blue.store import Store


def live_client(test, profile, baseline=None):
    store = Store(':memory:')
    test.addCleanup(store.close)
    app = ControllerApp(store, 't'*32, operator_token='o'*48, event_profile=profile,
                        auto_recover_services=True)
    app.set_autonomy_mode('guarded-autonomous')
    if baseline is not None:
        app.ingest(copy.deepcopy(baseline))
    else:
        for host in {s['host'] for s in profile.services}:
            app.ingest({'agent_id': host, 'hostname': host, 'platform': 'Linux', 'observed_at': time.time(),
                        'boot_id':'fixture', 'sequence':1, 'agent_version':profile.release['version'],
                        'profile_id':profile.profile_id, 'profile_fingerprint':profile.fingerprint,
                        'services':[{'name':s['service_id'],'state':'running'} for s in profile.services if s['host']==host]})
    server = ControllerServer(('127.0.0.1',0), make_handler(app))
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    test.addCleanup(server.server_close)
    test.addCleanup(server.shutdown)
    return app, store, DesktopClient(f'http://127.0.0.1:{server.server_port}', 'operator',1,'o'*48)
