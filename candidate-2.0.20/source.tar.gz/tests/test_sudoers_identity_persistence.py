"""Sudoers privilege persistence: detection and bounded revocation (issue #15, Linux).

A drop-in such as /etc/sudoers.d/99-backdoor granting NOPASSWD is privilege
persistence. Drop-ins were in neither the startup inventory nor the default
protected paths, and a grant inside a shared sudoers file could not be revoked
without removing the whole file.
"""
import hashlib
import os
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from sentinel_blue import persistence_security
from sentinel_blue.collectors import _integrity_paths, _linux_persistence
from sentinel_blue.persistence_security import (
    PersistenceRemediator, fingerprint, revoke_sudoers_lines, sudoers_entries, validate_target)


POLICY = (b"# team policy\n"
          b"Defaults\tenv_reset\n"
          b"User_Alias OPERATORS = blue, green\n"
          b"%sudo\tALL=(ALL:ALL) ALL\n"
          b"blue ALL=(ALL) ALL\n"
          b"attacker ALL=(ALL) NOPASSWD:ALL\n"
          b"@includedir /etc/sudoers.d\n")
MALICIOUS = b"attacker ALL=(ALL) NOPASSWD:ALL"
ADMIN_GRANT = b"%sudo\tALL=(ALL:ALL) ALL"


def digest(line):
    return hashlib.sha256(line).hexdigest()


class SudoersParsingTests(unittest.TestCase):
    def test_only_privilege_grants_are_entries(self):
        entries = sudoers_entries(POLICY)
        principals = [entry['principal'] for entry in entries]
        self.assertEqual(principals, ['%sudo', 'blue', 'attacker'])

    def test_structure_lines_are_never_entries(self):
        for line in (b'Defaults env_reset\n', b'User_Alias OPERATORS = blue\n',
                     b'@includedir /etc/sudoers.d\n', b'#include /etc/sudoers.local\n',
                     b'# attacker ALL=(ALL) NOPASSWD:ALL\n', b'\n'):
            with self.subTest(line=line):
                self.assertEqual(sudoers_entries(line), [])

    def test_administrator_grants_are_flagged(self):
        flags = {entry['principal']: entry['administrator_grant'] for entry in sudoers_entries(POLICY)}
        self.assertTrue(flags['%sudo'])
        self.assertFalse(flags['attacker'])
        self.assertFalse(flags['blue'])

    def test_revocation_keeps_the_rest_of_the_policy(self):
        after, removed = revoke_sudoers_lines(POLICY, digest(MALICIOUS))
        self.assertEqual(removed, 1)
        self.assertNotIn(b'attacker', after)
        self.assertIn(b'%sudo\tALL=(ALL:ALL) ALL', after)
        self.assertIn(b'blue ALL=(ALL) ALL', after)
        self.assertIn(b'Defaults\tenv_reset', after)
        self.assertIn(b'@includedir /etc/sudoers.d', after)
        self.assertEqual(after, POLICY.replace(MALICIOUS + b'\n', b''))

    def test_administrator_access_is_held_not_revoked(self):
        for line in (ADMIN_GRANT, b'root ALL=(ALL) ALL', b'%wheel ALL=(ALL) ALL',
                     b'%admin ALL=(ALL) ALL', b'ALL ALL=(ALL) ALL'):
            with self.subTest(line=line):
                data = POLICY + line + b'\n'
                with self.assertRaises(ValueError) as error:
                    revoke_sudoers_lines(data, digest(line))
                self.assertIn('held for human review', str(error.exception))
                self.assertIn(line, data)

    def test_absent_grant_refuses(self):
        with self.assertRaises(ValueError):
            revoke_sudoers_lines(POLICY, 'b' * 64)


class SudoersTargetValidationTests(unittest.TestCase):
    def target(self, path, entry=None):
        return {'kind': 'sudoers-entry', 'path': path,
                'entry_sha256': digest(MALICIOUS) if entry is None else entry}

    def test_reviewed_locations_are_accepted(self):
        for path in ('/etc/sudoers', '/etc/sudoers.d/99-backdoor'):
            with self.subTest(path=path):
                self.assertEqual(validate_target(self.target(path))['path'], path)

    def test_other_paths_are_refused(self):
        for path in ('/etc/passwd', '/etc/shadow', '/etc/crontab', '/etc/sudoers.d/../passwd',
                     '/home/blue/sudoers', 'etc/sudoers'):
            with self.subTest(path=path), self.assertRaises(ValueError):
                validate_target(self.target(path))

    def test_malformed_digests_are_refused(self):
        for entry in ('', 'abc', 'z' * 64):
            with self.subTest(entry=entry), self.assertRaises(ValueError):
                validate_target(self.target('/etc/sudoers', entry))


@unittest.skipIf(os.name == 'nt', 'POSIX sudoers')
class SudoersDetectionTests(unittest.TestCase):
    def setUp(self):
        self.directory = Path(tempfile.mkdtemp(prefix='sentinel-sudoers-'))
        self.addCleanup(shutil.rmtree, self.directory, True)
        os.chmod(self.directory, 0o755)
        (self.directory / '99-backdoor').write_bytes(MALICIOUS + b'\n')

    def test_drop_ins_reach_the_startup_inventory(self):
        with patch('sentinel_blue.collectors.Path', Path):
            errors = []
            items = _linux_persistence(errors)
        kinds = {item.kind for item in items if '/etc/sudoers.d/' in item.name}
        if kinds:  # Only when the host has drop-ins; the mapping is what matters.
            self.assertEqual(kinds, {'sudoers'})

    def test_drop_ins_are_default_protected_paths(self):
        paths = [str(path) for path in _integrity_paths('linux')]
        self.assertIn('/etc/sudoers', paths)
        if Path('/etc/sudoers.d').is_dir():
            for child in Path('/etc/sudoers.d').iterdir():
                if child.is_file():
                    self.assertIn(str(child), paths)


@unittest.skipIf(os.name == 'nt', 'POSIX sudoers')
class SudoersRemediationTests(unittest.TestCase):
    def setUp(self):
        self.state = Path(tempfile.mkdtemp(prefix='sentinel-sudoers-state-'))
        self.addCleanup(shutil.rmtree, self.state, True)
        os.chmod(self.state, 0o700)
        self.host = Path(tempfile.mkdtemp(prefix='sentinel-sudoers-host-'))
        self.addCleanup(shutil.rmtree, self.host, True)
        self.policy = self.host / 'sudoers'
        self.policy.write_bytes(POLICY)
        os.chmod(self.policy, 0o440)
        self.remediator = PersistenceRemediator(self.state, native=object())
        self.addCleanup(self.remediator.close)
        patched = patch.object(persistence_security, 'SUDOERS_ENTRY_FILES',
                               (*persistence_security.SUDOERS_ENTRY_FILES, str(self.policy)))
        patched.start()
        self.addCleanup(patched.stop)
        self.target = {'kind': 'sudoers-entry', 'path': str(self.policy),
                       'entry_sha256': digest(MALICIOUS)}

    def test_remove_then_restore_round_trips(self):
        snapshot = self.remediator.snapshot(self.target)
        result = self.remediator.remove(self.target, fingerprint(snapshot), operation_id='sudo-op-0001')
        self.assertEqual(result['status'], 'quarantined')
        current = self.policy.read_bytes()
        self.assertNotIn(b'attacker', current)
        self.assertIn(b'%sudo', current)
        self.assertEqual(os.stat(self.policy).st_mode & 0o777, 0o440)
        self.assertEqual(self.remediator.restore('sudo-op-0001')['status'], 'restored')
        self.assertEqual(self.policy.read_bytes(), POLICY)

    def test_an_administrator_grant_is_refused_before_any_write(self):
        target = {**self.target, 'entry_sha256': digest(ADMIN_GRANT)}
        with self.assertRaises(ValueError):
            self.remediator.snapshot(target)
        self.assertEqual(self.policy.read_bytes(), POLICY)

    def test_policy_changed_after_review_refuses(self):
        snapshot = self.remediator.snapshot(self.target)
        review = fingerprint(snapshot)
        self.policy.write_bytes(POLICY + b'green ALL=(ALL) ALL\n')
        with self.assertRaises(ValueError):
            self.remediator.remove(self.target, review, operation_id='sudo-op-0002')
        self.assertIn(b'green ALL=(ALL) ALL', self.policy.read_bytes())


if __name__ == '__main__':
    unittest.main()
