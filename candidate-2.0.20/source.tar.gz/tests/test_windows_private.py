import base64
import os
from pathlib import Path
import struct
import subprocess
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from sentinel_blue.windows_private import (
    SYSTEM_SID, ADMINISTRATORS_SID, CREATOR_OWNER_SID, OWNER_RIGHTS_SID, validate_private_descriptor,
)

EVERYONE = bytes.fromhex('010100000000000100000000')


def descriptor(rules, *, owner=SYSTEM_SID, dacl=True):
    entries = b''
    for kind, flags, sid in rules:
        body = struct.pack('<I', 0x1f01ff) + sid
        entries += struct.pack('<BBH', kind, flags, len(body)+4) + body
    acl = struct.pack('<BBHHH', 2, 0, len(entries)+8, len(rules), 0) + entries
    header = struct.pack('<BBHIIII', 1, 0, 0x8004, 20, 0, 0, 20+len(owner) if dacl else 0)
    return base64.b64encode(header + owner + (acl if dacl else b'')).decode()


class WindowsPrivateTests(unittest.TestCase):
    def test_recovery_paths_reject_directory_reparse_metadata(self):
        from sentinel_blue.recovery import _reject_symlink_components
        import stat
        info = SimpleNamespace(st_mode=stat.S_IFDIR | 0o700, st_file_attributes=0x400)
        with patch('sentinel_blue.recovery.os.lstat', return_value=info):
            with self.assertRaises(ValueError):
                _reject_symlink_components(Path('/owned-fixture/recovery'))

    def test_known_private_owner_and_administrative_grants(self):
        validate_private_descriptor(descriptor([(0, 3, SYSTEM_SID), (0, 3, ADMINISTRATORS_SID)]), SYSTEM_SID)

    def test_python_private_directory_owner_rights_require_trusted_owner(self):
        rules=[(0,3,SYSTEM_SID),(0,3,ADMINISTRATORS_SID),(0,3,OWNER_RIGHTS_SID)]
        validate_private_descriptor(descriptor(rules),SYSTEM_SID)
        with self.assertRaisesRegex(ValueError,'untrusted owner'):
            validate_private_descriptor(descriptor(rules,owner=EVERYONE),SYSTEM_SID)
        with self.assertRaisesRegex(ValueError,'another identity'):
            validate_private_descriptor(descriptor(rules+[(0,0,EVERYONE)]),SYSTEM_SID)

    def test_public_grants_are_rejected_even_when_inherited_or_children_only(self):
        for flags in (0, 3, 8, 16):
            with self.subTest(flags=flags), self.assertRaisesRegex(ValueError, 'another identity'):
                validate_private_descriptor(descriptor([(0, flags, EVERYONE)]), SYSTEM_SID)

    def test_null_dacl_and_untrusted_owner_are_rejected(self):
        with self.assertRaisesRegex(ValueError, 'restrictive DACL'):
            validate_private_descriptor(descriptor([], dacl=False), SYSTEM_SID)
        with self.assertRaisesRegex(ValueError, 'untrusted owner'):
            validate_private_descriptor(descriptor([], owner=EVERYONE), SYSTEM_SID)

    def test_only_inherit_only_creator_owner_is_accepted(self):
        validate_private_descriptor(descriptor([(0, 11, CREATOR_OWNER_SID)]), SYSTEM_SID)
        with self.assertRaises(ValueError):
            validate_private_descriptor(descriptor([(0, 3, CREATOR_OWNER_SID)]), SYSTEM_SID)

    def test_unfamiliar_grant_semantics_hold(self):
        for kind in (5, 9, 11):
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                validate_private_descriptor(descriptor([(kind, 0, SYSTEM_SID)]), SYSTEM_SID)

    def test_denial_does_not_hide_later_public_allowance(self):
        with self.assertRaisesRegex(ValueError, 'another identity'):
            validate_private_descriptor(descriptor([(1, 0, EVERYONE), (0, 0, EVERYONE)]), SYSTEM_SID)

    @unittest.skipUnless(os.name == 'nt', 'requires native Windows ACLs')
    def test_native_public_key_file_rejected_inside_private_directory(self):
        from sentinel_blue.recovery import load_recovery_key
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            key=root/'owned-test.key'
            key.write_bytes(b'owned fixture key material only!'*2)
            self.assertEqual(load_recovery_key(key),key.read_bytes())
            result=subprocess.run(['icacls.exe',str(key),'/grant','*S-1-1-0:R'],
                                  capture_output=True,text=True,timeout=10)
            self.assertEqual(result.returncode,0,result.stderr)
            with self.assertRaisesRegex(ValueError,'another identity'):
                load_recovery_key(key)
        self.assertFalse(root.exists())

    @unittest.skipUnless(os.name == 'nt', 'requires native Windows ACLs')
    def test_native_private_and_public_directory_and_handle_cleanup(self):
        from sentinel_blue.recovery import _require_private_directory
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            _require_private_directory(root)
            result = subprocess.run(['icacls.exe', str(root), '/grant', '*S-1-1-0:(OI)(CI)R'],
                                    capture_output=True, text=True, timeout=10)
            self.assertEqual(result.returncode, 0, result.stderr)
            with self.assertRaisesRegex(ValueError, 'another identity'):
                _require_private_directory(root)
        self.assertFalse(root.exists())


if __name__ == '__main__':
    unittest.main()
