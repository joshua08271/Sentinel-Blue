"""Enrollment token consumption must remain reversible without claiming edits."""
import hashlib
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from sentinel_blue import mutation_tracking
from sentinel_blue.mutation_ledger import LedgerError, MutationLedger
from sentinel_blue.state import remove_private_file, write_private_json
from sentinel_blue.withdrawal import WithdrawalCoordinator, guest, inventory
from sentinel_blue.withdrawal_native import NativeObjects, object_target


class EnrollmentWithdrawalTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        env = patch.dict(os.environ, SENTINEL_LEDGER_DIR=str(self.root / 'ledger'))
        env.start()
        self.addCleanup(env.stop)
        enabled = patch.object(mutation_tracking, '_ENABLED', False)
        enabled.start()
        self.addCleanup(enabled.stop)
        mutation_tracking.enable()
        self.ledger = MutationLedger()
        self.native = NativeObjects(self.ledger)
        self.token = self.root / 'enrollment.json'
        self.package = self.root / 'sentinel.pyz'
        self.target = object_target(files=[str(self.token), str(self.package)])

    def install(self):
        def publish():
            write_private_json(self.token, {'one_time_ticket': 'disposable-fixture'})
            self.package.write_bytes(b'disposable application')
        mutation_tracking.mutation(self.target, publish, ownership='sentinel_artifact')

    def remove(self):
        coordinator = WithdrawalCoordinator({'local': {'platform': 'linux'}},
            lambda name, request: guest(request, self.ledger), self.root / 'report')
        review = coordinator.review('remove')
        return review, coordinator.execute(review, review['review_digest'])

    def test_consumed_enrollment_allows_remove_and_keeps_configuration(self):
        self.install()
        remove_private_file(self.token)
        legitimate = self.root / 'legitimate.conf'
        legitimate.write_text('original')
        mutation_tracking.mutation(object_target(files=[str(legitimate)]),
                                   lambda: legitimate.write_text('approved change'))
        review, result = self.remove()
        self.assertEqual(review['conflicts'], [])
        self.assertEqual(result['status'], 'complete', result['conflicts'])
        self.assertFalse(self.token.exists())
        self.assertFalse(self.package.exists())
        self.assertEqual(legitimate.read_text(), 'approved change')

    def test_unlink_has_durable_exact_pre_state_before_side_effect(self):
        self.install()
        exact = self.native.file(str(self.token))
        original_unlink = Path.unlink
        def inspect_unlink(path, *args, **kwargs):
            if path == self.token:
                reopened = MutationLedger()
                action = reopened.actions(include_states=True)[-1]
                self.assertEqual(action['status'], 'prepared')
                self.assertEqual(action['ownership'], 'sentinel_credential')
                self.assertEqual(action['before']['files'][str(path)], exact)
            return original_unlink(path, *args, **kwargs)
        with patch.object(Path, 'unlink', inspect_unlink):
            remove_private_file(self.token)
        actions = MutationLedger().actions(include_states=True)
        self.assertEqual(actions[-1]['status'], 'committed')
        self.assertIsNone(actions[-1]['after']['files'][str(self.token)])
        self.assertEqual(actions[-1]['dependencies'], [actions[0]['action_id']])

    def test_teammate_recreation_is_preserved_and_blocks_installation_removal(self):
        self.install()
        old = self.token.read_bytes()
        remove_private_file(self.token)
        self.token.write_bytes(old)
        review, result = self.remove()
        self.assertTrue(review['conflicts'])
        self.assertEqual(result['status'], 'partial')
        self.assertEqual(self.token.read_bytes(), old)
        self.assertTrue(self.package.exists())

    def test_deferred_publication_does_not_bypass_late_teammate_edit(self):
        self.install()
        remove_private_file(self.token)
        coordinator = WithdrawalCoordinator({'local': {'platform': 'linux'}},
            lambda name, request: guest(request, self.ledger), self.root / 'report')
        review = coordinator.review('remove')
        self.assertEqual(review['conflicts'], [])
        self.package.write_bytes(b'teammate version after inventory')
        with self.assertRaises(LedgerError):
            coordinator.execute(review, review['review_digest'])
        self.assertEqual(self.package.read_bytes(), b'teammate version after inventory')

    def test_pause_blocks_token_consumption(self):
        self.install()
        before = self.token.read_bytes()
        self.ledger.pause('test-pause')
        with self.assertRaises(LedgerError):
            remove_private_file(self.token)
        self.assertEqual(self.token.read_bytes(), before)

    def test_failed_admission_does_not_consume_token(self):
        self.install()
        before = self.token.read_bytes()
        append = MutationLedger.append
        def fail_prepare(ledger, kind, **fields):
            if kind == 'prepared':
                raise OSError('fixture disk-full admission failure')
            return append(ledger, kind, **fields)
        with patch.object(MutationLedger, 'append', fail_prepare):
            with self.assertRaises(OSError):
                remove_private_file(self.token)
        self.assertEqual(self.token.read_bytes(), before)

    def test_interrupted_unlink_requires_reconciliation(self):
        self.install()
        with patch('sentinel_blue.state._fsync_directory', side_effect=OSError('fixture flush failure')):
            with self.assertRaises(OSError):
                remove_private_file(self.token)
        reopened = MutationLedger()
        self.assertEqual(reopened.actions()[-1]['status'], 'uncertain')
        self.assertFalse(reopened.pause('test-recovery')['drained'])
        self.assertIn('conflict', inventory(reopened)['actions'][-1])

    def test_remote_installation_covers_consumption_without_overlapping_claim(self):
        guest({'operation': 'install-begin', 'action_id': 'remote-install', 'target': self.target,
               'expected_files': {str(self.token): None,
                                  str(self.package): hashlib.sha256(b'application').hexdigest()}}, self.ledger)
        self.package.write_bytes(b'application')
        write_private_json(self.token, {'one_time_ticket': 'disposable-fixture'})
        remove_private_file(self.token)
        self.assertEqual(len(self.ledger.actions()), 1)
        self.assertEqual(self.ledger.actions()[0]['status'], 'prepared')
        guest({'operation': 'install-finish', 'action_id': 'remote-install'}, self.ledger)
        review, result = self.remove()
        self.assertEqual(review['conflicts'], [])
        self.assertEqual(result['status'], 'complete')
        self.assertFalse(self.package.exists())

    def test_pause_blocks_consumption_inside_prepared_remote_installation(self):
        guest({'operation': 'install-begin', 'action_id': 'remote-install', 'target': self.target}, self.ledger)
        write_private_json(self.token, {'one_time_ticket': 'disposable-fixture'})
        self.ledger.pause('test-pause')
        with self.assertRaises(LedgerError):
            remove_private_file(self.token)
        self.assertTrue(self.token.exists())


if __name__ == '__main__':
    unittest.main()
