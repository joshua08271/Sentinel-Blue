"""R91 defects: real loopback TLS/files plus explicit manager mocks, not VM tests."""
import copy
from dataclasses import asdict
import hashlib
import http.server
from pathlib import Path
import shutil
import ssl
import subprocess
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

from sentinel_blue import probes
from sentinel_blue.actions import ActionExecutor
from sentinel_blue.controller import ControllerApp
from sentinel_blue.native_probes import ProbeUnavailable
from sentinel_blue.probe_evidence import all_probes_healthy
from sentinel_blue.service_recovery import check_recovery_deadline, check_restart_target
from sentinel_blue.store import Store, _require_success_result_contract
from test_service_repair import repair_fixture
from test_service_manifest_policy import profile_for
from test_store_controller import _promote_integrity_baseline
from test_repair_input_contract_1991 import PARAMETERS, TELEMETRY, MANIFEST


@unittest.skipUnless(shutil.which('openssl'), 'loopback TLS fixture needs OpenSSL')
class LocalTLS1992Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(prefix='sb1992-tls-')
        cls.root = Path(cls.temp.name)
        key, crt = cls.root/'server.key', cls.root/'server.crt'
        subprocess.run(['openssl', 'req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-days', '1',
                        '-keyout', str(key), '-out', str(crt), '-subj', '/CN=localhost',
                        '-addext', 'subjectAltName=IP:127.0.0.1', '-addext', 'basicConstraints=critical,CA:TRUE'],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True, timeout=20)
        cls.certificate = crt.read_bytes()
        cls.requests = 0
        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                cls.requests += 1
                self.send_response(500 if self.path == '/fail' else 200)
                self.end_headers()
                self.wfile.write(b'HEALTHY-1992')
            def log_message(self, *_args):
                pass
        cls.server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.load_cert_chain(crt, key)
        cls.server.socket = context.wrap_socket(cls.server.socket, server_side=True)
        cls.thread = threading.Thread(target=cls.server.serve_forever, kwargs={'poll_interval': .02}, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown(); cls.server.server_close(); cls.thread.join(3); cls.temp.cleanup()

    def setUp(self):
        self.case = tempfile.TemporaryDirectory(dir=self.root, prefix='case-')
        self.addCleanup(self.case.cleanup)
        self.path = Path(self.case.name)
        self.ca = self.path/'checker.pem'
        self.ca.write_bytes(self.certificate)
        self.spec = {'name': 'web', 'kind': 'https', 'target': f'https://127.0.0.1:{self.server.server_port}/',
                     'ca_file': str(self.ca), 'ca_sha256': hashlib.sha256(self.certificate).hexdigest(),
                     'timeout': 2, 'expected_status': [200], 'expected_body': 'HEALTHY-1992'}

    def result(self):
        return probes.run_probe(self.spec, ['127.0.0.0/8'])

    def unavailable(self):
        before = self.requests
        result = self.result()
        self.assertFalse(result.healthy)
        self.assertIs(result.executed, False)
        self.assertIn('local TLS checker trust unavailable', result.detail)
        self.assertEqual(before, self.requests)
        return result

    def test_good_tls_is_measured_success(self):
        result = self.result()
        self.assertTrue(result.healthy and result.executed)

    def test_pin_mismatch_is_unknown_without_contact(self):
        self.ca.write_bytes(self.certificate + b'\n')
        self.unavailable()

    def test_missing_ca_is_unknown(self):
        self.ca.unlink(); self.unavailable()

    def test_unparseable_but_pinned_ca_is_unknown(self):
        self.ca.write_bytes(b'not a certificate\n')
        self.spec['ca_sha256'] = hashlib.sha256(self.ca.read_bytes()).hexdigest()
        self.unavailable()

    def test_non_ascii_pinned_ca_is_unknown(self):
        self.ca.write_bytes(b'\xff\xfe')
        self.spec['ca_sha256'] = hashlib.sha256(self.ca.read_bytes()).hexdigest()
        self.unavailable()

    def test_ca_directory_is_unknown(self):
        self.ca.unlink(); self.ca.mkdir(); self.unavailable()

    def test_oversize_ca_is_unknown(self):
        self.ca.write_bytes(b'x' * 65537); self.unavailable()

    def test_symlink_ca_is_unknown(self):
        original = self.path/'real.pem'; original.write_bytes(self.certificate)
        self.ca.unlink(); self.ca.symlink_to(original); self.unavailable()

    def test_permission_failure_is_unknown(self):
        with patch.object(probes.os, 'open', side_effect=PermissionError('test-owned refusal')):
            self.unavailable()

    def test_endpoint_hostname_failure_is_still_measured(self):
        self.spec['server_name'] = 'wrong.invalid'
        result = self.result()
        self.assertFalse(result.healthy)
        self.assertIs(result.executed, True)

    def test_actual_http_failure_is_still_measured(self):
        self.spec['target'] = self.spec['target'] + 'fail'
        result = self.result()
        self.assertFalse(result.healthy)
        self.assertIs(result.executed, True)

    def test_restore_checking_ca_restores_check(self):
        self.ca.write_bytes(self.certificate + b'\n'); self.unavailable()
        self.ca.write_bytes(self.certificate)
        self.assertTrue(self.result().healthy)

    def test_preflight_holds_before_a_native_mutation(self):
        self.ca.write_bytes(self.certificate + b'\n')
        executor = ActionExecutor(self.path/'state', allow_service_recovery=True, authorized_networks=['127.0.0.0/8'])
        with patch.object(executor, '_set_service_state') as native:
            with self.assertRaisesRegex(ValueError, 'check unavailable'):
                executor._service_recovery_preflight({'service': 'fixture', 'probes': [self.spec]})
            native.assert_not_called()

    def test_valid_preflight_is_not_globally_disabled(self):
        executor = ActionExecutor(self.path/'state', allow_service_recovery=True, authorized_networks=['127.0.0.0/8'])
        executor._service_recovery_preflight({'service': 'fixture', 'probes': [self.spec]})

    def test_tls_kind_local_failure_is_unknown(self):
        self.spec = {'kind': 'tls', 'target': '127.0.0.1', 'port': self.server.server_port,
                     'ca_file': str(self.ca), 'ca_sha256': '0'*64}
        self.unavailable()

    def test_transaction_local_tls_failure_precedes_connection(self):
        spec = {'kind': 'transaction', 'target': '127.0.0.1', 'port': self.server.server_port,
                'tls': True, 'ca_file': str(self.ca), 'ca_sha256': '0'*64,
                'steps': [{'send': 'HELLO\n', 'expect': 'OK'}]}
        with patch.object(probes.socket, 'create_connection') as connect:
            result = probes.run_probe(spec, ['127.0.0.0/8'])
        self.assertFalse(result.executed)
        connect.assert_not_called()

    def test_checker_failure_does_not_queue_repair(self):
        good = self.result()
        profile, baseline = repair_fixture()
        manifest = copy.deepcopy(profile.services[0]); manifest['expected_transactions'] = [self.spec]
        profile = profile_for([manifest]); baseline['probes'] = [asdict(good)]
        store = Store(':memory:'); self.addCleanup(store.close)
        app = ControllerApp(store, 't'*32, operator_token='o'*32, event_profile=profile,
                            auto_recover_services=True, auto_restore=True, restoration_probes=[self.spec])
        app.ingest(baseline); _promote_integrity_baseline(app, store, 'agent-one')
        self.ca.write_bytes(self.certificate + b'\n'); bad = self.unavailable()
        for seq in (2, 3, 4):
            current = copy.deepcopy(baseline); current.update(sequence=seq, observed_at=time.time()-1)
            current['probes'] = [asdict(bad)]; app.ingest(current)
        self.assertNotIn('repair_service', [row.action_type for row in store.pending_actions('agent-one')])

    def test_unnamed_https_success_completes_at_controller(self):
        spec = dict(self.spec); del spec['name']
        store = Store(':memory:'); self.addCleanup(store.close)
        app = ControllerApp(store, 't'*32, operator_token='o'*32)
        executor = ActionExecutor(self.path/'name-state', authorized_networks=['127.0.0.0/8'])
        params = {'probes': [spec]}; result = executor.execute('validate_service', params, {})
        self.assertTrue(result['success'])
        action = store.queue_action('agent-one', 'validate_service', params)
        self.assertEqual(len([r for r in store.pending_actions('agent-one') if r.action_id == action]), 1)
        accepted = app.complete_action(dict(result, action_id=action), 'agent-one')
        self.assertEqual(accepted, 'new')
        self.assertEqual(store.get_action(action)['status'], 'completed')


class Contract1992Tests(unittest.TestCase):
    def test_name_default_is_target(self):
        spec = {'target': '127.0.0.1'}
        result = {'success': True, 'probes': [{'name': '127.0.0.1', 'target': '127.0.0.1', 'healthy': True, 'executed': True}]}
        _require_success_result_contract('validate_service', {'probes': [spec]}, result)

    def test_duplicate_identities_still_refused(self):
        spec = {'name': 'x', 'target': '127.0.0.1'}
        with self.assertRaises(ValueError):
            _require_success_result_contract('validate_service', {'probes': [spec, spec]},
                {'success': True, 'probes': [dict(spec, healthy=True), dict(spec, healthy=True)]})

    def test_unknown_success_still_refused(self):
        spec = {'target': '127.0.0.1'}
        with self.assertRaises(ValueError):
            _require_success_result_contract('validate_service', {'probes': [spec]},
                {'success': True, 'probes': [{'name': '127.0.0.1', 'target': '127.0.0.1', 'healthy': True, 'executed': False}]})

    def test_wrong_target_still_refused(self):
        spec = {'name': 'x', 'target': '127.0.0.1'}
        with self.assertRaises(ValueError):
            _require_success_result_contract('validate_service', {'probes': [spec]},
                {'success': True, 'probes': [dict(spec, target='127.0.0.2', healthy=True)]})

    def test_malformed_deadline_parameters_refuse(self):
        for value in (None, [], 5, 'x', True):
            with self.subTest(value=value), self.assertRaises(ValueError):
                check_recovery_deadline(value)

    def test_malformed_nested_probe_contract_refuses(self):
        for value in (None, {}, 'x', 7, [None], [False], [5]):
            with self.subTest(value=value), self.assertRaises(ValueError):
                check_restart_target(PARAMETERS, TELEMETRY, manifest=dict(MANIFEST, expected_transactions=value))

    def test_ordinary_restart_still_admitted(self):
        check_restart_target(PARAMETERS, TELEMETRY, manifest=MANIFEST)

    def test_no_health_is_invented_for_empty_contract(self):
        self.assertFalse(all_probes_healthy([], []))
        self.assertTrue(all_probes_healthy([], [], allow_empty=True))
