import contextlib
import hashlib
import io
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

with patch.object(sys, 'path', [str(Path(__file__).resolve().parents[1]/'tools'), *sys.path]):
    import azure_capacity_rehearsal as capacity


class FakeAzure:
    def __init__(self):
        self.size = capacity.ORIGINAL_SIZE
        self.identity = '/owned-test/Windows'
        self.power = 'PowerState/deallocated'
        self.changes = []
        self.uncertain = False
    def call(self, *args, **_kwargs):
        if args[:2] == ('vm','show'):
            return {'id':self.identity,'provisioningState':'Succeeded','hardwareProfile':{'vmSize':self.size}}
        if args[:2] == ('vm','get-instance-view'):
            return {'statuses':[{'code':self.power}]}
        if args[:2] == ('vm','resize'):
            self.size = args[args.index('--size')+1]
            self.changes.append(self.size)
            if self.uncertain:
                raise capacity.lab.PreflightError('uncertain response')
            return None
        raise AssertionError(args[:2])


class CapacityTests(unittest.TestCase):
    def test_running_target_is_never_resized(self):
        azure=FakeAzure();azure.power='PowerState/running'
        with self.assertRaises(capacity.lab.PreflightError):
            capacity.resize(azure,azure.identity,capacity.ORIGINAL_SIZE,capacity.TEST_SIZE)
        self.assertEqual(azure.changes,[])

    def test_unexpected_current_size_is_never_overwritten(self):
        azure=FakeAzure();azure.size='unexpected'
        with self.assertRaises(capacity.lab.PreflightError):
            capacity.resize(azure,azure.identity,capacity.ORIGINAL_SIZE,capacity.TEST_SIZE)
        self.assertEqual(azure.changes,[])

    def test_uncertain_resize_is_read_back_without_replay(self):
        azure=FakeAzure();azure.uncertain=True
        capacity.resize(azure,azure.identity,capacity.ORIGINAL_SIZE,capacity.TEST_SIZE)
        self.assertEqual(azure.changes,[capacity.TEST_SIZE])

    def test_failed_child_launch_still_restores_size_and_network(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary);runtime=root/'runtime.pyz';runtime.write_bytes(b'never executed')
            work=root/'work';work.mkdir()
            azure=FakeAzure()
            state={'vms':{capacity.TARGET:{'id':azure.identity}},
                   'network':{name:{} for name in capacity.isolation.PUBLIC_HOSTS}}
            args=SimpleNamespace(runtime=runtime,runtime_sha256=hashlib.sha256(runtime.read_bytes()).hexdigest(),
                expected_network_sha256='reviewed',execute=True,with_uptime=False,private_storage_account='owned',
                test_size='Standard_B2ms')
            with contextlib.ExitStack() as stack:
                stack.enter_context(contextlib.redirect_stdout(io.StringIO()))
                stack.enter_context(patch.object(capacity.tempfile,'mkdtemp',return_value=str(work)))
                stack.enter_context(patch.object(capacity.lab,'Azure',return_value=azure))
                stack.enter_context(patch.object(capacity.isolation,'snapshot',return_value=state))
                stack.enter_context(patch.object(capacity.isolation,'network_digest',return_value='reviewed'))
                stack.enter_context(patch.object(capacity.isolation,'require_off'))
                restore=stack.enter_context(patch.object(capacity.isolation,'change_association'))
                cleanup=stack.enter_context(patch.object(capacity.lab,'cleanup'))
                stack.enter_context(patch.object(capacity.subprocess,'Popen',side_effect=OSError('owned test failure')))
                with self.assertRaises(OSError):
                    capacity.run(args)
            self.assertEqual(azure.changes,['Standard_B2ms',capacity.ORIGINAL_SIZE])
            cleanup.assert_called_once()
            self.assertEqual(restore.call_count,len(capacity.isolation.PUBLIC_HOSTS))
            report=json.loads((work/'result.json').read_text())
            self.assertEqual(report['status'], 'failed')
            self.assertEqual(report['error_type'], 'OSError')
            self.assertTrue(report['all_vms_deallocated'])
            self.assertTrue(report['original_size_restored'])
            self.assertTrue(report['original_network_restored'])
