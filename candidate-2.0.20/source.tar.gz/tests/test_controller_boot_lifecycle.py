"""Removing and replacing a controller boot registration (Linux).

`controller-boot-install` registers the controller to start at boot and refuses
to overwrite an existing registration — correctly, since an object it did not
install is not its to replace. But there was no reviewed way forward. The only
route to removal was a full Withdraw, which tears down every Sentinel artifact on
the host, so changing which config or ledger the controller boots with meant
withdrawing the whole installation and rebuilding it — or hand-editing systemd,
which abandons the ownership ledger and leaves the receipt describing something
that no longer exists.

`controller-boot-uninstall` reverses exactly that registration, using the same
evidenced undo a withdrawal performs, without withdrawing the host.
`controller-boot-status` answers what is registered in the first place.

The properties defended here: only what this ledger installed can be removed, an
object changed since installation is never quietly reversed, and the host is not
left in a withdrawal state afterwards.
"""

import hashlib
import json
import os
import shutil
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from sentinel_blue import controller_boot
from sentinel_blue.controller_boot import registrations, status, uninstall
from sentinel_blue.mutation_ledger import LedgerError, MutationLedger, OwnershipConflict
from sentinel_blue.withdrawal import _restore_one
from sentinel_blue.withdrawal_native import NativeObjects, object_target


class BootRegistrationFixture(unittest.TestCase):
    def setUp(self):
        self.root = Path(tempfile.mkdtemp(prefix="sentinel-boot-"))
        self.addCleanup(shutil.rmtree, self.root, True)
        os.chmod(self.root, 0o700)
        self.ledger = MutationLedger(self.root / "ledger")
        self.unit = self.root / "sentinel-blue-controller.service"
        self.receipt = self.root / "controller-boot-binding.json"

    def register(self, label="first", *, context=None, ownership="sentinel_artifact",
                 unit=None, receipt=None):
        """Record what install() records, without requiring systemd.

        The action id is supplied rather than discovered, so a test with more
        than one registration refers to the exact one it created.
        """
        unit = unit or self.unit
        receipt = receipt or self.receipt
        action_id = hashlib.sha256(f"{label}:{unit}".encode()).hexdigest()[:32]
        native = NativeObjects(self.ledger)
        target = object_target(files=[str(unit), str(receipt)])

        def perform():
            receipt.write_bytes(json.dumps({"schema": 2, "label": label}, sort_keys=True).encode())
            unit.write_bytes(f"[Unit]\nDescription=Sentinel Blue controller {label}\n".encode())
            return {"installed": True}

        with self.ledger.lock():
            self.ledger.mutate(
                native.name, target, perform, snapshot=native.snapshot, ownership=ownership,
                action_id=action_id,
                context={"controller_boot": True} if context is None else context)
        return action_id


class RegistrationIdentityTests(BootRegistrationFixture):
    def test_a_committed_boot_registration_is_found(self):
        action_id = self.register()
        rows = registrations(self.ledger)
        self.assertEqual([row["action_id"] for row in rows], [action_id])

    def test_another_sentinel_artifact_is_not_a_boot_registration(self):
        self.register(context={"installation": True})
        self.assertEqual(registrations(self.ledger), [])

    def test_a_configuration_change_is_not_a_boot_registration(self):
        # Ownership matters as well as context: a reviewed configuration edit is
        # never removable through this command.
        self.register(ownership="configuration", context={"controller_boot": True})
        self.assertEqual(registrations(self.ledger), [])

    def test_states_are_loaded_only_when_asked(self):
        self.register()
        self.assertIsNone(registrations(self.ledger)[0].get("after"))
        self.assertIsNotNone(registrations(self.ledger, include_states=True)[0].get("after"))


class BootStatusTests(BootRegistrationFixture):
    def test_nothing_registered_reports_nothing(self):
        state = status(self.ledger)
        self.assertFalse(state["registered"])
        self.assertEqual(state["registrations"], [])
        self.assertFalse(state["withdrawal_review_active"])

    def test_a_clean_registration_is_removable(self):
        self.register()
        entry = status(self.ledger)["registrations"][0]
        self.assertTrue(entry["matches_record"])
        self.assertTrue(entry["removable"])
        self.assertEqual(entry["reason"], "")
        self.assertIn(str(self.unit), entry["files"])

    def test_an_object_edited_after_installation_is_not_removable(self):
        self.register()
        self.unit.write_bytes(b"[Unit]\nDescription=edited by hand\n")
        entry = status(self.ledger)["registrations"][0]
        self.assertFalse(entry["matches_record"])
        self.assertFalse(entry["removable"])
        self.assertIn("held for human review", entry["reason"])

    def test_a_deleted_object_is_reported_rather_than_assumed_gone(self):
        self.register()
        self.unit.unlink()
        entry = status(self.ledger)["registrations"][0]
        self.assertFalse(entry["matches_record"])
        self.assertFalse(entry["removable"])

    def test_an_active_withdrawal_review_blocks_removal(self):
        self.register()
        self.ledger.pause("review-1")
        state = status(self.ledger)
        self.assertTrue(state["withdrawal_review_active"])
        self.assertFalse(state["registrations"][0]["removable"])

    def test_status_reports_the_ledger_it_consulted(self):
        self.assertEqual(status(self.ledger)["ledger_directory"], str(self.root / "ledger"))


class BootUninstallTests(BootRegistrationFixture):
    def test_the_registration_is_removed_and_the_host_is_not_withdrawn(self):
        self.register()
        result = uninstall(ledger=self.ledger)
        self.assertEqual(result["status"], "undone")
        self.assertFalse(result["starts_at_next_boot"])
        self.assertFalse(self.unit.exists())
        self.assertFalse(self.receipt.exists())
        # The whole point: this is not a withdrawal.
        self.assertFalse(self.ledger.paused())
        self.assertFalse(status(self.ledger)["registered"])

    def test_the_removed_objects_are_named_in_the_result(self):
        self.register()
        removed = uninstall(ledger=self.ledger)["removed"]
        self.assertIn(str(self.unit), removed["files"])
        self.assertIn(str(self.receipt), removed["files"])

    def test_the_controller_can_be_registered_again_afterwards(self):
        # This is the replacement path: remove, then install with new inputs.
        self.register("first")
        uninstall(ledger=self.ledger)
        self.register("second")
        self.assertTrue(status(self.ledger)["registrations"][0]["removable"])
        self.assertEqual(json.loads(self.receipt.read_bytes())["label"], "second")

    def test_removing_twice_is_not_an_error(self):
        self.register()
        uninstall(ledger=self.ledger)
        with self.assertRaises(ValueError) as error:
            uninstall(ledger=self.ledger)
        self.assertIn("records no controller boot registration", str(error.exception))

    def test_an_absent_registration_refuses_with_guidance(self):
        with self.assertRaises(ValueError) as error:
            uninstall(ledger=self.ledger)
        message = str(error.exception)
        self.assertIn("not Sentinel's to remove", message)

    def test_an_object_changed_after_installation_is_never_quietly_reversed(self):
        self.register()
        self.unit.write_bytes(b"[Unit]\nDescription=edited by hand\n")
        with self.assertRaises(OwnershipConflict):
            uninstall(ledger=self.ledger)
        self.assertTrue(self.unit.exists(), "the edited object is left for a person")

    def test_an_active_withdrawal_review_refuses_the_scoped_removal(self):
        self.register()
        self.ledger.pause("review-1")
        with self.assertRaises(ValueError) as error:
            uninstall(ledger=self.ledger)
        self.assertIn("withdrawal review is in progress", str(error.exception))
        self.assertTrue(self.unit.exists())

    def test_an_unknown_action_is_refused(self):
        self.register()
        with self.assertRaises(ValueError) as error:
            uninstall(action_id="0" * 32, ledger=self.ledger)
        self.assertIn("not a committed controller boot registration", str(error.exception))
        self.assertTrue(self.unit.exists())

    def test_a_non_boot_action_cannot_be_removed_through_this_path(self):
        other = self.register(context={"installation": True})
        with self.assertRaises(ValueError):
            uninstall(action_id=other, ledger=self.ledger)
        self.assertTrue(self.unit.exists())

    def test_several_registrations_require_naming_one(self):
        first = self.register("first")
        second_unit = self.root / "second.service"
        second_receipt = self.root / "second-binding.json"
        second = self.register("second", unit=second_unit, receipt=second_receipt)
        with self.assertRaises(ValueError) as error:
            uninstall(ledger=self.ledger)
        message = str(error.exception)
        self.assertIn("--action-id", message)
        self.assertIn(first, message)
        self.assertIn(second, message)
        # Naming one removes exactly that one.
        uninstall(action_id=second, ledger=self.ledger)
        self.assertFalse(second_unit.exists())
        self.assertTrue(self.unit.exists())


class WithdrawalDrainIsUnchangedTests(BootRegistrationFixture):
    """Relaxing the pause for one scoped artifact must not relax withdrawal."""

    def test_restore_one_still_requires_a_pause_by_default(self):
        action_id = self.register()
        with self.assertRaises(LedgerError) as error:
            _restore_one(self.ledger, action_id)
        self.assertIn("Pause and drain this host", str(error.exception))
        self.assertTrue(self.unit.exists())

    def test_a_full_withdrawal_still_reverses_the_registration(self):
        action_id = self.register()
        self.ledger.pause("review-1")
        self.assertEqual(_restore_one(self.ledger, action_id)["status"], "undone")
        self.assertFalse(self.unit.exists())

    def test_the_scoped_path_records_the_same_evidence(self):
        self.register()
        uninstall(ledger=self.ledger)
        kinds = [event["kind"] for event in self.ledger.read()]
        self.assertIn("undo_prepared", kinds)
        self.assertIn("undone", kinds)


class BootCommandLineTests(BootRegistrationFixture):
    def args(self, command, **extra):
        return SimpleNamespace(command=command, ledger_directory=str(self.root / "ledger"),
                               **extra)

    def test_status_runs_from_the_command_line(self):
        self.register()
        self.assertEqual(controller_boot.run(self.args("controller-boot-status")), 0)

    def test_uninstall_runs_from_the_command_line(self):
        self.register()
        self.assertEqual(
            controller_boot.run(self.args("controller-boot-uninstall", action_id=None)), 0)
        self.assertFalse(self.unit.exists())

    def test_both_commands_are_registered_in_the_parser(self):
        from sentinel_blue.__main__ import parser as build_parser
        command_line = build_parser()
        for command in ("controller-boot-status", "controller-boot-uninstall"):
            with self.subTest(command=command):
                parsed = command_line.parse_args([command])
                self.assertEqual(parsed.command, command)


if __name__ == "__main__":
    unittest.main()
