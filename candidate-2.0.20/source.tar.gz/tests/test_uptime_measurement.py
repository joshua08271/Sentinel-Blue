import json
from pathlib import Path
import sqlite3
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from tools.uptime_observer import summarize, validate
from tools.uptime_rehearsal import database_sample, DefaultIntervalDefender, summary
from tools.setup_native_inputs import profile_inventory, manifest
from sentinel_blue.controller import ControllerApp
from sentinel_blue.store import Store


class UptimeMeasurementTests(unittest.TestCase):
    def test_owned_baseline_capture_has_one_authorized_manifest_owner(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            runtime = root/'runtime.pyz'
            runtime.write_bytes(b'fixture identity only; never executed')
            paths = [str(root/'web.conf'), str(root/'second.conf')]
            service = manifest('owned-service', 'http', 41234,
                               [{'kind': 'http', 'target': 'http://127.0.0.1:41234/health'}])
            service.update(required_files=paths, allowed_automatic_actions=['capture_restore_point'])
            inventory = profile_inventory(runtime, [{'options': {'files': [{'path': p} for p in paths]}}], [service])
            defender = DefaultIntervalDefender(root/'defender', runtime, inventory, started_at=time.time())
            store = Store(':memory:')
            try:
                app = ControllerApp(store, 't'*32, operator_token='o'*32,
                                    event_profile=defender.profile)
                allowed, detail = app._service_manifest_policy('target', 'capture_restore_point',
                                    {'files': [{'path': p} for p in paths]}, automated=True)
                self.assertTrue(allowed, detail)
                self.assertEqual(defender.plan['profile_fingerprint'], defender.profile.fingerprint)
            finally:
                store.close()
                defender.close()

    def test_summary_preserves_lifecycle_status(self):
        self.assertEqual(summary({'status': 'failed', 'passed': False})['status'], 'failed')

    def test_missing_records_count_as_unavailable(self):
        data = summarize([{'slot': 0, 'healthy_1s': True, 'healthy_2s': True,
                           'reason': 'healthy', 'request_seconds': .01}], 5)
        self.assertEqual(data['availability_percent_2s'], 20)
        self.assertEqual(data['failed_check_reasons'], {'missing_record': 4})
        self.assertEqual(data['longest_failed_check_run_seconds'], 4)

    def test_deadlines_and_failed_sequences_are_preserved(self):
        rows = [{'slot': i, 'healthy_1s': i == 0, 'healthy_2s': i in (0, 3),
                 'reason': 'healthy' if i in (0, 3) else 'http_status'} for i in range(5)]
        result = summarize(rows, 5)
        self.assertEqual(result['availability_percent_1s'], 20)
        self.assertEqual(result['availability_percent_2s'], 40)
        self.assertEqual(result['longest_failed_check_run_seconds'], 2)

    def test_duplicate_scoring_slots_are_rejected(self):
        row = {'slot': 0, 'healthy_1s': True, 'healthy_2s': True, 'reason': 'healthy'}
        with self.assertRaises(ValueError):
            summarize([row, row], 5)

    def test_external_targets_and_unbounded_runs_are_rejected(self):
        validate('http://127.0.0.1:40000/health', 1080)
        for target in ('http://example.com:40000/health', 'http://127.0.0.1:40000/other',
                       'http://user:secret@127.0.0.1:40000/health', 'https://127.0.0.1:40000/health'):
            with self.subTest(target=target), self.assertRaises(ValueError):
                validate(target, 1080)
        for duration in (-1, 0, 1201, True):
            with self.subTest(duration=duration), self.assertRaises(ValueError):
                validate('http://127.0.0.1:40000/health', duration)

    def test_read_only_diagnostics_match_actual_store_schema(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            store = Store(root/'controller.db')
            store.close()
            with sqlite3.connect(root/'controller.db') as db:
                db.execute('INSERT INTO agents(agent_id,hostname,platform,registered_at,last_seen,latest_telemetry) VALUES (?,?,?,?,?,?)',
                           ('target', 'fixture', 'Linux', time.time(), time.time(),
                            json.dumps({'observed_at': time.time(), 'sequence': 3,
                                        'collector_errors': [], 'probes': [{'healthy': True}]})))
                db.execute('INSERT INTO baselines(agent_id,baseline_json,created_at,status) VALUES (?,?,?,?)',
                           ('target', '{}', time.time(), 'approved'))
            opened = []
            connect = sqlite3.connect
            def tracked_connection(*args, **kwargs):
                connection = connect(*args, **kwargs)
                opened.append(connection)
                return connection
            with patch('tools.uptime_rehearsal.sqlite3.connect', side_effect=tracked_connection):
                result = database_sample(SimpleNamespace(root=root, children=[]), 'owned-service', time.monotonic(), time.time())
            self.assertNotIn('diagnostic_error_type', result)
            self.assertEqual(result['sequence'], 3)
            self.assertEqual(result['baseline_status'], 'approved')
            self.assertTrue(result['all_probes_healthy'])
            self.assertEqual(result['service_actions'], [])
            self.assertEqual(len(opened), 1)
            with self.assertRaises(sqlite3.ProgrammingError):
                opened[0].execute('SELECT 1')


if __name__ == '__main__':
    unittest.main()
