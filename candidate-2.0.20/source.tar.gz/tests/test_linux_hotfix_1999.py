"""Findings 21–25: Linux router and telemetry boundary regressions.

Native network/service controls are modeled; root-owned files and ledgers are
private fixtures. No real host configuration, startup entry or account changes.
"""
from __future__ import annotations
import copy
from contextlib import ExitStack
from dataclasses import asdict
import json
import os
from pathlib import Path
import subprocess
import tempfile
import time
import unittest
from unittest.mock import patch

from sentinel_blue import network_native as net, collectors as c, analyzers as a, validation
from sentinel_blue.mutation_ledger import MutationLedger
from sentinel_blue.protocol import FirewallState
from sentinel_blue.risk import RiskModel
from sentinel_blue.detection import detect
from sentinel_blue.withdrawal import _restore_one
from test_linux_hotfix_1997 import RouterModel, POSIX_ROOT

NATIVE_COMMAND = net.command


@unittest.skipUnless(POSIX_ROOT, 'Private root-owned Linux fixture')
class Confirmation1999(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack(); self.addCleanup(self.stack.close)
        self.root = Path(self.stack.enter_context(tempfile.TemporaryDirectory(prefix='sb-1999-',dir='/var/lib')))
        self.m = RouterModel(self.root); self.m.enter(self.stack)
        self.spec = self.m.spec; self.ledger = MutationLedger()
        net.run('apply', self.spec, 'helper')

    def row(self):
        return self.ledger.actions(include_states=True)[-1]

    def stop_failure(self, *, after=False):
        fired=[]
        real=self.m.command
        def command(argv,data=None,**kw):
            match=argv == ['systemctl','disable','--now',self.m.service+'-rollback.timer'] and not fired
            if match and not after:
                fired.append(True); raise RuntimeError('fixture stop failure')
            result=real(argv,data,**kw)
            if match:
                fired.append(True); raise RuntimeError('fixture stop failure after side effect')
            return result
        with patch.object(net,'command',side_effect=command):
            with self.assertRaisesRegex(RuntimeError,'fixture stop failure'):
                net.run('commit',self.spec,'helper')
        return self.row()

    def test_timer_failure_leaves_durable_decision_and_pending_native_state(self):
        row=self.stop_failure()
        self.assertEqual(row['status'],'committed')
        self.assertEqual(self.m.state()['status'],'pending')
        self.assertIn(self.m.service+'-rollback.timer', self.m.active)
        self.assertIsNotNone(net.confirmation_intent(self.ledger,row['action_id']))

    def test_real_command_wrapper_rejects_nonzero_timer_stop(self):
        real=self.m.command
        def command(argv,data=None,**kw):
            if argv==['systemctl','disable','--now',self.m.service+'-rollback.timer']:
                with patch.object(net.subprocess,'run',return_value=subprocess.CompletedProcess(argv,1,'','fixture error')):
                    return NATIVE_COMMAND(argv, data, **kw)
            return real(argv,data,**kw)
        with patch.object(net,'command',side_effect=command):
            with self.assertRaisesRegex(RuntimeError,'exit 1'):net.run('commit',self.spec,'helper')
        self.assertEqual(self.m.state()['status'],'pending');self.assertEqual(self.row()['status'],'committed')
        net.run('commit',self.spec,'helper');self.assertTrue(net.verify(self.spec,self.m.state()))

    def test_intent_write_failure_never_commits_or_disables_timer(self):
        real=MutationLedger.append
        def append(ledger,kind,**kw):
            if kind=='router_confirmation_prepared':raise RuntimeError('fixture intent failure')
            return real(ledger,kind,**kw)
        with patch.object(MutationLedger,'append',new=append):
            with self.assertRaisesRegex(RuntimeError,'intent failure'):net.run('commit',self.spec,'helper')
        self.assertEqual(self.row()['status'],'applied')
        self.assertIn(self.m.service+'-rollback.timer',self.m.active)
        net.run('rollback',self.spec,'helper');self.assertEqual(self.row()['status'],'cancelled')

    def test_retry_confirmation_after_timer_failure_completes(self):
        self.stop_failure(); net.run('commit',self.spec,'helper')
        self.assertEqual(self.m.state()['status'],'committed')
        self.assertTrue(net.verify(self.spec,self.m.state()))
        self.assertNotIn(self.m.service+'-rollback.timer',self.m.active)
        self.assertEqual(len(self.ledger.actions()),1)

    def test_timer_itself_can_finish_a_durable_confirmation(self):
        self.stop_failure(); net.run('rollback',self.spec,'helper')
        self.assertEqual(self.row()['status'],'committed')
        self.assertEqual(self.m.state()['status'],'committed')
        self.assertNotIn(self.m.service+'-rollback.timer',self.m.active)
        self.assertTrue(self.m.unit.exists())

    def test_reapply_reconciles_confirmation_without_new_mutations(self):
        self.stop_failure(); before=len(self.m.mutations()); net.run('apply',self.spec,'helper')
        self.assertEqual(self.m.state()['status'],'committed')
        self.assertEqual(len(self.m.mutations()),before)
        self.assertEqual(len(self.ledger.actions()),1)

    def test_boot_can_finish_durable_confirmation_then_restore_volatile_policy(self):
        self.stop_failure(); self.m.table=None
        net.run('boot',self.spec,'helper')
        self.assertEqual(self.m.state()['status'],'committed')
        self.assertTrue(net.verify(self.spec,self.m.state()))

    def test_boot_does_not_adopt_changed_persistent_helpers(self):
        self.stop_failure(); self.m.unit.chmod(0o640); before=len(self.m.mutations())
        with self.assertRaises(ValueError):net.run('boot',self.spec,'helper')
        self.assertEqual(self.m.unit.stat().st_mode&0o777,0o640)
        self.assertEqual(len(self.m.mutations()),before)

    def test_stop_success_with_transport_error_is_retryable(self):
        self.stop_failure(after=True)
        self.assertNotIn(self.m.service+'-rollback.timer',self.m.active)
        net.run('commit',self.spec,'helper')
        self.assertTrue(net.verify(self.spec,self.m.state()))

    def test_check_remains_read_only_during_unpublished_confirmation(self):
        self.stop_failure(); head=self.ledger.head(); state=self.m.state()
        try:net.run('check',self.spec,'helper')
        except SystemExit:pass
        self.assertEqual(self.ledger.head(),head); self.assertEqual(self.m.state(),state)

    def test_interruption_before_ledger_commit_keeps_timer_and_rollback_usable(self):
        with patch.object(MutationLedger,'commit',side_effect=RuntimeError('fixture before commit')):
            with self.assertRaisesRegex(RuntimeError,'fixture before commit'):net.run('commit',self.spec,'helper')
        self.assertEqual(self.row()['status'],'applied')
        self.assertEqual(self.m.state()['status'],'pending')
        self.assertIn(self.m.service+'-rollback.timer',self.m.active)
        net.run('rollback',self.spec,'helper')
        self.assertEqual(self.row()['status'],'cancelled');self.assertFalse(self.m.unit.exists())

    def test_uncommitted_intent_can_retry_same_confirmation(self):
        with patch.object(MutationLedger,'commit',side_effect=RuntimeError('fixture before commit')):
            with self.assertRaises(RuntimeError):net.run('commit',self.spec,'helper')
        net.run('commit',self.spec,'helper')
        self.assertTrue(net.verify(self.spec,self.m.state()))
        self.assertEqual(sum(e['kind']=='router_confirmation_prepared' for e in self.ledger.read()),1)

    def test_uncommitted_intent_expires_to_authenticated_rollback(self):
        with patch.object(MutationLedger,'commit',side_effect=RuntimeError('fixture before commit')):
            with self.assertRaises(RuntimeError):net.run('commit',self.spec,'helper')
        future=self.m.state()['expires_monotonic']+1
        with patch.object(net.time,'monotonic',return_value=future):
            with self.assertRaisesRegex(ValueError,'deadline expired'):net.run('commit',self.spec,'helper')
        self.assertEqual(self.row()['status'],'cancelled')

    def test_interruption_after_ledger_commit_is_retryable(self):
        real=MutationLedger.commit
        def committed_then_crash(ledger,*args,**kw):
            real(ledger,*args,**kw); raise RuntimeError('fixture after commit')
        with patch.object(MutationLedger,'commit',new=committed_then_crash):
            with self.assertRaisesRegex(RuntimeError,'fixture after commit'):net.run('commit',self.spec,'helper')
        self.assertEqual(self.row()['status'],'committed')
        net.run('commit',self.spec,'helper');self.assertTrue(net.verify(self.spec,self.m.state()))

    def test_interruption_before_native_publication_is_retryable(self):
        real=net.save
        def save(path,state):
            if path==self.root/'state.json' and state.get('status')=='committed':
                raise RuntimeError('fixture before publication')
            return real(path,state)
        with patch.object(net,'save',side_effect=save):
            with self.assertRaisesRegex(RuntimeError,'fixture before publication'):net.run('commit',self.spec,'helper')
        self.assertEqual(self.row()['status'],'committed'); self.assertEqual(self.m.state()['status'],'pending')
        net.run('commit',self.spec,'helper');self.assertTrue(net.verify(self.spec,self.m.state()))

    def test_interruption_after_native_publication_is_retryable(self):
        real=net.save
        def save(path,state):
            real(path,state)
            if path==self.root/'state.json' and state.get('status')=='committed':
                raise RuntimeError('fixture after publication')
        with patch.object(net,'save',side_effect=save):
            with self.assertRaisesRegex(RuntimeError,'fixture after publication'):net.run('commit',self.spec,'helper')
        net.run('commit',self.spec,'helper'); self.assertTrue(net.verify(self.spec,self.m.state()))

    def test_interruption_before_publication_ack_is_retryable(self):
        real=MutationLedger.append
        def append(ledger,kind,**kw):
            if kind=='router_confirmation_published':raise RuntimeError('fixture before ack')
            return real(ledger,kind,**kw)
        with patch.object(MutationLedger,'append',new=append):
            with self.assertRaisesRegex(RuntimeError,'fixture before ack'):net.run('commit',self.spec,'helper')
        net.run('commit',self.spec,'helper')
        self.assertEqual(sum(e['kind']=='router_confirmation_published' for e in self.ledger.read()),1)
        head=self.ledger.head();net.run('commit',self.spec,'helper');self.assertEqual(head,self.ledger.head())

    def test_changed_lifecycle_state_is_not_replaced_on_retry(self):
        self.stop_failure(); state=self.m.state();state['operator_note']='keep';net.save(self.root/'state.json',state)
        with self.assertRaisesRegex(ValueError,'lifecycle changed'):net.run('commit',self.spec,'helper')
        self.assertEqual(self.m.state()['operator_note'],'keep')

    def test_changed_metadata_is_not_adopted_on_retry(self):
        self.stop_failure();self.m.unit.chmod(0o640)
        with self.assertRaises(ValueError):net.run('commit',self.spec,'helper')
        self.assertEqual(self.m.unit.stat().st_mode&0o777,0o640)

    def test_same_byte_rewrite_is_not_adopted_on_retry(self):
        self.stop_failure();self.m.unit.write_bytes(self.m.unit.read_bytes())
        with self.assertRaises(ValueError):net.run('commit',self.spec,'helper')
        self.assertEqual(self.m.state()['status'],'pending')

    def test_change_during_timer_stop_is_preserved(self):
        def hook(argv,data):
            if argv==['systemctl','disable','--now',self.m.service+'-rollback.timer']:self.m.unit.chmod(0o640)
        self.m.hook=hook
        with self.assertRaises(ValueError):net.run('commit',self.spec,'helper')
        self.assertEqual(self.m.unit.stat().st_mode&0o777,0o640)
        self.assertEqual(self.m.state()['status'],'pending')

    def test_changed_table_is_not_adopted_on_retry(self):
        self.stop_failure();self.m.table='operator table'
        with self.assertRaises(ValueError):net.run('commit',self.spec,'helper')
        self.assertEqual(self.m.table,'operator table')

    def test_wrong_spec_does_not_confirm_applied_state(self):
        head=self.ledger.head()
        with self.assertRaises(ValueError):net.run('commit',{**self.spec,'ruleset':'different'},'helper')
        self.assertEqual(self.ledger.head(),head);self.assertEqual(self.row()['status'],'applied')

    def test_legacy_committed_flag_without_intent_is_not_trusted(self):
        state=net.committed_state(self.m.state());net.save(self.root/'state.json',state)
        with self.assertRaises(ValueError):net.run('commit',self.spec,'helper')
        self.assertEqual(self.row()['status'],'applied')

    def test_mutated_inverse_prevents_first_confirmation(self):
        state=self.m.state();state['before']['forwarding']='1';net.save(self.root/'state.json',state)
        with self.assertRaises(ValueError):net.run('commit',self.spec,'helper')
        self.assertEqual(self.row()['status'],'applied')

    def test_confirmed_update_still_supports_withdrawal_after_interruption(self):
        net.run('commit',self.spec,'helper');original=self.row()['before_hash']
        updated={**self.spec,'ruleset':self.spec['ruleset']+'# update\n'}
        net.run('apply',updated,'new helper');self.spec=updated
        self.stop_failure();net.run('commit',updated,'new helper')
        key=self.row()['action_id'];self.ledger.pause('test')
        _restore_one(self.ledger,key)
        old=self.ledger.actions(include_states=True)[0]
        self.assertEqual(old['before_hash'],original)
        _restore_one(self.ledger,old['action_id']);self.assertFalse(self.m.unit.exists())


@unittest.skipUnless(POSIX_ROOT, 'Private root-owned Linux fixture')
class Withdrawal1999(unittest.TestCase):
    def setUp(self):
        self.stack=ExitStack();self.addCleanup(self.stack.close)
        self.root=Path(self.stack.enter_context(tempfile.TemporaryDirectory(prefix='sb-undo1999-',dir='/var/lib')))
        self.m=RouterModel(self.root);self.m.enter(self.stack);self.l=MutationLedger()
        net.run('apply',self.m.spec,'old');net.run('commit',self.m.spec,'old')
        self.spec={**self.m.spec,'ruleset':self.m.spec['ruleset']+'# update\n'}
        net.run('apply',self.spec,'new');net.run('commit',self.spec,'new')
        self.key=self.l.actions()[-1]['action_id'];self.l.pause('test')

    def conflict(self,change,verify):
        fired=[]
        def hook(argv,data):
            if argv==['systemctl','daemon-reload'] and not fired:fired.append(True);change()
        self.m.hook=hook
        with self.assertRaises((OSError,ValueError,RuntimeError)):_restore_one(self.l,self.key)
        verify();self.assertTrue(fired)
        self.assertEqual(self.l.actions()[-1]['status'],'conflict')
        self.assertFalse(any(e['kind']=='undone' and e.get('action_id')==self.key for e in self.l.read()))

    def test_permission_edit_preserved_and_not_reported_successful(self):
        self.conflict(lambda:self.m.unit.chmod(0o640),lambda:self.assertEqual(self.m.unit.stat().st_mode&0o777,0o640))

    def test_group_edit_preserved(self):
        self.conflict(lambda:os.chown(self.m.unit,0,65534),lambda:self.assertEqual(self.m.unit.stat().st_gid,65534))

    def test_extended_attribute_edit_preserved(self):
        self.conflict(lambda:os.setxattr(self.m.unit,'user.operator',b'keep'),lambda:self.assertEqual(os.getxattr(self.m.unit,'user.operator'),b'keep'))

    def test_same_content_rewrite_is_a_conflict(self):
        self.conflict(lambda:self.m.unit.write_bytes(self.m.unit.read_bytes()),lambda:self.assertEqual(self.m.unit.read_text(),'unit fixture\n'))

    def test_late_symlink_is_not_followed(self):
        target=self.root/'operator';target.write_text('keep')
        def change():self.m.unit.unlink();self.m.unit.symlink_to(target)
        self.conflict(change,lambda:self.assertEqual(target.read_text(),'keep'))
        self.assertTrue(self.m.unit.is_symlink())

    def test_clean_withdrawal_restores_original_metadata_and_chain(self):
        result=_restore_one(self.l,self.key);self.assertEqual(result['status'],'undone')
        self.assertEqual(self.m.unit.stat().st_mode&0o777,0o600)
        old=self.l.actions()[0];_restore_one(self.l,old['action_id']);self.assertFalse(self.m.unit.exists())


class PathIdentity1999(unittest.TestCase):
    def setUp(self):self.model=RiskModel()
    def processes(self,platform,before='/tmp/worker',current='/tmp/Worker'):
        return a.analyze_processes({'platform':platform,'processes':[{'path':current,'privileged':True,'username':'root'}]},
                                  {'processes':[{'path':before,'privileged':False}]},self.model)
    def persistence(self,platform,before='/etc/cron.d/Backup',current='/etc/cron.d/backup'):
        old={'kind':'cron','name':before,'owner':'root','sha256':'a'*64,'enabled':True}
        return a.analyze_persistence({'platform':platform,'persistence':[old,{**old,'name':current}]}, {'persistence':[old]},self.model)
    def test_linux_process_names_remain_distinct(self):self.assertEqual(len(self.processes('Linux')),1)
    def test_linux_persistence_names_remain_distinct(self):self.assertEqual(len(self.persistence('Linux')),1)
    def test_linux_exact_same_process_path_is_not_new(self):self.assertFalse(self.processes('Linux',current='/tmp/worker'))
    def test_linux_exact_same_persistence_path_is_not_new(self):self.assertFalse(self.persistence('Linux',current='/etc/cron.d/Backup'))
    def test_unknown_platform_does_not_merge_case_distinct_paths(self):self.assertTrue(self.processes(''));self.assertTrue(self.persistence(''))
    def test_windows_process_case_handling_is_retained(self):self.assertFalse(self.processes('Windows',r'C:\Temp\worker.exe',r'c:\temp\WORKER.EXE'))
    def test_windows_persistence_case_handling_is_retained(self):self.assertFalse(self.persistence('Windows',r'HKLM\Run\Backup',r'hklm\run\BACKUP'))
    def test_baseline_windows_platform_retains_case_handling_when_current_omits_it(self):
        old={'kind':'run_key','name':'HKLM\\Run\\Backup','sha256':'a'*64,'owner':'SYSTEM'}
        alerts=a.analyze_persistence({'persistence':[{**old,'name':old['name'].lower()}]},
                                    {'platform':'Windows','persistence':[old]},self.model)
        self.assertFalse(alerts)
    def test_windows_changed_payload_still_alerts(self):
        old={'kind':'run_key','name':'HKLM\\Run\\Backup','sha256':'a'*64,'owner':'SYSTEM'}
        alerts=a.analyze_persistence({'platform':'Windows','persistence':[{**old,'name':'hklm\\run\\BACKUP','sha256':'b'*64}]},{'persistence':[old]},self.model)
        self.assertEqual([x.kind for x in alerts],['persistence_changed'])
    def test_current_linux_platform_overrides_old_windows_marker(self):
        alerts=a.analyze_persistence({'platform':'Linux','persistence':[{'name':'/etc/Backup','kind':'cron'}]},
                                    {'platform':'Windows','persistence':[{'name':'/etc/backup','kind':'cron'}]},self.model)
        self.assertEqual([x.kind for x in alerts],['new_persistence_item'])
    def test_simultaneous_linux_baseline_entries_do_not_collapse(self):
        lower={'kind':'cron','name':'/etc/backup','sha256':'a'*64,'owner':'root'}
        upper={**lower,'name':'/etc/Backup','sha256':'b'*64}
        alerts=a.analyze_persistence({'platform':'Linux','persistence':[lower,upper]}, {'persistence':[lower,upper]},self.model)
        self.assertFalse(alerts)


class FirewallEvidence1999(unittest.TestCase):
    def query(self,provider):
        errors=[]
        with patch.object(c,'_run',side_effect=provider):obs=c._linux_firewall(errors)
        return obs,errors
    def detection(self,enabled):
        obs=validation._firewall({'enabled':enabled})
        return [x.kind for x in a.analyze_firewall({'firewall':obs},{'firewall':{'enabled':True}},RiskModel())]
    def test_all_query_errors_return_unknown_and_coverage_diagnostic(self):
        obs,errors=self.query(lambda *a,**k:subprocess.CompletedProcess(a[0],1,'','denied'))
        self.assertIsNone(obs.enabled);self.assertTrue(errors)
    def test_all_timeouts_return_unknown_and_coverage_diagnostic(self):
        def timeout(*a,**k):raise subprocess.TimeoutExpired('redacted',15)
        obs,errors=self.query(timeout);self.assertIsNone(obs.enabled);self.assertTrue(errors)
    def test_absent_all_optional_providers_is_unknown(self):
        def absent(*a,**k):raise FileNotFoundError()
        obs,errors=self.query(absent);self.assertIsNone(obs.enabled);self.assertTrue(errors)
    def test_known_disabled_state_still_alerts(self):self.assertEqual(self.detection(False),['host_firewall_disabled'])
    def test_unknown_state_survives_validation_and_does_not_alert_disabled(self):self.assertFalse(self.detection(None))
    def test_missing_firewall_field_stays_unknown(self):self.assertIsNone(validation._firewall({})['enabled'])
    def test_unknown_and_missing_baselines_do_not_claim_disable_transition(self):
        for old in ({},{'enabled':None},{'enabled':False}):
            self.assertFalse(a.analyze_firewall({'firewall':{'enabled':False}},{'firewall':old},RiskModel()))
    def test_explicit_successful_empty_ruleset_is_known_false(self):
        obs,errors=self.query(lambda *a,**k:subprocess.CompletedProcess(a[0],0,'',''))
        self.assertIs(obs.enabled,False);self.assertFalse(errors)
    def test_nonempty_ruleset_is_known_true(self):
        obs,errors=self.query(lambda *a,**k:subprocess.CompletedProcess(a[0],0,'table inet filter { }',''))
        self.assertIs(obs.enabled,True);self.assertFalse(errors)
    def test_failed_provider_empty_fallback_cannot_prove_disabled(self):
        def query(argv,**kw):return subprocess.CompletedProcess(argv,1 if argv[0]=='nft' else 0,'','')
        obs,errors=self.query(query);self.assertIsNone(obs.enabled);self.assertTrue(errors)
    def test_failed_provider_nonempty_fallback_retains_known_rules_and_errors(self):
        def query(argv,**kw):return subprocess.CompletedProcess(argv,1 if argv[0]=='nft' else 0,'' if argv[0]=='nft' else '*filter\nCOMMIT\n','')
        obs,errors=self.query(query);self.assertIs(obs.enabled,True);self.assertTrue(errors)
    def test_success_with_diagnostics_is_not_assumed_complete(self):
        obs,errors=self.query(lambda *a,**k:subprocess.CompletedProcess(a[0],0,'','warning'))
        self.assertIsNone(obs.enabled);self.assertTrue(errors)
    def test_malformed_ufw_output_is_unknown(self):
        def query(argv,**kw):
            if argv[0]!='ufw':raise FileNotFoundError()
            return subprocess.CompletedProcess(argv,0,'broken provider output','')
        obs,errors=self.query(query);self.assertIsNone(obs.enabled);self.assertTrue(errors)
    def test_ufw_inactive_is_known_when_other_providers_are_absent(self):
        def query(argv,**kw):
            if argv[0]!='ufw':raise FileNotFoundError()
            return subprocess.CompletedProcess(argv,0,'Status: inactive\n','')
        obs,errors=self.query(query);self.assertIs(obs.enabled,False);self.assertFalse(errors)
    def test_nonboolean_enabled_values_are_rejected(self):
        for v in (0,1,'false',[]):
            with self.assertRaises(validation.ValidationError):validation._firewall({'enabled':v})


class ServiceMetadata1999(unittest.TestCase):
    def collect(self,count=513,*,detail=None,clock=None,installed_extra=()):
        self.names=[f'unit-{i:04}.service' for i in range(count)];self.queries=[]
        def query(argv,**kw):
            self.queries.append((argv,kw))
            if argv[1]=='list-units':out=''.join(n+' loaded active running fixture\n' for n in self.names)
            elif argv[1]=='list-unit-files':out=''.join(n+' enabled enabled\n' for n in [*self.names,*installed_extra])
            elif argv[1]=='show':
                batch=[n for n in argv if n in self.names]
                out='\n\n'.join('Id='+n+'\nActiveState=active\nSubState=running\nUnitFileState=enabled\nNRestarts='+('7' if n==self.names[-1] else '0')+'\nResult=success\nExecMainStatus=0' for n in batch)+'\n'
                if detail is not None:return detail(argv,out,kw)
            else:raise AssertionError(argv)
            return subprocess.CompletedProcess(argv,0,out,'')
        errors=[]
        with ExitStack() as s:
            s.enter_context(patch.object(c,'_run',side_effect=query))
            if clock is not None:s.enter_context(patch.object(c.time,'monotonic',side_effect=lambda:clock[0]))
            rows=c._linux_services(errors)
        return rows,errors
    def test_513th_service_is_queried_and_restart_loop_detected(self):
        rows,errors=self.collect();self.assertFalse(errors);self.assertEqual(rows[-1].restart_count,7)
        live=asdict(rows[-1]);alerts=a.analyze_services({'services':[live]},{'services':[{**live,'restart_count':0}]},RiskModel())
        self.assertIn('service_restart_loop',[x.kind for x in alerts])
    def test_2000_loaded_services_use_four_bounded_batches(self):
        rows,errors=self.collect(2000);self.assertFalse(errors);self.assertEqual(len(rows),2000)
        sizes=[len(argv)-4 for argv,_ in self.queries if argv[1]=='show']
        self.assertEqual(sizes,[512,512,512,464]);self.assertEqual(rows[-1].restart_count,7)
    def test_exact_512_limit_needs_one_batch(self):
        rows,errors=self.collect(512);self.assertFalse(errors)
        self.assertEqual(len([a for a,k in self.queries if a[1]=='show']),1)
    def test_failed_second_batch_is_unknown_not_zero(self):
        def detail(argv,text,kw):return subprocess.CompletedProcess(argv,1 if self.names[-1] in argv else 0,text,'')
        rows,errors=self.collect(detail=detail);self.assertTrue(errors);self.assertIsNone(rows[-1].restart_count)
        self.assertEqual(rows[-1].result,'unknown');self.assertEqual(rows[0].restart_count,0)
    def test_timeout_keeps_earlier_good_details(self):
        def detail(argv,text,kw):
            if self.names[-1] in argv:raise subprocess.TimeoutExpired('systemctl',kw['timeout'])
            return subprocess.CompletedProcess(argv,0,text,'')
        rows,errors=self.collect(detail=detail);self.assertTrue(errors);self.assertIsNone(rows[-1].restart_count);self.assertEqual(rows[0].restart_count,0)
    def test_one_budget_is_shared_across_batches(self):
        clock=[10.0]
        def detail(argv,text,kw):clock[0]+=4;return subprocess.CompletedProcess(argv,0,text,'')
        rows,errors=self.collect(2000,detail=detail,clock=clock)
        self.assertFalse(errors);self.assertEqual([kw['timeout'] for a,kw in self.queries if a[1]=='show'],[20,16,12,8])
    def test_late_first_batch_is_not_accepted_or_followed_by_new_query(self):
        clock=[10.0]
        def detail(argv,text,kw):clock[0]+=21;return subprocess.CompletedProcess(argv,0,text,'')
        rows,errors=self.collect(detail=detail,clock=clock)
        self.assertTrue(errors);self.assertTrue(all(r.restart_count is None for r in rows))
        self.assertEqual(len([a for a,k in self.queries if a[1]=='show']),1)
    def test_missing_requested_record_reports_incomplete(self):
        rows,errors=self.collect(1,detail=lambda argv,text,kw:subprocess.CompletedProcess(argv,0,'',''))
        self.assertTrue(errors);self.assertIsNone(rows[0].restart_count)
    def test_duplicate_record_is_not_accepted(self):
        rows,errors=self.collect(1,detail=lambda argv,text,kw:subprocess.CompletedProcess(argv,0,text+'\n'+text,''))
        self.assertTrue(errors);self.assertIsNone(rows[0].restart_count)
    def test_duplicate_numeric_field_is_discarded_not_treated_as_evidence(self):
        rows,errors=self.collect(1,detail=lambda argv,text,kw:subprocess.CompletedProcess(argv,0,text.replace('NRestarts=7','NRestarts=7\nNRestarts=0'),''))
        self.assertTrue(errors);self.assertIsNone(rows[0].restart_count)

    def test_repair_evidence_does_not_invent_zero_delta_for_unknown_counter(self):
        from sentinel_blue.service_repair import native_fault_findings
        result=native_fault_findings('fixture',{'substate':'auto-restart','restart_count':None},{'restart_count':0})
        self.assertTrue(result)
        self.assertIsNone(result[0]['evidence']['restarts_since_baseline'])

    def test_missing_numeric_and_result_fields_are_unknown(self):
        def detail(argv,text,kw):return subprocess.CompletedProcess(argv,0,'Id='+self.names[0]+'\n','')
        rows,errors=self.collect(1,detail=detail);self.assertTrue(errors);self.assertIsNone(rows[0].restart_count);self.assertEqual(rows[0].result,'unknown')
    def test_oversized_numeric_field_does_not_crash_or_become_zero(self):
        rows,errors=self.collect(1,detail=lambda argv,text,kw:subprocess.CompletedProcess(argv,0,text.replace('NRestarts=7','NRestarts='+'9'*5000),''))
        self.assertTrue(errors);self.assertIsNone(rows[0].restart_count)
    def test_unloaded_installed_unit_is_not_in_detail_query(self):
        rows,errors=self.collect(1,installed_extra=('unloaded.service',))
        self.assertFalse(errors);self.assertIsNone(rows[-1].restart_count);self.assertEqual(rows[-1].result,'unknown')
        self.assertNotIn('unloaded.service',next(argv for argv,kw in self.queries if argv[1]=='show'))
    def test_nullable_count_survives_validation(self):
        row=validation._service({'name':'fixture','state':'running','restart_count':None},0)
        self.assertIsNone(row['restart_count'])
    def test_legacy_omitted_count_retains_wire_compatibility(self):self.assertEqual(validation._service({'name':'fixture'},0)['restart_count'],0)
    def test_invalid_counts_are_rejected_not_coerced(self):
        for v in (-1,True,'7',2**31):
            with self.assertRaises(validation.ValidationError):validation._service({'name':'fixture','restart_count':v},0)
    def test_unknown_counter_does_not_invent_a_restart_delta(self):
        for before,current in ((None,7),(0,None),(None,None)):
            alerts=a.analyze_services({'services':[{'name':'fixture','result':'success','restart_count':current}]},
                {'services':[{'name':'fixture','restart_count':before}]},RiskModel())
            self.assertFalse(alerts)
    def test_known_failed_restarting_service_still_alerts_with_unknown_baseline(self):
        alerts=a.analyze_services({'services':[{'name':'fixture','result':'exit-code','restart_count':7}]},
            {'services':[{'name':'fixture','restart_count':None}]},RiskModel())
        self.assertIn('service_restart_loop',[x.kind for x in alerts])


class TelemetryWire1999(unittest.TestCase):
    def test_unknown_firewall_and_service_count_survive_the_complete_wire_boundary(self):
        payload={'agent_id':'fixture-agent','hostname':'fixture','platform':'Linux','observed_at':time.time(),
                 'firewall':{'enabled':None},'services':[{'name':'fixture.service','state':'running','restart_count':None}],
                 'collector_errors':['firewall unavailable','service metadata unavailable']}
        normalized=validation.validate_telemetry(json.loads(json.dumps(payload)))
        self.assertIsNone(normalized['firewall']['enabled'])
        self.assertIsNone(normalized['services'][0]['restart_count'])
        kinds=[x.kind for x in detect(normalized,{'firewall':{'enabled':True},'services':[{'name':'fixture.service','restart_count':0}]},set(),RiskModel())]
        self.assertIn('telemetry_degraded',kinds)
        self.assertNotIn('host_firewall_disabled',kinds)
        self.assertNotIn('service_restart_loop',kinds)

    def test_known_false_firewall_still_survives_the_wire_boundary(self):
        payload={'agent_id':'fixture-agent','hostname':'fixture','platform':'Linux','observed_at':time.time(),
                 'firewall':{'enabled':False},'services':[]}
        normalized=validation.validate_telemetry(payload)
        self.assertIs(normalized['firewall']['enabled'],False)
        kinds=[x.kind for x in detect(normalized,{'firewall':{'enabled':True}},set(),RiskModel())]
        self.assertIn('host_firewall_disabled',kinds)

if __name__=='__main__':unittest.main(verbosity=2)
