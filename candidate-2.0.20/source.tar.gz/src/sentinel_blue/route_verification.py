"""Bind downstream health to a fresh connection witnessed by the intended router."""
from __future__ import annotations
from .runtime_environment import target_python_shell
import base64
import ipaddress
import json
import socket
import time
import uuid
from importlib.resources import files
from urllib.parse import urlparse


def endpoint(probe):
    kind = probe.get('kind')
    if kind in {'http', 'https'}:
        parsed = urlparse(probe['target'])
        return parsed.hostname, parsed.port or (443 if parsed.scheme == 'https' else 80)
    if kind == 'tcp':
        return probe.get('host') or probe.get('target'), probe['port']
    raise ValueError('Routed setup proof currently requires a TCP or HTTP(S) transaction')


def compile_paths(options, probes, router_address, profile):
    rows = options.get('path_checks', [])
    if not isinstance(rows, list) or len(rows) > 16:
        raise ValueError('Router path_checks must contain at most 16 entries')
    paths = {}
    for row in rows:
        if not isinstance(row, dict) or set(row) != {'probe_index', 'source_address', 'in_interface', 'out_interface'}:
            raise ValueError('Router path_checks require probe_index, source_address and both interfaces')
        index = row['probe_index']
        if type(index) is not int or not 0 <= index < len(probes) or index in paths:
            raise ValueError('Router path probe indexes must be distinct and valid')
        target, port = endpoint(probes[index])
        if type(port) is not int or not 1 <= port <= 65535:
            raise ValueError('Invalid routed destination port')
        source = str(ipaddress.ip_address(row['source_address']))
        for address in (source, target):
            parsed = ipaddress.ip_address(address)
            if parsed.version != 4 or parsed.is_loopback or parsed.is_unspecified or parsed.is_multicast or address == router_address:
                raise ValueError('Router path proof requires separate unicast IPv4 source and downstream hosts')
            profile.assert_target(address)
        if source == target:
            raise ValueError('Route proof source must differ from its destination')
        from .network_setup import identifier
        incoming = identifier(row['in_interface'], 'route ingress interface', 15)
        outgoing = identifier(row['out_interface'], 'route egress interface', 15)
        if not any(ipaddress.ip_address(source) in ipaddress.ip_network(rule['source'])
                   and ipaddress.ip_address(target) in ipaddress.ip_network(rule['destination'])
                   and incoming == rule['in_interface'] and outgoing == rule['out_interface']
                   and (not rule.get('protocol') or rule['protocol'] == 'tcp' and rule['port'] == port)
                   for rule in options.get('forward', [])):
            raise ValueError('Router path probe must match a declared forwarding rule')
        paths[index] = {'router_name': options['name'], 'source': source, 'destination': target,
                        'destination_port': port, 'in_interface': incoming, 'out_interface': outgoing}
    if options.get('forward') or options.get('routes') or options.get('masquerade'):
        downstream = {i for i, p in enumerate(probes) if
                      (urlparse(p.get('target', '')).hostname if p.get('kind') in {'http', 'https'} else p.get('host', p.get('target'))) != router_address}
        if not downstream or set(paths) != downstream:
            raise ValueError('Every downstream router probe requires an explicit path_checks entry')
    return {str(key): value for key, value in paths.items()}


def script(phase, flow, token):
    source = files('sentinel_blue').joinpath('route_check_native.py').read_text(encoding='utf-8')
    encoded = base64.b64encode(source.encode()).decode()
    data = base64.b64encode(json.dumps(flow, sort_keys=True).encode()).decode()
    return (f"set -eu\n{target_python_shell()} -I -B - <<'SENTINEL_ROUTE_WITNESS'\nimport base64,json\n"
            f"source=base64.b64decode('{encoded}').decode(); ns={{'__name__':'sentinel_route_witness'}}\n"
            "exec(compile(source,'sentinel-route-witness','exec'),ns)\n"
            f"ns['run']('{phase}',json.loads(base64.b64decode('{data}')),'{token}',source)\n"
            "SENTINEL_ROUTE_WITNESS\n")


def verify(runner, task, host, index, spec, deadline):
    from .runtime_environment import target_runtime, host_python
    with target_runtime(host_python(host)):
        return _verify(runner, task, host, index, spec, deadline)


def _verify(runner, task, host, index, spec, deadline):
    flow = dict(task['route_paths'][str(index)])
    token = uuid.uuid4().hex
    result = {'kind': 'router-path', 'healthy': False, 'router': host['address'],
              'source': flow['source'], 'destination': flow['destination'],
              'in_interface': flow['in_interface'], 'out_interface': flow['out_interface']}
    armed = False
    finished = False
    # Reserve a fresh source port while preparing the remote witness. The probe
    # uses this exact local endpoint, with proxies disabled and a pinned target.
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as reservation:
        try:
            reservation.bind((flow['source'], 0))
            flow['source_port'] = reservation.getsockname()[1]
            result['source_port'] = flow['source_port']
            available = min(runner.remaining(), deadline - time.monotonic())
            if available < 1:
                return result
            armed = True  # An uncertain arm still needs cleanup/expiry.
            response = runner._command(host, script('arm', flow, token), min(10, available / 3))
            if response.uncertain or response.returncode != 0:
                return result | {'reason': 'route witness could not be armed', 'uncertain': response.uncertain}
            reservation.close()
            available = min(runner.remaining(), deadline - time.monotonic())
            if available < 0.5:
                return result
            probe_spec = dict(spec, timeout=min(spec['timeout'], available / 2))
            probe = runner.probe(probe_spec, list(runner.profile.authorized_networks),
                                 authorized_hosts=runner.profile.authorized_hosts,
                                 excluded_hosts=runner.profile.excluded_hosts,
                                 source_address=(flow['source'], flow['source_port']))
            response = runner._command(host, script('finish', flow, token), min(10, max(0, deadline-time.monotonic())))
            finished = not response.uncertain and response.returncode in {0, 10}
            return result | {'healthy': probe.healthy and finished and response.returncode == 0,
                             'application_healthy': probe.healthy, 'path_witnessed': finished and response.returncode == 0,
                             'latency_ms': probe.latency_ms, 'uncertain': response.uncertain}
        except Exception as exc:
            return result | {'error_type': type(exc).__name__}
        finally:
            if armed and not finished and runner.remaining() > 0:
                try:
                    runner._command(host, script('cancel', flow, token), min(10, runner.remaining()))
                except Exception:
                    pass  # The root-owned native expiry timer remains active.
