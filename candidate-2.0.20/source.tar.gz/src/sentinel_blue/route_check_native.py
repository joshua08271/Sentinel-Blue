"""Temporary forward-path witnesses for one fresh, explicitly scoped TCP flow.

These rules only count packets. They never add an allow exception. A native
systemd timer removes the witness if the checking client disappears.
"""
from __future__ import annotations
import fcntl
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import time
import uuid

ROOT = Path('/var/lib/sentinel-blue-route-checks')


def secure(path, create=False):
    if not path.exists() and create:
        secure(path.parent, True)
        path.mkdir(mode=0o700)
    for parent in (path, *path.parents):
        info = parent.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
            raise ValueError('Route witness state requires trusted root-owned directories')


def read(path):
    """Read one bounded, stable, regular witness record without FIFO blocking."""
    secure(path.parent)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        info = os.fstat(fd)
        limit = 65536
        if not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or info.st_nlink != 1 or info.st_size > limit or info.st_mode & 0o077:
            raise ValueError('Untrusted route witness record')
        data = bytearray()
        while len(data) <= limit:
            block = os.read(fd, min(65536, limit + 1 - len(data)))
            if not block:
                break
            data.extend(block)
        if len(data) > limit:
            raise ValueError('Route witness record exceeds the read limit')
        def revision(st):
            return (st.st_dev, st.st_ino, st.st_mode, st.st_uid, st.st_gid,
                    st.st_nlink, st.st_size, st.st_mtime_ns, st.st_ctime_ns)
        if revision(info) != revision(os.fstat(fd)) or revision(info) != revision(path.lstat()):
            raise ValueError('Route witness record changed during read')
        return json.loads(bytes(data))
    finally:
        os.close(fd)


def write(path, data):
    secure(path.parent)
    temp = path.with_name('.' + path.name + '.' + uuid.uuid4().hex)
    fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, 'w') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def command(args, data=None, allowed=(0,)):
    r = subprocess.run(args, input=data, text=True, capture_output=True, timeout=10,
                       env={'PATH': '/usr/sbin:/usr/bin:/sbin:/bin', 'LANG': 'C.UTF-8'})
    if r.returncode not in allowed:
        raise RuntimeError('Native route witness command failed: ' + args[0])
    return r


def table(token):
    return 'sentinel_path_' + token


def inspect_table(token):
    r = command(['nft', '-j', 'list', 'table', 'inet', table(token)], allowed=(0, 1))
    if r.returncode:
        listing = json.loads(command(['nft', '-j', 'list', 'tables']).stdout)
        if any(row.get('table', {}).get('name') == table(token) and row['table']['family'] == 'inet' for row in listing['nftables']):
            raise RuntimeError('Route witness could not be read')
        return None
    return json.loads(r.stdout)


def signature(value):
    def clean(item):
        if isinstance(item, list):
            return [clean(x) for x in item if not isinstance(x, dict) or 'metainfo' not in x]
        if isinstance(item, dict):
            return {k: clean(v) for k, v in item.items() if k not in {'handle', 'index', 'packets', 'bytes'}}
        return item
    return hashlib.sha256(json.dumps(clean(value), sort_keys=True).encode()).hexdigest()


def normalize(flow):
    expected = {'router_name', 'source', 'destination', 'source_port', 'destination_port', 'in_interface', 'out_interface'}
    if set(flow) != expected:
        raise ValueError('Invalid route witness fields')
    for key in ('source', 'destination'):
        address = ipaddress.ip_address(flow[key])
        if address.version != 4 or address.is_unspecified or address.is_multicast or address.is_loopback:
            raise ValueError('A routed witness requires distinct unicast IPv4 hosts')
    if flow['source'] == flow['destination']:
        raise ValueError('A routed witness requires different endpoints')
    for key in ('source_port', 'destination_port'):
        if type(flow[key]) is not int or not 1 <= flow[key] <= 65535:
            raise ValueError('Invalid routed TCP port')
    for key in ('router_name', 'in_interface', 'out_interface'):
        if not isinstance(flow[key], str) or not re.fullmatch('[A-Za-z][A-Za-z0-9_-]{0,31}', flow[key]):
            raise ValueError('Invalid route witness identifier')
    return flow


def packet_counts(value):
    """Require a real forward chain and two distinct anonymous counter rules."""
    rows = value.get('nftables', []) if isinstance(value, dict) else []
    chains = [row['chain'] for row in rows if 'chain' in row]
    rules = [row['rule'] for row in rows if 'rule' in row]
    if (len(chains) != 1 or chains[0].get('name') != 'witness'
            or chains[0].get('type') != 'filter' or chains[0].get('hook') != 'forward'
            or chains[0].get('prio') != 20 or chains[0].get('policy') != 'accept'
            or len(rules) != 2):
        raise ValueError('Native route witness is incomplete')
    counts = {}
    for rule in rules:
        name = rule.get('comment')
        counters = [x['counter'].get('packets') for x in rule.get('expr', [])
                    if isinstance(x, dict) and isinstance(x.get('counter'), dict)]
        if (rule.get('chain') != 'witness' or name not in {'request', 'reply'} or name in counts
                or len(counters) != 1 or type(counters[0]) is not int or counters[0] < 0):
            raise ValueError('Native route witness counters are incomplete')
        counts[name] = counters[0]
    return counts


def expire(base, state, *, timer=False):
    value = inspect_table(state['token'])
    if value is not None:
        if not state.get('signature') or signature(value) != state['signature']:
            raise ValueError('Route witness rules changed; automatic removal is held')
        command(['nft', 'delete', 'table', 'inet', table(state['token'])])
    if not timer:
        command(['systemctl', 'stop', 'sentinel-path-' + state['token'] + '.timer'], allowed=(0, 5))
    state['status'] = 'closed'
    write(base / 'state.json', json.dumps(state, sort_keys=True))


def run(phase, flow, token, source):
    if os.geteuid() != 0 or not re.fullmatch('[0-9a-f]{32}', token):
        raise PermissionError('Route proof requires root and a fresh witness identity')
    normalize(flow)
    if phase not in {'arm', 'finish', 'cancel', 'expire'}:
        raise ValueError('Invalid route witness phase')
    secure(ROOT, True)
    base = ROOT / token
    if phase == 'arm':
        if base.exists() or base.is_symlink() or inspect_table(token) is not None:
            raise ValueError('A route witness cannot be replayed')
        secure(base, True)
    else:
        secure(base)
    fd = os.open(base / 'lock', os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_uid != 0 or info.st_mode & 0o077:
            raise ValueError('Untrusted route witness lock')
        deadline = time.monotonic() + 5
        while True:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() >= deadline:
                    raise ValueError('Route witness cleanup is still active') from None
                time.sleep(0.05)
        state_path = base / 'state.json'
        if phase == 'arm':
            state = {'status': 'pending', 'flow': flow, 'token': token,
                     'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
                     'expires': time.monotonic() + 60}
            write(base / 'native.py', source)
            write(state_path, json.dumps(state, sort_keys=True))
            command(['systemd-run', '--quiet', '--unit=sentinel-path-' + token, '--on-active=60s',
                     '--timer-property=AccuracySec=1s', '--property=Type=oneshot',
                     sys.executable, '-I', '-B', str(base / 'native.py'), 'expire', str(state_path)])
            a, b, sport, dport = flow['source'], flow['destination'], flow['source_port'], flow['destination_port']
            incoming, outgoing = flow['in_interface'], flow['out_interface']
            # nft 1.0.9 accepts a nested `create table` block while omitting its
            # chains/rules. Use explicit operations in one atomic transaction.
            prefix = f'inet {table(token)}'
            rules = (f'create table {prefix}\n'
                     f'add chain {prefix} witness {{ type filter hook forward priority 20; policy accept; }}\n'
                     f'add rule {prefix} witness iifname "{incoming}" oifname "{outgoing}" ip saddr {a} ip daddr {b} tcp sport {sport} tcp dport {dport} tcp flags & (syn | ack) == syn counter comment "request"\n'
                     f'add rule {prefix} witness iifname "{outgoing}" oifname "{incoming}" ip saddr {b} ip daddr {a} tcp sport {dport} tcp dport {sport} tcp flags & (syn | ack) == (syn | ack) counter comment "reply"\n')
            command(['nft', '--check', '--file', '-'], rules)
            command(['nft', '--file', '-'], rules)
            created = inspect_table(token)
            state['signature'] = signature(created)
            write(state_path, json.dumps(state, sort_keys=True))
            packet_counts(created)
            return
        state = read(state_path)
        if state['flow'] != flow or state['token'] != token:
            raise ValueError('Route witness identity changed')
        if phase in {'cancel', 'expire'}:
            expire(base, state, timer=phase == 'expire')
            return
        valid = (state['status'] == 'pending' and time.monotonic() < state['expires']
                 and state['boot_id'] == Path('/proc/sys/kernel/random/boot_id').read_text().strip())
        value = inspect_table(token)
        counts = {}
        if value is not None and signature(value) == state.get('signature'):
            try:
                counts = packet_counts(value)
            except ValueError:
                valid = False
        else:
            valid = False
        valid = valid and set(counts) == {'request', 'reply'} and all(type(x) is int and x > 0 for x in counts.values())
        state['counts'] = counts
        expire(base, state)
        raise SystemExit(0 if valid else 10)
    finally:
        os.close(fd)


if __name__ == '__main__':
    if len(sys.argv) != 3 or sys.argv[1] != 'expire':
        raise SystemExit(20)
    path = Path(sys.argv[2])
    state = read(path)
    if path != ROOT / state['token'] / 'state.json':
        raise SystemExit(20)
    run('expire', state['flow'], state['token'], Path(__file__).read_text())
