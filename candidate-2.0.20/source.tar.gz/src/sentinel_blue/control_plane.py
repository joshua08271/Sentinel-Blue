"""Optional dedicated-management contract, bound into the event fingerprint.

This is configuration enforcement, not VM attestation or a substitute for a
trusted hypervisor/network. Existing profiles retain their existing behavior.
An isolated profile never grants a permission absent from the event profile.
"""
from __future__ import annotations

import ipaddress
import re
from urllib.parse import urlsplit

MODE = 'dedicated-management'
MAX_AGENTS = 64


def address(value, *, loopback=False):
    if not isinstance(value, str) or '%' in value:
        raise ValueError('Control-plane addresses must be literal IP addresses without zone IDs')
    parsed = ipaddress.ip_address(value)
    if getattr(parsed, 'ipv4_mapped', None):
        parsed = parsed.ipv4_mapped
    if parsed.version != 4:
        raise ValueError('Dedicated control-plane transport currently requires IPv4 addresses; IPv6 service checks are unchanged')
    if str(parsed) == '255.255.255.255':
        raise ValueError('Broadcast addresses cannot identify a role')
    if parsed.is_unspecified or parsed.is_multicast or parsed.is_link_local or (parsed.is_loopback and not loopback):
        raise ValueError('Dedicated roles require unicast, non-loopback, non-link-local addresses')
    return str(parsed)


def contract(profile):
    raw = profile if isinstance(profile, dict) else profile.raw
    return raw.get('control_plane')


def validate_profile(raw):
    """Validate without side effects; the caller includes this object in its hash."""
    c = contract(raw)
    if c is None:
        return
    required = {'mode', 'controller_address', 'controller_port', 'operator_ingress_hosts',
                'agent_addresses', 'separate_host_confirmed', 'authorization_reference'}
    if not isinstance(c, dict) or set(c) != required or c.get('mode') != MODE:
        raise ValueError('Invalid dedicated-management control_plane contract')
    if c['separate_host_confirmed'] is not True:
        raise ValueError('Confirm a separate authorized team-controlled management host')
    ref = c['authorization_reference']
    if not isinstance(ref, str) or not 1 <= len(ref.strip()) <= 256 or any(ord(x) < 32 for x in ref):
        raise ValueError('Provide a bounded management-host authorization reference')
    controller = address(c['controller_address'])
    if c['controller_address'] != controller:
        raise ValueError('Use canonical control-plane addresses')
    port = c['controller_port']
    if type(port) is not int or not 1024 <= port <= 65535:
        raise ValueError('Dedicated controller port must be 1024–65535')
    agents = c['agent_addresses']
    if not isinstance(agents, dict) or not 1 <= len(agents) <= MAX_AGENTS:
        raise ValueError('Dedicated management requires 1–64 explicit agent addresses')
    from .validation import validate_agent_id
    for identifier, value in agents.items():
        validate_agent_id(identifier)
        if identifier in {'controller', 'relay', 'observer'} or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,63}', identifier):
            raise ValueError('Use a unique filename-safe host agent ID, not a controller/observer ID')
        if value != address(value):
            raise ValueError('Use canonical agent addresses')
    if len(set(agents.values())) != len(agents) or controller in agents.values():
        raise ValueError('Controller and every defended VM require distinct addresses')
    operators = c['operator_ingress_hosts']
    if not isinstance(operators, list) or not 1 <= len(operators) <= 16:
        raise ValueError('Declare 1–16 exact operator source addresses')
    if any(value != address(value, loopback=True) for value in operators) or len(set(operators)) != len(operators):
        raise ValueError('Operator source addresses must be unique and canonical')
    if set(operators) & set(agents.values()):
        raise ValueError('A defended VM cannot be an operator source in dedicated mode')
    if controller not in operators:
        raise ValueError('Include the management address as an operator source for its local GUI')
    hosts = set(raw.get('scope', {}).get('authorized_hosts', []))
    required_hosts = {controller, *operators, *agents.values()}
    if not required_hosts <= hosts:
        raise ValueError('Every management, operator and agent address must already be authorized')
    ingress = set(raw.get('scope', {}).get('controller_ingress_hosts', []))
    if ingress != set(operators) | set(agents.values()):
        raise ValueError('Isolated ingress must exactly match declared operator and agent sources')
    if not raw.get('capabilities', {}).get('external_controller'):
        raise ValueError('The event must explicitly permit external_controller')
    services = raw.get('services', [])
    if not services or {row.get('host') for row in services} != set(agents):
        raise ValueError('Every isolated agent needs a service contract; controller hosts cannot be scored-service targets')
    for service in services:
        for check in service.get('expected_transactions', []):
            target = str(check.get('target', ''))
            if '://' in target:
                target = urlsplit(target).hostname
            if target == controller:
                raise ValueError('A defended-service check cannot use the controller as its service endpoint')


def validate_inventory(inventory, profile, *, complete=False):
    c = contract(profile)
    if c is None:
        return
    seen = set()
    for row in inventory.get('hosts', []):
        identifier = row.get('agent_id', row.get('name'))
        if identifier in seen or identifier not in c['agent_addresses']:
            raise ValueError('Isolated inventory requires distinct approved agent identities')
        seen.add(identifier)
        if address(row.get('address')) != c['agent_addresses'][identifier]:
            raise ValueError('Isolated inventory address does not match its agent identity')
        if row.get('transport') == 'local':
            raise ValueError('Dedicated management never deploys defended services through local transport')
    if complete and seen != set(c['agent_addresses']):
        raise ValueError('The isolated inventory must cover every declared agent')


def local_addresses():
    from .linux_workspace import local_host_addresses
    values = local_host_addresses()
    if not values:
        raise ValueError('Cannot establish this host’s addresses; isolated startup is held')
    return set(values)


def validate_startup(profile, role, args, *, observed_addresses=None):
    c = contract(profile)
    if c is None:
        return
    # The optional explicit observation is for deterministic unit tests only;
    # CLI/GUI callers always collect the real interface inventory.
    own = set(local_addresses() if observed_addresses is None else observed_addresses)
    if role == 'controller':
        if args.bind != c['controller_address'] or args.port != c['controller_port']:
            raise ValueError('Controller must bind only its approved management address and port')
        if c['controller_address'] not in own or own & set(c['agent_addresses'].values()):
            raise ValueError('Controller must run on the separate management host, not a defended VM')
        if getattr(args, 'syslog_bind', None):
            raise ValueError('Dedicated mode does not open an unauthenticated syslog listener')
    elif role == 'agent':
        expected = c['agent_addresses'].get(getattr(args, 'agent_id', None))
        if not expected or expected not in own or c['controller_address'] in own:
            raise ValueError('Agent must run on its own approved defended VM, not the controller host')
        parsed = urlsplit(args.controller)
        if (parsed.scheme != 'https' or parsed.hostname != c['controller_address']
                or parsed.port != c['controller_port'] or parsed.username or parsed.password
                or parsed.query or parsed.fragment or parsed.path not in ('', '/')):
            raise ValueError('Agent origin must be the exact HTTPS dedicated controller')
    else:
        raise ValueError('Unknown isolated runtime role')


def request_allowed(profile, method, path, source, agent_id=None):
    """Additional source/role gate, never a substitute for signed authentication.

    Uses the actual socket peer, never X-Forwarded-For. Shared-source NAT, proxies
    and remote operator access from a scored guest are intentionally unsupported.
    """
    c = contract(profile)
    if c is None:
        return True
    try:
        source = address(source, loopback=True)
    except ValueError:
        return False
    operators = set(c['operator_ingress_hosts'])
    agents = c['agent_addresses']
    if method == 'GET' and path == '/api/v1/health':
        return source in operators or source in agents.values()
    if path.startswith('/api/v1/agent/'):
        return agents.get(agent_id) == source
    # Includes dashboard, readiness, auth-info, setup governance, recording,
    # backup/recovery and observer APIs. Observer credentials still need their
    # own verification; only a declared management-side source can submit here.
    return source in operators
