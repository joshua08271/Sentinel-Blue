"""Allow Sentinel on a host again after an executed Emergency withdrawal.

An executed withdrawal pauses the host for good: no Sentinel controller, agent
or setup job starts there until a person decides one may. This command is that
decision. It needs the withdrawal's operation id (from its report), so it is
not something a script stumbles into; it refuses while any change is still in
flight; and it changes nothing on the host. Every object the withdrawal held
for review stays held and on record.
"""
from __future__ import annotations

import json
import os
import sys


def status_text(operation, report=None, error=None):
    lines = []
    if operation is None:
        return "No withdrawal is pausing this host; Sentinel may run here."
    if report and report.get("status") == "released":
        lines.append(f"Withdrawal {operation} no longer pauses this host.")
    else:
        lines.append(f"Withdrawal {operation} is pausing this host: no Sentinel controller, agent or setup job starts.")
    if error:
        lines.append("It cannot be released yet: " + error)
    elif report and report.get("status") == "released":
        lines.append("Released. Sentinel may run on this host again; start a new reviewed session.")
    else:
        lines.append("Review its report first. To allow Sentinel here again, run:")
        lines.append(f"  sentinel-blue withdraw-release --operation-id {operation}")
    held = (report or {}).get("held_conflicts") or []
    if held:
        lines.append(f"{len(held)} object(s) the withdrawal held for review stay held and on record.")
    return "\n".join(lines)


def run(args) -> int:
    from .mutation_ledger import LedgerError, MutationLedger
    if os.name != "nt" and os.geteuid() != 0:
        print("withdraw-release requires administrator (root) access.", file=sys.stderr)
        return 2
    ledger = MutationLedger()
    operation = ledger.withdrawal_operation()
    requested = getattr(args, "operation_id", None)
    report, error = None, None
    try:
        if operation is not None:
            if requested is not None and requested != operation:
                raise LedgerError("That is not the withdrawal pausing this host")
            report = ledger.release_after_withdrawal(operation, check_only=requested is None)
    except LedgerError as exc:
        error = str(exc)
    if getattr(args, "json", False):
        print(json.dumps({"operation_id": operation, "report": report, "error": error}, indent=2, sort_keys=True))
    else:
        print(status_text(operation, report, error))
    if error or (requested is not None and (report or {}).get("status") != "released"):
        return 2
    return 0
