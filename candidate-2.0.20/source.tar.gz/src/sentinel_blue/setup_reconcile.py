"""Reconcile setup transactions left uncertain on this host.

An uncertain setup holds every later setup and all automatic recovery until it
is resolved. `reconcile_uncertain` closes one only when its objects are exactly
in their recorded before-state; anything else is reported, not changed.
"""

from __future__ import annotations


def report_text(report) -> str:
    if not report:
        return "No uncertain setup transactions on this host."
    lines = []
    for row in report:
        if row["result"] == "reconciled" and row.get("outcome") == "took effect":
            lines.append(f"{row['service']}: reconciled — its approved setup is in place and is now recorded as done "
                         "(Withdraw can still reverse it)")
        elif row["result"] == "reconciled":
            lines.append(f"{row['service']}: reconciled — nothing it began remains changed")
        else:
            lines.append(f"{row['service']}: held — {row.get('reason', 'review required')}")
    if any(row["result"] != "reconciled" for row in report):
        lines.append("A held setup is neither undone nor in its approved state. Review it under Withdraw → Review, "
                     "or put the named difference back and reconcile again.")
    return "\n".join(lines)


def run(args) -> int:
    import json
    import sys
    from .setup_linux_transaction import reconcile_uncertain
    try:
        report = reconcile_uncertain()
    except (OSError, ValueError, RuntimeError) as exc:
        print("setup-reconcile: " + str(exc), file=sys.stderr)
        return 2
    print(json.dumps(report, indent=2) if getattr(args, "json", False) else report_text(report))
    return 0 if all(row["result"] == "reconciled" for row in report) else 1
