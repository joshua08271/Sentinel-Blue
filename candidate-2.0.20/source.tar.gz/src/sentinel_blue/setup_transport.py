"""Authenticated, bounded transport for explicitly reviewed setup runbooks.

Scripts travel on stdin, not a process command line. Output is deliberately not
returned: setup scripts and package managers can print credentials. Reports
contain return codes, timings, and output hashes instead.
"""

from __future__ import annotations

import base64
import hashlib
import ipaddress
import math
import os
import signal
import shutil
import shlex
import subprocess
import tempfile
import time
import uuid
from dataclasses import dataclass, replace
from contextlib import ExitStack
from pathlib import Path
from typing import Any

from .launcher import DeploymentStep, _powershell_executable, _ssh_base


@dataclass(frozen=True)
class CommandResult:
    returncode: int | None
    seconds: float
    uncertain: bool = False
    output_sha256: str = ""
    output_log: str | None = None
    output_bytes: int = 0
    output_truncated: bool = False
    failure_reason: str | None = None


def _ps(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def powershell_environment(executable: str) -> dict[str, str] | None:
    # Python launched from pwsh inherits its PS7 module paths. Windows
    # PowerShell cannot load those modules: let it construct its own defaults.
    if Path(executable).name.casefold() == "powershell.exe":
        return {key: value for key, value in os.environ.items() if key.upper() != "PSMODULEPATH"}
    return None


# Cleanup is additional to the execution deadline. Do not reap the session
# leader until the last group signal: its unreaped PID pins the group identity.
PROCESS_TERMINATION_GRACE = 2.0


def _terminate_posix_group(proc: subprocess.Popen) -> None:
    try:
        os.killpg(proc.pid, signal.SIGTERM)
    except ProcessLookupError:
        proc.wait(timeout=3)
        return
    deadline = time.monotonic() + PROCESS_TERMINATION_GRACE
    while time.monotonic() < deadline:
        try:
            os.killpg(proc.pid, 0)
        except ProcessLookupError:
            break
        time.sleep(min(0.05, max(0.0, deadline - time.monotonic())))
    # This must not depend on proc.wait()/poll(): the leader may have exited
    # while a child ignored TERM. Signal the still-owned group before reaping.
    try:
        os.killpg(proc.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    proc.wait(timeout=3)


# The capture limit bounds disk and hash work, not merely the final log copy.
MAX_COMMAND_OUTPUT_BYTES = 16 * 1024 * 1024


def _stop_command(proc):
    if os.name == 'posix':
        _terminate_posix_group(proc)
    else:
        subprocess.run(['taskkill', '/PID', str(proc.pid), '/T', '/F'],
                       stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL, timeout=5, check=False)
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=3)


def _output_blocks(proc, deadline):
    """Bounded pipe reads; never spool the child's output to an unlimited file."""
    if os.name == 'posix':
        import selectors
        os.set_blocking(proc.stdout.fileno(), False)
        with selectors.DefaultSelector() as ready:
            ready.register(proc.stdout, selectors.EVENT_READ)
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0 or not ready.select(remaining):
                    raise subprocess.TimeoutExpired('setup output', 0)
                try:
                    block = os.read(proc.stdout.fileno(), 65536)
                except BlockingIOError:
                    continue
                if not block:
                    return
                yield block
    else:
        # Windows 3.11 has no selectable anonymous pipes. The fixed-size queue
        # and read block preserve the same memory bound; taskkill closes owned
        # writers on cancellation. Never put raw output in an exception/report.
        import queue
        import threading
        blocks = queue.Queue(maxsize=2)
        stopped = threading.Event()
        def reader():
            try:
                while not stopped.is_set():
                    block = proc.stdout.read1(65536)
                    while not stopped.is_set():
                        try:
                            blocks.put(block, timeout=0.05)
                            break
                        except queue.Full:
                            pass
                    if not block:
                        return
            except OSError:
                while not stopped.is_set():
                    try:
                        blocks.put(None, timeout=0.05)
                        break
                    except queue.Full:
                        pass
        worker = threading.Thread(target=reader, name='sentinel-setup-output', daemon=True)
        worker.start()
        try:
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise subprocess.TimeoutExpired('setup output', 0)
                try:
                    block = blocks.get(timeout=remaining)
                except queue.Empty:
                    raise subprocess.TimeoutExpired('setup output', 0) from None
                if block is None:
                    raise OSError('Setup output capture failed')
                if not block:
                    return
                yield block
        finally:
            stopped.set()
            worker.join(timeout=0.2)


def run_process(argv: list[str], script: str, seconds: float, *, log_dir: Path | None = None,
                env: dict[str, str] | None = None) -> CommandResult:
    """Bound execution/output; overflow and timeout never authorize replay."""
    if type(seconds) not in (int, float) or not math.isfinite(seconds) or seconds <= 0:
        return CommandResult(None, 0, True, failure_reason='invalid_deadline')
    started = time.monotonic()
    deadline = started + seconds
    captured_bytes = 0
    digest = hashlib.sha256()
    log_name = None
    uncertain = False
    truncated = False
    failure_reason = None
    with ExitStack() as resources:
        log = None
        if log_dir is not None:
            from .credential_vault import private_directory
            guard = private_directory(log_dir)
            if guard is not None:
                resources.callback(guard.close)
            log_name = uuid.uuid4().hex + '.log'
            descriptor = os.open(log_dir / log_name, os.O_WRONLY | os.O_CREAT | os.O_EXCL |
                                 getattr(os, 'O_NOFOLLOW', 0), 0o600)
            log = resources.enter_context(os.fdopen(descriptor, 'wb'))
        # Stdin contains a finite, already-reviewed script. There is no output spool.
        incoming = resources.enter_context(tempfile.TemporaryFile())
        incoming.write(script.encode('utf-8'))
        incoming.seek(0)
        if time.monotonic() >= deadline:
            return CommandResult(None, time.monotonic() - started, True, digest.hexdigest(),
                                 log_name, failure_reason='deadline_before_launch')
        proc = subprocess.Popen(argv, stdin=incoming, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            env=env, start_new_session=os.name == 'posix',
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0)
        blocks = _output_blocks(proc, deadline)
        try:
            for block in blocks:
                count = min(len(block), MAX_COMMAND_OUTPUT_BYTES - captured_bytes)
                captured = block[:count]
                digest.update(captured)
                if log is not None:
                    log.write(captured)
                captured_bytes += count
                if count < len(block):
                    uncertain, truncated, failure_reason = True, True, 'output_limit_exceeded'
                    _stop_command(proc)
                    break
            else:
                # Do not reap the POSIX leader while a child still owns stdout:
                # a later group termination must retain its pinned group identity.
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise subprocess.TimeoutExpired('setup process', seconds)
                proc.wait(timeout=remaining)
                if time.monotonic() >= deadline:
                    uncertain, failure_reason = True, 'deadline_exceeded'
        except subprocess.TimeoutExpired:
            uncertain, truncated, failure_reason = True, True, 'deadline_exceeded'
            _stop_command(proc)
        except BaseException:
            # A capture/write failure must not strand an unobserved mutation.
            _stop_command(proc)
            raise
        finally:
            blocks.close()
            proc.stdout.close()
        return CommandResult(proc.returncode, time.monotonic() - started, uncertain,
                             digest.hexdigest(), log_name, captured_bytes, truncated, failure_reason)


class SetupTransport:
    """One command per host at a time; the scheduler owns concurrency."""

    def __init__(self, log_dir: Path | None = None):
        self.log_dir = log_dir
        self.management_updates = {}

    def set_management_password(self, host, name, password):
        if host.get("transport") == "winrm" and host.get("username", "").split("\\")[-1].casefold() == name.casefold():
            self.management_updates[host["name"]] = (host["username"], password)

    def execute_receipt(self, host, script, seconds, prefix):
        if prefix != 'SENTINEL_WITHDRAW_RESULT=' or self.log_dir is None:
            raise ValueError('Only private, explicitly requested withdrawal receipts are supported')
        return self.execute(host, script, seconds, receipt_prefix=prefix)

    def execute(self, host: dict[str, Any], script: str, seconds: float,
                *, receipt_prefix: str | None = None) -> CommandResult:
        if seconds <= 0:
            return CommandResult(None, 0, True)
        route = host["transport"]
        platform = host["platform"]
        if route == "local":
            if not ipaddress.ip_address(host["address"]).is_loopback:
                raise ValueError("local setup requires a loopback target on this machine")
            if platform != ("windows" if os.name == "nt" else "linux"):
                raise ValueError("local setup platform does not match this machine")
            if platform == "linux":
                return run_process(["bash", "-se"], script, seconds, log_dir=self.log_dir)
            return self._powershell(script, seconds)
        if route == "ssh":
            if platform != "linux":
                raise ValueError("setup SSH currently supports Linux bash targets")
            step = DeploymentStep(host["name"], host["address"], platform, route, "setup", [], host)
            if host.get("accept_new_host_key"):
                raise ValueError("setup requires an already verified SSH host key")
            options, target = _ssh_base(step)
            # GNU timeout is also installed on the remote host. Losing the SSH
            # client alone does not establish that a remote mutation stopped.
            budget = max(1, math.floor(seconds))
            remote = f"timeout --signal=TERM --kill-after=3s {budget}s bash -se"
            if host.get("sudo", True):
                remote = "sudo -n -- " + remote
            result = run_process(
                ["ssh", *options, "-o", "ConnectTimeout=10", "-o", "ServerAliveInterval=5",
                 "-o", "ServerAliveCountMax=2", target, remote], script, seconds, log_dir=self.log_dir,
            )
            if result.returncode in {124, 137, 143, 255}:
                return replace(result, uncertain=True)
            return result
        if route == "winrm":
            payload = base64.b64encode(script.encode()).decode()
            credential = ""
            credential_argument = ""
            if host.get("credential_file"):
                path = Path(host["credential_file"])
                if not path.is_file() or path.is_symlink():
                    raise ValueError("WinRM credential_file must be a private Export-Clixml file")
                credential = f"$credential = Import-Clixml -LiteralPath {_ps(str(path))}\n"
                if host["name"] in self.management_updates:
                    username, password = self.management_updates[host["name"]]
                    encoded_secret = base64.b64encode(password.encode()).decode()
                    credential += (f"if ($credential.UserName -ine {_ps(username)}) {{ throw 'Management identity changed' }}\n"
                        f"$updated = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('{encoded_secret}'))\n"
                        "$credential = [PSCredential]::new($credential.UserName, (ConvertTo-SecureString $updated -AsPlainText -Force))\n")
                credential_argument = " -Credential $credential"
            port = host.get("port", 5986)
            if type(port) is not int or not 1 <= port <= 65535:
                raise ValueError("invalid WinRM port")
            remote = (
                "$ErrorActionPreference = 'Stop'\ntry {\n" + credential +
                f"$session = New-PSSession -ComputerName {_ps(host['address'])} -Port {port} "
                "-UseSSL -Authentication Negotiate" + credential_argument + "\n"
                "try {\n"
                "  $code = Invoke-Command -Session $session -ScriptBlock { param($payload)\n"
                "    $script = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($payload))\n"
                "    $temp = Join-Path $env:TEMP ([IO.Path]::GetRandomFileName() + '.ps1')\n"
                "    try {\n"
                "      [IO.File]::WriteAllText($temp, $script, [Text.UTF8Encoding]::new($false))\n"
                "      & powershell.exe -NoLogo -NoProfile -NonInteractive -File $temp *> $null\n"
                "      return [int]$LASTEXITCODE\n"
                "    } finally { Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue }\n"
                f"  }} -ArgumentList '{payload}'\n"
                "  if (@($code).Count -ne 1) { exit 255 }\n"
                "  exit ([int]$code)\n"
                "} finally { Remove-PSSession -Session $session }\n"
                "} catch { exit 255 }\n"
            )
            if receipt_prefix is not None:
                # Setup suppresses guest output by default. Withdrawal needs one
                # machine-readable receipt, retained only in a private local log.
                # Stream only its explicit prefix and a separately typed exit
                # status; never buffer or return arbitrary setup stdout.
                remote = (
                    "$ErrorActionPreference = 'Stop'\ntry {\n" + credential +
                    f"$session = New-PSSession -ComputerName {_ps(host['address'])} -Port {port} "
                    "-UseSSL -Authentication Negotiate" + credential_argument + "\n"
                    "try {\n$guestExit=$null; $invalidReply=$false\n"
                    "Invoke-Command -Session $session -ScriptBlock { param($payload,$prefix)\n"
                    "  $script=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($payload))\n"
                    "  $temp=Join-Path $env:TEMP ([IO.Path]::GetRandomFileName()+'.ps1')\n"
                    "  try {\n"
                    "    [IO.File]::WriteAllText($temp,$script,[Text.UTF8Encoding]::new($false))\n"
                    "    $ErrorActionPreference='Continue'; $LASTEXITCODE=255\n"
                    "    & powershell.exe -NoLogo -NoProfile -NonInteractive -File $temp 2>&1 | ForEach-Object {\n"
                    "      $line=[string]$_; if($line.StartsWith($prefix,[StringComparison]::Ordinal)){ $line }\n"
                    "    }\n"
                    "    [PSCustomObject]@{SentinelSetupExitCode=[int]$LASTEXITCODE}\n"
                    "  } finally {Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue}\n"
                    f"}} -ArgumentList '{payload}',{_ps(receipt_prefix)} | ForEach-Object {{\n"
                    "  if($_ -is [string]){[Console]::Out.WriteLine($_)}\n"
                    "  elseif(($_.PSObject.Properties.Name -contains 'SentinelSetupExitCode') -and $null -eq $guestExit){$guestExit=[int]$_.SentinelSetupExitCode}\n"
                    "  else {$invalidReply=$true}\n"
                    "}\nif($invalidReply -or $null -eq $guestExit){exit 255}\nexit $guestExit\n"
                    "} finally {Remove-PSSession -Session $session}\n} catch {exit 255}\n"
                )
            result = self._powershell(remote, seconds)
            # Transport exceptions may occur after a mutation; a nonzero wrapper
            # exit cannot safely authorize an automatic replay.
            return replace(result, uncertain=result.uncertain or result.returncode == 255)
        raise ValueError(f"setup adapter unavailable: {route}")

    def _powershell(self, script: str, seconds: float) -> CommandResult:
        executable = (shutil.which("powershell.exe") if os.name == "nt" else None) or _powershell_executable()
        # -File gives reliable exit semantics; -Command - with redirected stdin
        # can report success even when an earlier statement failed.
        with tempfile.TemporaryDirectory(prefix="sentinel-setup-") as directory:
            path = Path(directory) / "run.ps1"
            path.write_text(script, encoding="utf-8-sig")
            if os.name == "posix":
                path.chmod(0o600)
            return run_process([executable, "-NoLogo", "-NoProfile", "-NonInteractive",
                                "-File", str(path)], "", seconds, log_dir=self.log_dir,
                               env=powershell_environment(executable))

    def preflight(self, host: dict[str, Any], seconds: float) -> CommandResult:
        if host["platform"] == "linux":
            from .runtime_environment import host_python
            python = shlex.quote(host_python(host))
            script = ("set -eu\ncommand -v bash >/dev/null\ncommand -v timeout >/dev/null\nid -u >/dev/null\n" +
                      f"{python} -I -B -c 'import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 25)'\n")
        else:
            script = "$ErrorActionPreference = 'Stop'\n$PSVersionTable.PSVersion | Out-Null\nexit 0\n"
        return self.execute(host, script, seconds)
