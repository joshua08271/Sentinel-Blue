"""Local desktop control client. Secrets never enter dashboard requests or logs."""

from __future__ import annotations

import ipaddress
import secrets
import ssl
import time
from urllib.parse import urlsplit, quote

from .json_codec import canonical_json_bytes, strict_json_loads
from .operator_auth import operator_signature, validate_operator_principal
from .probes import _PinnedHTTPConnection, _PinnedHTTPSConnection
from .request_deadline import BoundedRequestPool
from .service_repair import (
    fault_summary, host_capacity_findings, native_fault_findings, port_conflict_findings,
    probe_health, unavailable_transactions)


def rejection_error(status, value):
    """Return the operator-facing error for a refused controller request.

    The controller composes these reasons itself and they carry no submitted
    secret, so one bounded printable field is shown; the body is never echoed.
    Without a usable reason the earlier generic guidance is kept.
    """
    detail = value.get('error') if isinstance(value, dict) else None
    detail = (''.join(character for character in detail if character.isprintable())[:200].strip()
              if isinstance(detail, str) else '')
    if detail:
        return RuntimeError(f'Controller rejected request (HTTP {status}): {detail}')
    return RuntimeError(f'Controller rejected request (HTTP {status}); '
                        'refresh and review the current state')


RECOVERY_WORDS = {
    "service_recovery_cooldown": "recovered recently; the next automatic attempt waits out its cooldown",
    "service_recovery_hourly_budget_exhausted": "hourly limit of automatic attempts reached; waiting",
    "service_recovery_failed_attempt_hourly_budget_exhausted":
        "automatic attempts failed repeatedly this hour; held for review",
    "service_recovery_prior_outcome_unresolved":
        "an earlier attempt's outcome is unknown; reconcile it on the Recovery tab",
    "service_recovery_history_unreadable": "recovery history could not be read; automatic recovery held",
    "service_recovery_history_budget_exceeded": "recovery history could not be read; automatic recovery held",
}


def recovery_words(status):
    """The Services tab's Recovery column: controller status codes in plain words."""
    return RECOVERY_WORDS.get(status, status)


def service_rows(manifests, telemetry, agents, *, now=None, stale_after=90):
    """Represent missing/stale evidence explicitly; a running PID is not uptime."""
    now = time.time() if now is None else now
    hosts = {row['agent_id']: row for row in agents}
    result = []
    for manifest in manifests:
        host, name = manifest['host'], manifest['service_id']
        sample = telemetry.get(host) or {}
        seen = sample.get('observed_at')
        age = now - seen if type(seen) in (int, float) else None
        fresh = age is not None and 0 <= age <= stale_after
        enabled = hosts.get(host, {}).get('enabled', False)
        services = [x for x in sample.get('services', []) if x.get('name') == name]
        native = services[0].get('state', 'unknown') if len(services) == 1 else 'unknown'
        checks = probe_health(manifest.get('expected_transactions', []), sample) if fresh and enabled else []
        expected = len(manifest.get('expected_transactions', []))
        passed = sum(x is True for x in checks)
        reason = ''
        if host not in hosts:
            # The manifest host must name an enrolled agent (its agent_id), not
            # an address that never reports. Without this the row reads "unknown"
            # forever with nothing to act on.
            reason = f'no enrolled agent reports manifest host {host!r}'
        elif not enabled:
            reason = 'agent is not enabled'
        elif seen is None:
            reason = 'no telemetry received from this agent yet'
        elif not fresh:
            reason = 'telemetry is stale'
        elif unavailable := unavailable_transactions(manifest.get('expected_transactions', []), sample):
            # The check ran and could not be attempted. Saying "check probe name
            # and target" here would send an operator somewhere with no answer.
            reason = (f"{unavailable[0]['name']}: {unavailable[0]['detail']}"
                      + (f" (+{len(unavailable) - 1} more)" if len(unavailable) > 1 else ''))
        elif expected and all(result is None for result in checks):
            # probe_health returns None for a check with no matching probe row,
            # which is the usual cause of a service that never leaves 'unverified'.
            reason = 'no matching service check ran; check probe name and target'
        elif len(services) == 1 and native in {'stopped', 'inactive', 'failed', 'activating', 'deactivating'}:
            # Name why the service manager says it is down, so a stopped scored
            # service is not left as an unexplained red row (issue #13). The
            # restart counter needs an approved baseline to mean anything, so
            # only the current verdict and sub-state are read here.
            current = services[0]
            findings = (native_fault_findings(name, current, {'restart_count': current.get('restart_count', 0)})
                        + host_capacity_findings(name, manifest, sample))
            if native == 'deactivating':
                # Still stopping: the listener on its port is its own process.
                findings.append({'code': 'service_stop_stuck', 'subject': name})
            else:
                findings += port_conflict_findings(name, manifest, sample)
            summary = fault_summary(findings)
            if summary:
                reason = summary
        if not enabled or not fresh:
            health = 'unknown' if seen is None or not enabled else 'stale'
        elif any(x is False for x in checks) or native in {'stopped', 'inactive', 'failed'}:
            health = 'unhealthy'
        elif expected and len(checks) == expected and all(x is True for x in checks):
            health = 'healthy'
        else:
            health = 'unverified'
        result.append({'agent_id': host, 'service': name, 'health': health,
                       'native_state': native if fresh and enabled else 'unknown',
                       'passed_checks': passed, 'expected_checks': expected,
                       'observed_at': seen, 'age_seconds': round(age, 1) if age is not None else None,
                       'reason': reason})
    return result


def storage_message(snapshot):
    storage = snapshot.get('controller', {}).get('storage')
    if not storage:
        return 'Storage usage is unavailable from this controller.'
    mib = 1024 * 1024
    message = (f"Storage {storage['state']} · Database {storage['database_used_bytes']/mib:.1f} / "
               f"{storage['database_max_bytes']/mib:.0f} MiB · Archives {storage['archive_bytes']/mib:.1f} MiB")
    if storage.get('telemetry_admission_paused'):
        message += ' · New telemetry is waiting for space; review storage.'
    elif storage.get('reasons'):
        message += ' · Review: ' + ', '.join(str(x).replace('_', ' ') for x in storage['reasons'])
    return message


SEVERITY_ORDER = {'critical': 0, 'high': 1, 'medium': 2, 'low': 3, 'unknown': 4}


def verification_rows(snapshot):
    rows = []
    for check in snapshot.get('external_observers', []):
        if check.get('health') in {'unhealthy', 'stale'}:
            rows.append({'kind': 'external-check', 'id': check['observer_id']+':'+check['check_id'],
                'host': check['agent_id'], 'title': 'External service check '+check['health']+': '+check['service_id'],
                'detail': check, 'choices': [], 'severity': 'high'})
    for alert in snapshot.get('alerts', []):
        if alert.get('status') == 'open':
            rows.append({'kind': 'alert', 'id': alert['alert_id'], 'host': alert['agent_id'],
                         'title': alert.get('title', 'Review alert'), 'detail': alert,
                         'choices': ['approve', 'observe', 'reject'],
                         'severity': str(alert.get('severity', 'unknown'))})
    for host in snapshot.get('agents', []):
        if host.get('baseline_status') == 'pending':
            rows.append({'kind': 'baseline', 'id': host['agent_id'], 'host': host['agent_id'],
                         'title': 'Review initial baseline', 'detail': host,
                         'choices': ['approve'], 'severity': 'medium'})
    for action in snapshot.get('actions', []):
        if action.get('status') == 'outcome_unknown':
            rows.append({'kind': 'outcome', 'id': action['action_id'], 'host': action['agent_id'],
                         'title': 'Verify whether action executed', 'detail': action,
                         'choices': ['executed', 'not_executed'], 'severity': 'high'})
    # Failed undos holding Resume until reviewed (2.0.18); the controller lists
    # them separately, so an older one is not lost behind 100 newer actions.
    for action in snapshot.get('undo_reviews', []):
        if isinstance(action, dict) and isinstance(action.get('action_id'), str):
            rows.append({'kind': 'undo-review', 'id': action['action_id'], 'host': action.get('agent_id', ''),
                         'title': 'Review an undo that failed after it began', 'detail': action,
                         'choices': ['reviewed'], 'severity': 'high'})
    return rows


class DesktopClient:
    def __init__(self, origin, principal, epoch, token, ca_file=None):
        parsed = urlsplit(origin)
        if parsed.scheme not in {'http', 'https'} or parsed.username or parsed.password or parsed.path not in {'', '/'} or parsed.query or parsed.fragment:
            raise ValueError('Controller requires an HTTP(S) origin without a path or embedded credentials')
        address = ipaddress.ip_address(parsed.hostname)
        if parsed.scheme == 'http' and not address.is_loopback:
            raise ValueError('Remote controller connections require HTTPS')
        self.address, self.origin = str(address), origin.rstrip('/')
        self.port, self.scheme = parsed.port or (443 if parsed.scheme == 'https' else 80), parsed.scheme
        self.principal = validate_operator_principal(principal)
        if type(epoch) is not int or epoch < 1:
            raise ValueError('Credential epoch must be a positive integer')
        self.epoch, self.token = epoch, token
        self.ca_file = str(ca_file) if ca_file else None
        operator_signature(token, principal, epoch, str(int(time.time())), secrets.token_hex(16), 'GET', '/api/v1/dashboard', b'')
        self.context = ssl.create_default_context(cafile=ca_file) if self.scheme == 'https' else None
        self.pool = BoundedRequestPool(2, label='desktop request', thread_name='sentinel-desktop-network')
        self.control_pool = BoundedRequestPool(1, label='desktop emergency control', thread_name='sentinel-desktop-control-network')

    def request(self, target, payload=None):
        method = 'GET' if payload is None else 'POST'
        body = b'' if payload is None else canonical_json_bytes(payload, max_bytes=65536)
        stamp, nonce = str(int(time.time())), secrets.token_hex(16)
        headers = {'X-SB-Operator-Version': '1', 'X-SB-Operator-Principal': self.principal,
                   'X-SB-Operator-Epoch': str(self.epoch), 'X-SB-Operator-Timestamp': stamp,
                   'X-SB-Operator-Request-ID': nonce, 'Content-Type': 'application/json',
                   'X-SB-Operator-Signature': operator_signature(self.token, self.principal, self.epoch, stamp, nonce, method, target, body)}

        def call(budget):
            if self.context:
                connection = _PinnedHTTPSConnection(self.address, self.address, self.port, budget.remaining(), self.context)
            else:
                connection = _PinnedHTTPConnection(self.address, self.address, self.port, budget.remaining())
            connection._budget = budget
            try:
                connection.request(method, target, body=body if payload is not None else None, headers=headers)
                response = connection.getresponse()
                raw = response.read(4 * 1024 * 1024 + 1)
                value = strict_json_loads(raw, max_bytes=4 * 1024 * 1024)
                if not isinstance(value, dict):
                    raise ValueError('Invalid controller response')
                if not 200 <= response.status < 300:
                    raise rejection_error(response.status, value)
                return value
            finally:
                connection.close()
        # No automatic POST retries: timeout can mean a mutation was admitted.
        # Starting a later weekly session verifies its previous archive before
        # reclaiming journal pages. Keep that signed POST bounded but allow the
        # disk verification to finish; mutation requests are still never retried.
        pool = self.control_pool if target in {'/api/v1/governance/emergency-stop', '/api/v1/governance/resume'} else self.pool
        return pool.run(call, 120 if target == '/api/v1/recording/start' and payload == {} else 8)

    def dashboard(self):
        value = self.request('/api/v1/dashboard')
        if isinstance(value, dict):
            # 2.0.9: local receipt time. Redo freshness is judged on this
            # machine's clock rather than by comparing two machines' clocks.
            value['client_received_at'] = time.time()
        return value

    def save_recording(self, directory):
        """Stop, wait for a durable export, download bounded chunks and verify."""
        import base64
        import hashlib
        import os
        import uuid
        from pathlib import Path
        from .recording import inspect_bundle, MAX_TOTAL
        from .state import _replace_with_retry, _fsync_directory
        status = self.request('/api/v1/recording/stop', {})
        identifier = status['session_id']
        deadline = time.monotonic() + 600
        while not status.get('export_ready'):
            if time.monotonic() >= deadline:
                raise TimeoutError('The recording is stopped but export is still pending; retry Save after checking storage')
            time.sleep(.25)
            status = self.request('/api/v1/recording/status')
            if status.get('session_id') != identifier or status.get('state') != 'stopped':
                raise RuntimeError('Another window started a session during export; preserve the previous controller export')
        root = Path(directory).absolute()
        from .credential_vault import private_directory
        guard = private_directory(root)
        path = root / ('controller-' + identifier + '.zip')
        temporary = root / ('.download-' + uuid.uuid4().hex + '.tmp')
        try:
            with open(temporary, 'xb') as handle:
                if os.name == 'posix':
                    os.chmod(temporary, 0o600)
                offset, total = 0, None
                download_deadline = time.monotonic()+600
                while total is None or offset < total:
                    if time.monotonic() >= download_deadline:
                        raise TimeoutError('Recording download exceeded its time budget; retry Save on a responsive connection')
                    result = self.request('/api/v1/recording/chunk?session_id=' + identifier + '&offset=' + str(offset))
                    if (result.get('session_id') != identifier or result.get('offset') != offset
                            or type(result.get('size')) is not int or not 0 < result['size'] <= 2*MAX_TOTAL
                            or total is not None and result['size'] != total):
                        raise ValueError('Recording transfer changed or exceeded its limit')
                    total = result['size']
                    data = base64.b64decode(result['data'], validate=True)
                    if not data or len(data) > 256*1024 or offset+len(data) > total or hashlib.sha256(data).hexdigest() != result['chunk_sha256']:
                        raise ValueError('Recording chunk failed verification')
                    handle.write(data)
                    offset += len(data)
                handle.flush(); os.fsync(handle.fileno())
            manifest = inspect_bundle(temporary)
            if manifest['session_id'] != identifier or manifest['stopped_at'] is None or manifest['events'] != status['events']:
                raise ValueError('Recording export is not the stopped session')
            if path.is_symlink():
                raise ValueError('Recording destination is a symlink')
            _replace_with_retry(temporary, path)
            _fsync_directory(root)
            return path
        finally:
            temporary.unlink(missing_ok=True)
            if guard:
                guard.close()

    def decide(self, row, choice):
        if choice not in row['choices']:
            raise ValueError('Invalid verification choice')
        subject = quote(row['id'], safe='')
        if row['kind'] == 'baseline':
            return self.request(f'/api/v1/agents/{subject}/baseline/approve', {})
        if row['kind'] == 'outcome':
            return self.request(f'/api/v1/actions/{subject}/reconcile', {'resolution': choice})
        if row['kind'] == 'undo-review':
            if choice != 'reviewed':
                raise ValueError('Invalid verification choice')
            return self.request(f'/api/v1/actions/{subject}/reconcile', {'resolution': 'reviewed'})
        if row['kind'] != 'alert':
            raise ValueError('Unsupported verification')
        authorization = ''
        action = row['detail'].get('recommended_action')
        if choice == 'approve' and action in {'restore_integrity', 'rollback_integrity', 'quarantine_session', 'restart_service', 'rollback_service', 'repair_service', 'rollback_service_repair'}:
            authorization = self.request('/api/v1/authorizations', {'agent_id': row['host'], 'action_type': action,
                'subject': row['id'], 'ttl_seconds': 120})['authorization_code']
        return self.request(f'/api/v1/alerts/{subject}/decision', {'decision': choice, 'authorization_code': authorization})
