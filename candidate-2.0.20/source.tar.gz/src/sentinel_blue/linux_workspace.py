"""Private, loopback-only Linux desktop sessions using the ordinary engine.

Creating a workspace prepares files only. The GUI separately reviews the plan
before starting processes or admitting a setup job. Existing event profiles are
never rewritten by this local-lab convenience path.
"""
from __future__ import annotations

import copy
import datetime
import hashlib
import ipaddress
import os
import json
import re
from pathlib import Path
import secrets
import socket
import subprocess
import sys
import time
import uuid

from . import __version__
from .state import read_private_json, read_private_text, write_private_json, _atomic_bytes


def is_proxmox_host():
    return Path('/etc/pve').exists() or Path('/usr/bin/pveversion').exists()


def local_observation():
    """Read service/listener state, without changing the machine."""
    from .desktop_services import catalog_presence
    services = []
    try:
        result = subprocess.run(['systemctl', 'list-units', '--all', '--type=service',
            '--no-legend', '--no-pager', '--plain'], capture_output=True, text=True, timeout=12)
        if result.returncode == 0:
            for line in result.stdout.splitlines():
                fields = line.split()
                if len(fields) >= 4 and fields[0].endswith('.service'):
                    services.append({'name': fields[0], 'state': fields[2]})
    except (OSError, subprocess.TimeoutExpired):
        pass
    # The agent's own listener reader: ss when installed, otherwise the
    # kernel's socket tables, with any gap reported as incomplete.
    from .collectors import _linux_listeners
    errors = []
    try:
        rows = _linux_listeners(errors)
    except (OSError, subprocess.SubprocessError):
        rows, errors = [], ['listener inventory unavailable']
    listeners = [{'protocol': row.protocol, 'port': row.port} for row in rows]
    complete = not errors
    try:
        addresses = local_host_addresses()
    except (OSError, ValueError, subprocess.SubprocessError):
        addresses = ()
    # This is the same normalized contract resolve_ports consumes.
    return {'presence': catalog_presence({'services': services}), 'addresses': list(addresses),
            'observation': {'observed_at': time.time(), 'complete': complete,
                            'listeners': listeners}}


def default_probe(sid, options):
    """Conservative local checks; never invent a successful application login."""
    from .linux_service_catalog import CATALOG
    from .service_ports import configured_ports
    row = CATALOG[sid]
    ports = configured_ports(sid, options)
    port = next(iter(ports.values()), next(iter(row['ports']), None))
    if row['family'] in {'dhcp', 'time'} or sid == 'rsyslog' or port is None:
        raise ValueError(row['label'] + ': use Service check… to supply a real verification '
                         'check. This service cannot be verified by guessing a TCP port.')
    if sid in {'nginx', 'apache2', 'tomcat', 'gunicorn'}:
        if any(options.get(k) for k in ('tls_certificate', 'tls_certificate_path')):
            raise ValueError('Use Service check… to select HTTPS and your CA certificate for ' + row['label'])
        return {'kind': 'http', 'target': f'http://127.0.0.1:{port}/',
                'expected_status': [200], 'timeout': 5}
    if sid in {'bind9', 'unbound', 'dnsmasq'}:
        raise ValueError('Use Service check… to enter a DNS query name and expected address. '
                         'A zone/domain name alone is not a readiness contract.')
    return {'kind': 'tcp', 'target': '127.0.0.1', 'port': port, 'timeout': 5}


def certificate(directory):
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import NameOID
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, 'Sentinel Blue local desktop')])
    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name)
        .public_key(key.public_key()).serial_number(x509.random_serial_number())
        .not_valid_before(now - datetime.timedelta(minutes=5))
        .not_valid_after(now + datetime.timedelta(days=365))
        .add_extension(x509.SubjectAlternativeName([x509.IPAddress(ipaddress.ip_address('127.0.0.1'))]), False)
        .sign(key, hashes.SHA256()))
    _atomic_bytes(directory/'controller.key', key.private_bytes(serialization.Encoding.PEM,
        serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
    _atomic_bytes(directory/'controller.crt', cert.public_bytes(serialization.Encoding.PEM))


# What every service chosen in Service setup may have repaired, and how. The
# grant is the same for a generated pack, an adopted catalog service and a unit
# outside the catalog: restore the files that belong to it, put its unit back to
# enabled (including from a mask), and restart it, validated by its own check.
REPAIR_FILE_LIMIT = 16
REPAIR_VALIDATION_SECONDS = 30


def repair_policy_for(owned, host=()):
    policy = {'restore_files': list(owned[:REPAIR_FILE_LIMIT]), 'restart_unhealthy': True,
              'validation_timeout_seconds': REPAIR_VALIDATION_SECONDS,
              'restore_start_mode': 'enabled', 'unmask': True}
    if host:
        # The host-wide files this manifest carries for baseline coverage and
        # approval-based restoration; its recovery does not depend on them.
        policy['host_files'] = list(host)
    return policy


def repair_actions(autonomy):
    automatic = (['validate_service', 'capture_restore_point', 'restart_service', 'repair_service']
                 if autonomy == 'guarded-autonomous' else [])
    approval = ['restart_service', 'rollback_service', 'capture_restore_point', 'repair_service', 'rollback_service_repair']
    return automatic, approval


def local_host_addresses():
    """This VM's own unicast addresses, which a local check may target."""
    from .collectors import _linux_interfaces
    from .service_repair import host_addresses
    interfaces = _linux_interfaces([])
    return tuple(sorted(host_addresses({'interfaces': [{'addresses': list(row.addresses)} for row in interfaces]})))


PACK_MODES = (0o644, 0o640, 0o600)


def keep_parent_modes(options, lstat=os.lstat):
    """Give each parent file a pack activates the mode it has on this VM.

    A pack adds one include line to a parent file (postgresql.conf,
    pg_hba.conf, redis.conf) and writes it with a reviewed mode, 0644 unless
    told otherwise. Found live on 2.0.6: Ubuntu ships pg_hba.conf as 0640, so
    the step refused to widen it only when it ran, after the review had been
    approved. The widest mode a pack may write that is no wider than the
    current one is chosen here, at review, where the operator sees it. A file
    already chosen by the operator, missing, or not a regular file is left
    alone; the step's own check still refuses to widen anything.
    """
    import stat as _stat
    result = copy.deepcopy(options) if isinstance(options, dict) else options
    for opts in (result.values() if isinstance(result, dict) else ()):
        if not isinstance(opts, dict) or not isinstance(opts.get('activation'), dict):
            continue
        modes = opts.get('file_modes', {})
        if not isinstance(modes, dict):
            continue
        chosen = dict(modes)
        for path in opts['activation']:
            if path in chosen or not isinstance(path, str):
                continue
            try:
                info = lstat(path)
            except (OSError, ValueError):
                continue
            if not _stat.S_ISREG(info.st_mode):
                continue
            current = _stat.S_IMODE(info.st_mode)
            mode = next((m for m in PACK_MODES if not m & ~current), None)
            if mode is not None:
                chosen[path] = f'{mode:04o}'
        if chosen != modes:
            opts['file_modes'] = chosen
    return result


def prepare_workspace(parent, runtime, selection, options, presence, checks=None, autonomy='approval-based',
                      port_observation=None, custom_services=None, local_addresses=None):
    from .credential_vault import private_directory
    from .desktop_services import service_plan
    from .event_profile import EventProfile, CAPABILITIES
    from .linux_service_catalog import CATALOG
    from .setup import compile_plan
    from .auth import derive_enrollment_ticket
    from .recovery_ops import initialize_controller_recovery
    runtime = Path(runtime).absolute()
    if autonomy not in {'approval-based', 'guarded-autonomous'}:
        raise ValueError('Choose approval-based or guarded automatic recovery.')
    if not runtime.is_file():
        raise ValueError('Open the complete offline application before preparing setup.')
    # Addresses come from the caller's earlier read-only observation;
    # preparing a plan never runs a command on the host itself.
    own = tuple(local_addresses or ())
    options = keep_parent_modes(options)
    fragment = service_plan(selection, 'local-linux', manager='apt', options=options, presence=presence,
                            custom=custom_services, local_addresses=own)
    # systemd telemetry and recovery actions use complete unit identities.
    # Bind the reviewed local plan to those same identities, including adoption.
    for task in fragment['tasks']:
        task['service_id'] = systemd_service_name(task['service_id'])
        if task['recipe'] == 'linux-service':
            task['options']['service'] = task['service_id']
    checks = checks or {}
    manifests = []
    for sid in fragment['review_notes']['configure'] + fragment['review_notes']['adopt_only']:
        row, opts = CATALOG[sid], options.get(sid, {})
        probe = copy.deepcopy(checks[sid] if sid in checks else default_probe(sid, opts))
        # The local wizard is intentionally bound to this VM. Remote plans use
        # the existing scoped inventory/profile workflow.
        from urllib.parse import urlsplit
        target = urlsplit(probe.get('target', '')).hostname if probe.get('kind') in {'http', 'https'} else probe.get('host', probe.get('target'))
        if target != '127.0.0.1' and target not in own:
            raise ValueError(row['label'] + ": local setup checks must target 127.0.0.1 or one of this VM's own addresses.")
        from .service_ports import configured_ports
        ports = configured_ports(sid, opts)
        primary = next(iter(ports.values()), next(iter(row['ports']), probe.get('port', 1)))
        automatic, approval = repair_actions(autonomy)
        manifests.append({'host': 'local-linux', 'service_id': systemd_service_name(row['unit']),
            'protocol': probe['kind'], 'port': primary, 'implementation': row['label'],
            'dependencies': [systemd_service_name(CATALOG[s]['unit']) for s in row['requires']],
            'required_accounts': [], 'required_files': [], 'required_data': list(row['data_paths']),
            'credential_source': 'Operator-provided private files when required',
            'expected_transactions': [probe], 'local_checks': [],
            # Repair may write only the files this service owns (see
            # local_repair_files); host-wide integrity files stay alert-only.
            'allowed_automatic_actions': automatic, 'approval_actions': approval,
            'backup_method': 'Exact state in the existing setup action ledger',
            'recovery_method': 'Restore owned configuration, restore startup, restart and validate',
            'rollback_method': 'Selective inverse of proved-owned changes'})
    from .custom_services import check_port
    for service in fragment.get('custom_services', []):
        automatic, approval = repair_actions(autonomy)
        probe = copy.deepcopy(service['check'])
        manifests.append({'host': 'local-linux', 'service_id': service['unit'],
            'protocol': probe['kind'], 'port': check_port(probe), 'implementation': service['label'],
            'dependencies': [], 'required_accounts': [], 'required_files': [], 'required_data': [],
            'credential_source': 'Operator-provided private files when required',
            'expected_transactions': [probe], 'local_checks': [],
            'allowed_automatic_actions': automatic, 'approval_actions': approval,
            'backup_method': 'Exact state in the existing setup action ledger',
            'recovery_method': 'Restore declared configuration, restore startup, restart and validate',
            'rollback_method': 'Selective inverse of proved-owned changes'})
    for manifest in manifests:
        for probe in manifest['expected_transactions']:
            if probe.get('kind') == 'dns':
                from .probes import _dns_approved_answers
                if not isinstance(probe.get('query'), str) or not probe['query'].strip():
                    raise ValueError('Use Service check… to enter a DNS query name and expected address.')
                qtype = {'A': 1, 'AAAA': 28, 'PTR': 12}.get(str(probe.get('record_type', 'A')).upper())
                _dns_approved_answers(qtype, probe.get('expected_answers'))
    discovery_issues = {}
    scoped_files, owned_files = _local_file_owners(fragment, Path(parent).absolute(),
                                                  discovery_issues=discovery_issues)
    baseline_files = sorted({path for paths in scoped_files.values() for path in paths})
    repair_coverage = {}
    for manifest in manifests:
        unit = manifest['service_id']
        manifest['required_files'] = scoped_files[unit]
        manifest['repair_policy'] = repair_policy_for(
            owned_files[unit], [path for path in scoped_files[unit] if path not in owned_files[unit]])
        repair_coverage[unit] = {'restorable': owned_files[unit][:REPAIR_FILE_LIMIT],
                                 'alert_only': owned_files[unit][REPAIR_FILE_LIMIT:],
                                 'discovery_issues': discovery_issues.get(unit, [])}
    for manifest in manifests:
        if 'capture_restore_point' not in manifest['allowed_automatic_actions']:
            manifest['allowed_automatic_actions'].append('capture_restore_point')
    parent = Path(parent).absolute()
    guard = private_directory(parent)
    if guard:
        guard.close()
    directory = parent / ('local-' + uuid.uuid4().hex[:16])
    guard = private_directory(directory)
    try:
        certificate(directory)
        raw = EventProfile.testing().raw
        raw['profile_id'] = 'desktop-' + directory.name
        # The engine requires guarded governance even for automatic backup
        # evidence. The recovery choice below separately controls whether a
        # service restart is automatic; approval-based recovery permits only
        # capture_restore_point in its automatic action allowlist.
        raw['autonomy_mode'] = 'guarded-autonomous'
        raw['approval'] = {'status': 'range-only', 'approved_by': 'local-desktop-operator'}
        # Own addresses a check actually targets join the scope, and only those.
        from .custom_services import check_host
        targeted = sorted({check_host(p) for m in manifests for p in m['expected_transactions']} & set(own))
        networks = ['127.0.0.1/32'] + [str(ipaddress.ip_network(a)) for a in targeted]
        raw['scope'] = {'authorized_networks': networks, 'authorized_hosts': ['127.0.0.1', *targeted],
            'controller_ingress_hosts': ['127.0.0.1'], 'excluded_hosts': [],
            'approved_deployment_paths': [str(directory)]}
        enabled = {'initial_provisioning', 'external_controller', 'network_monitoring',
                   'configuration_backups', 'in_place_repair', 'structured_rollback', 'file_restoration',
                   'guarded_autonomy'}
        raw['capabilities'] = {name: name in enabled for name in CAPABILITIES}
        raw['organizer_exceptions'] = []
        raw['allowed_automatic_actions'] = (['validate_service', 'capture_restore_point', 'restart_service', 'repair_service']
                                           if autonomy == 'guarded-autonomous' else ['capture_restore_point'])
        raw['services'], raw['services_confirmed'] = manifests, True
        if autonomy == 'guarded-autonomous':
            # Guarded recovery is chosen so that services stay up with nobody
            # watching. After an unclean controller exit, resume the durably
            # saved governance (a saved Pause stays paused) instead of forcing
            # observe mode. The controller still requires the authenticated
            # recovery key and anchor below and a ready recovery preflight.
            raw['recovery'] = {**raw.get('recovery', {}), 'resume_after_controller_crash': True}
        raw['release'] = {'version': __version__, 'approved': False,
            'sha256': hashlib.sha256(runtime.read_bytes()).hexdigest(),
            'controller_ca_sha256': hashlib.sha256((directory/'controller.crt').read_bytes()).hexdigest(),
            'cloud_processing': False, 'external_telemetry_export': False}
        profile = EventProfile.from_dict(raw)
        profile.require_range_ready()
        inventory = {'authorized_networks': networks, 'hosts': [{
            'name': 'local-linux', 'agent_id': 'local-linux', 'address': '127.0.0.1',
            'platform': 'linux', 'transport': 'local', 'python': str(Path(sys.executable).absolute()),
            'runtime': str(runtime)}],
            'setup': {'tasks': fragment['tasks']}}
        # Compile exactly what is saved (sorted keys), so the setup job, which
        # compiles the saved inventory again, finds the same approved plan.
        inventory = json.loads(json.dumps(inventory, sort_keys=True))
        plan = compile_plan(inventory, profile, directory)
        write_private_json(directory/'profile.json', raw)
        write_private_json(directory/'inventory.json', inventory)
        write_private_json(directory/'probes.json', {'probes': [p for m in manifests for p in m['expected_transactions']],
            'protected_paths': baseline_files})
        master, operator = secrets.token_urlsafe(48), secrets.token_urlsafe(48)
        write_private_json(directory/'master.json', {'token': master})
        write_private_json(directory/'enrollment.json', {'token': derive_enrollment_ticket(master, profile.fingerprint, 'local-linux')})
        _atomic_bytes(directory/'operator.txt', operator.encode())
        recovery = secrets.token_bytes(48)
        _atomic_bytes(directory/'recovery.key', recovery)
        initialize_controller_recovery(directory/'controller.db', directory/'recovery.anchor', recovery)
        with socket.socket() as sock:
            sock.bind(('127.0.0.1', 0))
            port = sock.getsockname()[1]
        config = {'schema': 1, 'session_id': uuid.uuid4().hex, 'directory': str(directory),
            'runtime': str(runtime), 'runtime_sha256': raw['release']['sha256'],
            'origin': f'https://127.0.0.1:{port}', 'port': port, 'principal': 'desktop-operator', 'epoch': 2,
            'ca_file': str(directory/'controller.crt'), 'inventory': str(directory/'inventory.json'),
            'event_profile': str(directory/'profile.json'), 'range_deployment': True,
            'selection': selection, 'options': options, 'checks': checks, 'autonomy': autonomy,
            'reviewed_port_observation': copy.deepcopy(port_observation),
            'baseline_capture_paths': baseline_files, 'repair_coverage': repair_coverage,
            'custom_services': copy.deepcopy(fragment.get('custom_services', []))}
        write_private_json(directory/'session.json', config)
        return config, plan
    finally:
        if guard:
            guard.close()


def systemd_service_name(name):
    return name if name.endswith('.service') else name + '.service'


def require_available_local_ports(config):
    """Recheck reviewed listeners before starting a local setup session."""
    from .service_ports import _occupied, endpoint_set
    inventory = read_private_json(config['inventory'])
    tasks = [task for task in inventory['setup']['tasks'] if task['recipe'] != 'linux-service']
    if not tasks:
        return
    current = local_observation()
    occupied, complete = _occupied(current['observation'])
    if not complete:
        raise ValueError('Listener inventory is incomplete. Refresh this VM’s service inventory and review setup again.')
    reviewed = config.get('reviewed_port_observation')
    # The old snapshot describes what was reviewed, not current availability.
    previous, reviewed_complete = _occupied(reviewed, now=reviewed.get('observed_at')) if reviewed else (set(), False)
    if not reviewed_complete:
        previous = set()
    for task in tasks:
        sid = task['id'].removeprefix('sentinel-')
        conflicts = endpoint_set(sid, config['options'].get(sid, {})) & occupied
        if current['presence'].get(sid) == 'running':
            conflicts -= previous
        if conflicts:
            ports = ', '.join(protocol.upper() + ' ' + str(port) for protocol, port in sorted(conflicts))
            raise ValueError(sid + ': ' + ports + ' is now occupied. Choose another port and review setup again, or release the conflicting listener before retrying.')


def local_baseline_files(fragment, root):
    """Bind actual and planned files once, without requiring absent packages.

    Collector hints include paths for packages not installed on this host.
    Those hints must not become mandatory restart dependencies. Planned files
    are included even before setup creates them, and are explicitly collected.
    """
    return _local_file_owners(fragment, root)[0]


def local_repair_files(fragment, root):
    """The files each service may have restored by its own repair.

    Exactly the files that belong to that service: what setup generated for it,
    its product's own configuration paths and its unit file. The host-wide
    integrity files every baseline also watches (accounts, sudoers, SSH keys and
    the like) are deliberately absent. They are monitored and alerted on, but a
    web server's repair must never be the thing that rewrites /etc/shadow.
    """
    return _local_file_owners(fragment, root)[1]


def _unit_file(unit):
    for directory in ('/etc/systemd/system', '/usr/lib/systemd/system', '/lib/systemd/system'):
        path = Path(directory)/unit
        if path.is_file():
            return str(path.resolve())
    return None


class ConfigFileSelection(list):
    """List-compatible bounded discovery result, with explicit coverage gaps."""
    def __init__(self):
        super().__init__()
        self.issues = []


def config_files(path, limit=64):
    """Select bounded regular files breadth first, never through symlinks.

    Limits apply during discovery, not after an unbounded walk. At most 1,024
    directories / 8,192 entries are inspected. A partial result carries reasons
    in ``issues``; local setup displays and saves them with repair coverage.
    """
    import stat as _stat
    from collections import deque
    from .restoration import RestorePointStore
    if type(limit) is not int or not 1 <= limit <= 4096:
        raise ValueError('configuration discovery limit must be 1 to 4096')
    path = Path(path).absolute()
    found = ConfigFileSelection()
    def note(reason):
        text = str(path) + ': configuration coverage incomplete — ' + reason
        if text not in found.issues and len(found.issues) < 16:
            found.issues.append(text)
    try:
        # Pin every parent component. A link encountered in any component is
        # excluded; a rename must not make discovery follow a different tree.
        parent_fd = RestorePointStore._open_parent_descriptor(path)
        try:
            info = os.stat(path.name, dir_fd=parent_fd, follow_symlinks=False)
        finally:
            os.close(parent_fd)
    except FileNotFoundError:
        return found
    except (OSError, ValueError):
        note('path is unavailable or has a symbolic-link ancestor')
        return found
    if _stat.S_ISREG(info.st_mode):
        if info.st_size <= 1024 * 1024:
            found.append(path)
        else:
            note('file exceeds the 1 MiB automatic-discovery limit')
        return found
    if not _stat.S_ISDIR(info.st_mode):
        note('path is not a regular file or plain directory')
        return found
    queue = deque([(path, info.st_dev, info.st_ino)])
    entries_seen = directories_seen = 0
    while queue:
        directory, dev, ino = queue.popleft()
        if directories_seen >= 1024:
            note('directory scan limit reached')
            break
        directories_seen += 1
        fd = None
        try:
            parent_fd = RestorePointStore._open_parent_descriptor(directory)
            try:
                fd = os.open(directory.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW,
                             dir_fd=parent_fd)
            finally:
                os.close(parent_fd)
            current = os.fstat(fd)
            if (current.st_dev, current.st_ino) != (dev, ino):
                note('directory changed while being inspected')
                continue
            rows = []
            with os.scandir(fd) as stream:
                for entry in stream:
                    entries_seen += 1
                    if entries_seen > 8192:
                        note('entry scan limit reached')
                        break
                    rows.append(entry)
            for entry in sorted(rows, key=lambda e: e.name):
                candidate = directory / entry.name
                try:
                    info = entry.stat(follow_symlinks=False)
                except OSError:
                    note('an entry could not be inspected')
                    continue
                if _stat.S_ISREG(info.st_mode):
                    if info.st_size > 1024 * 1024:
                        note('files larger than 1 MiB were excluded')
                    elif len(found) == limit:
                        note(f'more than {limit} eligible files; remaining files not monitored automatically')
                        return found
                    else:
                        found.append(candidate)
                elif _stat.S_ISDIR(info.st_mode):
                    if len(queue) < 1024:
                        queue.append((candidate, info.st_dev, info.st_ino))
                    else:
                        note('directory queue limit reached')
                elif _stat.S_ISLNK(info.st_mode):
                    note('symbolic links were excluded')
        except (OSError, ValueError):
            note('a directory could not be inspected safely')
        finally:
            if fd is not None:
                os.close(fd)
        if entries_seen > 8192:
            break
    return found


def setup_write_refusal(path):
    """Why setup's transaction would refuse to write this file, or None.

    The same rule the transaction applies on the host (every directory above
    the file root-owned and not writable by a group or other accounts), read
    here from directory metadata alone so it is caught at review, before a job
    starts. Ubuntu's /etc/redis (redis:redis 2770) and /etc/postgresql/*/main
    (postgres) fail it.
    """
    import stat
    parent = Path(path).parent
    while not parent.exists() and not parent.is_symlink():
        parent = parent.parent
    for directory in (parent, *parent.parents):
        try:
            info = directory.lstat()
        except OSError:
            return f'{directory} cannot be inspected'
        if not stat.S_ISDIR(info.st_mode):
            return f'{directory} is not a plain directory'
        if info.st_uid != 0:
            try:
                import pwd
                owner = pwd.getpwuid(info.st_uid).pw_name
            except (ImportError, KeyError):
                owner = f'uid {info.st_uid}'
            return f'{directory} is owned by {owner}, not root'
        if info.st_mode & 0o022:
            return f'{directory} can be written by a group or other accounts'
    return None


def _local_file_owners(fragment, root, *, discovery_issues=None):
    from .collectors import integrity_watch_paths
    from .linux_service_catalog import CATALOG
    owners = {}
    result = {task['service_id']: [] for task in fragment['tasks']}
    catalog = {}
    custom = {row['unit']: row for row in fragment.get('custom_services', [])}
    for task in fragment['tasks']:
        unit = task['service_id']
        if task['id'].startswith('custom-'):
            # A service outside the catalog brings exactly the files its
            # operator declared, and its unit file, and nothing else.
            for name in custom[unit].get('files', []):
                path = Path(name)
                key = str(path.resolve()) if path.exists() else str(path)
                if key in owners and owners[key] != unit:
                    raise ValueError('Selected services share a configuration path; review a separate setup: ' + key)
                owners[key] = unit
            unit_file = _unit_file(unit)
            if unit_file:
                owners.setdefault(unit_file, unit)
            continue
        sid = task['id'].removeprefix('sentinel-')
        catalog[unit] = CATALOG[sid]
        metadata = {}
        if task['recipe'] == 'linux-nginx':
            from .application_setup import linux_nginx
            linux_nginx(task['options'], root, metadata=metadata)
        elif task['recipe'] == 'linux-service-pack':
            from .linux_service_packs import build
            build(sid, {k:v for k,v in task['options'].items() if k != 'catalog_id'}, root, metadata=metadata)
        for row in metadata.get('files', []):
            path = row['path']
            refused = setup_write_refusal(path)
            if refused:
                label = CATALOG[sid]['label']
                raise ValueError(
                    f"{label} cannot be configured on this VM: {refused}, so setup will not write {path} as "
                    "root — an account that can change that directory could redirect the write. Remove its "
                    f"configuration choices to adopt the running {label} instead; repair still restores its "
                    "files from the approved baseline.")
            if path in owners and owners[path] != unit:
                raise ValueError('Selected services share a configuration path; review a separate setup: ' + path)
            owners[path] = unit
        for name in catalog[unit]['config_paths']:
            discovered = config_files(Path(name))
            if discovery_issues is not None:
                discovery_issues.setdefault(unit, []).extend(discovered.issues)
            for path in discovered:
                owners.setdefault(str(path.absolute()), unit)
        unit_file = _unit_file(unit)
        if unit_file:
            owners.setdefault(unit_file, unit)
    owned = {unit: sorted(path for path, owner in owners.items() if owner == unit) for unit in result}
    for name in integrity_watch_paths():
        path = Path(name)
        if path.is_file():
            owners.setdefault(str(path.resolve()), next(iter(result)))
    for path, unit in owners.items():
        result[unit].append(path)
    return {unit: sorted(paths) for unit, paths in result.items()}, owned


def local_baseline_blockers(config, snapshot):
    """Require consistent service-manager and probe evidence after setup."""
    from .linux_service_catalog import CATALOG
    blockers = []
    names = [systemd_service_name(CATALOG[sid]['unit']) for sid in config['selection']]
    names += [row['unit'] for row in config.get('custom_services', [])]
    for name in names:
        rows = [row for row in snapshot.get('service_health', [])
                if row.get('agent_id') == 'local-linux' and row.get('service') == name]
        if len(rows) != 1 or rows[0].get('native_state') != 'running' or rows[0].get('health') != 'healthy':
            blockers.append(name + ': waiting for fresh running service state and successful checks')
    return blockers


from .desktop_control import DesktopClient


class LocalDesktopClient(DesktopClient):
    def __init__(self, config, token):
        self.local_config = copy.deepcopy(config)
        super().__init__(config['origin'], config['principal'], config['epoch'], token, config['ca_file'])

    def dashboard(self):
        snapshot = super().dashboard()
        blockers = local_baseline_blockers(self.local_config, snapshot)
        for host in snapshot.get('agents', []):
            if host.get('agent_id') == 'local-linux' and host.get('baseline_status') == 'pending' and blockers:
                readiness = host.setdefault('baseline_readiness', {})
                readiness['ready'] = False
                readiness['blockers'] = list(readiness.get('blockers', [])) + blockers
                host['reason'] = 'Baseline approval is waiting: ' + '; '.join(blockers)
        return snapshot

    def decide(self, row, choice):
        if row.get('kind') == 'baseline':
            if row.get('id') != 'local-linux':
                raise ValueError('This local session can approve only its own host baseline.')
            blockers = local_baseline_blockers(self.local_config, self.dashboard())
            if blockers:
                raise ValueError('Baseline approval is held. ' + '; '.join(blockers) + '. Refresh after setup completes.')
        return super().decide(row, choice)


def client_for(config):
    directory = Path(config['directory'])
    return LocalDesktopClient(config, read_private_text(directory/'operator.txt', 4096).strip())


def activate_reviewed_session(config, client, checkpoint):
    """Apply a first-start approval through the normal authenticated controls.

    Reconnect never calls this function. Pause invalidates the caller's permit;
    a raced or uncertain activation is stopped, rather than silently retried.
    """
    from .event_profile import load_event_profile
    profile = load_event_profile(config['event_profile'])
    checkpoint()
    current = client.dashboard()['controller']['governance']
    if current.get('profile_fingerprint') != profile.fingerprint:
        raise ValueError('The running controller does not match the reviewed local profile.')
    try:
        checkpoint()
        client.request('/api/v1/governance/mode', {'mode': profile.autonomy_mode})
        checkpoint()
        result = client.request('/api/v1/governance/resume', {})
        if result.get('emergency_stopped') is not False:
            raise RuntimeError('The controller did not confirm the approved startup.')
        checkpoint()
    except Exception:
        try:
            client.request('/api/v1/governance/emergency-stop', {})
        except Exception:
            pass  # The owner also stops the session on an uncertain startup.
        raise


def session_arguments(config):
    d = Path(config['directory'])
    common = ['--event-profile', config['event_profile'], '--range-deployment']
    controller = ['controller', '--bind', '127.0.0.1', '--port', str(config['port']), '--supervise',
        '--token-file', str(d/'master.json'), '--operator-token-file', str(d/'operator.txt'),
        '--operator-principal-id', config['principal'], '--database', str(d/'controller.db'),
        '--recovery-anchor', str(d/'recovery.anchor'), '--recovery-key-file', str(d/'recovery.key'),
        '--tls-cert', config['ca_file'], '--tls-ca-file', config['ca_file'], '--tls-key', str(d/'controller.key'),
        '--maintenance-interval', '5', *common]
    if config.get('autonomy') == 'guarded-autonomous':
        controller.append('--auto-recover-services')
    agent = ['agent', '--controller', config['origin'], '--agent-id', 'local-linux',
        '--token-file', str(d/'enrollment.json'), '--state-dir', str(d/'agent-state'),
        '--probe-config', str(d/'probes.json'), '--ca-file', config['ca_file'],
        '--expected-package-sha256', config['runtime_sha256'], '--allow-service-recovery',
        '--allow-restoration', '--interval', '10', *common]
    return controller, agent


# The session runner restarts a child that exits (2.0.17, review bug 6). The
# delay doubles from CHILD_RESTART_DELAY up to MAX_CHILD_RESTART_DELAY while
# exits keep coming within CHILD_FAILURE_WINDOW seconds; it never gives up. A
# child that keeps exiting within RAPID_EXIT_SECONDS of starting is restarted
# every CRASH_LOOP_DELAY seconds after RAPID_EXITS_BEFORE_SLOWDOWN such exits
# in a row: each start is recorded in the host's append-only change ledger.
CHILD_RESTART_DELAY = 2.0
MAX_CHILD_RESTART_DELAY = 60.0
CHILD_FAILURE_WINDOW = 300.0
RAPID_EXIT_SECONDS = 30.0
RAPID_EXITS_BEFORE_SLOWDOWN = 10
CRASH_LOOP_DELAY = 300.0
# A restart that finds the host change ledger busy is retried this much later.
LEDGER_BUSY_RETRY_SECONDS = 10.0
# How long a previous runner's verified processes get to stop on SIGTERM.
ORPHAN_STOP_SECONDS = 30.0
CHILD_ROLES = {'controller': 'controller supervisor', 'agent': 'agent'}


def child_restart_delay(recent_exits, rapid_exits=0):
    """Seconds before restarting a child that exited recent_exits times within the window."""
    if rapid_exits >= RAPID_EXITS_BEFORE_SLOWDOWN:
        return CRASH_LOOP_DELAY
    return min(MAX_CHILD_RESTART_DELAY, CHILD_RESTART_DELAY * 2 ** (max(1, recent_exits) - 1))


def _current_identity(identity):
    """The live process a record names, or None when that process is gone.

    Every recorded field must match. The one allowed difference is an
    executable replaced on disk while the process ran (Linux then reports
    its path with " (deleted)"): the PID, start time, boot, file identity,
    user and session still prove it is the same process.
    """
    from .process_identity import inspect_process_identity
    try:
        current = inspect_process_identity(identity['process_id'], boot_id=identity['boot_id'])
    except (FileNotFoundError, ProcessLookupError):
        return None
    except OSError as exc:
        if 'different host boot' in str(exc):
            return None
        raise
    if current == identity:
        return current
    path = current.get('executable_path', '')
    if path.endswith(' (deleted)') and dict(current, executable_path=path[:-len(' (deleted)')]) == identity:
        return current
    return None   # Another process now has this PID; it is never signalled.


def _record_children(directory, config, identities, previous=()):
    write_private_json(directory/'session-processes.json', {
        'schema': 1, 'session_id': config['session_id'], 'children': identities,
        'previous': [{'role': role, 'identity': identity} for role, identity in previous],
        'updated_at': time.time()})


def read_previous_session_processes(directory, config):
    """[(role, identity)] recorded by an earlier runner of this session.

    A record that is not this session's, or is malformed, is refused every
    time and never overwritten, so it stays for review.
    """
    from .process_identity import validate_process_identity
    path = directory/'session-processes.json'
    if not path.exists() and not path.is_symlink():
        return []
    saved = read_private_json(path, 64 * 1024)
    if (not isinstance(saved, dict) or saved.get('session_id') != config['session_id']
            or not isinstance(saved.get('children'), dict) or not isinstance(saved.get('previous', []), list)):
        raise RuntimeError('The saved session process record is not this session\'s. Review the session directory.')
    rows = list(saved['children'].items()) + [
        (row.get('role'), row.get('identity')) if isinstance(row, dict) else (None, None)
        for row in saved.get('previous', [])]
    entries = []
    for role, value in rows:
        if role not in CHILD_ROLES:
            raise RuntimeError('The saved session process record names an unknown process role.')
        try:
            entries.append((role, validate_process_identity(value)))
        except ValueError as exc:
            raise RuntimeError('The saved session process record is malformed: ' + str(exc)) from exc
    return entries


def retire_previous_session_processes(pending):
    """Stop the verified processes an earlier runner of this session left behind.

    Runs only while this runner holds the session lock, so no other runner is
    alive. A process is signalled only while it is still the recorded one
    (see _current_identity); a reused PID is never signalled. Entries are
    removed from `pending` only once verified stopped, so whatever is left
    after a failure stays recorded for the next start. Returns what stopped.
    """
    from .process_identity import ProcessIdentityMismatch, signal_verified_process
    stopped, waiting = [], []
    for entry in list(pending):
        role, identity = entry
        current = _current_identity(identity)
        if current is None:
            pending.remove(entry)
            continue
        try:
            signal_verified_process(current['process_id'], current, 'terminate')
        except (ProcessLookupError, ProcessIdentityMismatch):
            if _current_identity(identity) is None:
                pending.remove(entry)
                continue
            raise
        waiting.append(entry)
    deadline = time.monotonic() + ORPHAN_STOP_SECONDS
    for entry in waiting:
        role, identity = entry
        while _current_identity(identity) is not None:
            if time.monotonic() >= deadline:
                raise RuntimeError(f'The previous session\'s {CHILD_ROLES[role]} (process {identity["process_id"]}) did not stop'
                                   f' within {ORPHAN_STOP_SECONDS:.0f} s. Stop it, then start the session again.')
            time.sleep(.2)
        pending.remove(entry)
        stopped.append({'role': role, 'process_id': identity['process_id']})
    return stopped


STOP_REQUEST = 'stop-session.json'
_RUN_TOKEN = re.compile(r'^[0-9a-f]{32}$')


def request_session_stop(config, *, run_id=None, launch_id=None):
    """Ask the session runner to stop (2.0.18).

    The request names the runner it is for: the running one (`run_id`, from
    session-status.json) or the one a launcher just started (`launch_id`). A
    runner stops only for a request naming it, or for an unscoped one written
    while it runs, and removes the request it honoured, so a request left
    behind by a stopped or failed session never stops a later start.
    """
    request = {'session_id': config['session_id']}
    for field, value in (('run_id', run_id), ('launch_id', launch_id)):
        if value is not None:
            if not isinstance(value, str) or not _RUN_TOKEN.fullmatch(value):
                raise ValueError(f'invalid session {field}')
            request[field] = value
    write_private_json(Path(config['directory'])/STOP_REQUEST, request)


def request_running_session_stop(config):
    """Stop the session's current runner, as named in its latest status."""
    try:
        status = read_private_json(Path(config['directory'])/'session-status.json', 4096)
    except (OSError, ValueError):
        status = {}
    run_id = status.get('run_id') if isinstance(status, dict) else None
    request_session_stop(config, run_id=run_id if isinstance(run_id, str) and _RUN_TOKEN.fullmatch(run_id) else None)


def session_runner_alive(config):
    """Whether a session runner currently holds this session's lock."""
    import fcntl
    path = Path(config['directory'])/'desktop-session.lock'
    if not path.exists():
        return False
    descriptor = os.open(path, os.O_RDWR | os.O_NOFOLLOW)
    try:
        fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        return True
    else:
        fcntl.flock(descriptor, fcntl.LOCK_UN)
        return False
    finally:
        os.close(descriptor)


def _classify_stop(request, config, run_id, launch_id):
    """'stop' for a request naming this runner (or none), 'stale' for another's, None for another session's."""
    if not isinstance(request, dict) or request.get('session_id') != config['session_id']:
        return None
    targets = {field: request[field] for field in ('run_id', 'launch_id') if field in request}
    if not targets:
        return 'stop'           # unscoped, as written before 2.0.18
    if targets.get('run_id') == run_id or (launch_id is not None and targets.get('launch_id') == launch_id):
        return 'stop'
    return 'stale'


def _take_stop_request(directory, config, run_id, launch_id, *, starting=False):
    """Remove the request if it is this runner's or stale; return True to stop.

    The file is first renamed aside, so only the exact request that was read
    is ever removed: a request written in between is a new file and stays.
    At start (`starting`) only a request naming this launch is honoured; any
    other request for this session was left for a runner that is gone.
    """
    path = directory/STOP_REQUEST
    if not path.exists() and not path.is_symlink():
        return False
    verdict = _classify_stop(read_private_json(path, 4096), config, run_id, launch_id)
    if verdict is None:
        return False            # another session's request is not ours to remove
    claimed = directory/f'.{STOP_REQUEST}.{run_id}.taken'
    try:
        os.replace(path, claimed)
    except FileNotFoundError:
        return False
    try:
        taken = read_private_json(claimed, 4096)
    except (OSError, ValueError):
        os.replace(claimed, path)      # keep an unreadable request for review, as before
        raise
    verdict = _classify_stop(taken, config, run_id, launch_id)
    if verdict is None:
        # Replaced by another session's request in between: put it back.
        try:
            os.link(claimed, path)
        except FileExistsError:
            pass
        claimed.unlink()
        return False
    claimed.unlink()
    if verdict == 'stale':
        return False
    # At start, an unscoped request predates this runner; one naming it does not.
    return not starting or taken.get('run_id') == run_id or (
        launch_id is not None and taken.get('launch_id') == launch_id)


def run_session(args):
    """Own child handles; stop requests never contain a PID or shell command.

    2.0.17 (review bug 6): a child that exits is restarted with a capped
    backoff instead of ending the session, and processes a previous runner of
    this session left behind are stopped (by verified identity) before new
    ones start. A child is not restarted when the approved profile or the
    runtime changed, or when emergency withdrawal paused this host.

    2.0.18: a stop request is honoured only if it names this runner (its
    run_id or the launcher's launch_id), or names none and was written after
    this runner started. It is removed once honoured, and one for a runner
    that is gone is removed as stale.
    """
    from .desktop_jobs import detach
    from .event_profile import load_event_profile
    from .mutation_ledger import LedgerBusy
    from .process_identity import inspect_process_identity
    import signal
    import fcntl
    path = Path(args.session).absolute()
    config = read_private_json(path, 2 * 1024 * 1024)
    directory = path.parent
    runtime = Path(sys.argv[0])
    launch_id = getattr(args, 'launch_id', None)
    if launch_id is not None and not _RUN_TOKEN.fullmatch(launch_id):
        raise ValueError('Session launch identifier is invalid.')
    run_id = uuid.uuid4().hex
    if directory != Path(config['directory']) or hashlib.sha256(runtime.read_bytes()).hexdigest() != config['runtime_sha256']:
        raise ValueError('Session runtime or directory changed. Review a fresh session.')
    # Separate from the persistent controller lock. Duplicate desktop launches
    # cannot race to start another pair of processes.
    lock = os.open(directory/'desktop-session.lock', os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        os.close(lock)
        return 2
    children, stopped = {}, False
    identities, started_at = {}, {}
    # The process record is rewritten only after it has been read and
    # trusted; until then an earlier runner's identities stay untouched.
    record = {'trusted': False, 'previous': []}
    def stop(_signum, _frame):
        nonlocal stopped
        stopped = True
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    def receipt(state, reason=''):
        write_private_json(directory/'session-status.json', {'state': state, 'reason': reason,
            'session_id': config['session_id'], 'run_id': run_id,
            **({'launch_id': launch_id} if launch_id else {}), 'updated_at': time.time()})
    def stop_requested():
        # Honoured requests and stale ones are removed; see _take_stop_request.
        return _take_stop_request(directory, config, run_id, launch_id)
    # Before this run is announced, any request already here was left for a
    # runner that is gone (this one holds the session lock), unless it names
    # this launch: the launcher may already have asked it to stop.
    stop_at_start = False
    def admission():
        # Said here, in words the window shows: the controller would only exit
        # "before readiness" and the reason would be lost with its stderr.
        try:
            from .mutation_tracking import admission_refusal
            return admission_refusal()
        except (OSError, ValueError):
            return None
    def save():
        if not record['trusted']:
            return
        try:
            _record_children(directory, config, {role: identities[role] for role, child in children.items()
                                                 if role in identities and child.poll() is None},
                             record['previous'])
        except (OSError, ValueError):
            pass
    def spawn(role, arguments):
        child = detach(arguments)
        children[role] = child
        started_at[role] = time.monotonic()
        try:
            identities[role] = inspect_process_identity(child.pid)
        except (OSError, ValueError):
            identities.pop(role, None)   # Not recorded: it cannot be retired later.
        save()
        return child
    try:
        # A request set aside by a runner that died before removing it.
        for leftover in directory.glob(f'.{STOP_REQUEST}.*.taken'):
            try:
                leftover.unlink()
            except OSError:
                pass
        stop_at_start = _take_stop_request(directory, config, run_id, launch_id, starting=True)
        receipt('starting')
        if stop_at_start:
            receipt('stopping', 'Stopped by its launcher before it started.')
            return 0
        refusal = admission()
        if refusal:
            raise RuntimeError(refusal)
        profile_fingerprint = load_event_profile(config['event_profile']).fingerprint
        record['previous'] = read_previous_session_processes(directory, config)
        record['trusted'] = True
        retired = retire_previous_session_processes(record['previous'])
        save()
        controller_args, agent_args = session_arguments(config)
        arguments = {'controller': controller_args, 'agent': agent_args}
        controller = spawn('controller', controller_args)
        client = client_for(config)
        deadline = time.monotonic() + 45
        while not stopped:
            if stop_requested():
                stopped = True
                break
            if controller.poll() is not None:
                raise RuntimeError('Controller exited before readiness. Review the Recovery tab and session files.')
            try:
                client.dashboard()
                break
            except (OSError, RuntimeError, ValueError):
                if time.monotonic() >= deadline:
                    raise RuntimeError('Controller did not become ready; its selected port may now be occupied.')
                time.sleep(.2)
        if stopped:
            receipt('stopping')
            return 0
        spawn('agent', agent_args)
        ready = 'Controller ready; waiting for fresh agent telemetry.'
        if retired:
            ready += ' Stopped ' + ', '.join(f'{CHILD_ROLES[row["role"]]} {row["process_id"]}' for row in retired) + \
                ' left by an earlier run of this session.'
        receipt('running', ready)
        from . import setup_redo
        automatic_redo = config.get('autonomy') == 'guarded-autonomous'
        next_redo_check = time.monotonic() + setup_redo.TICK_SECONDS
        failures = {role: [] for role in CHILD_ROLES}
        rapid = {role: 0 for role in CHILD_ROLES}
        restarts = {role: 0 for role in CHILD_ROLES}
        restart_at = {}
        def counts():
            return f'Restarts this session: agent {restarts["agent"]}, controller supervisor {restarts["controller"]}.'
        while not stopped:
            if stop_requested():
                break
            for role, child in list(children.items()):
                if role in restart_at or child.poll() is None:
                    continue
                now = time.monotonic()
                failures[role] = [x for x in failures[role] if now - x < CHILD_FAILURE_WINDOW]
                failures[role].append(now)
                rapid[role] = rapid[role] + 1 if now - started_at.get(role, now) < RAPID_EXIT_SECONDS else 0
                delay = child_restart_delay(len(failures[role]), rapid[role])
                restart_at[role] = now + delay
                slowed = (f' It exited within {RAPID_EXIT_SECONDS:.0f} s of starting {rapid[role]} times in a row,'
                          f' so restarts are {delay / 60:.0f} minutes apart until it stays up.'
                          if rapid[role] >= RAPID_EXITS_BEFORE_SLOWDOWN else '')
                receipt('running', (f'The {CHILD_ROLES[role]} exited (code {child.returncode}); restarting it in'
                                    f' {delay:.0f} s.{slowed} ' + counts())[:500])
            for role, due in list(restart_at.items()):
                if time.monotonic() < due or stopped:
                    continue
                # A restart never bypasses what a start checks: an emergency
                # withdrawal pause ends the session, and a changed profile or
                # runtime is a hold that needs a fresh review. A busy ledger
                # only delays the restart.
                try:
                    refusal = admission()
                except LedgerBusy:
                    restart_at[role] = time.monotonic() + LEDGER_BUSY_RETRY_SECONDS
                    receipt('running', f'Restarting the {CHILD_ROLES[role]} waits for the host change ledger, which is'
                            f' busy; retrying in {LEDGER_BUSY_RETRY_SECONDS:.0f} s. ' + counts())
                    continue
                if refusal:
                    raise RuntimeError(refusal)
                try:
                    changed = (hashlib.sha256(runtime.read_bytes()).hexdigest() != config['runtime_sha256']
                               or load_event_profile(config['event_profile']).fingerprint != profile_fingerprint)
                except OSError:
                    restart_at[role] = time.monotonic() + MAX_CHILD_RESTART_DELAY
                    continue
                except ValueError:
                    changed = True
                if changed:
                    raise RuntimeError('The approved event profile or the runtime changed while the session ran;'
                                       ' its processes are not restarted. Review a fresh session.')
                try:
                    spawn(role, arguments[role])
                except OSError as exc:
                    restart_at[role] = time.monotonic() + MAX_CHILD_RESTART_DELAY
                    receipt('running', f'The {CHILD_ROLES[role]} could not be started ({type(exc).__name__});'
                            f' retrying in {MAX_CHILD_RESTART_DELAY:.0f} s. ' + counts())
                    continue
                del restart_at[role]
                restarts[role] += 1
                receipt('running', f'Restarted the {CHILD_ROLES[role]} at {time.strftime("%H:%M:%S")}. ' + counts())
            if time.monotonic() >= next_redo_check:
                next_redo_check = time.monotonic() + setup_redo.TICK_SECONDS
                # When repair cannot fix a service, run its approved setup
                # again (guarded mode), or keep the evidence the Recovery tab
                # uses to offer it (approval mode). Never ends the session.
                try:
                    setup_redo.tick(directory, client.dashboard(), automatic=automatic_redo, client=client,
                                    close_incident=lambda agent, service: client.request(
                                        f'/api/v1/agents/{agent}/services/recovered',
                                        {'service': service, 'source': 'setup_redo'}))
                except Exception:
                    pass
            time.sleep(.3)
        receipt('stopping')
    except Exception as exc:
        receipt('failed', str(exc)[:500])
        return 2
    finally:
        for role in ('agent', 'controller'):
            child = children.get(role)
            if child is not None and child.poll() is None:
                child.terminate()
                try:
                    child.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    child.kill()
                    child.wait(timeout=5)
        save()
        current = read_private_json(directory/'session-status.json', 4096)
        if current.get('state') != 'failed':
            receipt('stopped', 'Local monitoring stopped. Configured services and action records remain.')
        os.close(lock)
    return 0
