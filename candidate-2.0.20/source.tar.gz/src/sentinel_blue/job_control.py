"""Durable operator pause for jobs sharing one desktop workspace.

An epoch is an admission permit, not a resume token. Pausing invalidates every
old permit permanently. Already admitted transactions may finish their bounded
verification/rollback; stopped jobs always need a new reviewed run.
"""

from __future__ import annotations

import secrets
import time
from contextlib import contextmanager
from pathlib import Path

from .credential_vault import private_directory
from .state import AgentProcessLock, read_private_json, write_private_json


class SetupPaused(Exception):
    """No new setup transaction was admitted at this boundary."""


class JobControl:
    def __init__(self, workspace):
        self.directory = Path(workspace).absolute() / 'job-control'
        self.path = self.directory / 'control.json'

    @contextmanager
    def _locked(self):
        guard = private_directory(self.directory)
        lock = AgentProcessLock(self.directory)
        try:
            deadline = time.monotonic() + 2
            while True:
                try:
                    lock.acquire()
                    break
                except RuntimeError:
                    if time.monotonic() >= deadline:
                        raise TimeoutError('Setup pause storage is busy; pause is not confirmed') from None
                    time.sleep(.01)
            yield
        finally:
            lock.close()
            if guard is not None:
                guard.close()

    def read(self):
        value = read_private_json(self.path, 4096)
        if (not isinstance(value, dict) or set(value) != {'version', 'epoch', 'paused'}
                or type(value['version']) is not int or value['version'] != 1 or type(value['paused']) is not bool
                or not isinstance(value['epoch'], str) or len(value['epoch']) != 32
                or any(c not in '0123456789abcdef' for c in value['epoch'])):
            raise ValueError('Invalid setup pause state; review the desktop workspace')
        return value

    def initialize(self):
        existed = self.directory.exists()
        with self._locked():
            if not self.path.exists() and not self.path.is_symlink():
                if existed:
                    raise ValueError('Setup pause state is missing from an existing control directory; review it before recovery')
                write_private_json(self.path, {'version': 1, 'epoch': secrets.token_hex(16), 'paused': False})
            return self.read()

    def set_paused(self, paused):
        if type(paused) is not bool:
            raise ValueError('Pause state must be a boolean')
        with self._locked():
            value = self.read()
            if paused and not value['paused']:
                value['epoch'] = secrets.token_hex(16)
            value['paused'] = paused
            write_private_json(self.path, value)
        from .recording import emit
        emit('setup_pause_changed', {'paused': paused, 'epoch': value['epoch']})
        return value

    def admit(self):
        value = self.read()
        if value['paused']:
            raise SetupPaused('Setup is paused. Resume and review a new plan before starting it.')
        return value['epoch']

    def permit(self, epoch):
        return JobPermit(self, epoch)


class JobPermit:
    def __init__(self, control, epoch):
        self.control, self.epoch = control, epoch
        self.reason = ''

    def checkpoint(self):
        if not self.reason:
            try:
                value = self.control.read()
                if value['paused'] or value['epoch'] != self.epoch:
                    self.reason = 'Operator paused setup; review completed transactions before a new run'
            except (OSError, ValueError) as exc:
                self.reason = 'Setup pause state is unavailable (' + type(exc).__name__ + '); no new transaction admitted'
        if self.reason:
            raise SetupPaused(self.reason)
