"""Bounded restore capability evidence; display messages are never path authority."""
from __future__ import annotations

MAX_PATHS = 2048
MAX_PATH_LENGTH = 4096
MAX_PATH_BYTES = 256 * 1024
FIELD = 'restore_point_health'


def validate(value):
    if not isinstance(value, dict) or set(value) != {'schema', 'authority', 'complete', 'lost', 'rebuilt'}:
        raise ValueError('restore point health fields are invalid')
    if type(value['schema']) is not int or value['schema'] != 1:
        raise ValueError('restore point health schema is unsupported')
    if value['authority'] not in {'available', 'unavailable', 'unknown'} or type(value['complete']) is not bool:
        raise ValueError('restore point authority/coverage is invalid')
    total = 0
    result = dict(value)
    for key in ('lost', 'rebuilt'):
        paths = value[key]
        if not isinstance(paths, list) or len(paths) > MAX_PATHS:
            raise ValueError('restore point path limit exceeded')
        seen = set()
        for path in paths:
            if (not isinstance(path, str) or not 1 <= len(path) <= MAX_PATH_LENGTH
                    or any(ord(c) < 32 for c in path) or path in seen):
                raise ValueError('restore point paths must be complete unique strings')
            total += len(path.encode('utf-8'))
            seen.add(path)
        result[key] = list(paths)
    if total > MAX_PATH_BYTES:
        raise ValueError('restore point evidence byte limit exceeded')
    return result


def from_audit(report):
    """An overflowing or malformed report remains explicitly incomplete, never clipped identities."""
    result = {'schema': 1, 'authority': 'available', 'complete': True, 'lost': [], 'rebuilt': []}
    if not isinstance(report, dict):
        return dict(result, authority='unknown', complete=False)
    if report.get('metadata_errors'):
        result['authority'] = 'unavailable'
    used = 0
    for key in ('lost', 'rebuilt'):
        paths = report.get(key, [])
        if not isinstance(paths, (list, tuple)):
            result['complete'] = False
            continue
        for path in paths:
            if (not isinstance(path, str) or not 1 <= len(path) <= MAX_PATH_LENGTH
                    or any(ord(c) < 32 for c in path)):
                result['complete'] = False
                continue
            if path in result[key]:
                continue
            size = len(path.encode('utf-8'))
            if len(result[key]) >= MAX_PATHS or used + size > MAX_PATH_BYTES:
                result['complete'] = False
                continue
            result[key].append(path)
            used += size
    return validate(result)


def evidence(telemetry):
    """Legacy diagnostic loss is conservatively scoped to this agent's restoration capability.

    Old peers lack structured identifiers. Their truncated strings must not be
    reinterpreted as trusted complete filenames. Old positive notices need not
    block independent restarts, but any ambiguous restore failure does block
    file-restoring plans. New peers carry a complete per-observation report.
    """
    if FIELD in telemetry:
        try:
            return validate(telemetry[FIELD])
        except (ValueError, TypeError, UnicodeError):
            return from_audit(None)
    result = from_audit({})
    errors = telemetry.get('collector_errors') or []
    sources = telemetry.get('collector_issue_sources') or []
    for index, error in enumerate(errors):
        source = sources[index] if isinstance(sources, list) and index < len(sources) else None
        if source == 'restore_points' or (isinstance(error, str) and error.startswith('restore point')):
            # Compatibility is fail-closed. Legacy human text cannot establish
            # a sound path scope or authenticate a metadata notice.
            if not isinstance(error, str) or not error.startswith('restore point rebuilt: '):
                result.update(authority='unknown', complete=False)
    return result


def refusal(telemetry, paths):
    paths = set(paths)
    if not paths:
        return None  # A restart needing no restoration does not require backups.
    state = evidence(telemetry)
    if state['authority'] != 'available':
        return 'restore-point metadata authority is unavailable; file restoration requires review'
    if not state['complete']:
        return 'restore-point coverage is incomplete; file restoration requires review'
    if paths.intersection(state['lost']):
        return 'a required restore point is lost; file restoration requires review'
    return None
