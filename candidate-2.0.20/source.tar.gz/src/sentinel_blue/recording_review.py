"""Read-only activity review. Lack of a nearby alert is a review lead, not an attack verdict."""
from __future__ import annotations
from collections import Counter,defaultdict
from bisect import bisect_left
import hashlib
import json
import shutil
import tempfile
import zipfile
from pathlib import Path
from .recording import inspect_bundle,MAX_EVENT


def events(path):
    """Stream verified JSON evidence without executing or restoring anything."""
    with zipfile.ZipFile(path) as archive:
        if 'events.jsonl' in archive.namelist():
            with archive.open('events.jsonl') as stream:
                while True:
                    line=stream.readline(MAX_EVENT+1)
                    if not line:break
                    if len(line)>MAX_EVENT:raise ValueError('Activity event exceeds its bound')
                    yield json.loads(line)
        else:
            for name in archive.namelist():
                if not name.endswith('.zip'):continue
                with tempfile.TemporaryFile() as file:
                    with archive.open(name) as source:shutil.copyfileobj(source,file)
                    file.seek(0)
                    with zipfile.ZipFile(file) as inner,inner.open('events.jsonl') as stream:
                        while True:
                            line=stream.readline(MAX_EVENT+1)
                            if not line:break
                            if len(line)>MAX_EVENT:raise ValueError('Activity event exceeds its bound')
                            yield json.loads(line)


def review(path,*,limit=5000,window_seconds=30):
    if type(limit) is not int or not 1<=limit<=10000:raise ValueError('Invalid review limit')
    manifest=inspect_bundle(path)
    alerts=defaultdict(list);host_agents={};samples=Counter();kinds=Counter()
    for event in events(path):
        kinds[event['kind']]+=1;data=event.get('data') or {}
        if event['kind'] not in {'agent_observation','controller_observation'}:continue
        telemetry=data.get('telemetry',data)
        agent=telemetry.get('agent_id','unknown');host=telemetry.get('hostname')
        if isinstance(host,str):host_agents[host]=agent
        samples[agent]+=1
        if event['kind']=='controller_observation' and data.get('alert_ids'):
            if len(alerts[agent])<10000:alerts[agent].append(event['at'])
    for values in alerts.values():values.sort()
    rows=[];seen=set();total=0;counts=Counter();gaps=[]
    def add(row,agent,default_at):
        nonlocal total
        if not isinstance(row,dict):return
        kind=row.get('kind','native_audit')
        at=row.get('occurred_at',row.get('at',default_at))
        if type(at) not in (int,float):at=default_at
        event_id=row.get('event_id');event_id=event_id if isinstance(event_id,str) else None
        path=row.get('path');path=path if isinstance(path,str) else None
        source=row.get('source');source=source if isinstance(source,str) else None
        identity=(agent,event_id) if event_id else (agent,kind,at,path,source)
        if identity in seen:return
        if len(seen)<250000:seen.add(identity)
        counts[kind]+=1
        if kind in {'coverage','coverage_gap'}:
            if row.get('available') is False or row.get('possibly_truncated') or row.get('audit_policy_verified') is False or row.get('object_rules_verified') is False or kind=='coverage_gap':
                if len(gaps)<1000:gaps.append(dict(row,agent_id=agent))
            return
        total+=1
        times=alerts[agent];position=bisect_left(times,at)
        nearby=any(abs(times[i]-at)<=window_seconds for i in (position-1,position) if 0<=i<len(times))
        if len(rows)<limit:rows.append(dict(row,agent_id=agent,at=at,nearby_alert_observed=nearby))
    for event in events(path):
        kind=event['kind'];data=event.get('data') or {}
        if kind in {'agent_observation','controller_observation'}:
            telemetry=data.get('telemetry',data);agent=telemetry.get('agent_id','unknown')
            for row in telemetry.get('activity_evidence',[]):add(row,agent,event['at'])
            for row in telemetry.get('security_events',[]):add(dict(row,kind='native_audit'),agent,event['at'])
        elif kind=='native_audit_evidence':
            for row in data.get('events',[]):add(dict(row,kind='native_audit',source=data.get('source','unknown')),host_agents.get(data.get('hostname'),'unknown'),event['at'])
        elif kind=='protected_file_access':
            for row in data.get('events',[]):add(row,'unknown',event['at'])
        elif kind=='protected_file_activity':
            for item in data.get('paths',[]):
                if isinstance(item,dict) and isinstance(item.get('path'),str):
                    add({'kind':'protected_file_change','path':item['path'],'source':data.get('source','unknown'),'actor':'unknown'},'unknown',event['at'])
        elif kind in {'activity_gap','audit_coverage'}:
            add(dict(data,kind='coverage_gap' if kind=='activity_gap' else 'coverage'),'unknown',event['at'])
    rows.sort(key=lambda row:row['at'])
    return {'format':'sentinel-blue-activity-review-v1','verified':True,
        'recording':manifest,'activity_count':total,'shown':len(rows),'truncated':total>len(rows),
        'activity_kind_counts':dict(counts),'recording_kind_counts':dict(kinds),'coverage_gaps':gaps,
        'limitations':['Observed activity is not attributed to red team without independent ground truth.',
            'A nearby alert can concern different activity; absence of one is only a review lead.',
            'Object/process access requires the operating system to audit it. Disabled policies and unlogged activity are not recoverable.',
            'Linux read/open notifications identify paths with coalesced counts; file notifications do not identify the actor or every read.',
            'Root/SYSTEM can alter host evidence. Remote evidence not delivered remains on its source.',
            'Alert context is bounded to10,000 alerted observations per host; output is bounded.'],
        'activities':rows}


def run(args):
    result=review(args.bundle)
    from .state import write_private_json
    output=Path(args.output).absolute()
    from .credential_vault import private_directory
    guard=private_directory(output.parent)
    try:write_private_json(output,result)
    finally:
        if guard:guard.close()
    print(json.dumps({'output':str(output),'activity_count':result['activity_count'],'truncated':result['truncated']}))
