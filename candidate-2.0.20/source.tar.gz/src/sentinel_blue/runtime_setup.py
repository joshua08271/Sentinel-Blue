"""Verify an already staged, version-pinned Windows Python; never download it."""
from __future__ import annotations

import re


def windows_python(options):
    version = options.get("version")
    digest = options.get("sha256")
    directory = options.get("install_directory")
    if not isinstance(version, str) or not re.fullmatch(r"3\.(?:1[1-9]|[2-9][0-9])\.[0-9]{1,3}", version):
        raise ValueError("windows-python requires an exact Python 3.11+ release")
    if not isinstance(digest, str) or not re.fullmatch(r"[a-f0-9]{64}", digest):
        raise ValueError("windows-python requires the approved installer SHA-256")
    if not isinstance(directory, str) or not re.fullmatch(
            r"[A-Za-z]:\\ProgramData\\[A-Za-z0-9_-]+(?:\\[A-Za-z0-9_-]+){0,4}", directory):
        raise ValueError("windows-python requires a dedicated ProgramData directory")
    executable = directory + r"\python.exe"
    check = f"""$ErrorActionPreference = 'Stop'
$python = '{executable}'
if (-not (Test-Path -LiteralPath $python -PathType Leaf)) {{ exit 10 }}
$node = Get-Item -LiteralPath '{directory}' -Force
while ($null -ne $node) {{
  if (($node.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {{ exit 42 }}
  $node = $node.Parent
}}
$actual = & $python -I -S -c 'import platform; print(platform.python_version())'
if ($LASTEXITCODE -ne 0 -or [string]$actual -ne '{version}') {{ exit 10 }}
exit 0
"""
    apply = check.replace("{ exit 10 }", "{ Write-Error 'Offline prerequisite missing: stage an approved local Python runtime before setup'; exit 25 }")
    return check, apply, None
