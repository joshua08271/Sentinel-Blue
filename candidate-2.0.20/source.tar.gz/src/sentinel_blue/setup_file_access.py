"""Reviewed creation ownership and effective-reader checks for Linux setup files.

Embedded as stdlib-only code in the generated check/apply scripts. Existing file
ownership is preserved. The probe opens the path with the reviewed Unix identity,
not a root descriptor inherited by a child. This does not model a daemon's MAC
policy, mount namespace, chroot or systemd sandbox; native acceptance is separate.
"""
from __future__ import annotations

import base64
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys

ACCESS_FIELDS = frozenset({'create_owner', 'create_group', 'readable_by'})
NAME = re.compile(r'[a-zA-Z_][a-zA-Z0-9_.-]{0,63}\Z')
MODES = {'0600', '0640', '0644'}


def validate(contract):
    if (not isinstance(contract, dict) or set(contract) != ACCESS_FIELDS | {'mode'}
            or not isinstance(contract['mode'], str) or contract['mode'] not in MODES
            or any(not isinstance(contract[key], str) or not NAME.fullmatch(contract[key])
                   for key in ACCESS_FIELDS)):
        raise ValueError('Invalid reviewed file access contract')


def resolve(contract):
    import pwd
    import grp
    validate(contract)
    # Resolve on the target, before the first write. Missing package-created
    # users/groups are prerequisites, never silently replaced with root.
    owner = pwd.getpwnam(contract['create_owner'])
    group = grp.getgrnam(contract['create_group'])
    reader = pwd.getpwnam(contract['readable_by'])
    groups = os.getgrouplist(reader.pw_name, reader.pw_gid)
    return owner.pw_uid, group.gr_gid, reader.pw_uid, reader.pw_gid, groups


def trusted_parent(path):
    if not path.is_absolute() or '..' in path.parts:
        raise ValueError('Noncanonical file access path')
    for parent in path.parents:
        info = parent.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
            raise ValueError('Untrusted file access parent')


# This subprocess drops root and all inherited supplemental groups *before* the
# open. It emits neither contents nor subprocess exception text.
READER = '''import os,stat,sys
fd=os.open(sys.argv[1], os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
try:
    st=os.fstat(fd)
    if not stat.S_ISREG(st.st_mode) or st.st_nlink != 1 or st.st_size > 4*1024*1024:
        raise ValueError("unsafe read probe target")
    os.read(fd,1)
finally:
    os.close(fd)
'''


# The interpreter may live in Sentinel's private root-owned extraction tree.
# Initialize that trusted interpreter first, then irreversibly discard all
# privileged IDs/groups before opening the target. No target descriptor is
# inherited, and no contents are emitted. Relaxing the bundle's permissions or
# falling back to a system interpreter would break its offline/security contract.
IDENTITY_READER = """import os,sys,json
uid=int(sys.argv[2]); gid=int(sys.argv[3]); groups=json.loads(sys.argv[4])
if type(uid) is not int or type(gid) is not int or not isinstance(groups,list):
    raise ValueError("invalid reader identity")
os.setgroups(groups)
os.setresgid(gid,gid,gid)
os.setresuid(uid,uid,uid)
if os.getresuid()!=(uid,uid,uid) or os.getresgid()!=(gid,gid,gid):
    raise ValueError("reader identity was not dropped")
""" + READER


def check(path, contract):
    trusted_parent(path)
    _, _, uid, gid, groups = resolve(contract)
    result = subprocess.run([sys.executable, '-I', '-S', '-c', IDENTITY_READER, str(path), str(uid), str(gid), json.dumps(groups)],
        stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        close_fds=True, timeout=10,
        env={'PATH':'/usr/sbin:/usr/bin:/sbin:/bin', 'LANG':'C.UTF-8'})
    if result.returncode:
        raise ValueError('Configuration is unreadable by the reviewed service identity')


def stage(path, target, contract):
    trusted_parent(path)
    trusted_parent(target)
    owner, group, _, _, _ = resolve(contract)
    try:
        existing = target.lstat()
    except FileNotFoundError:
        existing = None
    if existing is not None and (not stat.S_ISREG(existing.st_mode) or existing.st_nlink != 1):
        raise ValueError('Unsafe existing configuration')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size > 4*1024*1024:
            raise ValueError('Unsafe configuration stage')
        if existing is None:
            os.fchown(fd, owner, group)
        elif (info.st_uid, info.st_gid) != (existing.st_uid, existing.st_gid):
            raise ValueError('Existing configuration ownership was not preserved')
        os.fchmod(fd, int(contract['mode'], 8))
    finally:
        os.close(fd)
    check(path, contract)


def main():
    try:
        if os.geteuid() != 0 or len(sys.argv) not in {3, 4, 5}:
            raise ValueError('Invalid file access invocation')
        operation = sys.argv[1]
        if len(sys.argv[2]) > 2048:
            raise ValueError('Oversized file access contract')
        contract = json.loads(base64.b64decode(sys.argv[2], validate=True))
        if operation == 'resolve' and len(sys.argv) == 3:
            resolve(contract)
        elif operation == 'check' and len(sys.argv) == 4:
            check(Path(sys.argv[3]), contract)
        elif operation == 'stage' and len(sys.argv) == 5:
            stage(Path(sys.argv[3]), Path(sys.argv[4]), contract)
        else:
            raise ValueError('Invalid file access operation')
        return 0
    except (OSError, ValueError, KeyError, subprocess.SubprocessError):
        print('Sentinel file access check failed: verify the reviewed service identity, '
              'creation ownership and directory access; no permissions were relaxed.', file=sys.stderr)
        return 42


if __name__ == '__main__':
    raise SystemExit(main())
