"""Verify private recovery directories using native handles and Windows ACLs."""
from __future__ import annotations

import base64
import ctypes
from pathlib import Path


SYSTEM_SID = bytes.fromhex('010100000000000512000000')
ADMINISTRATORS_SID = bytes.fromhex('01020000000000052000000020020000')
CREATOR_OWNER_SID = bytes.fromhex('010100000000000300000000')
OWNER_RIGHTS_SID = bytes.fromhex('010100000000000304000000')


def validate_private_descriptor(encoded, current_user):
    from .restoration import _windows_security_descriptor_semantics
    parts = _windows_security_descriptor_semantics(encoded)
    trusted = {current_user, SYSTEM_SID, ADMINISTRATORS_SID}
    if not current_user or parts[3] not in trusted:
        raise ValueError('Windows recovery directory has an untrusted owner')
    dacl = parts[6]
    if not parts[2] & 4 or dacl is None:
        raise ValueError('Windows recovery directory has no restrictive DACL')
    for kind, flags, body in dacl[1]:
        # Denials do not grant access. Reject unfamiliar grant semantics rather
        # than treating object/callback ACEs as harmless ordinary allowances.
        if kind == 1:
            continue
        if kind != 0 or len(body) < 12:
            raise ValueError('Windows recovery directory has an unsupported access rule')
        access, sid = int.from_bytes(body[:4], 'little'), body[4:]
        if len(sid) != 8 + 4*sid[1] or sid[0] != 1:
            raise ValueError('Windows recovery directory has an invalid access identity')
        inherited_creator = sid == CREATOR_OWNER_SID and flags & 8
        # Python 3.13 mkdir(0o700) uses OWNER RIGHTS, not a literal user SID.
        # It grants the object's current owner; that owner was independently
        # required to be trusted above. It is not a general public allowance.
        trusted_owner_rights = sid == OWNER_RIGHTS_SID
        if access and sid not in trusted and not inherited_creator and not trusted_owner_rights:
            raise ValueError('Windows recovery directory grants access to another identity')


def _current_user(advapi, kernel):
    token = ctypes.c_void_p()
    kernel.GetCurrentProcess.restype = ctypes.c_void_p
    advapi.OpenProcessToken.argtypes = [ctypes.c_void_p, ctypes.c_uint32,
                                       ctypes.POINTER(ctypes.c_void_p)]
    advapi.OpenProcessToken.restype = ctypes.c_int
    advapi.GetTokenInformation.argtypes = [ctypes.c_void_p, ctypes.c_int,
                                         ctypes.c_void_p, ctypes.c_uint32,
                                         ctypes.POINTER(ctypes.c_uint32)]
    advapi.GetTokenInformation.restype = ctypes.c_int
    advapi.IsValidSid.argtypes = [ctypes.c_void_p]
    advapi.IsValidSid.restype = ctypes.c_int
    advapi.GetLengthSid.argtypes = [ctypes.c_void_p]
    advapi.GetLengthSid.restype = ctypes.c_uint32
    kernel.CloseHandle.argtypes = [ctypes.c_void_p]
    kernel.CloseHandle.restype = ctypes.c_int
    if not advapi.OpenProcessToken(kernel.GetCurrentProcess(), 8, ctypes.byref(token)):
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        needed = ctypes.c_uint32()
        advapi.GetTokenInformation(token, 1, None, 0, ctypes.byref(needed))
        if not ctypes.sizeof(ctypes.c_void_p) <= needed.value <= 4096:
            raise ValueError('Windows recovery identity exceeds its bound')
        buffer = ctypes.create_string_buffer(needed.value)
        if not advapi.GetTokenInformation(token, 1, buffer, len(buffer), ctypes.byref(needed)):
            raise ctypes.WinError(ctypes.get_last_error())
        sid = ctypes.cast(buffer, ctypes.POINTER(ctypes.c_void_p))[0]
        if not advapi.IsValidSid(sid):
            raise ValueError('Windows recovery identity is invalid')
        size = advapi.GetLengthSid(sid)
        if not 8 <= size <= 68:
            raise ValueError('Windows recovery identity exceeds its bound')
        return ctypes.string_at(sid, size)
    finally:
        if not kernel.CloseHandle(token):
            raise ctypes.WinError(ctypes.get_last_error())


def _require_private_handle(handle):
    """Check the actual open object's descriptor, without reopening its path."""
    advapi = ctypes.WinDLL('advapi32', use_last_error=True)
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    current_user = _current_user(advapi, kernel)
    advapi.GetSecurityInfo.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_uint32,
        ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_void_p)]
    advapi.GetSecurityInfo.restype = ctypes.c_uint32
    advapi.IsValidSecurityDescriptor.argtypes = [ctypes.c_void_p]
    advapi.IsValidSecurityDescriptor.restype = ctypes.c_int
    advapi.GetSecurityDescriptorLength.argtypes = [ctypes.c_void_p]
    advapi.GetSecurityDescriptorLength.restype = ctypes.c_uint32
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    kernel.LocalFree.restype = ctypes.c_void_p
    descriptor = ctypes.c_void_p()
    error = advapi.GetSecurityInfo(handle, 1, 5, None, None, None, None, ctypes.byref(descriptor))
    if error:
        raise ctypes.WinError(error)
    try:
        if not advapi.IsValidSecurityDescriptor(descriptor):
            raise ValueError('Windows recovery object security is invalid')
        size = advapi.GetSecurityDescriptorLength(descriptor)
        if not 20 <= size <= 65536:
            raise ValueError('Windows recovery object security exceeds its bound')
        encoded = base64.b64encode(ctypes.string_at(descriptor, size)).decode('ascii')
        validate_private_descriptor(encoded, current_user)
    finally:
        if kernel.LocalFree(descriptor):
            raise ctypes.WinError(ctypes.get_last_error())


def require_private_file_descriptor(descriptor: int):
    """Validate a caller-owned CRT descriptor; the caller retains its lifetime."""
    import msvcrt
    from .restoration import _WindowsNativeFileOps, WINDOWS_REPARSE_POINT_ATTRIBUTE
    handle = msvcrt.get_osfhandle(descriptor)
    if _WindowsNativeFileOps().file_attributes(handle) & WINDOWS_REPARSE_POINT_ATTRIBUTE:
        raise ValueError('Windows recovery file is a reparse point')
    _require_private_handle(handle)


def require_private_directory(path: Path):
    from .restoration import (
        _WindowsNativeFileOps, _windows_pinned_parent, _windows_child_path,
        WINDOWS_FILE_READ_ATTRIBUTES, WINDOWS_FILE_SHARE_READ, WINDOWS_FILE_SHARE_WRITE,
        WINDOWS_OPEN_EXISTING, WINDOWS_FILE_FLAG_BACKUP_SEMANTICS,
        WINDOWS_FILE_FLAG_OPEN_REPARSE_POINT, WINDOWS_FILE_ATTRIBUTE_DIRECTORY,
        WINDOWS_REPARSE_POINT_ATTRIBUTE,
    )
    native = _WindowsNativeFileOps()
    with _windows_pinned_parent(path.absolute(), native, allow_target_rename=True) as (_, parent, leaf):
        handle = native.open_file(_windows_child_path(parent, leaf),
            0x20000 | WINDOWS_FILE_READ_ATTRIBUTES,
            WINDOWS_FILE_SHARE_READ | WINDOWS_FILE_SHARE_WRITE, WINDOWS_OPEN_EXISTING,
            WINDOWS_FILE_FLAG_BACKUP_SEMANTICS | WINDOWS_FILE_FLAG_OPEN_REPARSE_POINT)
        try:
            attributes = native.file_attributes(handle)
            if not attributes & WINDOWS_FILE_ATTRIBUTE_DIRECTORY or attributes & WINDOWS_REPARSE_POINT_ATTRIBUTE:
                raise ValueError('Windows recovery destination is not a non-reparse directory')
            _require_private_handle(handle)
        finally:
            native.close(handle)
