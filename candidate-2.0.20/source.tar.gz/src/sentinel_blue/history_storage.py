"""Bound controller history with authenticated archives and explicit backpressure.

Archives are forensic records, never executable recovery or training authority.
Only a committed archive transaction removes live evidence. Current observations,
unfinished work, learning anchors, and current baseline receipts stay online.
"""
from __future__ import annotations

import gzip
import hashlib
import hmac
import io
import json
import math
import os
from pathlib import Path
import shutil
import threading
import time
import uuid
from dataclasses import asdict, dataclass

from . import __version__
from .json_codec import canonical_json_bytes, strict_json_loads, validate_json_value
from .recovery import (
    _atomic_private_write, _fsync_directory, _read_regular_bytes,
    _require_private_directory, sign_payload, verify_signed_payload,
)

MIB = 1024 * 1024
MAX_BATCH_BYTES = 8 * MIB
MAX_ARCHIVE_BYTES = MAX_BATCH_BYTES + 128 * 1024
MAX_BATCH_UNITS = 256
MAX_DIRECTORY_ENTRIES = 4096
MAGIC = b"SBHISTORY1\n"
STATE_KEY = "history_retention_v1"
KEYS = {
    "telemetry_observations": "observation_id", "alert_occurrences": "occurrence_id",
    "alert_lineage": "alert_id", "learning_labels": "label_id", "alerts": "alert_id",
    "actions": "action_id", "baseline_promotions": "promotion_id",
    "learning_feedback": "feedback_id", "external_events": "event_id",
    "audit_log": "audit_id", "change_grants": "grant_id",
    "privileged_authorizations": "authorization_id", "enrollment_tickets": "ticket_hash",
    "agent_reenrollment": "agent_id",
    "telemetry_boots": ("agent_id", "credential_epoch", "profile_fingerprint", "boot_id"),
    "http_request_replay": ("agent_id", "marker_sha256"),
    "operator_request_replay": ("principal_id", "credential_epoch", "request_id"),
}


class StoragePressure(RuntimeError):
    """The caller must retain its queued telemetry and retry later."""


@dataclass(frozen=True)
class HistoryPolicy:
    retention_days: int = 30
    minimum_online_seconds: int = 3600
    database_max_bytes: int = 512 * MIB
    archive_max_bytes: int = 1024 * MIB
    archive_max_files: int = 256
    archive_days: int = 90
    minimum_free_bytes: int = 256 * MIB
    backup_max_bytes: int = 2048 * MIB

    def __post_init__(self):
        bounds = {
            "retention_days": (1, 3650), "minimum_online_seconds": (60, 86400),
            "database_max_bytes": (32 * MIB, 1024**4),
            "archive_max_bytes": (16 * MIB, 1024**4), "archive_max_files": (2, 256),
            "archive_days": (1, 3650), "minimum_free_bytes": (8 * MIB, 1024**4),
            "backup_max_bytes": (32 * MIB, 1024**4),
        }
        for name, (low, high) in bounds.items():
            value = getattr(self, name)
            if type(value) is not int or not low <= value <= high:
                raise ValueError(f"history setting {name} is outside its supported range")

    @classmethod
    def from_args(cls, args):
        return cls(
            retention_days=args.retention_days,
            minimum_online_seconds=args.history_minimum_online_seconds,
            database_max_bytes=args.database_max_mib * MIB,
            archive_max_bytes=args.history_archive_max_mib * MIB,
            archive_max_files=args.history_archive_max_files,
            archive_days=args.history_archive_days,
            minimum_free_bytes=args.storage_minimum_free_mib * MIB,
            backup_max_bytes=args.backup_max_mib * MIB,
        )


def _encode(value):
    # Embedded SQL JSON columns are kept byte-for-byte as strings. Their size
    # needs a separate bound from ordinary HTTP JSON scalar strings.
    validate_json_value(value, max_string_chars=MAX_BATCH_BYTES,
                        max_total_string_chars=MAX_BATCH_BYTES,
                        max_container_items=4096)
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"),
                     ensure_ascii=False, allow_nan=False).encode("utf-8")
    if len(raw) > MAX_BATCH_BYTES:
        raise ValueError("history batch exceeds its byte limit")
    return raw


def read_archive(path, key, *, instance_id=None):
    """Authenticate, bound, and return one archive without importing its data."""
    raw = _read_regular_bytes(Path(path), maximum=MAX_ARCHIVE_BYTES, private=True)
    if not raw.startswith(MAGIC):
        raise ValueError("history archive format is invalid")
    header_raw, separator, compressed = raw[len(MAGIC):].partition(b"\n")
    if not separator or len(header_raw) > 64 * 1024:
        raise ValueError("history archive header is invalid")
    header = verify_signed_payload(
        strict_json_loads(header_raw, max_bytes=64 * 1024), key, purpose="history-archive",
    )
    if (header.get("schema") != 1 or header.get("format") != "sentinel-blue-history"
            or (instance_id is not None and header.get("controller_instance_id") != instance_id)
            or type(header.get("created_at")) not in (int, float)
            or not math.isfinite(header["created_at"]) or header["created_at"] < 0
            or type(header.get("payload_bytes")) is not int
            or not 0 < header["payload_bytes"] <= MAX_BATCH_BYTES
            or not hmac.compare_digest(hashlib.sha256(compressed).hexdigest(),
                                       str(header.get("compressed_sha256", "")))):
        raise ValueError("history archive identity or digest is invalid")
    if str(uuid.UUID(header["archive_id"])) != header["archive_id"]:
        raise ValueError("history archive identifier is invalid")
    with gzip.GzipFile(fileobj=io.BytesIO(compressed)) as stream:
        payload = stream.read(MAX_BATCH_BYTES + 1)
    if (len(payload) != header["payload_bytes"]
            or not hmac.compare_digest(hashlib.sha256(payload).hexdigest(),
                                       str(header.get("payload_sha256", "")))):
        raise ValueError("history archive contents are incomplete")
    # Authentication precedes parsing; canonical re-encoding also rejects
    # duplicate keys, non-finite values and structural/byte-limit violations.
    value = json.loads(payload)
    if _encode(value) != payload:
        raise ValueError("history archive contents are not canonical")
    if (set(value) != {"records", "deleted"}
            or not isinstance(value["records"], dict)
            or not isinstance(value["deleted"], dict)
            or not set(value["records"]).issubset(KEYS)
            or not set(value["deleted"]).issubset(KEYS)):
        raise ValueError("history archive record inventory is invalid")
    counts = {table: len(ids) for table, ids in value["deleted"].items()}
    if counts != header.get("deleted_counts"):
        raise ValueError("history archive deletion counts disagree")
    for table, ids in value["deleted"].items():
        records = value["records"].get(table, {})
        if not isinstance(ids, list) or not isinstance(records, dict):
            raise ValueError("history archive record set is invalid")
        if len(ids) != len(set(ids)) or any(identifier not in records for identifier in ids):
            raise ValueError("history archive is missing deleted records")
    return {"verified": True, "header": header, "contents": value, "bytes": len(raw)}


class HistoryStorage:
    def __init__(self, store, directory, key, policy=None, *, backup_keep=96):
        if store.path == ":memory:":
            raise ValueError("history retention requires a persistent database")
        self.store, self.root, self.key = store, Path(directory), key
        self.policy = policy or HistoryPolicy()
        _require_private_directory(self.root)
        self.instance_id = str(store.recovery_identity()["controller_instance_id"])
        self.prefix = f"history-{self.instance_id}-"
        self._lock = threading.RLock()
        self._cache = {}
        self._error = ""
        self._archive_bytes = self._archive_count = 0
        self._foreign_bytes = 0
        self._last_run = self._last_seconds = 0.0
        self._blocked_requests = 0
        self._capture_pins = set()
        self.backup_keep = max(2, min(int(backup_keep), 10000))
        self._backup_bytes = 0
        self._backup_seconds = 0.0
        self._backup_error = ""
        self._state = self._load_state()
        with store._lock:
            db = store._connection
            page_size = int(db.execute("PRAGMA page_size").fetchone()[0])
            # This is the last-resort database page ceiling. Admission stops
            # earlier, reserving room for action results and operator controls.
            self._effective_page_limit = int(db.execute(
                f"PRAGMA max_page_count={self.policy.database_max_bytes // page_size}"
            ).fetchone()[0]) * page_size
            db.execute("PRAGMA journal_size_limit=8388608")
        self._finish_expiry()
        self._inventory()

    def _load_state(self):
        with self.store._lock:
            row = self.store._connection.execute(
                "SELECT state_value FROM controller_state WHERE state_key=?", (STATE_KEY,)
            ).fetchone()
        if row is None:
            return {"schema": 1, "archived": {}, "expired": {}, "expired_archives": 0,
                    "committed_archives": {}, "orphan_archives_expired": 0}
        state = strict_json_loads(row[0], max_bytes=64 * 1024)
        if (not isinstance(state, dict) or state.get("schema") != 1
                or not isinstance(state.get("archived"), dict)
                or not isinstance(state.get("expired"), dict)
                or type(state.get("expired_archives")) is not int):
            raise ValueError("history retention state requires review")
        for name in ("archived", "expired"):
            if (not set(state[name]).issubset(KEYS)
                    or any(type(v) is not int or not 0 <= v <= 2**63-1 for v in state[name].values())):
                raise ValueError("history retention counters require review")
        catalog = state.get("committed_archives")
        if not isinstance(catalog, dict) or len(catalog) > 256:
            raise ValueError("history archive receipts require review")
        for identifier, digest in catalog.items():
            if str(uuid.UUID(identifier)) != identifier or len(digest) != 64:
                raise ValueError("history archive receipt is invalid")
        return state

    def _save_locked(self):
        self.store._connection.execute(
            "INSERT INTO controller_state(state_key,state_value,updated_at) VALUES(?,?,?) "
            "ON CONFLICT(state_key) DO UPDATE SET state_value=excluded.state_value, "
            "updated_at=excluded.updated_at",
            (STATE_KEY, canonical_json_bytes(self._state, max_bytes=64 * 1024).decode(), time.time()),
        )

    @staticmethod
    def _add_counts(target, counts):
        for table, count in counts.items():
            target[table] = min(2**63 - 1, int(target.get(table, 0)) + int(count))

    def _inventory(self):
        _require_private_directory(self.root)
        found, total, foreign = [], 0, 0
        with os.scandir(self.root) as iterator:
            for index, entry in enumerate(iterator):
                if index >= MAX_DIRECTORY_ENTRIES:
                    raise StoragePressure("history directory entry limit requires review")
                if entry.is_symlink() or not entry.is_file(follow_symlinks=False):
                    raise StoragePressure("history directory contains an unexpected entry")
                info = entry.stat(follow_symlinks=False)
                total += info.st_size
                if not entry.name.startswith(self.prefix) or not entry.name.endswith(".sbhistory"):
                    foreign += info.st_size
                    continue
                identity = (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)
                cached = self._cache.get(entry.name)
                if cached is None or cached[0] != identity:
                    verified = read_archive(entry.path, self.key, instance_id=self.instance_id)
                    expected = self.prefix + verified["header"]["archive_id"] + ".sbhistory"
                    if entry.name != expected:
                        raise ValueError("history archive filename disagrees with its identity")
                    cached = (identity, verified["header"])
                    self._cache[entry.name] = cached
                found.append((cached[1]["created_at"], entry.name, info.st_size, cached[1]))
        names = {item[1] for item in found}
        self._cache = {name: value for name, value in self._cache.items() if name in names}
        self._archive_bytes, self._archive_count, self._foreign_bytes = total, len(found), foreign
        present = {item[3]["archive_id"]: item[3]["payload_sha256"] for item in found}
        if any(identifier in present and present[identifier] != digest
               for identifier, digest in self._state["committed_archives"].items()):
            raise StoragePressure("a committed history archive changed")
        # Receipts remain intact. Loss of historical evidence is reported but
        # does not invalidate current trust, governance or action authority.
        self._missing_archives = sorted(set(self._state["committed_archives"]) - set(present))
        return sorted(found)

    def _finish_expiry(self):
        pending = self._state.get("pending_expiry")
        if not pending:
            return
        name = pending["name"]
        if (Path(name).name != name or not name.startswith(self.prefix)
                or not name.endswith(".sbhistory")):
            raise ValueError("history expiry state is invalid")
        path = self.root / name
        if os.path.lexists(path):
            verified = read_archive(path, self.key, instance_id=self.instance_id)
            if (verified["header"]["payload_sha256"] != pending["payload_sha256"]
                    or verified["header"]["deleted_counts"] != pending["counts"]):
                raise ValueError("history archive changed before expiry")
            path.unlink()
            _fsync_directory(self.root)
        with self.store._lock:
            previous = json.loads(json.dumps(self._state))
            self.store._connection.execute("BEGIN IMMEDIATE")
            try:
                identifier = pending["archive_id"]
                if identifier in self._state["committed_archives"]:
                    self._add_counts(self._state["expired"], pending["counts"])
                    self._state["committed_archives"].pop(identifier)
                else:
                    self._state["orphan_archives_expired"] += 1
                self._state["expired_archives"] += 1
                self._state.pop("pending_expiry")
                self._save_locked()
                self.store._connection.commit()
            except BaseException:
                self.store._connection.rollback()
                self._state = previous
                raise
        self._cache.pop(name, None)

    def _rotate(self, incoming=0):
        self._finish_expiry()
        archives = self._inventory()
        expiry = time.time() - self.policy.archive_days * 86400
        for created, name, size, header in archives:
            over = (self._archive_bytes + incoming > self.policy.archive_max_bytes
                    or self._archive_count + bool(incoming) > self.policy.archive_max_files)
            if not over and created >= expiry:
                continue
            with self.store._lock:
                previous = json.loads(json.dumps(self._state))
                self.store._connection.execute("BEGIN IMMEDIATE")
                try:
                    self._state["pending_expiry"] = {
                        "name": name, "archive_id": header["archive_id"],
                        "payload_sha256": header["payload_sha256"], "counts": header["deleted_counts"],
                        "reason": "storage_budget" if over else "retention_age",
                    }
                    self._save_locked()
                    self.store._connection.commit()
                except BaseException:
                    self.store._connection.rollback()
                    self._state = previous
                    raise
            self._finish_expiry()
            self._archive_bytes -= size
            self._archive_count -= 1
        if (self._archive_bytes + incoming > self.policy.archive_max_bytes
                or self._archive_count + bool(incoming) > self.policy.archive_max_files):
            raise StoragePressure("history archive budget cannot be reclaimed safely")

    def status(self):
        with self.store._lock:
            db = self.store._connection
            page = int(db.execute("PRAGMA page_size").fetchone()[0])
            count = int(db.execute("PRAGMA page_count").fetchone()[0])
            free = int(db.execute("PRAGMA freelist_count").fetchone()[0])
            incremental = int(db.execute("PRAGMA auto_vacuum").fetchone()[0]) == 2
        database_path = Path(self.store.path)
        wal = Path(self.store.path + "-wal")
        available = shutil.disk_usage(database_path.parent).free
        used = (count - free) * page
        wal_bytes = wal.stat().st_size if wal.exists() else 0
        wal_max = max(16 * MIB, min(128 * MIB, self.policy.database_max_bytes // 4))
        reserve = max(4 * MIB, self.policy.database_max_bytes // 10)
        blocked = (used >= self.policy.database_max_bytes - reserve
                   or available < self.policy.minimum_free_bytes or wal_bytes >= wal_max)
        reasons = []
        if getattr(self, "_missing_archives", []):
            reasons.append("historical_archives_missing")
        if used >= self.policy.database_max_bytes * 0.8:
            reasons.append("database_pressure")
        if available < self.policy.minimum_free_bytes:
            reasons.append("free_space_low")
        if wal_bytes >= wal_max:
            reasons.append("wal_checkpoint_waiting")
        if self._error:
            reasons.append(self._error)
        if self._backup_error:
            reasons.append(self._backup_error)
        if self._effective_page_limit > self.policy.database_max_bytes:
            reasons.append("existing_database_above_budget")
        return {
            "state": "blocked" if blocked else "warning" if reasons else "healthy",
            "telemetry_admission_paused": blocked,
            "missing_historical_archives": list(getattr(self, "_missing_archives", [])),
            "reasons": reasons, "database_used_bytes": used,
            "database_allocated_bytes": count * page, "database_reusable_bytes": free * page,
            "wal_bytes": wal_bytes, "wal_max_bytes": wal_max,
            "database_max_bytes": self.policy.database_max_bytes,
            "effective_database_page_limit_bytes": self._effective_page_limit,
            "free_bytes": available, "archive_bytes": self._archive_bytes,
            "archive_files": self._archive_count, "foreign_archive_bytes": self._foreign_bytes,
            "incremental_reclamation": incremental,
            "last_maintenance_at": self._last_run, "last_maintenance_seconds": self._last_seconds,
            "telemetry_backpressure_count": self._blocked_requests,
            "archived_records": dict(self._state["archived"]),
            "expired_archive_records": dict(self._state["expired"]),
            "expired_archives": self._state["expired_archives"], "policy": asdict(self.policy),
            "orphan_archives_expired": self._state["orphan_archives_expired"],
            "backup_bytes": self._backup_bytes, "last_backup_seconds": self._backup_seconds,
        }

    @staticmethod
    def _backup_usage(directory):
        total = count = 0
        for parent, directories, files in os.walk(directory, followlinks=False):
            if len(Path(parent).relative_to(directory).parts) >= 4 and directories:
                raise StoragePressure("backup directory nesting requires review")
            for name in [*directories, *files]:
                count += 1
                path = Path(parent) / name
                if count > 30000 or path.is_symlink():
                    raise StoragePressure("backup directory inventory requires review")
                if path.is_file():
                    total += path.stat().st_size
        return total

    def prepare_backup(self, directory, anchor, *, extra_bytes=0):
        from .recovery_ops import prune_recovery_backups
        try:
            status = self.status()
            estimate = status["database_allocated_bytes"] + 128 * 1024 + extra_bytes
            prune_recovery_backups(
                directory, anchor, self.key, keep=self.backup_keep,
                maximum_bytes=max(0, self.policy.backup_max_bytes - estimate),
            )
            from .controller_restore import prune_capsules
            prune_capsules(directory, anchor, self.key, keep=self.backup_keep,
                           maximum_bytes=max(0, self.policy.backup_max_bytes - estimate))
            self._backup_bytes = self._backup_usage(directory)
            if self._backup_bytes + estimate > self.policy.backup_max_bytes:
                raise StoragePressure("backup budget cannot fit a new bundle while retaining two backups")
            # Verification can make a private snapshot as well as the bundle.
            if shutil.disk_usage(directory).free < self.policy.minimum_free_bytes + 3 * estimate:
                raise StoragePressure("backup storage has insufficient free space")
        except BaseException:
            self._backup_error = "backup_storage_unavailable"
            raise

    def backup_failed(self):
        self._backup_error = "backup_creation_failed"

    def backup_completed(self, directory, seconds):
        self._backup_bytes = self._backup_usage(directory)
        self._backup_seconds = round(seconds, 4)
        self._backup_error = ("backup_budget_exceeded"
                              if self._backup_bytes > self.policy.backup_max_bytes else "")

    def admit_telemetry(self, payload):
        status = self.status()
        estimate = len(canonical_json_bytes(payload, max_bytes=2 * MIB)) * 4 + 64 * 1024
        reserve = max(4 * MIB, self.policy.database_max_bytes // 10)
        if (status["telemetry_admission_paused"]
                or status["database_used_bytes"] + estimate > self.policy.database_max_bytes - reserve
                or status["free_bytes"] < self.policy.minimum_free_bytes + estimate):
            self._blocked_requests += 1
            raise StoragePressure("controller storage is full; retain telemetry and retry")

    @staticmethod
    def _row(db, table, identifier):
        row = db.execute(f"SELECT * FROM {table} WHERE {KEYS[table]}=?", (identifier,)).fetchone()
        return dict(row) if row else None

    def _unit(self, db, table, row, *, delete_extra=()):
        records, deleted = {}, {}

        def add(name, value, *, remove=False):
            if value is None:
                return
            columns = KEYS[name]
            identifier = (json.dumps([value[column] for column in columns], separators=(",", ":"))
                          if isinstance(columns, tuple) else str(value[columns]))
            records.setdefault(name, {})[identifier] = dict(value)
            if remove:
                deleted.setdefault(name, []).append(identifier)

        add(table, row, remove=True)
        if table in {"learning_labels", "alert_occurrences", "actions", "baseline_promotions"}:
            alert_id = row.get("alert_id")
            if alert_id:
                add("alerts", self._row(db, "alerts", alert_id))
        if table == "learning_labels":
            occurrence = self._row(db, "alert_occurrences", row["occurrence_id"])
            add("alert_occurrences", occurrence)
        else:
            occurrence = row if table == "alert_occurrences" else None
        if occurrence:
            add("telemetry_observations", self._row(db, "telemetry_observations", occurrence["observation_id"]))
        if table == "baseline_promotions" and row.get("action_id"):
            add("actions", self._row(db, "actions", row["action_id"]))
        for name, value in delete_extra:
            add(name, value, remove=True)
            if name == "alert_occurrences":
                add("telemetry_observations", self._row(db, "telemetry_observations", value["observation_id"]))
        for name, values in records.items():
            for identifier, value in values.items():
                if db.execute(
                    "SELECT 1 FROM json_quarantine WHERE state='open' AND "
                    "(scope_kind='global' OR (table_name=? AND row_key=?) "
                    "OR (scope_kind='agent' AND scope_key=?)) LIMIT 1",
                    (name, identifier, str(value.get("agent_id", ""))),
                ).fetchone():
                    raise StoragePressure("unresolved evidence prevents history expiry")
        return {"records": records, "deleted": deleted}

    def _select_unit(self, db, cutoff, history_cutoff):
        # Expire labels as complete observation/occurrence/alert evidence units
        # before retiring their closed graph. Active actions and receipts pin it.
        row = db.execute("""
            SELECT l.* FROM learning_labels l JOIN alerts a ON a.alert_id=l.alert_id
            WHERE l.created_at<? AND a.status!='open'
              AND MAX(a.created_at,COALESCE(a.decided_at,0),COALESCE(a.last_observed_at,0))<?
              AND NOT EXISTS (SELECT 1 FROM actions x WHERE x.alert_id=a.alert_id)
              AND NOT EXISTS (SELECT 1 FROM baseline_promotions p WHERE p.alert_id=a.alert_id)
            ORDER BY l.created_at,l.label_id LIMIT 1
        """, (cutoff, cutoff)).fetchone()
        if row:
            return self._unit(db, "learning_labels", dict(row))
        row = db.execute("""
            SELECT o.* FROM alert_occurrences o
            JOIN telemetry_observations t ON t.observation_id=o.observation_id
            WHERE o.observed_at<? AND t.accepted_at<?
              AND NOT EXISTS (SELECT 1 FROM actions x WHERE x.agent_id=o.agent_id
                AND x.status NOT IN ('completed','failed','reconciled'))
              AND NOT EXISTS (SELECT 1 FROM alert_lineage l
                WHERE l.creation_occurrence_id=o.occurrence_id OR l.last_occurrence_id=o.occurrence_id)
              AND NOT EXISTS (SELECT 1 FROM learning_labels l WHERE l.occurrence_id=o.occurrence_id)
              AND NOT EXISTS (SELECT 1 FROM telemetry_processing p WHERE p.payload_sha256=o.observation_id)
            ORDER BY o.observed_at,o.occurrence_id LIMIT 1
        """, (history_cutoff, history_cutoff)).fetchone()
        if row:
            return self._unit(db, "alert_occurrences", dict(row))
        row = db.execute("""
            SELECT p.* FROM baseline_promotions p
            WHERE p.status!='pending' AND MAX(p.created_at,p.updated_at,COALESCE(p.completed_at,0))<?
              AND NOT EXISTS (SELECT 1 FROM baselines b
                WHERE b.agent_id=p.agent_id AND b.baseline_json=p.candidate_json)
              AND p.promotion_id NOT IN (
                SELECT n.promotion_id FROM baseline_promotions n WHERE n.agent_id=p.agent_id
                AND n.status='completed' ORDER BY n.completed_at DESC,n.promotion_id DESC LIMIT 1)
            ORDER BY p.created_at,p.promotion_id LIMIT 1
        """, (cutoff,)).fetchone()
        if row:
            return self._unit(db, "baseline_promotions", dict(row))
        capture_guard = (" AND x.action_id NOT IN (" + ",".join("?" for _ in self._capture_pins) + ")"
                         if self._capture_pins else "")
        redo_pins = getattr(self, "_redo_pins", None)
        if redo_pins is None or getattr(self, "_redo_pin_overflow", True):
            redo_guard, redo_arguments = " AND NOT (x.action_type='repair_service' AND x.status='failed')", ()
        else:
            redo_guard = (" AND NOT (x.action_type='repair_service' AND x.status='failed' AND ("
                          "x.action_id IN (SELECT value FROM json_each(?)) OR MAX(x.created_at,"
                          "COALESCE(x.completed_at,x.created_at),COALESCE(x.expires_at,x.created_at))>=?))")
            redo_arguments = (json.dumps(sorted(redo_pins)), self._redo_pin_before)
        # 2.0.18: an unreviewed failed undo holds Resume of its service; it
        # is not archived until reviewed.
        from .store import pending_undo_review_sql
        redo_guard += " AND NOT " + pending_undo_review_sql("x")
        row = db.execute("""
            SELECT x.* FROM actions x
            WHERE x.status IN ('completed','failed','reconciled')
              AND MAX(x.created_at,COALESCE(x.completed_at,0),COALESCE(x.expires_at,0))<?
              AND NOT EXISTS (SELECT 1 FROM baseline_promotions p WHERE p.action_id=x.action_id)
        """ + capture_guard + redo_guard + " ORDER BY x.created_at,x.action_id LIMIT 1",
            (min(cutoff, time.time() - 7 * 86400), *sorted(self._capture_pins), *redo_arguments)).fetchone()
        if row:
            return self._unit(db, "actions", dict(row))
        row = db.execute("""
            SELECT a.* FROM alerts a WHERE a.status!='open'
              AND MAX(a.created_at,COALESCE(a.decided_at,0),COALESCE(a.last_observed_at,0))<?
              AND NOT EXISTS (SELECT 1 FROM actions x WHERE x.alert_id=a.alert_id)
              AND NOT EXISTS (SELECT 1 FROM baseline_promotions p WHERE p.alert_id=a.alert_id)
              AND NOT EXISTS (SELECT 1 FROM learning_labels l WHERE l.alert_id=a.alert_id)
              AND NOT EXISTS (SELECT 1 FROM learning_feedback f WHERE f.alert_id=a.alert_id)
              AND (SELECT COUNT(*) FROM alert_occurrences o WHERE o.alert_id=a.alert_id)<=2
              AND NOT EXISTS (SELECT 1 FROM alert_occurrences o JOIN telemetry_processing p
                ON p.payload_sha256=o.observation_id WHERE o.alert_id=a.alert_id)
            ORDER BY a.created_at,a.alert_id LIMIT 1
        """, (cutoff,)).fetchone()
        if row:
            extras = [("alert_lineage", self._row(db, "alert_lineage", row["alert_id"]))]
            extras += [("alert_occurrences", dict(item)) for item in db.execute(
                "SELECT * FROM alert_occurrences WHERE alert_id=?", (row["alert_id"],))]
            return self._unit(db, "alerts", dict(row), delete_extra=extras)
        row = db.execute("""
            SELECT t.* FROM telemetry_observations t WHERE t.accepted_at<?
              AND NOT EXISTS (SELECT 1 FROM actions x WHERE x.agent_id=t.agent_id
                AND x.status NOT IN ('completed','failed','reconciled'))
              AND NOT EXISTS (SELECT 1 FROM alert_occurrences o WHERE o.observation_id=t.observation_id)
              AND NOT EXISTS (SELECT 1 FROM telemetry_processing p WHERE p.payload_sha256=t.observation_id)
              AND NOT EXISTS (SELECT 1 FROM agents a WHERE a.latest_payload_sha256=t.observation_id)
              AND NOT EXISTS (SELECT 1 FROM baseline_promotions p WHERE p.telemetry_sha256=t.observation_id)
            ORDER BY t.accepted_at,t.observation_id LIMIT 1
        """, (history_cutoff,)).fetchone()
        if row:
            return self._unit(db, "telemetry_observations", dict(row))
        for table, column in (
            ("learning_feedback", "created_at"), ("external_events", "created_at"),
            ("audit_log", "created_at"), ("change_grants", "expires_at"),
            ("privileged_authorizations", "expires_at"), ("enrollment_tickets", "expires_at"),
            ("agent_reenrollment", "expires_at"),
            ("http_request_replay", "expires_at"), ("operator_request_replay", "expires_at"),
        ):
            row = db.execute(f"SELECT * FROM {table} WHERE {column}<? ORDER BY {column} LIMIT 1",
                             (cutoff,)).fetchone()
            if row:
                return self._unit(db, table, dict(row))
        # Current-epoch retired boot identities remain replay fences. A prior
        # credential epoch cannot authenticate again and can age out safely.
        row = db.execute("""
            SELECT t.* FROM telemetry_boots t JOIN agents a ON a.agent_id=t.agent_id
            WHERE t.credential_epoch<a.credential_epoch AND t.last_seen_at<?
            ORDER BY t.last_seen_at LIMIT 1
        """, (cutoff,)).fetchone()
        if row:
            return self._unit(db, "telemetry_boots", dict(row))
        return None

    def _capture_pins_locked(self):
        from .store import baseline_capture_files
        db = self.store._connection
        pins = {row[0] for row in db.execute("""
            SELECT a.action_id FROM actions a WHERE a.action_type='capture_restore_point'
            AND a.status='completed' AND NOT EXISTS (
                SELECT 1 FROM actions n WHERE n.agent_id=a.agent_id
                AND n.action_type='capture_restore_point' AND n.status='completed'
                AND (n.created_at>a.created_at OR (n.created_at=a.created_at AND n.action_id>a.action_id)))
        """)}
        for row in db.execute("SELECT agent_id FROM baselines").fetchall():
            baseline = self.store.get_baseline(str(row[0]))
            if not baseline:
                continue
            expected = baseline_capture_files(baseline)
            if expected:
                receipt = self.store.matching_capture_for_agent(str(row[0]), expected)
                if receipt:
                    pins.add(receipt["action_id"])
        self._capture_pins = pins
        # 2.0.9: unresolved setup-redo evidence is never archived. Pins cover
        # failed repairs older than `_redo_pin_before`; newer failed repairs are
        # not archive candidates until a later pass classifies them.
        self._redo_pin_before = time.time() - 7 * 86400
        self._redo_pins, self._redo_pin_overflow = self.store.redo_evidence_pins_locked(
            before=self._redo_pin_before)

    @staticmethod
    def _delete_unit(db, unit):
        order = ("learning_labels", "alert_lineage", "alert_occurrences", "baseline_promotions",
                 "actions", "alerts", "telemetry_observations", "learning_feedback", "external_events",
                 "audit_log", "change_grants", "privileged_authorizations", "enrollment_tickets",
                 "agent_reenrollment", "telemetry_boots", "http_request_replay", "operator_request_replay")
        for table in order:
            for identifier in unit["deleted"].get(table, []):
                columns = KEYS[table]
                if isinstance(columns, tuple):
                    where = " AND ".join(f"{column}=?" for column in columns)
                    values = json.loads(identifier)
                else:
                    where, values = f"{columns}=?", (identifier,)
                changed = db.execute(f"DELETE FROM {table} WHERE {where}", values)
                if changed.rowcount != 1:
                    raise RuntimeError("history changed during archival")

    def _archive_batch(self, history_cutoff):
        cutoff = time.time() - self.policy.retention_days * 86400
        # Reserve an entire bounded batch before taking the SQL transaction.
        # Rotation must never commit a transaction containing pending deletions.
        self._rotate(MAX_ARCHIVE_BYTES)
        if (shutil.disk_usage(self.root).free < self.policy.minimum_free_bytes + 3 * MAX_ARCHIVE_BYTES
                or shutil.disk_usage(Path(self.store.path).parent).free
                < self.policy.minimum_free_bytes + 2 * MAX_ARCHIVE_BYTES):
            raise StoragePressure("archive storage has insufficient free space")
        start = time.monotonic()
        result = {"records": {}, "deleted": {}}
        estimated = 1024
        with self.store._lock:
            db = self.store._connection
            self._capture_pins_locked()
            db.execute("BEGIN IMMEDIATE")
            previous = json.loads(json.dumps(self._state))
            try:
                for _ in range(MAX_BATCH_UNITS):
                    unit = self._select_unit(db, cutoff, history_cutoff)
                    if not unit:
                        break
                    unit_bytes = len(_encode(unit)) + 512
                    if estimated + unit_bytes > MAX_BATCH_BYTES:
                        if not result["deleted"]:
                            raise StoragePressure("an evidence unit exceeds the archive batch limit")
                        break
                    for table, records in unit["records"].items():
                        result["records"].setdefault(table, {}).update(records)
                    for table, ids in unit["deleted"].items():
                        result["deleted"].setdefault(table, []).extend(ids)
                    self._delete_unit(db, unit)
                    estimated += unit_bytes
                    if time.monotonic() - start > 0.5:
                        break
                if not result["deleted"]:
                    db.rollback()
                    return {}
                payload = _encode(result)
                compressed = gzip.compress(payload, compresslevel=6, mtime=0)
                archive_id = str(uuid.uuid4())
                counts = {table: len(ids) for table, ids in result["deleted"].items()}
                header = {
                    "schema": 1, "format": "sentinel-blue-history", "archive_id": archive_id,
                    "controller_instance_id": self.instance_id, "runtime_version": __version__,
                    "created_at": time.time(), "policy": asdict(self.policy),
                    "payload_bytes": len(payload), "payload_sha256": hashlib.sha256(payload).hexdigest(),
                    "compressed_sha256": hashlib.sha256(compressed).hexdigest(), "deleted_counts": counts,
                }
                signed = sign_payload(header, self.key, purpose="history-archive")
                encoded = MAGIC + canonical_json_bytes(signed, max_bytes=64 * 1024) + b"\n" + compressed
                path = self.root / (self.prefix + archive_id + ".sbhistory")
                _atomic_private_write(path, encoded, maximum=MAX_ARCHIVE_BYTES, replace=False)
                verified = read_archive(path, self.key, instance_id=self.instance_id)
                if verified["contents"] != result:
                    raise RuntimeError("history archive verification disagrees with pending deletions")
                self._add_counts(self._state["archived"], counts)
                self._state["committed_archives"][archive_id] = header["payload_sha256"]
                self._state["last_archive_id"] = archive_id
                self._save_locked()
                # The archive is durable and authenticated before SQL deletion
                # becomes visible. A crash here leaves either both or extra
                # forensic evidence, never an unarchived committed deletion.
                db.commit()
                return counts
            except BaseException:
                db.rollback()
                self._state = previous
                raise

    def maintain(self):
        with self._lock:
            with self.store._lock:
                if self.store._connection.in_transaction:
                    raise RuntimeError("history maintenance cannot take over an existing transaction")
            started = time.monotonic()
            try:
                # A held external SQLite reader can keep the WAL growing even
                # when live pages are reused. Do not add bulk archival writes
                # until checkpointing can make progress again.
                with self.store._lock:
                    db = self.store._connection
                    db.execute("PRAGMA wal_checkpoint(PASSIVE)")
                    db.execute("PRAGMA busy_timeout=0")
                    try:
                        db.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                    finally:
                        db.execute("PRAGMA busy_timeout=5000")
                state = self.status()
                if state["wal_bytes"] >= state["wal_max_bytes"]:
                    self._error = "wal_checkpoint_waiting"
                    return {}
                self._rotate()
                age = self.policy.retention_days * 86400
                if state["database_used_bytes"] >= self.policy.database_max_bytes * 0.8:
                    age = self.policy.minimum_online_seconds
                with self.store._lock:
                    self._capture_pins_locked()
                    candidate = self._select_unit(
                        self.store._connection, time.time() - self.policy.retention_days * 86400,
                        time.time() - age)
                removed = self._archive_batch(time.time() - age) if candidate else {}
                with self.store._lock:
                    db = self.store._connection
                    db.execute("PRAGMA wal_checkpoint(PASSIVE)")
                    if state["incremental_reclamation"]:
                        for _ in range(128):
                            if not db.execute("PRAGMA freelist_count").fetchone()[0]:
                                break
                            db.execute("PRAGMA incremental_vacuum(1)")
                    db.execute("BEGIN IMMEDIATE")
                    try:
                        self.store._prune_resolved_quarantine_locked(
                            cutoff=time.time() - self.policy.retention_days * 86400)
                        db.commit()
                    except BaseException:
                        db.rollback()
                        raise
                self._inventory()
                self._error = ""
                return removed
            except BaseException:
                self._error = "history_maintenance_failed"
                raise
            finally:
                self._last_run = time.time()
                self._last_seconds = round(time.monotonic() - started, 4)


def add_cli(controller, subcommands):
    controller.add_argument("--history-directory", help="private authenticated history archive directory")
    controller.add_argument("--history-minimum-online-seconds", type=int, default=3600)
    controller.add_argument("--database-max-mib", type=int, default=512)
    controller.add_argument("--history-archive-max-mib", type=int, default=1024)
    controller.add_argument("--history-archive-max-files", type=int, default=256)
    controller.add_argument("--history-archive-days", type=int, default=90)
    controller.add_argument("--storage-minimum-free-mib", type=int, default=256)
    controller.add_argument("--backup-max-mib", type=int, default=2048)
    verify = subcommands.add_parser("history-verify", help="verify an authenticated history archive")
    verify.add_argument("--archive", required=True)
    verify.add_argument("--recovery-key-file", required=True)
    verify.add_argument("--output", help="write verified forensic records to a new private JSON file")
    compact = subcommands.add_parser("history-compact", help="reclaim free database pages while the controller is stopped")
    compact.add_argument("--database", required=True)
    compact.add_argument("--recovery-anchor", required=True)
    compact.add_argument("--recovery-key-file", required=True)
    compact.add_argument("--storage-minimum-free-mib", type=int, default=256)


def compact_database(database, anchor, key, *, minimum_free_bytes=256*MIB):
    """Convert/reclaim a stopped database under the same exclusive owner lock."""
    from .controller import ControllerDatabaseLock
    from .recovery_ops import controller_recovery_status
    from .store import Store
    if type(minimum_free_bytes) is not int or minimum_free_bytes < 8*MIB:
        raise ValueError("database compaction requires a positive free-space reserve")
    path = Path(database)
    with ControllerDatabaseLock(path):
        before = controller_recovery_status(path, anchor, key)
        if not before["ready"]:
            raise ValueError("controller recovery must be ready before compaction")
        old_bytes = path.stat().st_size
        if shutil.disk_usage(path.parent).free < 2*old_bytes + minimum_free_bytes:
            raise StoragePressure("database compaction requires space for a complete rewrite")
        started = time.monotonic()
        store = Store(path)
        try:
            identity = store.recovery_identity()
            with store._lock:
                store._connection.execute("PRAGMA auto_vacuum=INCREMENTAL")
                store._connection.execute("VACUUM")
                store._connection.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            if store.recovery_identity() != identity:
                raise RuntimeError("database identity changed during compaction")
        finally:
            store.close()
        after = controller_recovery_status(path, anchor, key)
        if not after["ready"]:
            raise RuntimeError("controller recovery verification failed after compaction")
        return {"compacted": True, "before_bytes": old_bytes, "after_bytes": path.stat().st_size,
                "seconds": round(time.monotonic()-started, 4), "recovery_ready": True,
                "controller_instance_id": identity["controller_instance_id"]}


def run(args):
    from .recovery import load_recovery_key
    if args.command == "history-compact":
        print(json.dumps(compact_database(
            args.database, args.recovery_anchor, load_recovery_key(args.recovery_key_file),
            minimum_free_bytes=args.storage_minimum_free_mib*MIB), indent=2))
        return 0
    result = read_archive(args.archive, load_recovery_key(args.recovery_key_file))
    if args.output:
        _atomic_private_write(Path(args.output), _encode(result["contents"]),
                              maximum=MAX_BATCH_BYTES, replace=False)
    print(json.dumps({"verified": True, "header": result["header"], "bytes": result["bytes"]}, indent=2))
    return 0
