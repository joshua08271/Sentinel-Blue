"""Runtime mutation admission and recorder integration.

Native entry points opt in once at CLI startup; tests/library integrations can
use enable() explicitly. Nested native calls form one exact object transaction.
"""
from __future__ import annotations
from contextlib import contextmanager
from contextvars import ContextVar
from functools import wraps
import os
from pathlib import Path
import sys
import uuid

from .mutation_ledger import MutationLedger, LedgerError, digest

_ENABLED = False
_DEPTH = ContextVar('sentinel_mutation_depth', default=0)
_CONTEXT = ContextVar('sentinel_mutation_context', default={})


def enable():
    global _ENABLED
    MutationLedger()  # Refuse to run with unreadable or corrupted evidence.
    _ENABLED = True


def active():
    return _ENABLED and _DEPTH.get() == 0


@contextmanager
def suppressed():
    token = _DEPTH.set(_DEPTH.get() + 1)
    try:
        yield
    finally:
        _DEPTH.reset(token)


@contextmanager
def action_context(**values):
    token = _CONTEXT.set({**_CONTEXT.get(), **values})
    try:
        yield
    finally:
        _CONTEXT.reset(token)


def mutation(target, operation, *, ownership='configuration', validate=None, adapter=None):
    if not active():
        return operation()
    from .withdrawal_native import NativeObjects
    ledger = MutationLedger()
    native = adapter or NativeObjects(ledger)
    action_id = uuid.uuid4().hex
    with suppressed():
        result = ledger.mutate(native.name, target, operation, snapshot=native.snapshot,
                               validate=validate, action_id=action_id, ownership=ownership,
                               context=_CONTEXT.get())
    from .recording import emit
    emit('mutation_committed', {'action_id': action_id, 'ownership': ownership,
                               'ledger_head': ledger.head(), 'objects': target.get('objects', [])})
    return result


def file_write(method):
    @wraps(method)
    def tracked(self, destination, data, mode, metadata=None, **kwargs):
        destination = Path(destination)
        if not active() or destination.is_relative_to(self.root):
            return method(self, destination, data, mode, metadata, **kwargs)
        from .withdrawal_native import object_target
        import base64
        target = object_target(files=[str(destination.absolute())])
        def validate(result, before, after):
            state = after['files'][str(destination.absolute())]
            return {'success': state is not None and base64.b64decode(state['bytes']) == data,
                    'ownership_proven': state is not None and base64.b64decode(state['bytes']) == data}
        return mutation(target, lambda: method(self, destination, data, mode, metadata, **kwargs), validate=validate)
    return tracked


def file_unlink(method):
    @wraps(method)
    def tracked(self, path, **kwargs):
        path = Path(path)
        if not active() or path.is_relative_to(self.root):
            return method(self, path, **kwargs)
        from .withdrawal_native import object_target
        return mutation(object_target(files=[str(path.absolute())]), lambda: method(self, path, **kwargs),
                        validate=lambda result, before, after: {'success': after['files'][str(path.absolute())] is None,
                                                               'ownership_proven': after['files'][str(path.absolute())] is None})
    return tracked


def service_transition(method):
    @wraps(method)
    def tracked(self, service, desired):
        from .withdrawal_native import object_target
        return mutation(object_target(services=[service]), lambda: method(self, service, desired))
    return tracked


def startup_transition(method):
    @wraps(method)
    def tracked(service, expected, desired):
        from .withdrawal_native import object_target
        return mutation(object_target(services=[service]), lambda: method(service, expected, desired))
    return tracked


def register_process(role):
    if not _ENABLED:
        return
    from .process_identity import inspect_process_identity
    ledger = MutationLedger()
    from .collectors import _boot_id
    identity = inspect_process_identity(os.getpid(), boot_id=_boot_id('windows' if os.name == 'nt' else 'linux'))
    with ledger.lock():
        for row in ledger.actions(include_states=True):
            if row['adapter'] == 'sentinel-process-v1' and row['target'].get('identity') == identity and row['status'] == 'committed':
                return
        target = {'identity': identity, 'role': role, 'objects': ['process:' + digest(identity)]}
        key = ledger.prepare('sentinel-process-v1', target, None, ownership='sentinel_process')
        ledger.commit(key, {'identity': identity}, {'success': True, 'runtime': str(Path(sys.argv[0]).absolute())})


def admission_refusal(ledger=None):
    """Why Sentinel may not start on this host, or None."""
    ledger = ledger or MutationLedger()
    if not ledger.paused():
        return None
    operation = ledger.withdrawal_operation() or ''
    return ('Emergency withdrawal has paused this runtime; re-enrollment requires human review. '
            'After reviewing the withdrawal report, an administrator can allow Sentinel on this '
            f'host again with: sentinel-blue withdraw-release --operation-id {operation}')


def assert_admission():
    if _ENABLED:
        refusal = admission_refusal()
        if refusal:
            raise LedgerError(refusal)


def persistence_target(target):
    from .withdrawal_native import object_target
    kind = target['kind']
    if kind in {'file', 'authorized-keys', 'systemd-service'}:
        return object_target(files=[target['path']], services=[target['service']] if kind == 'systemd-service' else [])
    if kind == 'scheduled-task':
        return object_target(tasks=[{k: target[k] for k in ('task_path', 'task_name')}])
    return object_target(persistence=[target])


def persistence_remove(method):
    @wraps(method)
    def tracked(self, target, expected, *, operation_id):
        return mutation(persistence_target(target), lambda: method(self, target, expected, operation_id=operation_id))
    return tracked


def persistence_restore(method):
    @wraps(method)
    def tracked(self, operation_id):
        if not active():
            return method(self, operation_id)
        import re
        if not re.fullmatch(r'[a-zA-Z0-9_-]{8,96}', operation_id):
            raise ValueError('Invalid persistence operation identity')
        from .state import read_private_json
        record = read_private_json(self.directory / (operation_id + '.json'))
        return mutation(persistence_target(record['target']), lambda: method(self, operation_id))
    return tracked


def password_change(method):
    @wraps(method)
    def tracked(self, name, account_id, password):
        if not active():
            return method(self, name, account_id, password)
        if os.name == 'nt':
            raise LedgerError('Windows password rotation is held: the native API cannot capture an exact reversible password pre-state')
        from .withdrawal_accounts import LinuxAccount
        ledger = MutationLedger()
        target = {'name': name, 'account_id': account_id, 'objects': ['account:' + name + ':' + account_id]}
        return mutation(target, lambda: method(self, name, account_id, password), adapter=LinuxAccount(ledger))
    return tracked


def process_control(method):
    @wraps(method)
    def tracked(process_id, expected_identity, operation):
        if not active() or operation == 'terminate':
            return method(process_id, expected_identity, operation)
        if os.name != 'posix':
            raise LedgerError('Process containment is held: this platform has no exact suspension-state rollback adapter')
        from .withdrawal_native import LinuxContainment
        import time
        native = LinuxContainment()
        target = {'identity': expected_identity, 'objects': ['containment:' + digest(expected_identity)]}
        def apply():
            method(process_id, expected_identity, operation)
            deadline = time.monotonic() + 5
            while time.monotonic() < deadline:
                state = native.snapshot(target)
                if state is None or state['stopped'] == (operation == 'suspend'):
                    return
                time.sleep(.02)
            raise LedgerError('Native containment state did not settle')
        return mutation(target, apply, ownership='sentinel_control', adapter=native)
    return tracked


def _credential_mutation(path, operation, event, *, validate=None):
    if not active() or path.name not in {'identity.json', 'enrollment.json'}:
        return operation()
    ledger = MutationLedger()
    from .withdrawal_native import file_object_id, object_target
    object_id = file_object_id(path.absolute())
    # Enrollment runs inside an already durable installation transaction,
    # possibly in a separate process. Its final snapshot includes credential
    # creation and one-time token consumption; do not create overlapping claims.
    with ledger.lock():
        owner = next((x for x in ledger.actions() if x['status'] in {'prepared', 'applied'} and
                      x.get('context', {}).get('installation') and object_id in x['target'].get('objects', [])), None)
        if owner:
            if ledger.paused():
                raise LedgerError('Enrollment is held by emergency withdrawal')
            result = operation()
            ledger.append(event, action_id=owner['action_id'], object=object_id)
            return result
    return mutation(object_target(files=[str(path.absolute())]), operation,
                    ownership='sentinel_credential', validate=validate)


def credential_bytes(method):
    @wraps(method)
    def tracked(path, encoded):
        path = Path(path)
        return _credential_mutation(path, lambda: method(path, encoded), 'installation_credential_written')
    return tracked


def credential_unlink(method):
    @wraps(method)
    def tracked(path):
        path = Path(path)
        def validate(result, before, after):
            absent = after['files'][str(path.absolute())] is None
            return {'success': absent, 'ownership_proven': absent}
        return _credential_mutation(path, lambda: method(path), 'installation_credential_removed', validate=validate)
    return tracked
