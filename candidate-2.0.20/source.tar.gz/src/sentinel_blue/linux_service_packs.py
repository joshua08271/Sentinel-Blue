"""Generated configuration for Linux competition services.

Every pack here produces the same shape the nginx adapter already produces: a set
of configuration files with their expected previous digests, and a `linux-service`
recipe that writes them, runs the product's own configuration test, and reloads —
reversing exactly what it wrote if any step fails.

Three rules hold for all of them, and the code enforces rather than documents them.

**Drop-ins, not replacements.** Where the product supports a configuration
directory, the pack writes one file into it and never touches the operator's main
configuration. Where it does not, the whole file is being replaced, so the caller
must supply the exact digest it expects to replace — an unreviewed overwrite is
refused, not merged.

**Data is never a configuration input.** Zone journals, mail queues, mailboxes,
database directories, shared files and lease files are listed in the catalog and
are never written, initialized or removed by a pack.

**Nothing weakens a service to make a check pass.** No anonymous FTP writes, no
open mail relay, no unauthenticated cache or broker exposed on a routable
address. Those combinations raise an error at plan time.

None of this has been run against the real products. Every catalog entry reports
`native_tested: False`, and a pack is not support until it passes the acceptance
matrix on the target platform.
"""

from __future__ import annotations

import hashlib
import ipaddress
import json
import shlex
import re
from pathlib import Path
from typing import Any

from .linux_service_catalog import CONFIGURE, entry
from .network_setup import identifier, port as _port
from .setup_recipes import _linux_service, _source, _boolean, DIGEST

# A generated file is owned by Sentinel and carries this marker, so an operator
# reading the host can tell immediately what wrote it and what to remove.
BANNER = "# Managed by Sentinel Blue. Reviewed setup plan; remove through Sentinel.\n"
# DNS master files use semicolon comments (RFC 1035 section 5.1), unlike
# the other configuration formats using BANNER. Keep their markers unchanged.
ZONE_BANNER = "; Managed by Sentinel Blue. Reviewed setup plan; remove through Sentinel.\n"

HOSTNAME = re.compile(r"[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*\Z")
UNIX_NAME = re.compile(r"[a-z_][a-z0-9_-]{0,31}\Z")
ABSOLUTE = re.compile(r"/[^\x00\n\r]{0,1023}\Z")


def _text(value, label, pattern, limit=256):
    if not isinstance(value, str) or len(value) > limit or not pattern.fullmatch(value):
        raise ValueError(f"{label} is missing or invalid")
    if pattern is ABSOLUTE:
        if any(part in {".", ".."} for part in value.split("/")) or "//" in value:
            raise ValueError(f"{label} must be a canonical absolute path")
        if any(c in value for c in ('"', "\\", "${", "\t")) or any(ord(c) < 32 for c in value):
            raise ValueError(f"{label} contains unsupported configuration characters")
    return value


def _integer(value, label, low, high):
    if type(value) is not int or not low <= value <= high:
        raise ValueError(f"{label} must be an integer from {low} to {high}")
    return value


def _sequence(value, label, limit=64):
    """A list option must be a list.

    Iterating a bare string yields characters and iterating a number raises, so
    without this an operator's typo becomes either a confusing per-character
    refusal or an unhandled TypeError/AttributeError. The dialog that collects
    these options only shows a correction for ValueError, so every malformed
    option has to arrive as one.

    Callers reading an operator's options go through `_option_list`, which is the
    only place that decides what an absent key means.
    """
    if value is None:
        raise ValueError(f"{label} is empty; give it a list of entries")
    if not isinstance(value, list):
        raise ValueError(f"{label} must be a list of entries, not a single "
                         f"{type(value).__name__}")
    if len(value) > limit:
        raise ValueError(f"{label} accepts at most {limit} entries")
    return value


def _option_list(options, name, label=None, default=(), limit=64):
    """A list option, where present-but-null is a mistake rather than a default.

    `options.get(name, default)` collapses two different situations: the key is
    absent, which means "use the documented default", and the key is present as
    null, which means the operator wrote something they never finished. Treating
    them alike quietly turned `"protocols": null` into an empty list -- a Dovecot
    serving no protocol at all -- and `"mynetworks": null` into a Postfix that
    trusts nothing, in both cases without the default the operator was reading
    from the documentation and without a word on screen. Absence keeps the
    default; null is refused with both of its alternatives named. This matches
    `_boolean`, which has always refused a null where it wanted true or false.
    """
    if name not in options:
        return list(default)
    value = options[name]
    if value is None:
        raise ValueError(f"{label or name} is empty; give it a list of entries, "
                         f"or remove the option entirely to keep its default")
    return _sequence(value, label or name, limit)


def _choice(value, label, allowed, message):
    """One of a fixed set of names.

    The type is tested first: an unhashable value such as a list or an object
    raises TypeError from the membership test itself, before any guard below it
    can turn the mistake into a stated refusal.
    """
    if not isinstance(value, str) or value not in allowed:
        raise ValueError(message)
    return value


def _address(value, label="listen address"):
    if not isinstance(value, str):
        raise ValueError(f"{label} must be a literal IP string")
    try:
        return str(ipaddress.ip_address(value))
    except (TypeError, ValueError):
        raise ValueError(f"{label} must be a literal IP address") from None


def _routable(value):
    """True when this address is reachable from outside the host."""
    try:
        address = ipaddress.ip_address(value)
    except ValueError:
        return True
    return not (address.is_loopback or address.is_unspecified is False and False)


def _exposed(value):
    address = ipaddress.ip_address(value)
    return not address.is_loopback


def _fields(options, allowed, label):
    if not isinstance(options, dict):
        raise ValueError(f"{label} options must be an object")
    for name in {"permit_root_login", "password_authentication", "anonymous_enable",
                 "local_enable", "write_enable", "chroot_local_user", "ssl_enable",
                 "require_tls", "read_only", "browseable", "protected_mode",
                 "allow_anonymous", "no_dhcp", "authorized", "manage_listener"} & set(options):
        _boolean(options, name)
    unknown = set(options) - set(allowed)
    if unknown:
        raise ValueError(f"unknown {label} option: {', '.join(sorted(unknown))}")


def _digest(text):
    return hashlib.sha256(text.encode()).hexdigest()


# --------------------------------------------------------------------- packs
# Each returns (generated_files, extra_service_options). A file's key is its
# absolute path; drop-in paths are used wherever the product supports them.

def _bind9(options):
    _fields(options, {"zone", "records", "allow_query", "allow_transfer", "mode",
                      "zone_file", "zone_sha256", "soa_mname", "soa_rname", "serial", "port"}, "bind9")
    zone = _text(options.get("zone"), "zone", HOSTNAME, 253).lower()
    mode = options.get("mode", "create-owned")
    generated = {}
    checked = []
    if mode == "adopt-existing":
        if "records" in options:
            raise ValueError("adopt-existing preserves zone data; records cannot be supplied or silently ignored")
        zone_path = _text(options.get("zone_file"), "zone file", ABSOLUTE, 1024)
        if not any(zone_path.startswith(prefix) for prefix in ("/etc/bind/", "/var/lib/bind/")):
            raise ValueError("adopted zone must be under /etc/bind or /var/lib/bind")
        digest = options.get("zone_sha256")
        if not isinstance(digest, str) or not DIGEST.fullmatch(digest):
            raise ValueError("adopting a zone requires its exact zone_sha256")
        checked.append({"path": zone_path, "sha256": digest})
    elif mode == "create-owned":
        if "zone_file" in options or "zone_sha256" in options:
            raise ValueError("create-owned does not replace an existing data-zone path")
        records = options.get("records")
        if not isinstance(records, list) or not 1 <= len(records) <= 256:
            raise ValueError("bind9 requires 1 to 256 zone records")
        mname = _text(options.get("soa_mname"), "soa_mname", HOSTNAME, 253)
        rname = _text(options.get("soa_rname", "hostmaster." + zone), "soa_rname", HOSTNAME, 253)
        serial = _integer(options.get("serial", 1), "zone serial", 1, 4294967295)
        zone_lines = [ZONE_BANNER, f"$ORIGIN {zone}.", "$TTL 300",
                      f"@ IN SOA {mname}. {rname}. ({serial} 3600 600 86400 300)",
                      f"@ IN NS {mname}."]
        for record in records:
            if not isinstance(record, dict) or set(record) - {"name", "type", "value", "priority"}:
                raise ValueError("zone records require name, type, value and optional MX priority")
            name = record.get("name")
            if name != "@":
                name = _text(name, "record name", HOSTNAME, 253)
            kind = _choice(record.get("type"), "record type",
                           {"A", "AAAA", "NS", "CNAME", "PTR", "MX"},
                           "this bounded zone builder accepts A, AAAA, NS, CNAME, PTR and MX only")
            value = record.get("value")
            if kind in {"A", "AAAA"}:
                value = _address(value, "record address")
                if ipaddress.ip_address(value).version != (4 if kind == "A" else 6):
                    raise ValueError("record type does not match IP address family")
            elif kind in {"NS", "CNAME", "PTR", "MX"}:
                value = _text(value, "record target", HOSTNAME, 253) + "."
                if kind == "MX":
                    value = str(_integer(record.get("priority", 10), "MX priority", 0, 65535)) + " " + value
            else:
                raise ValueError("this bounded zone builder accepts A, AAAA, NS, CNAME, PTR and MX only")
            if "priority" in record and kind != "MX":
                raise ValueError("priority is only valid for MX records")
            zone_lines.append(f"{name} IN {kind} {value}")
        zone_path = f"/etc/bind/sentinel-{zone}.zone"
        generated[zone_path] = "\n".join(zone_lines) + "\n"
    else:
        raise ValueError("bind9 mode must be create-owned or adopt-existing")
    query = [_network(v) for v in _option_list(options, "allow_query", default=["any"])]
    transfer = [_network(v) for v in _option_list(options, "allow_transfer", default=["none"])]
    lines = [BANNER, f'zone "{zone}" {{', "    type primary;", f'    file "{zone_path}";',
             "    allow-query { " + "; ".join(query) + "; };",
             "    allow-transfer { " + "; ".join(transfer) + "; };", "};"]
    generated["/etc/bind/named.conf.sentinel"] = "\n".join(lines) + "\n"
    return generated, {"checked_files": checked, "bind_zone": {"name": zone, "path": zone_path},
                       **({"bind_port": _port(options["port"])} if "port" in options else {}),
                       "activation_lines": {"/etc/bind/named.conf.local": 'include "/etc/bind/named.conf.sentinel";'}}


def _network(value):
    # Test the type before the set membership: an unhashable value such as a
    # nested list raises TypeError from `in`, before the guard below can turn it
    # into a stated refusal.
    if not isinstance(value, str):
        raise ValueError(f"invalid network in access list: {value!r}")
    if value in {"any", "none", "localhost", "localnets"}:
        return value
    try:
        return str(ipaddress.ip_network(value, strict=False))
    except (TypeError, ValueError):
        raise ValueError(f"invalid network in access list: {value!r}") from None


def _unbound(options):
    _fields(options, {"interface", "access_control", "forwarders", "port"}, "unbound")
    interface = _address(options.get("interface", "127.0.0.1"), "interface")
    access = [_network(value) for value in
              _option_list(options, "access_control", default=["127.0.0.0/8"])]
    forwarders = [_address(value, "forwarder") for value in
                  _option_list(options, "forwarders")]
    lines = [BANNER, "server:", f"    interface: {interface}"]
    if "port" in options:
        lines.append(f"    port: {_port(options['port'])}")
    lines += [f"    access-control: {network} allow" for network in access]
    if forwarders:
        lines.append("forward-zone:")
        lines.append('    name: "."')
        lines += [f"    forward-addr: {address}" for address in forwarders]
    return {"/etc/unbound/unbound.conf.d/sentinel.conf": "\n".join(lines) + "\n"}, {}


def _dnsmasq(options):
    _fields(options, {"interface", "domain", "addresses", "no_dhcp", "port"}, "dnsmasq")
    interface = _text(options.get("interface", "lo"), "interface", UNIX_NAME, 32)
    lines = [BANNER, f"interface={interface}", "bind-interfaces"]
    if "port" in options:
        lines.append(f"port={_port(options['port'])}")
    if options.get("domain"):
        lines.append("domain=" + _text(options["domain"], "domain", HOSTNAME, 253))
    # A mapping of hostname to address. A list is the natural mistake and must
    # arrive as a stated reason, not as .items() on something that has none.
    hosts = options["addresses"] if "addresses" in options else {}
    if not isinstance(hosts, dict):
        raise ValueError("dnsmasq addresses map each hostname to one literal address, "
                         "such as {\"scored.range.test\": \"192.168.10.20\"}")
    for name, address in hosts.items():
        lines.append(f"address=/{_text(name, 'name', HOSTNAME, 253)}/{_address(address)}")
    # DHCP on a shared range affects every host on it; it is opt-in elsewhere.
    if options.get("no_dhcp", True):
        lines.append("no-dhcp-interface=" + interface)
    return {"/etc/dnsmasq.d/sentinel.conf": "\n".join(lines) + "\n"}, {}


def _isc_dhcp(options):
    _fields(options, {"subnet", "netmask", "range_start", "range_end", "routers",
                      "dns_servers", "lease_seconds", "previous_sha256", "authorized"}, "dhcp")
    if options.get("authorized") is not True:
        raise ValueError(
            "enabling DHCP affects every host on the segment; this pack requires "
            "authorized=true from a reviewed event profile")
    subnet = str(ipaddress.ip_network(f"{options['subnet']}/{options['netmask']}", strict=True))
    network = ipaddress.ip_network(subnet)
    start, end = (ipaddress.ip_address(options["range_start"]),
                  ipaddress.ip_address(options["range_end"]))
    if network.version != 4 or network.prefixlen > 30:
        raise ValueError("DHCPv4 requires a subnet with usable host addresses")
    if start not in network or end not in network or end < start:
        raise ValueError("the DHCP range must lie inside its own subnet")
    if start == network.network_address or end == network.broadcast_address:
        raise ValueError("DHCP range must exclude network and broadcast addresses")
    routers = _option_list(options, "routers", "DHCP routers")
    resolvers = _option_list(options, "dns_servers", "DHCP dns_servers")
    for value in routers:
        router = ipaddress.ip_address(_address(value, "router"))
        if router not in network or router in {network.network_address, network.broadcast_address}:
            raise ValueError("DHCP router must be a usable address inside its subnet")
        if start <= router <= end:
            raise ValueError("DHCP router cannot overlap the dynamic address pool")
    lease = _integer(options.get("lease_seconds", 3600), "DHCP lease", 60, 86400)
    if not 60 <= lease <= 86400:
        raise ValueError("DHCP lease time must be 60 to 86400 seconds")
    lines = [BANNER, f"subnet {network.network_address} netmask {network.netmask} {{",
             f"    range {start} {end};",
             f"    default-lease-time {lease};", f"    max-lease-time {lease * 2};"]
    if routers:
        lines.append("    option routers " + ", ".join(
            _address(value, "router") for value in routers) + ";")
    if resolvers:
        lines.append("    option domain-name-servers " + ", ".join(
            _address(value, "dns server") for value in resolvers) + ";")
    lines.append("}")
    return {"/etc/dhcp/sentinel.conf": "\n".join(lines) + "\n"}, {
        "activation_lines": {"/etc/dhcp/dhcpd.conf": 'include "/etc/dhcp/sentinel.conf";'}}


def _chrony(options):
    _fields(options, {"sources", "allow", "port"}, "chrony")
    sources = _option_list(options, "sources", "chrony sources")
    if not sources:
        raise ValueError("chrony requires at least one approved time source")
    lines = [BANNER]
    if "port" in options:
        lines.append(f"port {_port(options['port'])}")
    lines += [f"server {_text(value, 'time source', HOSTNAME, 253)} iburst"
              if not _is_address(value) else f"server {value} iburst" for value in sources]
    lines += [f"allow {_network(value)}" for value in _option_list(options, "allow", "chrony allow")]
    return {"/etc/chrony/conf.d/sentinel.conf": "\n".join(lines) + "\n"}, {}


def _is_address(value):
    try:
        ipaddress.ip_address(value)
        return True
    except (TypeError, ValueError):
        return False


def _apache2(options):
    _fields(options, {"server_name", "document_root", "port", "tls_certificate_path",
                      "tls_key_path", "manage_listener", "listen_address"}, "apache2")
    name = _text(options.get("server_name"), "server name", HOSTNAME, 253)
    root = _text(options.get("document_root"), "document root", ABSOLUTE, 1024)
    listen = _port(options.get("port", 80))
    tls = bool(options.get("tls_certificate_path"))
    if bool(options.get("tls_key_path")) != tls:
        raise ValueError("Apache TLS requires both certificate and key paths")
    address = _address(options.get("listen_address", "0.0.0.0"))
    endpoint = f"[{address}]:{listen}" if ":" in address else f"{address}:{listen}"
    prefix = [BANNER]
    if _boolean(options, "manage_listener"):
        prefix.append(f"Listen {endpoint}")
    lines = prefix + [f"<VirtualHost {endpoint}>", f"    ServerName {name}",
             f'    DocumentRoot "{root}"',
             f"    ErrorLog ${{APACHE_LOG_DIR}}/sentinel-{name}-error.log"]
    if tls:
        certificate = _text(options["tls_certificate_path"], "certificate path", ABSOLUTE, 1024)
        key = _text(options.get("tls_key_path"), "key path", ABSOLUTE, 1024)
        lines += ["    SSLEngine on", f'    SSLCertificateFile "{certificate}"',
                  f'    SSLCertificateKeyFile "{key}"',
                  "    SSLProtocol -all +TLSv1.2 +TLSv1.3"]
    lines.append("</VirtualHost>")
    files = {f"/etc/apache2/sites-enabled/sentinel-{name}.conf": "\n".join(lines) + "\n"}
    checked = [{"path": root, "directory": True}]
    if tls:
        checked.extend([{"path": certificate}, {"path": key, "secret": True}])
    return files, {"checked_files": checked, "apache_site": name}


def _mariadb(options):
    _fields(options, {"bind_address", "port", "require_tls"}, "mariadb")
    address = _address(options.get("bind_address", "127.0.0.1"), "bind address")
    lines = [BANNER, "[mysqld]", f"bind-address = {address}",
             f"port = {_port(options.get('port', 3306))}"]
    if options.get("require_tls"):
        lines.append("require_secure_transport = ON")
    return {"/etc/mysql/mariadb.conf.d/60-sentinel.cnf": "\n".join(lines) + "\n"}, {}


def _postgresql(options):
    _fields(options, {"listen_addresses", "port", "allowed_networks", "auth_method",
                      "config_directory", "ssl_certificate_path", "ssl_key_path", "ssl_ca_path"}, "postgresql")
    method = _choice(options.get("auth_method", "scram-sha-256"), "PostgreSQL auth_method",
                     {"scram-sha-256", "md5", "cert"},
                     "PostgreSQL auth_method must be scram-sha-256, md5 or cert")
    # PostgreSQL 10 or newer (Ubuntu 24.04 ships 16, Debian 12 ships 15). Only
    # 17+ was accepted before 2.0.6, which refused every current LTS release.
    directory = _text(options.get("config_directory"), "PostgreSQL config_directory",
                      re.compile(r"/etc/postgresql/(?:1[0-9]|[2-9][0-9])/[A-Za-z0-9_-]+\Z"), 200)
    version = int(directory.split("/")[3])
    addresses = [_address(v) for v in
                 _option_list(options, "listen_addresses", default=["127.0.0.1"])]
    if not addresses:
        raise ValueError("at least one PostgreSQL listen address is required")
    lines = [BANNER, "listen_addresses = '" + ",".join(addresses) + "'",
             f"port = {_port(options.get('port', 5432))}"]
    checked = []
    tls_keys = ("ssl_certificate_path", "ssl_key_path", "ssl_ca_path")
    if method == "cert" or any(key in options for key in tls_keys):
        for key in tls_keys:
            path = _text(options.get(key), key, ABSOLUTE, 1024)
            if "'" in path:
                raise ValueError("PostgreSQL TLS paths cannot contain single quotes")
            checked.append({"path": path, "secret": key == "ssl_key_path"})
        lines += ["ssl = on", f"ssl_cert_file = '{options['ssl_certificate_path']}'",
                  f"ssl_key_file = '{options['ssl_key_path']}'", f"ssl_ca_file = '{options['ssl_ca_path']}'"]
    conf = directory + "/conf.d/60-sentinel.conf"
    files = {conf: "\n".join(lines) + "\n"}
    activation = {directory + "/postgresql.conf": "include = 'conf.d/60-sentinel.conf'"}
    networks = options.get("allowed_networks", [])
    if not isinstance(networks, list):
        raise ValueError("allowed_networks must be a list of CIDRs")
    if method == "cert" and not networks:
        raise ValueError("certificate authentication requires explicit allowed_networks")
    if networks:
        if version < 16:
            raise ValueError("pg_hba.conf can include another file only from PostgreSQL 16; "
                             "omit allowed_networks for this cluster, or manage its pg_hba.conf yourself")
        networks = [str(ipaddress.ip_network(v, strict=False)) for v in networks]
        kind = "hostssl" if method == "cert" else "host"
        hba = directory + "/sentinel-pg-hba.conf"
        files[hba] = BANNER + "\n".join(f"{kind} all all {n} {method}" for n in networks) + "\n"
        # pg_hba.conf quotes with double quotes. The single-quoted form used
        # before 2.0.6 names a file whose name includes the quotes, so the
        # server refuses to start (checked against a real PostgreSQL 16).
        activation[directory + "/pg_hba.conf"] = 'include "sentinel-pg-hba.conf"'
    return files, {"checked_files": checked, "activation_lines": activation,
                   "postgres_cluster": directory}


def _redis(options):
    _fields(options, {"bind_address", "port", "password_file", "protected_mode",
                      "acl_file", "acl_sha256"}, "redis")
    if "password_file" in options:
        raise ValueError("password_file was never applied by Redis: supply a reviewed acl_file and acl_sha256 instead; plaintext secret paths are not authentication")
    address = _address(options.get("bind_address", "127.0.0.1"), "bind address")
    if _exposed(address) and not options.get("acl_file"):
        raise ValueError("binding Redis outside loopback without a reviewed ACL would expose an unauthenticated data store")
    lines = [BANNER, f"bind {address}", f"port {_port(options.get('port', 6379))}",
             "protected-mode " + ("yes" if _boolean(options, "protected_mode", True) else "no")]
    checked = []
    if options.get("acl_file"):
        acl = _text(options["acl_file"], "ACL file", ABSOLUTE, 1024)
        digest = options.get("acl_sha256")
        if not isinstance(digest, str) or not DIGEST.fullmatch(digest):
            raise ValueError("Redis ACL must be pinned by acl_sha256")
        lines.append(f'aclfile "{acl}"')
        checked.append({"path": acl, "sha256": digest, "secret": True, "redis_acl": True})
    elif "acl_sha256" in options:
        raise ValueError("acl_sha256 requires acl_file")
    return {"/etc/redis/sentinel.conf": "\n".join(lines) + "\n"}, {
        "checked_files": checked,
        "activation_lines": {"/etc/redis/redis.conf": 'include /etc/redis/sentinel.conf'},
        "redis_expected": {"bind": address, "port": str(_port(options.get("port", 6379))),
                           "protected-mode": "yes" if options.get("protected_mode", True) else "no",
                           **({"aclfile": options["acl_file"]} if options.get("acl_file") else {})}}


def _postfix(options):
    _fields(options, {"myhostname", "mydomain", "mynetworks", "relay_restrictions",
                      "message_size_limit", "smtp_port", "smtp_listener"}, "postfix")
    if "relay_restrictions" in options:
        raise ValueError("relay_restrictions is not configurable by this bounded pack; the fixed deny-relay policy is explicit")
    hostname = _text(options.get("myhostname"), "myhostname", HOSTNAME, 253)
    domain = _text(options.get("mydomain"), "mydomain", HOSTNAME, 253)
    networks = [_network(value) for value in _option_list(options, "mynetworks", default=["127.0.0.0/8"])]
    if any(value in {"none", "localhost", "localnets"} for value in networks):
        raise ValueError("Postfix mynetworks requires literal CIDRs")
    if any(network in {"any", "0.0.0.0/0", "::/0"} for network in networks):
        raise ValueError("mynetworks covering the whole internet would create an open relay")
    lines = [BANNER, f"myhostname = {hostname}", f"mydomain = {domain}",
             "mynetworks = " + " ".join(networks),
             "smtpd_relay_restrictions = permit_mynetworks, "
             "permit_sasl_authenticated, reject_unauth_destination",
             f"message_size_limit = {_integer(options.get('message_size_limit', 10240000), 'message_size_limit', 1024, 1073741824)}"]
    extra = {"merge_main_config": True}
    if "smtp_port" in options:
        extra["postfix_smtp_port"] = _port(options["smtp_port"])
        extra["postfix_smtp_selector"] = options.get("smtp_listener", "smtp")
    elif "smtp_listener" in options:
        raise ValueError("smtp_listener requires smtp_port")
    return {"/etc/postfix/main.cf": "\n".join(lines) + "\n"}, extra


def _dovecot(options):
    _fields(options, {"protocols", "mail_location", "ssl_certificate_path", "ssl_key_path",
                      "imap_port", "imaps_port", "pop3_port", "pop3s_port", "submission_port", "submissions_port"},
            "dovecot")
    protocols = _option_list(options, "protocols", default=["imap"])
    # Build the set from checked strings: an unhashable entry makes set() itself
    # raise, before the membership test below can state the reason.
    allowed = {"imap", "pop3", "lmtp", "submission"}
    if any(not isinstance(value, str) or value not in allowed for value in protocols):
        raise ValueError("dovecot protocols must be imap, pop3, lmtp or submission")
    lines = [BANNER, "protocols = " + " ".join(protocols)]
    if options.get("mail_location"):
        lines.append("mail_location = " + _text(options["mail_location"], "mail location",
                                                re.compile(r"[A-Za-z0-9:/%~._-]{1,256}\Z"), 256))
    if options.get("ssl_certificate_path"):
        lines += ["ssl = required",
                  "ssl_cert = <" + _text(options["ssl_certificate_path"], "certificate", ABSOLUTE, 1024),
                  "ssl_key = <" + _text(options.get("ssl_key_path"), "key", ABSOLUTE, 1024)]
    groups = {"imap": ("imap", "imaps"), "pop3": ("pop3", "pop3s"), "submission": ("submission", "submissions")}
    used = set()
    for protocol, listeners in groups.items():
        selected = [name for name in listeners if name + "_port" in options]
        if not selected:
            continue
        if protocol not in protocols:
            raise ValueError("Port requested for a disabled Dovecot protocol")
        lines.append("service " + protocol + "-login {")
        for listener in selected:
            port = _port(options[listener + "_port"])
            if port in used:
                raise ValueError("Dovecot listeners require distinct ports")
            used.add(port)
            secure = listener != protocol
            if secure and not (options.get("ssl_certificate_path") and options.get("ssl_key_path")):
                raise ValueError("Implicit-TLS port requires existing certificate and key")
            lines += ["    inet_listener " + listener + " {", f"        port = {port}"]
            if secure:
                lines.append("        ssl = yes")
            lines.append("    }")
        lines.append("}")
    return {"/etc/dovecot/conf.d/99-sentinel.conf": "\n".join(lines) + "\n"}, {}


def _vsftpd(options):
    _fields(options, {"anonymous_enable", "local_enable", "write_enable", "chroot_local_user",
                      "ssl_enable", "rsa_cert_file", "pasv_min_port", "pasv_max_port",
                      "previous_sha256", "listen_port"}, "vsftpd")
    anonymous = bool(options.get("anonymous_enable", False))
    write = bool(options.get("write_enable", False))
    if anonymous and write:
        raise ValueError("anonymous write access is never enabled by a generated configuration")
    listen = _port(options.get("listen_port", 21))
    lines = [BANNER, "listen=YES", f"listen_port={listen}",
             "anonymous_enable=" + ("YES" if anonymous else "NO"),
             "local_enable=" + ("YES" if options.get("local_enable", True) else "NO"),
             "write_enable=" + ("YES" if write else "NO"),
             "chroot_local_user=" + ("YES" if options.get("chroot_local_user", True) else "NO")]
    if options.get("ssl_enable"):
        lines += ["ssl_enable=YES", "force_local_data_ssl=YES", "force_local_logins_ssl=YES",
                  "rsa_cert_file=" + _text(options.get("rsa_cert_file"), "certificate", ABSOLUTE, 1024)]
    low = _port(options.get("pasv_min_port", 40000))
    high = _port(options.get("pasv_max_port", 40100))
    if high < low or high - low > 1023:
        raise ValueError("the passive port range must be ordered and at most 1024 ports")
    if low <= listen <= high:
        raise ValueError("FTP control port cannot overlap its passive range")
    lines += [f"pasv_min_port={low}", f"pasv_max_port={high}"]
    return {"/etc/vsftpd.conf": "\n".join(lines) + "\n"}, {}


def _openssh(options):
    _fields(options, {"port", "permit_root_login", "password_authentication",
                      "allow_users", "allow_groups", "sftp_only_group"}, "openssh")
    lines = [BANNER, f"Port {_port(options.get('port', 22))}",
             "PermitRootLogin " + ("yes" if options.get("permit_root_login") else "no"),
             "PasswordAuthentication " + (
                 "yes" if options.get("password_authentication", True) else "no")]
    users = [_text(value, "allowed user", UNIX_NAME, 32) for value in
             _option_list(options, "allow_users")]
    groups = [_text(value, "allowed group", UNIX_NAME, 32)
              for value in _option_list(options, "allow_groups")]
    if users:
        lines.append("AllowUsers " + " ".join(users))
    if groups:
        lines.append("AllowGroups " + " ".join(groups))
    if options.get("sftp_only_group"):
        group = _text(options["sftp_only_group"], "sftp group", UNIX_NAME, 32)
        lines += [f"Match Group {group}", "    ForceCommand internal-sftp",
                  "    ChrootDirectory %h", "    AllowTcpForwarding no"]
    return {"/etc/ssh/sshd_config.d/60-sentinel.conf": "\n".join(lines) + "\n"}, {}


def _samba(options):
    _fields(options, {"share", "path", "valid_users", "read_only", "browseable",
                      "create_mask", "directory_mask", "smb_port", "netbios_port"}, "samba")
    share = _text(options.get("share"), "share name", UNIX_NAME, 32)
    path = _text(options.get("path"), "share path", ABSOLUTE, 1024)
    users = [_text(value, "valid user", UNIX_NAME, 32)
             for value in _option_list(options, "valid_users")]
    if not users:
        raise ValueError("a generated share always names its permitted users")
    prefix = [BANNER]
    extra = {"activation_lines": {"/etc/samba/smb.conf": f"include = /etc/samba/conf.d/sentinel-{share}.conf"},
             "samba_share": {"name": share, "path": path, "valid users": users,
                             "read only": bool(options.get("read_only", True)),
                             "browseable": bool(options.get("browseable", True)),
                             "guest ok": False,
                             "create mask": _mode(options.get("create_mask", "0644")),
                             "directory mask": _mode(options.get("directory_mask", "0755"))}}
    if "smb_port" in options or "netbios_port" in options:
        smb, netbios = _port(options.get("smb_port", 445)), _port(options.get("netbios_port", 139))
        if smb == netbios:
            raise ValueError("SMB and NetBIOS listener ports must be distinct")
        prefix += ["[global]", f"    smb ports = {smb} {netbios}"]
        extra["smb_ports"] = [smb, netbios]
        extra["activation_lines"] = {"/etc/samba/smb.conf": f"include = /etc/samba/conf.d/sentinel-{share}.conf"}
    lines = prefix + [f"[{share}]", f"    path = {path}",
             "    valid users = " + " ".join(users),
             "    read only = " + ("yes" if options.get("read_only", True) else "no"),
             "    browseable = " + ("yes" if options.get("browseable", True) else "no"),
             f"    create mask = {_mode(options.get('create_mask', '0644'))}",
             f"    directory mask = {_mode(options.get('directory_mask', '0755'))}",
             "    guest ok = no"]
    return {f"/etc/samba/conf.d/sentinel-{share}.conf": "\n".join(lines) + "\n"}, extra


def _mode(value):
    if not isinstance(value, str) or not re.fullmatch(r"0[0-7]{3}", value):
        raise ValueError("a file mode must be four octal digits, such as 0644")
    return value


def _nfs(options):
    _fields(options, {"export_path", "clients", "read_only", "squash"}, "nfs")
    path = _text(options.get("export_path"), "export path", ABSOLUTE, 1024)
    clients = [_network(value) for value in _option_list(options, "clients", "nfs clients")]
    if not clients:
        raise ValueError("an export always names its permitted clients")
    if any(client in {"any", "0.0.0.0/0", "::/0"} for client in clients):
        raise ValueError("exporting to every network is never generated")
    squash = _choice(options.get("squash", "root_squash"), "squash",
                     {"root_squash", "all_squash", "no_root_squash"},
                     "squash must be root_squash, all_squash or no_root_squash")
    access = "ro" if options.get("read_only", True) else "rw"
    entries = " ".join(f"{client}({access},sync,{squash})" for client in clients)
    return {"/etc/exports.d/sentinel.exports": BANNER + f"{path} {entries}\n"}, {}


def _haproxy(options):
    _fields(options, {"frontend_port", "backends", "mode", "previous_sha256"}, "haproxy")
    listen = _port(options.get("frontend_port", 80))
    mode = _choice(options.get("mode", "http"), "haproxy mode", {"http", "tcp"},
                   "haproxy mode must be http or tcp")
    backends = _option_list(options, "backends", "haproxy backends")
    if not backends:
        raise ValueError("haproxy requires at least one backend")
    lines = [BANNER, "frontend sentinel_front", f"    bind *:{listen}", f"    mode {mode}",
             "    default_backend sentinel_back", "", "backend sentinel_back", f"    mode {mode}"]
    for index, backend in enumerate(backends):
        if not isinstance(backend, dict) or set(backend) - {"address", "port"}:
            raise ValueError("each haproxy backend is an object with address and port, "
                             "such as {\"address\": \"10.0.0.5\", \"port\": 8080}")
        address = _address(backend.get("address"), "backend address")
        lines.append(f"    server s{index} {address}:{_port(backend.get('port'))} check")
    text = "\n".join(lines) + "\n"
    return {"/etc/haproxy/conf.d/sentinel.cfg": text}, {"haproxy_expected": text}


def _rsyslog(options):
    _fields(options, {"forward_to", "forward_port", "protocol", "facility"}, "rsyslog")
    lines = [BANNER]
    if options.get("forward_to"):
        address = _address(options["forward_to"], "log destination")
        marker = "@@" if options.get("protocol", "tcp") == "tcp" else "@"
        facility = _text(options.get("facility", "*.*"), "facility",
                         re.compile(r"[a-z*]+\.[a-z*]+\Z"), 64)
        lines.append(f"{facility} {marker}{address}:{_port(options.get('forward_port', 514))}")
    else:
        raise ValueError("rsyslog pack requires a forwarding destination")
    return {"/etc/rsyslog.d/60-sentinel.conf": "\n".join(lines) + "\n"}, {}


def _mosquitto(options):
    _fields(options, {"listener_port", "bind_address", "allow_anonymous", "password_file"},
            "mosquitto")
    address = _address(options.get("bind_address", "127.0.0.1"), "bind address")
    anonymous = bool(options.get("allow_anonymous", False))
    if anonymous and _exposed(address):
        raise ValueError(
            "anonymous MQTT on a routable address would expose an unauthenticated broker")
    lines = [BANNER, f"listener {_port(options.get('listener_port', 1883))} {address}",
             "allow_anonymous " + ("true" if anonymous else "false")]
    if options.get("password_file"):
        lines.append("password_file " + _text(options["password_file"], "password file",
                                              ABSOLUTE, 1024))
    return {"/etc/mosquitto/conf.d/sentinel.conf": "\n".join(lines) + "\n"}, {}


def _host_port(address, port):
    """Format a validated literal endpoint without confusing IPv6 colons."""
    return f"[{address}]:{port}" if ipaddress.ip_address(address).version == 6 else f"{address}:{port}"


def _gunicorn(options):
    _fields(options, {"application", "working_directory", "user", "bind_address", "port",
                      "workers"}, "gunicorn")
    application = _text(options.get("application"), "application",
                        re.compile(r"[A-Za-z0-9_.:]{1,128}\Z"), 128)
    # systemd does not unquote WorkingDirectory=: the quoted form written
    # before 2.0.6 is "not absolute" and the unit never loaded (found live).
    # Plain path characters only, so the value needs no quoting at all.
    working = _text(options.get("working_directory"), "working directory",
                    re.compile(r"/[A-Za-z0-9._@+/-]{0,1023}\Z"), 1024)
    user = _text(options.get("user"), "service user", UNIX_NAME, 32)
    address = _address(options.get("bind_address", "127.0.0.1"), "bind address")
    workers = _integer(options.get("workers", 2), "gunicorn workers", 1, 32)
    if not 1 <= workers <= 32:
        raise ValueError("gunicorn workers must be 1 to 32")
    unit = [BANNER.replace("# ", "# "), "[Unit]", "Description=Sentinel-managed WSGI application",
            "After=network-online.target", "", "[Service]", "Type=simple", f"User={user}",
            f"WorkingDirectory={working}",
            f"ExecStart=/usr/bin/gunicorn --workers {workers} "
            f"--bind {_host_port(address, _port(options.get('port', 8000)))} {application}",
            "Restart=on-failure", "RestartSec=5", "NoNewPrivileges=true",
            "PrivateTmp=true", "", "[Install]", "WantedBy=multi-user.target"]
    return {"/etc/systemd/system/sentinel-gunicorn.service": "\n".join(unit) + "\n"}, {
        "checked_files": [{"path": working, "directory": True}, {"path": "/usr/bin/gunicorn"}]}


BUILDERS = {
    "bind9": _bind9, "unbound": _unbound, "dnsmasq": _dnsmasq,
    "isc-dhcp-server": _isc_dhcp, "chrony": _chrony,
    "apache2": _apache2, "gunicorn": _gunicorn,
    "mariadb": _mariadb, "postgresql": _postgresql, "redis": _redis,
    "postfix": _postfix, "dovecot": _dovecot,
    "vsftpd": _vsftpd, "openssh-server": _openssh, "samba": _samba, "nfs-server": _nfs,
    "haproxy": _haproxy, "rsyslog": _rsyslog, "mosquitto": _mosquitto,
}

# Files replaced whole rather than dropped in. The caller must state the digest
# it expects to replace, so an unreviewed overwrite is refused.
WHOLE_FILE_PACKS = {"vsftpd"}


def build(service_id: str, options: dict[str, Any], root: Path, *, metadata=None):
    """Compile one service pack to (check, apply, rollback).

    The pack is built from the catalog entry, so a service whose capability is
    adoption-only cannot be configured by naming it here.
    """
    row = entry(service_id)
    if row["capability"] != CONFIGURE:
        raise ValueError(
            f"{row['label']} is adoption-only in this release: it can be detected, "
            "validated, monitored and restarted, but its configuration is not generated")
    if service_id == "nginx":
        raise ValueError("nginx has its own established adapter; use the linux-nginx recipe")
    builder = BUILDERS.get(service_id)
    if builder is None:
        raise ValueError(f"no configuration builder for {service_id}")
    if not isinstance(options, dict):
        raise ValueError("service pack options must be an object")
    # The approved plan is compiled again from the saved inventory, whose JSON
    # has sorted keys. Build from the same canonical form here, so the order in
    # which a form or script filled these options can never change the plan.
    try:
        options = json.loads(json.dumps(options, sort_keys=True))
    except (TypeError, ValueError) as exc:
        raise ValueError(f"service pack options must be plain JSON values: {exc}") from None
    manager = options.get("manager", "apt")
    if manager != "apt":
        raise ValueError("service-pack configuration currently has only an apt/Debian-layout contract; other layouts require a separately reviewed adapter")
    previous = options.get("previous_sha256")
    if previous is not None and not (isinstance(previous, str) and (previous == "absent" or DIGEST.fullmatch(previous))):
        raise ValueError("previous_sha256 must be an exact digest or absent")
    previous_files = options.get("previous_files", {})
    if not isinstance(previous_files, dict) or any(
        not isinstance(k, str) or not isinstance(v, str) or (v != "absent" and not DIGEST.fullmatch(v))
        for k, v in previous_files.items()):
        raise ValueError("previous_files must map exact paths to digests or absent")
    common = {"previous_sha256", "previous_files", "activation", "main_config", "manager", "file_modes", "file_access", "existing_dependencies", "listener_config", "master_config"}
    generated, extra = builder({key: value for key, value in options.items() if key not in common})
    dependencies = options.get("existing_dependencies", [])
    if not isinstance(dependencies, list) or any(not isinstance(v, str) or v not in row["requires"] for v in dependencies):
        raise ValueError("existing_dependencies must name declared catalog dependencies only")
    extra["dependency_units"] = [entry(value)["unit"] for value in dependencies]
    # Product-wide port changes require an exact reviewed parent snapshot.
    port_snapshots = {}
    if "listener_config" in options or "bind_port" in extra:
        if service_id != "bind9" or "bind_port" not in extra or "listener_config" not in options:
            raise ValueError("BIND port selection requires listener_config: a hash-pinned named.conf.options snapshot")
        from .port_config_merge import bind_port
        snapshot = options["listener_config"]
        generated["/etc/bind/named.conf.options"] = bind_port(_source(root, snapshot), extra["bind_port"])
        port_snapshots["/etc/bind/named.conf.options"] = snapshot["sha256"]
    if "master_config" in options or "postfix_smtp_port" in extra:
        if service_id != "postfix" or "postfix_smtp_port" not in extra or "master_config" not in options:
            raise ValueError("Postfix port selection requires master_config: a hash-pinned master.cf snapshot")
        from .port_config_merge import postfix_smtp_port
        snapshot = options["master_config"]
        generated["/etc/postfix/master.cf"] = postfix_smtp_port(_source(root, snapshot), extra["postfix_smtp_port"], extra["postfix_smtp_selector"])
        port_snapshots["/etc/postfix/master.cf"] = snapshot["sha256"]
    file_modes = options.get("file_modes", {})
    if not isinstance(file_modes, dict) or any(not isinstance(k, str) or not isinstance(v, str) or v not in {"0600", "0640", "0644"} for k, v in file_modes.items()):
        raise ValueError("file_modes must map generated paths to 0600, 0640 or 0644")
    inferred_previous = dict(port_snapshots)
    if extra.get("merge_main_config"):
        snapshot = options.get("main_config")
        if snapshot is None:
            raise ValueError("Postfix requires main_config: a hash-pinned snapshot of /etc/postfix/main.cf; main.cf.d is not an active include directory")
        current = _source(root, snapshot)
        generated["/etc/postfix/main.cf"] = _merge_postfix(current, generated["/etc/postfix/main.cf"])
        inferred_previous["/etc/postfix/main.cf"] = snapshot["sha256"]
    elif "main_config" in options and service_id == "haproxy":
        snapshot = options["main_config"]
        current = _source(root, snapshot)
        block = generated.pop("/etc/haproxy/conf.d/sentinel.cfg")
        begin, end = "# BEGIN SENTINEL HAPROXY", "# END SENTINEL HAPROXY"
        if begin in current or end in current:
            if current.count(begin) != 1 or current.count(end) != 1:
                raise ValueError("ambiguous HAProxy managed block; review the parent configuration")
            match = re.search(r"(?m)^" + re.escape(begin) + r"\n.*?^" + re.escape(end) + r"(?:\n|$)", current, re.S)
            if match is None:
                raise ValueError("invalid HAProxy managed block boundaries")
            outside = current[:match.start()] + current[match.end():]
        else:
            match, outside = None, current
        if re.search(r"(?m)^\s*(?:frontend|backend|listen)\s+sentinel_(?:front|back)\b", outside):
            raise ValueError("HAProxy Sentinel section names already exist outside the reviewed managed block")
        replacement = begin + "\n" + block + end + "\n"
        generated["/etc/haproxy/haproxy.cfg"] = (current[:match.start()] + replacement + current[match.end():] if match
            else current + ("" if current.endswith("\n") else "\n") + replacement)
        inferred_previous["/etc/haproxy/haproxy.cfg"] = snapshot["sha256"]
    elif "main_config" in options:
        raise ValueError("main_config is only valid for a reviewed Postfix or HAProxy merge")
    activation = options.get("activation", {})
    if not isinstance(activation, dict):
        raise ValueError("activation must map allowed parent-config paths to hash-pinned source snapshots")
    permitted = extra.get("activation_lines", {})
    if set(activation) - set(permitted):
        raise ValueError("activation contains a parent configuration not owned by this pack contract")
    for path, snapshot in activation.items():
        current = _source(root, snapshot)
        line = permitted[path]
        # Byte-preserving append; the native parser must accept the result before restart.
        activation_text = ("[global]\n" + line) if service_id == "samba" else line
        generated[path] = current if line in current.splitlines() else current + ("" if current.endswith("\n") else "\n") + activation_text + "\n"
        if path.endswith("/pg_hba.conf") and line not in current.splitlines():
            generated[path] = line + "\n" + current
        inferred_previous[path] = snapshot["sha256"]
    if set(file_modes) - set(generated):
        raise ValueError("file_modes contains a path not generated by this pack")
    if set(previous_files) - set(generated):
        raise ValueError("previous_files contains a path not generated by this pack")
    if previous is not None and len(generated) != 1:
        raise ValueError("multi-file packs require previous_files per path, not one previous_sha256")
    if service_id in WHOLE_FILE_PACKS and not previous and not previous_files:
        raise ValueError(f"{row['label']} replaces its whole file; supply previous_sha256 or previous_files")
    for path, digest in inferred_previous.items():
        if path in previous_files and previous_files[path] != digest:
            raise ValueError("activation snapshot and previous_files disagree")
        if previous is not None and previous != digest:
            raise ValueError("snapshot and previous_sha256 disagree")
    access_overrides = options.get("file_access", {})
    if not isinstance(access_overrides, dict) or set(access_overrides) - set(generated):
        raise ValueError("file_access must map generated paths to reviewed access contracts")
    access_fields = {"create_owner", "create_group", "readable_by"}
    for access in access_overrides.values():
        if (not isinstance(access, dict) or set(access) != access_fields
                or any(not isinstance(access[key], str) or not re.fullmatch(r"[a-zA-Z_][a-zA-Z0-9_.-]{0,63}", access[key]) for key in access_fields)):
            raise ValueError("file_access requires explicit create_owner, create_group and readable_by names")
    files = []
    for path, value in sorted(generated.items()):
        file = {"path": path, "source": {"path": "generated", "sha256": _digest(value)},
                "mode": file_modes.get(path, "0640" if _sensitive(path) else "0644"),
                "previous_sha256": inferred_previous.get(path, previous_files.get(path, previous or "absent"))}
        access = access_overrides.get(path)
        if access is None and service_id in {"redis", "mosquitto"}:
            # Reviewed apt-layout defaults. Resolve these package-created names
            # on the host, or refuse before writing. Custom service identities
            # must use an explicit per-path override, not a guessed numeric ID.
            access = {"create_owner": "root", "create_group": service_id,
                      "readable_by": service_id}
        elif access is None and _sensitive(path):
            # These remaining built-in sensitive paths are read by the root
            # service entry point. A non-root customization needs file_access.
            access = {"create_owner": "root", "create_group": "root", "readable_by": "root"}
        if access is not None:
            file.update(access)
        files.append(file)
    service_options = {"service": row["unit"], "enable": True, "files": files}
    if row["validate_argv"]:
        service_options["validate_argv"] = list(row["validate_argv"])
    if service_id == "bind9":
        service_options["validate_argv"] = ["/usr/sbin/named-checkconf", "/etc/bind/named.conf"]
    if service_id == "postgresql":
        version, cluster = extra["postgres_cluster"].split("/")[3:5]
        service_options["member_units"] = [f"postgresql@{version}-{cluster}.service"]
    extra["mode_preconditions"] = [{"path": f["path"], "mode": f["mode"]}
                                   for f in files if f["path"] in inferred_previous]
    generated = dict(sorted(generated.items()))
    from .service_pack_checks import check_scripts
    preflight, validation = check_scripts(service_id, generated, extra)
    if metadata is not None:
        metadata.update(service=row["unit"], catalog_id=service_id,
                        native_tested=False, data_preserved=list(row["data_paths"]),
                        files=[{key: item[key] for key in ("path", "mode", "previous_sha256", "create_owner", "create_group", "readable_by") if key in item}
                               | {"sha256": item["source"]["sha256"]} for item in files],
                        **extra)
    return _linux_service(service_options, root, generated_sources=generated,
                          preflight_script=preflight, validation_script=validation)


def _merge_postfix(current, desired):
    """Replace only generated parameters (including continuation lines), preserve others."""
    wanted = {}
    for line in desired.splitlines():
        if line and not line.startswith("#"):
            key, value = line.split("=", 1)
            wanted[key.strip()] = value.strip()
    output = []
    suppress = False
    for line in current.splitlines(keepends=True):
        if line[:1].isspace() and line.strip() and not line.lstrip().startswith("#"):
            if not suppress:
                output.append(line)
            continue
        match = re.match(r"([a-zA-Z0-9_]+)\s*=", line)
        if match:
            suppress = match.group(1) in wanted
        elif line.strip() and not line.lstrip().startswith("#"):
            suppress = False
        if not (match and suppress):
            output.append(line)
    text = "".join(output)
    return text + ("" if not text or text.endswith("\n") else "\n") + desired


def _sensitive(path):
    return any(marker in path for marker in ("ssh", "redis", "mosquitto", "dhcp", "krb"))


def pack_ids() -> list[str]:
    return sorted(BUILDERS)
