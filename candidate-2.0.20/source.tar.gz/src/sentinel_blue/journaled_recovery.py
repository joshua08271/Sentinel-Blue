"""Journaled, no-file Linux service starts under existing restart permission.

The internal repair plan cannot broaden restart authority into file or startup
restoration. Its origin is retained in the journal and checked by the inverse.
"""
from __future__ import annotations
import copy
from dataclasses import asdict
import subprocess

START_JOURNAL = "service-start-v1"
START_NOOP = "service-start-noop-v1"
# Signed guards from 2.0.16 and earlier carry no validation window; their
# journals were planned with this value and must still verify for undo.
LEGACY_START_VALIDATION_SECONDS = 5


def start_validation_seconds(parameters):
    """The validation window the signed guard grants (2.0.17: from the manifest)."""
    return parameters.get("recovery_guard", {}).get("validation_timeout_seconds", LEGACY_START_VALIDATION_SECONDS)


def start_plan(parameters):
    from .policy import validate_action_parameters
    validate_action_parameters("restart_service", parameters)
    if parameters.get("recovery_guard", {}).get("recorded_undo") is not True:
        raise ValueError("journaled start requires its signed recorded-undo guard")
    result = {key: copy.deepcopy(parameters[key]) for key in ("service", "probes", "recovery_guard")}
    result["repair"] = {"restore_files": [], "observed_state": "stopped",
                        "restart_unhealthy": False, "validation_timeout_seconds": start_validation_seconds(parameters)}
    validate_action_parameters("repair_service", result)
    return result


def start(executor, parameters, telemetry, started):
    from .service_repair import plan_digest
    from .service_recovery import check_restart_target
    try:
        plan = start_plan(parameters)
        if not executor.allow_service_recovery:
            return executor._result("restart_service", True, "dry run: journaled service start requires recovery permission",
                                    started, dry_run=True)
        check_restart_target(parameters, telemetry)
        before = executor._service_state(parameters["service"])
        if before not in {"running", "stopped"}:
            raise ValueError("unknown native service state holds recovery")
        if before == "running":
            # A recovered service needs validation, not a fictitious stopped
            # before-state or a second start. No mutation/journal is issued.
            executor.repairs._verify_files(plan)
            probes, attempts, healthy = executor._wait_for_service_probes(
                parameters["probes"], grace_seconds=plan["repair"]["validation_timeout_seconds"])
            executor.repairs._verify_files(plan)
            healthy = healthy and executor._service_state(parameters["service"]) == "running"
            return executor._result("restart_service", healthy,
                "service already running; validation only, no mutation to undo", started,
                pre_state={"service": parameters["service"], "desired_state": "running"},
                stable_health=healthy, probes=[asdict(p) for p in probes], probe_attempts=attempts,
                record={"journal_kind": START_NOOP, "origin_action": "restart_service",
                        "plan_sha256": plan_digest(plan), "files": copy.deepcopy(parameters["recovery_guard"]["files"])})
        observed = next(row["state"] for row in telemetry["services"] if row["name"] == parameters["service"])
        if observed == "running":
            raise ValueError("service stopped after the latest observation; fresh diagnosis is required")
        result = executor.repairs.execute("repair_service", plan, telemetry, started,
                                         origin_action="restart_service")
        result["action_type"] = "restart_service"
        if result.get("success") is True and not result.get("dry_run"):
            result["pre_state"]["journal_kind"] = START_JOURNAL
            result["record"]["journal_kind"] = START_JOURNAL
            result["message"] = "Service started and validated; recorded prior state is available for reviewed undo"
        return result
    except (OSError, KeyError, TypeError, ValueError, RuntimeError, StopIteration, subprocess.TimeoutExpired) as exc:
        return executor._result("restart_service", False, "service recovery held: " + str(exc), started)


def undo_start(executor, parameters, telemetry, started):
    from .policy import validate_action_parameters
    validate_action_parameters("rollback_service", parameters)
    journal = executor.repairs._read(executor.repairs._path(parameters["transaction_id"]))
    if (journal.get("origin_action") != "restart_service" or journal["service"] != parameters["service"]
            or journal["before"] != parameters["desired_state"]):
        raise ValueError("recorded start inverse does not match its original authority")
    inverse = {key: parameters[key] for key in ("service", "desired_state", "transaction_id")}
    result = executor.repairs.execute("rollback_service_repair", inverse, telemetry, started,
                                     origin_action="restart_service")
    result["action_type"] = "rollback_service"
    return result
