"""Operator-entered credentials and explicit private runtime materialization."""

from __future__ import annotations

import base64
import hashlib
import os
import re
import secrets
from pathlib import Path

from .credential_vault import CredentialVault, private_directory
from .state import write_private_text, read_private_bytes


KINDS = ('password', 'ssh-key', 'winrm')


class DesktopCredentials:
    def __init__(self):
        self.vault = None

    def unlock(self, directory, passphrase, *, create=False):
        self.lock()
        self.vault = CredentialVault(directory, passphrase, create=create)

    def lock(self):
        if self.vault is not None:
            self.vault.close()
            self.vault = None

    def entries(self):
        if self.vault is None:
            return []
        return [{k: row[k] for k in ('id', 'label', 'kind', 'username', 'path')}
                for row in self.vault.data['entries'].values() if row.get('entry_type') == 'desktop']

    def save(self, label, kind, username, secret, path):
        if self.vault is None:
            raise ValueError('Unlock the credential vault first')
        if not isinstance(label, str) or not label.strip() or len(label) > 128 or kind not in KINDS:
            raise ValueError('A label and supported credential kind are required')
        if not isinstance(username, str) or len(username) > 256 or any(c in username for c in '\r\n\x00'):
            raise ValueError('Invalid credential username')
        if not isinstance(secret, str) or not secret or len(secret.encode()) > 32768 or '\x00' in secret:
            raise ValueError('A nonempty bounded credential is required')
        if kind != 'ssh-key' and ('\n' in secret or '\r' in secret):
            raise ValueError('Passwords must contain one line')
        if kind == 'ssh-key' and not re.match(r'-----BEGIN (?:OPENSSH |RSA |EC |ENCRYPTED )?PRIVATE KEY-----', secret):
            raise ValueError('Enter a PEM or OpenSSH private key')
        if kind == 'winrm' and not username:
            raise ValueError('WinRM credentials require a username')
        target = Path(path).expanduser()
        if not target.is_absolute() or target.name in {'', '.', '..'} or '..' in target.parts:
            raise ValueError('Runtime credential requires an absolute local path')
        if target == self.vault.path or target.parent == self.vault.directory:
            raise ValueError('Runtime credentials must be outside the encrypted vault directory')
        key = 'desktop:' + hashlib.sha256(str(target).encode()).hexdigest()
        row = {'entry_type': 'desktop', 'id': key, 'label': label.strip(), 'kind': kind,
               'username': username, 'path': str(target), 'secret': secret}
        self.vault.data['entries'][key] = row
        self.vault.save()
        return key

    def supply(self, key):
        from .mutation_tracking import mutation
        from .withdrawal_native import object_target
        if self.vault is None:
            raise ValueError('Unlock the credential vault first')
        row = self.vault.data['entries'].get(key)
        if not row or row.get('entry_type') != 'desktop':
            raise ValueError('Credential entry is unavailable')
        return mutation(object_target(files=[str(Path(row['path']).absolute())]),
                        lambda: self._supply(key), ownership='sentinel_credential')

    def _supply(self, key):
        if self.vault is None:
            raise ValueError('Unlock the credential vault first')
        row = self.vault.data['entries'].get(key)
        if not row or row.get('entry_type') != 'desktop':
            raise ValueError('Credential entry is unavailable')
        path = Path(row['path'])
        guard = private_directory(path.parent)
        try:
            if path.is_symlink():
                raise ValueError('Runtime credential cannot be a symbolic link')
            if path.exists():
                info = path.stat()
                if info.st_nlink != 1 or os.name == 'posix' and (info.st_uid != os.geteuid() or info.st_mode & 0o077):
                    raise ValueError('Existing runtime credential permissions are unsafe')
                read_private_bytes(path, 65536)
            if row['kind'] == 'winrm':
                self._winrm(row, path)
            else:
                value = row['secret']
                if row['kind'] == 'ssh-key' and not value.endswith('\n'):
                    value += '\n'
                write_private_text(path, value)
        finally:
            if guard is not None:
                guard.close()
        return {'path': str(path), 'kind': row['kind'], 'supplied': True}

    @staticmethod
    def _winrm(row, path):
        if os.name != 'nt':
            raise ValueError('Create WinRM credentials on the Windows operator desktop that will use them')
        from .setup_transport import SetupTransport, _ps
        incoming = path.with_name(path.name + '.' + secrets.token_hex(8) + '.incoming')
        encoded = base64.b64encode(row['secret'].encode()).decode()
        script = ("$ErrorActionPreference='Stop'\ntry {\n"
            f"$secret=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('{encoded}'))\n"
            f"$credential=[PSCredential]::new({_ps(row['username'])},(ConvertTo-SecureString $secret -AsPlainText -Force))\n"
            f"$credential | Export-Clixml -LiteralPath {_ps(str(incoming))}\nexit 0\n}} catch {{ exit 20 }}\n")
        try:
            result = SetupTransport()._powershell(script, 20)
            if result.uncertain or result.returncode != 0:
                raise RuntimeError('Windows credential creation failed; no runtime file was replaced')
            from .state import _atomic_bytes
            _atomic_bytes(path, read_private_bytes(incoming, 65536))
        finally:
            incoming.unlink(missing_ok=True)


def credential_requirements(inventory, root):
    """Only local inventory paths become credential prompts, never remote text."""
    result = {}
    def add(path, kind, label, username=''):
        if not isinstance(path, str) or not path:
            return
        target = Path(path).expanduser()
        target = target if target.is_absolute() else Path(root) / target
        result[str(target)] = {'path': str(target), 'kind': kind, 'label': label, 'username': username,
                               'available': target.is_file() and not target.is_symlink()}
    for host in inventory.get('hosts', []):
        label = str(host.get('name', host.get('address', 'Host')))
        add(host.get('key_file'), 'ssh-key', label + ' SSH key', host.get('username', ''))
        add(host.get('credential_file'), 'winrm', label + ' management', host.get('username', ''))
    profile = inventory.get('event_profile', {})
    for service in profile.get('services', []):
        for probe in service.get('expected_transactions', []):
            add(probe.get('password_file'), 'password', str(service.get('host', '')) + ' / ' + str(service.get('service_id', '')), probe.get('username', ''))
    return list(result.values())
