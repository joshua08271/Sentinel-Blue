"""Standalone exact-state guard embedded in generated Linux service recipes.

Private before/backup/post records live beside the retained shell backups. A
missing post receipt after a possible write is uncertain, not permission to undo.
This guards observable intervening edits; it is not an OS compare-and-swap against
an uncooperative privileged writer racing the final rename/unlink syscall.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import sys
import uuid

MAX_FILE = 4 * 1024 * 1024


def trusted_parent(path: Path) -> None:
    for parent in path.parents:
        info = parent.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
            raise ValueError('Untrusted setup file parent')


def snapshot(path: Path) -> dict | None:
    trusted_parent(path)
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except FileNotFoundError:
        return None
    try:
        before = os.fstat(fd)
        if (not stat.S_ISREG(before.st_mode) or before.st_nlink != 1
                or before.st_size > MAX_FILE or before.st_mode & 0o022):
            raise ValueError('Unsafe setup file')
        content = bytearray()
        while len(content) <= MAX_FILE:
            block = os.read(fd, min(65536, MAX_FILE + 1 - len(content)))
            if not block:
                break
            content.extend(block)
        if len(content) > MAX_FILE:
            raise ValueError('Setup file exceeds guard limit')
        attrs = {name: base64.b64encode(os.getxattr(fd, name)).decode()
                 for name in sorted(os.listxattr(fd))}
        def revision(info):
            return [info.st_dev, info.st_ino, info.st_mtime_ns, info.st_ctime_ns]
        if revision(before) != revision(os.fstat(fd)) or revision(before) != revision(path.lstat()):
            raise ValueError('Setup file changed during ownership check')
        return {'sha256': hashlib.sha256(content).hexdigest(),
                'uid': before.st_uid, 'gid': before.st_gid,
                'mode': stat.S_IMODE(before.st_mode), 'xattrs': attrs,
                'revision': revision(before)}
    finally:
        os.close(fd)


def equivalent(value):
    return None if value is None else {k: v for k, v in value.items() if k != 'revision'}


def save(path: Path, value) -> None:
    trusted_parent(path)
    temporary = path.with_name('.guard-' + uuid.uuid4().hex)
    try:
        fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, 'w') as stream:
            json.dump(value, stream, sort_keys=True)
            stream.flush(); os.fsync(stream.fileno())
        os.replace(temporary, path)
        fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    finally:
        temporary.unlink(missing_ok=True)


def record(base: Path, suffix: str):
    path = Path(str(base) + suffix)
    info = snapshot(path)
    if info is None or info['uid'] != 0 or info['mode'] & 0o077:
        raise ValueError('Missing or untrusted setup ownership receipt')
    return json.loads(path.read_text())


def prepare(base: Path, target: Path) -> None:
    before = snapshot(target)
    backup = snapshot(base)
    if equivalent(before) != equivalent(backup):
        raise ValueError('Setup file changed during backup')
    save(Path(str(base) + '.before.json'), before)
    save(Path(str(base) + '.backup.json'), backup)


def install(base: Path, target: Path, temporary: Path) -> None:
    before = record(base, '.before.json')
    expected = snapshot(temporary)
    if expected is None or temporary.parent != target.parent:
        raise ValueError('Invalid staged setup file')
    # Intent is durable before rename. Without the post receipt, rollback holds
    # unless the original exact object is still present (rename never happened).
    save(Path(str(base) + '.written'), {'intent': True})
    if snapshot(target) != before:
        raise ValueError('Setup file changed before replacement')
    os.replace(temporary, target)
    actual = snapshot(target)
    if (equivalent(actual) != equivalent(expected) or actual is None
            or actual['revision'][:3] != expected['revision'][:3]):
        raise ValueError('Setup file changed before post-state receipt')
    save(Path(str(base) + '.post.json'), actual)


def checked(base: Path, target: Path):
    before = record(base, '.before.json')
    current = snapshot(target)
    if current == before:
        return before, current, False  # No file write completed; no inverse needed.
    after = record(base, '.post.json')
    if current != after:
        raise ValueError('Setup ownership conflict; rollback held')
    if snapshot(base) != record(base, '.backup.json'):
        raise ValueError('Setup backup changed; rollback held')
    return before, current, True


def restore(base: Path, target: Path) -> None:
    before, current, needed = checked(base, target)
    if not needed:
        return
    if before is None:
        if snapshot(target) != current:
            raise ValueError('Setup file changed before rollback removal')
        target.unlink()
    else:
        temporary = target.with_name('.sentinel-restore-' + uuid.uuid4().hex)
        try:
            shutil.copy2(base, temporary, follow_symlinks=False)
            os.chown(temporary, before['uid'], before['gid'])
            os.chmod(temporary, before['mode'])
            if equivalent(snapshot(temporary)) != equivalent(before):
                raise ValueError('Setup restore metadata does not match backup')
            if snapshot(target) != current:
                raise ValueError('Setup file changed before rollback replacement')
            os.replace(temporary, target)
        finally:
            temporary.unlink(missing_ok=True)
    if equivalent(snapshot(target)) != equivalent(before):
        raise ValueError('Setup file changed during rollback')


def main() -> int:
    try:
        if os.geteuid() != 0 or len(sys.argv) not in {4, 5}:
            raise ValueError('Invalid setup guard invocation')
        operation, base, target = sys.argv[1:4]
        base, target = Path(base), Path(target)
        if operation == 'prepare' and len(sys.argv) == 4:
            prepare(base, target)
        elif operation == 'install' and len(sys.argv) == 5:
            install(base, target, Path(sys.argv[4]))
        elif operation == 'check' and len(sys.argv) == 4:
            checked(base, target)
        elif operation == 'restore' and len(sys.argv) == 4:
            restore(base, target)
        else:
            raise ValueError('Invalid setup guard operation')
        return 0
    except (OSError, ValueError, RuntimeError):
        # Do not echo paths, configuration content or exception output.
        print('Sentinel setup file ownership/backup check failed; rollback held for review.', file=sys.stderr)
        return 43


if __name__ == '__main__':
    raise SystemExit(main())
