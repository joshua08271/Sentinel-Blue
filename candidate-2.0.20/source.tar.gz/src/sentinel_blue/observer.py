"""Explicitly assigned external service observers. No enrollment or action channel."""
from __future__ import annotations
import hashlib
import ipaddress
import json
import math
import re
import ssl
import sys
import time
from pathlib import Path
from urllib.parse import urlsplit

from . import __version__
from .auth import ENROLLMENT_TOKEN, signature, verify, verify_response
from .json_codec import canonical_json_bytes, strict_json_loads
from .state import read_private_json, read_private_text

REPORT_PATH = '/api/v1/observer/report'
MAX_REPORT = 65536
IDENTIFIER = re.compile(r'^[A-Za-z0-9_.:@-]{1,128}$')
DIGEST = re.compile(r'^[0-9a-f]{64}$')


def identifier(value):
    if not isinstance(value,str) or not IDENTIFIER.fullmatch(value):
        raise ValueError('Invalid observer/check/service identifier')
    return value


def number(value, low, high):
    if type(value) not in (int,float) or not math.isfinite(value) or not low <= value <= high:
        raise ValueError('Observer number is outside its supported range')
    return value


def contract(entry):
    """The same public contract is pinned at both ends; secrets are separate."""
    result={'observer_id':identifier(entry['observer_id']), 'runtime_sha256':entry['runtime_sha256']}
    if not isinstance(result['runtime_sha256'],str) or not DIGEST.fullmatch(result['runtime_sha256']):
        raise ValueError('Observer runtime requires an exact SHA-256')
    for field in ('authorized_networks','authorized_hosts','excluded_hosts'):
        rows=entry.get(field,[])
        if not isinstance(rows,list) or len(rows)>128 or any(not isinstance(x,str) or len(x)>128 for x in rows):
            raise ValueError('Invalid explicit observer scope')
        result[field]=sorted(set(rows))
    if not result['authorized_hosts'] or not result['authorized_networks']:
        raise ValueError('Observer requires exact authorized hosts and networks')
    networks=[ipaddress.ip_network(x,strict=False) for x in result['authorized_networks']]
    # Exact numeric endpoints avoid an observer silently changing its DNS scope.
    for host in result['authorized_hosts']:
        address=ipaddress.ip_address(host)
        if host in result['excluded_hosts'] or not any(address in n for n in networks if n.version==address.version):
            raise ValueError('Observer host is outside its approved network')
    result['interval_seconds']=number(entry.get('interval_seconds',15),5,300)
    result['stale_after_seconds']=number(entry.get('stale_after_seconds',60),15,900)
    if result['stale_after_seconds']<2*result['interval_seconds']:
        raise ValueError('Observer stale deadline must allow at least two intervals')
    checks=entry.get('checks')
    if not isinstance(checks,list) or not 1<=len(checks)<=32:
        raise ValueError('Observer requires 1 to 32 explicit checks')
    result['checks']=[]; seen=set()
    for check in checks:
        if set(check)!={'check_id','agent_id','service_id','probe'}:
            raise ValueError('Observer check fields are invalid')
        row={k:identifier(check[k]) for k in ('check_id','agent_id','service_id')}
        if row['check_id'] in seen:raise ValueError('Duplicate observer check')
        seen.add(row['check_id'])
        probe=check['probe']
        if not isinstance(probe,dict) or probe.get('kind') not in {'http','https','tcp','dns','tls'}:
            raise ValueError('Observer supports read-only HTTP, HTTPS, TCP, DNS and TLS checks')
        if any(k in probe for k in ('password','username','send','command','headers')):
            raise ValueError('Observer checks do not carry credentials or arbitrary requests')
        if probe.get('method','GET') not in {'GET','HEAD'} or probe.get('verify',True) is not True:
            raise ValueError('Observer requires safe methods and verified TLS')
        target=probe.get('target')
        if not isinstance(target,str) or not 1<=len(target)<=2048:raise ValueError('Invalid probe target')
        host=(urlsplit(target).hostname if probe['kind'] in {'http','https'} else probe.get('host',target))
        if host not in result['authorized_hosts'] or host in result['excluded_hosts']:
            raise ValueError('Observer target must be an exact approved address')
        if probe['kind'] in {'http','https'}:
            url=urlsplit(target)
            if url.username or url.password or url.query or url.fragment:
                raise ValueError('Observer URLs cannot contain credentials, queries or fragments')
            if url.scheme not in {'http','https'}:raise ValueError('Invalid HTTP probe URL')
            if 'expected_status' not in probe:raise ValueError('HTTP observer checks require explicit expected status')
        if 'timeout' in probe:number(probe['timeout'],.2,15)
        row['probe']=json.loads(canonical_json_bytes(probe,max_bytes=8192))
        result['checks'].append(row)
    canonical_json_bytes(result,max_bytes=MAX_REPORT)
    return result


def contract_digest(value):
    return hashlib.sha256(canonical_json_bytes(value,max_bytes=MAX_REPORT)).hexdigest()


def read_key(path):
    token=read_private_text(path,4096).strip()
    if not ENROLLMENT_TOKEN.fullmatch(token):raise ValueError('Observer key must be 32–256 URL-safe characters')
    return token


class ObserverRegistry:
    """Bounded persistent evidence; never inserted as authoritative host telemetry."""
    def __init__(self,store,entries,*,services,forbidden_tokens=(),authorized_hosts=(),excluded_hosts=()):
        if not isinstance(entries,list) or len(entries)>64:raise ValueError('At most 64 observers are supported')
        self.store=store;self.entries={}
        from .auth import PrincipalRateLimiter
        self.rate=PrincipalRateLimiter(.5,4,64)
        service_ids={(s['host'],s['service_id']) for s in services}
        tokens=set(forbidden_tokens)
        for entry in entries:
            value=contract(entry);identity=value['observer_id'];token=read_key(entry['key_file'])
            if identity in self.entries or token in tokens:raise ValueError('Observer identities and keys must be distinct')
            if not set(value['authorized_hosts'])<=set(authorized_hosts) or set(value['authorized_hosts'])&set(excluded_hosts):
                raise ValueError('Observer targets must belong to the reviewed event scope')
            if any((c['agent_id'],c['service_id']) not in service_ids for c in value['checks']):
                raise ValueError('Observer check refers to an undeclared service')
            tokens.add(token)
            self.entries[identity]={'contract':value,'digest':contract_digest(value),'token':token,
                'key_digest':hashlib.sha256(token.encode()).hexdigest()}
        with store._lock:
            rows=store._connection.execute("SELECT state_key,state_value FROM controller_state WHERE state_key LIKE 'observer-report:%' LIMIT 65").fetchall()
            if len(rows)>64:raise ValueError('Observer state exceeds its configured capacity')
            for row in rows:
                identity=row['state_key'].removeprefix('observer-report:')
                current=self.entries.get(identity)
                saved=strict_json_loads(row['state_value'],max_bytes=MAX_REPORT)
                if not isinstance(saved,dict):raise ValueError('Observer state requires review')
                if current is None or current['digest']!=saved.get('configuration_sha256') or current['key_digest']!=saved.get('key_digest'):
                    store._connection.execute('DELETE FROM controller_state WHERE state_key=?',(row['state_key'],))
            store._connection.commit()

    def accept(self,body,headers,*,now=None):
        now=time.time() if now is None else now
        def header(name):
            values=headers.get_all(name) if hasattr(headers,'get_all') else [headers.get(name)]
            if len(values or [])!=1 or not isinstance(values[0],str) or len(values[0])>256:return None
            return values[0]
        identity=header('X-SB-Observer');entry=self.entries.get(identity)
        stamp=header('X-SB-Timestamp');supplied=header('X-SB-Signature')
        if supplied is not None and not DIGEST.fullmatch(supplied):supplied=None
        if entry is None or not stamp or not supplied or len(body)>MAX_REPORT or not verify(entry['token'],stamp,'POST',REPORT_PATH,body,supplied,now=now):
            raise PermissionError('Observer authentication failed')
        if not self.rate.consume(identity)[0]:raise PermissionError('Observer report rate exceeded')
        payload=strict_json_loads(body,max_bytes=MAX_REPORT)
        expected={'observer_id','configuration_sha256','runtime_sha256','observed_at','sequence','probes'}
        if not isinstance(payload,dict) or set(payload)!=expected:raise ValueError('Invalid observer report fields')
        if payload['observer_id']!=identity or payload['configuration_sha256']!=entry['digest'] or payload['runtime_sha256']!=entry['contract']['runtime_sha256']:
            raise PermissionError('Observer report binding differs')
        sequence=payload['sequence']
        if type(sequence) is not int or not 1<=sequence<=2**63-1:raise ValueError('Invalid observer sequence')
        observed=number(payload['observed_at'],now-300,now+5)
        results=payload['probes'];expected_ids={c['check_id'] for c in entry['contract']['checks']}
        if not isinstance(results,list) or len(results)!=len(expected_ids):raise ValueError('Observer check set is incomplete')
        actual=[]
        for result in results:
            if not isinstance(result,dict) or set(result)!={'check_id','healthy','latency_ms','reason_code'}:raise ValueError('Invalid observer result')
            actual.append(identifier(result['check_id']))
            if type(result['healthy']) is not bool:raise ValueError('Invalid observer health')
            number(result['latency_ms'],0,60000)
            if result['reason_code'] not in {'probe_passed','probe_failed'}:raise ValueError('Invalid observer reason')
        if len(set(actual))!=len(actual) or set(actual)!=expected_ids:raise ValueError('Observer check identities differ')
        with self.store._lock:
            db=self.store._connection
            try:
                db.execute('BEGIN IMMEDIATE')
                stored=db.execute('SELECT state_value FROM controller_state WHERE state_key=?',('observer-report:'+identity,)).fetchone()
                old=strict_json_loads(stored['state_value'],max_bytes=MAX_REPORT) if stored else None
                if old and (sequence<=old['sequence'] or observed<old['observed_at']):raise PermissionError('Observer report is replayed or reordered')
                missing=max(0,sequence-old['sequence']-1) if old else 0
                saved={'configuration_sha256':entry['digest'],'key_digest':entry['key_digest'],
                    'sequence':sequence,'observed_at':observed,'received_at':now,'payload':payload}
                db.execute('INSERT INTO controller_state(state_key,state_value,updated_at) VALUES(?,?,?) ON CONFLICT(state_key) DO UPDATE SET state_value=excluded.state_value,updated_at=excluded.updated_at',
                    ('observer-report:'+identity,canonical_json_bytes(saved,max_bytes=MAX_REPORT).decode(),now))
                db.commit()
            except Exception:
                db.rollback();raise
        from .recording import emit
        emit('external_observer_report',dict(payload,received_at=now,missing_sequences=missing,sequence_origin_unknown=old is None,
             fresh=0<=now-observed<=entry['contract']['stale_after_seconds']))
        return entry['token'],supplied,{'accepted':True,'sequence':sequence,'missing_sequences':missing}

    def status(self,*,now=None):
        now=time.time() if now is None else now
        with self.store._lock:
            saved={}
            for identity in self.entries:
                row=self.store._connection.execute('SELECT state_value FROM controller_state WHERE state_key=?',('observer-report:'+identity,)).fetchone()
                if row:
                    value=strict_json_loads(row['state_value'],max_bytes=MAX_REPORT)
                    if not isinstance(value,dict):raise ValueError('Observer state requires review')
                    saved[identity]=value
        rows=[]
        for identity,entry in self.entries.items():
            stored=saved.get(identity);payload=None
            try:
                if stored:payload=stored['payload']
            except (ValueError,TypeError):pass
            age=now-payload['observed_at'] if payload else None
            fresh=age is not None and 0<=age<=entry['contract']['stale_after_seconds']
            results={x['check_id']:x for x in payload['probes']} if payload else {}
            for check in entry['contract']['checks']:
                result=results.get(check['check_id'])
                health=('healthy' if result['healthy'] else 'unhealthy') if fresh and result else ('stale' if payload else 'unknown')
                rows.append({'observer_id':identity,'check_id':check['check_id'],'agent_id':check['agent_id'],
                    'service_id':check['service_id'],'health':health,'observed_at':payload['observed_at'] if payload else None,
                    'age_seconds':round(age,1) if age is not None else None,'latency_ms':result['latency_ms'] if fresh and result else None})
        return rows


def attach_service_health(service_rows,observer_rows):
    for row in service_rows:
        checks=[x for x in observer_rows if (x['agent_id'],x['service_id'])==(row['agent_id'],row['service'])]
        states={x['health'] for x in checks}
        row['external_health']=('unconfigured' if not states else 'unhealthy' if 'unhealthy' in states else
            'unknown' if 'unknown' in states else 'stale' if 'stale' in states else 'healthy')
        row['external_checks']=checks
        row['local_external_disagreement']=row['health']=='healthy' and row['external_health']=='unhealthy'


def send_report(config,token,payload):
    from .probes import _PinnedHTTPConnection,_PinnedHTTPSConnection
    from .request_deadline import BoundedRequestPool
    origin=urlsplit(config['controller']);address=ipaddress.ip_address(origin.hostname)
    if origin.scheme not in {'http','https'} or origin.username or origin.password or origin.path not in {'','/'} or origin.query or origin.fragment:
        raise ValueError('Observer controller must be an HTTP(S) IP origin')
    if origin.scheme=='http' and not address.is_loopback:raise ValueError('Remote observer requires HTTPS')
    context=ssl.create_default_context(cafile=config.get('ca_file')) if origin.scheme=='https' else None
    body=canonical_json_bytes(payload,max_bytes=MAX_REPORT);stamp=str(time.time())
    signed=signature(token,stamp,'POST',REPORT_PATH,body)
    headers={'Content-Type':'application/json','X-SB-Observer':payload['observer_id'],'X-SB-Timestamp':stamp,'X-SB-Signature':signed}
    def call(budget):
        args=(str(address),str(address),origin.port or (443 if context else 80),budget.remaining())
        connection=_PinnedHTTPSConnection(*args,context) if context else _PinnedHTTPConnection(*args)
        connection._budget=budget
        try:
            connection.request('POST',REPORT_PATH,body,headers)
            response=connection.getresponse();raw=response.read(MAX_REPORT+1)
            if len(raw)>MAX_REPORT or not verify_response(token,response.getheader('X-SB-Response-Timestamp',''),response.status,REPORT_PATH,signed,raw,response.getheader('X-SB-Response-Signature','')):
                raise PermissionError('Observer acknowledgement was not authenticated')
            if response.status!=202:raise RuntimeError('Controller rejected observer report')
            result=strict_json_loads(raw,max_bytes=MAX_REPORT)
            if result.get('accepted') is not True or result.get('sequence')!=payload['sequence']:raise ValueError('Observer acknowledgement differs')
            return result
        finally:connection.close()
    return _REQUESTS.run(call,10)


from .request_deadline import BoundedRequestPool
_REQUESTS=BoundedRequestPool(1,label='observer report',thread_name='sentinel-observer-network')


def add_cli(subcommands):
    cmd=subcommands.add_parser('observer',help='run only approved external service checks; no host agent or repair controls')
    cmd.add_argument('--config',required=True,help='private reviewed observer configuration')
    cmd.add_argument('--once',action='store_true')


def run(args):
    from http.client import HTTPException
    from .credential_vault import private_directory
    from .state import SequenceCounter,AgentProcessLock
    from .recording import Recorder
    from .probes import run_probes
    config=read_private_json(args.config,MAX_REPORT);value=contract(config);token=read_key(config['key_file'])
    runtime=Path(sys.argv[0]).resolve(strict=True)
    if hashlib.sha256(runtime.read_bytes()).hexdigest()!=value['runtime_sha256']:raise ValueError('Observer package differs from approved runtime')
    directory=Path(config['state_directory']).absolute();guard=private_directory(directory)
    lock=AgentProcessLock(directory);lock.acquire()
    counter=SequenceCounter(directory)
    recorder=Recorder(directory/'recordings',role='external-observer')
    try:
        while True:
            results=run_probes([c['probe'] for c in value['checks']],value['authorized_networks'],authorized_hosts=value['authorized_hosts'],excluded_hosts=value['excluded_hosts'])
            payload={'observer_id':value['observer_id'],'configuration_sha256':contract_digest(value),
                'runtime_sha256':value['runtime_sha256'],'observed_at':time.time(),'sequence':counter.next(),
                'probes':[{'check_id':c['check_id'],'healthy':p.healthy,'latency_ms':p.latency_ms,
                    'reason_code':'probe_passed' if p.healthy else 'probe_failed'} for c,p in zip(value['checks'],results)]}
            recorder.emit('external_observer_sample',payload)
            try:
                result=send_report(config,token,payload)
                recorder.emit('observer_delivery_acknowledged',result)
                print(json.dumps({'observer_id':value['observer_id'],'delivered':True,'sequence':payload['sequence']}),flush=True)
            except (OSError,ValueError,RuntimeError,PermissionError,HTTPException) as exc:
                recorder.emit('observer_delivery_failed',{'observer_id':value['observer_id'],'sequence':payload['sequence'],'error_type':type(exc).__name__})
                print(json.dumps({'observer_id':value['observer_id'],'delivered':False,'sequence':payload['sequence'],'error_type':type(exc).__name__}),flush=True)
            if args.once:return
            time.sleep(value['interval_seconds'])
    finally:
        recorder.close();lock.close()
        if guard:guard.close()
