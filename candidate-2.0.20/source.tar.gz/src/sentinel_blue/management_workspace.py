"""Prepare a separate Linux control plane; never migrate or deploy implicitly.

Only per-host enrollment material is exportable. Controller credentials, signing
keys, database and authenticated backups remain on the management host. Local
agent restore blobs/journals are NOT remotely replicated by this feature.
"""
from __future__ import annotations

import copy
import datetime
import hashlib
import io
import ipaddress
import json
import os
from pathlib import Path
import secrets
import stat
import shutil
from types import SimpleNamespace
import uuid
import zipfile

from . import __version__
from .control_plane import MODE, address, validate_inventory, validate_startup
from .credential_vault import private_directory
from .event_profile import EventProfile, load_event_profile
from .json_codec import canonical_json_bytes, strict_json_loads
from .state import _atomic_bytes, read_private_bytes, read_private_json, write_private_json

JOIN_FILES = frozenset({'join.json', 'event-profile.json', 'controller-ca.crt', 'enrollment.json', 'probes.json'})
MAX_JOIN_BYTES = 8 * 1024 * 1024


def _private(path):
    guard = private_directory(Path(path))
    if guard:
        guard.close()


def _digest(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def _certificate(directory, ip):
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import NameOID
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, 'Sentinel Blue dedicated management')])
    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key())
            .serial_number(x509.random_serial_number()).not_valid_before(now - datetime.timedelta(minutes=5))
            .not_valid_after(now + datetime.timedelta(days=365))
            .add_extension(x509.SubjectAlternativeName([x509.IPAddress(ipaddress.ip_address(ip))]), False)
            .sign(key, hashes.SHA256()))
    _atomic_bytes(directory/'controller.key', key.private_bytes(serialization.Encoding.PEM,
                  serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
    _atomic_bytes(directory/'controller.crt', cert.public_bytes(serialization.Encoding.PEM))


def prepare(parent, runtime, inventory, profile, controller_address, port=8765,
            operator_addresses=(), *, confirmed=False, authorization_reference=''):
    """Create an unapproved candidate only. Inputs must already authorize hosts.

    Requires a network inventory/profile prepared by the normal Setup workflow.
    No automatic network-scope expansion, guest inspection, service installation,
    port opening, baseline promotion, or organizer approval occurs here.
    """
    if os.name != 'posix':
        raise ValueError('Dedicated workspace preparation is currently Linux-only')
    from .linux_workspace import is_proxmox_host
    if is_proxmox_host():
        raise ValueError('Use an authorized management guest, not the Proxmox hypervisor')
    runtime = Path(runtime).absolute()
    if runtime.is_symlink() or not runtime.is_file() or not zipfile.is_zipfile(runtime):
        raise ValueError('Select the complete release’s actual application .pyz')
    if not isinstance(inventory, dict) or not isinstance(inventory.get('hosts'), list):
        raise ValueError('Select a network inventory with explicit hosts')
    source = profile if isinstance(profile, EventProfile) else EventProfile.from_dict(profile)
    raw = copy.deepcopy(source.raw)
    caddr = address(controller_address)
    operators = list(dict.fromkeys([caddr, *operator_addresses]))
    hosts = inventory['hosts']
    mapping = {}
    for row in hosts:
        if not isinstance(row, dict) or row.get('platform') != 'linux':
            raise ValueError('This GUI join workflow currently accepts Linux agents only; Windows work is unchanged')
        aid = row.get('agent_id')
        if not isinstance(aid, str) or aid in mapping:
            raise ValueError('Network inventory requires unique explicit agent_id values')
        mapping[aid] = address(row.get('address'))
    raw['control_plane'] = {'mode': MODE, 'controller_address': caddr, 'controller_port': port,
        'operator_ingress_hosts': operators, 'agent_addresses': mapping,
        'separate_host_confirmed': confirmed, 'authorization_reference': authorization_reference}
    # Narrow the ingress inventory, without enlarging target scope or permissions.
    raw['scope']['controller_ingress_hosts'] = sorted(set(operators) | set(mapping.values()))
    raw['approval'] = {'status': 'pending', 'approved_by': ''}
    raw['release'] = {'version': __version__, 'sha256': _digest(runtime), 'approved': False,
                      'cloud_processing': False, 'external_telemetry_export': False}
    candidate = EventProfile.from_dict(raw)
    validate_inventory(inventory, candidate, complete=True)
    candidate.assert_inventory_networks(inventory.get('authorized_networks', []))
    validate_startup(candidate, 'controller', SimpleNamespace(bind=caddr, port=port, syslog_bind=None))
    _private(parent)
    directory = Path(parent).absolute()/('management-' + uuid.uuid4().hex)
    _private(directory)
    try:
        _certificate(directory, caddr)
        raw['release']['controller_ca_sha256'] = _digest(directory/'controller.crt')
        candidate = EventProfile.from_dict(raw)
        write_private_json(directory/'candidate-profile.json', candidate.raw)
        write_private_json(directory/'inventory.json', inventory)
        config = {'schema': 1, 'role': 'controller', 'directory': str(directory),
                  'runtime': str(runtime), 'runtime_sha256': _digest(runtime),
                  'candidate_fingerprint': candidate.fingerprint,
                  'range_deployment': source.environment == 'range-autonomous', 'finalized': False}
        write_private_json(directory/'role.json', config)
        return config
    except Exception:
        # Only this never-started, newly created random directory is removed.
        shutil.rmtree(directory)
        raise


def _approval_independent(raw):
    result = copy.deepcopy(raw)
    result.pop('approval', None)
    # These are existing engine approval facts, not topology or capability edits.
    for key in ('approved', 'public_url', 'frozen', 'submitted_to_officials', 'submission_approved',
                'public_and_equal_access', 'public_days_before_event', 'submitted_days_before_event'):
        result.get('release', {}).pop(key, None)
    return result


def finalize(config_path, *, approved_profile=None, range_operator=None):
    # Serialize credential issuance with other issuers and the running role.
    # A second GUI must never overwrite a first GUI's already-issued master.
    from .state import AgentProcessLock
    path = Path(config_path).absolute()
    read_private_json(path, 65536)  # Validate the private existing path first.
    _private(path.parent)
    lock = AgentProcessLock(path.parent).acquire()
    try:
        return _finalize_locked(path, approved_profile=approved_profile, range_operator=range_operator)
    finally:
        lock.close()


def _finalize_locked(config_path, *, approved_profile=None, range_operator=None):
    """Accept fresh approval of the exact candidate, then create per-agent exports.

    A live candidate must be approved outside this helper and pass the existing
    live-readiness checks. An explicit local range approval can never authorize a
    live event. This does not start any process.
    """
    path = Path(config_path).absolute()
    config = read_private_json(path, 65536)
    directory = path.parent
    if config.get('role') != 'controller' or config.get('directory') != str(directory):
        raise ValueError('Select the management role.json from this workspace')
    _private(directory)
    if config.get('finalized') or (directory/'master.json').exists():
        raise ValueError('This workspace was finalized or partially finalized; do not regenerate its identities')
    candidate = load_event_profile(directory/'candidate-profile.json')
    if candidate.fingerprint != config.get('candidate_fingerprint'):
        raise ValueError('Candidate changed after review; prepare a new workspace')
    raw = copy.deepcopy(candidate.raw)
    if approved_profile is not None:
        approved = load_event_profile(approved_profile)
        if _approval_independent(approved.raw) != _approval_independent(candidate.raw):
            raise ValueError('Approved profile changed the reviewed candidate; prepare and review again')
        raw = approved.raw
    elif config.get('range_deployment') is True and isinstance(range_operator, str) and 1 <= len(range_operator.strip()) <= 128:
        raw['approval'] = {'status': 'range-only', 'approved_by': range_operator.strip()}
    else:
        raise ValueError('Load explicit approval of the new live profile; range approval cannot authorize a competition')
    profile = EventProfile.from_dict(raw)
    profile.require_runtime_ready(range_deployment=config['range_deployment'])
    profile.verify_release_file(config['runtime'])
    profile.verify_controller_ca_file(directory/'controller.crt')
    c = profile.raw['control_plane']
    validate_startup(profile, 'controller', SimpleNamespace(bind=c['controller_address'], port=c['controller_port'], syslog_bind=None))
    inventory = read_private_json(directory/'inventory.json', 2 * 1024 * 1024)
    validate_inventory(inventory, profile, complete=True)
    # All admission checks precede production-secret generation.
    master, operator = secrets.token_urlsafe(48), secrets.token_urlsafe(48)
    recovery = secrets.token_bytes(48)
    write_private_json(directory/'profile.json', raw)
    write_private_json(directory/'master.json', {'token': master})
    _atomic_bytes(directory/'operator.txt', operator.encode())
    _atomic_bytes(directory/'recovery.key', recovery)
    from .recovery_ops import initialize_controller_recovery
    initialize_controller_recovery(directory/'controller.db', directory/'recovery.anchor', recovery)
    _private(directory/'backups')
    _private(directory/'agent-exports')
    config.update(finalized=True, profile_fingerprint=profile.fingerprint)
    # No source paths from inventory (SSH private keys, management vault, etc.)
    # are copied into an export. The public event profile itself is shared so
    # all agents remain bound to the SAME approved fingerprint.
    from .auth import derive_enrollment_ticket
    ca = read_private_bytes(directory/'controller.crt', 65536)
    exports = []
    for aid, ip in sorted(c['agent_addresses'].items()):
        services = [row for row in profile.services if row['host'] == aid]
        probes = {'probes': [p for row in services for p in row['expected_transactions']],
                  'protected_paths': sorted({p for row in services for p in row.get('required_files', [])})}
        join = {'schema': 1, 'role': 'agent', 'agent_id': aid, 'address': ip,
                'profile_fingerprint': profile.fingerprint, 'runtime_sha256': config['runtime_sha256'],
                'range_deployment': config['range_deployment']}
        contents = {'join.json': canonical_json_bytes(join),
                    'event-profile.json': canonical_json_bytes(raw), 'controller-ca.crt': ca,
                    'enrollment.json': canonical_json_bytes({'token': derive_enrollment_ticket(master, profile.fingerprint, aid)}),
                    'probes.json': canonical_json_bytes(probes)}
        stream = io.BytesIO()
        with zipfile.ZipFile(stream, 'w', compression=zipfile.ZIP_DEFLATED) as z:
            for name in sorted(JOIN_FILES):
                info = zipfile.ZipInfo(name); info.create_system = 3; info.external_attr = 0o100600 << 16
                z.writestr(info, contents[name], compress_type=zipfile.ZIP_DEFLATED)
        dest = directory/'agent-exports'/f'{aid}.sentinel-agent.zip'
        _atomic_bytes(dest, stream.getvalue())
        exports.append(str(dest))
    config['exports'] = exports
    _atomic_bytes(directory/'EXPORTS-SHA256.txt', ''.join(_digest(x) + '  ' + Path(x).name + '\n' for x in exports).encode())
    write_private_json(path, config)
    return config


def _join_bytes(package):
    """Read one bounded regular-file snapshot, never a link/device/FIFO.

    The same returned bytes are hashed and parsed. Path replacement between
    verification and import therefore cannot substitute different trust data.
    """
    fd = os.open(package, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_NONBLOCK', 0))
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_size > MAX_JOIN_BYTES:
            raise ValueError('Join package must be a bounded regular file')
        chunks, size = [], 0
        while size <= MAX_JOIN_BYTES:
            data = os.read(fd, min(65536, MAX_JOIN_BYTES + 1 - size))
            if not data:
                break
            chunks.append(data); size += len(data)
        after = os.fstat(fd)
        identity = lambda v: (v.st_dev, v.st_ino, v.st_size, v.st_mtime_ns, v.st_ctime_ns)
        if size > MAX_JOIN_BYTES or size != before.st_size or identity(before) != identity(after):
            raise ValueError('Join package changed during verification or exceeds its bound')
        return b''.join(chunks)
    finally:
        os.close(fd)


def read_join(package):
    """Strict allowlisted read; ZIP content is never blindly extracted."""
    return _decode_join(_join_bytes(package))


def _decode_join(raw):
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        entries = z.infolist()
        if len(entries) != len(JOIN_FILES) or {i.filename for i in entries} != JOIN_FILES:
            raise ValueError('Join package contains missing, duplicate, or forbidden files')
        if sum(i.file_size for i in entries) > MAX_JOIN_BYTES:
            raise ValueError('Expanded join package is oversized')
        if any(i.is_dir() or ((i.external_attr >> 16) & 0o170000) not in (0, 0o100000) for i in entries):
            raise ValueError('Join package contains non-regular entries')
        data = {i.filename: z.read(i) for i in entries}
    meta = strict_json_loads(data['join.json'], max_bytes=65536)
    if not isinstance(meta, dict) or set(meta) != {'schema','role','agent_id','address','profile_fingerprint','runtime_sha256','range_deployment'}:
        raise ValueError('Invalid join metadata')
    if meta['schema'] != 1 or meta['role'] != 'agent' or type(meta['range_deployment']) is not bool:
        raise ValueError('This is not an isolated agent package')
    profile = EventProfile.from_dict(strict_json_loads(data['event-profile.json'], max_bytes=2 * 1024 * 1024))
    profile.require_runtime_ready(range_deployment=meta['range_deployment'])
    c = profile.raw.get('control_plane')
    if (not c or profile.fingerprint != meta['profile_fingerprint'] or
            c['agent_addresses'].get(meta['agent_id']) != meta['address'] or
            profile.release['sha256'] != meta['runtime_sha256'] or
            hashlib.sha256(data['controller-ca.crt']).hexdigest() != profile.controller_ca_sha256):
        raise ValueError('Join identity, profile, runtime, or certificate binding mismatch')
    token = strict_json_loads(data['enrollment.json'], max_bytes=4096)
    import re
    if not isinstance(token, dict) or set(token) != {'token'} or not isinstance(token['token'], str) or not re.fullmatch(r'[A-Za-z0-9_-]{32,256}', token['token']):
        raise ValueError('Join package has invalid enrollment material')
    # Reconstruct rather than trusting arbitrary extra probe/protected paths.
    services = [row for row in profile.services if row['host'] == meta['agent_id']]
    expected = {'probes': [p for row in services for p in row['expected_transactions']],
                'protected_paths': sorted({p for row in services for p in row.get('required_files', [])})}
    if strict_json_loads(data['probes.json'], max_bytes=2 * 1024 * 1024) != expected:
        raise ValueError('Join probes do not match this agent’s approved manifests')
    return meta, profile, data


def origin(c):
    ip = c['controller_address']
    return f"https://{'[' + ip + ']' if ':' in ip else ip}:{c['controller_port']}"


def import_agent(parent, runtime, package, *, expected_sha256):
    from .linux_workspace import is_proxmox_host
    if is_proxmox_host():
        raise ValueError('Join only inside an authorized Linux guest, never the hypervisor')
    import re
    raw = _join_bytes(package)
    if not isinstance(expected_sha256, str) or not re.fullmatch(r'[0-9a-fA-F]{64}', expected_sha256) or hashlib.sha256(raw).hexdigest() != expected_sha256.lower():
        raise ValueError('Join checksum must match the value obtained independently from the management host')
    meta, profile, data = _decode_join(raw)
    runtime = str(Path(runtime).absolute())
    profile.verify_release_file(runtime)
    c = profile.raw['control_plane']
    validate_startup(profile, 'agent', SimpleNamespace(agent_id=meta['agent_id'], controller=origin(c)))
    _private(parent)
    directory = Path(parent).absolute()/('agent-' + meta['agent_id'] + '-' + uuid.uuid4().hex)
    _private(directory)
    try:
        for name in sorted(JOIN_FILES):
            _atomic_bytes(directory/name, data[name])
        _private(directory/'agent-state')
        config = {'schema': 1, 'role': 'agent', 'directory': str(directory), 'agent_id': meta['agent_id'],
                  'runtime': runtime, 'runtime_sha256': meta['runtime_sha256'],
                  'profile_fingerprint': profile.fingerprint, 'range_deployment': meta['range_deployment'], 'finalized': True}
        write_private_json(directory/'role.json', config)
        return config
    except Exception:
        shutil.rmtree(directory)
        raise


def role_arguments(config_path):
    path = Path(config_path).absolute(); d = path.parent
    config = read_private_json(path, 65536)
    if (config.get('schema') != 1 or config.get('directory') != str(d) or not config.get('finalized')
            or config.get('role') not in {'controller', 'agent'} or type(config.get('range_deployment')) is not bool):
        raise ValueError('Select an approved isolated role.json')
    _private(d)
    role = config['role']
    profile_path = d/('profile.json' if role == 'controller' else 'event-profile.json')
    profile = load_event_profile(profile_path)
    if profile.fingerprint != config.get('profile_fingerprint') or not profile.raw.get('control_plane'):
        raise ValueError('Role profile changed; no implicit reapproval or migration is allowed')
    profile.require_runtime_ready(range_deployment=config['range_deployment'])
    profile.verify_release_file(config['runtime'])
    c = profile.raw['control_plane']
    common = ['--event-profile', str(profile_path)]
    if config['range_deployment']:
        common.append('--range-deployment')
    if role == 'controller':
        arguments = ['controller', '--bind', c['controller_address'], '--port', str(c['controller_port']), '--supervise',
            '--token-file', str(d/'master.json'), '--operator-token-file', str(d/'operator.txt'),
            '--operator-principal-id', 'management-operator', '--database', str(d/'controller.db'),
            '--recovery-anchor', str(d/'recovery.anchor'), '--recovery-key-file', str(d/'recovery.key'),
            '--tls-cert', str(d/'controller.crt'), '--tls-ca-file', str(d/'controller.crt'), '--tls-key', str(d/'controller.key'),
            '--backup-directory', str(d/'backups'), '--backup-interval', '300', '--maintenance-interval', '5',
            '--max-agents', str(len(c['agent_addresses'])), *common]
        if profile.autonomy_mode in {'guarded-autonomous', 'range-autonomous'}:
            arguments.append('--auto-recover-services')
    else:
        arguments = ['agent', '--controller', origin(c), '--agent-id', config['agent_id'],
            '--token-file', str(d/'enrollment.json'), '--state-dir', str(d/'agent-state'),
            '--ca-file', str(d/'controller-ca.crt'), '--probe-config', str(d/'probes.json'),
            '--expected-package-sha256', config['runtime_sha256'], '--interval', '10', *common]
        if profile.allows('in_place_repair'):
            arguments.append('--allow-service-recovery')
        if profile.allows('file_restoration'):
            arguments.append('--allow-restoration')
    from .__main__ import parser
    args = parser().parse_args(arguments)
    validate_startup(profile, role, args)
    from .config_validation import validate_bound_transport
    if role == 'controller':
        validate_bound_transport(profile, role=role, ca_file=args.tls_ca_file, tls_cert=args.tls_cert, tls_key=args.tls_key)
    else:
        validate_bound_transport(profile, role=role, controller=args.controller, ca_file=args.ca_file)
    return config, arguments


def connection(config_path):
    config, _ = role_arguments(config_path)
    if config['role'] != 'controller':
        raise ValueError('Agent-only workspace has no operator credentials')
    d = Path(config['directory']); profile = load_event_profile(d/'profile.json')
    return {'origin': origin(profile.raw['control_plane']), 'principal': 'management-operator', 'epoch': 2,
            'ca_file': str(d/'controller.crt'), 'operator_file': str(d/'operator.txt'),
            'event_profile': str(d/'profile.json'), 'inventory': str(d/'inventory.json'), 'runtime': config['runtime'],
            'range_deployment': config['range_deployment']}
