"""Identical bounded retry policy for controller history and native journals."""
from __future__ import annotations
import math

DEFAULT_LIMITS = {"cooldown_seconds": 300, "maximum_attempts": 3}
WINDOW_SECONDS = 3600
FAILURE_COOLDOWN_SECONDS = 300
MAXIMUM_FAILURES = 3
MAX_SUCCESS_ATTEMPTS = 120


def normalize_attempt_limits(value=None):
    if value is None:
        return dict(DEFAULT_LIMITS)
    if not isinstance(value, dict) or set(value) != set(DEFAULT_LIMITS):
        raise ValueError('attempt_limits require cooldown_seconds and maximum_attempts')
    cooldown, maximum = value['cooldown_seconds'], value['maximum_attempts']
    if type(cooldown) is not int or not 15 <= cooldown <= 300:
        raise ValueError('recovery cooldown must be from 15 to 300 seconds')
    if type(maximum) is not int or not 1 <= maximum <= MAX_SUCCESS_ATTEMPTS:
        raise ValueError('recovery maximum_attempts must be from 1 to 120 per hour (explicit approved service policy required)')
    return dict(value)


def evaluate_attempts(events, now, limits=None):
    """Events are (timestamp, verified_success); unknown outcomes are held upstream.

    A signed service policy may permit more successful restorations. Failed
    attempts retain the original five-minute cooldown and three-per-hour cap.
    Neither process restarts nor a later success clear preceding failures.
    """
    if type(now) not in (int, float) or not math.isfinite(now):
        raise ValueError('invalid recovery clock')
    limits = normalize_attempt_limits(limits)
    attempts, failures = [], []
    for created, success in events:
        if type(created) not in (int, float) or not math.isfinite(created) or type(success) is not bool:
            raise ValueError('invalid durable recovery attempt')
        if now - created < WINDOW_SECONDS:
            attempts.append(created)
            if not success:
                failures.append(created)
    reason, retry_at = None, None
    if len(attempts) >= limits['maximum_attempts']:
        reason = 'service_recovery_hourly_budget_exhausted'
        retry_at = sorted(attempts)[-limits['maximum_attempts']] + WINDOW_SECONDS
    if len(failures) >= MAXIMUM_FAILURES:
        reason = 'service_recovery_failed_attempt_hourly_budget_exhausted'
        retry_at = max(retry_at or 0, sorted(failures)[-MAXIMUM_FAILURES] + WINDOW_SECONDS)
    if attempts:
        next_cooldown = max(attempts) + limits['cooldown_seconds']
        if failures:
            next_cooldown = max(next_cooldown, max(failures) + FAILURE_COOLDOWN_SECONDS)
        if now < next_cooldown:
            reason = reason or 'service_recovery_cooldown'
            retry_at = max(retry_at or 0, next_cooldown)
    return {
        'allowed': reason is None, 'reason': reason, 'retry_at': retry_at,
        'attempts_in_window': len(attempts), 'failed_attempts_in_window': len(failures),
        'maximum_attempts': limits['maximum_attempts'], 'maximum_failed_attempts': MAXIMUM_FAILURES,
        'window_seconds': WINDOW_SECONDS, 'cooldown_seconds': limits['cooldown_seconds'],
        'failure_cooldown_seconds': FAILURE_COOLDOWN_SECONDS,
    }
