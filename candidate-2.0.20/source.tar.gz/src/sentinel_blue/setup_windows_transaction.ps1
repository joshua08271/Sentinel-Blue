# Durable rollback of explicitly owned Windows service, firewall and IIS changes.
$ErrorActionPreference = 'Stop'

function Get-SBJson($value) { return ConvertTo-Json -InputObject $value -Depth 24 -Compress }
function Test-SBEqual($left, $right) { return (Get-SBJson $left) -ceq (Get-SBJson $right) }
function Get-SBHash([string]$value) {
    $algorithm = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($algorithm.ComputeHash([Text.Encoding]::UTF8.GetBytes($value)))).Replace('-','').ToLowerInvariant() }
    finally { $algorithm.Dispose() }
}
function Test-SBAncestors([string]$path) {
    $current = [IO.Path]::GetFullPath($path)
    while ($current) {
        if (Test-Path -LiteralPath $current) {
            $item = Get-Item -LiteralPath $current -Force
            if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Reparse points require review before owned rollback' }
        }
        $next = [IO.Path]::GetDirectoryName($current)
        if ($next -eq $current) { break }; $current = $next
    }
}
function Set-SBPrivateAcl([string]$path, [bool]$directory) {
    $acl = if ($directory) { [Security.AccessControl.DirectorySecurity]::new() } else { [Security.AccessControl.FileSecurity]::new() }
    $acl.SetAccessRuleProtection($true, $false)
    $acl.SetOwner([Security.Principal.SecurityIdentifier]::new('S-1-5-32-544'))
    foreach ($sid in @('S-1-5-18','S-1-5-32-544')) {
        $inherit = if ($directory) { 'ContainerInherit,ObjectInherit' } else { 'None' }
        $acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new([Security.Principal.SecurityIdentifier]::new($sid),'FullControl',$inherit,'None','Allow'))
    }
    Set-Acl -LiteralPath $path -AclObject $acl
}
function Test-SBPrivate([string]$path) {
    Test-SBAncestors $path
    $acl = Get-Acl -LiteralPath $path
    if ($acl.GetOwner([Security.Principal.SecurityIdentifier]).Value -notin @('S-1-5-18','S-1-5-32-544')) { throw 'Untrusted transaction owner' }
    $rules = @($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]))
    if ($rules.Count -ne 2) { throw 'Untrusted transaction permissions' }
    foreach ($sid in @('S-1-5-18','S-1-5-32-544')) {
        $match = @($rules | Where-Object { $_.IdentityReference.Value -eq $sid -and [string]$_.AccessControlType -eq 'Allow' -and [string]$_.FileSystemRights -eq 'FullControl' })
        if ($match.Count -ne 1) { throw 'Untrusted transaction access rule' }
    }
}
function New-SBPrivateDirectory([string]$path) {
    Test-SBAncestors $path
    if (-not (Test-Path -LiteralPath $path)) { New-Item -ItemType Directory -Path $path | Out-Null; Set-SBPrivateAcl $path $true }
    if (-not (Get-Item -LiteralPath $path).PSIsContainer) { throw 'Transaction directory is not a directory' }
    Test-SBPrivate $path
}
function Write-SBText([string]$path, [string]$value) {
    Test-SBPrivate ([IO.Path]::GetDirectoryName($path))
    Test-SBAncestors $path
    $temp = $path + '.' + [Guid]::NewGuid().ToString('N')
    try {
        [IO.File]::WriteAllText($temp,$value,[Text.UTF8Encoding]::new($false))
        Set-SBPrivateAcl $temp $false
        $stream = [IO.File]::Open($temp,'Open','ReadWrite','None')
        try { $stream.Flush($true) } finally { $stream.Dispose() }
        # PowerShell 5.1 coerces ordinary $null to an empty string for this .NET
        # string parameter. File.Replace requires an actual null backup path.
        if (Test-Path -LiteralPath $path) { [IO.File]::Replace($temp,$path,[System.Management.Automation.Language.NullString]::Value) } else { [IO.File]::Move($temp,$path) }
    } finally { if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force } }
}
function Write-SBState([string]$path, $value) { Write-SBText $path (Get-SBJson $value) }
function Read-SBState([string]$path) {
    Test-SBPrivate $path
    if ((Get-Item -LiteralPath $path).Length -gt 4194304) { throw 'Oversized transaction record' }
    return [IO.File]::ReadAllText($path) | ConvertFrom-Json
}
function Get-SBService([string]$name) {
    $escaped = $name.Replace("'","''")
    $service = Get-CimInstance -ClassName Win32_Service -Filter "Name='$escaped'"
    if (-not $service) { return [ordered]@{exists=$false; running=$false; start=4; delayed=0; delayedPresent=$false; configuration=''} }
    if ([string]$service.State -notin @('Running','Stopped')) { throw 'Transitional service state requires review' }
    $registry = Get-ItemProperty -LiteralPath ('HKLM:\SYSTEM\CurrentControlSet\Services\'+$name)
    return [ordered]@{exists=$true; running=([string]$service.State -eq 'Running'); start=[int]$registry.Start;
        delayed=[int]$registry.DelayedAutoStart; delayedPresent=($null -ne $registry.PSObject.Properties['DelayedAutoStart']); configuration=(Get-SBHash (Get-SBJson @([string]$service.PathName,[string]$service.StartName))); configurationDetails=@([string]$service.PathName,[string]$service.StartName) }
}
function Restore-SBService([string]$name, $before) {
    $now = Get-SBService $name
    if (-not $now.exists) { if ($before.exists) { throw 'Service disappeared during rollback' }; return }
    $type = switch ([int]$before.start) { 2 {'Automatic'}; 3 {'Manual'}; 4 {'Disabled'}; default { throw 'Unsupported service startup type' } }
    # A previously disabled service must be stopped before its startup is restored.
    if (-not $before.running) { Stop-Service -Name $name; (Get-Service -Name $name).WaitForStatus('Stopped',[TimeSpan]::FromSeconds(45)) }
    Set-Service -Name $name -StartupType $type
    if ($before.delayedPresent) { Set-ItemProperty -LiteralPath ('HKLM:\SYSTEM\CurrentControlSet\Services\'+$name) -Name DelayedAutoStart -Type DWord -Value ([int]$before.delayed) }
    else { Remove-ItemProperty -LiteralPath ('HKLM:\SYSTEM\CurrentControlSet\Services\'+$name) -Name DelayedAutoStart -ErrorAction SilentlyContinue }
    if ($before.running) { Start-Service -Name $name; (Get-Service -Name $name).WaitForStatus('Running',[TimeSpan]::FromSeconds(45)) }
    $after = Get-SBService $name
    if ($after.running -ne $before.running -or $after.start -ne $before.start -or $after.delayed -ne $before.delayed -or $after.delayedPresent -ne $before.delayedPresent) { throw 'Service rollback verification failed' }
    if ($before.exists -and $after.configuration -cne $before.configuration) { throw 'Service configuration was not restored' }
}
function Get-SBFirewall($names) {
    Import-Module NetSecurity
    $values = @()
    foreach ($name in $names) {
        $rule = Get-NetFirewallRule -Name $name -PolicyStore PersistentStore -ErrorAction SilentlyContinue
        if (-not $rule) { $values += [ordered]@{name=$name; exists=$false; fingerprint=''}; continue }
        if (@($rule).Count -ne 1) { throw 'Ambiguous firewall rule ownership' }
        $config = [ordered]@{
            rule=($rule | Select-Object Name,DisplayName,Description,Group,Enabled,Profile,Direction,Action,EdgeTraversalPolicy,LooseSourceMapping,LocalOnlyMapping,Owner)
            port=($rule | Get-NetFirewallPortFilter | Select-Object Protocol,LocalPort,RemotePort,IcmpType,DynamicTarget)
            address=($rule | Get-NetFirewallAddressFilter | Select-Object LocalAddress,RemoteAddress)
            app=($rule | Get-NetFirewallApplicationFilter | Select-Object Program,Package)
            service=($rule | Get-NetFirewallServiceFilter | Select-Object Service)
            interface=($rule | Get-NetFirewallInterfaceFilter | Select-Object InterfaceAlias)
            interfaceType=($rule | Get-NetFirewallInterfaceTypeFilter | Select-Object InterfaceType)
            security=($rule | Get-NetFirewallSecurityFilter | Select-Object Authentication,Encryption,LocalUser,RemoteUser,RemoteMachine,OverrideBlockRules)
        }
        $values += [ordered]@{name=$name; exists=$true; fingerprint=(Get-SBHash (Get-SBJson $config)); configuration=$config}
    }
    return ,$values
}
function Get-SBIis($spec) {
    $root = 'C:\inetpub\' + $spec.name
    Test-SBAncestors $root
    $content = $null
    if (Test-Path -LiteralPath $root) {
        $items = @(Get-ChildItem -LiteralPath $root -Force -Recurse)
        if ($items.Count -ne 1 -or $items[0].Name -ne 'index.html' -or $items[0].PSIsContainer -or ($items[0].Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Unexpected application content requires review' }
        $content = [ordered]@{
            sha256=(Get-FileHash -LiteralPath $items[0].FullName -Algorithm SHA256).Hash.ToLowerInvariant()
            bytes=[Convert]::ToBase64String([IO.File]::ReadAllBytes($items[0].FullName))
            fileSecurity=(Get-Acl -LiteralPath $items[0].FullName).Sddl
            directorySecurity=(Get-Acl -LiteralPath $root).Sddl
            revision=@($items[0].CreationTimeUtc.Ticks,$items[0].LastWriteTimeUtc.Ticks)
            fileAcl=(Get-SBHash (Get-Acl -LiteralPath $items[0].FullName).Sddl)
            directoryAcl=(Get-SBHash (Get-Acl -LiteralPath $root).Sddl)
        }
    }
    $sitePresent=$false; $siteRunning=$false; $poolPresent=$false; $poolRunning=$false; $ssl=$null; $config=''
    if (Get-Module -ListAvailable WebAdministration) {
        Import-Module WebAdministration
        $site = Get-Website -Name $spec.name -ErrorAction SilentlyContinue
        $sitePresent = $null -ne $site
        if ($sitePresent) { $siteRunning = [string]$site.state -eq 'Started' }
        $poolPresent = Test-Path -LiteralPath ('IIS:\AppPools\'+$spec.name)
        if ($poolPresent) { $poolRunning = [string](Get-WebAppPoolState -Name $spec.name).Value -eq 'Started' }
        if ($spec.certificate) {
            $sslPath = 'IIS:\SslBindings\' + $spec.address + '!' + $spec.port
            if (Test-Path -LiteralPath $sslPath) {
                $entry = Get-Item -LiteralPath $sslPath
                $ssl = [ordered]@{thumbprint=[string]$entry.Thumbprint; store=[string]$entry.Store}
            }
        }
        $config = (Get-FileHash -LiteralPath ($env:windir+'\System32\inetsrv\config\applicationHost.config') -Algorithm SHA256).Hash.ToLowerInvariant()
    }
    return [ordered]@{content=$content; sitePresent=$sitePresent; siteRunning=$siteRunning; poolPresent=$poolPresent;
        poolRunning=$poolRunning; ssl=$ssl; configuration=$config; service=(Get-SBService 'W3SVC')}
}
function Get-SBSnapshot($spec) {
    switch ($spec.recipe) {
        'windows-service' { return Get-SBService $spec.service }
        'windows-firewall' { return ,(Get-SBFirewall $spec.rules) }
        'windows-iis' { return Get-SBIis $spec }
        default { throw 'Unsupported owned Windows recipe' }
    }
}
function Release-SBClaims($state, [string]$token, [string]$root) {
    foreach ($key in $state.resources) {
        $p=Join-Path $root ('resource-'+$key+'.json')
        if (Test-Path -LiteralPath $p) { if ((Read-SBState $p).transaction -cne $token) { throw 'Transaction resource owner changed' } }
    }
    foreach ($key in $state.resources) { $p=Join-Path $root ('resource-'+$key+'.json'); if (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p -Force } }
}
function Restore-SBOwned($state, $spec, [string]$token, [string]$base, [string]$root) {
    if ($state.status -eq 'rolled-back') { Release-SBClaims $state $token $root; return }
    if ($state.status -notin @('applied','apply-failed')) { throw 'Unknown or committed mutation requires reconciliation' }
    $now = Get-SBSnapshot $spec
    switch ($spec.recipe) {
        'windows-service' {
            foreach ($key in @('exists','start','delayed','delayedPresent','configuration')) { if ($now.$key -cne $state.after.$key) { throw 'Service configuration changed after setup' } }
            Restore-SBService $spec.service $state.before
        }
        'windows-firewall' {
            if (-not (Test-SBEqual $now $state.after)) { throw 'Firewall changed after setup; rollback held' }
            foreach ($row in $state.before) { if (-not $row.exists) { Remove-NetFirewallRule -Name $row.name -PolicyStore PersistentStore -ErrorAction SilentlyContinue } }
            if (-not (Test-SBEqual (Get-SBSnapshot $spec) $state.before)) { throw 'Firewall rollback verification failed' }
        }
        'windows-iis' {
            foreach ($key in @('content','sitePresent','poolPresent','ssl','configuration')) { if (-not (Test-SBEqual $now.$key $state.after.$key)) { throw 'IIS changed after setup; rollback held' } }
            foreach ($key in @('exists','start','delayed','delayedPresent','configuration')) { if ($now.service.$key -cne $state.after.service.$key) { throw 'IIS service changed after setup' } }
            if (-not $state.before.sitePresent -and $now.sitePresent) { Remove-Website -Name $spec.name }
            elseif ($state.before.sitePresent) { if ($state.before.siteRunning) { Start-Website -Name $spec.name } else { Stop-Website -Name $spec.name } }
            if (-not $state.before.poolPresent -and $now.poolPresent) { Remove-WebAppPool -Name $spec.name }
            elseif ($state.before.poolPresent) { if ($state.before.poolRunning) { Start-WebAppPool -Name $spec.name } else { Stop-WebAppPool -Name $spec.name } }
            if ($null -eq $state.before.ssl -and $null -ne $now.ssl) { Remove-Item -LiteralPath ('IIS:\SslBindings\'+$spec.address+'!'+$spec.port) }
            if ($null -eq $state.before.content -and $null -ne $now.content) {
                $directory='C:\inetpub\'+$spec.name
                Remove-Item -LiteralPath ($directory+'\index.html') -Force
                Remove-Item -LiteralPath $directory -Force
            }
            Restore-SBService 'W3SVC' $state.before.service
            $restored=Get-SBSnapshot $spec
            foreach ($key in @('content','sitePresent','siteRunning','poolPresent','poolRunning','ssl')) { if (-not (Test-SBEqual $restored.$key $state.before.$key)) { throw 'IIS rollback verification failed' } }
        }
    }
    $state.status='rolled-back'; Write-SBState (Join-Path $base 'state.json') $state
    Release-SBClaims $state $token $root
}
function Invoke-SentinelTransaction([string]$phase, [string]$token, $spec, [string]$apply) {
    if ($token -cnotmatch '^[0-9a-f]{32}$' -or $phase -notin @('admit','apply','rollback','commit')) { throw 'Invalid owned transaction identity or phase' }
    $principal=[Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Owned Windows setup requires elevation' }
    $plain=[Text.Encoding]::Unicode.GetString([Convert]::FromBase64String($apply))
    if ((Get-SBHash $plain) -cne $spec.apply_sha256) { throw 'Setup command identity changed' }
    $root=Join-Path ([Environment]::GetFolderPath('CommonApplicationData')) 'SentinelBlueSetupTransactions'
    Test-SBAncestors $root
    if ($phase -eq 'admit' -and -not (Test-Path -LiteralPath $root)) { exit 0 }
    New-SBPrivateDirectory $root
    $ledger=Open-SBLedger
    if($phase -in @('admit','apply') -and (Test-SBLPaused $ledger)){Close-SBLedger $ledger;throw 'Emergency withdrawal paused setup'}
    $lock=$null; $deadline=[DateTime]::UtcNow.AddSeconds(5)
    while ($null -eq $lock) {
        try { $lock=[IO.File]::Open((Join-Path $root 'lock'),'OpenOrCreate','ReadWrite','None') }
        catch [IO.IOException] { if ([DateTime]::UtcNow -ge $deadline) { throw 'Another owned setup command is active' }; Start-Sleep -Milliseconds 50 }
    }
    try {
        $base=Join-Path $root $token
        if ($phase -in @('admit','apply')) {
            if ($phase -eq 'apply' -and (Test-Path -LiteralPath $base)) { throw 'A setup mutation cannot be replayed' }
            $resources=@()
            if ($spec.service) { $resources += 'service:'+$spec.service.ToLowerInvariant() }
            if ($spec.recipe -eq 'windows-firewall') { foreach ($name in $spec.rules) { $resources += 'firewall:'+$name.ToLowerInvariant() } }
            if ($spec.recipe -eq 'windows-iis') { $resources += 'iis:'+$spec.name.ToLowerInvariant() }
            $keys=@($resources | Sort-Object -Unique | ForEach-Object { Get-SBHash $_ })
            foreach ($key in $keys) { if (Test-Path -LiteralPath (Join-Path $root ('resource-'+$key+'.json'))) { throw 'An earlier setup transaction still owns this resource' } }
            if ($phase -eq 'admit') { exit 0 }
            $before=Get-SBSnapshot $spec
            Prepare-SBLSetup $ledger $spec $token $before
            if ($spec.recipe -eq 'windows-iis' -and $spec.certificate -and $before.ssl -and ($before.ssl.thumbprint -ine $spec.certificate -or $before.ssl.store -ine 'My')) { throw 'An existing HTTPS binding requires review' }
            New-SBPrivateDirectory $base
            $state=[ordered]@{status='prepared'; spec=$spec; before=$before; after=$null; resources=$keys}
            Write-SBState (Join-Path $base 'state.json') $state
            foreach ($key in $keys) { Write-SBState (Join-Path $root ('resource-'+$key+'.json')) @{transaction=$token} }
            $scriptPath=Join-Path $base 'apply.ps1'
            Write-SBText $scriptPath $plain
            try {
                & (Join-Path $PSHOME 'powershell.exe') -NoLogo -NoProfile -NonInteractive -File $scriptPath
                $code=$LASTEXITCODE
            } finally { Remove-Item -LiteralPath $scriptPath -Force }
            if ($code -eq 30) { $state.status='reboot-required'; Write-SBState (Join-Path $base 'state.json') $state; exit 30 }
            $state.after=Get-SBSnapshot $spec; $state.status=if ($code -eq 0) { 'applied' } else { 'apply-failed' }
            Write-SBState (Join-Path $base 'state.json') $state
            Write-SBLEvent $ledger 'applied' @{action_id=('setup-'+$token);after_hash=(Store-SBLState $ledger $state.after);validation=@{success=($code -eq 0);external=$false}}
            if ($code -ne 0) { Restore-SBOwned $state $spec $token $base $root; Write-SBLEvent $ledger 'cancelled' @{action_id=('setup-'+$token);restored_hash=(Store-SBLState $ledger (Get-SBSnapshot $spec));validation=@{success=$false;rolled_back=$true}}; exit $code }
        } else {
            Test-SBPrivate $base; $state=Read-SBState (Join-Path $base 'state.json')
            if (-not (Test-SBEqual $state.spec $spec)) { throw 'Rollback configuration does not match its private record' }
            if ($phase -eq 'rollback') { Restore-SBOwned $state $spec $token $base $root; Write-SBLEvent $ledger 'cancelled' @{action_id=('setup-'+$token);restored_hash=(Store-SBLState $ledger (Get-SBSnapshot $spec));validation=@{success=$true}} }
            else {
                if ($state.status -ne 'applied' -or -not (Test-SBEqual (Get-SBSnapshot $spec) $state.after)) { throw 'Owned setup changed before health confirmation' }
                Write-SBLEvent $ledger 'committed' @{action_id=('setup-'+$token);after_hash=(Store-SBLState $ledger $state.after);validation=@{success=$true;external_health_confirmed=$true}}
                $state.status='committed'; Write-SBState (Join-Path $base 'state.json') $state; Release-SBClaims $state $token $root
            }
        }
    } finally { $lock.Dispose(); Close-SBLedger $ledger }
    exit 0
}
