"""Durable, per-service recovery holds, independent of event-profile grants.

The controller persists a pause before queuing an operator's inverse. Signed
poll responses replicate it to the agent. A local undo latch also prevents a
lost result or disconnection from allowing offline recovery to reapply it.
Resume removes only this hold, never profile, failure, baseline or global gates.

2.0.15 (R214-01/R214-01b): state belongs to one approved-profile lineage. A
re-approved profile carries every hold of a still-approved service forward
into its own lineage (controller and agent) instead of refusing forever. A
controller whose state is older than an agent's durable floor no longer cuts
the agent off: the agent keeps its floor, holds only automatic recovery, still
receives reviewed manual work, and reports its floor on the signed poll so an
explicit operator Pause/Resume can re-synchronize without dropping a hold.
"""
from __future__ import annotations
import copy
import json
import logging
import math
import threading
import time
from pathlib import Path
from urllib.parse import urlencode

from .json_codec import canonical_json_dumps, strict_json_loads
from .state import read_private_json, write_private_json
from .validation import validate_agent_id

LOG = logging.getLogger('sentinel_blue.service_automation')
MAX_BYTES = 256 * 1024
MAX_SERVICES = 256
FORWARD = frozenset({'restart_service', 'repair_service', 'restore_integrity'})
KEY_PREFIX = 'service_automation:'
# Agent -> controller floor report on the signed poll query (R214-01b).
REPORT_PARAMETER = 'sa'
MAX_REPORT_BYTES = 48 * 1024
MAX_REPORT_REVISION = 2**62
_REPORTS_LOCK = threading.RLock()


def _key(agent):
    return KEY_PREFIX + validate_agent_id(agent)


def empty(profile, agent):
    return {'schema': 1, 'agent_id': agent, 'profile_fingerprint': profile.fingerprint,
            'revision': 0, 'services': {}}


def _approved(profile, agent):
    return {m['service_id'] for m in profile.services if m['host'] == agent}


def validate_structure(value, agent):
    """Shape checks that do not depend on which approved profile is in force."""
    if (not isinstance(value, dict) or set(value) != {'schema', 'agent_id', 'profile_fingerprint', 'revision', 'services'}
            or type(value['schema']) is not int or value['schema'] != 1
            or value['agent_id'] != agent
            or not isinstance(value['profile_fingerprint'], str) or len(value['profile_fingerprint']) != 64
            or any(c not in '0123456789abcdef' for c in value['profile_fingerprint'])
            or type(value['revision']) is not int or not 0 <= value['revision'] < 2**63
            or not isinstance(value['services'], dict) or len(value['services']) > MAX_SERVICES):
        raise ValueError('service automation state is invalid or belongs to another profile; review required')
    for service, item in value['services'].items():
        if (not isinstance(service, str) or not 1 <= len(service) <= 128 or not isinstance(item, dict)
                or set(item) != {'paused', 'reason', 'transaction_id', 'updated_at'}
                or type(item['paused']) is not bool
                or not isinstance(item['reason'], str) or not 1 <= len(item['reason']) <= 500
                or not isinstance(item['transaction_id'], str) or len(item['transaction_id']) > 128
                or type(item['updated_at']) not in (int, float) or not math.isfinite(item['updated_at'])):
            raise ValueError('service automation entry is malformed or outside the approved service scope')
    return value


def validate(value, profile, agent):
    validate_structure(value, agent)
    if value['profile_fingerprint'] != profile.fingerprint:
        raise ValueError('service automation state is invalid or belongs to another profile; review required')
    approved = _approved(profile, agent)
    if any(service not in approved for service in value['services']):
        raise ValueError('service automation entry is malformed or outside the approved service scope')
    return copy.deepcopy(value)


def carried_lineage(value, profile, agent):
    """The same holds, re-scoped to the approved profile now in force.

    Entries of services that remain approved for this agent keep their pause,
    reason and transaction identity. Entries of services the new profile no
    longer approves cannot be automated under it and are not carried.
    """
    approved = _approved(profile, agent)
    carried = {s: copy.deepcopy(e) for s, e in value['services'].items() if s in approved}
    return ({'schema': 1, 'agent_id': agent, 'profile_fingerprint': profile.fingerprint,
             'revision': value['revision'], 'services': carried},
            sorted(set(value['services']) - set(carried)))


def migrate_lineage(store, profile):
    """Move every agent's controller record into the profile now in force (R214-01).

    Runs once per controller start, after the release binding is activated.
    The revision is kept: the agent carries its own floor into the new lineage
    the same way, so an in-step agent sees identical state, and a controller
    that was already behind an agent cannot move past that floor without an
    explicit operator decision. Unreadable records are never replaced; they
    stay a per-agent hold for review. Returns the migrated agent identities.
    """
    migrated = []
    with store._lock:
        rows = store._connection.execute(
            'SELECT state_key, state_value FROM controller_state WHERE substr(state_key, 1, ?) = ?',
            (len(KEY_PREFIX), KEY_PREFIX)).fetchall()
        plans = []
        for row in rows:
            agent = str(row['state_key'])[len(KEY_PREFIX):]
            try:
                validate_agent_id(agent)
                value = validate_structure(strict_json_loads(row['state_value'], max_bytes=MAX_BYTES), agent)
            except (TypeError, ValueError):
                LOG.error('service automation state for %s is unreadable; its hold remains for review', agent[:128])
                continue
            if value['profile_fingerprint'] == profile.fingerprint or value['revision'] >= 2**63 - 2:
                continue
            carried, dropped = carried_lineage(value, profile, agent)
            validate(carried, profile, agent)
            plans.append((row['state_key'], row['state_value'], carried, value, dropped))
        if not plans:
            return migrated
        store._connection.execute('BEGIN IMMEDIATE')
        try:
            for key, old_text, carried, value, dropped in plans:
                changed = store._connection.execute(
                    'UPDATE controller_state SET state_value=?, updated_at=? WHERE state_key=? AND state_value=?',
                    (canonical_json_dumps(carried, max_bytes=MAX_BYTES), time.time(), key, old_text)).rowcount
                if not changed:
                    continue
                store.audit('controller', 'migrate_service_automation_lineage', carried['agent_id'], {
                    'from_profile_fingerprint': value['profile_fingerprint'],
                    'to_profile_fingerprint': carried['profile_fingerprint'],
                    'revision': carried['revision'],
                    'paused_services_carried': sorted(s for s, e in carried['services'].items() if e['paused']),
                    'services_no_longer_approved': dropped})
                migrated.append(carried['agent_id'])
            store._connection.commit()
        except BaseException:
            if store._connection.in_transaction:
                store._connection.rollback()
            raise
    return migrated


def snapshot(store, profile, agent):
    with store._lock:
        row = store._connection.execute('SELECT state_value FROM controller_state WHERE state_key=?',
                                         (_key(agent),)).fetchone()
        value = strict_json_loads(row['state_value'], max_bytes=MAX_BYTES) if row else empty(profile, agent)
        return validate(value, profile, agent)


def _after(now, entry):
    """A decision's timestamp is strictly later than the entry it replaces.

    Agents accept an unpause only from an entry newer than the pause they hold.
    """
    return max(now, entry['updated_at'] + 1e-6) if entry else now


def update(store, profile, agent, service, paused, reason, *, expected_revision=None, transaction_id=None,
           report=None):
    return update_with_details(store, profile, agent, service, paused, reason, expected_revision=expected_revision,
                               transaction_id=transaction_id, report=report)[0]


def update_with_details(store, profile, agent, service, paused, reason, *, expected_revision=None,
                        transaction_id=None, report=None):
    """Caller serializes controller egress/governance. Commit pause before undo.

    An unsuccessful subsequent queue leaves the pause in place deliberately.
    No audit/retention sweep deletes this controller_state record.

    `report` is the agent's last authenticated floor report. When this
    controller's state is behind that floor (for example after a restore),
    this explicit operator decision re-synchronizes it: the revision moves past
    the floor and every hold the agent reported for another service is carried
    forward as a pause (with its undo transaction), so no hold is silently
    lost. Only the service the operator explicitly chose changes.
    """
    if (type(paused) is not bool or not isinstance(reason, str) or not 3 <= len(reason.strip()) <= 500
            or any(ord(c) < 32 or ord(c) == 127 for c in reason)):
        raise ValueError('enter a bounded explicit reason and Boolean pause choice')
    with store._lock:
        old = snapshot(store, profile, agent)
        if expected_revision is not None and expected_revision != old['revision']:
            raise PermissionError('service automation changed; refresh before changing its hold')
        new = copy.deepcopy(old)
        base = old['revision']
        details = {'resynchronized_from_agent_floor': None, 'carried_forward': []}
        now = time.time()
        if report is not None and behind(report, old):
            base = max(base, report['revision'])
            details['resynchronized_from_agent_floor'] = report['revision']
            approved = _approved(profile, agent)
            held = {s: t for s, t in report['held'].items() if s in approved}
            for other in sorted((set(held) | set(report['latches'])) & approved - {service}):
                entry = new['services'].get(other)
                # Kept already, or an explicit Resume newer than the agent's pause.
                lost_pause = other in held and not keeps_hold(entry, held[other])
                lost_latch = latch_holds(report, old, other) and not (entry is not None and entry['paused'] is True)
                if not (lost_pause or lost_latch):
                    continue
                txn = report['latches'].get(other, (entry or {}).get('transaction_id', ''))
                new['services'][other] = {
                    'paused': True, 'transaction_id': txn, 'updated_at': _after(now, entry),
                    'reason': ("Carried forward from the agent's durable hold (revision "
                               f"{report['revision']}); the controller state had fallen behind")}
                details['carried_forward'].append(other)
        if report is not None and transaction_id is None and service in report['latches']:
            # The agent's undo latch clears only with this exact transaction,
            # whether or not this controller is behind (a restore can lose it).
            transaction_id = report['latches'][service]
        if base >= 2**63 - 2:
            raise ValueError('service automation revision exhausted')
        previous = new['services'].get(service, {})
        new['revision'] = base + 1
        decided_at = _after(now, previous)
        held_at = (report or {}).get('held', {}).get(service)
        if held_at is not None and math.isfinite(held_at):
            # This explicit decision knowingly supersedes the agent's reported
            # pause, even if this controller's clock is behind that pause.
            decided_at = max(decided_at, held_at + 1e-6)
        new['services'][service] = {'paused': paused, 'reason': reason.strip(),
            'transaction_id': previous.get('transaction_id', '') if transaction_id is None else transaction_id,
            'updated_at': decided_at}
        validate(new, profile, agent)
        data = canonical_json_dumps(new, max_bytes=MAX_BYTES)
        store._connection.execute('INSERT INTO controller_state(state_key,state_value,updated_at) VALUES(?,?,?) '
            'ON CONFLICT(state_key) DO UPDATE SET state_value=excluded.state_value,updated_at=excluded.updated_at',
            (_key(agent), data, time.time()))
        store._connection.commit()
        return new, details


# -- agent floor reports (R214-01b) -------------------------------------------
def parse_report(profile, agent, values):
    """Validate one agent's signed-poll floor report; None when absent.

    `held` maps each service paused in the agent's floor to that pause entry's
    `updated_at` (a controller timestamp). With it the controller evaluates
    exactly the agent's own adoption rule (`continuous`), without guessing
    which responses the agent has seen.
    """
    raw = values.get(REPORT_PARAMETER)
    if not raw:
        return None
    if len(raw) != 1 or len(raw[0]) > MAX_REPORT_BYTES:
        raise ValueError('service automation report is malformed')
    value = strict_json_loads(raw[0], max_bytes=MAX_REPORT_BYTES)
    if (not isinstance(value, dict) or set(value) != {'revision', 'behind', 'held', 'latches', 'truncated'}
            or type(value['revision']) is not int or not 0 <= value['revision'] < MAX_REPORT_REVISION
            or type(value['behind']) is not bool or type(value['truncated']) is not bool
            or not isinstance(value['held'], dict) or len(value['held']) > MAX_SERVICES
            or any(not isinstance(s, str) or not 1 <= len(s) <= 128 or type(t) not in (int, float)
                   or not math.isfinite(t) for s, t in value['held'].items())
            or not isinstance(value['latches'], dict) or len(value['latches']) > MAX_SERVICES
            or any(not isinstance(s, str) or not 1 <= len(s) <= 128 or not isinstance(t, str)
                   or not 1 <= len(t) <= 128 or any(ord(c) < 33 or ord(c) > 126 for c in t)
                   for s, t in value['latches'].items())):
        raise ValueError('service automation report is malformed')
    approved = _approved(profile, agent)
    # A truncated report could hold anything: every approved service counts as
    # held with an unknown (infinitely late) pause, so only a pause carries it.
    held = ({s: math.inf for s in approved} if value['truncated']
            else {s: float(t) for s, t in value['held'].items() if s in approved})
    return {'revision': value['revision'], 'behind': value['behind'], 'truncated': value['truncated'],
            'held': dict(sorted(held.items())),
            'latches': {s: t for s, t in sorted(value['latches'].items()) if s in approved},
            'reported_at': time.time()}


def _reports(app):
    reports = getattr(app, '_service_automation_reports', None)
    if reports is None:
        with _REPORTS_LOCK:
            reports = getattr(app, '_service_automation_reports', None)
            if reports is None:
                reports = {}
                app._service_automation_reports = reports
    return reports


def record_report(app, agent, values):
    """Remember the latest authenticated floor report (memory only; re-sent each poll)."""
    try:
        report = parse_report(app.event_profile, agent, values)
    except (TypeError, ValueError) as exc:
        LOG.warning('ignoring malformed service automation report from %s: %s', agent[:128], exc)
        report = None
    with _REPORTS_LOCK:
        _reports(app)[agent] = report
    return report


def agent_report(app, agent):
    with _REPORTS_LOCK:
        return copy.deepcopy(_reports(app).get(agent))


def keeps_hold(entry, paused_at):
    """The agent's continuity rule for one held service (see `continuous`)."""
    return entry is not None and (entry['paused'] is True or entry['updated_at'] > paused_at)


def behind(report, control):
    """True when the agent will not adopt this controller state.

    Mirrors LocalAutomation.accept exactly: a lower revision, an equal revision
    the agent reported as conflicting, or a newer revision that drops any hold
    of the agent's floor. The revision alone is never trusted.
    """
    if report is None:
        return False
    if report['revision'] > control['revision']:
        return True
    keeps = all(keeps_hold(control['services'].get(s), t) for s, t in report['held'].items())
    if report['revision'] == control['revision']:
        # In step means identical state, so every held service is paused here.
        return report['behind'] or not keeps
    return not keeps


def latch_holds(report, control, service):
    """The agent holds an undo latch this controller state will not clear."""
    if report is None or service not in report['latches']:
        return False
    entry = control['services'].get(service)
    return not (entry is not None and entry['paused'] is False
                and entry['transaction_id'] == report['latches'][service])


def sync_status(app, agent, control):
    report = agent_report(app, agent)
    status = {'agent_reported': report is not None, 'behind': behind(report, control),
              'controller_revision': control['revision'],
              'latched': sorted(s for s in (report or {}).get('latches', {}) if latch_holds(report, control, s))}
    if report is not None:
        status.update(agent_floor_revision=report['revision'], agent_held=sorted(report['held']),
                      agent_latched=sorted(report['latches']), report_truncated=report['truncated'],
                      reported_seconds_ago=round(max(0.0, time.time() - report['reported_at']), 1))
    return status


def behind_reason(status):
    return ('Agent holds automatic recovery: controller automation state (revision '
            f"{status['controller_revision']}) is older than, conflicts with or does not carry the holds of the "
            f"agent's durable floor (revision {status.get('agent_floor_revision')}). Review, then Pause or Resume "
            "explicitly to re-synchronize; the agent's other holds are carried forward.")


def latch_reason(service):
    return ('Agent holds an undo latch for ' + service + '; automatic recovery stays paused until an explicit '
            'Resume of that service')


def controller_refusal(app, agent, action_type, parameters, control=None):
    """The controller's view: an operator hold, or an agent that is ahead of it."""
    control = snapshot(app.store, app.event_profile, agent) if control is None else control
    reason = refusal(control, app.event_profile, agent, action_type, parameters)
    if reason is None and action_type in FORWARD:
        status = sync_status(app, agent, control)
        if status['behind']:
            reason = behind_reason(status)
        else:
            latched = sorted(set(status['latched']) & affected(app.event_profile, agent, action_type, parameters))
            if latched:
                reason = latch_reason(', '.join(latched))
    return reason


def affected(profile, agent, action_type, parameters):
    if action_type not in FORWARD:
        return set()
    if action_type != 'restore_integrity':
        return {parameters.get('service')} if isinstance(parameters.get('service'), str) else set()
    from .service_repair import recovery_files, path_key
    target = parameters.get('path')
    if not isinstance(target, str):
        return set()
    return {m['service_id'] for m in profile.services if m['host'] == agent
            and path_key(target) in {path_key(p) for p in recovery_files(m)}}


def inverse_readiness(profile, agent, action_type, parameters):
    """Only already authorized, recorded inverse kinds may accompany automation."""
    if action_type not in FORWARD or not profile.services_confirmed:
        return None
    targets = affected(profile, agent, action_type, parameters)
    inverse = {'restart_service': 'rollback_service', 'repair_service': 'rollback_service_repair',
               'restore_integrity': 'rollback_integrity'}[action_type]
    manifests = [m for m in profile.services if m['host'] == agent and m['service_id'] in targets]
    if not targets or len(manifests) != len(targets):
        return 'automatic recovery requires an exact declared service and recorded inverse'
    if (not profile.action_allowed(inverse, automated=False, autonomy_mode='approval-based')
            or any(inverse not in m['approval_actions'] for m in manifests)):
        return 'approve ' + inverse + ' before enabling this automatic recovery; no permission was added'
    return None


def refusal(value, profile, agent, action_type, parameters):
    held = [service for service in affected(profile, agent, action_type, parameters)
            if value['services'].get(service, {}).get('paused') is True]
    if held:
        return 'Automatic recovery paused by operator for ' + ', '.join(sorted(held)) + '; explicit resume required'
    return None


def continuous(floor, value):
    """A newer controller state may replace the floor only if it keeps its holds.

    Every service paused in the floor must still be paused, or carry an
    explicit decision made after that pause (a reviewed Resume). A restored or
    rebuilt controller that merely counted past the floor without knowing a
    pause is therefore treated as behind, not as newer (review of R214-01b).
    """
    return all(keeps_hold(value['services'].get(service), entry['updated_at'])
               for service, entry in floor['services'].items() if entry['paused'] is True)


class LocalAutomation:
    """Private signed-response snapshot plus sticky local inverse latches.

    The ordinary authenticated client verifies the response before accept(). A
    stale restored controller cannot clear a newer hold: decreasing revisions or
    altered equal-revision state never replace the durable floor. Latches
    require an explicit, newer resume for the same transaction, not
    disappearance from a snapshot.

    2.0.15: a stale controller no longer makes accept() fail the whole poll
    (R214-01b). The floor is kept, a small synchronization record holds every
    automatic forward change on this agent until the controller catches up,
    and reviewed manual work is still delivered. A snapshot recorded under a
    previously approved profile is carried into the current profile's lineage
    with the same revision floor and every still-approved hold/latch (R214-01).
    """
    SYNC_NAME = 'service-automation-sync.json'

    def __init__(self, directory, profile, agent):
        self.path = Path(directory) / 'service-automation.json'
        self.sync_path = Path(directory) / self.SYNC_NAME
        self.profile, self.agent = profile, agent

    def _load(self):
        """Return (data, prior_lineage). Nothing is written here."""
        if not self.path.exists() and not self.path.is_symlink():
            return {'snapshot': empty(self.profile, self.agent), 'latches': {}}, False
        data = read_private_json(self.path, MAX_BYTES)
        if not isinstance(data, dict) or set(data) != {'snapshot', 'latches'}:
            raise ValueError('local automation evidence is invalid; automatic changes are held')
        validate_structure(data['snapshot'], self.agent)
        if not isinstance(data['latches'], dict) or len(data['latches']) > MAX_SERVICES:
            raise ValueError('invalid local inverse latches')
        for service, item in data['latches'].items():
            if (not isinstance(service, str) or not 1 <= len(service) <= 128
                    or not isinstance(item, dict) or set(item) != {'transaction_id', 'revision'}
                    or not isinstance(item['transaction_id'], str) or not 1 <= len(item['transaction_id']) <= 128
                    or type(item['revision']) is not int or item['revision'] < 0):
                raise ValueError('invalid local inverse latch')
        approved = _approved(self.profile, self.agent)
        if data['snapshot']['profile_fingerprint'] == self.profile.fingerprint:
            validate(data['snapshot'], self.profile, self.agent)
            if any(service not in approved for service in data['latches']):
                raise ValueError('invalid local inverse latch')
            return data, False
        # A re-approved profile starts its own lineage from this durable floor.
        carried, _ = carried_lineage(data['snapshot'], self.profile, self.agent)
        return {'snapshot': carried,
                'latches': {s: dict(item) for s, item in data['latches'].items() if s in approved}}, True

    def read(self):
        return self._load()[0]

    def sync(self):
        """None when in step with the controller; otherwise the recorded gap."""
        if not self.sync_path.exists() and not self.sync_path.is_symlink():
            return None
        value = read_private_json(self.sync_path, 4096)
        if (not isinstance(value, dict) or set(value) != {'schema', 'controller_revision', 'floor_revision'}
                or value['schema'] != 1 or type(value['schema']) is not int
                or any(type(value[k]) is not int or not 0 <= value[k] < 2**63
                       for k in ('controller_revision', 'floor_revision'))):
            raise ValueError('local automation synchronization evidence is invalid; automatic changes are held')
        return value

    def _set_sync(self, value):
        if value is None:
            if self.sync_path.exists() or self.sync_path.is_symlink():
                self.sync_path.unlink()
            return
        try:
            current = self.sync()
        except (OSError, ValueError):
            current = None
        if current != value:
            write_private_json(self.sync_path, value)

    def accept(self, incoming):
        """Persist an authenticated controller snapshot; returns 'current' or 'behind'."""
        value = validate(incoming, self.profile, self.agent)
        data, prior = self._load(); previous = data['snapshot']
        if (value['revision'] < previous['revision'] or (value['revision'] == previous['revision'] and value != previous)
                or not continuous(previous, value)):
            if prior:
                write_private_json(self.path, data)
            self._set_sync({'schema': 1, 'controller_revision': value['revision'],
                            'floor_revision': previous['revision']})
            return 'behind'
        before = copy.deepcopy(data['latches'])
        for service, item in list(data['latches'].items()):
            remote = value['services'].get(service, {})
            if (value['revision'] > item['revision'] and remote.get('paused') is False
                    and remote.get('transaction_id') == item['transaction_id']):
                del data['latches'][service]
        if value != previous or data['latches'] != before or prior or not self.path.exists():
            data['snapshot'] = value
            write_private_json(self.path, data)
        self._set_sync(None)
        return 'current'

    def latch(self, service, transaction_id):
        data = self.read()
        if not transaction_id:
            raise ValueError('inverse requires a transaction identity before pausing automation')
        if service not in _approved(self.profile, self.agent):
            raise ValueError('inverse names a service outside the approved profile; no latch was recorded')
        data['latches'][service] = {'transaction_id': transaction_id, 'revision': data['snapshot']['revision']}
        write_private_json(self.path, data)
        self.read()

    def refusal(self, action_type, parameters):
        data = self.read()
        for service in affected(self.profile, self.agent, action_type, parameters):
            if service in data['latches']:
                return 'Automatic recovery remains paused after recorded undo of ' + service
        gap = self.sync()
        if gap is not None and action_type in FORWARD:
            return (f"controller automation state (revision {gap['controller_revision']}) is older than, conflicts with "
                    f"or does not carry the holds of this agent's durable floor (revision {gap['floor_revision']}); "
                    'automatic recovery is held until an explicit operator Pause or Resume re-synchronizes it')
        return refusal(data['snapshot'], self.profile, self.agent, action_type, parameters)

    def report(self):
        """Signed-poll query pairs describing this agent's durable floor."""
        data = self.read()
        gap = self.sync()
        # Holds and latches are always reported: the controller may be behind
        # before this agent has seen any of its stale state (first poll).
        value = {'revision': data['snapshot']['revision'], 'behind': gap is not None, 'truncated': False,
                 'latches': {s: item['transaction_id'] for s, item in sorted(data['latches'].items())},
                 'held': {s: e['updated_at'] for s, e in sorted(data['snapshot']['services'].items())
                          if e['paused'] is True}}
        if value['held'] or value['latches']:
            for trim in ('held', 'latches'):
                if len(urlencode([(REPORT_PARAMETER, json.dumps(value, separators=(',', ':'), sort_keys=True))])) <= MAX_REPORT_BYTES:
                    break
                value[trim] = {}
                value['truncated'] = True
        text = json.dumps(value, separators=(',', ':'), sort_keys=True)
        if len(text) > MAX_REPORT_BYTES or len(urlencode([(REPORT_PARAMETER, text)])) > MAX_REPORT_BYTES:
            value.update(held={}, latches={}, truncated=True)
            text = json.dumps(value, separators=(',', ':'), sort_keys=True)
        return [(REPORT_PARAMETER, text)]


def cancelled_before_delivery(item):
    from .store import ACTION_AUTOMATION_PAUSED_RESULT
    return (item.get('status') == 'failed' and item.get('automated') in (1, True)
            and item.get('attempts') == 0 and item.get('dispatched_at') is None
            and item.get('result_source') == 'controller'
            and item.get('result') == strict_json_loads(ACTION_AUTOMATION_PAUSED_RESULT, max_bytes=4096))


def never_delivered(item):
    """Automatic work no agent ever received: cancelled by Pause, or expired
    before delivery (2.0.18). It changed nothing, so it is not later work."""
    from .store import ACTION_AUTHORIZATION_EXPIRED_RESULT
    if cancelled_before_delivery(item):
        return True
    return (item.get('status') == 'failed' and item.get('automated') in (1, True)
            and item.get('attempts') == 0 and item.get('dispatched_at') is None
            and item.get('result_source') == 'controller'
            and item.get('result') == strict_json_loads(ACTION_AUTHORIZATION_EXPIRED_RESULT, max_bytes=4096))


def cancel_queued(store, profile, agent, service):
    """Cancel only positively never-leased automatic work after the pause commits.

    Delivered, unknown and manual actions are not declared cancelled. Their
    ordinary verification/reconciliation remains necessary before undo/resume.
    The caller holds the controller's egress and governance barriers.
    """
    from .store import ACTION_AUTOMATION_PAUSED_RESULT
    cancelled = []
    with store._lock:
        rows = store._connection.execute(
            "SELECT action_id,action_type,parameters_json FROM actions WHERE agent_id=? "
            "AND status='queued' AND automated=1 AND attempts=0 AND dispatched_at IS NULL "
            "AND action_type IN ('restart_service','repair_service','restore_integrity') LIMIT 65", (agent,)).fetchall()
        if len(rows) > 64:
            raise ValueError('outstanding action budget exceeded; pause remains held')
        for row in rows:
            parameters = strict_json_loads(row['parameters_json'], max_bytes=1024*1024)
            if service not in affected(profile, agent, row['action_type'], parameters):
                continue
            changed = store._connection.execute(
                "UPDATE actions SET status='failed',completed_at=?,result_json=?,result_source='controller' "
                "WHERE action_id=? AND status='queued' AND automated=1 AND attempts=0 "
                "AND dispatched_at IS NULL AND parameters_json=?",
                (time.time(), ACTION_AUTOMATION_PAUSED_RESULT, row['action_id'], row['parameters_json'])).rowcount
            if changed:
                cancelled.append(row['action_id'])
        store._connection.commit()
        if cancelled:
            store.audit('controller', 'cancel_undelivered_automation', agent + '/' + service,
                        {'action_ids': cancelled, 'reason': 'durable operator pause'})
    return cancelled
