"""Native application and host-firewall recipes with explicit configuration inputs."""

from __future__ import annotations

import base64
import hashlib
import ipaddress
import json
import re
import shlex
from pathlib import Path

from .network_setup import identifier, port
from .setup_recipes import _source, _linux_packages, _linux_service, _ps, DIGEST


def _fields(options, allowed):
    if set(options) - set(allowed):
        raise ValueError('Unknown application setup option')


def linux_nginx(options, root, *, metadata=None):
    _fields(options, {'name', 'listen_address', 'port', 'content', 'previous_content_sha256',
                      'previous_config_sha256', 'manager', 'cache_only', 'tls_certificate', 'tls_key',
                      'previous_certificate_sha256', 'previous_key_sha256'})
    name = identifier(options.get('name'), 'application name')
    address = str(ipaddress.ip_address(options.get('listen_address')))
    listener = '[' + address + ']' if ':' in address else address
    service_port = port(options.get('port'))
    content = _source(root, options.get('content'))
    directory = '/var/lib/sentinel-blue-apps/' + name
    config_path = '/etc/nginx/conf.d/sentinel-' + name + '.conf'
    tls = options.get('tls_certificate') is not None or options.get('tls_key') is not None
    generated = {directory + '/www/index.html': content}
    lines = ['server {', f'    listen {listener}:{service_port}' + (' ssl;' if tls else ';'),
             '    server_name _;', f'    root {directory}/www;', '    index index.html;',
             '    location / { try_files $uri $uri/ =404; }']
    previous = {directory + '/www/index.html': options.get('previous_content_sha256', 'absent'),
                config_path: options.get('previous_config_sha256', 'absent')}
    modes = {}
    access = {}
    if tls:
        certificate = _source(root, options.get('tls_certificate'))
        key = _source(root, options.get('tls_key'))
        certificate_path, key_path = directory + '/certificate.pem', directory + '/private-key.pem'
        generated.update({certificate_path: certificate, key_path: key})
        previous.update({certificate_path: options.get('previous_certificate_sha256', 'absent'),
                         key_path: options.get('previous_key_sha256', 'absent')})
        modes[key_path] = '0600'
        # The built-in nginx master reads its private key as root; workers do
        # not need world/group access to key material.
        access[key_path] = {'create_owner': 'root', 'create_group': 'root', 'readable_by': 'root'}
        lines += [f'    ssl_certificate {certificate_path};', f'    ssl_certificate_key {key_path};',
                  '    ssl_protocols TLSv1.2 TLSv1.3;']
    generated[config_path] = '\n'.join(lines + ['}', ''])
    service_options = {'service': 'nginx', 'enable': True, 'validate_argv': ['/usr/sbin/nginx', '-t'],
        'files': [{'path': path, 'source': {'path': 'generated', 'sha256': hashlib.sha256(value.encode()).hexdigest()},
                   'mode': modes.get(path, '0644'), 'previous_sha256': previous[path], **access.get(path, {})} for path, value in generated.items()]}
    if metadata is not None:
        metadata.update(service='nginx', files=[{
            'path': path, 'sha256': hashlib.sha256(value.encode()).hexdigest(),
            'mode': modes.get(path, '0644'), 'previous_sha256': previous[path], **access.get(path, {})
        } for path, value in generated.items()])
    check, apply, rollback = _linux_service(service_options, root, generated_sources=generated)
    package_check, package_apply, _ = _linux_packages({'packages': ['nginx'], 'manager': options.get('manager', 'apt'), 'cache_only': options.get('cache_only', True)})
    # Create only the application-specific tree; retain all existing sites/data.
    parents = ['/var/lib/sentinel-blue-apps', directory, directory + '/www', '/etc/nginx/conf.d']
    directories = "set -eu\ntest \"$(id -u)\" = 0\n"
    for path in parents:
        quoted = shlex.quote(path)
        directories += f"test ! -L {quoted}\nif [ ! -d {quoted} ]; then mkdir -m 0755 -- {quoted}; fi\ntest \"$(stat -c %u -- {quoted})\" = 0\nsb_mode=$(stat -c %a -- {quoted}); test \"$((0$sb_mode & 0022))\" = 0\n"
    install = 'if (\n' + package_check + '); then :; else\necho \"nginx prerequisites require a reviewed package mutation adapter\" >&2; exit 25\nfi\n'
    return package_check + check, install + directories + apply, rollback


def windows_firewall(options):
    _fields(options, {'name', 'allow'})
    name = identifier(options.get('name'), 'firewall policy name')
    allow = options.get('allow')
    if not isinstance(allow, list) or not 1 <= len(allow) <= 64:
        raise ValueError('Windows firewall requires 1 to 64 explicit allow rules')
    rows = []
    for index, row in enumerate(allow):
        if not isinstance(row, dict) or set(row) != {'source', 'protocol', 'port'} or row['protocol'] not in {'tcp', 'udp'}:
            raise ValueError('Firewall rules require source, protocol, and port')
        subnet = ipaddress.ip_network(row['source'], strict=True)
        source = str(subnet)
        forms = [source]
        if subnet.version == 4:
            forms.append(subnet.with_netmask)
        if subnet.prefixlen == subnet.max_prefixlen:
            forms.append(str(subnet.network_address))
        rows.append({'name': f'Sentinel-{name}-{index:03d}', 'source': source, 'source_forms': forms,
                     'protocol': row['protocol'].upper(), 'port': port(row['port'])})
    group = 'Sentinel Blue / ' + name
    # Literal records avoid PowerShell 5.1's nested JSON-array behavior. Accept
    # only equivalent CIDR, dotted-netmask, or single-host representations.
    records = []
    for row in rows:
        fields = '; '.join(key + '=' + _ps(row[key]) for key in ('name', 'source', 'protocol'))
        forms = ','.join(_ps(value) for value in row['source_forms'])
        records.append(' [PSCustomObject]@{' + fields + '; port=' + str(row['port']) + '; source_forms=@(' + forms + ')}')
    declaration = '$desired=@(\n' + '\n'.join(records) + '\n)\n'
    header = ("$ErrorActionPreference='Stop'\nImport-Module NetSecurity\n"
              f"$group={_ps(group)}\n" + declaration +
              "if (@(Get-NetFirewallProfile -PolicyStore ActiveStore | Where-Object {[string]$_.Enabled -ne 'True'}).Count -gt 0) {throw 'Disabled firewall profiles require review before declaring this policy ready'}\n"
              "function Test-SentinelRule($want,$rule) {\n"
              " if ($null -eq $rule -or @($rule).Count -ne 1) {return $false}\n"
              " $p=$rule | Get-NetFirewallPortFilter; $a=$rule | Get-NetFirewallAddressFilter\n"
              " $protocol=if ($want.protocol -eq 'TCP') {'6'} else {'17'}\n"
              " return ([string]$rule.Group -eq $group -and [string]$rule.Enabled -eq 'True' -and [string]$rule.Direction -eq 'Inbound' -and [string]$rule.Action -eq 'Allow' -and [string]$rule.Profile -eq 'Any' -and @($p.LocalPort).Count -eq 1 -and [string]$p.LocalPort -eq [string]$want.port -and ([string]$p.Protocol -eq $want.protocol -or [string]$p.Protocol -eq $protocol) -and @($a.RemoteAddress).Count -eq 1 -and [string]$a.RemoteAddress -in $want.source_forms)\n}\n"
              "$owned=@(Get-NetFirewallRule -PolicyStore PersistentStore | Where-Object {$_.Group -eq $group})\n"
              "if (@($owned | Where-Object {$_.Name -notin $desired.name}).Count -gt 0) {throw 'Existing firewall policy needs review'}\n")
    check = header + "foreach ($want in $desired) {if (-not (Test-SentinelRule $want (Get-NetFirewallRule -Name $want.name -PolicyStore ActiveStore -ErrorAction SilentlyContinue))) {exit 10}}\nexit 0\n"
    apply = header + "$created=@()\ntry {\nforeach ($want in $desired) {\n"
    apply += " $existing=Get-NetFirewallRule -Name $want.name -PolicyStore PersistentStore -ErrorAction SilentlyContinue\n"
    apply += " if ($existing) {if (-not (Test-SentinelRule $want $existing)) {throw 'Existing firewall rule differs from the declared policy'}} else {\n"
    apply += "  New-NetFirewallRule -Name $want.name -DisplayName $want.name -Group $group -Direction Inbound -Action Allow -Enabled True -Profile Any -Protocol $want.protocol -LocalPort $want.port -RemoteAddress $want.source -PolicyStore PersistentStore | Out-Null\n  $created += $want.name\n }\n}\n"
    apply += "foreach ($want in $desired) {if (-not (Test-SentinelRule $want (Get-NetFirewallRule -Name $want.name -PolicyStore ActiveStore))) {throw 'Effective firewall policy failed verification'}}\nexit 0\n} catch {foreach ($name in $created) {Remove-NetFirewallRule -Name $name -PolicyStore PersistentStore -ErrorAction SilentlyContinue}; exit 20}\n"
    return check, apply, None


def windows_iis(options, root):
    _fields(options, {'name', 'listen_address', 'port', 'content', 'certificate_thumbprint'})
    name = 'Sentinel-' + identifier(options.get('name'), 'application name')
    address = str(ipaddress.ip_address(options.get('listen_address')))
    if ':' in address:
        raise ValueError('IIS setup currently requires an IPv4 binding')
    service_port = port(options.get('port'))
    content = _source(root, options.get('content'))
    thumbprint = options.get('certificate_thumbprint')
    if thumbprint is not None and (not isinstance(thumbprint, str) or not re.fullmatch('[A-Fa-f0-9]{40}', thumbprint)):
        raise ValueError('IIS HTTPS requires an existing local-machine certificate thumbprint')
    protocol = 'https' if thumbprint else 'http'
    site_root = 'C:\\inetpub\\' + name
    payload = base64.b64encode(content.encode()).decode()
    expected = hashlib.sha256(content.encode()).hexdigest()
    header = "$ErrorActionPreference='Stop'\n"
    definitions = f"$name={_ps(name)}; $root={_ps(site_root)}; $binding={_ps(address + ':' + str(service_port) + ':')}\n"
    configuration_check = (
        "Import-Module WebAdministration\n" + definitions +
        "$site=Get-Website -Name $name -ErrorAction SilentlyContinue\n"
        f"if (-not $site -or [string]$site.physicalPath -ne $root -or [string]$site.applicationPool -ne $name -or @($site.bindings.Collection).Count -ne 1 -or [string]$site.bindings.Collection[0].bindingInformation -ne $binding -or [string]$site.bindings.Collection[0].protocol -ne '{protocol}') {{exit 10}}\n"
        f"if (-not (Test-Path -LiteralPath ($root+'\\index.html')) -or (Get-FileHash -LiteralPath ($root+'\\index.html') -Algorithm SHA256).Hash.ToLowerInvariant() -ne '{expected}') {{exit 10}}\n"
        "if (-not (Test-Path -LiteralPath ('IIS:\\AppPools\\'+$name))) {exit 10}\n")
    if thumbprint:
        configuration_check += "$hash=$site.bindings.Collection[0].certificateHash\nif ($hash -is [byte[]]) {$hash=[BitConverter]::ToString($hash) -replace '-',''}\n"
        configuration_check += f"if ([string]$hash -ine '{thumbprint}' -or [string]$site.bindings.Collection[0].certificateStoreName -ine 'My') {{exit 10}}\n"
    native_check = configuration_check + "if ([string]$site.state -ne 'Started' -or [string](Get-WebAppPoolState -Name $name).Value -ne 'Started' -or (Get-Service W3SVC).Status -ne 'Running' -or (Get-Service W3SVC).StartType -ne 'Automatic') {exit 10}\n"
    check = header + "Import-Module ServerManager\nif (@(Get-WindowsFeature Web-Server,Web-Scripting-Tools | Where-Object {-not $_.Installed}).Count -gt 0) {exit 10}\n" + native_check + 'exit 0\n'
    apply = header + definitions + "Import-Module ServerManager\n$features=@(Get-WindowsFeature Web-Server,Web-Scripting-Tools)\nif ($features.Count -ne 2 -or @($features | Where-Object { -not $_.Installed }).Count) {throw 'IIS prerequisites require a reviewed feature mutation adapter'}\nImport-Module WebAdministration\n"
    start = "Set-Service W3SVC -StartupType Automatic\nStart-Service W3SVC\nif ([string](Get-WebAppPoolState -Name $name).Value -ne 'Started') {Start-WebAppPool -Name $name}\nif ([string](Get-Website -Name $name).state -ne 'Started') {Start-Website -Name $name}\n"
    apply += "if (Get-Website -Name $name -ErrorAction SilentlyContinue) {\n" + configuration_check + start + native_check + "exit 0\n}\n"
    # Existing content/site/pool needs explicit review, never an implicit replacement.
    apply += "if (Test-Path -LiteralPath $root) {throw 'Existing application directory requires review'}\nif (Test-Path -LiteralPath ('IIS:\\AppPools\\'+$name)) {throw 'Existing application pool requires review'}\n"
    apply += "foreach ($site in Get-Website) {foreach ($entry in $site.bindings.Collection) {if ([string]$entry.protocol -eq '" + protocol + "' -and ([string]$entry.bindingInformation -eq $binding -or [string]$entry.bindingInformation -eq '*:" + str(service_port) + ":')) {throw 'Application binding is already in use'}}}\n"
    if thumbprint:
        apply += f"$certificate=Get-Item -LiteralPath 'Cert:\\LocalMachine\\My\\{thumbprint}'\nif (-not $certificate.HasPrivateKey -or $certificate.NotAfter -le (Get-Date)) {{throw 'Application certificate is unavailable or expired'}}\n"
    apply += "$directoryMade=$false; $poolMade=$false; $siteMade=$false\ntry {\nNew-Item -ItemType Directory -Path $root | Out-Null\n$directoryMade=$true\n"
    apply += f"[IO.File]::WriteAllBytes(($root+'\\index.html'),[Convert]::FromBase64String('{payload}'))\n"
    apply += "$acl=Get-Acl -LiteralPath $root\n$identity=[Security.Principal.SecurityIdentifier]::new('S-1-5-32-568')\n$rule=[Security.AccessControl.FileSystemAccessRule]::new($identity,'ReadAndExecute','ContainerInherit,ObjectInherit','None','Allow')\n$acl.AddAccessRule($rule); Set-Acl -LiteralPath $root -AclObject $acl\n"
    apply += "New-WebAppPool -Name $name | Out-Null\n$poolMade=$true\n"
    apply += f"New-Website -Name $name -IPAddress {_ps(address)} -Port {service_port} -PhysicalPath $root -ApplicationPool $name" + (' -Ssl' if thumbprint else '') + " | Out-Null\n$siteMade=$true\n"
    if thumbprint:
        apply += f"(Get-WebBinding -Name $name -Protocol https).AddSslCertificate('{thumbprint}','My')\n"
    apply += start
    # Verification is a throwing sub-script so failures reach the rollback catch.
    verify_throw = native_check.replace('exit 10', "throw 'Application verification failed'")
    apply += verify_throw + "exit 0\n} catch {\nif ($siteMade) {Remove-Website -Name $name}\nif ($poolMade) {Remove-WebAppPool -Name $name}\nif ($directoryMade) {Remove-Item -LiteralPath $root -Recurse -Force}\nexit 20\n}\n"
    return check, apply, None


def compile_application(recipe, options, root):
    if recipe == 'linux-nginx':
        return linux_nginx(options, root)
    if recipe == 'windows-firewall':
        return windows_firewall(options)
    if recipe == 'windows-iis':
        return windows_iis(options, root)
    raise ValueError('Unsupported application recipe')
