"""Reviewed port choices, never live port hopping or an authority override.

The planner emits literal ports. It never scans an undeclared host, reserves a
socket on the GUI machine for a remote host, rewrites a scoring profile, or
silently changes firewalls/management connections. A fresh listener snapshot is
advisory; it cannot prove that a port will remain free until setup executes.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any
import copy
import math
import time
from urllib.parse import urlparse

from .linux_service_catalog import CATALOG, CONFIGURE


@dataclass(frozen=True)
class PortField:
    key: str
    label: str
    default: int
    protocol: str = "tcp"
    role: str = "listener"
    primary: bool = True


# Only fields actually consumed by the corresponding configuration builders.
_FIELDS = {
    "nginx": (PortField("port", "Web listening port", 80),),
    "apache2": (PortField("port", "Web listening port", 80),),
    "openssh-server": (PortField("port", "SSH / SFTP port", 22),),
    "mariadb": (PortField("port", "Database port", 3306),),
    "postgresql": (PortField("port", "Database port", 5432),),
    "redis": (PortField("port", "Redis port", 6379),),
    "gunicorn": (PortField("port", "Application port", 8000),),
    "haproxy": (PortField("frontend_port", "Frontend listening port", 80),),
    "mosquitto": (PortField("listener_port", "MQTT listening port", 1883),),
    "unbound": (PortField("port", "DNS port (TCP and UDP)", 53, "both"),),
    "dnsmasq": (PortField("port", "DNS port (not DHCP)", 53, "both"),),
    "bind9": (PortField("port", "DNS port (TCP and UDP)", 53, "both"),),
    "chrony": (PortField("port", "NTP server port", 123, "udp"),),
    "postfix": (PortField("smtp_port", "SMTP listening port", 25),),
    "samba": (PortField("smb_port", "Direct SMB port", 445),
              PortField("netbios_port", "NetBIOS SMB port", 139, primary=False)),
    "vsftpd": (PortField("listen_port", "FTP control port", 21),
               PortField("pasv_min_port", "Passive range start", 40000, primary=False),
               PortField("pasv_max_port", "Passive range end", 40100, primary=False)),
    "rsyslog": (PortField("forward_port", "Destination log-server port (outbound)", 514,
                         "both", "destination"),),
}
_FIXED = {
    "isc-dhcp-server": "DHCP keeps its protocol ports 67/68. This adapter does not move DHCP listeners.",
    "nfs-server": "This adapter configures exports, not kernel NFS/RPC listener ports. Keep existing ports.",
}


def port_number(value: Any) -> int:
    if type(value) is not int or not 1 <= value <= 65535:
        raise ValueError("Enter a whole port number from 1 to 65535.")
    return value


def port_text(value: str) -> int:
    """UI conversion only; JSON builder inputs still require real integers."""
    if not isinstance(value, str) or not value.strip().isascii() or not value.strip().isdigit():
        raise ValueError("Enter a whole port number from 1 to 65535.")
    return port_number(int(value.strip()))


def fields_for(service_id: str, options: dict | None = None) -> tuple[PortField, ...]:
    if not isinstance(service_id, str) or service_id not in CATALOG:
        raise ValueError("Choose a service in the catalog.")
    options = {} if options is None else options
    if not isinstance(options, dict):
        raise ValueError("Service options must be an object.")
    if service_id == "dovecot":
        protocols = options.get("protocols", ["imap"])
        if not isinstance(protocols, list) or any(not isinstance(v, str) for v in protocols):
            raise ValueError("Dovecot protocols must be a list.")
        fields = []
        for protocol, plain, secure in (("imap", 143, 993), ("pop3", 110, 995), ("submission", 587, 465)):
            if protocol in protocols:
                fields.append(PortField(protocol + "_port", protocol.upper() + " port", plain,
                                        primary=not fields))
                if options.get("ssl_certificate_path") and options.get("ssl_key_path"):
                    name = {"imap": "imaps", "pop3": "pop3s", "submission": "submissions"}[protocol]
                    fields.append(PortField(name + "_port", name.upper() + " implicit-TLS port", secure,
                                            primary=False))
        return tuple(fields)
    fields = _FIELDS.get(service_id, ())
    if service_id in {"nginx", "apache2"} and (options.get("tls_certificate") or options.get("tls_certificate_path")):
        return (PortField("port", "HTTPS listening port", 443),)
    return fields


def capability(service_id: str, options: dict | None = None) -> dict:
    fields = fields_for(service_id, options)
    if fields:
        note = "Manual and automatic port choices are available; ordinary setup review is still required."
        if service_id == "rsyslog":
            note = "This pack forwards logs. This is the remote destination port, not a local listener."
        elif service_id == "openssh-server":
            note = "Changing SSH can disconnect management. Existing management/scoring ports remain protected."
        elif service_id == "bind9":
            note = "Custom DNS ports require a hash-pinned listener_config snapshot and compatible clients."
        elif service_id == "postfix":
            note = "Custom SMTP ports require a hash-pinned master_config snapshot; mail clients must agree."
        elif service_id == "dovecot":
            note = "Port fields follow the enabled protocols and supplied TLS prerequisites (Dovecot 2.3 layout)."
        return {"editable": True, "fields": [asdict(x) for x in fields], "reason": note}
    reason = _FIXED.get(service_id)
    if reason is None and CATALOG[service_id]["capability"] == CONFIGURE:
        reason = "This configuration has no editable TCP/UDP listener here. Unix sockets do not use a port number."
    if reason is None:
        reason = ("No TCP/UDP listener is configured by this adapter." if not CATALOG[service_id]["ports"]
                  else "Adopt-only in this release: the existing installation keeps its ports. A configuration adapter is required to change them.")
    return {"editable": False, "fields": [], "reason": reason}


def configured_ports(service_id: str, options: dict | None = None) -> dict[str, int]:
    options = {} if options is None else options
    return {f.key: port_number(options.get(f.key, f.default)) for f in fields_for(service_id, options)}


def endpoint_set(service_id: str, options: dict | None = None) -> set[tuple[str, int]]:
    options = {} if options is None else options
    values = configured_ports(service_id, options)
    endpoints = set()
    for f in fields_for(service_id, options):
        if f.role != "listener":
            continue
        if service_id == "vsftpd" and f.key.startswith("pasv_"):
            continue
        protocols = ("tcp", "udp") if f.protocol == "both" else (f.protocol,)
        endpoints.update((p, values[f.key]) for p in protocols)
    if service_id == "vsftpd":
        low, high = values["pasv_min_port"], values["pasv_max_port"]
        if high < low or high - low > 1023:
            raise ValueError("Use an ordered passive FTP range of at most 1024 ports.")
        if low <= values["listen_port"] <= high:
            raise ValueError("The FTP control port cannot be inside its passive transfer range.")
        endpoints.update(("tcp", p) for p in range(low, high + 1))
    return endpoints


def distinct_configured_endpoints(a: str, b: str, options: dict | None) -> bool:
    # Only explicitly configured products can override the catalog's generic
    # same-role conflict, and only port conflicts (not identity/data conflicts).
    if {a, b} not in ({"nginx", "apache2"}, {"bind9", "unbound"},
                     {"bind9", "dnsmasq"}, {"unbound", "dnsmasq"}):
        return False
    if not isinstance(options, dict) or a not in options or b not in options:
        return False
    try:
        ea, eb = endpoint_set(a, options[a]), endpoint_set(b, options[b])
        return bool(ea and eb) and ea.isdisjoint(eb)
    except ValueError:
        return False


def listener_observation(telemetry: Any, *, now: float | None = None) -> dict:
    """Bounded advisory data for this exact enrolled host; never an active scan."""
    now = time.time() if now is None else now
    if not isinstance(telemetry, dict):
        return {"complete": False, "listeners": [], "reason": "No host telemetry."}
    stamp = telemetry.get("observed_at")
    rows = telemetry.get("listeners")
    if (type(stamp) not in {int, float} or not math.isfinite(stamp)
            or not 0 <= now - stamp <= 90 or not isinstance(rows, list)):
        return {"complete": False, "listeners": [], "reason": "Listener telemetry is missing or stale."}
    normalized = []
    from .telemetry_diagnostics import recovery_blocking
    complete = len(rows) <= 256 and not recovery_blocking(telemetry) and not telemetry.get("collection_errors")
    for row in rows[:256]:
        if not isinstance(row, dict) or type(row.get("port")) is not int or not 1 <= row["port"] <= 65535:
            complete = False
            continue
        raw_protocol = row.get("protocol")
        if not isinstance(raw_protocol, str):
            complete = False
            continue
        protocol = raw_protocol.lower().removesuffix("6")
        if protocol not in {"tcp", "udp"}:
            complete = False
            continue
        normalized.append({"port": row["port"], "protocol": protocol})
    return {"observed_at": stamp, "complete": bool(complete), "listeners": normalized,
            "reason": "Advisory observed listeners; not a reservation or proof of future availability."}


def _occupied(observation: dict | None, *, now: float | None = None) -> tuple[set, bool]:
    if observation is None:
        return set(), False
    if not isinstance(observation, dict):
        raise ValueError("Port observation must belong to the selected host.")
    stamp = observation.get("observed_at")
    now = time.time() if now is None else now
    fresh = type(stamp) in {int, float} and math.isfinite(stamp) and 0 <= now - stamp <= 90
    rows = observation.get("listeners", [])
    if not isinstance(rows, list) or len(rows) > 256:
        return set(), False
    used = set()
    valid = True
    for row in rows:
        if (not isinstance(row, dict) or (not isinstance(row.get("protocol"), str) or row.get("protocol") not in {"tcp", "udp"})
                or type(row.get("port")) is not int or not 1 <= row["port"] <= 65535):
            valid = False
        else:
            used.add((row["protocol"], row["port"]))
    return (used if fresh else set()), fresh and valid and observation.get("complete") is True


def resolve_ports(service_id: str, options: dict, choices: dict, *,
                  required: dict | None = None, reserved: set | None = None,
                  observation: dict | None = None, allow_alternates: bool = False,
                  now: float | None = None, service_presence: str = "unknown") -> tuple[dict, dict]:
    """Resolve manual/automatic choices once, into literal digest-bound options.

    Automatic prefers required -> explicitly configured -> standard. Only a
    genuinely new, unconstrained port can use an alternate, only with explicit
    permission and fresh complete listener telemetry. Selection never claims to
    have changed a host or reserved a port.
    """
    if not isinstance(options, dict) or not isinstance(choices, dict):
        raise ValueError("Port options and choices must be objects.")
    if type(allow_alternates) is not bool:
        raise ValueError("Alternate-port permission must be a boolean.")
    if not isinstance(service_presence, str) or service_presence not in {"absent", "installed", "running", "unknown"}:
        raise ValueError("Service presence must come from the selected host's reviewed inventory.")
    fields = fields_for(service_id, options)
    keys = {f.key for f in fields}
    if not fields:
        raise ValueError(capability(service_id, options)["reason"])
    if set(choices) - keys:
        raise ValueError("A port choice does not belong to this service.")
    required = {} if required is None else required
    if not isinstance(required, dict) or set(required) - keys:
        raise ValueError("Required port constraints do not match this service's endpoints.")
    required = {k: port_number(v) for k, v in required.items()}
    reserved = set() if reserved is None else set(reserved)
    used, observed = _occupied(observation, now=now)
    result = copy.deepcopy(options)
    decisions = []
    for f in fields:
        choice = choices.get(f.key, {"mode": "auto"})
        if not isinstance(choice, dict) or set(choice) - {"mode", "port"} or not isinstance(choice.get("mode"), str) or choice.get("mode") not in {"auto", "manual"}:
            raise ValueError("Choose Automatic or Manual for each port.")
        current = port_number(options[f.key]) if f.key in options else None
        if choice["mode"] == "manual":
            value = port_number(choice.get("port"))
            reason = "Manual choice"
        else:
            if "port" in choice:
                raise ValueError("An automatic choice must not contain a hidden manual port.")
            value = required.get(f.key, current if current is not None else f.default)
            reason = "Required by reviewed event/management settings" if f.key in required else (
                "Retained existing configured value" if current is not None else "Standard service default")
        if f.key in required and value != required[f.key]:
            raise ValueError(f"{f.label} is required to stay on {required[f.key]}; review the event/management configuration first.")
        protocols = ("tcp", "udp") if f.protocol == "both" else (f.protocol,)
        conflict = f.role == "listener" and any((proto, value) in reserved for proto in protocols)
        occupied = f.role == "listener" and any((proto, value) in used for proto in protocols)
        movable = (choice["mode"] == "auto" and allow_alternates and f.key not in required
                   and service_presence == "absent" and current is None and f.primary and service_id not in {"openssh-server", "samba", "chrony", "bind9", "dnsmasq", "unbound", "postfix"})
        if (conflict or occupied) and movable:
            if not observed:
                raise ValueError("Automatic alternate selection requires fresh, complete listener telemetry from this host.")
            candidate = next((p for p in range(20000, 30000)
                              if all((proto, p) not in used | reserved for proto in protocols)), None)
            if candidate is None:
                raise ValueError("No candidate in the bounded alternate range; enter a reviewed manual port.")
            value, reason = candidate, "Candidate not listed as occupied in this host's recent telemetry"
            conflict = False
        if conflict:
            raise ValueError(f"{f.label} {value} conflicts with another selected service; choose distinct reviewed ports.")
        # A listener may legitimately belong to the service being configured.
        # Do not accuse or terminate it; display uncertainty for review instead.
        if occupied and not movable:
            reason += "; an existing listener uses this port—verify ownership before setup"
            if allow_alternates and service_presence != "absent":
                reason += "; service is existing or unverified, so no automatic migration is allowed"
        result[f.key] = value
        decisions.append({"key": f.key, "label": f.label, "mode": choice["mode"],
                          "port": value, "protocol": f.protocol, "role": f.role, "reason": reason})
    endpoint_set(service_id, result)  # range and duplicate checks
    values = [(f.protocol, result[f.key]) for f in fields if f.role == "listener" and not f.key.startswith("pasv_")]
    if len(values) != len(set(values)):
        raise ValueError("Different listeners of one service cannot use the same port.")
    if service_id == "vsftpd" and endpoint_set(service_id, result) & reserved:
        raise ValueError("The passive FTP range conflicts with another selected service.")
    return result, {"service_id": service_id, "decisions": decisions, "listener_data_current": observed, "service_presence": service_presence,
                    "warning": "Not applied. Review firewall, scorer/client, observer and management dependencies. No port is reserved."}


def manifest_constraints(service_id: str, options: dict, manifests, host_ids) -> dict:
    """Only exact native unit identities are matched; never guess application roles."""
    if not isinstance(manifests, (list, tuple)):
        raise ValueError("Reviewed manifests are missing.")
    unit = CATALOG[service_id]["unit"].removesuffix(".service")
    matches = [m for m in manifests if isinstance(m, dict) and m.get("host") in host_ids
               and isinstance(m.get("service_id"), str) and m["service_id"].removesuffix(".service") == unit]
    if len(matches) > 1:
        raise ValueError("More than one manifest claims this service on the selected host.")
    if not matches:
        return {}
    fields = [f for f in fields_for(service_id, options) if f.role == "listener" and not f.key.startswith("pasv_")]
    if not fields:
        return {}
    manifest = matches[0]
    value = port_number(manifest["port"])
    protocol = str(manifest.get("protocol", "")).lower()
    if service_id == "dovecot":
        key = protocol + "_port"
        selected = next((f for f in fields if f.key == key), None)
        if selected is None:
            candidates = [f for f in fields if options.get(f.key, f.default) == value]
            if len(candidates) != 1:
                raise ValueError("The mail manifest must identify which enabled IMAP/POP3/submission listener its port belongs to.")
            selected = candidates[0]
    elif service_id == "samba":
        candidates = [f for f in fields if f.default == value]
        selected = candidates[0] if len(candidates) == 1 else fields[0]
    else:
        selected = next((f for f in fields if f.primary), fields[0])
    return {selected.key: value}


def validate_manifest_ports(service_id: str, options: dict, manifest: dict, host: dict) -> None:
    """Keep the service and its approved checks aligned. Never rewrite authority."""
    fields = fields_for(service_id, options)
    if not fields:
        return
    # Legacy untouched configurations retain their old interpretation. The new
    # editor always emits explicit fields, so its changes are checked here.
    explicit = [f for f in fields if f.key in options and f.role == "listener"]
    if not explicit:
        return
    endpoints = endpoint_set(service_id, options)
    ports = {p for _, p in endpoints}
    constraints = manifest_constraints(service_id, options, [manifest], {manifest.get("host")})
    if any(port_number(options.get(key, next(f.default for f in fields if f.key == key))) != value
           for key, value in constraints.items()):
        raise ValueError("Selected service port differs from the approved manifest. Review the event port and its checks; Sentinel will not silently move scoring.")
    aliases = {host.get("address"), "127.0.0.1", "::1", "localhost"}
    for probe in manifest.get("expected_transactions", []):
        if not isinstance(probe, dict):
            raise ValueError("Malformed service transaction.")
        kind = probe.get("kind", "tcp")
        target = probe.get("host", probe.get("target"))
        port = probe.get("port")
        if kind in {"http", "https"}:
            parsed = urlparse(probe.get("target", ""))
            target, port = parsed.hostname, parsed.port or (443 if parsed.scheme == "https" else 80)
        elif port is None:
            port = {"dns": 53, "dns-update": 53, "ssh-login": 22, "smb": 445,
                    "ftp": 21, "smtp": 25, "mysql": 3306, "postgres": 5432, "tls": 443}.get(kind)
        if target in aliases and port is not None and port not in ports:
            raise ValueError("A local service check still uses a different port. Review its explicit mapping before setup.")
    if service_id == "openssh-server" and host.get("transport") == "ssh":
        if options.get("port", 22) != host.get("port", 22):
            raise ValueError("Changing the SSH management port requires a separately verified migration; retain the current management port.")
