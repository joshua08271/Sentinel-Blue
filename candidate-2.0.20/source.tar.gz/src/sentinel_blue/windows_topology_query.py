"""Fixed, read-only IP Helper topology query without CIM provider round trips."""

TOPOLOGY_QUERY = r'''
if (-not ('SentinelTopologySnapshot' -as [type])) {
Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
public static class SentinelTopologySnapshot {
  [StructLayout(LayoutKind.Explicit, Size=28)] struct Address {
    [FieldOffset(0)] public ushort Family;
    [FieldOffset(4)] public uint IPv4;
    [FieldOffset(8)] public uint A;
    [FieldOffset(12)] public uint B;
    [FieldOffset(16)] public uint C;
    [FieldOffset(20)] public uint D;
    [FieldOffset(24)] public uint Scope;
    public string Text() {
      if (Family==2) return new IPAddress(BitConverter.GetBytes(IPv4)).ToString();
      if (Family!=23) throw new InvalidOperationException("Unknown topology address family");
      byte[] bytes=new byte[16]; uint[] words={A,B,C,D};
      for(int i=0;i<4;i++) Buffer.BlockCopy(BitConverter.GetBytes(words[i]),0,bytes,i*4,4);
      return new IPAddress(bytes).ToString();
    }
  }
  [StructLayout(LayoutKind.Sequential)] struct Prefix { public Address Address; public byte Length; }
  [StructLayout(LayoutKind.Sequential)] struct Route {
    public ulong Luid; public uint Index; public Prefix Destination; public Address Next;
    public byte SiteLength; public uint Valid,Preferred,Metric,Protocol;
    public byte Loopback,Autoconfigure,Publish,Immortal; public uint Age,Origin;
  }
  [StructLayout(LayoutKind.Sequential)] struct Neighbor {
    public Address Address; public uint Index; public ulong Luid;
    [MarshalAs(UnmanagedType.ByValArray, SizeConst=32)] public byte[] Physical;
    public uint PhysicalLength,State; public byte Flags; public uint Reachability;
  }
  [StructLayout(LayoutKind.Sequential)] struct RouteTable { public uint Count; public Route First; }
  [StructLayout(LayoutKind.Sequential)] struct NeighborTable { public uint Count; public Neighbor First; }
  public class RouteItem { public string DestinationPrefix,NextHop,InterfaceAlias; public uint RouteMetric; }
  public class NeighborItem { public string IPAddress,LinkLayerAddress,InterfaceAlias,State; }
  public class ListenerItem { public string LocalAddress; public uint LocalPort,OwningProcess; }
  [DllImport("iphlpapi.dll")] static extern uint GetIpForwardTable2(ushort family,out IntPtr table);
  [DllImport("iphlpapi.dll")] static extern uint GetIpNetTable2(ushort family,out IntPtr table);
  [DllImport("iphlpapi.dll")] static extern void FreeMibTable(IntPtr table);
  [DllImport("iphlpapi.dll",CharSet=CharSet.Unicode)] static extern uint ConvertInterfaceLuidToAlias(ref ulong luid,StringBuilder name,UIntPtr size);
  [DllImport("iphlpapi.dll")] static extern uint GetExtendedTcpTable(IntPtr table,ref uint size,bool order,uint family,int kind,uint reserved);
  static int Count(IntPtr table) {
    int count=Marshal.ReadInt32(table);
    if(count<0 || count>16384) throw new InvalidOperationException("Topology inventory exceeded its row bound");
    return count;
  }
  static string Alias(ulong luid) {
    var name=new StringBuilder(257);
    uint error=ConvertInterfaceLuidToAlias(ref luid,name,(UIntPtr)257);
    if(error!=0) throw new Win32Exception((int)error);
    return name.ToString();
  }
  public static RouteItem[] Routes() {
    if(Marshal.SizeOf(typeof(Route))!=104) throw new InvalidOperationException("Unsupported native route layout");
    IntPtr table; uint error=GetIpForwardTable2(0,out table);
    if(error!=0) throw new Win32Exception((int)error);
    try {
      var result=new List<RouteItem>(); int count=Count(table);
      int offset=(int)Marshal.OffsetOf(typeof(RouteTable),"First");
      for(int i=0;i<count;i++) {
        var row=(Route)Marshal.PtrToStructure(IntPtr.Add(table,offset+i*104),typeof(Route));
        if(row.Destination.Length>(row.Destination.Address.Family==2?32:128)) throw new InvalidOperationException("Invalid route prefix");
        result.Add(new RouteItem {DestinationPrefix=row.Destination.Address.Text()+"/"+row.Destination.Length,
          NextHop=row.Next.Text(),InterfaceAlias=Alias(row.Luid),RouteMetric=row.Metric});
      }
      return result.ToArray();
    } finally { FreeMibTable(table); }
  }
  public static NeighborItem[] Neighbors() {
    if(Marshal.SizeOf(typeof(Neighbor))!=88) throw new InvalidOperationException("Unsupported native neighbor layout");
    IntPtr table; uint error=GetIpNetTable2(0,out table);
    if(error==232) return new NeighborItem[0]; // ERROR_NO_DATA, a complete empty table.
    if(error!=0) throw new Win32Exception((int)error);
    try {
      var result=new List<NeighborItem>(); int count=Count(table);
      int offset=(int)Marshal.OffsetOf(typeof(NeighborTable),"First");
      string[] states={"Unreachable","Incomplete","Probe","Delay","Stale","Reachable","Permanent"};
      for(int i=0;i<count;i++) {
        var row=(Neighbor)Marshal.PtrToStructure(IntPtr.Add(table,offset+i*88),typeof(Neighbor));
        if(row.PhysicalLength>32 || row.State>=states.Length) throw new InvalidOperationException("Invalid neighbor row");
        result.Add(new NeighborItem {IPAddress=row.Address.Text(),InterfaceAlias=Alias(row.Luid),State=states[row.State],
          LinkLayerAddress=BitConverter.ToString(row.Physical,0,(int)row.PhysicalLength)});
      }
      return result.ToArray();
    } finally { FreeMibTable(table); }
  }
  public static ListenerItem[] Listeners() {
    var result=new List<ListenerItem>();
    foreach(uint family in new uint[]{2,23}) {
      uint size=0; uint error=GetExtendedTcpTable(IntPtr.Zero,ref size,false,family,3,0);
      if(error!=0 && error!=122) throw new Win32Exception((int)error);
      bool complete=false;
      for(int attempt=0;attempt<3;attempt++) {
        if(size<4 || size>8388608) throw new InvalidOperationException("TCP inventory exceeded its byte bound");
        uint allocated=size; IntPtr table=Marshal.AllocHGlobal((int)allocated);
        try {
          error=GetExtendedTcpTable(table,ref size,false,family,3,0);
          if(error==122) continue; // Current table grew; bounded fresh retry.
          if(error!=0) throw new Win32Exception((int)error);
          int count=Count(table), width=family==2?24:56;
          if(4L+(long)count*width>allocated) throw new InvalidOperationException("TCP row layout exceeds its buffer");
          for(int i=0;i<count;i++) {
            IntPtr row=IntPtr.Add(table,4+i*width); string address; uint port,pid;
            if(family==2) {
              address=new IPAddress(BitConverter.GetBytes((uint)Marshal.ReadInt32(row,4))).ToString();
              port=(uint)Marshal.ReadInt32(row,8); pid=(uint)Marshal.ReadInt32(row,20);
            } else {
              byte[] bytes=new byte[16]; Marshal.Copy(row,bytes,0,16);
              address=new IPAddress(bytes,(uint)Marshal.ReadInt32(row,16)).ToString();
              port=(uint)Marshal.ReadInt32(row,20); pid=(uint)Marshal.ReadInt32(row,52);
            }
            result.Add(new ListenerItem {LocalAddress=address,LocalPort=((port&255)<<8)|((port>>8)&255),OwningProcess=pid});
          }
          complete=true; break;
        } finally { Marshal.FreeHGlobal(table); }
      }
      if(!complete) throw new InvalidOperationException("TCP inventory changed beyond its retry bound");
    }
    return result.ToArray();
  }
}
'@
}
$problems=@{}
try { $routes=@([SentinelTopologySnapshot]::Routes()) }
catch { $routes=@(); $problems['Routes']='Native route inventory failed' }
try { $neighbors=@([SentinelTopologySnapshot]::Neighbors()) }
catch { $neighbors=@(); $problems['Neighbors']='Native neighbor inventory failed' }
try { $listeners=@([SentinelTopologySnapshot]::Listeners()) }
catch { $listeners=@(); $problems['Listeners']='Native TCP inventory failed' }
[PSCustomObject]@{Schema=1;Routes=$routes;Neighbors=$neighbors;Listeners=$listeners;Errors=$problems} | ConvertTo-Json -Depth 4 -Compress
'''
