"""Live, authenticated governance checks for setup-redo dispatch and mutation boundaries.

These checks are not cancellation of an already admitted transaction: its
bounded verification and rollback must finish. Every subsequent admission and
apply boundary asks the controller again. Failed requests never grant authority.
"""
from __future__ import annotations

import time
from pathlib import Path

from .job_control import SetupPaused
from .state import read_private_json, write_private_json

CHECK_PATH = '/api/v1/setup/redo/check'
POLICY_MAX_AGE = 30
# Same-host ordering jitter only. Freshness is judged on this machine's clock
# (the local receipt time) whenever the snapshot came from a live client, so a
# GUI whose clock differs from the controller's is neither held nor admitted by
# comparing two machines' wall clocks.
POLICY_CLOCK_TOLERANCE = 5


def rollback_failed(result):
    if not isinstance(result, dict):
        return True
    errors = result.get('errors') or []
    if not isinstance(errors, list):
        return True
    return result.get('review_required') is True or result.get('rolled_back') is False and len(errors) > 1


def action_holds(actions, agent, service=None):
    """Every unresolved repair, not merely the most recent one or a timed window."""
    reasons = []
    for row in actions:
        if not isinstance(row, dict) or row.get('agent_id') != agent or row.get('action_type') != 'repair_service':
            continue
        params = row.get('parameters') or {}
        name = params.get('service') if isinstance(params, dict) else None
        if service is not None and name not in {None, service}:
            continue
        status = row.get('status')
        if status == 'outcome_unknown':
            reasons.append("a repair's outcome is unknown; reconcile it before setup redo")
        elif status in {'pending', 'queued', 'dispatched'}:
            reasons.append('a repair is in progress')
        elif status == 'failed' and rollback_failed(row.get('result') or {}):
            reasons.append('a repair did not roll back cleanly; review before any further change')
    return list(dict.fromkeys(reasons))


def snapshot_hold(snapshot, agent, service, now):
    """Advisory scheduler gate; the worker separately requires a signed live check."""
    controller = snapshot.get('controller') or {}
    governance = controller.get('governance') or {}
    if governance.get('emergency_stopped') is not False:
        return 'emergency stop or unavailable controller governance holds setup redo'
    if governance.get('autonomy_mode') in {'observe', 'unknown'}:
        return 'current governance holds setup redo'
    policy = controller.get('setup_redo_policy')
    if policy is not None:
        received = snapshot.get('client_received_at')
        if (not isinstance(policy, dict) or policy.get('complete') is not True
                or type(policy.get('observed_at')) not in {int, float}):
            return 'fresh complete redo-governance evidence is unavailable'
        age = now - (received if type(received) in {int, float} else policy['observed_at'])
        if not -POLICY_CLOCK_TOLERANCE <= age <= POLICY_MAX_AGE:
            return 'fresh complete redo-governance evidence is unavailable'
        if policy.get('profile_fingerprint') != governance.get('profile_fingerprint'):
            return 'redo-governance profile binding differs'
        rows = [row for row in policy.get('services', []) if isinstance(row, dict)
                and row.get('agent_id') == agent and row.get('service') == service]
        if len(rows) != 1:
            return 'service lacks unambiguous redo-governance evidence'
        if rows[0].get('holds'):
            return '; '.join(rows[0]['holds'])
        return None
    # Raw history is also checked, so older dashboards cannot erase a visible
    # hold. Production workers reject controllers without the live-check API.
    for grant in snapshot.get('change_grants', []):
        if not isinstance(grant, dict) or grant.get('agent_id') != agent or grant.get('revoked_at') is not None:
            continue
        expiry = grant.get('expires_at')
        if type(expiry) not in {int, float} or expiry >= now:
            # Setup can touch shared includes/directories beyond repair_files;
            # conservatively protect the host, never an unrelated host.
            return 'approved change grant holds setup redo on this host'
    reasons = action_holds(snapshot.get('actions', []), agent, service)
    return '; '.join(reasons) if reasons else None


def automatic_allowed(snapshot):
    controller = snapshot.get('controller') or {}
    governance = controller.get('governance') or {}
    if (governance.get('emergency_stopped') is not False
            or governance.get('autonomy_mode') != 'guarded-autonomous'):
        return False
    policy = controller.get('setup_redo_policy')
    return policy is None or policy.get('automatic_allowed') is True


def check(client, request):
    try:
        answer = client.request(CHECK_PATH, request)
    except Exception as exc:
        raise SetupPaused('Live redo governance could not be verified: ' + type(exc).__name__) from exc
    if (not isinstance(answer, dict) or answer.get('allowed') is not True
            or answer.get('profile_fingerprint') != request['profile_fingerprint']
            or answer.get('services') != request['services']
            or answer.get('automated') is not request['automated']):
        reason = answer.get('reason', 'no matching permission') if isinstance(answer, dict) else 'invalid response'
        raise SetupPaused('Setup redo held: ' + str(reason)[:300])
    return answer


def prepare_guard(client, directory, pairs, automated, profile):
    """Store worker connection material privately, never in job/report/display text."""
    request = {'profile_fingerprint': profile.fingerprint, 'services': pairs, 'automated': automated}
    check(client, request)
    from .credential_vault import private_directory
    guard = private_directory(directory)
    try:
        path = Path(directory) / 'redo-control.json'
        write_private_json(path, {'schema': 1, 'request': request,
            'connection': {'origin': client.origin, 'principal': client.principal,
                'epoch': client.epoch, 'token': client.token, 'ca_file': client.ca_file}})
    finally:
        if guard is not None:
            guard.close()
    return str(path)


class WorkerGuard:
    """Bound to exact profile and task scope, checked before each new mutation."""
    def __init__(self, job, profile, plan=None):
        from .desktop_control import DesktopClient
        reference = job.get('redo_guard_file')
        if not isinstance(reference, str) or not Path(reference).is_absolute():
            raise SetupPaused('Redo has no live controller authority; reconnect and review it again')
        payload = read_private_json(Path(reference), 65536)
        if (not isinstance(payload, dict) or set(payload) != {'schema', 'request', 'connection'}
                or payload.get('schema') != 1):
            raise SetupPaused('Redo controller authority is invalid')
        request = payload['request']
        if (not isinstance(request, dict) or request.get('profile_fingerprint') != profile.fingerprint
                or type(request.get('automated')) is not bool
                or request.get('services') != job.get('only_services')
                or not request.get('services')):
            raise SetupPaused('Redo controller authority does not match the reviewed job')
        self.request = dict(request)
        if plan is not None:
            from .setup import SetupRunner
            selected = SetupRunner(plan, profile)._chosen_tasks(job['only_services'])
            pairs = {tuple(pair) for pair in request['services']}
            governed = {(m['host'], m['service_id']) for m in profile.services}
            for task in plan['tasks']:
                if task['id'] not in selected:
                    continue
                host = plan['hosts'][task['host']]
                names = {task['host'], host.get('agent_id'), host.get('address')} - {None}
                matches = {(m['host'], m['service_id']) for m in profile.services if m['host'] in names}
                if not matches:
                    raise SetupPaused('A setup dependency has no controller-governed host/service scope')
                # 2.0.9: a task bound to one approved service is governed by that
                # service's holds. A host-level task (packages, shared files)
                # conservatively takes every governed service on its host.
                key = task.get('service_key')
                exact = (tuple(key) if isinstance(key, list) and len(key) == 2
                         and all(isinstance(x, str) for x in key) else None)
                pairs.update({exact} if exact in governed and exact in matches else matches)
            self.request['services'] = [list(pair) for pair in sorted(pairs)]
        connection = payload['connection']
        if not isinstance(connection, dict) or set(connection) != {'origin', 'principal', 'epoch', 'token', 'ca_file'}:
            raise SetupPaused('Redo connection material is invalid')
        self.client = DesktopClient(**connection)
        self.checkpoint()

    def checkpoint(self):
        check(self.client, self.request)
