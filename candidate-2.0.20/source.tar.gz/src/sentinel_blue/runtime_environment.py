"""Keep portable runtimes independent of system Python and user packages."""
from __future__ import annotations

import sys


def python_command():
    """Children retain the isolation selected by the offline launcher."""
    return [sys.executable, *(['-I', '-B'] if sys.flags.isolated else [])]


# Compile-time binding, isolated across parallel planners. Targets are never
# inferred from an untrusted environment variable or a remote host response.
import contextlib
from contextvars import ContextVar
from pathlib import PurePosixPath, Path
import re
import shlex

_TARGET_PYTHON = ContextVar("sentinel_target_python", default=None)


def validate_linux_python(value):
    """Accept a literal executable name or a reviewed absolute POSIX pathname."""
    if not isinstance(value, str) or not value or len(value) > 512:
        raise ValueError("Linux Python must be a reviewed executable name or absolute path")
    if value.startswith('/'):
        if not re.fullmatch(r"/[A-Za-z0-9_./ -]+", value) or '..' in PurePosixPath(value).parts or value.endswith('/'):
            raise ValueError("Linux Python path contains unsafe components")
    elif not re.fullmatch(r"[A-Za-z0-9_.+-]+", value):
        raise ValueError("Linux Python executable name is invalid")
    return value


def bundled_python():
    """Return this bundle's interpreter only when actually running inside it."""
    exe = Path(sys.executable).resolve()
    if (exe.parent.name == 'bin' and exe.parent.parent.name == 'runtime'
            and (exe.parent.parent.parent / 'offline-manifest.json').is_file()):
        return str(exe)
    return None


def host_python(host):
    configured = host.get('python')
    if configured is not None:
        return validate_linux_python(configured)
    if host.get('transport') == 'local':
        return validate_linux_python(bundled_python() or '/usr/bin/python3')
    # Remote Python is deliberately not borrowed from the controller's path.
    # The complete offline bundle must be copied to the target first.
    if bundled_python():
        raise ValueError("Offline remote setup requires host.python naming its pre-staged bundled interpreter")
    return '/usr/bin/python3'


@contextlib.contextmanager
def target_runtime(executable):
    token = _TARGET_PYTHON.set(validate_linux_python(executable) if executable else None)
    try:
        yield
    finally:
        _TARGET_PYTHON.reset(token)


def target_python():
    return _TARGET_PYTHON.get() or bundled_python() or '/usr/bin/python3'


def target_python_shell():
    return shlex.quote(target_python())
