"""Authenticated POSIX restore-point metadata replicas (2.0.7).

The readable manifest is a cache. Two HMAC-bound snapshots contain its complete
path/content/security metadata; one is outside the session when a blob mirror
is configured. The signing key is never recreated after authenticated state
exists. This detects damage, not compromise of the account that owns the key.
Legacy unsigned metadata is not silently signed or inferred from changed files.
"""
from __future__ import annotations

from contextlib import contextmanager
import hashlib
import hmac
import os
from pathlib import Path
import secrets
import stat

from .json_codec import canonical_json_bytes, strict_json_loads

MAX_BYTES = 32 * 1024 * 1024
ENVELOPE_BYTES = MAX_BYTES + 8192


class ManifestAuthority:
    def __init__(self, owner):
        self.owner = owner
        self.scope = hashlib.sha256(str(owner.root.absolute()).encode()).hexdigest()
        parent = owner.mirror.parent / 'restore-metadata' if owner.mirror is not None else owner.root / 'manifest-metadata'
        self.directory = parent / self.scope
        self.local = owner.root / 'manifest.auth.json'
        self.remote = self.directory / 'checkpoint.json'
        self.key_path = self.directory / 'key'
        self.floor = owner.root / 'manifest.floor.json'
        self.marker = owner.root / 'manifest.initialized'
        self.last = None
        self.legacy = False
        self.notices = []

    def _notice(self, message):
        if message not in self.notices and len(self.notices) < 16:
            self.notices.append(message)

    @contextmanager
    def _guard(self):
        import fcntl
        from .credential_vault import private_directory
        private_directory(self.directory.parent)
        private_directory(self.directory)
        lock_path = self.directory / 'writer.lock'
        parent = self.owner._open_parent_descriptor(lock_path)
        try:
            fd = os.open(lock_path.name, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW | os.O_NONBLOCK,
                         0o600, dir_fd=parent)
        finally:
            os.close(parent)
        try:
            info = os.fstat(fd)
            if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1
                    or info.st_uid != os.geteuid() or info.st_mode & 0o077):
                raise ValueError('restore manifest lock is not private')
            # Never freeze monitoring behind another process. A busy audit is
            # reported; mutation callers retry through the ordinary action flow.
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            yield
        finally:
            os.close(fd)

    def _read(self, path, limit=ENVELOPE_BYTES):
        parent = self.owner._open_parent_descriptor(path)
        try:
            try:
                fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
            except FileNotFoundError:
                return None
        finally:
            os.close(parent)
        try:
            info = os.fstat(fd)
            if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size > limit
                    or info.st_uid != os.geteuid() or info.st_mode & 0o077):
                raise ValueError('restore manifest state has unsafe ownership, permissions, size or links: ' + path.name)
            with os.fdopen(fd, 'rb', closefd=False) as stream:
                data = stream.read(limit + 1)
            after = os.fstat(fd)
            fields = ('st_dev', 'st_ino', 'st_size', 'st_mode', 'st_uid', 'st_gid', 'st_nlink',
                      'st_mtime_ns', 'st_ctime_ns')
            if len(data) > limit or any(getattr(info, f) != getattr(after, f) for f in fields):
                raise ValueError('restore manifest state changed while being read')
            return data
        finally:
            os.close(fd)

    def _encode(self, body, key):
        raw = canonical_json_bytes(body, max_bytes=ENVELOPE_BYTES)
        return canonical_json_bytes({'body': body, 'mac': hmac.digest(key, raw, 'sha256').hex()},
                                    max_bytes=ENVELOPE_BYTES)

    def _decode(self, data, key, *, floor=False):
        value = strict_json_loads(data, max_bytes=ENVELOPE_BYTES)
        if not isinstance(value, dict) or set(value) != {'body', 'mac'}:
            raise ValueError('invalid restore manifest envelope')
        body = value['body']
        if (not isinstance(body, dict) or body.get('schema') != 1 or body.get('scope') != self.scope
                or type(body.get('generation')) is not int or body['generation'] < 1
                or not isinstance(value['mac'], str)):
            raise ValueError('invalid restore manifest scope or generation')
        expected_fields = {'schema', 'scope', 'generation', 'digest'} | (set() if floor else {'manifest'})
        if set(body) != expected_fields:
            raise ValueError('invalid restore manifest fields')
        mac = hmac.digest(key, canonical_json_bytes(body, max_bytes=ENVELOPE_BYTES), 'sha256').hex()
        if not hmac.compare_digest(value['mac'], mac):
            raise ValueError('restore manifest authentication failed')
        if not isinstance(body['digest'], str) or len(body['digest']) != 64:
            raise ValueError('invalid restore manifest digest')
        if not floor:
            if not isinstance(body['manifest'], dict):
                raise ValueError('restore manifest is not an object')
            raw = canonical_json_bytes(body['manifest'], max_bytes=MAX_BYTES)
            if hashlib.sha256(raw).hexdigest() != body['digest']:
                raise ValueError('restore manifest content digest differs')
        return body

    def _state(self):
        raw = {p: self._read(p) for p in (self.local, self.remote, self.floor)}
        key = self._read(self.key_path, 32)
        marker = self._read(self.marker, 256)
        if key is None:
            if marker is not None or any(value is not None for value in raw.values()):
                raise ValueError('restore manifest authentication key is missing; restoration is held')
            return None, None, raw
        if len(key) != 32:
            raise ValueError('restore manifest authentication key is corrupt; restoration is held')
        candidates = []
        for p in (self.local, self.remote):
            if raw[p] is not None:
                try:
                    candidates.append(self._decode(raw[p], key))
                except (ValueError, TypeError, UnicodeError):
                    self._notice('damaged authenticated manifest copy: ' + str(p))
        if not candidates:
            if marker is not None or any(value is not None for value in raw.values()):
                raise ValueError('no authenticated restore manifest copy is usable; restoration is held')
            return key, None, raw
        latest = max(candidates, key=lambda item: item['generation'])
        if any(c['generation'] == latest['generation'] and c['digest'] != latest['digest'] for c in candidates):
            raise ValueError('conflicting authenticated restore manifests; restoration is held')
        if raw[self.floor] is not None:
            try:
                floor = self._decode(raw[self.floor], key, floor=True)
            except (ValueError, TypeError, UnicodeError) as exc:
                # A corrupt high-water mark could conceal loss of the newest
                # generation. Do not downgrade based only on an older replica.
                raise ValueError('restore manifest generation checkpoint is corrupt; restoration is held') from exc
            if (floor['generation'] > latest['generation'] or
                    floor['generation'] == latest['generation'] and floor['digest'] != latest['digest']):
                raise ValueError('newest approved restore manifest is unavailable; restoration is held')
        return key, latest, raw

    def _save(self, path, data):
        # These are private restoration authority/evidence, not managed service
        # configuration. Like state under owner.root, retain them on withdrawal
        # and never copy the signing key into a configuration-action snapshot.
        from .mutation_tracking import suppressed
        with suppressed():
            self.owner._atomic_write(path, data, 0o600)

    def _preserve(self, raw):
        if raw is None:
            return
        name = 'manifest-damaged-' + hashlib.sha256(raw).hexdigest()
        target = self.owner.evidence / name
        if target.exists():
            return
        # Keep bounded exact evidence. If full, retain the damaged file in place.
        if sum(1 for _ in self.owner.evidence.glob('manifest-damaged-*')) >= 8:
            raise ValueError('restore manifest damage evidence limit reached; review required')
        self._save(target, raw)

    def read(self, *, for_capture=False):
        with self._guard():
            key, latest, raw = self._state()
            primary = self._read(self.owner.manifest_path, MAX_BYTES)
            if latest is None:
                self.last = None
                if primary is None:
                    previous = any(any(p.iterdir()) for p in (self.owner.blobs, self.owner.transactions))
                    if previous and not for_capture:
                        raise ValueError('restore manifest is missing for existing restore data; restoration is held')
                    self.legacy = False
                    return {}
                try:
                    manifest = strict_json_loads(primary, max_bytes=MAX_BYTES)
                except (ValueError, UnicodeError) as exc:
                    raise ValueError('restore-point manifest is corrupt; refusing to overwrite it') from exc
                if not isinstance(manifest, dict):
                    raise ValueError('restore-point manifest is not an object; refusing to overwrite it')
                if not manifest and not for_capture and any(
                        any(p.iterdir()) for p in (self.owner.blobs, self.owner.transactions)):
                    raise ValueError('empty restore manifest contradicts existing restore data; restoration is held')
                self.legacy = bool(manifest)
                if self.legacy:
                    self._notice('legacy manifest lacks authenticated metadata redundancy; explicitly review and recapture all its files')
                return manifest
            self.last = (latest['generation'], latest['digest'])
            self.legacy = False
            desired = canonical_json_bytes(latest['manifest'], max_bytes=MAX_BYTES)
            try:
                equivalent = primary is not None and canonical_json_bytes(
                    strict_json_loads(primary, max_bytes=MAX_BYTES), max_bytes=MAX_BYTES) == desired
            except (ValueError, UnicodeError):
                equivalent = False
            if not equivalent:
                self._preserve(primary)
                self._save(self.owner.manifest_path, desired)
                self._notice('restore manifest rebuilt from authenticated metadata: ' + str(self.owner.manifest_path))
            envelope = self._encode(latest, key)
            for p in (self.local, self.remote):
                if raw[p] != envelope:
                    self._preserve(raw[p])
                    self._save(p, envelope)
                    self._notice('authenticated restore manifest copy rebuilt: ' + str(p))
            floor = self._encode({k: v for k, v in latest.items() if k != 'manifest'}, key)
            if raw[self.floor] != floor:
                self._save(self.floor, floor)
            if not self.marker.exists():
                self._save(self.marker, self.scope.encode())
            return latest['manifest']

    def write(self, manifest, *, captured):
        data = canonical_json_bytes(manifest, max_bytes=MAX_BYTES)
        with self._guard():
            key, latest, _raw = self._state()
            current = (latest['generation'], latest['digest']) if latest is not None else None
            if current != self.last:
                raise ValueError('restore manifest changed during capture; retry the approved capture')
            if self.legacy and not set(manifest).issubset(set(captured)):
                # Older entries were not part of this approval. Preserve legacy
                # behavior, but never sign them merely because they are on disk.
                self._save(self.owner.manifest_path, data)
                self._notice('legacy metadata not mirrored: a complete approved recapture is required')
                return
            if not manifest and latest is None:
                self._save(self.owner.manifest_path, data)
                return
            if key is None:
                key = secrets.token_bytes(32)
                self._save(self.key_path, key)
            generation = latest['generation'] + 1 if latest is not None else 1
            body = {'schema': 1, 'scope': self.scope, 'generation': generation,
                    'digest': hashlib.sha256(data).hexdigest(), 'manifest': manifest}
            envelope = self._encode(body, key)
            # The first signed publication commits this explicitly approved
            # capture. The read path completes interrupted later publications.
            self._save(self.local, envelope)
            self._save(self.remote, envelope)
            self._save(self.floor, self._encode({k: v for k, v in body.items() if k != 'manifest'}, key))
            self._save(self.marker, self.scope.encode())
            self._save(self.owner.manifest_path, data)
            self.last = (generation, body['digest'])
            self.legacy = False
