"""Private local recovery controls and explicit offline authorization."""
import json
from pathlib import Path
import sys
import threading
import uuid


class RecoveryControls:
    def _recovery(self):
        tab = self.tabs['Recovery']
        self.recovery_review = None
        self.recovery_busy = False
        self.recovery_configuration = None
        self.ttk.Label(tab, text='Controller recovery & offline continuity', font=('Segoe UI', 16, 'bold')).pack(anchor='w')
        self.ttk.Label(tab, text='Restore a verified backup while the controller is stopped. Restored changes remain paused until agent journals and unresolved actions are reviewed.', wraplength=940).pack(anchor='w', pady=8)
        row = self.ttk.Frame(tab)
        row.pack(fill='x')
        self.ttk.Button(row, text='Review controller recovery', command=self.review_controller_recovery).pack(side='left')
        self.recovery_execute = self.ttk.Button(row, text='Restore reviewed backup', command=self.execute_controller_recovery, state='disabled')
        self.recovery_execute.pack(side='left', padx=8)
        self.ttk.Button(row, text='Enable controller at boot', command=self.enable_controller_boot).pack(side='left')
        offline = self.ttk.Frame(tab)
        offline.pack(fill='x', pady=12)
        self.offline_fields = {}
        for label, initial, width in [('Agent', '', 18), ('Services', '', 22), ('Minutes', '15', 6), ('Attempts', '3', 6), ('Cooldown seconds', '300', 8)]:
            self.ttk.Label(offline, text=label).pack(side='left', padx=3)
            variable = self.tk.StringVar(value=initial)
            self.offline_fields[label] = variable
            self.ttk.Entry(offline, textvariable=variable, width=width).pack(side='left')
        self.ttk.Button(tab, text='Authorize bounded offline service recovery', command=self.authorize_offline).pack(anchor='w')
        self.ttk.Label(tab, text='Only approved service restarts are supported. Authorization expires within one hour. No new baseline or shell command is permitted.', wraplength=940).pack(anchor='w', pady=6)
        self.ttk.Button(tab, text='Pause across inventory through SSH / WinRM', command=self.pause_disconnected_network).pack(anchor='w')
        if sys.platform.startswith('linux'):
            redo = self.ttk.Frame(tab)
            redo.pack(fill='x', pady=(10, 0))
            self.ttk.Button(redo, text='Redo approved setup', command=self.redo_local_setup).pack(side='left')
            self.ttk.Button(redo, text='Reconcile interrupted setup', command=self.reconcile_setup).pack(side='left', padx=8)
            # Wrapped to the room left beside both buttons (2.0.5 added the
            # second one and the old width clipped the end of this sentence).
            self.ttk.Label(redo, text='Redo runs the setup you approved (for this VM, or a network inventory) again '
                           'for the services repair cannot fix; nothing else runs and nothing new is authorized. '
                           'Reconcile closes an interrupted setup only on proof of what it left.', wraplength=600,
                           justify='left').pack(side='left', padx=10)
            self.ttk.Button(tab, text='Verify repaired redo holds…', command=self.verify_redo_recovery).pack(anchor='w', pady=4)
            self.redo_status = self.tk.StringVar(value='')
            self.ttk.Label(tab, textvariable=self.redo_status, wraplength=940, justify='left').pack(anchor='w', pady=(4, 0))
        self.recovery_status_text = self.tk.StringVar(value='Connect to see controller authority and journal reconciliation.')
        self.ttk.Label(tab, textvariable=self.recovery_status_text, wraplength=940).pack(anchor='w', pady=8)
        self.recovery_text = self.tk.Text(tab, height=12, wrap='word', bg='#172636', fg='#edf3f8', relief='flat')
        self.recovery_text.pack(fill='both', expand=True)
        self.recovery_text.configure(state='disabled')

    def _recovery_display(self, value):
        self.recovery_text.configure(state='normal')
        self.recovery_text.delete('1.0', 'end')
        self.recovery_text.insert('1.0', value if isinstance(value, str) else json.dumps(value, indent=2))
        self.recovery_text.configure(state='disabled')

    def _recovery_work(self, operation, complete):
        if self.recovery_busy:
            self.footer.set('Recovery operation is already running.')
            return
        generation = self.generation
        self.recovery_busy = True
        def failed(value):
            self.recovery_busy = False
            self._recovery_display('Held for review: ' + value[1])
        def done(value):
            self.recovery_busy = False
            complete(value)
        def work():
            try:
                self.events.put(('done', (generation, done, True), operation()))
            except Exception as exc:
                self.events.put(('error', (generation, failed, True), (type(exc).__name__, str(exc)[:700])))
        threading.Thread(target=work, name='sentinel-controller-recovery', daemon=False).start()

    def review_controller_recovery(self):
        config = self.filedialog.askopenfilename(parent=self.root, title='Select the private controller configuration')
        if not config:
            return
        capsule = self.filedialog.askdirectory(parent=self.root, title='Select the saved .sbrecovery folder')
        if not capsule:
            return
        self.recovery_review = None
        self.recovery_execute.configure(state='disabled')
        def review():
            from .controller_boot import arguments_from_config
            from .controller_restore import verify_capsule
            from .event_profile import load_event_profile
            from .recovery import load_recovery_key
            from .controller import ControllerDatabaseLock
            _, args = arguments_from_config(config)
            profile = load_event_profile(args.event_profile)
            key = load_recovery_key(args.recovery_key_file)
            with ControllerDatabaseLock(args.database):
                info, verified = verify_capsule(capsule, args.recovery_anchor, key,
                                               release_sha256=profile.release['sha256'], profile_fingerprint=profile.fingerprint)
            receipt = Path(args.database).parent / ('restore-' + uuid.uuid4().hex)
            return args, capsule, profile, receipt, {'backup_verified': True, 'database': args.database,
                        'receipt_directory': str(receipt), 'saved_ledger_head': info['ledger_head'],
                        'saved_withdrawal_pause': info['ledger_paused'],
                        'uncertain_actions': info['uncertain_ledger_actions'],
                        'next': 'Restore refuses newer valid state and keeps automation paused.'}
        def ready(value):
            self.recovery_review = value
            self._recovery_display(value[-1])
            self.recovery_execute.configure(state='normal')
        self._recovery_work(review, ready)

    def execute_controller_recovery(self):
        if not self.recovery_review:
            return
        args, capsule, profile, receipt, _ = self.recovery_review
        self.recovery_execute.configure(state='disabled')
        def restore():
            from .controller import ControllerDatabaseLock
            from .controller_restore import restore_capsule
            from .recovery import load_recovery_key
            from .mutation_ledger import default_directory
            with ControllerDatabaseLock(args.database):
                return restore_capsule(capsule, args.database, args.recovery_anchor,
                         load_recovery_key(args.recovery_key_file), release_sha256=profile.release['sha256'],
                         profile_fingerprint=profile.fingerprint, ledger_directory=default_directory(),
                         receipt_directory=receipt, recovery_key_file=args.recovery_key_file)
        self._recovery_work(restore, self._recovery_display)

    def enable_controller_boot(self):
        config = self.filedialog.askopenfilename(parent=self.root, title='Select the exact private controller configuration')
        if config:
            from .controller_boot import install
            self._recovery_work(lambda: install(config, Path(sys.argv[0]).absolute()), self._recovery_display)

    def authorize_offline(self):
        if self.client is None:
            self.footer.set('Connect to the controller to authorize offline work.')
            return
        try:
            payload = {'agent_id': self.offline_fields['Agent'].get().strip(),
                       'services': [x.strip() for x in self.offline_fields['Services'].get().split(',') if x.strip()],
                       'duration_seconds': int(self.offline_fields['Minutes'].get()) * 60,
                       'max_attempts': int(self.offline_fields['Attempts'].get()),
                       'cooldown_seconds': int(self.offline_fields['Cooldown seconds'].get())}
        except ValueError:
            self.footer.set('Enter whole numbers for time and attempt limits.')
            return
        client = self.client
        self._recovery_work(lambda: client.request('/api/v1/continuity/authorize', payload), self._recovery_display)

    def pause_disconnected_network(self):
        inventory, profile = self.inventory_path.get(), self.profile_path.get()
        if not inventory or not profile:
            self.footer.set('Select the approved inventory and profile in Setup first.')
            return
        from .continuity_controls import network_pause
        directory = self.directory / 'independent-pauses' / uuid.uuid4().hex
        range_mode = self.range_mode.get()
        self._recovery_work(lambda: network_pause(inventory, profile, directory, range_deployment=range_mode), self._recovery_display)

    def render_recovery(self, snapshot):
        controller = snapshot.get('controller', {})
        continuity = controller.get('continuity', {})
        rows = continuity.get('agents', [])
        waiting = [x['agent_id'] for x in rows if not x.get('reconciled')]
        descriptions = [x['agent_id'] + ': ' + x.get('connection_status', 'awaiting connection') + '; last report: ' + (x.get('held') or x.get('agent_status', 'awaiting journal')) for x in rows]
        text = ('All enrolled agents reconciled.' if continuity.get('network_reconciled') else
                'Changing authority held pending agent journals: ' + ', '.join(waiting))
        text += '\nRestore: ' + controller.get('restore', {}).get('status', 'not-restored')
        self.recovery_status_text.set(text + '\n' + '\n'.join(descriptions[:12]))
        workspace = self._redo_workspace()
        if getattr(self, 'redo_status', None) is not None:
            if workspace is None:
                self.redo_status.set('')
            else:
                from .setup_redo import status_text
                try:
                    self.redo_status.set(status_text(workspace, snapshot))
                except (OSError, ValueError, KeyError) as exc:
                    self.redo_status.set('Setup redo: ' + str(exc)[:200])
        if hasattr(self, 'tick_network_redo'):
            self.tick_network_redo(snapshot)

    def _redo_workspace(self):
        """This VM's approved local setup, else the approved network setup (2.0.6)."""
        local = getattr(self, 'local_workspace', None)
        if local is not None:
            return Path(local['directory'])
        return getattr(self, 'network_redo_workspace', None)

    def reconcile_setup(self):
        """Close uncertain setups on this VM that provably changed nothing."""
        import os
        from .setup_reconcile import report_text
        if os.geteuid() != 0:
            self.note('Reconciling setup requires administrator access.'); return
        if self.job_path is not None or self.setup_starting:
            self.note('Wait for the current setup job to finish.'); return
        def work():
            from .setup_linux_transaction import reconcile_uncertain
            return reconcile_uncertain()
        def done(report):
            self._recovery_display(report_text(report))
            self.note('Setup reconciliation: ' + (f"{sum(r['result'] == 'reconciled' for r in report)} reconciled, "
                      f"{sum(r['result'] != 'reconciled' for r in report)} held" if report else 'nothing to reconcile'))
        def failed(exc):
            self.note('Setup reconciliation did not run: ' + str(exc)[:250])
        self.submit(work, done, failed)

    def verify_redo_recovery(self):
        """Explicit acknowledgment after an operator has reconciled/finished recovery."""
        client = self.client
        if client is None:
            self.note('Connect to the controller first.'); return
        if not self.messagebox.askyesno('Verify repaired redo holds',
                'First finish or reconcile the interrupted repair on the target and verify its files and service. '
                'Ask the controller to acknowledge recovered services from fresh baseline-matching evidence? '
                'Nothing is overwritten, no baseline is changed, and unresolved or unhealthy services remain held.', parent=self.root):
            return
        def work():
            snapshot = client.dashboard()
            rows = (snapshot.get('controller', {}).get('setup_redo_policy') or {}).get('services', [])
            report = []
            for row in rows:
                if any('roll back' in str(reason) for reason in row.get('holds', [])):
                    # 2.0.9: one refused service does not hide the others' answers.
                    try:
                        result = client.request(f"/api/v1/agents/{row['agent_id']}/services/recovered",
                            {'service': row['service'], 'source': 'operator_verified_recovery'})
                    except Exception as exc:
                        result = {'closed': 0, 'reason': 'not verified: ' + str(exc)[:200]}
                    report.append({'agent': row['agent_id'], 'service': row['service'], **result})
            return report or 'No incomplete-rollback redo holds were reported.'
        self._recovery_work(work, self._recovery_display)

    def redo_local_setup(self):
        """Operator-started redo of the approved local setup."""
        from .setup_redo import manual_redo
        workspace = self._redo_workspace()
        snapshot = getattr(self, 'snapshot', None)
        if workspace is None or self.client is None or not snapshot:
            self.note('Reconnect the local session, or connect to the controller, first; a redo runs the setup approved for this VM or network.'); return
        if self.job_path is not None or self.setup_starting:
            self.note('Wait for the current setup job to finish.'); return
        if not self.messagebox.askyesno('Redo approved setup',
                'Run the setup you approved again for the services that are not healthy? It is checked against '
                'the approved plan before anything starts. Healthy and held services are left alone; '
                'excluded services are reported. Shared-dependency safety checks still apply.', parent=self.root):
            return
        directory = Path(workspace)
        def done(entry):
            message = 'Setup redo started for ' + ', '.join(entry['units']) + '. Progress: ' + entry['job']
            excluded = entry.get('excluded') or {}
            if excluded:
                message += '. Excluded: ' + ', '.join(sorted(excluded))
                self._recovery_display("\n".join(
                    [message, 'Excluded services (not selected for redo):'] +
                    [f'  {unit}: {reason}' for unit, reason in sorted(excluded.items())]))
            self.note(message)
        def failed(exc):
            self.note('Setup redo not started: ' + str(exc)[:250])
        self.submit(lambda: manual_redo(directory, snapshot, client=self.client), done, failed)
