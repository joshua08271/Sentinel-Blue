"""Command line interface for all Sentinel Blue components."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import __version__


def parser(*, include_labs: bool = False) -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(prog="sentinel-blue")
    root.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    subcommands = root.add_subparsers(dest="command", required=True)
    offline = subcommands.add_parser("offline-check", help="check bundled dependencies locally without network access")
    offline.add_argument("--desktop", action="store_true", help="also open and close a native test window")
    from .security_workflow import add_cli
    add_cli(subcommands)
    from .recording import add_cli as add_recording_cli
    add_recording_cli(subcommands)
    from .observer import add_cli as add_observer_cli
    add_observer_cli(subcommands)

    desktop = subcommands.add_parser("desktop", help="open the desktop status, verification, and credential window")
    desktop.add_argument("--config", help="private desktop connection settings")
    desktop.add_argument("--foreground", action="store_true", help=argparse.SUPPRESS)
    desktop_worker = subcommands.add_parser("desktop-worker", help=argparse.SUPPRESS)
    desktop_worker.add_argument("--job", required=True)
    if sys.platform.startswith('linux'):
        isolated = subcommands.add_parser('isolated-role-session', help=argparse.SUPPRESS)
        isolated.add_argument('--config', required=True)
        local_session = subcommands.add_parser('linux-desktop-session', help=argparse.SUPPRESS)
        local_session.add_argument('--session', required=True)
        local_session.add_argument('--launch-id', help=argparse.SUPPRESS)

    controller = subcommands.add_parser("controller", help="run the controller and dashboard")
    controller.add_argument("--bind", default="127.0.0.1")
    controller.add_argument(
        "--supervise", action="store_true",
        help="supervise the pinned controller process with bounded crash and stalled-loop recovery",
    )
    controller.add_argument("--supervisor-child", action="store_true", help=argparse.SUPPRESS)
    controller.add_argument("--port", type=int, default=8765)
    controller_token = controller.add_mutually_exclusive_group(required=True)
    controller_token.add_argument("--token")
    controller_token.add_argument("--token-file")
    controller.add_argument("--database", default="sentinel-blue.db")
    controller.add_argument("--recording-directory", help="private local range recordings; defaults beside the database")
    controller.add_argument(
        "--event-profile", required=True,
        help="private approved default-deny event profile/inventory JSON",
    )
    controller.add_argument(
        "--range-deployment",
        action="store_true",
        help=(
            "explicitly permit a checksum-pinned disposable range profile; "
            "never valid for a live competition profile"
        ),
    )
    controller.add_argument(
        "--model",
        help="external risk model; requires an exact release.model_sha256 profile binding",
    )
    controller.add_argument(
        "--adaptive-model-output",
        help="train a regression-gated candidate model when the controller stops",
    )
    controller.add_argument(
        "--campaign-id",
        help="bounded evidence/training campaign identifier; generated once per database if omitted",
    )
    controller.add_argument(
        "--authorized-network",
        action="append",
        default=[],
        help="authorized CIDR for passive topology filtering; repeat as needed",
    )
    controller.add_argument("--probe-config", help="JSON file containing relay-side service probes")
    controller.add_argument("--probe-interval", type=float, default=15.0)
    controller.add_argument("--observer-config", help="private approved external observers and reporting keys")
    controller.add_argument(
        "--enrollment-window",
        type=float,
        default=3600.0,
        help="seconds after startup in which new agents may enroll",
    )
    controller.add_argument("--max-agents", type=int, default=512)
    controller.add_argument("--stale-after", type=float, default=90.0)
    controller.add_argument("--maintenance-interval", type=float, default=30.0)
    controller.add_argument("--retention-days", type=int, default=30)
    from .history_storage import add_cli as add_history_cli
    add_history_cli(controller, subcommands)
    controller.add_argument(
        "--backup-directory",
        help="private recovery bundle directory; defaults to a private sibling of the recovery anchor",
    )
    controller.add_argument("--backup-interval", type=float, default=900.0)
    controller.add_argument(
        "--backup-keep", type=int, default=96,
        help="maximum authenticated controller bundles to retain (minimum: 2)",
    )
    controller.add_argument(
        "--recovery-key-file",
        required=True,
        help="private raw recovery signing key; never copied into a backup",
    )
    controller.add_argument(
        "--recovery-anchor",
        required=True,
        help="protected signed recovery anchor stored outside backup bundles",
    )
    operator_token = controller.add_mutually_exclusive_group(required=True)
    operator_token.add_argument(
        "--operator-token",
        help="independent operator secret; prefer --operator-token-file",
    )
    operator_token.add_argument(
        "--operator-token-file",
        help="existing private file containing an independent operator secret",
    )
    controller.add_argument(
        "--operator-principal-id",
        required=True,
        help="bounded blue-team identity recorded for every signed operator request",
    )
    controller.add_argument(
        "--operator-credential-epoch",
        type=int,
        default=2,
        help=(
            "operator key epoch; increment by exactly one with every key rotation "
            "(authenticated-recovery deployments begin at 2)"
        ),
    )
    controller.add_argument(
        "--auto-restore",
        action="store_true",
        help="automatically queue approved integrity restoration when no change grant is active",
    )
    controller.add_argument(
        "--auto-recover-services",
        action="store_true",
        help="recover explicitly authorized stopped services after two fresh observations and guarded checks",
    )
    controller.add_argument(
        "--restore-confirmations",
        type=int,
        default=2,
        choices=range(1, 6),
        metavar="1-5",
        help="matching integrity observations required before automatic restoration (default: 2)",
    )
    controller.add_argument(
        "--allow-unprobed-restoration",
        action="store_true",
        help="permit automatic restoration without a mapped service/scoring probe (not recommended)",
    )
    controller.add_argument("--tls-cert")
    controller.add_argument("--tls-key")
    controller.add_argument(
        "--tls-ca-file",
        help="public controller trust anchor pinned by release.controller_ca_sha256",
    )
    controller.add_argument("--syslog-bind", help="enable agentless UDP syslog receiver on this address")
    controller.add_argument("--syslog-port", type=int, default=5514)
    controller.add_argument("--log-level", default="INFO")

    agent = subcommands.add_parser("agent", help="run a host telemetry agent")
    agent.add_argument("--controller", required=True)
    agent.add_argument("--recording-directory", help="private local range recordings; defaults in agent state")
    agent.add_argument(
        "--event-profile", required=True,
        help="private approved default-deny event profile/inventory JSON",
    )
    agent.add_argument(
        "--range-deployment",
        action="store_true",
        help=(
            "explicitly permit a checksum-pinned disposable range profile; "
            "never valid for a live competition profile"
        ),
    )
    agent_token = agent.add_mutually_exclusive_group()
    agent_token.add_argument("--token", help="bootstrap token; prefer --token-file")
    agent_token.add_argument("--token-file", help="one-time bootstrap token file deleted after enrollment")
    agent.add_argument(
        "--re-enroll",
        dest="reenroll",
        action="store_true",
        help=(
            "explicitly replace a revoked agent credential using a fresh "
            "ticket; never falls back automatically after authentication failure"
        ),
    )
    agent.add_argument("--agent-id")
    agent.add_argument("--interval", type=float, default=15.0)
    agent.add_argument(
        "--change-watch-interval",
        type=float,
        default=1.0,
        help="portable protected-file fingerprint fallback interval in seconds",
    )
    agent.add_argument("--state-dir", default=str(Path.home() / ".sentinel-blue"))
    agent.add_argument("--allow-containment", action="store_true")
    agent.add_argument(
        "--allow-service-recovery", action="store_true",
        help="permit profile-authorized native service recovery independently of session containment",
    )
    agent.add_argument(
        "--allow-restoration",
        action="store_true",
        help="permit live restoration from agent-local approved restore points",
    )
    agent.add_argument("--probe-config", help="JSON file containing scope-limited service probes")
    agent.add_argument("--ca-file", help="CA certificate for an HTTPS controller")
    agent.add_argument(
        "--expected-package-sha256",
        help="refuse controller actions if the deployed zipapp no longer matches this digest",
    )
    agent.add_argument("--spool-limit", type=int, default=256)
    agent.add_argument("--quarantine-ttl", type=float, default=300.0)
    agent.add_argument(
        "--authorized-network",
        action="append",
        default=[],
        help="authorized CIDR for probes; repeat as needed",
    )
    agent.add_argument("--once", action="store_true")
    agent.add_argument("--log-level", default="INFO")
    agent.add_argument(
        "--log-file",
        help="absolute rotating log path directly inside --state-dir",
    )
    agent.add_argument("--log-max-bytes", type=int, default=5 * 1024 * 1024)
    agent.add_argument("--log-backups", type=int, default=3)

    if include_labs:
        simulator = subcommands.add_parser("simulate", help="train and evaluate in the local simulated range")
        simulator.add_argument("--epochs", type=int, default=250)
        simulator.add_argument("--model-output", default="sentinel-blue-model.json")
        simulator.add_argument("--json", action="store_true")

    launcher = subcommands.add_parser("launcher", help="produce an authorized deployment plan")
    launcher.add_argument("--inventory", required=True)
    launcher.add_argument(
        "--event-profile",
        help="private approved profile JSON; defaults to --inventory when embedded",
    )
    launcher.add_argument("--package-url")
    launcher.add_argument("--package")
    launcher.add_argument("--checksum")
    launcher.add_argument("--controller")
    launcher.add_argument(
        "--ca-file",
        help="public controller trust anchor pinned by release.controller_ca_sha256",
    )
    launcher.add_argument(
        "--range-deployment",
        action="store_true",
        help="authorize only an exact checksum-bound disposable range profile",
    )
    launcher_token = launcher.add_mutually_exclusive_group()
    launcher_token.add_argument("--token")
    launcher_token.add_argument("--token-file")
    launcher.add_argument(
        "--preflight",
        action="store_true",
        help="run non-mutating package, configuration, and local transport readiness checks",
    )
    launcher.add_argument("--execute", action="store_true")
    launcher.add_argument("--yes", action="store_true", help="confirm execution against the inventory")
    launcher.add_argument("--max-parallel-hosts", type=int, default=4)
    launcher.add_argument("--budget-seconds", type=float, default=180, help="shared deadline including all uploads and enrollment")

    setup = subcommands.add_parser("setup", help="plan or execute initial service provisioning within a fixed deadline")
    setup.add_argument("--inventory", required=True)
    setup.add_argument("--event-profile")
    setup.add_argument("--plan-out", help="write the full private plan for review")
    setup.add_argument("--execute", action="store_true")
    setup.add_argument("--approve-plan", help="exact SHA-256 printed by the planning command")
    setup.add_argument("--state-dir", help="private persistent setup journal directory")
    setup.add_argument("--resume", action="store_true", help="resume without resetting the original deadline")
    setup.add_argument("--started-at", type=float, help="optional original event/setup start as a Unix timestamp; cannot be in the future")
    setup.add_argument("--range-deployment", action="store_true")
    setup.add_argument("--output", help="write a sanitized setup readiness report")

    opening = subcommands.add_parser("opening", help="time complete scored-service and defender setup from the first upload")
    opening.add_argument("--catalog", choices=["ncae", "gddc-ualbany"], help="print the exact screenshot score columns")
    opening.add_argument("--inventory")
    opening.add_argument("--event-profile")
    opening.add_argument("--runtime", help="exact approved pyz to upload to the targets")
    opening.add_argument("--plan-out")
    opening.add_argument("--execute", action="store_true")
    opening.add_argument("--approve-plan")
    opening.add_argument("--state-dir")
    opening.add_argument("--started-at", type=float, help="original upload start, including transfer to this controller")
    opening.add_argument("--range-deployment", action="store_true")
    opening.add_argument("--output")
    opening.add_argument("--security-vault-dir", help="operator-side encrypted credential vault for the optional security stage")

    learner = subcommands.add_parser("learn", help="train a regression-gated candidate from recorded decisions")
    learner.add_argument("--database", required=True)
    learner.add_argument("--base-model")
    learner.add_argument("--output", required=True)
    learner.add_argument("--campaign-id", required=True)
    learner.add_argument("--profile-id", required=True)
    learner.add_argument("--profile-fingerprint", required=True)
    learner.add_argument("--release-sha256", required=True)
    learner.add_argument("--agent-version", required=True)
    learner.add_argument("--model-fingerprint", required=True)

    if include_labs:
        range_command = subcommands.add_parser(
            "range", help="run an end-to-end disposable defensive range campaign"
        )
        range_command.add_argument("--runs", type=int, default=200)
        range_command.add_argument("--json", action="store_true")

        restoration_lab = subcommands.add_parser(
            "restoration-lab",
            help="run the disposable restoration and rollback attack campaign",
        )
        restoration_lab.add_argument("--runs", type=int, default=120)
        restoration_lab.add_argument("--json", action="store_true")

        policy_lab = subcommands.add_parser(
            "policy-lab",
            help="run the disposable competition-legality adversarial policy campaign",
        )
        policy_lab.add_argument("--runs", type=int, default=200)
        policy_lab.add_argument("--json", action="store_true")

        native_lab = subcommands.add_parser(
            "native-lab",
            help="run the owner-gated native campaign on a disposable GitHub-hosted runner",
        )
        native_lab.add_argument(
            "--output",
            help=(
                "report path; must resolve to "
                "GITHUB_WORKSPACE/native-live-report.json"
            ),
        )
        native_lab.add_argument("--json", action="store_true")

        windows_native_lab = subcommands.add_parser(
            "windows-native-lab",
            help=(
                "run the owner-gated Windows-native campaign on a disposable "
                "GitHub-hosted runner"
            ),
        )
        windows_native_lab.add_argument(
            "--output",
            help=(
                "report path; must resolve to "
                "GITHUB_WORKSPACE/windows-native-live-report.json"
            ),
        )
        windows_native_lab.add_argument("--json", action="store_true")

    diagnose = subcommands.add_parser("diagnose", help="explain service failures and dependency repair order from saved evidence")
    diagnose.add_argument("--event-profile", required=True)
    diagnose.add_argument("--telemetry", required=True)
    diagnose.add_argument("--baseline")
    diagnose.add_argument("--baseline-approved", action="store_true", help="operator assertion for this read-only report; grants no execution permission")
    diagnose.add_argument("--output", help="private JSON report; defaults to stdout")

    setup_reconcile = subcommands.add_parser(
        "setup-reconcile", help="close uncertain setup transactions that provably changed nothing (root)")
    setup_reconcile.add_argument("--json", action="store_true")
    release = subcommands.add_parser(
        "withdraw-release",
        help="after reviewing an executed withdrawal, allow Sentinel on this host again (root)")
    release.add_argument("--operation-id", help="the withdrawal's operation id, from its report; omit to see it")
    release.add_argument("--json", action="store_true")

    repair_grant = subcommands.add_parser(
        "repair-grant", help="write a NEW event profile that grants every service a reviewed repair policy")
    repair_grant.add_argument("--event-profile", required=True, help="the reviewed profile; never modified")
    repair_grant.add_argument("--output", required=True, help="new profile file to write; must not exist")
    repair_grant.add_argument("--automatic", action="store_true",
                              help="also grant automatic repair (used only in guarded-autonomous mode)")
    repair_grant.add_argument("--service", action="append", default=[],
                              help="limit to host/service_id or service_id; repeatable")
    repair_grant.add_argument("--windows-host", action="append", default=[],
                              help="host that runs Windows (startup restored to auto, no unmask); repeatable")
    repair_grant.add_argument("--enable-capabilities", action="store_true",
                              help="turn on the capabilities repair needs if the profile has them off")
    repair_grant.add_argument("--json", action="store_true")

    doctor = subcommands.add_parser("doctor", help="run local readiness and package diagnostics")
    doctor.add_argument("--acceptance-context", help="current reviewed options/root and observed product versions; not a receipt file")
    doctor.add_argument("--database")
    doctor.add_argument("--state-dir", default=str(Path.home() / ".sentinel-blue"))
    doctor.add_argument("--json", action="store_true")

    recovery_init = subcommands.add_parser(
        "recovery-init",
        help="offline initialize a controller database and protected anchor",
    )
    recovery_init.add_argument("--database", required=True)
    recovery_init.add_argument("--recovery-key-file", required=True)
    recovery_init.add_argument("--recovery-anchor", required=True)
    recovery_init.add_argument(
        "--enrollment-window",
        type=float,
        default=3600.0,
        help="initial enrollment window for a genuinely new database",
    )

    recovery_status = subcommands.add_parser(
        "recovery-status",
        help="offline verify live database freshness against its anchor",
    )
    recovery_status.add_argument("--database", required=True)
    recovery_status.add_argument("--recovery-key-file", required=True)
    recovery_status.add_argument("--recovery-anchor", required=True)

    recovery_backup = subcommands.add_parser(
        "recovery-backup",
        help="offline create and anchor an authenticated backup bundle",
    )
    recovery_backup.add_argument("--database", required=True)
    recovery_backup.add_argument("--output-directory", required=True)
    recovery_backup.add_argument("--recovery-key-file", required=True)
    recovery_backup.add_argument("--recovery-anchor", required=True)
    recovery_backup.add_argument("--event-profile", help="create a complete private recovery capsule")
    recovery_backup.add_argument("--ledger-directory")
    recovery_backup.add_argument("--controller-config", help="private controller_arguments JSON for complete input material")

    recovery_verify = subcommands.add_parser(
        "recovery-verify",
        help="authenticate and inspect a backup without restoring it",
    )
    recovery_verify.add_argument("--bundle", required=True)
    recovery_verify.add_argument("--recovery-key-file", required=True)
    recovery_verify.add_argument("--recovery-anchor", required=True)

    receipts = subcommands.add_parser("recovery-receipt", help="verify private recovery and rejection receipt chains")
    receipts.add_argument("--receipt-directory", required=True)
    receipts.add_argument("--recovery-key-file", required=True)
    restore = subcommands.add_parser("recovery-restore", help="offline authenticate, restore and hold a complete controller capsule")
    for option in ("database", "bundle", "recovery-key-file", "recovery-anchor", "event-profile", "expected-package-sha256", "receipt-directory"):
        restore.add_argument("--" + option, required=True)
    restore.add_argument("--ledger-directory")
    for command in ("continuity-pause", "continuity-resume"):
        local_control = subcommands.add_parser(command, help="local independent-management automation latch; never clears Withdraw")
        local_control.add_argument("--ledger-directory")
        local_control.add_argument("--reason", required=True)
    for command in ("controller-boot-install", "controller-boot-run"):
        boot = subcommands.add_parser(command, help="install or run an exact private controller boot configuration")
        boot.add_argument("--config", required=True)
        boot.add_argument("--runtime", required=True)
        if command == 'controller-boot-run':
            boot.add_argument('--ledger-directory',
                              help='exact private ledger pinned during boot installation; '
                                   'omitted only by registrations written before that pinning existed')
    # Removing a registration needs neither the config nor the runtime: the
    # ledger owns the record of what was installed, and only what this ledger
    # installed can be removed.
    boot_status = subcommands.add_parser(
        "controller-boot-status",
        help="report what is registered to start this controller at boot")
    boot_status.add_argument("--ledger-directory")
    boot_remove = subcommands.add_parser(
        "controller-boot-uninstall",
        help="remove this host's controller boot registration without withdrawing the host")
    boot_remove.add_argument("--ledger-directory")
    boot_remove.add_argument(
        "--action-id", help="exact recorded registration to remove, when more than one exists")

    if include_labs:
        selftest = subcommands.add_parser(
            "self-test", help="run the packaged disposable range and recovery certification"
        )
        selftest.add_argument("--scenarios", type=int, default=300)
        selftest.add_argument("--fuzz-iterations", type=int, default=1500)
        selftest.add_argument("--load-events", type=int, default=750)
        selftest.add_argument(
            "--full",
            action="store_true",
            help="use the maximum 5,000 scenarios, 50,000 hostile inputs, and 50,000 load events",
        )
        selftest.add_argument("--json", action="store_true")

    from .withdrawal import add_cli as add_withdrawal_cli
    add_withdrawal_cli(subcommands)
    return root


def main(*, include_labs: bool = False) -> None:
    # No arguments means the desktop window, which is how a double-click arrives.
    # That launch has no terminal, so a failure printed to stderr is invisible and
    # the program simply appears to do nothing.
    implicit_desktop = not sys.argv[1:] or sys.argv[1:2] == ['desktop']
    try:
        return _main(include_labs=include_labs)
    except (ValueError, KeyError) as exc:
        # Reviewed configuration problems are the operator's normal failure mode.
        # Print the reason; a traceback hid it and looked like a crash. Unexpected
        # errors keep their traceback.
        if implicit_desktop:
            from .launch_report import report
            report(str(exc))
        else:
            print(f'sentinel-blue: {exc}', file=sys.stderr)
        raise SystemExit(2) from None
    except (RuntimeError, ImportError, OSError) as exc:
        if not implicit_desktop:
            raise
        # The traceback is still printed, so nothing is hidden from a terminal
        # launch; the dialog is what reaches a double-click.
        import traceback
        from .launch_report import report
        report(str(exc), detail=traceback.format_exc())
        raise SystemExit(2) from None


def _main(*, include_labs: bool = False) -> None:
    args = parser(include_labs=include_labs).parse_args(sys.argv[1:] or ["desktop"])
    if args.command in {"controller", "agent"}:
        from .config_validation import validate_bound_transport
        from .event_profile import load_event_profile

        event_profile = load_event_profile(args.event_profile)
        event_profile.require_runtime_ready(
            range_deployment=bool(getattr(args, "range_deployment", False))
        )
        from .control_plane import validate_startup
        validate_startup(event_profile, args.command, args)
        if args.command == "controller":
            validate_bound_transport(
                event_profile,
                role="controller",
                ca_file=args.tls_ca_file,
                tls_cert=args.tls_cert,
                tls_key=args.tls_key,
                syslog_bind=args.syslog_bind,
            )
        else:
            validate_bound_transport(
                event_profile,
                role="agent",
                controller=args.controller,
                ca_file=args.ca_file,
            )
    if args.command in {'controller', 'agent', 'desktop', 'desktop-worker', 'setup', 'opening', 'launcher', 'security', 'security-guest'}:
        from .mutation_tracking import enable, register_process, assert_admission
        enable()
        if args.command in {'controller', 'agent', 'desktop-worker'}:
            assert_admission()
            role = 'controller-supervisor' if getattr(args, 'supervise', False) else args.command
            register_process(role)
    if args.command == "offline-check":
        from .offline import run
    elif args.command in {"withdraw", "withdraw-guest"}:
        from .withdrawal import run
    elif args.command == "desktop":
        from .desktop import run
    elif args.command == "desktop-worker":
        from .desktop_jobs import run
    elif args.command == 'isolated-role-session':
        from .management_role import run
    elif args.command == 'linux-desktop-session':
        from .linux_workspace import run_session as run
    elif args.command == "controller":
        if args.supervise:
            from .controller_supervisor import run
        else:
            from .controller import run
    elif args.command == "agent":
        from .agent import run
    elif args.command == "observer":
        from .observer import run
    elif args.command == "simulate":
        from .simulator import run
    elif args.command == "learn":
        from .learning import run
    elif args.command == "range":
        from .range_lab import run
    elif args.command == "restoration-lab":
        from .restoration_lab import run
    elif args.command == "policy-lab":
        from .policy_lab import run
    elif args.command == "native-lab":
        from .native_range_lab import run
    elif args.command == "windows-native-lab":
        from .windows_native_range_lab import run
    elif args.command == "diagnose":
        from .recovery_reasoning import run
    elif args.command == "repair-grant":
        from .repair_grants import run
    elif args.command == "setup-reconcile":
        from .setup_reconcile import run
    elif args.command == "withdraw-release":
        from .withdrawal_release import run
    elif args.command == "doctor":
        from .diagnostics import run
    elif args.command == "opening":
        from .opening import run

    elif args.command == "setup":
        from .setup import run
    elif args.command in {"security", "security-guest"}:
        from .security_workflow import run
    elif args.command == "recording-review":
        from .recording_review import run
    elif args.command in {"recording-inspect", "recording-export"}:
        from .recording import run
    elif args.command in {"history-verify", "history-compact"}:
        from .history_storage import run as run_history
        raise SystemExit(run_history(args))
    elif args.command.startswith("controller-boot-"):
        from .controller_boot import run
    elif args.command in {"continuity-pause", "continuity-resume"}:
        from .continuity_controls import run
    elif args.command.startswith("recovery-"):
        from .recovery_ops import run
    elif args.command == "self-test":
        from .selftest import run
    else:
        from .launcher import run
    recorder = None
    if args.command in {"controller", "agent", "desktop", "desktop-worker", "setup", "opening"} and not getattr(args, "supervise", False):
        from .recording import initialize
        recorder = initialize(args)
    try:
        exit_code = run(args)
    finally:
        if recorder is not None:
            recorder.close()
    if isinstance(exit_code, int) and exit_code != 0:
        raise SystemExit(exit_code)


if __name__ == "__main__":
    main()
