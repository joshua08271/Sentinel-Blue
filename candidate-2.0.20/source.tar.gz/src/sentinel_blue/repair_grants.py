"""Give every service in an event profile the repair a guided setup gets.

A guided local setup grants each of its services a repair automatically. A
competition network is described by an operator-written event profile instead,
and its services often have none: they were written before repair existed, or
by someone who only thought about restarts. This makes the same grant for them,
from what the profile already says about each service, and writes it to a NEW
profile file for review. The original is never changed.

What a service is allowed to restore is decided conservatively, per file:

* a file another service on the same host also lists is **shared** — restoring
  it for one would change the other, so it stays alert-only;
* a file inside one of the service's own `required_data` paths is **data** —
  scored content is never rolled back to the baseline;
* account, sudo, PAM, SSH-key, /proc, /sys, /dev and /boot paths are **host
  identity** — monitored, never a service repair's to overwrite, and listed as
  the policy's `host_files` so a change to them does not hold the repair;
* at most 16 files per service, the repair engine's limit; the rest stay
  alert-only and are named in the report.

Nothing about the event's own decisions is widened silently. Capabilities the
profile turns off stay off unless `enable_capabilities` is passed, and automatic
repair is only granted when asked for.
"""

from __future__ import annotations

import copy
from typing import Any, Iterable

MAX_RESTORE_FILES = 16
VALIDATION_SECONDS = 30
REPAIR_CAPABILITIES = ("file_restoration", "structured_rollback", "in_place_repair")
APPROVAL_ACTIONS = ("restart_service", "capture_restore_point", "repair_service", "rollback_service_repair")
AUTOMATIC_ACTIONS = ("validate_service", "capture_restore_point", "restart_service", "repair_service")
MAX_ACTIONS = 16


def _refusal(path: str) -> str | None:
    from .custom_services import _file
    try:
        _file(path)
    except ValueError as exc:
        return str(exc)
    return None


def _under(path: str, roots: Iterable[str]) -> bool:
    for root in roots:
        root = root.rstrip("/")
        if root and (path == root or path.startswith(root + "/")):
            return True
    return False


def _add(actions: list[str], names: Iterable[str]) -> list[str]:
    result = list(actions)
    for name in names:
        if name not in result:
            result.append(name)
    if len(result) > MAX_ACTIONS:
        raise ValueError("a service may list at most 16 actions; remove unused ones before granting repair")
    return result


def restorable_files(manifest: dict[str, Any], others: list[dict[str, Any]]) -> tuple[list[str], list[dict[str, str]]]:
    """The files this service's repair may restore, and why each other file may not."""
    shared: dict[str, str] = {}
    for other in others:
        if other is manifest or other.get("host") != manifest.get("host"):
            continue
        for path in other.get("required_files", []):
            shared.setdefault(path, other.get("service_id", "another service"))
    keep, withheld = [], []
    for path in sorted(dict.fromkeys(manifest.get("required_files", []))):
        if path in shared:
            withheld.append({"path": path, "reason": f"shared with {shared[path]}"})
        elif _under(path, manifest.get("required_data", [])):
            withheld.append({"path": path, "reason": "service data, never rolled back"})
        elif (reason := _refusal(path)) is not None:
            withheld.append({"path": path, "reason": reason})
        elif len(keep) >= MAX_RESTORE_FILES:
            withheld.append({"path": path, "reason": "beyond the 16-file repair limit"})
        else:
            keep.append(path)
    return keep, withheld


def grant_repair(raw: dict[str, Any], *, automatic: bool = False, windows_hosts: Iterable[str] = (),
                 only: Iterable[str] = (), enable_capabilities: bool = False) -> tuple[dict[str, Any], dict[str, Any]]:
    """Return a new profile with repair granted, and a report of every decision.

    `only` limits the grant to named services (`host/service_id` or just the
    service id). Services that already carry a repair_policy keep it unchanged.
    """
    from .event_profile import EventProfile
    from .service_repair import local_probe
    EventProfile.from_dict(raw)                   # the input must already be a valid profile
    result = copy.deepcopy(raw)
    windows = set(windows_hosts)
    wanted = set(only)
    services = result.get("services", [])
    report: dict[str, Any] = {"granted": [], "kept": [], "skipped": [], "warnings": []}
    for manifest in services:
        name = f"{manifest['host']}/{manifest['service_id']}"
        if wanted and name not in wanted and manifest["service_id"] not in wanted:
            continue
        if "repair_policy" in manifest:
            report["kept"].append({"service": name, "reason": "already has a repair policy"})
            continue
        if not manifest.get("required_files"):
            report["skipped"].append({"service": name, "reason": "lists no required_files; repair needs the "
                                      "service's approved configuration files. Add them, then grant again."})
            continue
        files, withheld = restorable_files(manifest, services)
        policy: dict[str, Any] = {"restore_files": files, "restart_unhealthy": True,
                                  "validation_timeout_seconds": VALIDATION_SECONDS}
        if manifest["host"] in windows:
            policy["restore_start_mode"] = "auto"
        else:
            policy.update(restore_start_mode="enabled", unmask=True)
        # Host identity files stay monitored and alerted on, but the service's
        # own recovery no longer waits for them to match (a new account must not
        # hold a web server's repair).
        host = [row["path"] for row in withheld if _refusal(row["path"]) is not None]
        if host:
            policy["host_files"] = host
        try:
            approval = _add(manifest.get("approval_actions", []), APPROVAL_ACTIONS)
            automatic_list = (_add(manifest.get("allowed_automatic_actions", []), AUTOMATIC_ACTIONS)
                              if automatic else manifest.get("allowed_automatic_actions", []))
        except ValueError as exc:
            report["skipped"].append({"service": name, "reason": str(exc)})
            continue
        manifest["repair_policy"] = policy
        manifest["approval_actions"] = approval
        manifest["allowed_automatic_actions"] = automatic_list
        # A check on the host's own address never leaves the host, so it tells a
        # broken service from a network fault just as loopback does (2.0.5).
        own = frozenset()
        try:
            import ipaddress
            own = frozenset({str(ipaddress.ip_address(manifest["host"]))})
        except ValueError:
            pass
        if not any(local_probe(spec, own) for spec in manifest.get("expected_transactions", [])):
            report["warnings"].append(f"{name}: no check on 127.0.0.1 or on the host's own address, so a service "
                                      "that is running but broken cannot be told apart from a network problem; "
                                      "only a stopped service is repaired.")
        report["granted"].append({"service": name, "restore_files": files, "withheld": withheld,
                                  "start_mode": policy["restore_start_mode"], "unmask": policy.get("unmask", False)})
    if automatic and report["granted"]:
        result["allowed_automatic_actions"] = _add(result.get("allowed_automatic_actions", []),
                                                   ("capture_restore_point", "repair_service"))
    capabilities = result.setdefault("capabilities", {})
    needed = list(REPAIR_CAPABILITIES) + (["guarded_autonomy"] if automatic else [])
    off = [name for name in needed if capabilities.get(name) is not True]
    if off and report["granted"]:
        if enable_capabilities:
            for name in off:
                capabilities[name] = True
            report["warnings"].append("enabled capabilities: " + ", ".join(off))
        else:
            report["warnings"].append("this profile turns off " + ", ".join(off) + "; repair stays refused until "
                                      "they are enabled (grant again with enable_capabilities, or edit the profile)")
    EventProfile.from_dict(result)               # and so must the output
    return result, report


def report_text(report: dict[str, Any]) -> str:
    lines = [f"Repair granted to {len(report['granted'])} service(s); "
             f"{len(report['kept'])} kept their own policy; {len(report['skipped'])} skipped."]
    for row in report["granted"]:
        mode = row["start_mode"] + (" (unmask)" if row["unmask"] else "")
        lines.append(f"  {row['service']}: restores {len(row['restore_files'])} file(s); startup back to {mode}")
        lines += [f"      {path}" for path in row["restore_files"]]
        lines += [f"      alert only: {item['path']} — {item['reason']}" for item in row["withheld"]]
    lines += [f"  kept {row['service']}: {row['reason']}" for row in report["kept"]]
    lines += [f"  skipped {row['service']}: {row['reason']}" for row in report["skipped"]]
    lines += ["Note: " + text for text in report["warnings"]]
    lines.append("Review this profile before using it. Agents need --allow-service-recovery and "
                 "--allow-restoration, and the baseline must be re-approved so its backups are captured.")
    return "\n".join(lines)


def grant_file(source, destination, **options) -> dict[str, Any]:
    """Read a profile, write the granted copy to a new file, return the report."""
    from pathlib import Path
    from .json_codec import strict_json_loads
    from .state import write_private_json
    source, destination = Path(source).absolute(), Path(destination).absolute()
    if destination == source:
        raise ValueError("write the granted profile to a new file; the reviewed original is never changed")
    if destination.exists():
        raise ValueError(f"{destination} already exists; choose a new file name")
    raw = strict_json_loads(source.read_text(encoding="utf-8"), max_bytes=4 * 1024 * 1024)
    result, report = grant_repair(raw, **options)
    write_private_json(destination, result)
    return report


def run(args) -> int:
    import json
    import sys
    try:
        report = grant_file(args.event_profile, args.output, automatic=args.automatic,
                            windows_hosts=args.windows_host, only=args.service,
                            enable_capabilities=args.enable_capabilities)
    except (OSError, ValueError) as exc:
        print("repair-grant: " + str(exc), file=sys.stderr)
        return 2
    print(json.dumps(report, indent=2) if args.json else report_text(report))
    return 0
