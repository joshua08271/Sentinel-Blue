"""Emergency controls kept separate from the reversible Pause button."""
from pathlib import Path
import threading
import uuid


def withdrawal_explanation(result):
    """Plain words for the parts of a withdrawal result that read like a failure."""
    lines = []
    local_only = [row for row in result.get('external_verification', [])
                  if 'separate observer' in str(row.get('reason', ''))]
    if local_only and result.get('status') == 'held':
        lines += ['', 'This VM has no separate observer, so its services could not be checked from outside it. '
                  'The changes listed above were still reversed; Sentinel kept its own files and the evidence, '
                  'which is why the result says held.']
    if result.get('operation_id'):
        lines += ['', 'This VM now stays paused: no Sentinel controller, agent or setup job starts here. To use '
                  'Sentinel on it again, choose "Allow Sentinel on this VM again…" (operation '
                  + str(result['operation_id']) + ').']
    return lines


class WithdrawalControls:
    def _withdrawal(self):
        tab = self.tabs['Withdraw']
        self.withdraw_review = None
        self.withdraw_busy = False
        self.ttk.Label(tab, text='Emergency removal', font=('Segoe UI', 16, 'bold')).pack(anchor='w')
        self.ttk.Label(tab, text='Remove Sentinel stops its controller and agents and removes proven Sentinel installation objects. Service configuration stays in place.', wraplength=940).pack(anchor='w', pady=8)
        self.ttk.Label(tab, text='Restore & Withdraw also reverses owned configuration changes in dependency order, verifies services externally, and reports conflicts. Teammate edits are preserved.', wraplength=940).pack(anchor='w', pady=8)
        self.ttk.Label(tab, text='Uses the inventory and event profile selected in Setup. Reviewing first pauses every declared host.', wraplength=940, style='Subtitle.TLabel').pack(anchor='w', pady=8)
        controls = self.ttk.Frame(tab)
        controls.pack(fill='x', pady=8)
        self.ttk.Button(controls, text='Review Remove Sentinel', command=lambda: self.review_withdrawal('remove')).pack(side='left')
        self.ttk.Button(controls, text='Review Restore & Withdraw', command=lambda: self.review_withdrawal('restore-withdraw')).pack(side='left', padx=8)
        self.withdraw_execute = self.ttk.Button(controls, text='Execute reviewed withdrawal', state='disabled', command=self.execute_withdrawal)
        self.withdraw_execute.pack(side='left')
        after = self.ttk.Frame(tab)
        after.pack(fill='x', pady=4)
        self.ttk.Button(after, text='Cancel this withdrawal review', command=self.cancel_withdrawal_review).pack(side='left')
        # After an executed withdrawal the VM stays paused until someone decides
        # otherwise; this records that decision (sentinel-blue withdraw-release).
        self.ttk.Button(after, text='Allow Sentinel on this VM again…', command=self.release_withdrawal).pack(side='left', padx=8)
        self.withdraw_text = self.tk.Text(tab, height=15, wrap='word', bg='#172636', fg='#edf3f8', relief='flat')
        self.withdraw_text.pack(fill='both', expand=True, pady=10)
        self.withdraw_text.configure(state='disabled')

    def _withdraw_display(self, message):
        self.withdraw_text.configure(state='normal')
        self.withdraw_text.delete('1.0', 'end')
        self.withdraw_text.insert('1.0', message)
        self.withdraw_text.configure(state='disabled')

    def _withdraw_background(self, operation, done):
        # Emergency work never waits behind an ordinary setup/UI queue.
        generation = self.generation
        def failed(value):
            self.withdraw_busy = False
            self._withdraw_display('Withdrawal is held. ' + value[1] + '\nRecovery evidence is retained. Review a fresh inventory before retrying.')
        def work():
            try:
                value = operation()
                self.events.put(('done', (generation, done, True), value))
            except Exception as exc:
                self.events.put(('error', (generation, failed, True), (type(exc).__name__, str(exc)[:500])))
        self.withdraw_busy = True
        threading.Thread(target=work, name='sentinel-emergency-withdrawal', daemon=False).start()

    def review_withdrawal(self, mode):
        if self.withdraw_busy:
            self.footer.set('Emergency withdrawal is already running; its report will update when confirmed.')
            return
        inventory, profile = self.inventory_path.get(), self.profile_path.get()
        if not inventory or not profile:
            self.footer.set('Select the network inventory and event profile in Setup first.')
            return
        self.withdraw_review = None
        self.withdraw_execute.configure(state='disabled')
        directory = self.directory / 'withdrawals' / uuid.uuid4().hex
        client = self.client
        range_mode = self.range_mode.get()
        self._withdraw_display('Pausing the declared network and collecting ownership evidence…')
        def review():
            from .withdrawal import coordinator_from_files
            self.job_control.set_paused(True)
            # A failed controller connection does not prevent independent guest
            # withdrawal, but it is visible in the review and must be resolved.
            controller_note = ''
            if client is not None:
                try:
                    result = client.request('/api/v1/governance/emergency-stop', {})
                    if result.get('emergency_stopped') is not True:
                        raise ValueError('Controller pause was not confirmed')
                except Exception:
                    controller_note = 'Controller API did not confirm Pause; review the independent controller-host result.\n'
            coordinator = coordinator_from_files(inventory, profile, directory, range_deployment=range_mode)
            return coordinator, coordinator.review(mode), controller_note
        def ready(value):
            self.withdraw_busy = False
            coordinator, report, note = value
            self.withdraw_review = coordinator, report
            lines = [note + ('Remove Sentinel' if mode == 'remove' else 'Restore & Withdraw'),
                     str(len(report['hosts'])) + ' systems inventoried.', 'Recovery report: ' + str(directory), '']
            for host, data in sorted(report['hosts'].items()):
                if data.get('error'):
                    lines.append(host + ': HELD — ' + data['error'])
                for action in data.get('inventory', {}).get('actions', []):
                    objects = ', '.join(action['target'].get('objects', []))
                    intent = ('keep configuration' if mode == 'remove' and action['ownership'] == 'configuration' else 'reverse owned change')
                    lines.append(host + ' · ' + objects + ' · ' + (action.get('conflict') or intent))
            lines += ['', str(len(report['conflicts'])) + ' conflicts require review. No whole-machine restoration is performed.']
            self._withdraw_display('\n'.join(lines))
            if not any('error' in x for x in report['hosts'].values()):
                self.withdraw_execute.configure(state='normal')
        self._withdraw_background(review, ready)

    def cancel_withdrawal_review(self):
        if self.withdraw_busy or self.withdraw_review is None:
            return
        coordinator, report = self.withdraw_review
        self.withdraw_execute.configure(state='disabled')
        def done(result):
            self.withdraw_busy = False
            self.withdraw_review = None
            self._withdraw_display('Withdrawal review cancelled. Use the existing Pause and Resume controls to choose whether to resume approved changes.')
        self._withdraw_background(lambda: coordinator.cancel_review(report), done)

    def execute_withdrawal(self):
        if self.withdraw_busy or self.withdraw_review is None:
            return
        coordinator, report = self.withdraw_review
        name = 'Remove Sentinel' if report['mode'] == 'remove' else 'Restore & Withdraw'
        if not self.messagebox.askyesno(name, 'Execute the reviewed changes across ' + str(len(report['hosts'])) + ' systems? Conflicting objects will be preserved and reported.', parent=self.root):
            return
        self.withdraw_execute.configure(state='disabled')
        def done(result):
            self.withdraw_busy = False
            lines = [name + ': ' + result['status'], 'Report: ' + str(coordinator.directory / 'result.json')]
            for conflict in result['conflicts']:
                lines.append((conflict.get('action') or conflict.get('host') or 'Verification') + ': ' + conflict['reason'])
            lines += withdrawal_explanation(result)
            self._withdraw_display('\n'.join(lines))
            self.footer.set('Withdrawal ' + result['status'] + '. Recovery evidence has been retained.')
        self._withdraw_background(lambda: coordinator.execute(report, report['review_digest']), done)

    def release_withdrawal(self):
        """Record the decision to allow Sentinel on this host after a withdrawal."""
        import os
        from .mutation_ledger import LedgerError, MutationLedger
        from .withdrawal_release import status_text
        if os.name != 'nt' and os.geteuid() != 0:
            self.note('Allowing Sentinel again needs the administrator window (Start here → Open as administrator…).')
            return
        operation = None
        try:
            ledger = MutationLedger()
            operation = ledger.withdrawal_operation()
            check = ledger.release_after_withdrawal(operation, check_only=True) if operation else None
        except (LedgerError, OSError, ValueError) as exc:
            self._withdraw_display(status_text(operation, None, str(exc)))
            return
        if operation is None:
            self._withdraw_display(status_text(None))
            return
        held = len((check or {}).get('held_conflicts') or [])
        if not self.messagebox.askyesno('Allow Sentinel on this VM again',
                f'Withdrawal {operation} is pausing this VM. Allow Sentinel to run here again? '
                'This changes nothing on the VM; review the withdrawal report first.'
                + (f' {held} object(s) it held for review stay held.' if held else ''), parent=self.root):
            return
        try:
            report = ledger.release_after_withdrawal(operation)
        except (LedgerError, OSError, ValueError) as exc:
            self._withdraw_display(status_text(operation, None, str(exc)))
            return
        self._withdraw_display(status_text(operation, report))
        self.note('Sentinel may run on this VM again; start a new reviewed session.')
