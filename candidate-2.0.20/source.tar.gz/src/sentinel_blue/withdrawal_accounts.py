"""Account-row rollback preserves every other account's current shadow entry."""
from __future__ import annotations
import ctypes
from pathlib import Path
import os

from .mutation_ledger import OwnershipConflict, LedgerError


class LinuxAccount:
    name = 'linux-account-v1'
    def __init__(self, ledger):
        self.ledger = ledger

    def snapshot(self, target):
        if os.name != 'posix':
            raise LedgerError('No exact account rollback adapter exists for this platform')
        from .security_native import NativeSecurityBackend
        account = NativeSecurityBackend().account(target['name'])
        if account['account_id'] != target['account_id']:
            raise OwnershipConflict('Account identity changed')
        from .restoration import RestorePointStore
        data, _ = RestorePointStore._read_target(Path('/etc/shadow'))
        prefix = target['name'].encode() + b':'
        rows = [x for x in data.splitlines(keepends=True) if x.startswith(prefix)]
        if len(rows) != 1:
            raise OwnershipConflict('Local account row is absent or ambiguous')
        return {'account': account, 'shadow_row': rows[0].decode('utf-8')}

    def restore(self, target, before, expected):
        libc = ctypes.CDLL(None, use_errno=True)
        if libc.lckpwdf() != 0:
            raise LedgerError('Cannot acquire the native password database lock')
        try:
            if self.snapshot(target) != expected:
                raise OwnershipConflict('Account changed after Sentinel; password restore held')
            from .restoration import RestorePointStore
            from .mutation_tracking import suppressed
            store = RestorePointStore(self.ledger.directory / 'account-restore')
            path = Path('/etc/shadow')
            data, metadata = store._read_target(path)
            rows = data.splitlines(keepends=True)
            prefix = target['name'].encode() + b':'
            indices = [i for i, row in enumerate(rows) if row.startswith(prefix)]
            if len(indices) != 1 or rows[indices[0]].decode() != expected['shadow_row']:
                raise OwnershipConflict('Password database entry changed before restoration')
            rows[indices[0]] = before['shadow_row'].encode()
            with suppressed():
                store._atomic_write(path, b''.join(rows), metadata['mode'], metadata, expected_current=(data, metadata))
            result = self.snapshot(target)
            if result != before:
                raise LedgerError('Account rollback failed exact validation')
            return result
        finally:
            libc.ulckpwdf()
