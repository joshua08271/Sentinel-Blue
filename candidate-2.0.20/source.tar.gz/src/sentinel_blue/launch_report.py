"""Tell someone who double-clicked the program why it did not open.

A launch from a file manager or a desktop entry has no terminal attached, so
anything written to stderr goes nowhere the person will ever look. The window
simply fails to appear. The two things that realistically stop it — Tk not
installed, and no graphical session — both raise before any window exists, which
is exactly when there is nothing on screen to carry the message.

So the message is put on screen by whatever the desktop already provides. The
helpers are tried in the order most likely to be present on a competition image,
and each is run as an argument list: the text is never handed to a shell, and it
is bounded, stripped of control characters and passed after `--` so it cannot be
read as an option.

Nothing here is required for the program to work. If no helper exists the text
still goes to stderr, and the caller still fails.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys

TITLE = "Sentinel Blue"

# Bounded so a long chain of exception text cannot become a dialog taller than
# the screen or an unreasonable argument list.
LIMIT = 800

TIMEOUT = 20


def _clean(message: str) -> str:
    text = " ".join("".join(c if c.isprintable() or c.isspace() else " "
                            for c in str(message)).split())
    if len(text) > LIMIT:
        text = text[:LIMIT - 1] + "…"
    return text or "Sentinel Blue could not start."


def _graphical() -> bool:
    return bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))


def _commands(text: str) -> list[list[str]]:
    """Dialog helpers, most common first. Argument lists only — never a shell."""
    return [
        ["zenity", "--error", "--no-markup", "--width=460",
         f"--title={TITLE}", "--text", text],
        ["kdialog", "--title", TITLE, "--error", text],
        ["xmessage", "-center", "-timeout", str(TIMEOUT), "--", text],
        ["notify-send", "--urgency=critical", "--", TITLE, text],
    ]


def _tk_dialog(text: str) -> bool:
    """Tk is usually the thing that is missing, but try it when it is not."""
    try:
        import tkinter
        from tkinter import messagebox
    except Exception:
        return False
    try:
        root = tkinter.Tk()
        root.withdraw()
        try:
            messagebox.showerror(TITLE, text)
        finally:
            root.destroy()
        return True
    except Exception:
        return False


def report(message: str, *, detail: str | None = None) -> bool:
    """Put the reason where the person can see it. True when something showed it.

    stderr is always written first, so a launch from a terminal keeps the exact
    text and a launch without one loses nothing that was not already lost.
    """
    text = _clean(message)
    print(f"sentinel-blue: {text}", file=sys.stderr)
    if detail:
        print(detail, file=sys.stderr)
    if not _graphical():
        return False
    for argv in _commands(text):
        if shutil.which(argv[0]) is None:
            continue
        try:
            result = subprocess.run(argv, timeout=TIMEOUT, check=False,
                           stdin=subprocess.DEVNULL,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if result.returncode == 0:
                return True
        except (OSError, ValueError, subprocess.SubprocessError):
            continue
    return _tk_dialog(text)
