"""Keep local collection/self-health diagnostics bounded and provenance-aligned.

Provenance is structural, never inferred from message text. The existing wire
vocabulary is retained so older controllers need no new provenance enum.
"""
from __future__ import annotations

MAX_DIAGNOSTICS = 256
VALID_SOURCES = frozenset({"unknown", "payload_fingerprint", "network_inventory", "restore_points"})
# Gaps in these collectors leave no hole in the evidence service recovery uses
# (service state, files, checks, listeners, capacity, accounts). They cost drift
# detection for firewall, routes, neighbors and interfaces, and are reported,
# but they must not hold a restart or repair. Before 2.0.5 they did: one nft
# warning, or a host without iproute2, disabled all recovery.
# A lost restore point is reported (and alerted) but costs only the repair of
# that one file; holding every other service's recovery for it would repeat the
# pre-2.0.5 mistake.
RECOVERY_INDEPENDENT_SOURCES = frozenset({"network_inventory", "restore_points"})


class DiagnosticIssue(str):
    """A diagnostic whose provenance is its type, never its text."""
    source = "unknown"


class NetworkInventoryIssue(DiagnosticIssue):
    """A firewall, route, neighbor or interface collection gap."""
    source = "network_inventory"


class RestorePointIssue(DiagnosticIssue):
    """A restore point whose backup bytes were deleted or rebuilt."""
    source = "restore_points"


class RestorePointDiagnostics(list):
    """Carry the complete bounded audit alongside its optional display messages."""
    def __init__(self, rows, health):
        super().__init__(rows)
        self.restore_health = health
        for row in self:
            row.restore_health = health


def restore_point_issues(report):
    """Diagnostics for one audit_backups() report."""
    issues = [RestorePointIssue(f"restore point lost: {path}") for path in report.get("lost", [])]
    issues += [RestorePointIssue(f"restore point rebuilt: {path}") for path in report.get("rebuilt", [])]
    issues += [RestorePointIssue(f"restore manifest metadata: {message}")
               for key in ("metadata_errors", "metadata_notices") for message in report.get(key, [])]
    from .restore_health import from_audit
    return RestorePointDiagnostics(issues, from_audit(report))


# Parallel to collector_errors (2.0.16): which service each payload-coverage
# gap belongs to. See payload_inventory.PAYLOAD_OWNER_*.
OWNERS_FIELD = "collector_issue_owners"
# Service states in which a unit has no running process of its own.
STOPPED_SERVICE_STATES = frozenset({"stopped", "inactive", "failed", "dead"})


def _same_service(observed, service):
    observed, service = str(observed), str(service)
    return observed == service or observed == service + ".service" or observed + ".service" == service


def service_has_processes(telemetry, service):
    """Whether the service may have running processes (unknown counts as yes)."""
    rows = [row for row in telemetry.get("services") or []
            if isinstance(row, dict) and _same_service(row.get("name"), service)]
    if len(rows) != 1:
        return True
    return str(rows[0].get("state", "")).casefold() not in STOPPED_SERVICE_STATES


def payload_gap_concerns(owner, service, running):
    """Whether a payload-coverage gap with this owner can concern ``service``."""
    from .payload_inventory import (PAYLOAD_OWNER_ANY, PAYLOAD_OWNER_ANY_RUNNING, PAYLOAD_OWNER_NONE,
                                    valid_payload_owner)
    if not valid_payload_owner(owner) or owner == PAYLOAD_OWNER_ANY:
        return True
    if owner == PAYLOAD_OWNER_NONE:
        return False
    if owner == PAYLOAD_OWNER_ANY_RUNNING:
        return running
    return _unit_covers(owner, service)


def _unit_covers(owner, service):
    """Whether a gap owned by ``owner`` belongs to ``service``.

    A template (``app@.service``) or prefix drop-in owner (``app-.service``,
    from ``app-.service.d/``) covers every instance or unit it configures.
    """
    if _same_service(owner, service):
        return True
    unit = str(service) if str(service).endswith(".service") else str(service) + ".service"
    stem = owner[:-len(".service")]
    return (stem.endswith("@") or stem.endswith("-")) and unit.startswith(stem) and len(unit) > len(owner)


def recovery_blocking(telemetry, *, allow_payload=False, service=None, defer_attributed_payload=False):
    """The diagnostics that make this sample incomplete evidence for recovery.

    With ``service``, a payload-coverage gap holds only the recovery it can
    concern: a gap attributed to that service, a gap no collector could
    attribute, or an uninspected running process while the service has
    processes of its own. A gap that belongs to another service or to no
    service stays reported (and alerted) but does not hold this recovery.
    ``defer_attributed_payload`` counts only unattributable gaps, for a
    host-wide gate whose per-service checks run again before any action.
    ``allow_payload`` (the manifest opt-out) ignores payload gaps, except,
    when a service is named, a gap attributed to that service.
    """
    from .payload_inventory import PAYLOAD_OWNER_ANY, PAYLOAD_OWNER_ANY_RUNNING, valid_payload_owner
    errors = telemetry.get("collector_errors") or []
    sources = telemetry.get("collector_issue_sources")
    if not isinstance(sources, list) or len(sources) != len(errors):
        return list(errors)
    # The manifest opt-out (allow_unrelated_payload_errors) covers gaps that
    # are unrelated or cannot be attributed. With a service named, a gap
    # attributed to that very service still holds its recovery.
    ignored = RECOVERY_INDEPENDENT_SOURCES | ({"payload_fingerprint"} if allow_payload and service is None else set())
    owners = telemetry.get(OWNERS_FIELD)
    if not isinstance(owners, list) or len(owners) != len(errors):
        owners = [PAYLOAD_OWNER_ANY] * len(errors)
    scoped = service is not None or defer_attributed_payload
    running = service_has_processes(telemetry, service) if service is not None else True
    blocking = []
    for error, source, owner in zip(errors, sources, owners):
        if source in ignored:
            continue
        if source == "payload_fingerprint" and scoped:
            if service is None:
                # Host-wide gate: only a gap that could concern any service.
                if valid_payload_owner(owner) and owner != PAYLOAD_OWNER_ANY:
                    continue
            elif allow_payload:
                if not (valid_payload_owner(owner) and owner not in {PAYLOAD_OWNER_ANY, PAYLOAD_OWNER_ANY_RUNNING}
                        and _unit_covers(owner, service)):
                    continue
            elif not payload_gap_concerns(owner, service, running):
                continue
        blocking.append(error)
    return blocking


def _clean(error):
    text = "".join(c if ord(c) >= 32 or c in "\t\r\n" else "\ufffd"
                   for c in str(error)).strip()
    return (text or "collector failed without detail")[:256]


def normalize_diagnostics(errors, sources=None, *, extra_errors=()):
    """Return equally sized wire arrays; prioritize self-health on overflow.

    An absent/empty legacy provenance list becomes explicitly unknown. Malformed
    alignment is not salvaged by trusting displaced labels. A bounded overflow
    record witnesses omitted diagnostics rather than hiding loss of coverage.
    """
    errors, sources, _owners = normalize_diagnostics_with_owners(errors, sources, extra_errors=extra_errors)
    return errors, sources


def normalize_diagnostics_with_owners(errors, sources=None, *, extra_errors=(), owners=None):
    """``normalize_diagnostics`` plus the aligned payload-gap owner array.

    Owners come from typed issues on first normalization, or from an aligned
    explicit ``owners`` list when an already-normalized sample is normalized
    again. A payload gap without a valid owner may concern any service; every
    other diagnostic has the empty owner, which nothing reads.

    Identical payload gaps (the workers of one upgraded daemon) are reported
    once with their count. When the bounded array still overflows and every
    omitted row is a payload gap, the loss witness keeps that provenance and
    the omitted owners, so it holds only the recovery those gaps concern.
    """
    from .payload_inventory import MAX_ISSUE_OWNERS, PAYLOAD_OWNER_ANY, PayloadCoverageIssue, valid_payload_owner
    original = errors if isinstance(errors, (list, tuple)) else list(errors)
    explicit = list(sources) if sources is not None else None
    bad_provenance = bool(explicit) and (len(explicit) != len(original)
        or any(not isinstance(s, str) or s not in VALID_SOURCES for s in explicit))
    explicit_owners = (list(owners) if isinstance(owners, (list, tuple)) and len(owners) == len(original)
                       else None)
    rows, payload_rows = [], {}
    for index, error in enumerate(original):
        typed = getattr(error, "source", None) if isinstance(error, (PayloadCoverageIssue, DiagnosticIssue)) else None
        source = (explicit[index] if explicit and not bad_provenance else
                  typed if explicit is None and typed in VALID_SOURCES
                  else "unknown")
        owner = ""
        if source == "payload_fingerprint":
            owner = (explicit_owners[index] if explicit_owners is not None and explicit else
                     getattr(error, "owner", PAYLOAD_OWNER_ANY) if explicit is None else PAYLOAD_OWNER_ANY)
            if not valid_payload_owner(owner):
                owner = PAYLOAD_OWNER_ANY
            key = (_clean(error), owner)
            if key in payload_rows:
                payload_rows[key][3] += 1
                continue
            payload_rows[key] = row = [key[0], source, owner, 1]
            rows.append(row)
            continue
        rows.append([_clean(error), source, owner, 1])
    for row in rows:
        if row[3] > 1:
            suffix = f" ({row[3]} occurrences)"
            row[0] = row[0][:256 - len(suffix)] + suffix
    rows = [tuple(row[:3]) for row in rows]
    if bad_provenance:
        rows.append(("collector diagnostic provenance unavailable; coverage incomplete", "unknown", ""))
    extra_values = extra_errors if isinstance(extra_errors, (list, tuple)) else list(extra_errors)
    extra = [(_clean(error), error.source if isinstance(error, DiagnosticIssue) and error.source in VALID_SOURCES
              else "unknown", "") for error in extra_values]
    if len(rows) + len(extra) <= MAX_DIAGNOSTICS:
        combined = rows + extra
    else:
        # Reserve space for the loss witness. Health faults must not disappear
        # behind a saturated inventory-error array (nor acquire a payload tag).
        def bounded(witnesses):
            retained_extra = extra[:MAX_DIAGNOSTICS - witnesses]
            kept = rows[:MAX_DIAGNOSTICS - witnesses - len(retained_extra)]
            omitted = rows[len(kept):] + extra[len(retained_extra):]
            if any(row[1] != "payload_fingerprint" for row in omitted):
                needed = None
            else:
                needed = sorted({row[2] for row in omitted})
                if len(needed) > MAX_ISSUE_OWNERS:
                    needed = [PAYLOAD_OWNER_ANY]
            return kept + retained_extra, omitted, needed

        witnesses = 1
        kept, omitted, needed = bounded(witnesses)
        while needed is not None and len(needed) > witnesses:
            witnesses = len(needed)
            kept, omitted, needed = bounded(witnesses)
        if needed is not None and len(needed) < witnesses:
            # Fewer owners after growing: one unattributed witness is exact enough.
            kept, omitted, _ = bounded(1)
            needed = [PAYLOAD_OWNER_ANY]
        text = f"additional collector/self-health errors exceed the telemetry diagnostic limit ({len(omitted)} omitted)"
        witness = ([(text, "unknown", "")] if needed is None else
                   [(text, "payload_fingerprint", owner) for owner in needed])
        combined = kept + witness
    return [r[0] for r in combined], [r[1] for r in combined], [r[2] for r in combined]


def merge_health_diagnostics(telemetry, health_errors):
    from .restore_health import FIELD, validate
    attached = getattr(health_errors, 'restore_health', None)
    health_errors = list(health_errors)
    reports = ([attached] if attached is not None else
               [error.restore_health for error in health_errors if isinstance(error, RestorePointIssue)
                and hasattr(error, 'restore_health')])
    if reports:
        # A telemetry observation carries one audit. Conflicting audits are not
        # silently reduced to whichever message happens to survive truncation.
        health = validate(reports[0])
        if any(value != reports[0] for value in reports[1:]):
            health.update(authority='unknown', complete=False)
        telemetry[FIELD] = health
    errors, sources, owners = normalize_diagnostics_with_owners(telemetry.get("collector_errors", []),
        telemetry.get("collector_issue_sources", []), extra_errors=health_errors,
        owners=telemetry.get(OWNERS_FIELD))
    telemetry["collector_errors"] = errors
    telemetry["collector_issue_sources"] = sources
    telemetry[OWNERS_FIELD] = owners
