"""Offline, authenticated, resumable recovery. Never restore a machine image.

The independently retained key and anchor are required. All host mutation
admission stays paused after recovery until the operator and agents reconcile.
A capsule is private: it contains enrollment/TLS material and rollback states.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import sqlite3
import time
import uuid

from . import recovery as r
from .mutation_ledger import MutationLedger
from .event_profile import load_event_profile
from .store import Store

MAX_DOCUMENT = 4 * 1024 * 1024
MAX_MATERIAL = 512 * 1024 * 1024
MAX_FILES = 20000
CONSTRAINTS = dict(expected_application_id=r.CONTROLLER_APPLICATION_ID,
                   expected_user_version=r.CONTROLLER_USER_VERSION,
                   required_tables=r.CONTROLLER_REQUIRED_TABLES,
                   allowed_tables=r.CONTROLLER_ALLOWED_TABLES)
ARTIFACT_ROLES = frozenset({'event_profile', 'token_file', 'operator_token_file',
                           'tls_cert', 'tls_key', 'tls_ca_file', 'probe_config',
                           'model', 'observer_config'})


def _hash(data):
    return hashlib.sha256(data).hexdigest()


def _bytes(path, maximum=MAX_MATERIAL):
    return r._read_regular_bytes(Path(path), maximum=maximum)


def _write(path, data):
    r._require_private_directory(Path(path).parent)
    r._atomic_private_write(Path(path), data, maximum=MAX_MATERIAL, replace=False)


def _signed(path, value, key, purpose):
    r._write_signed_document(Path(path), value, key, purpose=purpose,
                             maximum=MAX_DOCUMENT, replace=False)


def _read_signed(path, key, purpose):
    return r._read_signed_document(Path(path), key, purpose=purpose, maximum=MAX_DOCUMENT)


def _tree(root, *, skip_lock=False):
    """Bounded exact regular-file inventory, without following any links."""
    result = {}
    total = 0
    for parent, directories, files in os.walk(root, followlinks=False):
        for name in directories:
            r._require_private_directory(Path(parent) / name)
        for name in files:
            path = Path(parent) / name
            if skip_lock and Path(parent) == Path(root) and name == 'writer.lock':  # Ledger's live lock is not portable state.
                continue
            data = _bytes(path)
            total += len(data)
            if len(result) >= MAX_FILES or total > MAX_MATERIAL:
                raise ValueError('Recovery material exceeds bounded capsule capacity')
            result[path.relative_to(root).as_posix()] = {'sha256': _hash(data), 'bytes': len(data)}
    return result


def _copy_tree(source, destination, inventory, *, ledger=False):
    native = None
    if ledger and os.name == 'nt':
        from .win_state import _NativeWindowsStateBackend
        native = _NativeWindowsStateBackend()
        # Atomic, exclusive creation with the ledger's exact private ACL.
        # Never normalize a pre-existing destination around copied material.
        native.create_directory(str(destination))
    else:
        destination.mkdir(mode=0o700, exist_ok=False)
    for name, expected in inventory.items():
        relative = Path(name)
        if relative.is_absolute() or '..' in relative.parts or not relative.parts:
            raise ValueError('Unsafe capsule relative path')
        target = destination / relative
        parent = destination
        for part in relative.parts[:-1]:
            parent = parent / part
            if not parent.exists():
                if native is not None:
                    native.create_directory(str(parent))
                else:
                    # parents=True applies mode only to the leaf. Create each
                    # level privately, including nested restore metadata.
                    parent.mkdir(mode=0o700)
            r._require_private_directory(parent)
        data = _bytes(source / relative)
        if {'sha256': _hash(data), 'bytes': len(data)} != expected:
            raise ValueError('Recovery input changed while copying')
        _write(target, data)
    r._fsync_directory(destination)


def create_capsule(store, root, anchor_path, key, *, artifacts, ledger_directory,
                   references=None, controller_arguments=None):
    """Snapshot the DB, rollback chain, exact approved inputs and evidence refs."""
    from .recovery_ops import create_controller_backup
    root = Path(root)
    r._require_private_directory(root)
    if not set(artifacts) <= ARTIFACT_ROLES or 'event_profile' not in artifacts:
        raise ValueError('A capsule requires an exact event profile and known input roles')
    profile = load_event_profile(artifacts['event_profile'])
    ledger = MutationLedger(ledger_directory)
    directory = root / ('recovery-' + uuid.uuid4().hex + '.sbrecovery')
    directory.mkdir(mode=0o700)
    inputs = directory / 'inputs'
    inputs.mkdir(mode=0o700)
    # Store and mutation locks cover the complete cross-file snapshot. Host
    # changes already hold the ledger lock for their entire native mutation.
    with ledger.lock(), store._lock:
        events = ledger.read()
        head = ledger.head()
        inventory = _tree(ledger.directory, skip_lock=True)
        _copy_tree(ledger.directory, directory / 'ledger', inventory, ledger=True)
        for role, source in artifacts.items():
            _write(inputs / role, r._read_regular_bytes(Path(source), maximum=16 * 1024 * 1024,
                                                   private=role in {"token_file", "operator_token_file", "tls_key"}))
        backup = create_controller_backup(store, directory, anchor_path, key, advance_anchor=False)
        verified = r.verify_backup_bundle(backup['bundle'], key, **CONSTRAINTS,
                                          expected_profile_fingerprint=profile.fingerprint)
        payload = {
            'format': 'sentinel-blue-recovery-capsule', 'schema': 1,
            'backup': Path(backup['bundle']).name,
            'manifest_sha256': verified.manifest_sha256,
            'controller_instance_id': verified.inspection.controller_instance_id,
            'profile_fingerprint': profile.fingerprint,
            'release_sha256': verified.inspection.active_release_binding['release_sha256'],
            'created_at': time.time(), 'ledger_head': head,
            'ledger_paused': ledger.paused(),
            'uncertain_ledger_actions': [a['action_id'] for a in ledger.actions()
                                        if a['status'] in {'prepared', 'applied', 'uncertain',
                                                          'undo_prepared', 'boot_prepared', 'quiesce_prepared'}],
            'ledger_files': inventory, 'inputs': _tree(inputs),
            'references': references or {},
            'controller_arguments': controller_arguments,
        }
        if load_event_profile(inputs / 'event_profile').fingerprint != profile.fingerprint:
            raise ValueError('Approved event profile changed during backup')
        _signed(directory / 'capsule.json', payload, key, 'recovery-capsule')
        r._fsync_directory(directory)
        advanced = r.advance_backup_anchor(anchor_path, key, r.load_anchor(anchor_path, key), verified)
        backup['protected_sequence_floor'] = advanced['backup_sequence_floor']
    return {**backup, 'capsule': str(directory), 'ledger_head': head,
            'private_material': True, 'capsule_sha256': _hash(_bytes(directory / 'capsule.json'))}


def inspect_capsule(directory, anchor_path, key, *, release_sha256, profile_fingerprint):
    """Authenticate retained material, including historical backups.

    Integrity is not restore admission. Only verify_capsule enforces the exact
    latest protected backup required by the restoration transaction.
    """
    directory = Path(directory)
    r._require_private_directory(directory)
    capsule = _read_signed(directory / 'capsule.json', key, 'recovery-capsule')
    if capsule.get('format') != 'sentinel-blue-recovery-capsule' or capsule.get('schema') != 1:
        raise ValueError('Unsupported recovery capsule')
    name = capsule['backup']
    if Path(name).name != name or not name.endswith('.sbbackup'):
        raise ValueError('Invalid capsule database path')
    if {p.name for p in directory.iterdir()} != {'capsule.json', name, 'ledger', 'inputs'}:
        raise ValueError('Recovery capsule has incomplete or unexpected material')
    for field, expected in [('release_sha256', release_sha256),
                            ('profile_fingerprint', profile_fingerprint)]:
        if capsule[field] != expected:
            raise ValueError('Recovery capsule wrong ' + field)
    anchor = r.load_anchor(anchor_path, key)
    backup = r.verify_backup_bundle(directory / name, key, **CONSTRAINTS, anchor=anchor,
                                    expected_controller_instance_id=anchor['controller_instance_id'],
                                    expected_release_sha256=release_sha256,
                                    expected_profile_fingerprint=profile_fingerprint)
    if (backup.manifest_sha256 != capsule['manifest_sha256']
            or capsule['controller_instance_id'] != anchor['controller_instance_id']):
        raise ValueError('Recovery capsule disagrees with its authenticated database')
    for label, inventory in [('ledger', capsule['ledger_files']), ('inputs', capsule['inputs'])]:
        r._require_private_directory(directory / label)
        if _tree(directory / label, skip_lock=label == "ledger") != inventory:
            raise ValueError('Incomplete, changed or tampered ' + label + ' material')
    if not set(capsule['inputs']) <= ARTIFACT_ROLES or 'event_profile' not in capsule['inputs']:
        raise ValueError('Invalid recovery input roles')
    if load_event_profile(directory / 'inputs/event_profile').fingerprint != profile_fingerprint:
        raise ValueError('Recovered event profile disagrees with approved binding')
    MutationLedger(directory / 'ledger').read(pinned=capsule['ledger_head'])
    return capsule, backup


def verify_capsule(directory, anchor_path, key, *, release_sha256, profile_fingerprint):
    capsule, backup = inspect_capsule(directory, anchor_path, key,
        release_sha256=release_sha256, profile_fingerprint=profile_fingerprint)
    anchor = r.load_anchor(anchor_path, key)
    if (backup.anchor_binding != 'latest'
            or backup.manifest_sha256 != (anchor.get('latest_backup') or {}).get('manifest_sha256')
            or int(backup.manifest['recovery_generation']) != anchor['recovery_generation']
            or int(backup.manifest['backup_sequence']) != anchor['backup_sequence_floor']):
        raise ValueError('Only the exact latest protected backup may be restored')
    return capsule, backup


def _read_receipt(directory, key):
    files = sorted(Path(directory).glob('receipt-*.json'))
    if len(files) > 24:
        raise ValueError('Recovery receipt chain is oversized')
    previous, value = '', None
    for index, path in enumerate(files, 1):
        value = _read_signed(path, key, 'recovery-receipt')
        if path.name != f'receipt-{index:03}.json' or value['previous'] != previous:
            raise ValueError('Recovery receipt chain is incomplete')
        previous = _hash(_bytes(path))
    return value, len(files), previous


def _receipt(directory, key, value, phase, **fields):
    _, sequence, previous = _read_receipt(directory, key)
    value = {**value, **fields, 'phase': phase, 'previous': previous, 'at': time.time()}
    _signed(Path(directory) / f'receipt-{sequence + 1:03}.json', value, key, 'recovery-receipt')
    return value


def _live_hash(database):
    if not os.path.lexists(database):
        return _hash(b'')
    fd, _ = r._open_regular_file(Path(database), maximum=r.DEFAULT_MAX_DATABASE_BYTES, private=True)
    try:
        return r._hash_descriptor(fd, maximum=r.DEFAULT_MAX_DATABASE_BYTES)[0]
    finally:
        os.close(fd)


def _stage_state(database, capsule, backup, receipt_id, generation, sequence):
    with r.open_verified_database(backup) as source:
        # Read the authenticated pinned descriptor, never reopen its pathname.
        with open(database, 'xb') as output:
            os.chmod(database, 0o600)
            os.lseek(source, 0, os.SEEK_SET)
            while True:
                chunk = os.read(source, 1024 * 1024)
                if not chunk:
                    break
                output.write(chunk)
            output.flush()
            os.fsync(output.fileno())
    store = Store(database)
    try:
        before = dict(backup.inspection.governance)
        unresolved = [dict(x) for x in store._connection.execute(
            "SELECT action_id,agent_id,status FROM actions WHERE status IN ('queued','dispatched','outcome_unknown')")]
        agents = [str(x[0]) for x in store._connection.execute("SELECT agent_id FROM agents WHERE enabled=1 AND agent_id != 'sentinel-relay-probes'")]
        # This preserves all receipts, approvals, baselines, trust and budgets.
        # Queued work is invalidated; possibly delivered work remains unknown.
        store.force_safe_governance(capsule['profile_fingerprint'])
        # Even a queued-at-backup action may have been delivered after the
        # snapshot. Never infer that its side effects could not have happened.
        for action in unresolved:
            store._connection.execute("UPDATE actions SET status='outcome_unknown',completed_at=NULL WHERE action_id=?",
                                      (action['action_id'],))
        record = {'receipt_id': receipt_id, 'status': 'held', 'original_governance': before,
                  'agents_pending_reconciliation': agents,
                  'unresolved_actions': unresolved, 'ledger_head': capsule['ledger_head'],
                  'ledger_paused': capsule['ledger_paused'],
                  'uncertain_ledger_actions': capsule['uncertain_ledger_actions'],
                  'references': capsule['references'],
                  'reference_status': {name: ('present' if Path(value).exists() else 'missing')
                                       for name, value in capsule['references'].items()
                                       if name.endswith('_directory') and isinstance(value, str)},
                  'reason': 'Recovered controller requires fresh agent journals and operator Resume'}
        raw = json.dumps(record, sort_keys=True, separators=(',', ':'))
        if len(raw.encode()) > r.MAX_STATE_VALUE_BYTES:
            raise ValueError('Recovery reconciliation inventory exceeds state capacity')
        for name, value in [('recovery_generation', str(generation)), ('backup_sequence', str(sequence)),
                            ('recovery_receipt', raw)]:
            store._connection.execute('INSERT OR REPLACE INTO controller_state VALUES (?,?,?)',
                                      (name, value, time.time()))
        store._connection.commit()
    finally:
        store.close()
    return record


def _restore_capsule(directory, database, anchor_path, key, *, release_sha256,
                    profile_fingerprint, ledger_directory, receipt_directory,
                    failpoint=None, recovery_key_file=None):
    """Caller holds ControllerDatabaseLock. Repeating exact arguments resumes.

    failpoint is a test-only injectable crash boundary; it is not a CLI option.
    Existing valid divergent databases and divergent ledgers are never replaced.
    """
    database, receipt_dir, ledger_dir = map(lambda p: Path(p).absolute(),
                                           (database, receipt_directory, ledger_directory))
    for path in (database.parent, receipt_dir.parent, ledger_dir.parent):
        r._require_private_directory(path)
    receipt_dir.mkdir(mode=0o700, exist_ok=True)
    r._require_private_directory(receipt_dir)
    binding = dict(database=str(database), capsule=str(Path(directory).absolute()),
                   anchor=str(Path(anchor_path).absolute()), ledger=str(ledger_dir),
                   release_sha256=release_sha256, profile_fingerprint=profile_fingerprint,
                   recovery_key_file=str(Path(recovery_key_file).absolute()) if recovery_key_file else None)
    state, _, _ = _read_receipt(receipt_dir, key)
    if state:
        candidate = state['work_directory']
        if not isinstance(candidate, str) or Path(candidate).name != candidate or not candidate.startswith('candidate-'):
            raise ValueError('Invalid recovery staging receipt')
        working = receipt_dir / candidate
    else:
        if len(list(receipt_dir.glob('candidate-*'))) >= 3:
            raise ValueError('Interrupted preparation capacity exceeded; retain evidence and choose a fresh receipt directory')
        working = receipt_dir / ('candidate-' + uuid.uuid4().hex)
        working.mkdir(mode=0o700)
    stage = working / 'staged.db'
    if state and state['binding'] != binding:
        raise ValueError('Recovery restart arguments differ from durable receipt')
    if not state:
        capsule, backup = verify_capsule(directory, anchor_path, key,
                                         release_sha256=release_sha256,
                                         profile_fingerprint=profile_fingerprint)
        anchor = r.load_anchor(anchor_path, key)
        if anchor['phase'] != 'committed':
            raise ValueError('Pending recovery requires its original receipt directory')
        sidecars = {suffix: _live_hash(Path(str(database) + suffix))
                    for suffix in ('-wal', '-shm', '-journal') if os.path.lexists(str(database) + suffix)}
        if database.exists():
            try:
                current = r.inspect_controller_database(database, **CONSTRAINTS,
                                                         require_recovery_state=True)
            except r.RecoveryError as exc:
                if any(word in str(exc) for word in ('application_id', 'user_version', 'forbidden', 'unexpected tables', 'missing required tables')):
                    raise ValueError('Existing database identity/schema requires human review') from exc
                current = None
            if current and sidecars:
                raise ValueError('Valid database with SQLite sidecars requires checkpoint/review; no restore performed')
            if current and current.sha256 != backup.inspection.sha256:
                raise ValueError('Refusing to overwrite a different valid controller state')
        # A newer ledger must extend the exact saved chain, including its key.
        if ledger_dir.exists():
            if not (ledger_dir / 'authentication.key').exists():
                raise ValueError('Existing ledger directory lacks ownership evidence')
            ledger = MutationLedger(ledger_dir)
            ledger.read(pinned=capsule['ledger_head'])
            if ledger.key != _bytes(Path(directory) / 'ledger/authentication.key', 32):
                raise ValueError('Live ledger identity differs from capsule')
        else:
            _copy_tree(Path(directory) / 'ledger', working / 'staged-ledger', capsule['ledger_files'], ledger=True)
        live_ledger = MutationLedger(ledger_dir if ledger_dir.exists() else working / 'staged-ledger')
        capsule = {**capsule, 'ledger_paused': live_ledger.paused(),
                   'uncertain_ledger_actions': [a['action_id'] for a in live_ledger.actions()
                         if a['status'] in {'prepared','applied','uncertain','undo_prepared','boot_prepared','quiesce_prepared'}]}
        record = _stage_state(stage, capsule, backup, receipt_dir.name,
                              anchor['recovery_generation'] + 1, anchor['backup_sequence_floor'] + 1)
        _copy_tree(Path(directory) / 'inputs', working / 'restored-inputs', capsule['inputs'])
        old_hash = _live_hash(database)
        if database.exists():
            output_path = working / 'preserved-controller.db'
            fd, _ = r._open_regular_file(database, maximum=r.DEFAULT_MAX_DATABASE_BYTES, private=True)
            try:
                with open(output_path, 'xb') as output:
                    os.chmod(output_path, 0o600)
                    while True:
                        block = os.read(fd, 1024 * 1024)
                        if not block:
                            break
                        output.write(block)
                    output.flush()
                    os.fsync(output.fileno())
            finally:
                os.close(fd)
            if _live_hash(output_path) != old_hash or _live_hash(database) != old_hash:
                raise ValueError('Damaged controller evidence changed during preservation')
        state = _receipt(receipt_dir, key, {'binding': binding, 'old_hash': old_hash,
                         'new_hash': _live_hash(stage), 'prior_anchor': anchor,
                         'work_directory': working.name, 'sidecars': sidecars,
                         'preserved_database': str(working / 'preserved-controller.db') if database.exists() else None,
                         'reconciliation': record, 'ledger_files': capsule['ledger_files'],
                         'ledger_key_sha256': _hash(_bytes(Path(directory) / 'ledger/authentication.key', 32)),
                         'input_files': capsule['inputs'],
                         'controller_arguments': capsule.get('controller_arguments'),
                         'backup_manifest_sha256': backup.manifest_sha256}, 'prepared')
    def checkpoint(phase):
        if failpoint:
            failpoint(phase)
    checkpoint(state['phase'])
    if state['phase'] == 'complete':
        current = r.inspect_controller_database(database, **CONSTRAINTS, require_recovery_state=True)
        if (current.controller_instance_id != state['prior_anchor']['controller_instance_id']
                or current.recovery_generation < state['prior_anchor']['recovery_generation'] + 1):
            raise ValueError('Completed receipt no longer matches controller identity')
        return state
    anchor = r.load_anchor(anchor_path, key)
    if anchor == state['prior_anchor']:
        if _live_hash(database) != state['old_hash'] or _live_hash(stage) != state['new_hash']:
            raise ValueError('Recovery state changed before anchor reservation')
        anchor = r.begin_pending_anchor(anchor_path, key, anchor, state['new_hash'],
                                        previous_database_sha256=state['old_hash'],
                                        pending_backup_sequence=anchor['backup_sequence_floor'] + 1)
    elif (anchor['controller_instance_id'] != state['prior_anchor']['controller_instance_id']
          or anchor['recovery_generation'] != state['prior_anchor']['recovery_generation'] + 1):
        raise ValueError('Recovery anchor no longer belongs to this transaction')
    checkpoint('anchor_pending')
    if anchor['phase'] == 'pending':
        if anchor['pending_database_sha256'] != state['new_hash']:
            raise ValueError('Pending anchor belongs to another database')
        for suffix, expected in state.get('sidecars', {}).items():
            original, preserved = Path(str(database) + suffix), working / ('preserved' + suffix)
            if os.path.lexists(original):
                if _live_hash(original) != expected or preserved.exists():
                    raise ValueError('SQLite sidecar changed during recovery')
                os.replace(original, preserved)
                r._fsync_directory(database.parent)
                r._fsync_directory(working)
            if not preserved.exists() or _live_hash(preserved) != expected:
                raise ValueError('SQLite sidecar preservation is incomplete')
        if _live_hash(database) != state['new_hash']:
            if _live_hash(database) != state['old_hash'] or _live_hash(stage) != state['new_hash']:
                raise ValueError('Database changed during recovery; held')
            if any(Path(str(database) + suffix).exists() for suffix in ('-wal', '-shm', '-journal')):
                raise ValueError('SQLite sidecars appeared during recovery')
            os.replace(stage, database)
            r._fsync_directory(database.parent)
        checkpoint('database_replaced')
    if _tree(working / 'restored-inputs') != state['input_files']:
        raise ValueError('Recovered input material changed before completion')
    if not ledger_dir.exists():
        if _tree(working / 'staged-ledger', skip_lock=True) != state['ledger_files']:
            raise ValueError('Staged rollback ledger changed')
        os.replace(working / 'staged-ledger', ledger_dir)
        r._fsync_directory(ledger_dir.parent)
    ledger = MutationLedger(ledger_dir)
    with ledger.lock():
        ledger.read(pinned=state['reconciliation']['ledger_head'])
        if _hash(ledger.key) != state['ledger_key_sha256']:
            raise ValueError('Recovered ledger key differs')
        checkpoint('ledger_reconciled')
        inspection = r.inspect_controller_database(database, **CONSTRAINTS, require_recovery_state=True)
        if inspection.sha256 != state['new_hash']:
            raise ValueError('Recovered database changed before final commit')
        if anchor['phase'] == 'pending':
            r.commit_pending_anchor(anchor_path, key, anchor,
                                    live_controller_instance_id=inspection.controller_instance_id,
                                    live_recovery_generation=inspection.recovery_generation,
                                    live_database_sha256=inspection.sha256,
                                    live_backup_sequence=inspection.backup_sequence)
        checkpoint('anchor_committed')
        launch_config = None
        if state.get('controller_arguments') and recovery_key_file:
            launch_config = receipt_dir / 'controller-config.json'
            arguments = list(state['controller_arguments'])
            replacements = {'--' + role.replace('_', '-'): str(working / 'restored-inputs' / role)
                            for role in state['input_files']}
            replacements.update({'--database': str(database), '--recovery-anchor': str(Path(anchor_path).absolute()),
                                 '--recovery-key-file': str(Path(recovery_key_file).absolute())})
            for option, value in replacements.items():
                if option in arguments:
                    arguments[arguments.index(option) + 1] = value
                elif any(x.startswith(option + '=') for x in arguments):
                    arguments = [option + '=' + value if x.startswith(option + '=') else x for x in arguments]
                else:
                    arguments.extend([option, value])
            encoded = json.dumps({'controller_arguments': arguments}, sort_keys=True).encode()
            if launch_config.exists():
                if _bytes(launch_config) != encoded:
                    raise ValueError('Recovered launch configuration changed')
            else:
                _write(launch_config, encoded)
        state = _receipt(receipt_dir, key, state, 'complete',
                         controller_config=str(launch_config) if launch_config else None,
                         ledger_head_after=ledger.head(), ledger_paused_after=ledger.paused(),
                         restored_inputs=str(working / 'restored-inputs'),
                         held=True, ready_for_observation=not ledger.paused())
    return state


def status(store):
    with store._lock:
        row = store._connection.execute("SELECT state_value FROM controller_state WHERE state_key='recovery_receipt'").fetchone()
    return json.loads(row[0]) if row else {'status': 'not-restored'}


def capsule_material_size(ledger_directory, artifacts):
    ledger = MutationLedger(ledger_directory)
    with ledger.lock():
        size = sum(x['bytes'] for x in _tree(ledger.directory, skip_lock=True).values())
    return size + sum(Path(p).stat().st_size for p in artifacts.values()) + MAX_DOCUMENT


def prune_capsules(directory, anchor_path, key, *, keep, maximum_bytes):
    root = Path(directory)
    r._require_private_directory(root)
    anchor = r.load_anchor(anchor_path, key)
    latest = (anchor.get('latest_backup') or {}).get('backup_id')
    candidates = []
    for index, path in enumerate(root.iterdir()):
        if index >= 10000:
            raise ValueError('Backup root capacity exceeded')
        if not path.name.endswith('.sbrecovery') or path.is_symlink() or not path.is_dir():
            continue
        try:
            info = _read_signed(path / 'capsule.json', key, 'recovery-capsule')
            name = info['backup']
            if Path(name).name != name or {p.name for p in path.iterdir()} != {'capsule.json', name, 'inputs', 'ledger'}:
                continue
            verified = r.verify_backup_bundle(path / name, key, **CONSTRAINTS,
                         expected_controller_instance_id=anchor['controller_instance_id'])
            if verified.manifest_sha256 != info['manifest_sha256']:
                continue
            if _tree(path / 'inputs') != info['inputs'] or _tree(path / 'ledger', skip_lock=True) != info['ledger_files']:
                continue
            MutationLedger(path / 'ledger').read(pinned=info['ledger_head'])
            size = verified.inspection.size_bytes + sum(v['bytes'] for field in ('inputs', 'ledger_files') for v in info[field].values()) + MAX_DOCUMENT
            candidates.append((int(verified.manifest['backup_sequence']), verified.manifest['backup_id'], path, size))
        except (ValueError, OSError, RuntimeError, KeyError):
            continue  # Unrecognized material is never removed to make room.
    candidates.sort(reverse=True)
    total = sum(x[3] for x in candidates)
    count = len(candidates)
    protected = {x[2] for x in candidates[:2]} | {x[2] for x in candidates if x[1] == latest}
    removed = []
    for sequence, backup_id, path, size in reversed(candidates):
        if path in protected or (count <= max(2, keep) and total <= maximum_bytes):
            continue
        shutil.rmtree(path)
        removed.append(path.name)
        total -= size
        count -= 1
    if removed:
        r._fsync_directory(root)
    return removed


def restore_capsule(directory, database, anchor_path, key, **options):
    try:
        return _restore_capsule(directory, database, anchor_path, key, **options)
    except Exception as exc:
        # Rejected attempts are separate from the transaction's resumable
        # phase chain; a failed preflight never becomes a prepared restore.
        try:
            root = Path(options['receipt_directory']).absolute()
            root.mkdir(mode=0o700, exist_ok=True)
            r._require_private_directory(root)
            existing = sorted(root.glob('rejection-*.json'))
            if len(existing) >= 256:
                raise ValueError('Recovery rejection receipt capacity exhausted')
            previous = _hash(_bytes(existing[-1])) if existing else ''
            _signed(root / f'rejection-{len(existing)+1:03}.json',
                    {'phase': 'rejected-or-held', 'at': time.time(), 'previous': previous,
                     'database': str(Path(database).absolute()), 'capsule': str(Path(directory).absolute()),
                     'error_type': type(exc).__name__, 'reason': str(exc)[:1000]}, key, 'recovery-receipt')
        except Exception as receipt_error:
            exc.add_note('Rejection receipt could not be saved: ' + str(receipt_error)[:200])
        raise


def verify_receipts(directory, key):
    current, count, head = _read_receipt(directory, key)
    previous, rejections = '', []
    paths = sorted(Path(directory).glob('rejection-*.json'))
    if len(paths) > 256:
        raise ValueError('Recovery rejection receipt capacity exceeded')
    for index, path in enumerate(paths, 1):
        value = _read_signed(path, key, 'recovery-receipt')
        if path.name != f'rejection-{index:03}.json' or value['previous'] != previous:
            raise ValueError('Recovery rejection chain is incomplete')
        previous = _hash(_bytes(path))
        rejections.append(value)
    if not current and not rejections:
        raise ValueError('No recovery receipts are present')
    return {'verified': True, 'transaction_records': count, 'receipt_head': head,
            'receipt': current, 'rejections': rejections, 'rejection_head': previous}
