"""Windows/Linux desktop companion. All widget access stays on the Tk thread."""

from __future__ import annotations

import json
import os
import queue
import sys
import threading
import time
from pathlib import Path

from . import __version__
from .credential_vault import private_directory
from .desktop_control import DesktopClient, verification_rows
from .desktop_credentials import DesktopCredentials, credential_requirements
from .desktop_jobs import detach, prepare, launch_job, start_controller
from .job_control import JobControl, SetupPaused
from .setup import plan_digest, summarize_plan
from .state import read_private_json, read_private_text, write_private_json


from .desktop_withdrawal import WithdrawalControls
from .desktop_recovery import RecoveryControls
from .linux_desktop_setup import LinuxSetupControls
from .desktop_management import ManagementControls
from .desktop_service_actions import ServiceActionControls


CHOICE_GUIDANCE = {
    'alert': 'Approve: apply the recommended action.  Observe: record that you reviewed it and '
             'take no action.  Reject: record that this is unwanted and take no action.',
    'baseline': 'Approve: accept this first inventory as the known-good baseline for recovery.',
    'outcome': 'Say whether the action actually executed on the host. Sentinel never guesses this.',
    'undo-review': 'Reviewed: you checked the service after the failed undo. Accepted only when the agent\'s '
                   'latest observation, collected after the failure, reports no interrupted change.',
}


def governance_label(governance, host_paused=None):
    """Describe whether automatic changes can actually run right now."""
    mode = governance.get('autonomy_mode', 'unknown')
    approved = governance.get('profile_autonomy_mode')
    allowed = governance.get('automatic_allowed')
    if allowed is None:  # a controller that predates automatic_allowed
        allowed = mode not in {'observe', 'unknown'} and not governance.get('emergency_stopped')
    restore = (' · Resume restores the approved ' + approved + ' mode'
               if approved and approved != mode else '')
    if governance.get('emergency_stopped'):
        return f'Mode: {mode} · Automatic changes: paused' + (restore or ' · Resume to continue')
    if host_paused:
        return (f'Mode: {mode} · Automatic changes: paused by the host-wide Pause or Withdraw'
                ' (Resume here does not clear it; continuity-resume does)')
    if not allowed:
        return f'Mode: {mode} · Automatic changes: off' + restore
    if governance.get('automatic_recovery') is False:
        return f'Mode: {mode} · Automatic changes: on, but service recovery waits for approval'
    return f'Mode: {mode} · Automatic changes: on, as the event profile allows'


class DesktopWindow(WithdrawalControls, RecoveryControls, LinuxSetupControls, ManagementControls, ServiceActionControls):
    def __init__(self, root, config=None, *, directory=None):
        import tkinter as tk
        from tkinter import ttk, messagebox, filedialog
        self.tk, self.ttk, self.messagebox, self.filedialog = tk, ttk, messagebox, filedialog
        self.root, self.config = root, config or {}
        self.directory = Path(directory or Path.home() / '.sentinel-blue-desktop')
        self.guard = private_directory(self.directory)
        self.client = None
        self.generation = 0
        self.closed = False
        self.events = queue.SimpleQueue()
        self.jobs = queue.Queue(maxsize=4)
        self.job_control = JobControl(self.directory)
        self.job_control.initialize()
        self.control_jobs = queue.SimpleQueue()
        self.control_revision = 0
        self.control_pending = set()
        self.worker_stop = threading.Event()
        self.lock_requested = threading.Event()
        self.credentials = DesktopCredentials()
        self.snapshot = {}
        self.prompts = {}
        self.seen = set()
        self.plan = None
        self.job_path = None
        self.job_process = None
        self.job_outcome_unknown = False
        self.setup_starting = False
        self.controller_starting = False
        self.background_controller = None
        self.next_poll = 0
        self.polling = False
        self.messages = []
        # The approved network setup a redo may run again (2.0.6); None until one
        # is approved from this window.
        self.network_redo_workspace = self._saved_network_redo()
        self.next_redo_tick = 0.0
        self.redo_ticking = False
        root.title(f'Sentinel Blue {__version__}' + (' · Linux GUI 1' if sys.platform.startswith('linux') else ''))
        root.geometry('1120x760')
        root.minsize(900, 620)
        root.configure(bg='#101923')
        style = ttk.Style(root)
        style.theme_use('clam')
        style.configure('.', background='#101923', foreground='#edf3f8', font=('Segoe UI', 10))
        style.configure('TFrame', background='#101923')
        style.configure('TLabel', background='#101923')
        style.configure('Title.TLabel', font=('Segoe UI', 23, 'bold'))
        style.configure('Subtitle.TLabel', foreground='#a8bacb')
        style.configure('TButton', padding=(12, 7), background='#29435a')
        style.map('TButton', background=[('active', '#376080'), ('disabled', '#243342')])
        style.configure('TEntry', fieldbackground='#1b2b3a', foreground='#f5f7fa', insertcolor='white')
        style.configure('TCombobox', fieldbackground='#1b2b3a', foreground='#f5f7fa')
        style.map('TCombobox', fieldbackground=[('readonly', '#1b2b3a')], foreground=[('readonly', '#f5f7fa')])
        style.configure('Treeview', background='#172636', fieldbackground='#172636', foreground='#edf3f8', rowheight=31)
        style.configure('Treeview.Heading', background='#243b50', foreground='#edf3f8', padding=7)
        style.map('Treeview', background=[('selected', '#345c79')])
        style.configure('TNotebook', background='#101923', borderwidth=0)
        style.configure('TNotebook.Tab', background='#203447', padding=(16, 9))
        style.map('TNotebook.Tab', background=[('selected', '#376080')])
        top = ttk.Frame(root, padding=(22, 18))
        top.pack(fill='x')
        ttk.Label(top, text='SENTINEL BLUE', style='Title.TLabel').pack(side='left')
        self.status = tk.StringVar(value='Connect to your defender')
        ttk.Label(top, textvariable=self.status, style='Subtitle.TLabel').pack(side='right')
        toolbar = ttk.Frame(root, padding=(22, 0, 22, 12))
        toolbar.pack(fill='x')
        ttk.Label(toolbar, text=('Configure services and respond to alerts here. Monitoring continues when minimized.'
            if sys.platform.startswith('linux') else 'Defense keeps running while you work in your own terminal.'), style='Subtitle.TLabel').pack(side='left')
        ttk.Button(toolbar, text='Minimize', command=root.iconify).pack(side='right', padx=4)
        ttk.Button(toolbar, text='Lock window', command=self.lock).pack(side='right', padx=4)
        linux_desktop = sys.platform.startswith('linux')
        if linux_desktop:
            navigation = ttk.Frame(root, padding=(22, 0, 22, 10))
            navigation.pack(fill='x')
            style.layout('Linux.TNotebook.Tab', [])
        self.notebook = ttk.Notebook(root, **({'style': 'Linux.TNotebook'} if linux_desktop else {}))
        self.notebook.pack(fill='both', expand=True, padx=22, pady=(0, 14))
        self.tabs = {}
        tab_names = ('Session', 'Services', 'Alerts & verification', 'Credentials', 'Service setup', 'Setup', 'Withdraw', 'Recovery', 'Connection')
        if linux_desktop:
            tab_names = ('Start here', 'Service setup', 'Setup', 'Services', 'Alerts & verification',
                         'Credentials', 'Session', 'Withdraw', 'Recovery', 'Connection')
        for index, name in enumerate(tab_names):
            tab = ttk.Frame(self.notebook, padding=14)
            self.notebook.add(tab, text=name)
            self.tabs[name] = tab
            if linux_desktop:
                ttk.Button(navigation, text=name, command=lambda t=tab: self.notebook.select(t)).grid(
                    row=index//5, column=index%5, sticky='ew', padx=2, pady=2)
                navigation.columnconfigure(index%5, weight=1)
        self._session()
        self._messages(self.tabs['Session'])
        self._services()
        self._reviews()
        self._credentials()
        self._service_chooser()
        self._setup()
        self._connection()
        self._withdrawal()
        self._recovery()
        self.footer = tk.StringVar(value='Window ready. Existing services continue independently.')
        self.footer_label = ttk.Label(root, textvariable=self.footer, style='Subtitle.TLabel', padding=(22, 0, 22, 12))
        self.footer_label.pack(side='bottom', fill='x', before=self.notebook)
        root.protocol('WM_DELETE_WINDOW', root.iconify)
        menu = tk.Menu(root)
        file_menu = tk.Menu(menu, tearoff=False)
        file_menu.add_command(label='Close window; keep defender running', command=self.close)
        menu.add_cascade(label='Window', menu=file_menu)
        root.configure(menu=menu)
        self.worker_thread = threading.Thread(target=self._worker, name='sentinel-desktop-work', daemon=True)
        self.worker_thread.start()
        self.control_thread = threading.Thread(target=self._control_worker, name='sentinel-desktop-control', daemon=False)
        self.control_thread.start()
        self.tick_timer = root.after(100, self._tick)
        if linux_desktop:
            self._linux_start()
        self.notebook.select(self.tabs['Start here' if linux_desktop else 'Connection'])
        root.deiconify()

    def note(self, text):
        """Show a message and retain it; the footer alone loses earlier errors."""
        text = ''.join(c for c in str(text) if c.isprintable())[:300].strip()
        if not text:
            return
        stamp = time.strftime('%H:%M:%S')
        self.footer.set(text)
        messages = getattr(self, 'messages', None)
        if messages is None:
            messages = self.messages = []
        messages.append(stamp + '  ' + text)
        del messages[:-200]
        widget = getattr(self, 'message_log', None)
        if widget is not None and widget.winfo_exists():
            widget.configure(state='normal')
            widget.insert('end', stamp + '  ' + text + '\n')
            widget.see('end')
            widget.configure(state='disabled')

    def _tree(self, parent, columns, widths):
        frame = self.ttk.Frame(parent)
        frame.pack(fill='both', expand=True, pady=8)
        tree = self.ttk.Treeview(frame, columns=columns, show='headings', selectmode='browse')
        if sys.platform.startswith('linux'):
            tree.configure(height=5)
        for name, width in zip(columns, widths):
            tree.heading(name, text=name)
            tree.column(name, width=width, minwidth=65, stretch=True)
        bar = self.ttk.Scrollbar(frame, orient='vertical', command=tree.yview)
        tree.configure(yscrollcommand=bar.set)
        tree.pack(side='left', fill='both', expand=True)
        bar.pack(side='right', fill='y')
        for tag, color in [('healthy', '#94e4bf'), ('unhealthy', '#ff9b99'), ('stale', '#f2c678'), ('unknown', '#a8bacb')]:
            tree.tag_configure(tag, foreground=color)
        return tree

    def _entry(self, parent, row, label, value='', *, secret=False, browse=False):
        self.ttk.Label(parent, text=label).grid(row=row, column=0, sticky='w', padx=(0, 14), pady=7)
        variable = self.tk.StringVar(value=value)
        self.ttk.Entry(parent, textvariable=variable, show='*' if secret else '').grid(row=row, column=1, sticky='ew', pady=7)
        parent.columnconfigure(1, weight=1)
        if browse:
            self.ttk.Button(parent, text='Browse', command=lambda: self._browse(variable)).grid(row=row, column=2, padx=8)
        return variable

    def _browse(self, variable):
        value = self.filedialog.askopenfilename(parent=self.root)
        if value:
            variable.set(value)

    def _services(self):
        tab = self.tabs['Services']
        self.summary = self.tk.StringVar(value='Service health appears after connecting.')
        self.ttk.Label(tab, textvariable=self.summary).pack(anchor='w')
        self.storage_summary = self.tk.StringVar(value='Storage usage appears after connecting.')
        self.ttk.Label(tab, textvariable=self.storage_summary, wraplength=980).pack(anchor='w')
        self.service_reasons = self.tk.StringVar(value='')
        self.ttk.Label(tab, textvariable=self.service_reasons, wraplength=980, style='Subtitle.TLabel').pack(anchor='w')
        self.services = self._tree(tab, ('System', 'Service', 'Local health', 'Process', 'Checks', 'Recovery', 'External health'), (105, 165, 90, 75, 55, 360, 120))
        # Reserve controls before the expandable table consumes the available
        # height. Emergency actions must remain usable at the minimum size.
        controls = self.ttk.Frame(tab)
        controls.pack(side='bottom', fill='x', before=self.services.master)
        self.governance = self.tk.StringVar(value='')
        self.ttk.Label(controls, textvariable=self.governance, wraplength=980, style='Subtitle.TLabel').pack(anchor='w', pady=8)
        self.setup_governance = self.tk.StringVar(value='')
        self.ttk.Label(controls, textvariable=self.setup_governance, wraplength=980, style='Subtitle.TLabel').pack(anchor='w')
        buttons = self.ttk.Frame(controls)
        buttons.pack(fill='x')
        self.ttk.Button(buttons, text='Pause automatic changes', command=lambda: self._governance('emergency-stop')).pack(side='left')
        self.ttk.Button(buttons, text='Resume approved changes', command=lambda: self._governance('resume')).pack(side='left', padx=8)
        self.ttk.Button(buttons, text='Emergency removal…', command=lambda: self.notebook.select(self.tabs['Withdraw'])).pack(side='left', padx=8)
        if sys.platform.startswith('linux'):
            actions = self.ttk.Frame(controls)
            actions.pack(fill='x', pady=(6, 0))
            self.ttk.Button(actions, text='Choose action / Undo…', command=self.open_service_actions).pack(side='left')
            self.ttk.Label(actions, text='Select a VM/service above. Includes reviewable actions, exact-journal undo and per-service recovery budgets.',
                           wraplength=680).pack(side='left', padx=10)

    def _session(self):
        tab = self.tabs['Session']
        self.session_busy = False
        from .recording import status as recording_status, current as current_recorder
        local_status = recording_status()
        initial = ('Local recording: ' + local_status.get('state', 'unavailable')
                   + '. Connect to include controller evidence.')
        if local_status.get('state') == 'unavailable':
            initial = 'Local recording is unavailable. Press Start to retry and review storage if it fails.'
        self.session_status = self.tk.StringVar(value=initial)
        self.ttk.Label(tab, text='Range session', style='Title.TLabel').pack(anchor='w')
        self.ttk.Label(tab, textvariable=self.session_status, wraplength=950).pack(anchor='w', pady=16)
        self.ttk.Label(tab, text='Start records your session. A reviewed setup plan can then configure the declared services. '
            'Existing agents and approved defenses continue independently of this window. '
            'Stop & save ends recording and creates one ZIP for you to copy to your laptop; defense keeps running.',
            wraplength=950).pack(anchor='w', pady=12)
        controls = self.ttk.Frame(tab)
        controls.pack(fill='x', pady=12)
        self.start_session_button = self.ttk.Button(controls, text='Start', command=self.start_session)
        self.start_session_button.pack(side='left')
        self.stop_session_button = self.ttk.Button(controls, text='Stop & save', command=self.stop_session)
        self.stop_session_button.pack(side='left', padx=10)
        self.ttk.Label(tab, text='Records sampled host state, service checks, setup progress, decisions, actions, and collection gaps. '
            'Passwords, keystrokes, packet contents, command output, and raw log messages are excluded. '
            'No automatic upload or external AI is used. The ZIP still contains private host and service information.',
            wraplength=950, style='Subtitle.TLabel').pack(anchor='w', pady=12)
        self.recording_location = self.tk.StringVar(value='The saved file location will appear here.')
        recorder = current_recorder()
        if recorder is not None and local_status.get('export_name'):
            self.recording_location.set('Automatic recovery copy: ' + str(recorder.directory/local_status['export_name']))
        self.ttk.Label(tab, textvariable=self.recording_location, wraplength=950).pack(anchor='w', pady=12)

    def start_session(self):
        if self.session_busy:
            return
        from .recording import current, initialize
        recorder = current()
        if recorder is None:
            from argparse import Namespace
            recorder = initialize(Namespace(command='desktop', recording_directory=str(self.directory/'recordings')))
        if recorder is None:
            self.note('Recording is unavailable. Review local storage before starting the range.')
            return
        client = self.client
        def start():
            local = recorder.start()
            remote = client.request('/api/v1/recording/start', {}) if client else None
            recorder.emit('operator_session_start', {'controller_connected': remote is not None})
            return local, remote
        def done(result):
            self.session_busy = False
            local, remote = result
            self.session_status.set('Recording · controller connected' if remote else 'Recording locally · controller is not connected; its evidence is not yet included')
            self.recording_location.set('Automatic recovery copy: ' + str(recorder.directory/local['export_name']))
            if self.plan is not None:
                self.execute_setup()
        def failed(_):
            self.session_busy = False
            self.session_status.set('Start did not finish. Existing evidence is preserved; check recording storage and the controller connection, then retry.')
        self.session_busy = True
        self.session_status.set('Starting recording and verifying the previous session archive…')
        if not self.submit(start, done, failed, preserve=True):
            self.session_busy = False

    def stop_session(self):
        if self.session_busy:
            return
        from .recording import current, make_session_bundle
        recorder = current()
        if recorder is None:
            self.note('No local recorder is available. Reconnect to save controller evidence.')
            return
        client = self.client
        runtime = Path(self.runtime_path.get()).absolute()
        destination_root = (runtime.parent if runtime.is_file() else self.directory) / 'Sentinel-Blue-recordings'
        # Capture immutable values on the UI thread; workers never access Tk.
        def save():
            remote = None
            if client:
                try:
                    remote = client.save_recording(self.directory/'downloads')
                except Exception as exc:
                    recorder.emit('controller_export_unavailable', {'error_type': type(exc).__name__})
            recorder.emit('operator_session_stop', {'controller_export_included': remote is not None})
            stopped = recorder.stop()
            local = recorder.export()
            path = destination_root / ('Sentinel-Blue-session-' + stopped['session_id'] + '.zip')
            result = make_session_bundle(path, ([remote] if remote else []) + [local])
            return result, remote is not None
        def done(result):
            self.session_busy = False
            path, connected = result
            self.session_status.set('Recording stopped · file verified' + ('' if connected else ' · local evidence only; controller export was unavailable and its recording may still be active'))
            self.recording_location.set('Copy this file to your laptop: ' + str(path))
            self.note('Session saved. Copy the ZIP to your laptop for later analysis. Defense continues.')
        def failed(_):
            self.session_busy = False
            self.session_status.set('Save did not complete. Existing local recordings are preserved. Reconnect and retry Stop & save.')
        self.session_busy = True
        self.session_status.set('Stopping and verifying the recording… Large sessions can take several minutes; this window remains responsive.')
        if not self.submit(save, done, failed, preserve=True):
            self.session_busy = False

    def _messages(self, tab):
        self.ttk.Label(tab, text='Recent messages', style='Subtitle.TLabel').pack(anchor='w', pady=(12, 2))
        self.message_log = self.tk.Text(tab, height=6, wrap='word', bg='#172636', fg='#edf3f8',
                                        relief='flat', padx=10, pady=8, state='disabled')
        self.message_log.pack(fill='both', expand=False)
        for line in self.messages[-50:]:
            self.message_log.configure(state='normal')
            self.message_log.insert('end', line + '\n')
            self.message_log.configure(state='disabled')

    def _reviews(self):
        tab = self.tabs['Alerts & verification']
        self.review_count = self.tk.StringVar(value='No current verification requests')
        self.ttk.Label(tab, textvariable=self.review_count).pack(anchor='w')
        controls = tab
        if sys.platform.startswith('linux'):
            controls = self.ttk.Frame(tab)
            controls.pack(side='bottom', fill='x')
        self.reviews = self._tree(tab, ('Severity', 'Type', 'System', 'Request'), (90, 95, 165, 550))
        for name, colour in (('critical', '#f2b8b5'), ('high', '#f6c177'), ('medium', '#e8e3c8'), ('low', '#cfe3d4')):
            self.reviews.tag_configure(name, foreground=colour)
        self.reviews.bind('<Double-1>', lambda _e: self.review())
        self.ttk.Button(controls, text='Review selected request', command=self.review).pack(anchor='w')
        self.notify = self.tk.BooleanVar(value=True)
        self.ttk.Checkbutton(controls, text='Show a popup when new verification is needed', variable=self.notify).pack(anchor='w', pady=8)
        self.show_history = self.tk.BooleanVar(value=False)
        self.ttk.Checkbutton(controls, text='Include resolved alerts', variable=self.show_history,
            command=lambda: self.render(self.snapshot) if self.snapshot else None).pack(anchor='w')

    def _credentials(self):
        tab = self.tabs['Credentials']
        form = self.ttk.Frame(tab)
        form.pack(fill='x')
        self.vault_path = self._entry(form, 0, 'Encrypted vault', str(self.directory / 'vault'))
        self.vault_pass = self._entry(form, 1, 'Vault passphrase', secret=True)
        self.ttk.Button(form, text='Unlock / create vault', command=self.unlock_vault).grid(row=1, column=2, padx=8)
        self.credential_list = self._tree(tab, ('Credential', 'Kind', 'User', 'Runtime file'), (210, 90, 160, 400))
        controls = self.ttk.Frame(tab)
        controls.pack(fill='x')
        self.ttk.Button(controls, text='Add credential', command=self.add_credential).pack(side='left')
        self.ttk.Button(controls, text='Supply selected credential', command=self.supply_credential).pack(side='left', padx=8)
        self.ttk.Button(controls, text='Check required credentials', command=self.required_credentials).pack(side='left')
        self.ttk.Label(tab, text='Supplied credentials remain in private runtime files so background jobs can use them. Locking the vault closes access to its encrypted entries.',
                       wraplength=980, style='Subtitle.TLabel').pack(anchor='w', pady=12)

    def _setup(self):
        tab = self.tabs['Setup']
        form = self.ttk.Frame(tab)
        form.pack(fill='x')
        self.inventory_path = self._entry(form, 0, 'Event inventory', self.config.get('inventory', ''), browse=True)
        self.profile_path = self._entry(form, 1, 'Event profile', self.config.get('event_profile', ''), browse=True)
        runtime = str(Path(sys.argv[0]).absolute())
        self.runtime_path = self._entry(form, 2, 'Approved script', self.config.get('runtime', runtime), browse=True)
        self.setup_kind = self.tk.StringVar(value='setup')
        self.ttk.Label(form, text='Operation').grid(row=3, column=0, sticky='w')
        self.ttk.Combobox(form, textvariable=self.setup_kind, values=('setup', 'opening'), state='readonly').grid(row=3, column=1, sticky='w', pady=7)
        self.range_mode = self.tk.BooleanVar(value=False)
        self.ttk.Checkbutton(form, text='Disposable range profile', variable=self.range_mode).grid(row=4, column=1, sticky='w')
        # Choosing services produces a reviewed plan fragment, never a change.
        # Approval below stays the only route to execution.
        # Review and approval are packed against the bottom first, so nothing
        # above can push the only route to execution off-screen.
        controls = self.ttk.Frame(tab)
        controls.pack(side='bottom', fill='x')
        self.ttk.Button(controls, text='Review setup plan', command=self.review_setup).pack(side='left')
        self.start_setup = self.ttk.Button(controls, text='Approve and start in background', command=self.execute_setup, state='disabled')
        self.start_setup.pack(side='left', padx=8)
        if sys.platform.startswith('linux'):
            self.ttk.Button(controls, text='Change local choices', command=self.discard_local_plan).pack(side='left')
            self.ttk.Button(controls, text='Grant repair to every service…', command=self.grant_profile_repair).pack(side='left', padx=8)
        self.setup_text = self.tk.Text(tab, height=10, wrap='word', bg='#172636', fg='#edf3f8', relief='flat', padx=10, pady=10)
        self.setup_text.pack(fill='both', expand=True, pady=12)
        self.setup_text.insert('1.0', 'Load your event inventory to review the services, dependencies, and configuration changes.')
        self.setup_text.configure(state='disabled')

    def _service_chooser(self):
        """Pick the services this host should run. Selection produces a plan."""
        tab = self.tabs['Service setup']
        actions = self.ttk.Frame(tab)
        actions.pack(side='bottom', fill='x', pady=(8, 0))
        self.ttk.Button(actions, text='Save selected services as a plan',
                        command=self.save_service_plan).pack(side='left')
        self.ttk.Button(actions, text='Merge into inventory copy…', command=self.merge_service_plan).pack(side='left', padx=6)
        self.ttk.Label(actions, text='Saved plans are reviewed and approved on the Setup tab; '
                                     'nothing is changed here.',
                       style='Subtitle.TLabel', wraplength=780).pack(side='bottom', anchor='w', pady=4)
        if sys.platform.startswith('linux'):
            self.ttk.Button(actions, text='Review local setup', command=self.prepare_local_setup).pack(side='left', padx=6)
            extra = self.ttk.Frame(tab)
            extra.pack(side='bottom', fill='x')
            self.ttk.Button(extra, text='Service check…', command=self.edit_service_check).pack(side='left')
            self.ttk.Label(extra, text='Double-click to select. Configure parameters, then choose Automatic or Manual ports.',
                           wraplength=700).pack(side='left', padx=12)
        from .desktop_services import ServiceSelectionPanel
        self.service_panel = ServiceSelectionPanel(tab, (self.tk, self.ttk), port_context_provider=self.port_context)

    def save_service_plan(self):
        """Write the chosen services out as a plan fragment for ordinary review."""
        from .desktop_services import service_plan
        from .state import write_private_json
        panel = getattr(self, 'service_panel', None)
        if panel is None:
            return
        report = panel.report()
        if report['blocking']:
            self.note('Service selection has unresolved issues: ' + '; '.join(report['blocking'])[:400])
            return
        host = (self.agent_for_setup() or '').strip()
        if not host:
            self.note('Select a host with reported telemetry before saving a service plan.')
            return
        try:
            plan = service_plan(panel.selection, host, manager='apt', options=panel.options, presence=panel.presence,
                                custom=panel.custom_services)
            destination = Path(self.inventory_path.get() or '.').expanduser().absolute()
            target = (destination if destination.is_dir() else destination.parent) / 'sentinel-service-plan.json'
            write_private_json(target, plan)
        except (OSError, ValueError) as exc:
            self.note('Could not save the service plan: ' + str(exc)[:300])
            return
        self.note(f'Saved {len(plan["tasks"])} service task(s) to {target}. '
                  'Review it before approving; no service has been changed.')

    def merge_service_plan(self):
        """Preview a full, scoped inventory copy; never apply through the chooser."""
        import hashlib
        from .desktop_services import service_plan, merge_service_fragment
        from .launcher import load_inventory
        from .event_profile import load_event_profile
        from .setup import compile_plan
        if self.job_path is not None or self.setup_starting:
            self.note('Finish reviewing the current job before preparing a new inventory.')
            return
        try:
            path = Path(self.inventory_path.get()).expanduser().absolute()
            if not path.is_file():
                raise ValueError('Load the complete event inventory on Setup first')
            original = path.read_bytes()
            inventory = load_inventory(path)
            profile = load_event_profile(Path(self.profile_path.get() or path))
            panel = self.service_panel
            fragment = service_plan(panel.selection, self.agent_for_setup(), manager='apt',
                                    options=panel.options, presence=panel.presence, custom=panel.custom_services)
            merged = merge_service_fragment(inventory, fragment)
            compiled = compile_plan(merged, profile, path.parent)
            reviewed = plan_digest(compiled)
            summary = summarize_plan(compiled)
            if not self.messagebox.askyesno('Review inventory merge',
                    'Create a NEW inventory copy with these tasks? The original inventory, scope, service checks '
                    'and existing tasks are preserved. No hosts are changed.\n\n' + json.dumps(summary, indent=2)[:5000], parent=self.root):
                return
            if path.read_bytes() != original:
                raise ValueError('Inventory changed during review; review again')
            # Same directory preserves all relative source paths. New name prevents
            # overwriting a teammate file or a previous approved candidate.
            import uuid
            target = path.with_name(path.stem + '-services-' + uuid.uuid4().hex[:12] + '.json')
            write_private_json(target, merged)
            if plan_digest(compile_plan(load_inventory(target), profile, target.parent)) != reviewed:
                raise ValueError('Merged inventory changed during verification; held for review')
            self.inventory_path.set(str(target))
            self.plan = None
            self.start_setup.configure(state='disabled')
            self.notebook.select(self.tabs['Setup'])
            self._setup_report('Inventory copy saved; use Review setup plan, then approve normally.\n' + json.dumps(summary, indent=2))
            self.note('Merged into a new inventory. No service has changed; ordinary profile/runtime review is still required.')
        except (OSError, ValueError, TypeError, KeyError) as exc:
            self.note('Inventory merge held: ' + str(exc)[:300])

    def port_context(self, service_id, options):
        """Read current declared constraints, not permission to invent a scorer port."""
        from .service_ports import manifest_constraints, fields_for
        from .event_profile import load_event_profile
        from .launcher import load_inventory
        host_id = self.agent_for_setup()
        context = {'host': host_id, 'required': {}, 'notice': 'No reviewed event loaded: choices remain drafts.'}
        snapshot = getattr(self, 'snapshot', None) or {}
        context['observation'] = snapshot.get('port_observations', {}).get(host_id)
        if sys.platform.startswith('linux') and getattr(self, 'local_context', None) is not None and self.local_context.get() and self.client is None:
            context['observation'] = self.local_ports
        raw = self.inventory_path.get()
        if not raw:
            return context
        path = Path(raw).expanduser().absolute()
        inventory = load_inventory(path)
        profile = load_event_profile(Path(self.profile_path.get()).expanduser().absolute() if self.profile_path.get() else path)
        matches = [h for h in inventory.get('hosts', []) if isinstance(h, dict)
                   and host_id in {h.get('name'), h.get('agent_id'), h.get('address')}]
        if len(matches) != 1:
            raise ValueError('Select exactly one inventory host before choosing event ports.')
        host = matches[0]
        ids = {host.get('name'), host.get('agent_id'), host.get('address')}
        context['required'] = manifest_constraints(service_id, options, profile.services, ids)
        if service_id == 'openssh-server' and host.get('transport') == 'ssh':
            management = host.get('port', 22)
            if 'port' in context['required'] and context['required']['port'] != management:
                raise ValueError('The SSH event and management ports disagree; reconcile them before setup.')
            context['required']['port'] = management
        context['notice'] = 'Loaded event ports are protected. Saving never rewrites approval, observers or the host management connection.'
        return context

    def agent_for_setup(self):
        """The host a service selection applies to: the one currently selected."""
        if sys.platform.startswith('linux') and getattr(self, 'local_context', None) is not None and self.local_context.get() and self.client is None:
            return 'local-linux'
        chosen = self.services.selection() if hasattr(self, 'services') else ()
        if chosen and self.services.exists(chosen[0]):
            return str(self.services.item(chosen[0], 'values')[0])
        snapshot = getattr(self, 'snapshot', None) or {}
        agents = snapshot.get('agents') or []
        return str(agents[0].get('agent_id', '')) if agents else ''

    def _connection(self):
        tab = self.tabs['Connection']
        form = self.ttk.Frame(tab)
        form.pack(fill='x')
        self.origin = self._entry(form, 0, 'Controller', self.config.get('origin', 'http://127.0.0.1:8765'))
        self.principal = self._entry(form, 1, 'Operator identity', self.config.get('principal', 'operator'))
        self.epoch = self._entry(form, 2, 'Credential epoch', str(self.config.get('epoch', 2)))
        self.ca_path = self._entry(form, 3, 'Controller CA certificate', self.config.get('ca_file', ''), browse=True)
        self.operator_key = self._entry(form, 4, 'Operator signing key', secret=True)
        controls = self.ttk.Frame(tab)
        controls.pack(fill='x', pady=14)
        self.ttk.Button(controls, text='Connect', command=self.connect).pack(side='left')
        self.ttk.Button(controls, text='Load signing key file', command=self.load_key).pack(side='left', padx=8)
        self.ttk.Button(controls, text='Save connection settings', command=self.save_settings).pack(side='left')
        self.ttk.Separator(tab).pack(fill='x', pady=20)
        self.ttk.Label(tab, text='Background controller', font=('Segoe UI', 14, 'bold')).pack(anchor='w')
        self.ttk.Label(tab, text='Start a prepared controller configuration, or connect to a controller already running as a service.',
                       wraplength=940, style='Subtitle.TLabel').pack(anchor='w', pady=10)
        self.ttk.Button(tab, text='Start prepared controller…', command=self.launch_controller).pack(anchor='w')

    def submit(self, operation, done, failed=None, *, preserve=False):
        if self.closed:
            return False
        try:
            self.jobs.put_nowait((self.generation, operation, done, failed, preserve))
            return True
        except queue.Full:
            self.note('An operation is still running. Try again after it finishes.')
            return False

    def _worker(self):
        try:
            while not self.worker_stop.is_set() or not self.jobs.empty():
                if self.lock_requested.is_set():
                    self.lock_requested.clear()
                    self.credentials.lock()
                try:
                    generation, operation, done, failed, preserve = self.jobs.get(timeout=.1)
                except queue.Empty:
                    continue
                if generation != self.generation and not preserve:
                    continue
                try:
                    result = operation()
                    event = ('done', (generation, done, preserve), result)
                except Exception as exc:
                    from .recording import emit
                    emit('desktop_operation_failed', {'error_type': type(exc).__name__})
                    event = ('error', (generation, failed, preserve), (type(exc).__name__, str(exc)[:500]))
                if not self.closed:
                    self.events.put(event)
        finally:
            self.credentials.lock()

    def _tick(self):
        if self.closed:
            return
        for _ in range(32):
            try:
                kind, callback, value = self.events.get_nowait()
            except queue.Empty:
                break
            if kind == 'control':
                revision, operation = callback
                self.control_pending.discard(operation)
                if revision == self.control_revision:
                    self.note(value)
                    self.next_poll = 0
            elif kind == 'snapshot':
                self.polling = False
                if callback == self.generation:
                    if isinstance(value, dict):
                        try:
                            self.render(value)
                        except (KeyError, TypeError, ValueError):
                            self.disconnected()
                    else:
                        self.disconnected()
            else:
                generation, handler, preserve = callback
                if generation != self.generation and not preserve:
                    continue
                try:
                    if handler is not None:
                        handler(value)
                    if kind == 'error':
                        self.note(f'{value[0]}: {value[1]}')
                except Exception as exc:
                    self.note(f'Window update failed ({type(exc).__name__}); refresh to verify current state.')
        now = time.monotonic()
        if now >= getattr(self, 'next_control_poll', 0):
            self.next_control_poll = now + 2
            try:
                paused = self.job_control.read()['paused']
                self.setup_governance.set('Setup: paused. Stopped jobs require a new reviewed run.' if paused
                                          else 'Setup: new reviewed runs allowed.')
            except (OSError, ValueError):
                self.setup_governance.set('Setup pause state unavailable; new runs are held for review.')
        if self.client is not None and not self.polling and now >= self.next_poll:
            self.polling = True
            self.next_poll = now + 4
            client, generation = self.client, self.generation
            events = self.events  # polling must not retain the Tk window
            def poll():
                try:
                    value = client.dashboard()
                except Exception:
                    value = None
                events.put(('snapshot', generation, value))
            threading.Thread(target=poll, name='sentinel-desktop-poll', daemon=True).start()
        if self.job_path is not None and now >= getattr(self, 'next_job_poll', 0):
            self.next_job_poll = now + 2
            self._poll_background_job()
        self.tick_timer = self.root.after(100, self._tick)

    def _poll_background_job(self):
        result = self.job_path.parent / 'result.json'
        try:
            report = read_private_json(result)
            if not isinstance(report, dict) or not isinstance(report.get('status'), str) or not report['status']:
                raise ValueError('Invalid job report')
        except (ValueError, OSError):
            process = self.job_process
            if process is not None and process.poll() is not None and not self.job_outcome_unknown:
                self.job_outcome_unknown = True
                self._setup_report(json.dumps({'status': 'outcome_unknown', 'job': str(self.job_path),
                    'worker_exit': process.returncode,
                    'reason': 'Worker exited without a readable completion report. Verify the service and saved job state before starting another setup.'}, indent=2))
                self.note('Setup outcome unknown. Review the saved job state; automatic retry is disabled.')
                if self.notify.get():
                    self.popup(1, destination='Setup', message='Setup stopped without a completion report. Verify the current service state before retrying.')
            return
        self._setup_report(json.dumps(report, indent=2))
        self.note('Background job finished: ' + report['status'])
        if report['status'] not in {'passed', 'ready'} and self.notify.get():
            self.popup(1, destination='Setup', message='Setup needs your review. Open the result to see what remains unresolved.')
        self.job_path = None
        self.job_process = None
        self.job_outcome_unknown = False

    def connect(self):
        key = self.operator_key.get().strip()
        self.operator_key.set('')
        try:
            client = DesktopClient(self.origin.get(), self.principal.get(), int(self.epoch.get()), key, self.ca_path.get() or None)
        except Exception as exc:
            self.note(str(exc))
            return
        self.client = client
        if sys.platform.startswith('linux') and hasattr(self, 'local_context'):
            self.local_context.set(False)
        self.generation += 1
        self.next_poll = 0
        self.status.set('Connecting…')
        self.notebook.select(self.tabs['Services'])

    def load_key(self):
        path = self.filedialog.askopenfilename(parent=self.root)
        if path:
            try:
                self.operator_key.set(read_private_text(path, 65536).strip())
            except (OSError, ValueError):
                self.note('Signing key file could not be read.')

    def lock(self):
        self.client = None
        self.generation += 1
        self.operator_key.set('')
        self.vault_pass.set('')
        self.lock_requested.set()
        self.credential_list.delete(*self.credential_list.get_children())
        self.snapshot = {}
        self.prompts = {}
        if getattr(self, 'service_panel', None) is not None:
            self.service_panel.observe({})
        for widget in self.root.winfo_children():
            if isinstance(widget, self.tk.Toplevel):
                widget.destroy()
        for tree in (self.services, self.reviews):
            tree.delete(*tree.get_children())
        self.status.set('Window locked')
        self.summary.set('Connect to see current service health.')
        self.governance.set('')
        self.notebook.select(self.tabs['Connection'])

    def disconnected(self):
        from .recording import emit
        emit('desktop_controller_unavailable')
        self.status.set('Controller unavailable — health unknown')
        for item in self.services.get_children():
            values = list(self.services.item(item, 'values'))
            values[2], values[3], values[4] = 'unknown', 'unknown', 'unverified'
            if len(values)>6:values[6]='unknown'
            self.services.item(item, values=values, tags=('unknown',))
        self.prompts = {}
        if getattr(self, 'service_panel', None) is not None:
            self.service_panel.observe({})
        self.reviews.delete(*self.reviews.get_children())
        self.review_count.set('Reconnect before verifying requests')

    def render(self, snapshot):
        from .desktop_control import storage_message
        self.snapshot = snapshot
        panel = getattr(self, 'service_panel', None)
        if panel is not None:
            presence = snapshot.get('catalog_presence', snapshot.get('controller', {}).get('catalog_presence', {}))
            host = self.agent_for_setup()
            panel.observe(presence.get(host, {}) if isinstance(presence, dict) else {}, host=host)
            panel.options_root = Path(self.inventory_path.get() or '.').expanduser().absolute().parent
        self.render_recovery(snapshot)
        from .recording import emit
        emit('desktop_snapshot', snapshot)
        recording = snapshot.get('recording', {})
        if not self.session_busy:
            text = 'Controller recording: ' + recording.get('state', 'unavailable')
            text += ' · ' + str(recording.get('events', 0)) + ' events'
            if recording.get('dropped_events') or recording.get('storage_errors_this_process'):
                text += ' · Coverage degraded; review drops and storage errors'
            self.session_status.set(text)
        self.storage_summary.set(storage_message(snapshot))
        self.status.set('Controller connected · ' + time.strftime('%H:%M:%S'))
        rows = snapshot.get('service_health', [])
        from .desktop_control import recovery_words
        recovery = {(x['agent_id'], x['service']): recovery_words(x.get('status', ''))
                    for x in snapshot.get('controller', {}).get('service_recovery_status', [])}
        selected = self.services.selection()
        self.services.delete(*self.services.get_children())
        for index, row in enumerate(rows):
            self.services.insert('', 'end', iid=str(index), values=(row['agent_id'], row['service'], row['health'], row['native_state'],
                f"{row['passed_checks']}/{row['expected_checks']}", recovery.get((row['agent_id'], row['service']), ''), row.get('external_health', 'unconfigured')), tags=('unhealthy' if row.get('local_external_disagreement') else row['health'],))
        if selected and self.services.exists(selected[0]):
            self.services.selection_set(selected[0])
        self.summary.set(f"{sum(x['health'] == 'healthy' for x in rows)} / {len(rows)} services healthy · {sum(x['health'] in {'unknown', 'stale', 'unverified'} for x in rows)} need fresh verification")
        unexplained = [f"{row['service']}: {row['reason']}" for row in rows if row.get('reason')]
        self.service_reasons.set(' · '.join(unexplained[:3]) + ('' if len(unexplained) <= 3 else f' · +{len(unexplained) - 3} more')
                                 if unexplained else '')
        governance = snapshot.get('controller', {}).get('governance', {})
        self.governance.set(governance_label(governance, snapshot.get('controller', {}).get('host_automation_paused')))
        requests = verification_rows(snapshot)
        notifications = {row['kind'] + ':' + row['id'] for row in requests}
        review_total = len(requests)
        if self.show_history.get():
            requests += [{'kind': 'history', 'id': row['alert_id'], 'host': row['agent_id'],
                          'title': row.get('title', 'Alert') + ' · ' + str(row.get('status', '')),
                          'detail': row, 'choices': [], 'severity': str(row.get('severity', 'unknown'))}
                         for row in snapshot.get('alerts', []) if row.get('status') != 'open']
        selected = self.reviews.selection()
        self.reviews.delete(*self.reviews.get_children())
        self.prompts = {}
        from .desktop_control import SEVERITY_ORDER
        requests = sorted(requests, key=lambda item: (SEVERITY_ORDER.get(item.get('severity'), 2),
                                                      item.get('kind', ''), item.get('host', '')))
        for row in requests:
            key = row['kind'] + ':' + row['id']
            self.prompts[key] = row
            severity = str(row.get('severity', 'unknown'))
            self.reviews.insert('', 'end', iid=key, values=(severity, row['kind'], row['host'], row['title']),
                                tags=(severity,))
        if selected and self.reviews.exists(selected[0]):
            self.reviews.selection_set(selected[0])
        self.review_count.set(f'{review_total} requests awaiting review')
        if sys.platform.startswith('linux'):
            self.notebook.tab(self.tabs['Alerts & verification'], text=f'Alerts & verification ({review_total})')
            if review_total:
                self.status.set(f'{review_total} need your response · Controller connected')
        new = notifications - self.seen
        self.seen = notifications
        if new and self.notify.get():
            self.popup(len(new))

    def popup(self, count, *, destination='Alerts & verification', message=None):
        if getattr(self, 'notice', None) is not None and self.notice.winfo_exists():
            return
        popup = self.tk.Toplevel(self.root)
        self.notice = popup
        popup.title('Sentinel Blue — verification needed')
        popup.attributes('-topmost', True)
        popup.configure(bg='#101923')
        popup.resizable(False, False)
        self.ttk.Label(popup, text=message or f'{count} new request(s) need your review.', padding=18, wraplength=350).pack()
        def show():
            popup.destroy()
            self.root.deiconify()
            self.notebook.select(self.tabs[destination])
        self.ttk.Button(popup, text='Review requests', command=show).pack(pady=(0, 14))
        popup.geometry('+%d+%d' % (max(0, self.root.winfo_screenwidth()-390), max(0, self.root.winfo_screenheight()-180)))
        timer = popup.after(12000, lambda: popup.destroy() if popup.winfo_exists() else None)
        popup.bind('<Destroy>', lambda event: popup.after_cancel(timer) if event.widget is popup else None, add='+')

    def review(self):
        selected = self.reviews.selection()
        if not selected or self.client is None or selected[0] not in self.prompts:
            return
        row = self.prompts[selected[0]]
        client, generation = self.client, self.generation
        window = self.tk.Toplevel(self.root)
        window.title(row['title'])
        window.geometry('760x600')
        if sys.platform.startswith('linux'):
            buttons = self.ttk.Frame(window, padding=10)
            buttons.pack(side='bottom', fill='x')
        detail = row['detail'] if isinstance(row['detail'], dict) else {}
        header = self.ttk.Frame(window, padding=(12, 12, 12, 0))
        header.pack(fill='x')
        lines = [f"{row['title']}",
                 f"Severity: {row.get('severity', 'unknown')} · Type: {row['kind']} · Host: {row['host']}"]
        if detail.get('summary'):
            lines.append(str(detail['summary'])[:400])
        if detail.get('recommended_action'):
            lines.append('Recommended action: ' + str(detail['recommended_action']).replace('_', ' '))
        if sys.platform.startswith('linux'):
            from .linux_service_forms import response_explanation
            reason, response = response_explanation(row)
            lines += ['Why this needs attention: ' + reason, 'Your response: ' + response]
        for index, line in enumerate(lines):
            self.ttk.Label(header, text=line, wraplength=720,
                           style='Subtitle.TLabel' if index else '').pack(anchor='w', pady=(0, 4))
        if row['choices']:
            self.ttk.Label(header, text=CHOICE_GUIDANCE.get(row['kind'], ''), wraplength=720,
                           style='Subtitle.TLabel').pack(anchor='w', pady=(6, 0))
        self.ttk.Label(window, text='Evidence', padding=(12, 10, 12, 0)).pack(anchor='w')
        text = self.tk.Text(window, wrap='word', padx=12, pady=12)
        text.pack(fill='both', expand=True)
        text.insert('1.0', json.dumps(row['detail'], indent=2, ensure_ascii=False))
        text.configure(state='disabled')
        if not sys.platform.startswith('linux'):
            buttons = self.ttk.Frame(window, padding=10)
            buttons.pack(fill='x')
        def choose(choice):
            if self.client is not client or generation != self.generation or selected[0] not in self.prompts:
                window.destroy()
                return
            if not self.messagebox.askyesno('Confirm verification', f'{choice.replace("_", " ").capitalize()} this request for {row["host"]}?', parent=window):
                return
            window.destroy()
            self.submit(lambda: client.decide(row, choice), lambda _: self._decision_done())
        for choice in row['choices']:
            self.ttk.Button(buttons, text=choice.replace('_', ' ').capitalize(), command=lambda c=choice: choose(c)).pack(side='left', padx=5)

    def _decision_done(self):
        self.note('Verification submitted. Refreshing current state…')
        self.next_poll = 0

    def _governance(self, operation):
        if self.closed or operation not in {'emergency-stop', 'resume'}:
            return
        if operation in self.control_pending:
            self.note('This control request is already pending; awaiting confirmation.')
            return
        if operation == 'resume' and 'emergency-stop' in self.control_pending:
            self.note('Wait for the pause result before resuming.')
            return
        prompt = ('Pause automatic changes and stop new setup transactions? Already admitted transactions finish their verification or rollback.'
                  if operation == 'emergency-stop' else
                  'Resume changes permitted by the approved event profile? This also restores the approved automation mode '
                  '(for example after a controller crash). Stopped setup jobs need a new reviewed run.')
        if self.messagebox.askyesno('Confirm change', prompt, parent=self.root):
            self.control_revision += 1
            self.control_pending.add(operation)
            self.control_jobs.put((self.control_revision, operation, self.client))
            self.note('Pause requested; awaiting local and controller confirmation.' if operation == 'emergency-stop'
                            else 'Resume requested; awaiting confirmation.')

    def _control_worker(self):
        """Control requests never wait for the ordinary UI work or network pool."""
        while not self.worker_stop.is_set() or not self.control_jobs.empty():
            try:
                revision, operation, client = self.control_jobs.get(timeout=.1)
            except queue.Empty:
                continue
            local, remote = '', 'Controller unconfirmed (not connected).'
            evidence = {'operation': operation, 'local': {'status': 'unconfirmed'},
                        'controller': {'status': 'unconfirmed', 'connected': client is not None}}
            try:
                if operation == 'resume' and revision != self.control_revision:
                    local = 'Resume superseded by a newer pause.'
                    evidence['local']['status'] = 'superseded'
                    continue
                if operation == 'emergency-stop':
                    try:
                        self.job_control.set_paused(True)
                        evidence['local']['status'] = 'paused'
                        local = 'Setup paused; admitted transactions may still be finishing.'
                    except Exception as exc:
                        local = 'Setup pause UNCONFIRMED (' + type(exc).__name__ + ').'
                        evidence['local']['error_type'] = type(exc).__name__
                remote_ok = client is None
                if client is not None:
                    try:
                        # Resume also returns a controller that a crash or a
                        # storage fault left in observe mode to the approved
                        # profile mode; otherwise it would stay off.
                        result = client.request('/api/v1/governance/' + operation,
                                                {'restore_profile_mode': True} if operation == 'resume' else {})
                        if result.get('emergency_stopped') is not (operation == 'emergency-stop'):
                            raise ValueError('Controller did not confirm the requested state')
                        remote = 'Controller pause confirmed.' if operation == 'emergency-stop' else 'Controller resume confirmed.'
                        remote_ok = True
                        evidence['controller']['status'] = 'paused' if operation == 'emergency-stop' else 'resumed'
                    except Exception as exc:
                        remote = 'Controller ' + ('pause' if operation == 'emergency-stop' else 'resume') + ' UNCONFIRMED (' + type(exc).__name__ + ').'
                        evidence['controller']['error_type'] = type(exc).__name__
                if operation == 'resume':
                    if remote_ok and revision == self.control_revision:
                        self.job_control.set_paused(False)
                        evidence['local']['status'] = 'resumed'
                        local = 'New reviewed setup runs allowed; stopped jobs were not restarted.'
                    else:
                        local = 'Setup state unchanged; resume unconfirmed.'
                        evidence['local']['status'] = 'unchanged'
            except Exception as exc:
                local = 'Setup control UNCONFIRMED (' + type(exc).__name__ + ').'
                evidence['local']['error_type'] = type(exc).__name__
            finally:
                client = None
                message = local + ' ' + remote
                from .recording import emit
                emit('desktop_control_result', evidence)
                if not self.closed:
                    self.events.put(('control', (revision, operation), message))

    def unlock_vault(self):
        path, phrase = self.vault_path.get(), self.vault_pass.get()
        self.vault_pass.set('')
        creating = not (Path(path) / 'vault.json').exists()
        if creating:
            from tkinter.simpledialog import askstring
            confirm = askstring('Create vault', 'Confirm your new vault passphrase:', show='*', parent=self.root)
            if confirm != phrase:
                self.note('Passphrases did not match.')
                return
        def unlock():
            self.credentials.unlock(path, phrase, create=creating)
            return self.credentials.entries()
        self.submit(unlock, self._credential_rows)

    def _credential_rows(self, rows):
        self.credential_list.delete(*self.credential_list.get_children())
        for row in rows:
            self.credential_list.insert('', 'end', iid=row['id'], values=(row['label'], row['kind'], row['username'], row['path']))
        self.note('Vault unlocked.' if self.credentials.vault is not None else 'Vault locked. Background defense continues.')

    def add_credential(self, preset=None):
        if self.lock_requested.is_set() or self.credentials.vault is None:
            self.note('Unlock or create the credential vault before adding a credential.')
            self.notebook.select(self.tabs['Credentials'])
            return
        preset = preset or {}
        window = self.tk.Toplevel(self.root)
        window.title('Supply a system credential')
        window.geometry('700x490')
        form = self.ttk.Frame(window, padding=18)
        form.pack(fill='both', expand=True)
        label = self._entry(form, 0, 'System / purpose', preset.get('label', ''))
        kind = self.tk.StringVar(value=preset.get('kind', 'password'))
        self.ttk.Label(form, text='Credential kind').grid(row=1, column=0, sticky='w')
        self.ttk.Combobox(form, textvariable=kind, values=('password', 'ssh-key', 'winrm'), state='readonly').grid(row=1, column=1, sticky='ew')
        username = self._entry(form, 2, 'Username', preset.get('username', ''))
        path = self._entry(form, 3, 'Private runtime file', preset.get('path', str(self.directory / 'credentials' / 'system.secret')))
        value = self._entry(form, 4, 'Password', secret=True)
        key = self.tk.Text(form, height=5, wrap='none')
        key.grid(row=5, column=1, sticky='nsew', pady=6)
        self.ttk.Label(form, text='Private key (SSH only)').grid(row=5, column=0, sticky='nw', pady=6)
        def save():
            data = (label.get(), kind.get(), username.get(), key.get('1.0', 'end-1c') if kind.get() == 'ssh-key' else value.get(), path.get())
            value.set('')
            key.delete('1.0', 'end')
            window.destroy()
            def store():
                entry = self.credentials.save(*data)
                self.credentials.supply(entry)
                return self.credentials.entries()
            self.submit(store, self._credential_rows)
        self.ttk.Button(form, text='Save encrypted and supply to runtime', command=save).grid(row=6, column=1, sticky='w', pady=12)

    def supply_credential(self):
        selected = self.credential_list.selection()
        if selected:
            entry = selected[0]
            self.submit(lambda: self.credentials.supply(entry), lambda _: self.note('Credential supplied to the private runtime file.'))

    def required_credentials(self):
        try:
            path = Path(self.inventory_path.get()).absolute()
            inventory = read_private_json(path)
            if self.profile_path.get():
                profile = read_private_json(self.profile_path.get())
                inventory['event_profile'] = profile.get('event_profile', profile)
            rows = credential_requirements(inventory, path.parent)
        except (ValueError, OSError):
            self.note('Choose an event inventory on the Setup tab first.')
            return
        missing = [row for row in rows if not row['available']]
        if missing:
            self.add_credential(missing[0])
            self.note(f'{len(missing)} missing credential file(s). Supply each required credential before setup.')
        else:
            self.note(f'{len(rows)} declared credential file(s) present. Authentication is checked when used.')

    def _setup_values(self):
        return {'inventory': self.inventory_path.get(), 'event_profile': self.profile_path.get(),
                'runtime': self.runtime_path.get(), 'kind': self.setup_kind.get(), 'range_deployment': self.range_mode.get()}

    def grant_profile_repair(self):
        """Write a reviewed copy of the event profile in which every service can be repaired."""
        from .repair_grants import grant_file, report_text
        if self.job_path is not None or self.setup_starting:
            self.note('Finish the current setup job before changing the event profile.'); return
        text = self.profile_path.get().strip()
        source = Path(text).expanduser().absolute() if text else None
        if source is None or not source.is_file():
            self.note('Load the event profile on Setup first.'); return
        automatic = self.messagebox.askyesnocancel('Grant repair to every service',
            'Write a NEW copy of this event profile in which every service that lists its configuration files '
            'can be repaired: restore its own files, re-enable it and restart it, validated by its checks. '
            'Shared, data and account files stay alert-only. The original file is not changed.\n\n'
            'Yes — also allow automatic repair (used only in guarded-autonomous mode)\n'
            'No — repair only after you approve it\nCancel — change nothing', parent=self.root)
        if automatic is None:
            return
        stem = source.name.removesuffix('.json')
        destination = next(candidate for candidate in
                           (source.with_name(stem + ('.repair' if n == 1 else f'.repair-{n}') + '.json') for n in range(1, 1000))
                           if not candidate.exists())
        try:
            report = grant_file(source, destination, automatic=bool(automatic))
        except (OSError, ValueError) as exc:
            self.note('Could not grant repair: ' + str(exc)[:280]); return
        self.profile_path.set(str(destination))
        self.plan = None
        self.start_setup.configure(state='disabled')
        self._setup_report(report_text(report) + '\n\nSaved as ' + str(destination) + '. The Event profile field now uses it; '
                           'review the setup plan again. The copy keeps the original approval record, so if your event '
                           'requires the organizer to approve profile changes, have them review this file.')
        self.note('Wrote ' + destination.name + ' with repair granted to ' + str(len(report['granted'])) + ' service(s).')

    def _setup_report(self, text):
        self.setup_text.configure(state='normal')
        self.setup_text.delete('1.0', 'end')
        self.setup_text.insert('1.0', text)
        self.setup_text.configure(state='disabled')

    def review_setup(self):
        if self.setup_starting or self.job_path is not None:
            self.note('Review the current background job before starting another setup.')
            return
        values = self._setup_values()
        self.plan = None
        self.start_setup.configure(state='disabled')
        def build():
            plan, _ = prepare(values['inventory'], values['event_profile'], values['runtime'], values['kind'], values['range_deployment'])
            return values, plan
        def ready(result):
            values, plan = result
            if self.setup_starting or self.job_path is not None or values != self._setup_values():
                return
            self.plan = (values, plan)
            summary = summarize_plan(plan['setup'] if values['kind'] == 'opening' else plan)
            self._setup_report(json.dumps({'operation': values['kind'], 'approved_digest': plan_digest(plan), 'review': summary}, indent=2))
            self.start_setup.configure(state='normal')
        self.submit(build, ready)

    def execute_setup(self, _confirmed=False):
        if self.plan is None or self.job_path is not None or self.setup_starting:
            return
        values, plan = self.plan
        if (sys.platform.startswith('linux') and getattr(self, 'local_workspace', None) is not None
                and values.get('event_profile') == self.local_workspace['event_profile']
                and self._local_selection() != self.local_selection_digest):
            self.note('Service choices changed after review. Use Change local choices, then review the new plan.')
            return
        if values != self._setup_values():
            self.note('Inputs changed. Review the setup plan again.')
            self.start_setup.configure(state='disabled')
            return
        if not _confirmed and not self.messagebox.askyesno('Approve setup', 'Apply the displayed plan to the declared systems and verify their services?', parent=self.root):
            return
        if sys.platform.startswith('linux') and getattr(self, 'local_workspace', None) is not None and self.client is None:
            self.start_local_session(lambda: self.execute_setup(_confirmed=True))
            return
        job = dict(values, approved_digest=plan_digest(plan))
        try:
            job['control_epoch'] = self.job_control.admit()
        except (OSError, ValueError, SetupPaused) as exc:
            self.note(str(exc))
            return
        from .recording import emit
        emit('setup_plan_approved', {'plan_sha256': job['approved_digest'], 'kind': values['kind']})
        phrase = None
        if plan.get('security') is not None:
            from tkinter.simpledialog import askstring
            vault_dir = askstring('Security stage vault', 'Operator-side security vault directory:',
                                  initialvalue=str(self.directory/'security-vault'), parent=self.root)
            if not vault_dir:
                return
            phrase = askstring('Security stage vault', 'Vault passphrase:', show='*', parent=self.root)
            if not phrase:
                return
            if not (Path(vault_dir)/'vault.json').exists():
                if askstring('Create security vault', 'Confirm the new passphrase:', show='*', parent=self.root) != phrase:
                    self.note('Security vault passphrases did not match.')
                    return
            job['security_vault_dir'] = str(Path(vault_dir).absolute())
        import secrets
        directory = self.directory / ('job-' + secrets.token_hex(8))
        self.setup_starting = True
        self.start_setup.configure(state='disabled')
        local = getattr(self, 'local_workspace', None)
        local = local if (sys.platform.startswith('linux') and local is not None
                          and values.get('event_profile') == local['event_profile'] and values['kind'] == 'setup') else None
        def started(result):
            self.setup_starting = False
            self.job_process, self.job_path = result
            self.job_outcome_unknown = False
            self.plan = None
            self.note('Setup running in the background. You can minimize this window.')
            if local is not None:
                # Kept so the same approved plan can be run again when repair
                # cannot fix a service (setup_redo). It authorizes nothing new.
                try:
                    from .setup_redo import record_approved_setup
                    record_approved_setup(Path(local['directory']), job, job_root=self.directory, job_path=self.job_path)
                except (OSError, ValueError, KeyError) as exc:
                    self.note('Setup started, but redo-after-failed-repair is unavailable: ' + str(exc)[:200])
            elif values['kind'] == 'setup':
                # 2.0.6: the same for an approved network inventory. Its redo
                # runs from this window, only for the services repair could not
                # fix, and on its own only in guarded-autonomous mode.
                try:
                    self.network_redo_workspace = self._record_network_setup(job)
                except (OSError, ValueError, KeyError) as exc:
                    self.note('Setup started, but redo-after-failed-repair is unavailable: ' + str(exc)[:200])
        def failed(_):
            self.setup_starting = False
            self.plan = None
            self._setup_report('Launch did not confirm a job handle. Inspect ' + str(directory) + ' before reviewing a new setup plan.')
        if not self.submit(lambda: launch_job(job, directory, phrase), started, failed, preserve=True):
            self.setup_starting = False
            self.start_setup.configure(state='normal')

    def _saved_network_redo(self):
        try:
            saved = read_private_json(self.directory / 'last-network-setup.json', 4096)
            path = Path(saved['workspace'])
            return path if (path / 'approved-setup.json').is_file() else None
        except (OSError, ValueError, KeyError, TypeError):
            return None

    def _record_network_setup(self, job):
        from .setup_redo import record_approved_setup
        workspace = self.directory / 'network-redo' / job['approved_digest'][:16]
        workspace.mkdir(mode=0o700, parents=True, exist_ok=True)
        workspace.chmod(0o700)
        record_approved_setup(workspace, job, job_root=self.directory, job_path=self.job_path, scope='network')
        write_private_json(self.directory / 'last-network-setup.json', {'workspace': str(workspace)})
        return workspace

    def tick_network_redo(self, snapshot):
        """Keep the network redo's evidence current; start one only in guarded mode."""
        workspace = self.network_redo_workspace
        if (workspace is None or getattr(self, 'local_workspace', None) is not None or self.client is None
                or self.redo_ticking or time.monotonic() < self.next_redo_tick):
            return
        from . import setup_redo
        self.next_redo_tick = time.monotonic() + setup_redo.TICK_SECONDS
        governance = (snapshot.get('controller') or {}).get('governance') or {}
        automatic = governance.get('autonomy_mode') == 'guarded-autonomous' and not governance.get('emergency_stopped')
        client = self.client
        def close(agent, service):
            return client.request(f'/api/v1/agents/{agent}/services/recovered',
                                  {'service': service, 'source': 'setup_redo'})
        def work():
            try:
                verdict = setup_redo.tick(workspace, client.dashboard(), automatic=automatic, close_incident=close, client=client)
                if verdict.get('launched'):
                    self.events.put(('done', (self.generation, lambda entry: self.note(
                        'Setup redo started for ' + ', '.join(entry['units']) + '.'), False), verdict['launched']))
            except Exception:
                pass
            finally:
                self.redo_ticking = False
        self.redo_ticking = True
        threading.Thread(target=work, name='sentinel-network-redo', daemon=True).start()

    def launch_controller(self):
        if self.controller_starting:
            self.note('A controller launch is already pending.')
            return
        if self.background_controller is not None and self.background_controller.poll() is None:
            self.note('This window already started a running controller.')
            return
        path = self.filedialog.askopenfilename(parent=self.root)
        if not path:
            return
        try:
            configuration = read_private_json(path, 65536)
            arguments = configuration['controller_arguments']
        except (ValueError, OSError, KeyError, TypeError):
            self.note('Select a controller configuration containing controller_arguments.')
            return
        def started(process):
            self.controller_starting = False
            self.background_controller = process
            self.note('Controller process started. Connect to verify readiness.')
        def failed(_):
            self.controller_starting = False
        try:
            permit = self.job_control.permit(self.job_control.admit())
        except (OSError, ValueError, SetupPaused) as exc:
            self.note(str(exc))
            return
        def launch():
            permit.checkpoint()
            return start_controller(arguments)
        self.controller_starting = True
        if not self.submit(launch, started, failed, preserve=True):
            self.controller_starting = False

    def save_settings(self):
        try:
            values = {'origin': self.origin.get(), 'principal': self.principal.get(), 'epoch': int(self.epoch.get()),
                      'ca_file': self.ca_path.get(), 'inventory': self.inventory_path.get(),
                      'event_profile': self.profile_path.get(), 'runtime': self.runtime_path.get()}
            write_private_json(self.directory / 'desktop.json', values)
            self.note('Connection settings saved. Signing keys and passwords were excluded.')
        except (ValueError, OSError):
            self.note('Connection settings could not be saved.')

    def close(self):
        if self.closed:
            return
        self.closed = True
        self.generation += 1
        self.root.after_cancel(self.tick_timer)
        self.client = None
        self.operator_key.set('')
        self.vault_pass.set('')
        # Already admitted jobs finish independently. Vault cleanup cannot be
        # rejected by a full work queue, and the idle worker is allowed to exit.
        self.worker_stop.set()
        if self.guard is not None:
            self.guard.close()
        root = self.root
        root.destroy()
        # Jobs retain this Python controller while finishing. Do not let their
        # final reference release Tcl-owned Variables/widgets on a worker thread.
        # Destroy/release all GUI references here, on the interpreter's owner
        # thread; retain queues, credentials and job state for admitted work.
        # Tk is optional: a controller host need not have python3-tk, and a
        # window can be built by a fixture without it. If tkinter was never
        # imported then no Tk-owned object can exist to release, so look the
        # module up rather than importing it and failing a clean shutdown.
        tk = sys.modules.get('tkinter')
        if tk is not None and isinstance(root, tk.Misc):
            gui_types = (tk.Misc, tk.Variable)
            panel = getattr(self, 'service_panel', None)
            if panel is not None:
                port_editor = getattr(panel, 'port_editor', None)
                if port_editor is not None:
                    port_editor.close()
                    panel.port_editor = None
                for name, value in list(vars(panel).items()):
                    if isinstance(value, gui_types):
                        setattr(panel, name, None)
                self.service_panel = None
            for name, value in list(vars(self).items()):
                if isinstance(value, gui_types):
                    setattr(self, name, None)
                elif isinstance(value, dict):
                    for key in list(value):
                        if isinstance(value[key], gui_types):
                            del value[key]
            # Clear pending callbacks on this thread as well. Late results do not
            # invoke callbacks once closed; already admitted operations continue.
            while True:
                try:
                    self.events.get_nowait()
                except queue.Empty:
                    break
            import gc
            gc.collect()


def run(args):
    try:
        import tkinter as tk
    except ImportError:
        raise RuntimeError(
            'The desktop window needs Python Tk, which is not installed. '
            'On Debian, Ubuntu or Kali: sudo apt install python3-tk  '
            '(everything else — controller, agent, observer — runs without it.)') from None
    if os.name != 'nt' and not os.environ.get('DISPLAY'):
        raise RuntimeError(
            'The desktop window needs a graphical session and this one has no display. '
            'Open it from the desktop of the machine itself, or over SSH with X forwarding (ssh -X). '
            'To run without a window, use the controller, agent or observer commands.')
    if not args.foreground:
        command = ['desktop', '--foreground']
        if args.config:
            command += ['--config', str(Path(args.config).absolute())]
        detach(command)
        return 0
    default = Path.home() / '.sentinel-blue-desktop' / 'desktop.json'
    path = Path(args.config) if args.config else default
    config = read_private_json(path, 65536) if path.is_file() else {}
    try:
        root = tk.Tk()
    except tk.TclError as exc:
        raise RuntimeError('The desktop could not connect to the graphical display. '
                           'Open Sentinel inside a working X11/XWayland session. '
                           + str(exc)) from exc
    try:
        DesktopWindow(root, config)
        root.mainloop()
    finally:
        # Failed initialization must not leave a blank Tk window behind.
        try:
            root.destroy()
        except tk.TclError:
            pass
    return 0
