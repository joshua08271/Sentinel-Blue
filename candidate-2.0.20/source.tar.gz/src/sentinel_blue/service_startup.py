"""Exact, bounded native startup-mode restoration for declared services."""

from __future__ import annotations

import platform
import re
import subprocess

from .mutation_tracking import startup_transition
from .policy import SERVICE_NAME


MASKED = frozenset({"masked", "masked-runtime"})
LINUX_MODES = frozenset({"enabled", "disabled"}) | MASKED


def _linux_commands(service: str, expected: str, desired: str) -> list[list[str]]:
    """The exact systemctl steps from one startup mode to another.

    Unmasking restores whatever enablement links the unit still has, so an
    unmask is always followed by the explicit enable or disable that was asked
    for. Masking an enabled unit disables it first, so undoing a repair returns
    the unit to the mask it was found in rather than a masked-but-wanted hybrid.
    """
    runtime = ["--runtime"]
    steps: list[list[str]] = []
    if expected in MASKED:
        steps.append(["systemctl", "unmask", *(runtime if expected == "masked-runtime" else []), service])
        if desired in MASKED:
            steps.append(["systemctl", "mask", *(runtime if desired == "masked-runtime" else []), service])
            return steps
        steps.append(["systemctl", "enable" if desired == "enabled" else "disable", service])
        return steps
    if desired in MASKED:
        if expected == "enabled":
            steps.append(["systemctl", "disable", service])
        steps.append(["systemctl", "mask", *(runtime if desired == "masked-runtime" else []), service])
        return steps
    return [["systemctl", "enable" if desired == "enabled" else "disable", service]]


def _service(name: str) -> None:
    if not isinstance(name, str) or not SERVICE_NAME.fullmatch(name) or name.startswith("-"):
        raise ValueError("invalid service startup target")


def _run(argv: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(argv, capture_output=True, text=True, timeout=15, check=False)


def read_start_mode(service: str) -> str:
    _service(service)
    if platform.system().casefold() == "windows":
        result = _run(["sc.exe", "qc", service])
        # Use the numeric type, never the service's display name or error text.
        matches = re.findall(r"^\s*START_TYPE\s*:\s*([0-4])\s", result.stdout, re.MULTILINE)
        if result.returncode or len(matches) != 1 or matches[0] not in {"2", "3", "4"}:
            raise ValueError("native Windows startup mode is unavailable or unsupported")
        return {"2": "auto", "3": "manual", "4": "disabled"}[matches[0]]
    if platform.system().casefold() != "linux":
        raise ValueError("native startup restoration supports Linux and Windows")
    result = _run(["systemctl", "show", "--property=LoadState", "--property=UnitFileState", service])
    rows = [line.split("=", 1) for line in result.stdout.splitlines() if "=" in line]
    if len(rows) != 2 or len({key for key, _ in rows}) != 2:
        raise ValueError("native Linux startup evidence is ambiguous")
    data = dict(rows)
    if result.returncode:
        raise ValueError("native Linux startup mode is unavailable or unsupported")
    # A masked unit is linked to /dev/null, so systemd reports it as masked
    # rather than loaded. It is a startup mode like any other, and the one an
    # attacker reaches for because `systemctl start` then refuses outright.
    if data.get("LoadState") == "masked" and data.get("UnitFileState") in MASKED:
        return data["UnitFileState"]
    if data.get("LoadState") != "loaded" or data.get("UnitFileState") not in {"enabled", "disabled"}:
        raise ValueError("native Linux startup mode is unavailable or unsupported")
    return data["UnitFileState"]


@startup_transition
def change_start_mode(service: str, expected: str, desired: str) -> None:
    """Compare immediately before mutation; verify afterwards, including rollback."""
    _service(service)
    windows = platform.system().casefold() == "windows"
    allowed = {"auto", "manual", "disabled"} if windows else LINUX_MODES
    if expected not in allowed or desired not in allowed:
        raise ValueError("unsupported startup-mode transition")
    if read_start_mode(service) != expected:
        raise ValueError("native startup mode changed after observation")
    if desired == expected:
        return
    if windows:
        commands = [["sc.exe", "config", service, "start=", {"auto": "auto", "manual": "demand", "disabled": "disabled"}[desired]]]
    else:
        commands = _linux_commands(service, expected, desired)
    for command in commands:
        if _run(command).returncode:
            raise ValueError("native startup transition failed: " + " ".join(command[:2]))
    if read_start_mode(service) != desired:
        raise ValueError("native startup transition failed verification")
