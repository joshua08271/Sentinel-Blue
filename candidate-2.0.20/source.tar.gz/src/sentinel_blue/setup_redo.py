"""When repair cannot fix a service, run its approved setup again.

Repair puts back what the baseline captured: the service's own files, its
startup mode, a running process. Some damage is outside that — a deleted unit,
a removed package directory, a generated file beyond the repair limit, the
ownership of a directory setup created. Setup can rebuild those, and the setup
that built this VM's services is already reviewed and approved. A redo runs
exactly that approved plan again, as a new background job:

* The worker recompiles the plan from the same inventory and profile and
  refuses to start unless it hashes to the digest the operator approved. A
  profile or inventory edited since approval stops the redo; nothing new is
  ever authorized by it.
* Setup checks every task's service first and leaves a healthy one alone, so a
  redo changes only what is broken.
* It honours the Setup pause, runs one job at a time, at most once per service
  every ten minutes and three times an hour, and never after a repair whose
  rollback did not complete, while an action's outcome is unknown, during an
  emergency stop, or for a fault setup cannot fix (a port held by another
  process, a full or read-only filesystem, host memory, a restart loop).

In guarded-autonomous mode the local session runs a redo on its own when a
service qualifies. In approval-based mode the Recovery tab offers the same redo
for the operator to start.

A redo is recorded like any setup. Withdraw reverses it to the state it found,
and then holds the original setup's inverse for review, exactly as it does when
setup is re-run by hand.
"""

from __future__ import annotations

import secrets
import time
from pathlib import Path
from typing import Any

from .state import read_private_json, write_private_json
from .redo_governance import snapshot_hold, automatic_allowed, action_holds

RECORD = "approved-setup.json"
STATE = "setup-redo.json"
AGENT = "local-linux"
UNIT_COOLDOWN_SECONDS = 600
HOURLY_LIMIT = 3
MISSING_GRACE_SECONDS = 60
UNREPAIRED_GRACE_SECONDS = 180
REPAIR_WINDOW_SECONDS = 900
JOB_STALE_SECONDS = 45 * 60
TICK_SECONDS = 15
# After a redo finishes ready, how long the session keeps asking the controller
# to close that service's incident: the controller closes it only once its own
# telemetry shows the service running, its checks healthy and its files as
# approved, which takes a collection cycle or two.
INCIDENT_CLOSE_WINDOW_SECONDS = 300
IN_PROGRESS = frozenset({"pending", "queued", "dispatched"})
TRANSITIONAL = frozenset({"activating", "deactivating", "reloading", "refreshing"})
RECORD_FIELDS = frozenset({"schema", "kind", "inventory", "event_profile", "runtime", "range_deployment",
                           "approved_digest", "job_root", "original_job", "approved_at"})


def _futile_phrases() -> tuple[str, ...]:
    from .service_repair import FAULT_SUMMARIES, RESTART_FUTILE_CODES
    codes = set(RESTART_FUTILE_CODES) | {"socket_activation_holds_port"}
    return tuple(FAULT_SUMMARIES[code] for code in sorted(codes) if code in FAULT_SUMMARIES)


# -- the approved setup ------------------------------------------------------
def record_approved_setup(workspace, job, *, job_root, job_path, scope="local") -> dict[str, Any]:
    """Keep what the operator approved, so the same plan can be run again.

    `scope` is "local" for the guided setup of this VM, "network" for an
    approved network inventory (2.0.6): its redo covers every host's services.
    """
    record = {"schema": 1, "kind": job["kind"], "inventory": str(Path(job["inventory"]).absolute()),
              "event_profile": str(Path(job["event_profile"] or job["inventory"]).absolute()),
              "runtime": str(Path(job["runtime"]).absolute()), "range_deployment": bool(job.get("range_deployment")),
              "approved_digest": job["approved_digest"], "job_root": str(Path(job_root).absolute()),
              "original_job": str(Path(job_path).absolute()), "approved_at": time.time()}
    if scope != "local":
        record["scope"] = scope
    _check_record(record)
    write_private_json(Path(workspace) / RECORD, record)
    return record


def _check_record(record: Any) -> dict[str, Any]:
    if (not isinstance(record, dict) or set(record) - {"scope"} != RECORD_FIELDS or record.get("schema") != 1
            or record.get("scope", "local") not in {"local", "network"}):
        raise ValueError("the approved setup record is malformed; review a new setup")
    if record["kind"] != "setup":
        raise ValueError("only an approved setup can be redone")
    digest = record["approved_digest"]
    if not isinstance(digest, str) or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
        raise ValueError("the approved setup record has no valid plan digest")
    for name in ("inventory", "event_profile", "runtime", "job_root", "original_job"):
        if not isinstance(record[name], str) or not Path(record[name]).is_absolute():
            raise ValueError("the approved setup record must use absolute paths")
    if type(record["range_deployment"]) is not bool:
        raise ValueError("the approved setup record is malformed; review a new setup")
    return record


def load_record(workspace) -> dict[str, Any] | None:
    path = Path(workspace) / RECORD
    if not path.is_file():
        return None
    return _check_record(read_private_json(path, 65536))


def load_state(workspace) -> dict[str, Any]:
    path = Path(workspace) / STATE
    empty = {"history": [], "missing_since": {}, "unhealthy_since": {}, "seen_healthy": [], "running": None, "last": "",
             "close_pending": {}}
    if not path.is_file():
        return empty
    value = read_private_json(path, 256 * 1024)
    if not isinstance(value, dict):
        return empty
    return {**empty, **{key: value[key] for key in empty if key in value}}


def save_state(workspace, state) -> None:
    state = dict(state)
    state["history"] = state["history"][-64:]
    write_private_json(Path(workspace) / STATE, state)


def _job_running(job_path: str | None) -> bool:
    """A job with no result yet, unless its worker evidently died long ago."""
    if not job_path:
        return False
    path = Path(job_path)
    if not path.is_file() or (path.parent / "result.json").exists():
        return False
    return time.time() - path.stat().st_mtime < JOB_STALE_SECONDS


def _job_result(job_path: str) -> dict[str, Any] | None:
    path = Path(job_path).parent / "result.json"
    if not path.is_file():
        return None
    try:
        value = read_private_json(path, 1024 * 1024)
    except (OSError, ValueError):
        return None
    return value if isinstance(value, dict) else None


def _scope(record: dict[str, Any] | None) -> str:
    return (record or {}).get("scope", "local")


def _key(agent: str, unit: str, scope: str) -> str:
    """How a service is named in the redo state: bare on this VM, host/unit on a network."""
    return unit if scope == "local" else f"{agent}/{unit}"


def _pair(key: str, scope: str) -> list[str]:
    if scope == "local":
        return [AGENT, key]
    agent, _, unit = key.partition("/")
    return [agent, unit]


def _task_for(record: dict[str, Any], key: str) -> dict[str, Any] | None:
    """The approved inventory's setup task for this service, or None."""
    try:
        inventory = read_private_json(Path(record["inventory"]), 4 * 1024 * 1024)
    except (OSError, ValueError):
        return None
    if not isinstance(inventory, dict):
        return None
    agent, unit = _pair(key, _scope(record))
    hosts = {}
    for row in inventory.get("hosts", []):
        if isinstance(row, dict):
            names = {row.get("name"), row.get("address"), row.get("agent_id")} - {None}
            for name in names:
                hosts[name] = names
    for task in (inventory.get("setup") or {}).get("tasks") or []:
        if (isinstance(task, dict) and task.get("service_id") in {unit, unit.removesuffix(".service")}
                and agent in hosts.get(task.get("host"), {task.get("host")})):
            return task
    return None


def _original_task_ready(record: dict[str, Any], key: str) -> bool | None:
    """Did the approved setup finish this service's own task? None when it cannot tell."""
    tasks = (_job_result(record["original_job"]) or {}).get("tasks")
    task = _task_for(record, key)
    if not isinstance(tasks, dict) or task is None:
        return None
    row = tasks.get(task.get("id"))
    return isinstance(row, dict) and row.get("status") == "ready"


# -- deciding ----------------------------------------------------------------
def _rollback_failed(result: dict[str, Any]) -> bool:
    """A repair that started changing the host and could not undo itself.

    rolled_back is also false for a repair held before it changed anything, so
    it is not enough on its own. 2.0.4 marks a failed undo review_required;
    earlier agents are recognised by the undo's own error following the first.
    """
    if result.get("review_required") is True:
        return True
    return result.get("rolled_back") is False and len(result.get("errors") or []) > 1


def _latest_repairs(snapshot: dict[str, Any], agent: str) -> dict[str, dict[str, Any]]:
    from .service_automation import never_delivered
    latest: dict[str, dict[str, Any]] = {}
    for action in snapshot.get("actions", []):
        if action.get("agent_id") != agent or action.get("action_type") != "repair_service" or action.get("redo_reconciled") is True:
            continue
        if never_delivered(action):
            continue   # 2.0.18: a repair no agent received is not a repair that failed
        service = (action.get("parameters") or {}).get("service")
        if isinstance(service, str) and (service not in latest or action.get("created_at", 0) > latest[service].get("created_at", 0)):
            latest[service] = action
    return latest


def _history_covers(item: dict[str, Any], unit: str) -> bool:
    """A batch cools down every member; an old unscoped wildcard covers all.

    Network keys include the agent ID and are compared exactly. An absent,
    empty or malformed membership list cannot narrow a historical wildcard.
    """
    members = item.get("units")
    if isinstance(members, list) and members and all(isinstance(x, str) and x for x in members):
        return unit in members or "*" in members or item.get("unit") == unit
    return item.get("unit") in {unit, "*"}


def assess(snapshot: dict[str, Any], record: dict[str, Any] | None, state: dict[str, Any], now: float,
           *, agent: str = AGENT) -> dict[str, Any]:
    """Decide, for every service of this VM, whether a redo is due. Updates `state` timers."""
    result: dict[str, Any] = {"blocked": None, "units": {}}
    governance = (snapshot.get("controller") or {}).get("governance") or {}
    if record is None:
        result["blocked"] = "no approved local setup is recorded; approve setup on this VM first"
    elif governance.get("emergency_stopped"):
        result["blocked"] = "emergency stop is enabled"
    elif _job_running((state.get("running") or {}).get("job")):
        result["blocked"] = "a setup redo is already running"
    elif _job_running(record["original_job"]):
        result["blocked"] = "the approved setup is still running"
    scope = _scope(record)
    seen = set(state.get("seen_healthy", []))
    # An approved baseline is itself proof every service was healthy: approval
    # is refused while any of its checks fail. A service broken in the seconds
    # between approval and the first tick is still one setup once had working.
    approved_agents = {host.get("agent_id") for host in snapshot.get("agents", [])
                       if host.get("baseline_status") == "approved"}
    missing = dict(state.get("missing_since", {}))
    unhealthy = dict(state.get("unhealthy_since", {}))
    repairs_by_agent: dict[str, dict[str, dict[str, Any]]] = {}
    futile = _futile_phrases()
    history = [row for row in state.get("history", []) if now - row.get("at", 0) < 3600]
    for row in snapshot.get("service_health", []):
        host = row.get("agent_id")
        if scope == "local" and host != agent:
            continue
        if not isinstance(host, str) or not isinstance(row.get("service"), str):
            continue
        name, health, native = row.get("service"), row.get("health"), row.get("native_state")
        unit = _key(host, name, scope)
        baseline_approved = host in approved_agents
        if host not in repairs_by_agent:
            repairs_by_agent[host] = _latest_repairs(snapshot, host)
        repairs = {(_key(host, service, scope)): value for service, value in repairs_by_agent[host].items()}
        verdict = {"status": "waiting", "reason": ""}
        result["units"][unit] = verdict
        if health == "healthy":
            seen.add(unit)
            missing.pop(unit, None)
            unhealthy.pop(unit, None)
            verdict.update(status="healthy", reason="healthy")
            continue
        if health != "unhealthy":
            missing.pop(unit, None)
            unhealthy.pop(unit, None)
            verdict["reason"] = "no fresh health verdict"
            continue
        hold = snapshot_hold(snapshot, host, name, now)
        if hold:
            verdict.update(status='waiting' if hold == 'a repair is in progress' else 'held', reason=hold)
            continue
        since = unhealthy.setdefault(unit, now)
        repair = repairs.get(unit)
        result_row = (repair or {}).get("result") or {}
        reason = row.get("reason") or ""
        if unit not in seen and not baseline_approved:
            verdict["reason"] = "not yet seen healthy in this session; setup itself has not finished"
        elif reason.startswith(futile):
            verdict.update(status="held", reason=f"setup cannot fix this: {reason}")
        elif str(native).casefold() in TRANSITIONAL:
            # Setup refuses a unit systemd is still starting, stopping or
            # reloading; running it now would only fail. Wait for it to settle.
            verdict["reason"] = "the service manager is still changing its state"
        elif repair and repair.get("status") == "outcome_unknown":
            verdict.update(status="held", reason="the last repair's outcome is unknown; review it first")
        elif repair and repair.get("status") in IN_PROGRESS:
            verdict["reason"] = "a repair is in progress"
        elif repair and repair.get("status") == "failed" and _rollback_failed(result_row):
            verdict.update(status="held", reason="the last repair did not roll back cleanly; review before any further change")
        elif (repair and repair.get("status") == "failed"
              and now - (repair.get("completed_at") or 0) < REPAIR_WINDOW_SECONDS):
            verdict.update(status="eligible", reason=("repair failed and was rolled back: " if result_row.get("rolled_back")
                                                      else "repair could not be applied: ")
                           + str(result_row.get("message", ""))[:200])
        elif native == "unknown":
            first = missing.setdefault(unit, now)
            if now - first >= MISSING_GRACE_SECONDS:
                verdict.update(status="eligible", reason="the unit is no longer present on this host")
            else:
                verdict["reason"] = "the unit is missing; waiting to confirm"
        elif now - since >= UNREPAIRED_GRACE_SECONDS and not (
                repair and now - (repair.get("created_at") or 0) < UNREPAIRED_GRACE_SECONDS):
            verdict.update(status="eligible", reason="unhealthy for three minutes and repair could not fix it")
        else:
            verdict["reason"] = "waiting for repair"
        if verdict["status"] == "eligible":
            service_history = [item for item in history if _history_covers(item, unit)]
            recent = [item for item in service_history if now - item["at"] < UNIT_COOLDOWN_SECONDS]
            if recent:
                verdict.update(status="waiting", reason=f"redone {int(now - max(item['at'] for item in recent))} s ago; waiting before another")
            elif len(service_history) >= HOURLY_LIMIT:
                verdict.update(status="held", reason="three redos in the last hour; review before another",
                               hold_kind="hourly_limit")
    state["seen_healthy"] = sorted(seen)
    state["missing_since"] = missing
    state["unhealthy_since"] = unhealthy
    return result


# -- acting ------------------------------------------------------------------
def launch_redo(workspace, record, state, units, reason, *, now=None, launcher=None, client=None, automated=False,
                excluded=None) -> dict[str, Any]:
    """Start the approved setup again as a new background job."""
    from .desktop_jobs import launch_job
    production = launcher is None
    launcher = launcher or launch_job
    now = time.time() if now is None else now
    job = {"kind": record["kind"], "inventory": record["inventory"], "event_profile": record["event_profile"],
           "runtime": record["runtime"], "range_deployment": record["range_deployment"],
           "approved_digest": record["approved_digest"], "redo": True}
    if list(units) != ["*"]:
        # Only these services' tasks, and what they require, run (2.0.6): an
        # unrelated task of the approved plan is neither retried nor able to
        # fail the redo.
        job["only_services"] = [_pair(unit, _scope(record)) for unit in units]
    directory = Path(record["job_root"]) / ("job-redo-" + secrets.token_hex(8))
    if client is not None:
        from .event_profile import load_event_profile
        from .redo_governance import prepare_guard
        from .job_control import SetupPaused, JobControl
        if not job.get('only_services'):
            raise SetupPaused('Redo needs an explicit service scope; review the selected unhealthy services')
        if production:
            # 2.0.9: refuse a paused Setup before any worker connection material
            # is written. launch_job() repeats this admission atomically.
            control = JobControl(directory.parent)
            control.initialize()
            control.admit()
        job['redo_guard_file'] = prepare_guard(client, directory, job['only_services'], automated,
                                               load_event_profile(record['event_profile']))
    elif production:
        from .job_control import SetupPaused
        raise SetupPaused('Reconnect to the controller to verify current redo governance')
    try:
        _process, job_path = launcher(job, directory)
    except BaseException:
        # A redo that did not start leaves no copy of the operator connection.
        discard_guard(job.get('redo_guard_file'))
        raise
    entry = {"at": now, "unit": units[0] if len(units) == 1 else "*", "units": list(units), "reason": reason,
             "job": str(job_path)}
    if excluded:
        entry["excluded"] = dict(excluded)
    state["history"] = [*state.get("history", []), entry]
    state["running"] = entry
    state["last"] = f"redo started for {', '.join(units)}: {reason}"
    if excluded:
        state["last"] += "; excluded: " + "; ".join(f"{unit}: {why}" for unit, why in sorted(excluded.items()))
    for unit in units:
        state.get("unhealthy_since", {}).pop(unit, None)
        state.get("missing_since", {}).pop(unit, None)
    save_state(workspace, state)
    from .recording import emit
    emit("setup_redo_started", {"units": list(units), "reason": reason, "job": str(job_path),
                               **({"excluded": dict(excluded)} if excluded else {})})
    return entry


def discard_guard(reference) -> None:
    """Remove a redo worker's private connection file once it is no longer needed."""
    if not isinstance(reference, str) or not reference:
        return
    path = Path(reference)
    if path.name != "redo-control.json" or not path.is_absolute():
        return
    try:
        path.unlink()
    except FileNotFoundError:
        return
    try:
        path.parent.rmdir()          # only when the refused job left nothing else
    except OSError:
        pass


def tick(workspace, snapshot, *, now=None, automatic=True, launcher=None, close_incident=None, client=None) -> dict[str, Any]:
    """One pass of the local session loop. Launches at most one redo.

    `close_incident(agent, service)` asks the controller to close a service's
    incident after a redo fixed it; the controller verifies that from its own
    telemetry.
    """
    now = time.time() if now is None else now
    record = load_record(workspace)
    state = load_state(workspace)
    running = state.get("running")
    pending = state["close_pending"] if isinstance(state.get("close_pending"), dict) else {}
    state["close_pending"] = pending
    if running and not _job_running(running.get("job")):
        outcome = _job_result(running["job"]) or {}
        state["last"] = f"redo for {', '.join(running.get('units', []))} finished: {outcome.get('status', 'no result')}"
        state["running"] = None
        if outcome.get("status") in {"passed", "ready"}:
            for unit in running.get("units", []):
                if unit != "*":
                    pending[unit] = now + INCIDENT_CLOSE_WINDOW_SECONDS
    for unit, deadline in list(pending.items()):
        if not isinstance(deadline, (int, float)) or now > deadline:
            pending.pop(unit, None)
            continue
        if close_incident is None:
            continue
        try:
            answer = close_incident(*_pair(unit, _scope(record)))
        except Exception:          # the controller may be busy; try next tick
            continue
        if isinstance(answer, dict) and not answer.get("reason"):
            pending.pop(unit, None)
    verdict = assess(snapshot, record, state, now)
    eligible = sorted(unit for unit, row in verdict["units"].items() if row["status"] == "eligible")
    for unit in list(eligible):
        if _task_for(record, unit) is None:
            verdict["units"][unit].update(status="held", reason="no task of the approved setup covers it, "
                                          "so a redo cannot fix it")
            eligible.remove(unit)
    live_automatic = automatic_allowed(snapshot)
    if automatic and not live_automatic and verdict['blocked'] is None:
        verdict['blocked'] = 'current controller mode does not permit automatic redo'
    if automatic and live_automatic and eligible and verdict["blocked"] is None:
        original = _job_result(record["original_job"]) or {}
        if original.get("status") not in {"passed", "ready"}:
            # 2.0.6: a service whose own approved task finished is still redone
            # automatically when an unrelated task of the same setup failed; the
            # redo runs only that service's tasks.
            finished = [unit for unit in eligible if _original_task_ready(record, unit) is True]
            for unit in eligible:
                if unit not in finished:
                    verdict["units"][unit].update(status="held", reason="its approved setup task did not finish "
                                                  "successfully, so it is not redone automatically")
            eligible = finished
            if not eligible:
                verdict["blocked"] = "the approved setup did not finish successfully, so it is not redone automatically"
        if eligible and verdict["blocked"] is None:
            try:
                verdict["launched"] = launch_redo(workspace, record, state, eligible,
                                                  "; ".join(f"{u}: {verdict['units'][u]['reason']}" for u in eligible),
                                                  now=now, launcher=launcher, client=client, automated=True)
                return verdict
            except Exception as exc:          # a paused Setup, a busy disk: say so, keep monitoring
                state["last"] = "redo not started: " + str(exc)[:300]
    save_state(workspace, state)
    verdict["last"] = state["last"]
    return verdict


def manual_redo(workspace, snapshot, *, now=None, launcher=None, client=None) -> dict[str, Any]:
    """Redo only unheld covered services; report exclusions without relaxing guards.

    Operator requests can override scheduler timers, never live governance.
    The worker still expands the selected tasks' dependency scope and checks
    fresh signed authority before mutation, including host-wide work.
    """
    if client is not None:
        # 2.0.9: fetch the live governance view first, then take the time used
        # to judge its freshness. Taking the time first made every fresh view
        # look like it came from the future, so every manual redo was refused.
        snapshot = client.dashboard()
    now = time.time() if now is None else now
    record = load_record(workspace)
    state = load_state(workspace)
    verdict = assess(snapshot, record, state, now)
    hard = verdict["blocked"]
    if hard is not None:
        raise ValueError(hard)
    units, excluded = [], {}
    for unit, row in sorted(verdict["units"].items()):
        if row["status"] == "healthy":
            continue
        # In-progress repairs are rendered as 'waiting', not 'held'; they
        # must also be excluded rather than vetoing an unrelated safe batch.
        hold = snapshot_hold(snapshot, *_pair(unit, _scope(record)), now)
        if hold:
            excluded[unit] = hold
        elif row["status"] == "held" and row.get("hold_kind") != "hourly_limit":
            excluded[unit] = row["reason"]
        elif _task_for(record, unit) is None:
            excluded[unit] = "no task of the approved setup covers this service"
        else:
            units.append(unit)
    if not units:
        if excluded:
            raise ValueError("No services can be redone: " + "; ".join(
                f"{unit}: {reason}" for unit, reason in sorted(excluded.items())))
        # Never fall back to an unscoped wildcard when nothing was selected.
        raise ValueError("Every service covered by the approved setup is healthy; there is nothing to redo.")
    return launch_redo(workspace, record, state, units, "operator requested", now=now, launcher=launcher,
                       client=client, excluded=excluded)


def status_text(workspace, snapshot, *, now=None) -> str:
    now = time.time() if now is None else now
    try:
        record = load_record(workspace)
    except (OSError, ValueError) as exc:
        return "Setup redo: " + str(exc)
    state = load_state(workspace)
    verdict = assess(snapshot, record, dict(state), now)
    lines = ["Setup redo: " + (verdict["blocked"] or "available")]
    for unit, row in sorted(verdict["units"].items()):
        if row["status"] != "healthy":
            lines.append(f"  {unit}: {row['status']} — {row['reason']}")
    if state.get("last"):
        lines.append("  last: " + state["last"])
    return "\n".join(lines)
