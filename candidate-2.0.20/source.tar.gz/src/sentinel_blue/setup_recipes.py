"""Deterministic setup scripts. No guessed accounts, ports, data, or passwords.

Recipes install ordinary distro packages/features and apply the exact reviewed
configuration. Event-specific database, directory, and appliance configuration
can be supplied as hash-pinned check/apply/rollback runbooks.
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import shlex
import zlib
from pathlib import Path, PurePosixPath
from importlib.resources import files as resource_files
from typing import Any

from .state import read_private_text


NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.@+-]{0,127}$")
DIGEST = re.compile(r"^[a-f0-9]{64}$")
RECIPES = {
    "linux-packages", "linux-service", "windows-features", "windows-service", "windows-python", "runbook",
    "linux-router", "linux-nginx", "windows-firewall", "windows-iis",
    # Generated configuration for a catalogued Linux competition service. The
    # service is named in options['catalog_id']; the pack is built from the
    # support registry, so an adoption-only service cannot be configured here.
    "linux-service-pack",
}


def _name(value: Any, label: str) -> str:
    if not isinstance(value, str) or not NAME.fullmatch(value):
        raise ValueError(f"invalid {label}")
    return value


def _boolean(options: dict, name: str, default: bool = False) -> bool:
    value = options.get(name, default)
    if type(value) is not bool:
        raise ValueError(f"{name} must be a boolean")
    return value


def _argv(value: Any) -> str:
    if not isinstance(value, list) or not value or len(value) > 64:
        raise ValueError("validate_argv requires 1 to 64 literal arguments")
    if any(not isinstance(x, str) or not x or "\x00" in x or len(x) > 1024 for x in value):
        raise ValueError("invalid validate_argv argument")
    if not value[0].startswith("/"):
        raise ValueError("validate_argv executable must be an absolute path")
    return shlex.join(value)


def _source(root: Path, value: Any) -> str:
    if not isinstance(value, dict) or set(value) != {"path", "sha256"}:
        raise ValueError("runbook/configuration source requires path and sha256")
    path = Path(str(value["path"]))
    if not path.is_absolute():
        path = root / path
    text = read_private_text(path, 1024 * 1024)
    actual = hashlib.sha256(text.encode("utf-8")).hexdigest()
    if value["sha256"] != actual:
        raise ValueError(f"setup source checksum mismatch: {path.name}")
    if "\x00" in text:
        raise ValueError("setup sources must be UTF-8 text without NUL")
    return text


def _ps(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def _linux_packages(options: dict) -> tuple[str, str, str | None]:
    packages = options.get("packages")
    if not isinstance(packages, list) or not packages or len(packages) > 64:
        raise ValueError("linux-packages requires 1 to 64 package names")
    names = sorted({_name(x, "package name") for x in packages})
    manager = options.get("manager", "apt")
    cache = _boolean(options, "cache_only", True)
    if not cache:
        raise ValueError("Offline release requires cache_only=true; stage approved packages locally before setup")
    if manager == "apt":
        check = "set -eu\n"
        for name in names:
            check += f"test \"$(dpkg-query -W -f='${{Status}}' {shlex.quote(name)} 2>/dev/null)\" = 'install ok installed'\n"
        args = shlex.join(names)
        apply = "set -eu\ntest \"$(id -u)\" = 0\nexport DEBIAN_FRONTEND=noninteractive\n"
        apply += (
            "apt-get -y --no-install-recommends --no-remove "
            "-o DPkg::Lock::Timeout=60 -o Dpkg::Options::=--force-confold "
            + "--no-download " + "install " + args + "\n"
        )
        return check, apply, None
    if manager == "dnf":
        check = "set -eu\nrpm -q " + shlex.join(names) + " >/dev/null\n"
        apply = "set -eu\ntest \"$(id -u)\" = 0\ndnf -y "
        apply += "--cacheonly "
        return check, apply + "install " + shlex.join(names) + "\n", None
    raise ValueError("package manager must be apt or dnf")


SETTLE_SECONDS = 3
SERVICE_COMMAND_SECONDS = 120
# Decodes one embedded file: base64 of zlib-compressed bytes on stdin.
INFLATE = "import base64,sys,zlib;sys.stdout.buffer.write(zlib.decompress(base64.b64decode(sys.stdin.buffer.read(),validate=True)))"


def _linux_service(options: dict, root: Path, *, generated_sources=None, preflight_script="", validation_script="") -> tuple[str, str, str | None]:
    service = _name(options.get("service"), "service name")
    enable = _boolean(options, "enable")
    unmask = _boolean(options, "unmask")
    refresh_runtime = _boolean(options, "refresh_replaced_executable")
    # Units the service starts and restarts that do the real work. Ubuntu's
    # postgresql.service only wraps postgresql@<version>-<cluster>.service and
    # stays "active" even when its cluster failed to start on a bad
    # configuration, so the step also waits for these, and a cluster that does
    # not come up is an ordinary failed, rolled-back step.
    members = options.get("member_units", [])
    if not isinstance(members, list) or len(members) > 8:
        raise ValueError("member_units must list at most 8 units")
    members = [_name(value, "member unit") for value in members]
    from .runtime_environment import target_python_shell
    py = target_python_shell()
    files = options.get("files", [])
    if not isinstance(files, list) or len(files) > 64:
        raise ValueError("linux-service files must be an array of at most 64 files")
    normalized = []
    access_contracts = {}
    access_fields = {"create_owner", "create_group", "readable_by"}
    seen = set()
    for row in files:
        if not isinstance(row, dict) or set(row) - {"path", "source", "mode", "previous_sha256"} - access_fields:
            raise ValueError("invalid setup file fields")
        target = row.get("path")
        if (not isinstance(target, str) or not target.startswith("/") or
                any(x in {"..", "."} for x in target.split("/")) or "\n" in target or
                "\r" in target or "\x00" in target or len(target) > 512):
            raise ValueError("setup file target requires a canonical absolute path")
        if target in seen:
            raise ValueError("duplicate setup file target")
        seen.add(target)
        mode = row.get("mode", "0644")
        if mode not in {"0600", "0640", "0644"}:
            raise ValueError("setup file mode must be 0600, 0640, or 0644")
        previous = row.get("previous_sha256")
        if previous != "absent" and (not isinstance(previous, str) or not DIGEST.fullmatch(previous)):
            raise ValueError("setup file requires exact previous_sha256 or 'absent'")
        content = generated_sources[target] if generated_sources is not None and target in generated_sources else _source(root, row.get("source"))
        if access_fields & set(row):
            if not access_fields <= set(row):
                raise ValueError("File access requires create_owner, create_group and readable_by")
            access = {key: row[key] for key in access_fields} | {"mode": mode}
            if any(not isinstance(access[key], str) or not re.fullmatch(r"[a-zA-Z_][a-zA-Z0-9_.-]{0,63}", access[key]) for key in access_fields):
                raise ValueError("File access identities must be explicit Unix account/group names")
            access_contracts[target] = base64.b64encode(json.dumps(access, sort_keys=True).encode()).decode()
        elif previous == "absent" and mode in {"0600", "0640"}:
            raise ValueError("New restricted files require reviewed creation ownership and readable_by")
        normalized.append((target, content, mode, previous))
    access_helper = ""
    if access_contracts:
        payload = base64.b64encode(resource_files('sentinel_blue').joinpath('setup_file_access.py').read_bytes()).decode()
        access_helper = (f"command -v {py} >/dev/null\n"
                        "sb_file_access() { " + py + " -I -S -c \"$(printf '%s' '" + payload + "' | base64 -d)\" \"$@\"; }\n")
    check = "set -eu\n" + access_helper
    for target, content, mode, _ in normalized:
        path = shlex.quote(target)
        digest = hashlib.sha256(content.encode()).hexdigest()
        check += f"test -f {path} && test ! -L {path}\n"
        check += f"test \"$(sha256sum -- {path} | cut -d' ' -f1)\" = {digest}\n"
        check += f"test \"$(stat -c %a -- {path})\" = {mode[1:]}\n"
    quoted = shlex.quote(service)
    runtime_check = f"""sb_runtime_current() {{
  sb_pid=$(systemctl show --property=MainPID --value -- {quoted}) || return 42
  case "$sb_pid" in ''|*[!0-9]*) return 42;; 0) return 0;; esac
  sb_links=$(stat -Lc %h -- "/proc/$sb_pid/exe") || return 42
  case "$sb_links" in ''|*[!0-9]*) return 42;; esac
  test "$sb_links" -gt 0 || return 10
}}
""" if refresh_runtime else ""
    check += runtime_check
    check += f"systemctl is-active --quiet -- {quoted}\n"
    for member in members:
        check += f"systemctl is-active --quiet -- {shlex.quote(member)}\n"
    if refresh_runtime:
        check += "sb_runtime_current\n"
    if enable:
        check += f"systemctl is-enabled --quiet -- {quoted}\n"
    if options.get("validate_argv"):
        check += _argv(options["validate_argv"]) + " >/dev/null\n"

    for target, contract in access_contracts.items():
        check += f"sb_file_access check {contract} {shlex.quote(target)}\n"
    check += validation_script

    # All file preconditions run before the first write. Backups remain on the
    # host and preserve metadata; no credential-bearing file enters the report.
    apply = """set -eu
test "$(id -u)" = 0
sb_secure_parent() {
  sb_parent=$(dirname -- "$1")
  while [ "$sb_parent" != / ]; do
    test ! -L "$sb_parent" || return 1
    test -d "$sb_parent" || return 1
    test "$(stat -c %u -- "$sb_parent")" = 0 || return 1
    sb_mode=$(stat -c %a -- "$sb_parent")
    test "$((0$sb_mode & 0022))" = 0 || return 1
    sb_parent=$(dirname -- "$sb_parent")
  done
}
"""
    if normalized:
        guard = base64.b64encode(resource_files('sentinel_blue').joinpath('setup_file_guard.py').read_bytes()).decode()
        apply += f"command -v {py} >/dev/null\n"
        apply += "sb_file_guard() { " + py + " -I -S -c \"$(printf '%s' '" + guard + "' | base64 -d)\" \"$@\"; }\n"
    apply += access_helper
    for contract in access_contracts.values():
        apply += f"sb_file_access resolve {contract}\n"
    apply += preflight_script
    for target, content, mode, previous in normalized:
        path = shlex.quote(target)
        desired = hashlib.sha256(content.encode()).hexdigest()
        apply += f"sb_secure_parent {path}\ntest ! -L {path}\n"
        apply += f"if [ -e {path} ]; then\n  test -f {path}\n  test \"$(stat -c %h -- {path})\" = 1\n"
        apply += f"  sb_hash=$(sha256sum -- {path} | cut -d' ' -f1)\n"
        allowed = f'  test "$sb_hash" = {desired}'
        if previous != "absent":
            allowed += f' || test "$sb_hash" = {previous}'
        # A redo of the approved setup (set by the owned transaction, never by
        # the plan) puts back a file in whatever state damage left it.
        allowed += ' || test "${SENTINEL_SETUP_REDO:-}" = 1'
        apply += allowed + "\n"
        apply += "else\n" + ("  :\n" if previous == "absent" else '  test "${SENTINEL_SETUP_REDO:-}" = 1 || exit 42\n') + "fi\n"
    apply += f"sb_active=0; systemctl is-active --quiet -- {quoted} && sb_active=1\n"
    apply += "sb_runtime_replaced=0\n"
    if refresh_runtime:
        apply += runtime_check
        apply += ('if [ "$sb_active" = 1 ]; then\n'
                  '  if sb_runtime_current; then :; else\n'
                  '    sb_runtime_status=$?\n'
                  '    if [ "$sb_runtime_status" = 10 ]; then sb_runtime_replaced=1; else exit "$sb_runtime_status"; fi\n'
                  '  fi\nfi\n')
    apply += f"sb_enabled=$(systemctl is-enabled -- {quoted} 2>/dev/null || true)\n"
    # Whether this step creates the unit, from its load state, which every
    # systemd reports the same way (is-enabled output differs by release).
    apply += (f"sb_new_unit=0\nif [ \"$(systemctl show --property=LoadState --value -- {quoted} 2>/dev/null)\" = not-found ]; "
              "then sb_new_unit=1; fi\n")
    if not unmask:
        apply += 'case "$sb_enabled" in masked*) exit 42;; esac\n'
    # root's persistent backups are intentionally retained after either outcome.
    apply += "umask 077\nsb_backup=$(mktemp -d /var/lib/sentinel-setup-backup.XXXXXXXX)\n"
    apply += "sb_changed=0\n"
    rollback = "sb_restore() {\n  set +e\n  sb_restore_failed=0\n"
    # A unit this step created (it was "not-found" before) is stopped and
    # disabled while its file still exists, so no enable link is left behind.
    # Found live on 2.0.6: a new unit that failed to start could never be
    # rolled back, because stopping it after its file was removed fails
    # ("not loaded"); the step ended uncertain and held all setup on the host.
    rollback += (f'  if [ "$sb_new_unit" = 1 ]; then\n'
                 f'    timeout {SERVICE_COMMAND_SECONDS} systemctl stop -- {quoted} >/dev/null 2>&1\n'
                 f'    systemctl disable -- {quoted} >/dev/null 2>&1\n  fi\n')
    for index, (target, content, mode, _) in enumerate(normalized):
        path = shlex.quote(target)
        apply += f"if [ -e {path} ]; then cp -a -- {path} \"$sb_backup/{index}\"; else touch \"$sb_backup/{index}.absent\"; fi\n"
        apply += f"sb_file_guard prepare \"$sb_backup/{index}\" {path}\n"
        rollback += f"  sb_file_guard check \"$sb_backup/{index}\" {path} || sb_restore_failed=1\n"
    # Reject any known conflict before restoring a file or touching the service.
    rollback += '  [ "$sb_restore_failed" = 0 ] || return 1\n'
    for index, (target, *_rest) in enumerate(normalized):
        path = shlex.quote(target)
        rollback += f"  if [ -f \"$sb_backup/{index}.written\" ]; then sb_file_guard restore \"$sb_backup/{index}\" {path} || return 1; fi\n"
    if any(target.startswith("/etc/systemd/system/") for target, *_ in normalized):
        rollback += "  systemctl daemon-reload || sb_restore_failed=1\n"
    rollback += (f"  if [ \"$sb_active\" = 1 ]; then timeout {SERVICE_COMMAND_SECONDS} systemctl restart -- {quoted} || sb_restore_failed=1; "
                 f"elif [ \"$sb_new_unit\" = 1 ] && [ \"$(systemctl show --property=LoadState --value -- {quoted} 2>/dev/null)\" = not-found ]; then :; "
                 f"else timeout {SERVICE_COMMAND_SECONDS} systemctl stop -- {quoted} || sb_restore_failed=1; fi\n")
    if enable:
        rollback += f"  case \"$sb_enabled\" in disabled) systemctl disable -- {quoted} || sb_restore_failed=1;; esac\n"
    if unmask:
        rollback += f"  case \"$sb_enabled\" in masked) systemctl mask -- {quoted} || sb_restore_failed=1;; masked-runtime) systemctl mask --runtime -- {quoted} || sb_restore_failed=1;; esac\n"
    rollback += "  return $sb_restore_failed\n}\n"
    apply += rollback
    apply += "trap 'sb_status=$?; if [ \"$sb_status\" -ne 0 ]; then sb_restore || exit 43; fi' EXIT\n"
    for index, (target, content, mode, _) in enumerate(normalized):
        path = shlex.quote(target)
        digest = hashlib.sha256(content.encode()).hexdigest()
        # Compressed: a stock configuration (redis.conf is 106 KB) is then
        # wrapped again by the setup transaction, and an uncompressed copy
        # overflowed the plan's 256 KiB string limit so setup never started.
        encoded = base64.b64encode(zlib.compress(content.encode(), 9)).decode()
        apply += f"if [ ! -f {path} ] || [ \"$(sha256sum -- {path} | cut -d' ' -f1)\" != {digest} ] || [ \"$(stat -c %a -- {path})\" != {mode[1:]} ]; then\n"
        apply += f"  sb_temp=$(mktemp -- {shlex.quote(str(PurePosixPath(target).parent) + '/.sentinel-setup.XXXXXXXX')})\n"
        apply += f"  printf '%s' '{encoded}' | {py} -I -S -c '{INFLATE}' > \"$sb_temp\"\n"
        apply += f"  test \"$(sha256sum -- \"$sb_temp\" | cut -d' ' -f1)\" = {digest}\n"
        # Preserve an existing file's owner, ACLs, and xattrs by cloning before
        # replacing its content. New files receive the explicit reviewed mode.
        apply += f"  if [ -f {path} ]; then cp --attributes-only --preserve=all -- {path} \"$sb_temp\"; fi\n"
        if target in access_contracts:
            apply += f'  if sb_file_access stage {access_contracts[target]} "$sb_temp" {path}; then :; else\n'
            apply += '    sb_access_status=$?; rm -f -- "$sb_temp"; exit "$sb_access_status"\n  fi\n'
        else:
            apply += f'  chmod {mode} "$sb_temp"\n'
        apply += f"  sb_file_guard install \"$sb_backup/{index}\" {path} \"$sb_temp\"\n  sb_changed=1\nfi\n"
    for target, contract in access_contracts.items():
        apply += f"sb_file_access check {contract} {shlex.quote(target)}\n"
    if options.get("validate_argv"):
        apply += _argv(options["validate_argv"]) + "\n"
    apply += validation_script
    if unmask:
        apply += f"systemctl unmask -- {quoted}\n"
    if any(target.startswith("/etc/systemd/system/") for target, *_ in normalized):
        apply += "systemctl daemon-reload\n"
    if enable:
        apply += f"systemctl enable -- {quoted}\n"
    # Start and restart wait for systemd's job. A unit that never finishes
    # stopping (TimeoutStopSec=0) would hold that wait, and this whole setup
    # task, until the task deadline killed it with its outcome unknown. A bound
    # turns it into an ordinary failure the restore trap then undoes.
    apply += "sb_started=0\n"
    apply += (f"if [ \"$sb_active\" = 1 ] && {{ [ \"$sb_changed\" = 1 ] || [ \"$sb_runtime_replaced\" = 1 ]; }}; then "
              f"timeout {SERVICE_COMMAND_SECONDS} systemctl restart -- {quoted}; sb_started=1; "
              f"elif [ \"$sb_active\" != 1 ]; then timeout {SERVICE_COMMAND_SECONDS} systemctl start -- {quoted}; sb_started=1; fi\n")
    apply += f"systemctl is-active --quiet -- {quoted}\n"
    active_members = "".join(f" && systemctl is-active --quiet -- {shlex.quote(member)}" for member in members)
    # A simple-type unit is "active" the moment its process is forked, so a
    # daemon that exits on a bad configuration passes the check above and dies
    # a moment later. Setup then recorded an after-state that no longer held,
    # could prove neither success nor its own undo, and left an uncertain
    # transaction that holds every later setup and all recovery on the host.
    # Watching it stay up turns that into an ordinary failed, rolled-back step.
    # Only a start or restart this step made needs watching; a service that
    # was already running and unchanged was not touched.
    apply += (f"if [ \"$sb_started\" = 1 ]; then\n  sb_settle=0\n  while [ \"$sb_settle\" -lt {SETTLE_SECONDS} ]; do\n"
              f"    sleep 1\n    systemctl is-active --quiet -- {quoted}{active_members}\n    sb_settle=$((sb_settle + 1))\n  done\nfi\n")
    for member in members:
        apply += f"systemctl is-active --quiet -- {shlex.quote(member)}\n"
    if refresh_runtime:
        apply += "sb_runtime_current\n"
    apply += "trap - EXIT\n"
    return check, apply, None


def _windows_features(options: dict) -> tuple[str, str, str | None]:
    values = options.get("features")
    if not isinstance(values, list) or not values or len(values) > 32:
        raise ValueError("windows-features requires 1 to 32 feature names")
    names = ",".join(_ps(_name(x, "Windows feature")) for x in values)
    header = "$ErrorActionPreference = 'Stop'\nImport-Module ServerManager\n"
    check = header + f"$features = @(Get-WindowsFeature -Name {names})\n"
    check += f"if ($features.Count -ne {len(set(values))}) {{ exit 20 }}\n"
    check += "$missing = @($features | Where-Object { -not $_.Installed })\n"
    check += "if ($missing.Count -gt 0) { exit 10 }; exit 0\n"
    apply = check.replace("if ($missing.Count -gt 0) { exit 10 }", "if ($missing.Count -gt 0) { Write-Error 'Offline prerequisite missing: install from approved local Windows media before setup'; exit 25 }")
    return check, apply, None


def _windows_service(options: dict) -> tuple[str, str, str | None]:
    name = _ps(_name(options.get("service"), "Windows service"))
    enable = _boolean(options, "enable")
    check = "$ErrorActionPreference = 'Stop'\n"
    check += f"$svc = Get-Service -Name {name}\nif ($svc.Status -ne 'Running') {{ exit 10 }}\n"
    if enable:
        check += "if ($svc.StartType -ne 'Automatic') { exit 10 }\n"
    check += "exit 0\n"
    apply = "$ErrorActionPreference = 'Stop'\n"
    apply += f"$svc = Get-Service -Name {name}\n"
    if enable:
        apply += f"Set-Service -Name {name} -StartupType Automatic\n"
    else:
        apply += "if ($svc.StartType -eq 'Disabled') { exit 42 }\n"
    apply += f"Start-Service -Name {name}\n(Get-Service -Name {name}).WaitForStatus('Running', [TimeSpan]::FromSeconds(45))\nexit 0\n"
    return check, apply, None


def compile_recipe(recipe: str, options: dict, root: Path, platform: str) -> tuple[str, str, str | None]:
    if recipe not in RECIPES or not isinstance(options, dict):
        raise ValueError("unknown setup recipe or invalid options")
    if recipe == "linux-service-pack":
        if platform != "linux":
            raise ValueError("Linux setup recipe assigned to a non-Linux host")
        from .linux_service_packs import build
        catalog_id = options.get("catalog_id")
        if not isinstance(catalog_id, str):
            raise ValueError("a service pack names its catalog service in catalog_id")
        return build(catalog_id, {key: value for key, value in options.items()
                                  if key != "catalog_id"}, root)
    if recipe in {"linux-router", "linux-nginx", "windows-firewall", "windows-iis"}:
        if not recipe.startswith(platform + "-"):
            raise ValueError("Provisioning recipe does not match the target platform")
        if recipe == "linux-router":
            from .network_setup import script
            return script('check', options), script('apply', options), script('rollback', options)
        from .application_setup import compile_application
        return compile_application(recipe, options, root)
    allowed = {
        "linux-packages": {"packages", "manager", "cache_only"},
        "linux-service": {"service", "enable", "unmask", "files", "validate_argv", "refresh_replaced_executable"},
        "windows-features": {"features"},
        "windows-service": {"service", "enable"},
        "windows-python": {"version", "sha256", "install_directory"},
        "runbook": {"check", "apply", "rollback"},
    }
    if set(options) - allowed[recipe]:
        raise ValueError("unknown setup recipe option")
    if recipe.startswith("linux-") and platform != "linux":
        raise ValueError("Linux setup recipe assigned to a non-Linux host")
    if recipe.startswith("windows-") and platform != "windows":
        raise ValueError("Windows setup recipe assigned to a non-Windows host")
    if recipe == "linux-packages":
        return _linux_packages(options)
    if recipe == "linux-service":
        return _linux_service(options, root)
    if recipe == "windows-features":
        return _windows_features(options)
    if recipe == "windows-service":
        return _windows_service(options)
    if recipe == "windows-python":
        from .runtime_setup import windows_python
        return windows_python(options)
    if set(options) - {"check", "apply", "rollback"}:
        raise ValueError("unknown runbook option")
    check = _source(root, options.get("check"))
    apply = _source(root, options.get("apply"))
    rollback = _source(root, options["rollback"]) if options.get("rollback") else None
    return check, apply, rollback


def compile_commit(recipe, options):
    if recipe == 'linux-router':
        from .network_setup import script
        return script('commit', options)
    return None
