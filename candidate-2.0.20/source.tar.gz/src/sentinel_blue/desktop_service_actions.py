"""GUI for explicit, server-reviewed service choices, journal undo and budgets."""
from __future__ import annotations

import copy
import json
import time

from .operator_recovery import CHOICES
from .recovery_policy_editor import PRESETS, policy_candidate, save_candidate


class ServiceActionDialog:
    def __init__(self, app, agent, service):
        self.app, self.agent, self.service = app, agent, service
        self.client, self.generation = app.client, app.generation
        self.review = None
        self.automation_state = None
        self.busy = False
        self.review_generation = 0
        tk, ttk = app.tk, app.ttk
        self.window = tk.Toplevel(app.root)
        self.window.title(f'Service actions — {agent} / {service}')
        self.window.geometry('960x720'); self.window.minsize(780, 600)
        self.window.transient(app.root)
        frame = ttk.Frame(self.window, padding=14); frame.pack(fill='both', expand=True)
        ttk.Label(frame, text=f'{agent} / {service}', font=('Segoe UI', 16, 'bold')).pack(anchor='w')
        ttk.Label(frame, text='Choose a supported action, review its exact effects, then approve. '
            'Approved autonomous recoveries appear in History automatically. Undo pauses this service until explicit resume.',
            wraplength=870).pack(anchor='w', pady=(5, 10))
        notebook = ttk.Notebook(frame); notebook.pack(fill='both', expand=True)
        self.action_tab = ttk.Frame(notebook, padding=10)
        self.history_tab = ttk.Frame(notebook, padding=10)
        self.policy_tab = ttk.Frame(notebook, padding=10)
        for name, tab in [('Choose action / approve', self.action_tab), ('History / undo', self.history_tab),
                          ('Repeated-disruption policy', self.policy_tab)]:
            notebook.add(tab, text=name)
        self.notebook = notebook
        self.status = tk.StringVar(value='No action reviewed or queued.')
        ttk.Label(frame, textvariable=self.status, wraplength=880).pack(fill='x', pady=(8, 0))
        self._actions(); self._history(); self._policy()
        self.window.protocol('WM_DELETE_WINDOW', self.window.destroy)

    def _exists(self):
        try:
            return bool(self.window.winfo_exists())
        except self.app.tk.TclError:
            return False

    def _current(self):
        return (self._exists() and self.app.client is self.client
                and self.app.generation == self.generation and self.client is not None)

    def _work(self, operation, complete):
        if self.busy:
            self.status.set('An operation is already in progress.'); return
        if not self._current():
            self.status.set('Connection changed. Reopen this dialog on the intended controller.'); return
        self.busy = True
        def done(value):
            self.busy = False
            if self._current():
                complete(value)
        def failed(exc):
            self.busy = False
            if self._exists():
                self.review = None
                self.approve.configure(state='disabled')
                self.status.set('Held / not confirmed: ' + str(exc)[:600])
                self._show({'held': str(exc)[:1200], 'next': 'Inspect History before retrying if a reply was lost. '
                    'Unknown outcomes, failed rollback, stale observations and missing permissions are not bypassed.'})
        submitted = self.app.submit(operation, done, failed)
        if submitted is False:
            self.busy = False
            self._invalidate()
            self.status.set('Local GUI work queue is busy or closed; nothing was submitted. Review again when it is available.')

    def _actions(self):
        tk, ttk, tab = self.app.tk, self.app.ttk, self.action_tab
        row = ttk.Frame(tab); row.pack(fill='x')
        self.choice_labels = {CHOICES[key]: key for key in ('check', 'start', 'repair')}
        self.choice = tk.StringVar(value=CHOICES['check'])
        box = ttk.Combobox(row, textvariable=self.choice, values=list(self.choice_labels), state='readonly', width=62)
        box.pack(side='left', fill='x', expand=True)
        box.bind('<<ComboboxSelected>>', lambda _: self._invalidate())
        ttk.Button(row, text='Review selected action', command=self.review_choice).pack(side='left', padx=8)
        controls = ttk.Frame(tab); controls.pack(side='bottom', fill='x', pady=(10, 0))
        ttk.Label(controls, text='Reason (required; do not enter passwords):').pack(anchor='w')
        self.reason = tk.StringVar()
        ttk.Entry(controls, textvariable=self.reason).pack(fill='x', pady=5)
        self.approve = ttk.Button(controls, text='Approve and run reviewed action', state='disabled', command=self.execute_review)
        self.approve.pack(anchor='w')
        text_frame = ttk.Frame(tab); text_frame.pack(fill='both', expand=True, pady=(10, 0))
        self.details = tk.Text(text_frame, height=14, wrap='word', state='disabled',
                               bg='#172636', fg='#edf3f8', relief='flat', padx=10, pady=10)
        scroll = ttk.Scrollbar(text_frame, command=self.details.yview)
        self.details.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right', fill='y'); self.details.pack(fill='both', expand=True)
        self._show('Review is read-only. Approval queues a signed action; it does not mean the agent executed it. '
                   'A real coordinated repair saves its before-state and rolls back on validation failure. '
                   'For a later problem, use History / undo and review its exact inverse.')

    def _invalidate(self):
        self.review_generation += 1
        self.review = None
        self.approve.configure(state='disabled')
        self.status.set('Choice changed. Review again before approval.')

    def _show(self, value):
        self.details.configure(state='normal'); self.details.delete('1.0', 'end')
        self.details.insert('1.0', value if isinstance(value, str) else json.dumps(value, indent=2))
        self.details.configure(state='disabled')

    def _show_review(self, value):
        selection, effects = value['selection'], value['effects']
        lines = [CHOICES[selection['choice']], f"Target: {self.agent} / {self.service}",
                 "Review only: nothing has been changed. Expires in 90 seconds.", ""]
        if selection['choice'] == 'undo':
            lines += ["Original action: " + effects['original_action_id'],
                      "Restore previous service state: " + effects['restore_previous_service_state'],
                      "Restore the recorded previous bytes for:"]
            lines += ["  " + path for path in effects['restore_previous_files']] or ["  No file changes in this action."]
        elif selection['choice'] != 'check':
            lines += ["Service state: " + effects['previous_state'] + " -> " + effects['desired_state'],
                      "Restore these approved configuration files:"]
            lines += ["  " + path for path in effects['restore_approved_files']] or ["  No file changes in this action."]
            if effects.get('startup'):lines += ["Includes the explicitly reviewed startup change."]
            budget = effects['budget']
            lines += [f"Recovery allowance: {budget['attempts_in_window']} of {budget['maximum_attempts']} used this hour."]
        lines += ["", effects['warning'], "", "Detailed bound review / evidence:", json.dumps(value, indent=2)]
        self._show('\n'.join(lines))

    def _review_selection(self, choice, action_id=''):
        if not self._current() or self.busy:
            self.status.set('Reconnect or finish the current operation before reviewing.'); return
        self._invalidate()
        payload = {'agent_id': self.agent, 'service': self.service, 'choice': choice, 'action_id': action_id}
        revision = self.review_generation
        def ready(value):
            if revision != self.review_generation:
                self.status.set('Choice changed while the review was loading. Review the new selection.'); return
            self.review = value
            self._show_review(value)
            self.approve.configure(state='normal', text=('Approve recorded undo' if choice == 'undo'
                                                       else 'Approve and run reviewed action'))
            self.status.set('Review ready. Expires in 90 seconds; changed effects require a new review.')
            self.notebook.select(self.action_tab)
        self._work(lambda: self.client.request('/api/v1/service-actions/review', payload), ready)

    def review_choice(self):
        choice = self.choice_labels.get(self.choice.get())
        if choice:
            self._review_selection(choice)

    def execute_review(self):
        if self.busy or self.review is None or not self._current():
            return
        review = copy.deepcopy(self.review)
        reason = self.reason.get().strip()
        if not 3 <= len(reason) <= 500 or any(ord(c) < 32 for c in reason):
            self.status.set('Enter a printable reason between 3 and 500 characters.'); return
        undo = review['selection']['choice'] == 'undo'
        message = (f"{CHOICES[review['selection']['choice']]}\n\nTarget: {self.agent} / {self.service}\n"
                   'Only the reviewed plan will be queued. The agent must recheck permissions, '
                   'current state, and the recorded files before changing anything.')
        if undo:
            message += '\n\nUndo may return the service to an unhealthy before-state. It cannot restore process memory or lost user data. Automatic recovery and setup redo remain paused until you explicitly resume this service.'
        if not self.app.messagebox.askyesno('Approve recorded undo' if undo else 'Approve service action',
                                            message, parent=self.window):
            return
        self.approve.configure(state='disabled')
        def operation():
            authorization = ''
            if review.get('requires_authorization_code'):
                authorization = self.client.request('/api/v1/authorizations', {
                    'agent_id': self.agent, 'action_type': review['action_type'],
                    'subject': review['authorization_subject'], 'ttl_seconds': 90})['authorization_code']
            return self.client.request('/api/v1/service-actions/execute', {
                'review_id': review['review_id'], 'review_sha256': review['review_sha256'],
                'reason': reason, 'authorization_code': authorization})
        def queued(value):
            self.review = None
            self.status.set('Queued action ' + value['action_id'] + '. Refresh History to see the actual agent result.')
            self.app.note(self.status.get())
            self._show(value)
            self.app.next_poll = 0
            self.refresh_history()
        self._work(operation, queued)

    def _history(self):
        ttk, tab = self.app.ttk, self.history_tab
        ttk.Label(tab, text='Undo only an exact recorded, successful repair. Already rolled-back, dry-run, '
            'failed or unknown actions are not represented as undoable successes. Automatic starts, coordinated repairs and '
            'declared file restorations share this view. Undo pauses further automatic recovery for this service.',
            wraplength=840).pack(anchor='w', pady=(0, 8))
        row = ttk.Frame(tab); row.pack(side='bottom', fill='x', pady=10)
        ttk.Button(row, text='Refresh results', command=self.refresh_history).pack(side='left')
        ttk.Button(row, text='Review undo of selected action', command=self.review_undo).pack(side='left', padx=8)
        self.automation_status = self.app.tk.StringVar(value='Refresh results to read the active automation state.')
        ttk.Label(tab, textvariable=self.automation_status, wraplength=830).pack(anchor='w', pady=5)
        controls = ttk.Frame(tab); controls.pack(side='bottom', fill='x', pady=5)
        ttk.Button(controls, text='Pause automatic recovery', command=lambda: self.change_automation(True)).pack(side='left')
        ttk.Button(controls, text='Resume approved automatic recovery', command=lambda: self.change_automation(False)).pack(side='left', padx=8)
        self.history = self.app._tree(tab, ('Time', 'Source', 'Action', 'Status', 'Undo', 'Result'), (90, 90, 130, 90, 70, 310))
        self.history_rows = {}
        self.history.bind('<Double-1>', lambda _: self.show_history_result())

    def refresh_history(self):
        def complete(value):
            chosen = self.history.selection()
            self.history.delete(*self.history.get_children()); self.history_rows = {}
            for item in value['actions']:
                key = item['action_id']; self.history_rows[key] = item
                stamp = time.strftime('%H:%M:%S', time.localtime(item['created_at']))
                self.history.insert('', 'end', iid=key, values=(stamp, 'Automatic' if item.get('automated') else 'Operator', item['action_type'], item['status'],
                    item.get('undo_status', 'Review' if item['undo_candidate'] else 'No'), item['message']))
            if chosen and self.history.exists(chosen[0]):
                self.history.selection_set(chosen[0])
            self.automation_state = value.get('service_automation')
            current = (self.automation_state or {}).get('services', {}).get(self.service, {})
            sync = value.get('automation_sync') or {}
            text = (('PAUSED: ' + current.get('reason', 'Operator hold') + '. Explicit resume required.')
                if current.get('paused') else ('Approved automatic recovery is enabled; individual permission and safety gates still apply.'
                if value.get('automatic_recovery_enabled') else 'No service hold; global recovery may be disabled or awaiting authorization.'))
            if sync.get('behind'):
                held = ', '.join(sync.get('agent_held', []) + [s for s in sync.get('agent_latched', [])
                                                                if s not in sync.get('agent_held', [])]) or 'none reported'
                text = (f"AGENT HOLDS AUTOMATIC RECOVERY: this controller's automation state (revision "
                        f"{sync.get('controller_revision')}) is older than, conflicts with or does not carry the holds "
                        f"of the agent's durable floor (revision "
                        f"{sync.get('agent_floor_revision')}); agent-held services: {held}. Manual actions still run. "
                        'After review, Pause or Resume re-synchronizes and carries the agent holds forward. ' + text)
            self.automation_status.set(text)
            if value['truncated']:
                self.status.set('History is a bounded recent view, not the complete action ledger. Undo rechecks the full relevant window.')
        self._work(lambda: self.client.request('/api/v1/service-actions/history',
                   {'agent_id': self.agent, 'service': self.service}), complete)

    def change_automation(self, paused):
        if not self._current() or self.busy:
            self.status.set('Finish the current operation or reconnect first.'); return
        if self.automation_state is None:
            self.status.set('Refresh results first to read the current automation revision.'); return
        reason = self.reason.get().strip()
        if not 3 <= len(reason) <= 500:
            self.status.set('Enter a reason in Choose action / approve before changing automation.');
            self.notebook.select(self.action_tab); return
        prompt = ('Pause new automatic recovery for this exact service? Never-delivered automatic actions are cancelled; already running work is not cancelled.'
                  if paused else 'Resume only the already approved automatic recovery for this service? '
                  'This does not change the baseline, grant permissions, clear failure history, or enable a globally disabled controller.')
        if not self.app.messagebox.askyesno('Service automation', prompt, parent=self.window):
            return
        payload = {'agent_id': self.agent, 'service': self.service, 'paused': paused, 'reason': reason,
                   'expected_revision': self.automation_state['revision']}
        def done(value):
            self.automation_state = value['service_automation']
            self.status.set(value['message']); self.app.note(value['message'])
            self.app.next_poll = 0
            self.refresh_history()
        self._work(lambda: self.client.request('/api/v1/service-actions/automation', payload), done)

    def show_history_result(self):
        chosen = self.history.selection()
        if chosen:
            self._invalidate()
            self._show(self.history_rows[chosen[0]])
            self.notebook.select(self.action_tab)

    def review_undo(self):
        chosen = self.history.selection()
        if not chosen:
            self.status.set('Select a completed, journaled recovery in History first.'); return
        if not self.history_rows[chosen[0]].get('undo_candidate'):
            self.status.set('This action has no completed real repair journal to undo. Inspect its result or reconciliation workflow.'); return
        self._review_selection('undo', chosen[0])

    def _policy(self):
        tk, ttk, tab = self.app.tk, self.app.ttk, self.policy_tab
        ttk.Label(tab, text='Repeated successful recoveries can have a higher per-service allowance. '
            'Failures retain a 300-second cooldown and a three-failures-per-hour circuit breaker. '
            'Unknown outcomes and Emergency Stop remain held. This edits a NEW unapproved profile copy; '
            'it does not change a running agent or clear attempt history.', wraplength=850).pack(anchor='w', pady=8)
        self.policy_source = tk.StringVar(
            value=self.app.profile_path.get() if hasattr(self.app, 'profile_path') else '')
        form = ttk.Frame(tab); form.pack(fill='x', pady=10)
        ttk.Label(form, text='Source event profile').grid(row=0, column=0, sticky='w')
        ttk.Entry(form, textvariable=self.policy_source).grid(row=0, column=1, sticky='ew', padx=8)
        def browse():
            selected = self.app.filedialog.askopenfilename(parent=self.window, title='Select the current event profile',
                                                         filetypes=[('JSON profile', '*.json'), ('All files', '*')])
            if selected: self.policy_source.set(selected)
        ttk.Button(form, text='Browse', command=browse).grid(row=0, column=2)
        form.columnconfigure(1, weight=1)
        self.preset = tk.StringVar(value='Conservative')
        preset_box = ttk.Combobox(form, textvariable=self.preset, values=list(PRESETS), state='readonly')
        ttk.Label(form, text='Candidate preset (not live)').grid(row=1, column=0, sticky='w', pady=8)
        preset_box.grid(row=1, column=1, sticky='ew', padx=8)
        self.cooldown = tk.StringVar(value='300'); self.maximum = tk.StringVar(value='3')
        for index, (name, variable) in enumerate([('Cooldown seconds (15–300)', self.cooldown),
                                                ('Maximum attempts/hour (1–120)', self.maximum)], start=2):
            ttk.Label(form, text=name).grid(row=index, column=0, sticky='w', pady=8)
            ttk.Entry(form, textvariable=variable).grid(row=index, column=1, sticky='ew', padx=8)
        def preset(_=None):
            value = PRESETS[self.preset.get()]
            self.cooldown.set(str(value['cooldown_seconds'])); self.maximum.set(str(value['maximum_attempts']))
        preset_box.bind('<<ComboboxSelected>>', preset)
        ttk.Button(tab, text='Review and save new policy candidate…', command=self.save_policy).pack(anchor='w', pady=10)
        ttk.Label(tab, text='Applies only to this exact host/service. No service permissions are added. '
            'After approval, redeploy the matching profile to the controller AND agents using the existing '
            'safe migration workflow. Setup-redo retains its separate 3/hour and 600-second limits. '
            'Faster successful recovery is not proof that an attacker was removed.', wraplength=850).pack(anchor='w')

    def save_policy(self):
        try:
            from .event_profile import load_event_profile
            limits = {'cooldown_seconds': int(self.cooldown.get()), 'maximum_attempts': int(self.maximum.get())}
            source = load_event_profile(self.policy_source.get())
            candidate, report = policy_candidate(source.raw, [(self.agent, self.service)], limits)
            if self.app.snapshot:
                expected = (self.app.snapshot.get('controller', {}).get('governance') or {}).get('profile_fingerprint')
                if expected and expected != source.fingerprint:
                    raise ValueError('source profile differs from the connected controller; use its exact profile')
            if not self.app.messagebox.askyesno('Review recovery policy candidate',
                    json.dumps(report, indent=2), parent=self.window):
                return
            path = self.app.filedialog.asksaveasfilename(parent=self.window, title='Save NEW unapproved profile',
                                                       defaultextension='.json', initialfile='recovery-policy-candidate.json')
            if not path: return
            result = save_candidate(path, candidate)
        except (OSError, TypeError, ValueError) as exc:
            self.status.set('Policy not saved: ' + str(exc)[:600]); return
        self.status.set('Saved unapproved candidate: ' + result + '. Not applied to the running session.')
        self.app.note(self.status.get())


class ServiceActionControls:
    def open_service_actions(self):
        if self.client is None:
            self.note('Connect to the controller first.'); return
        chosen = self.services.selection()
        if not chosen:
            self.note('Select the exact VM/service row on Services first.'); return
        values = self.services.item(chosen[0], 'values')
        if len(values) < 2:
            self.note('Refresh the service list first.'); return
        return ServiceActionDialog(self, str(values[0]), str(values[1]))
