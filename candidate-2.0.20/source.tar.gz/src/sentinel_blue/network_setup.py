"""Typed configuration compiler for an explicitly declared Linux IPv4 router.

Routing, NAT and interface addresses are IPv4 only. Filtering is not: the table
is `inet`, so it sees IPv6 as well, and a drop policy has to drop it. Until 2.0.2
both drops were written `meta nfproto ipv4 drop`, so on a host with IPv6 enabled
— every current Linux default — `input_policy: drop` left every IPv6 listener
reachable while the operator believed the host was default-deny. Most daemons
listen dual-stack, so that was the whole host, not a corner of it.

Input and forward drops are now family-agnostic. ICMPv6 is accepted ahead of
the invalid-state drop, because IPv6 does not work without neighbor discovery,
and blocking it would take the host off an IPv6 network rather than filter it.
Management and allow rules may name IPv6 sources, written `ip6 saddr`, so a
service that must answer over IPv6 can be allowed explicitly instead of being
left open by accident.
"""

from __future__ import annotations
from .runtime_environment import target_python_shell

import base64
import ipaddress
import json
import re
from importlib.resources import files


def identifier(value, label, maximum=32):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{0,' + str(maximum-1) + '}', value):
        raise ValueError('Invalid ' + label)
    return value


def network(value, *, families=(4,)):
    """A literal CIDR network of an allowed IP family.

    The type is tested first: `ipaddress.ip_network(5)` is `0.0.0.5/32`, so a
    number an operator typed where a network belongs would otherwise be admitted
    as a real, and wrong, address.
    """
    if not isinstance(value, str):
        raise ValueError('Networks must be written as literal CIDR text')
    parsed = ipaddress.ip_network(value, strict=True)
    if parsed.version not in families:
        if families == (4,):
            raise ValueError('This router adapter requires explicit IPv4 networks')
        raise ValueError('Networks must be IPv4 or IPv6 CIDR text')
    return str(parsed)


# Input filtering sees both families; routing, forwarding and NAT stay IPv4.
FILTER_FAMILIES = (4, 6)


def _source_match(source):
    """`ip saddr` for an IPv4 source, `ip6 saddr` for an IPv6 one."""
    return ('ip6' if ipaddress.ip_network(source).version == 6 else 'ip') + ' saddr ' + source


def port(value):
    if type(value) is not int or not 1 <= value <= 65535:
        raise ValueError('Port must be from 1 to 65535')
    return value


def _rows(value, label, allowed, required=()):
    if not isinstance(value, list) or len(value) > 64:
        raise ValueError(label + ' must contain at most 64 entries')
    for row in value:
        if not isinstance(row, dict) or set(row) - set(allowed) or set(required) - set(row):
            raise ValueError('Invalid ' + label + ' fields')
    return value


def normalize(options):
    if not isinstance(options, dict) or set(options) - {'name', 'forwarding', 'input_policy', 'management', 'allow', 'forward', 'masquerade', 'routes', 'addresses', 'rollback_seconds', 'manager', 'cache_only', 'path_checks'}:
        raise ValueError('Invalid Linux router options')
    result = {'name': identifier(options.get('name'), 'router name')}
    result['manager'] = options.get('manager', 'apt')
    result['cache_only'] = options.get('cache_only', True)
    if result['manager'] not in {'apt', 'dnf'} or type(result['cache_only']) is not bool:
        raise ValueError('Router setup requires apt/dnf and a boolean cache_only')
    result['forwarding'] = options.get('forwarding', True)
    if type(result['forwarding']) is not bool:
        raise ValueError('forwarding must be a boolean')
    result['input_policy'] = options.get('input_policy', 'accept')
    if result['input_policy'] not in {'accept', 'drop'}:
        raise ValueError('input_policy must be accept or drop')
    seconds = options.get('rollback_seconds', 120)
    if type(seconds) is not int or not 30 <= seconds <= 300:
        raise ValueError('rollback_seconds must be from 30 to 300')
    result['rollback_seconds'] = seconds
    result['management'] = [dict(source=network(row['source'], families=FILTER_FAMILIES), port=port(row['port'])) for row in
        _rows(options.get('management', []), 'management', {'source', 'port'}, {'source', 'port'})]
    if not result['management']:
        raise ValueError('Declare at least one management source network and TCP port')
    result['allow'] = []
    for row in _rows(options.get('allow', []), 'allow', {'source', 'protocol', 'port'}, {'source', 'protocol', 'port'}):
        if row['protocol'] not in {'tcp', 'udp'}:
            raise ValueError('Allow rules require TCP or UDP')
        result['allow'].append(dict(source=network(row['source'], families=FILTER_FAMILIES),
                                    protocol=row['protocol'], port=port(row['port'])))
    result['forward'] = []
    for row in _rows(options.get('forward', []), 'forward', {'source', 'destination', 'protocol', 'port', 'in_interface', 'out_interface'}, {'source', 'destination', 'in_interface', 'out_interface'}):
        value = {key: network(row[key]) for key in ('source', 'destination')}
        value.update({key: identifier(row[key], 'interface', 15) for key in ('in_interface', 'out_interface')})
        if 'protocol' in row or 'port' in row:
            if row.get('protocol') not in {'tcp', 'udp'} or 'port' not in row:
                raise ValueError('Forward port rules require TCP or UDP and a port')
            value.update(protocol=row['protocol'], port=port(row['port']))
        result['forward'].append(value)
    result['masquerade'] = [dict(source=network(row['source']), out_interface=identifier(row['out_interface'], 'interface', 15)) for row in
        _rows(options.get('masquerade', []), 'masquerade', {'source', 'out_interface'}, {'source', 'out_interface'})]
    if not result['forwarding'] and (result['forward'] or result['masquerade']):
        raise ValueError('Forward and NAT rules require forwarding')
    result['routes'] = []
    for row in _rows(options.get('routes', []), 'routes', {'destination', 'via', 'interface'}, {'destination', 'via', 'interface'}):
        gateway = ipaddress.ip_address(row['via'])
        if gateway.version != 4 or gateway.is_unspecified or gateway.is_multicast:
            raise ValueError('Route gateway must be a unicast IPv4 address')
        destination = network(row['destination'])
        if destination == '0.0.0.0/0':
            raise ValueError('Default-route replacement requires a separate reviewed platform runbook')
        result['routes'].append(dict(destination=destination, via=str(gateway), interface=identifier(row['interface'], 'interface', 15)))
    if len({row['destination'] for row in result['routes']}) != len(result['routes']):
        raise ValueError('Route destinations must be unique')
    result['addresses'] = []
    for row in _rows(options.get('addresses', []), 'addresses', {'address', 'interface'}, {'address', 'interface'}):
        address = ipaddress.ip_interface(row['address'])
        if address.version != 4 or address.ip.is_unspecified or address.ip.is_multicast:
            raise ValueError('Interface address must be unicast IPv4')
        result['addresses'].append(dict(address=str(address), interface=identifier(row['interface'], 'interface', 15)))
    if len({row['address'] for row in result['addresses']}) != len(result['addresses']):
        raise ValueError('Interface addresses must be unique')
    return result


def ruleset(spec):
    name = 'sentinel_blue_' + spec['name']
    # ICMPv6 comes before the invalid-state drop: neighbor discovery and
    # packet-too-big are ICMPv6, and IPv6 stops working without them. This mirrors
    # the IPv4 rule below, which has always accepted ICMP.
    lines = [f'table inet {name} {{', ' chain input {', '  type filter hook input priority 10; policy accept;',
             '  iifname "lo" accept', '  ct state established,related accept',
             '  meta l4proto ipv6-icmp accept',
             '  ct state invalid drop', '  ip protocol icmp accept']
    for row in spec['management']:
        lines.append(f"  {_source_match(row['source'])} tcp dport {row['port']} accept")
    for row in spec['allow']:
        lines.append(f"  {_source_match(row['source'])} {row['protocol']} dport {row['port']} accept")
    if spec['input_policy'] == 'drop':
        # Both families. An IPv4-only drop left every dual-stack listener open.
        lines.append('  drop')
    lines += [' }', ' chain forward {', '  type filter hook forward priority 10; policy accept;',
              '  ct state established,related accept']
    for row in spec['forward']:
        rule = f"  iifname \"{row['in_interface']}\" oifname \"{row['out_interface']}\" ip saddr {row['source']} ip daddr {row['destination']}"
        if row.get('protocol'):
            rule += f" {row['protocol']} dport {row['port']}"
        lines.append(rule + ' accept')
    if spec['forwarding']:
        # Forward rules are IPv4, so any IPv6 transit is unreviewed and dropped.
        lines.append('  drop')
    lines += [' }', ' chain postrouting {', '  type nat hook postrouting priority 100; policy accept;']
    for row in spec['masquerade']:
        lines.append(f"  ip saddr {row['source']} oifname \"{row['out_interface']}\" masquerade")
    return '\n'.join(lines + [' }', '}', ''])


def script(phase, options):
    spec = normalize(options)
    spec['ruleset'] = ruleset(spec)
    source = files('sentinel_blue').joinpath('network_native.py').read_text(encoding='utf-8')
    ledger_source = base64.b64encode(files('sentinel_blue').joinpath('mutation_ledger.py').read_bytes()).decode()
    prelude = "import base64,sys,types\nledger=types.ModuleType('sentinel_mutation_ledger');sys.modules[ledger.__name__]=ledger\n" + f"exec(compile(base64.b64decode('{ledger_source}'),'sentinel-ledger','exec'),ledger.__dict__)\n"
    source = source.replace('import base64\n', 'import base64\n' + prelude, 1)
    encoded = base64.b64encode(source.encode()).decode()
    payload = base64.b64encode(json.dumps(spec, sort_keys=True).encode()).decode()
    def invoke(operation):
        return (f"{target_python_shell()} -I -B - <<'SENTINEL_NETWORK'\nimport base64,json\n"
            f"source=base64.b64decode('{encoded}').decode()\nnamespace={{'__name__':'sentinel_network'}}\nexec(compile(source,'sentinel-network','exec'),namespace)\n"
            f"namespace['run']('{operation}',json.loads(base64.b64decode('{payload}')),source)\nSENTINEL_NETWORK\n")
    command = 'set -eu\n'
    if phase == 'apply':
        from .setup_recipes import _linux_packages
        packages = ['nftables', 'iproute2', 'procps'] if spec['manager'] == 'apt' else ['nftables', 'iproute', 'procps-ng']
        check, install, _ = _linux_packages({'manager': spec['manager'], 'cache_only': spec['cache_only'], 'packages': packages})
        command += 'if (\n' + check + '); then :; else\necho \"Router prerequisites require a reviewed package mutation adapter\" >&2; exit 25\nfi\n'
    if phase == 'commit':
        command += invoke('activate')
        command += 'systemctl start -- sentinel-router-' + spec['name'] + '.service\n'
    return command + invoke(phase)
