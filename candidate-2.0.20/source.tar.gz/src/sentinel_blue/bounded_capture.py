"""Standalone, quota-enforced native-client capture; never spools child output.

The input file is finite/private. Output is bounded in memory as it arrives.
Timeout/overflow stop only this command's owned process group/tree and return no
partial success. Cleanup cannot prove that a remote or partially written state
was restored. This module is also embedded into generated service-pack checks.
"""
from __future__ import annotations

import math
import os
import signal
import subprocess
import sys
import tempfile
import time

CAPTURE_CLEANUP_GRACE = 0.2
CAPTURE_BLOCK_BYTES = 65536
MAX_CAPTURE_INPUT = 16 * 1024 * 1024


class CaptureError(RuntimeError):
    """Sanitized failure evidence: no argv, stdin, credentials or child output."""
    def __init__(self, reason, captured_bytes=0):
        self.reason = reason
        self.captured_bytes = captured_bytes
        self.uncertain = True
        super().__init__('Native client capture failed: ' + reason + '; cleanup may be uncertain')


def _linux_namespace_depth() -> int:
    """Locate the caller's PID namespace relative to the mounted procfs."""
    with open("/proc/self/status", "r", encoding="utf-8", errors="strict") as handle:
        status = handle.read(256 * 1024 + 1)
    if len(status) > 256 * 1024:
        raise OSError("Linux caller process metadata exceeds its accepted size")
    rows = [line.split()[1:] for line in status.splitlines() if line.startswith("NSpid:")]
    if (len(rows) != 1 or not rows[0] or
            any(not item.isascii() or not item.isdecimal() for item in rows[0]) or
            int(rows[0][-1]) != os.getpid()):
        raise OSError("Linux caller PID namespace identity is unavailable")
    return len(rows[0])


def _linux_procfs_pid(process_id: int) -> int:
    """Resolve a caller-relative PID without accepting a parent/sibling collision.

    An existing /proc/PID is insufficient when procfs belongs to an ancestor
    namespace. A pidfd binds the caller's PID to the kernel process; its fdinfo
    reports that process's PID in this procfs mount, including descendants.
    Never scan for a matching innermost NSpid: siblings can share that number.
    """
    depth = _linux_namespace_depth()
    if depth == 1:
        procfs_pid = process_id
    else:
        if not hasattr(os, "pidfd_open"):
            raise OSError("Linux PID namespace translation requires pidfd support")
        descriptor = os.pidfd_open(process_id, 0)
        try:
            with open("/proc/self/fdinfo/" + str(descriptor),
                      "r", encoding="utf-8", errors="strict") as handle:
                info = handle.read(64 * 1024 + 1)
            if len(info) > 64 * 1024:
                raise OSError("Linux pidfd metadata exceeds its accepted size")
            pids = [line.split()[1:] for line in info.splitlines() if line.startswith("Pid:")]
            nspids = [line.split()[1:] for line in info.splitlines() if line.startswith("NSpid:")]
            if pids == [["-1"]]:
                raise ProcessLookupError(process_id, "Linux process has exited")
            if (len(pids) != 1 or len(pids[0]) != 1 or len(nspids) != 1 or
                    len(nspids[0]) < depth or
                    any(not item.isascii() or not item.isdecimal()
                        for item in pids[0] + nspids[0]) or
                    int(pids[0][0]) <= 0 or nspids[0][0] != pids[0][0] or
                    int(nspids[0][depth - 1]) != process_id):
                raise OSError("Linux pidfd namespace identity is incomplete or inconsistent")
            procfs_pid = int(pids[0][0])
        finally:
            os.close(descriptor)
    if not os.path.isdir("/proc/" + str(procfs_pid)):
        raise ProcessLookupError(process_id, "Linux process identity is unavailable")
    return procfs_pid


def _live_group_members(pgid):
    """Linux-only observation, not ownership discovery or permission to signal.

    The caller pins its own unreaped session leader before any group signal.
    Zombies have stopped executing and do not count as a live client.
    """
    try:
        procfs_pgid = _linux_procfs_pid(pgid)
    except OSError:
        raise CaptureError("cleanup_incomplete") from None
    members = []
    with os.scandir('/proc') as entries:
        for entry in entries:
            if not entry.name.isdigit():
                continue
            try:
                with open(entry.path + '/stat', 'r') as stream:
                    fields = stream.read(8192).rsplit(') ', 1)[1].split()
                if int(fields[2]) == procfs_pgid and fields[0] not in {'Z', 'X'}:
                    members.append(int(entry.name))
            except (FileNotFoundError, ProcessLookupError):
                continue
            except PermissionError:
                # Unreadable proc entries prevent a complete drain assertion.
                raise CaptureError('cleanup_incomplete') from None
    return members


def _wait_stopped_group(pgid):
    if not sys.platform.startswith('linux'):
        return
    deadline = time.monotonic() + 3
    while _live_group_members(pgid):
        if time.monotonic() >= deadline:
            raise CaptureError('cleanup_incomplete')
        time.sleep(0.01)


def _wait_unreaped(proc, deadline):
    """Wait for a Linux owned leader without releasing the group-ID anchor."""
    while True:
        if time.monotonic() >= deadline:
            raise CaptureError('deadline_exceeded')
        result = os.waitid(os.P_PID, proc.pid, os.WEXITED | os.WNOHANG | os.WNOWAIT)
        if result is not None:
            return
        time.sleep(min(.01, max(0., deadline - time.monotonic())))


def _capture_stop(proc, *, owns_group=True):
    # A nested native client deliberately shares its supervisor's group. This
    # worker may kill that direct child, but must never signal its own group.
    # The outer supervisor remains alive to drain the whole group before return.
    if os.name == 'posix' and not owns_group:
        try:
            proc.terminate()
            proc.wait(timeout=CAPTURE_CLEANUP_GRACE)
        except subprocess.TimeoutExpired:
            proc.kill(); proc.wait(timeout=3)
        except ProcessLookupError:
            proc.wait(timeout=3)
        return
    if os.name == 'posix':
        try:
            os.killpg(proc.pid, signal.SIGTERM)
        except ProcessLookupError:
            proc.wait(timeout=3)
            return
        until = time.monotonic() + CAPTURE_CLEANUP_GRACE
        while time.monotonic() < until:
            try:
                os.killpg(proc.pid, 0)
            except ProcessLookupError:
                break
            time.sleep(min(0.025, max(0.0, until - time.monotonic())))
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        # Signal delivery is asynchronous. Wait for observed termination, not
        # merely leader exit, while its unreaped PID still anchors the group.
        try:
            _wait_stopped_group(proc.pid)
        finally:
            proc.wait(timeout=3)
    else:
        try:
            subprocess.run(['taskkill', '/PID', str(proc.pid), '/T', '/F'],
                           stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, timeout=3, check=False)
        finally:
            try:
                proc.wait(timeout=1)
            except subprocess.TimeoutExpired:
                proc.kill(); proc.wait(timeout=3)


def _capture_blocks(proc, deadline):
    if os.name == 'posix':
        import selectors
        os.set_blocking(proc.stdout.fileno(), False)
        with selectors.DefaultSelector() as ready:
            ready.register(proc.stdout, selectors.EVENT_READ)
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0 or not ready.select(remaining):
                    raise CaptureError('deadline_exceeded')
                try:
                    block = os.read(proc.stdout.fileno(), CAPTURE_BLOCK_BYTES)
                except BlockingIOError:
                    continue
                if not block:
                    return
                yield block
    else:
        import queue
        import threading
        blocks = queue.Queue(maxsize=2)
        stopped = threading.Event()
        def reader():
            try:
                while not stopped.is_set():
                    block = proc.stdout.read1(CAPTURE_BLOCK_BYTES)
                    while not stopped.is_set():
                        try:
                            blocks.put(block, timeout=0.05)
                            break
                        except queue.Full:
                            pass
                    if not block:
                        return
            except (OSError, ValueError):
                while not stopped.is_set():
                    try:
                        blocks.put(None, timeout=0.05)
                        break
                    except queue.Full:
                        pass
        worker = threading.Thread(target=reader, name='sentinel-native-output', daemon=True)
        worker.start()
        try:
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise CaptureError('deadline_exceeded')
                try:
                    block = blocks.get(timeout=remaining)
                except queue.Empty:
                    raise CaptureError('deadline_exceeded') from None
                if block is None:
                    raise CaptureError('pipe_read_failed')
                if not block:
                    return
                yield block
        finally:
            stopped.set()
            worker.join(timeout=0.2)


def capture_command(argv, seconds, *, limit, incoming=b'', env=None, merge_stderr=False,
                    deadline=None, join_supervisor_group=False, supervise_tree=False):
    """Return (exit code, complete bytes) or sanitized failure; no output file.

    `limit` is the maximum retained response size, not a post-exit read limit.
    At most one additional fixed-size pipe block is inspected to detect overflow.
    stderr is either included in that same quota or discarded to the null device.
    """
    if type(seconds) not in {int, float} or not math.isfinite(seconds) or seconds <= 0:
        raise CaptureError('invalid_deadline')
    if type(limit) is not int or not 0 <= limit <= 16 * 1024 * 1024:
        raise ValueError('Invalid native-client output quota')
    if not isinstance(incoming, bytes) or len(incoming) > MAX_CAPTURE_INPUT:
        raise ValueError('Native-client input exceeds its bound')
    if deadline is not None and (type(deadline) not in {int, float} or not math.isfinite(deadline)):
        raise CaptureError('invalid_deadline')
    deadline = min(time.monotonic() + seconds, deadline) if deadline is not None else time.monotonic() + seconds
    if join_supervisor_group and (os.name != 'posix' or os.getpgrp() != os.getpid() or os.getsid(0) != os.getpid()):
        raise ValueError('Only the dedicated native worker may join its owned supervisor group')
    data = bytearray()
    with tempfile.TemporaryFile() as source:
        source.write(incoming)
        source.seek(0)
        if time.monotonic() >= deadline:
            raise CaptureError('deadline_before_launch')
        proc = subprocess.Popen(argv, stdin=source, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT if merge_stderr else subprocess.DEVNULL,
                                env=env, start_new_session=os.name == 'posix' and not join_supervisor_group,
                                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0)
        blocks = _capture_blocks(proc, deadline)
        reaped = False
        try:
            for block in blocks:
                count = min(len(block), limit - len(data))
                data.extend(block[:count])
                if count < len(block):
                    raise CaptureError('output_limit_exceeded', len(data))
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise CaptureError('deadline_exceeded', len(data))
            if supervise_tree and sys.platform.startswith('linux'):
                _wait_unreaped(proc, deadline)
                if _live_group_members(proc.pid):
                    raise CaptureError('descendants_after_exit', len(data))
            proc.wait(timeout=max(.001, deadline - time.monotonic()))
            reaped = True
            if time.monotonic() >= deadline:
                raise CaptureError('deadline_exceeded', len(data))
            return proc.returncode, bytes(data)
        except BaseException as exc:
            if not reaped:
                try:
                    _capture_stop(proc, owns_group=not join_supervisor_group)
                except (OSError, subprocess.SubprocessError):
                    raise CaptureError('cleanup_incomplete', len(data)) from None
            if isinstance(exc, CaptureError):
                raise CaptureError(exc.reason, len(data)) from None
            if isinstance(exc, subprocess.TimeoutExpired):
                raise CaptureError('deadline_exceeded', len(data)) from None
            if isinstance(exc, OSError):
                raise CaptureError('pipe_read_failed', len(data)) from None
            raise
        finally:
            blocks.close()
            proc.stdout.close()
