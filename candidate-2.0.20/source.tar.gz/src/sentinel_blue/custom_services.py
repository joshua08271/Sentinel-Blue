"""Services outside the 39-service catalog, set up and repaired like any other.

A competition network runs whatever its designers chose, and a scored service
that is not a catalogued product still has to come back when it fails. An
operator names the systemd unit, the configuration files that belong to it and
the check that proves it works; Sentinel adopts the unit through the ordinary
reviewed setup path and gives it the same repair every catalogued service gets:
restore those files, put the unit back to enabled (including from a mask) and
restart it, validated by that check.

Two things are refused rather than trusted:

* **Host-identity files.** A custom service's files are restored by its repair,
  so they cannot include the files that decide who can log in — accounts,
  sudoers, SSH keys — or anything under /proc, /sys, /dev or /boot. Those stay
  monitored and alerted on; they are never a service's to overwrite.
* **Checks that are not local.** The guided setup is bound to this VM, so the
  check must target 127.0.0.1 or one of this VM's own addresses (for a service
  that listens only on its network address).
"""

from __future__ import annotations

import hashlib
import re
from pathlib import Path, PurePosixPath
from typing import Any
from urllib.parse import urlsplit

MAX_CUSTOM_SERVICES = 16
MAX_CUSTOM_FILES = 16
UNIT = re.compile(r"[A-Za-z0-9_][A-Za-z0-9_.@-]{0,118}\.service\Z")
IDENTITY_FILES = frozenset({"/etc/passwd", "/etc/shadow", "/etc/group", "/etc/gshadow", "/etc/sudoers",
                            "/etc/login.defs", "/etc/pam.conf"})
IDENTITY_PREFIXES = ("/etc/sudoers.d/", "/etc/pam.d/", "/etc/security/", "/root/")
SYSTEM_TREES = ("/proc/", "/sys/", "/dev/", "/boot/")
CHECK_KINDS = ("tcp", "http", "https", "dns")


LOOPBACK = "127.0.0.1"


def check_host(check: dict[str, Any]) -> str | None:
    target = check.get("target")
    if not isinstance(target, str):
        return None
    return urlsplit(target).hostname if check.get("kind") in {"http", "https"} else target


def _require_local(host: Any, local_addresses) -> None:
    if host == LOOPBACK or (isinstance(host, str) and host in set(local_addresses or ())):
        return
    raise ValueError("Local setup checks must target 127.0.0.1 or one of this VM's own addresses"
                     + (f" ({', '.join(sorted(local_addresses))})" if local_addresses else "") + ".")


def local_check(kind: str, target: str, port: Any = None, *, query: str = "", answers: str = "",
                expected_body: str = "", ca_file: str = "", local_addresses=()) -> dict[str, Any]:
    """One verification check against this VM, from the fields an operator types."""
    from .service_ports import port_text
    if kind not in CHECK_KINDS:
        raise ValueError("Choose a TCP, HTTP, HTTPS or DNS check.")
    target = (target or "").strip()
    check: dict[str, Any] = {"kind": kind, "target": target, "timeout": 5}
    host = urlsplit(target).hostname if kind in {"http", "https"} else target
    _require_local(host, local_addresses)
    if kind in {"tcp", "dns"}:
        check["port"] = port_text(port if isinstance(port, str) else str(port or ""))
    if kind == "dns":
        if not query.strip() or not answers.strip():
            raise ValueError("Enter the DNS query and expected answers.")
        check.update(query=query.strip(), expected_answers=[x.strip() for x in answers.split(",") if x.strip()])
    if kind in {"http", "https"}:
        if urlsplit(target).scheme != kind:
            raise ValueError("The URL must match the selected check type.")
        check["expected_status"] = [200]
        if expected_body:
            check["expected_body"] = expected_body
    if kind == "https":
        path = Path(ca_file)
        data = path.read_bytes()
        check.update(verify=True, ca_file=str(path.absolute()), ca_sha256=hashlib.sha256(data).hexdigest())
    return check


def check_port(check: dict[str, Any]) -> int:
    if check["kind"] in {"tcp", "dns"}:
        return int(check["port"])
    parsed = urlsplit(check["target"])
    return parsed.port or (443 if check["kind"] == "https" else 80)


def _file(value: Any) -> str:
    if not isinstance(value, str) or not value or len(value) > 1024 or "\x00" in value or "\n" in value:
        raise ValueError("Each configuration file must be one absolute path.")
    path = PurePosixPath(value)
    if not path.is_absolute() or ".." in path.parts or str(path) != value.rstrip("/") or "//" in value:
        raise ValueError(f"Use a canonical absolute path: {value}")
    if value in IDENTITY_FILES or value.startswith(IDENTITY_PREFIXES) or "/.ssh/" in value + "/":
        raise ValueError(f"{value} decides who can use this host; it is monitored, not restored by a service repair.")
    if value.startswith(SYSTEM_TREES):
        raise ValueError(f"{value} is kernel or boot state, not a service configuration file; it is monitored, not restored.")
    return value


def normalize_custom_service(spec: Any, *, catalog_units: set[str] | frozenset[str] = frozenset(),
                             local_addresses=()) -> dict[str, Any]:
    """Validate one operator-declared service. Type first, then meaning."""
    if not isinstance(spec, dict) or set(spec) - {"unit", "label", "files", "check"} or not {"unit", "check"} <= set(spec):
        raise ValueError("A custom service needs a unit name and a check, and may list its configuration files.")
    unit = spec["unit"]
    if not isinstance(unit, str) or not UNIT.fullmatch(unit):
        raise ValueError("Name the systemd unit exactly, ending in .service (for example scoreboard.service).")
    if unit in catalog_units:
        raise ValueError(f"{unit} is a catalogued service; choose it from the list instead.")
    label = spec.get("label") or unit.removesuffix(".service")
    if not isinstance(label, str) or not 0 < len(label) <= 64 or any(ord(c) < 32 for c in label):
        raise ValueError("The service label must be short plain text.")
    files = spec.get("files", [])
    if not isinstance(files, list) or len(files) > MAX_CUSTOM_FILES:
        raise ValueError(f"A custom service may declare at most {MAX_CUSTOM_FILES} configuration files.")
    files = [_file(item) for item in files]
    if len(set(files)) != len(files):
        raise ValueError("Each configuration file may be listed once.")
    check = spec["check"]
    if not isinstance(check, dict) or check.get("kind") not in CHECK_KINDS:
        raise ValueError("A custom service needs a TCP, HTTP, HTTPS or DNS check.")
    _require_local(check_host(check), local_addresses)
    check_port(check)
    return {"unit": unit, "label": label, "files": files, "check": dict(check)}


def normalize_custom_services(values: Any, *, catalog_units=frozenset(), local_addresses=()) -> list[dict[str, Any]]:
    if values is None:
        return []
    if not isinstance(values, list) or len(values) > MAX_CUSTOM_SERVICES:
        raise ValueError(f"At most {MAX_CUSTOM_SERVICES} custom services can be set up at once.")
    rows = [normalize_custom_service(value, catalog_units=catalog_units, local_addresses=local_addresses)
            for value in values]
    units = [row["unit"] for row in rows]
    if len(set(units)) != len(units):
        raise ValueError("Each custom unit may be added once.")
    owners: dict[str, str] = {}
    for row in rows:
        for path in row["files"]:
            if path in owners:
                raise ValueError(f"{path} is declared by both {owners[path]} and {row['unit']}; a file has one owner.")
            owners[path] = row["unit"]
    return rows


def custom_task(row: dict[str, Any], host: str) -> dict[str, Any]:
    """Adopt the existing unit through the ordinary reviewed setup path.

    No configuration is generated: the operator's own files are the approved
    state, and setup confirms the unit exists, is enabled and runs.
    """
    slug = re.sub(r"[^a-z0-9-]+", "-", row["unit"].removesuffix(".service").lower()).strip("-")[:48] or "service"
    return {"id": f"custom-{slug}", "host": host, "requires": [], "service_id": row["unit"],
            "recipe": "linux-service", "options": {"service": row["unit"], "enable": True, "unmask": True}}
