"""Exact-object withdrawal adapters. No VM snapshots, directory wipes, or globs."""
from __future__ import annotations
import base64
import copy
import os
from pathlib import Path
import re
import stat
import time

from .mutation_ledger import OwnershipConflict, LedgerError, digest


def semantic(value):
    if isinstance(value, dict):
        return {k: semantic(v) for k, v in value.items() if k != 'revision'}
    if isinstance(value, list):
        return [semantic(v) for v in value]
    return value


def canonical_file(value):
    value = str(value)
    if re.match(r'^[A-Za-z]:[\\/]', value):
        import ntpath
        return ntpath.normpath(value)
    return os.path.normpath(value)


def file_object_id(value):
    path = canonical_file(value)
    return 'file:' + (path.casefold() if re.match(r'^[A-Za-z]:', path) else path)


def object_target(*, files=(), services=(), tasks=(), persistence=()):
    target = {'files': sorted(set(canonical_file(x) for x in files)), 'services': sorted(set(services)),
              'tasks': list(tasks), 'persistence': list(persistence)}
    target['objects'] = ([file_object_id(x) for x in target['files']] +
                         ['service:' + x.casefold() for x in target['services']] +
                         ['task:' + digest(x) for x in target['tasks']] +
                         ['persistence:' + digest(x) for x in target['persistence']])
    return target


class NativeObjects:
    name = 'native-objects-v1'

    def __init__(self, ledger):
        self.ledger = ledger
        from .restoration import RestorePointStore
        state = ledger.directory / 'file-restore'
        if os.name == 'posix':
            # Everything under the ledger is copied into controller recovery
            # capsules, which refuse any directory others can read. This one was
            # created with the process umask (0755), so every controller backup
            # failed on any host where an agent had run. Create it private, and
            # repair the mode of one an earlier release left behind.
            if state.is_symlink():
                raise ValueError('Withdrawal file-restore state must not be a symbolic link')
            state.mkdir(mode=0o700, exist_ok=True)
            if state.stat().st_uid == os.geteuid() and state.stat().st_mode & 0o077:
                state.chmod(0o700)
        self.files = RestorePointStore(state)

    def file(self, filename):
        path = Path(filename)
        if not path.is_absolute():
            raise ValueError('Withdrawal requires an absolute object path')
        try:
            info = path.lstat()
        except FileNotFoundError:
            return None
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            raise OwnershipConflict('A file is no longer a unique regular file')
        revision = [info.st_dev, info.st_ino, info.st_ctime_ns, info.st_mtime_ns]
        data, metadata = self.files._read_target(path, maximum=32 * 1024 * 1024)
        check = path.lstat()
        if revision != [check.st_dev, check.st_ino, check.st_ctime_ns, check.st_mtime_ns]:
            raise OwnershipConflict('File changed during inventory')
        if os.name == 'nt':
            revision = {'stat': revision, 'native_metadata': metadata}
            metadata = self.files._metadata_snapshot(metadata)
        return {'bytes': base64.b64encode(data).decode('ascii'), 'metadata': metadata, 'revision': revision}

    def service(self, name):
        if not re.fullmatch(r'[A-Za-z0-9_.@-]{1,128}', name) or name.startswith('-'):
            raise ValueError('Invalid literal service identity')
        if os.name != 'nt':
            from .setup_linux_transaction import service_state, command
            state = service_state(name)
            # Configuration bytes are exact evidence, not just a hash. The unit
            # files themselves must also be declared to authorize editing them.
            state['configuration'] = command('systemctl', 'cat', '--', name, allowed=(0, 1)).stdout if state['exists'] else ''
            fields = command('systemctl', 'show', '--property=StateChangeTimestampMonotonic', '--', name, allowed=(0, 4)).stdout
            state['revision'] = fields.strip()
            return state
        from .security_native import powershell_json
        return powershell_json(r"""
$s=Get-Service -Name $p.name -ErrorAction SilentlyContinue
if(!$s){'null';exit}
if([string]$s.Status -notin @('Running','Stopped')){throw 'Service is transitioning'}
$c=Get-CimInstance Win32_Service | Where-Object {$_.Name -ceq $p.name}
if(@($c).Count -ne 1){throw 'Ambiguous service'}
$k=Get-ItemProperty -LiteralPath ('HKLM:\SYSTEM\CurrentControlSet\Services\'+$p.name)
[ordered]@{exists=$true;active=([string]$s.Status -eq 'Running');start=[int]$k.Start;
 delayedPresent=($null -ne $k.DelayedAutoStart);delayed=[int]$k.DelayedAutoStart;
 configuration=[ordered]@{path=[string]$c.PathName;account=[string]$c.StartName;type=[int]$c.ServiceType};
 revision=$null}|ConvertTo-Json -Depth 8 -Compress
""", {'name': name})

    def task(self, target):
        from .security_native import NativeSecurityBackend
        native = NativeSecurityBackend()
        if native.persistence_absent(dict(target, kind='scheduled-task')):
            return None
        return native.persistence_snapshot(dict(target, kind='scheduled-task'))

    def snapshot(self, target):
        from .security_native import NativeSecurityBackend
        native = NativeSecurityBackend()
        persistence = {}
        for item in target.get('persistence', []):
            try:
                persistence[digest(item)] = native.persistence_snapshot(item)
            except FileNotFoundError:
                persistence[digest(item)] = None
        return {'files': {x: self.file(x) for x in target.get('files', [])},
                'services': {x: self.service(x) for x in target.get('services', [])},
                'tasks': {digest(x): self.task(x) for x in target.get('tasks', [])},
                'persistence': persistence}

    def _file_restore(self, filename, before, expected):
        path = Path(filename)
        if self.file(filename) != expected:
            raise OwnershipConflict('File changed immediately before restoration')
        expected_metadata = None if expected is None else expected['revision'].get('native_metadata', expected['metadata']) if isinstance(expected['revision'], dict) else expected['metadata']
        expected_native = None if expected is None else (base64.b64decode(expected['bytes']), expected_metadata)
        if before is None:
            if expected is not None:
                self.files._unlink_target(path, expected_current=expected_native)
        else:
            self.files._atomic_write(path, base64.b64decode(before['bytes']), before['metadata']['mode'],
                                     before['metadata'], expected_current=expected_native)
        if semantic(self.file(filename)) != semantic(before):
            raise LedgerError('File restoration failed exact byte/security validation')

    def _service_restore(self, name, before, expected, *, reload_configuration=False):
        if before is not None and before.get('exists'):
            current = self.service(name)
            if current is None or current.get('configuration') != before.get('configuration'):
                raise OwnershipConflict('Service configuration changed during file restoration')
        if semantic(before) == semantic(expected) and not (reload_configuration and before and before.get('active')):
            return
        if os.name == 'nt':
            from .security_native import powershell_json
            if before is None:
                raise OwnershipConflict('Windows service deletion requires a recorded creation adapter')
            powershell_json(r"""
$k='HKLM:\SYSTEM\CurrentControlSet\Services\'+$p.name
Set-ItemProperty -LiteralPath $k -Name Start -Value $p.before.start
if($p.before.delayedPresent){Set-ItemProperty -LiteralPath $k -Name DelayedAutoStart -Value $p.before.delayed}
else{Remove-ItemProperty -LiteralPath $k -Name DelayedAutoStart -ErrorAction SilentlyContinue}
if($p.before.active){if($p.reload){Restart-Service -Name $p.name}else{Start-Service -Name $p.name}}else{Stop-Service -Name $p.name}
'true'
""", {'name': name, 'before': before, 'reload': reload_configuration})
            return
        from .setup_linux_transaction import command
        if not before['exists']:
            command('systemctl', 'daemon-reload')
            return
        mode = before['enabled']
        if mode not in {'enabled', 'disabled', 'enabled-runtime', 'masked', 'masked-runtime', 'static', 'indirect', 'alias', ''}:
            raise OwnershipConflict('Unsupported service startup restoration')
        expected_mode = expected.get('enabled')
        if expected_mode in {'masked', 'masked-runtime'} and expected_mode != mode:
            # Remove the recorded mask at its actual lifetime before restoring
            # the other lifetime; a runtime mask cannot override /etc's mask.
            command('systemctl', 'unmask', *(['--runtime'] if expected_mode == 'masked-runtime' else []), '--', name)
        elif mode not in {'masked', 'masked-runtime'}:
            command('systemctl', 'unmask', '--', name)
        if mode == 'enabled-runtime' and expected.get('enabled') != 'enabled-runtime':
            # Runtime enablement does not remove the persistent links created
            # by the recorded change. Undo those first, then restore the lifetime.
            # restore() has already verified the complete recorded object state.
            command('systemctl', 'disable', '--', name)
        if mode in {'enabled', 'enabled-runtime'}:
            command('systemctl', 'enable', *(['--runtime'] if mode == 'enabled-runtime' else []), '--', name)
        elif mode in {'disabled', 'masked', 'masked-runtime'}:
            command('systemctl', 'disable', '--', name)
        if before['active']:
            command('systemctl', 'restart' if reload_configuration else 'start', '--', name)
        else:
            command('systemctl', 'stop', '--', name)
        if mode in {'masked', 'masked-runtime'}:
            command('systemctl', 'mask', *(['--runtime'] if mode == 'masked-runtime' else []), '--', name)

    def quiesce(self, target, before, expected):
        if self.snapshot(target) != expected:
            raise OwnershipConflict('Sentinel startup registration changed after inventory')
        if target.get('services') and os.name != 'nt':
            from .setup_linux_transaction import command
            for name, old in before['services'].items():
                # Do not claim or stop a pre-existing teammate service by name.
                if old['exists']:
                    raise OwnershipConflict('Pre-existing service registration requires review before removal')
                if expected['services'][name]['exists']:
                    command('systemctl', 'disable', '--', name)
                    command('systemctl', 'stop', '--', name)
        for item in target.get('tasks', []):
            key = digest(item)
            if before['tasks'][key] is not None:
                raise OwnershipConflict('Pre-existing scheduled task requires review before removal')
            if expected['tasks'][key] is not None:
                from .security_native import powershell_json
                powershell_json(r"""
$xml=Export-ScheduledTask -TaskPath $p.target.task_path -TaskName $p.target.task_name
if([string]$xml -cne $p.expected.xml){throw 'Task changed before stopping'}
Disable-ScheduledTask -TaskPath $p.target.task_path -TaskName $p.target.task_name | Out-Null
Stop-ScheduledTask -TaskPath $p.target.task_path -TaskName $p.target.task_name
'true'
""", {'target': item, 'expected': expected['tasks'][key]})
        return self.snapshot(target)

    def restore(self, target, before, expected):
        if self.snapshot(target) != expected:
            raise OwnershipConflict('Object changed after Sentinel; human review required')
        # All objects and all rollback blobs are checked before the first change.
        from .security_native import NativeSecurityBackend
        native = NativeSecurityBackend()
        for item in target.get('tasks', []):
            key = digest(item)
            old, new = before['tasks'][key], expected['tasks'][key]
            if old == new:
                continue
            descriptor = dict(item, kind='scheduled-task')
            if new is not None:
                native.persistence_remove(descriptor, new)
            if old is not None:
                native.persistence_restore(descriptor, old)
        if os.name != 'nt':
            from .setup_linux_transaction import command
            for name, state in expected['services'].items():
                old = before['services'][name]
                if state['exists'] and not old['exists']:
                    command('systemctl', 'stop', '--', name)
                    command('systemctl', 'disable', '--', name)
        for filename, state in before['files'].items():
            if semantic(state) != semantic(expected['files'][filename]):
                self._file_restore(filename, state, expected['files'][filename])
        if target.get('services') and os.name != 'nt':
            from .setup_linux_transaction import command
            command('systemctl', 'daemon-reload')
        for name, state in before['services'].items():
            self._service_restore(name, state, expected['services'][name], reload_configuration=any(semantic(value) != semantic(expected['files'][path]) for path, value in before['files'].items()))
        for item in target.get('persistence', []):
            key = digest(item)
            old, new = before['persistence'][key], expected['persistence'][key]
            if old == new:
                continue
            if new is not None:
                native.persistence_remove(item, new)
            if old is not None:
                native.persistence_restore(item, old)
        result = self.snapshot(target)
        if semantic(result) != semantic(before):
            raise LedgerError('Native restoration did not reach the exact recorded pre-state')
        return result


class OwnedProcess:
    name = 'sentinel-process-v1'

    def snapshot(self, target):
        from .process_identity import inspect_process_identity, ProcessIdentityMismatch
        identity = target['identity']
        try:
            current = inspect_process_identity(identity['process_id'], boot_id=identity['boot_id'])
        except (FileNotFoundError, ProcessLookupError):
            return None
        except OSError as exc:
            if os.name == 'nt' and (getattr(exc, 'winerror', None) or exc.errno) in {87, 1168}:
                return None
            raise
        if current != identity:
            return None  # The original process exited; never signal a reused PID.
        return {'identity': current}

    def restore(self, target, before, expected):
        if before is not None:
            raise OwnershipConflict('Only Sentinel-created processes can be removed')
        current = self.snapshot(target)
        if current is None:
            return None
        if current != expected:
            raise OwnershipConflict('Process identity changed')
        if target['identity']['process_id'] == os.getpid():
            raise OwnershipConflict('The withdrawal helper cannot terminate itself')
        from .process_identity import signal_verified_process
        signal_verified_process(target['identity']['process_id'], target['identity'], 'terminate')
        deadline = time.monotonic() + 15
        while time.monotonic() < deadline:
            try:
                if self.snapshot(target) is None:
                    return None
            except ProcessLookupError:
                return None
            if os.name != 'nt':
                from .process_identity import _linux_proc_path
                try:
                    path = _linux_proc_path(target['identity']['process_id']) / 'stat'
                    if path.read_text().rsplit(')', 1)[1].strip().startswith('Z '):
                        return None
                except (FileNotFoundError, ProcessLookupError):
                    return None
            time.sleep(0.1)
        raise LedgerError('Sentinel process did not stop; evidence and files retained')


def adapter_for(name, ledger):
    if name == 'linux-containment-v1':
        return LinuxContainment()
    if name == NativeObjects.name:
        return NativeObjects(ledger)
    if name == OwnedProcess.name:
        return OwnedProcess()
    if name == 'linux-account-v1':
        from .withdrawal_accounts import LinuxAccount
        return LinuxAccount(ledger)
    if name == 'router-v1':
        from .withdrawal_router import RouterAdapter
        return RouterAdapter(ledger)
    if name == 'setup-linux-v1':
        from .withdrawal_setup import LinuxSetupAdapter
        return LinuxSetupAdapter(ledger)
    if name == 'setup-windows-v1':
        from .withdrawal_setup import WindowsSetupAdapter
        return WindowsSetupAdapter(ledger)
    raise OwnershipConflict('No exact native inverse is registered for this action')


class LinuxContainment:
    name = 'linux-containment-v1'

    def snapshot(self, target):
        from .process_identity import inspect_process_identity, _linux_proc_path
        identity = target['identity']
        try:
            actual = inspect_process_identity(identity['process_id'], boot_id=identity['boot_id'])
            if actual != identity:
                return None
            raw = (_linux_proc_path(identity['process_id']) / 'stat').read_text()
        except (FileNotFoundError, ProcessLookupError):
            return None
        state = raw.rsplit(')', 1)[1].split()[0]
        if state == 't':
            raise OwnershipConflict('A debugger owns the stopped process; human review required')
        if state in {'Z', 'X'}:
            return None
        return {'identity': actual, 'stopped': state == 'T'}

    def matches_pre(self, before, after):
        return after is None or after == before

    def restore(self, target, before, expected):
        current = self.snapshot(target)
        if current is None:
            return None
        if current != expected or before is None:
            raise OwnershipConflict('Process containment ownership changed')
        if current['stopped'] != before['stopped']:
            from .process_identity import signal_verified_process
            from .mutation_tracking import suppressed
            with suppressed():
                signal_verified_process(target['identity']['process_id'], target['identity'], 'suspend' if before['stopped'] else 'resume')
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline:
            observed = self.snapshot(target)
            if self.matches_pre(before, observed):
                return observed
            time.sleep(0.02)
        raise LedgerError('Process containment inverse did not verify')
