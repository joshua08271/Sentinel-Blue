"""Reviewed desktop jobs survive closing the window and never occupy a terminal."""

from __future__ import annotations

import os
import subprocess
import sys
import time
import zipfile
from pathlib import Path

from .credential_vault import private_directory
from .event_profile import load_event_profile
from .launcher import load_inventory
from .job_control import JobControl, SetupPaused
from .setup import compile_plan, plan_digest, SetupRunner
from .state import read_private_json, write_private_json


def runtime_command():
    from .runtime_environment import python_command
    runtime = Path(sys.argv[0]).absolute()
    if runtime.is_file() and zipfile.is_zipfile(runtime):
        return [*python_command(), str(runtime)]
    return [*python_command(), '-m', 'sentinel_blue']


def detach(arguments, *, stdin=subprocess.DEVNULL):
    return subprocess.Popen(runtime_command() + arguments, stdin=stdin,
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, close_fds=True,
        start_new_session=os.name != 'nt',
        creationflags=(subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP) if os.name == 'nt' else 0)


def prepare(inventory_path, profile_path, runtime, kind, range_deployment):
    inventory_path = Path(inventory_path).absolute()
    profile_path = Path(profile_path or inventory_path).absolute()
    inventory = load_inventory(inventory_path)
    profile = load_event_profile(profile_path)
    if kind == 'opening':
        from .opening import compile_opening
        for host in inventory['hosts']:
            host['event_profile'] = str(profile_path)
        plan = compile_opening(inventory, profile, inventory_path.parent, Path(runtime).absolute(),
                               range_deployment=range_deployment)
    elif kind == 'setup':
        profile.require_runtime_ready(range_deployment=range_deployment)
        profile.verify_release_file(runtime)
        if not profile.allows('initial_provisioning'):
            raise ValueError('event profile must explicitly permit initial_provisioning')
        plan = compile_plan(inventory, profile, inventory_path.parent)
    else:
        raise ValueError('Choose setup or opening')
    return plan, profile


def start_controller(arguments):
    from .__main__ import parser
    if not isinstance(arguments, list) or not all(isinstance(x, str) and '\x00' not in x for x in arguments):
        raise ValueError('Controller configuration requires a literal argument array')
    if any(x.split('=')[0] in {'--token', '--operator-token', '--supervisor-child'} for x in arguments):
        raise ValueError('Use private token files for a background controller')
    try:
        args = parser().parse_args(['controller', *arguments])
    except SystemExit:
        raise ValueError('Controller arguments are incomplete or invalid') from None
    profile = load_event_profile(args.event_profile)
    profile.require_runtime_ready(range_deployment=args.range_deployment)
    profile.verify_release_file(sys.argv[0])
    from .config_validation import validate_bound_transport
    validate_bound_transport(profile, role='controller', ca_file=args.tls_ca_file,
                             tls_cert=args.tls_cert, tls_key=args.tls_key, syslog_bind=args.syslog_bind)
    from .control_plane import validate_startup
    validate_startup(profile, 'controller', args)
    command = ['controller', *arguments]
    if '--supervise' not in arguments:
        command.append('--supervise')
    return detach(command)


def launch_job(job, directory, vault_passphrase=None):
    directory = Path(directory).absolute()
    control = JobControl(directory.parent)
    control.initialize()
    job = dict(job)
    job.setdefault('control_epoch', control.admit())
    control.permit(job['control_epoch']).checkpoint()
    guard = private_directory(directory)
    try:
        path = directory / 'job.json'
        if path.exists():
            raise ValueError('Choose a new job directory; previous runs are never replayed automatically')
        write_private_json(path, job)
        process = detach(['desktop-worker', '--job', str(path)],
                         stdin=subprocess.PIPE if vault_passphrase is not None else subprocess.DEVNULL)
        if vault_passphrase is not None:
            import json
            try:
                process.stdin.write((json.dumps({'vault_passphrase': vault_passphrase}) + '\n').encode())
                process.stdin.close()
            except (BrokenPipeError, OSError):
                raise RuntimeError('The background job did not accept its vault unlock input') from None
        return process, path
    finally:
        if guard is not None:
            guard.close()


def run(args):
    try:
        return _run(args)
    finally:
        _discard_redo_connection(args)


def _discard_redo_connection(args):
    """2.0.9: a finished redo worker leaves no copy of the operator connection.

    Only the job's own ``redo-control.json`` beside ``job.json`` is removed.
    Jobs are never replayed, so the file has no later use.
    """
    try:
        path = Path(args.job).absolute()
        job = read_private_json(path, 65536)
        reference = job.get('redo_guard_file') if isinstance(job, dict) else None
        if isinstance(reference, str) and Path(reference).parent == path.parent:
            (path.parent / 'redo-control.json').unlink(missing_ok=True)
    except (OSError, ValueError, TypeError):
        pass


def _run(args):
    path = Path(args.job).absolute()
    job = read_private_json(path, 65536)
    report_path = path.parent / 'result.json'
    started = time.time()
    try:
        permit = JobControl(path.parent.parent).permit(job.get('control_epoch'))
        permit.checkpoint()
        secret = None
        if job.get('security_vault_dir'):
            from .json_codec import strict_json_loads
            incoming = sys.stdin.buffer.readline(32769)
            secret = strict_json_loads(incoming, max_bytes=32768).get('vault_passphrase')
            if not isinstance(secret, str) or not 16 <= len(secret) <= 4096:
                raise ValueError('The security stage requires an unlocked vault')
        plan, profile = prepare(job['inventory'], job.get('event_profile'), job['runtime'],
                                job['kind'], job.get('range_deployment', False))
        if plan_digest(plan) != job['approved_digest']:
            raise ValueError('Configuration changed after review; no setup changes started')
        checkpoint = permit.checkpoint
        if job.get('redo') is True:
            from .redo_governance import WorkerGuard
            live_guard = WorkerGuard(job, profile, plan)
            def checkpoint():
                permit.checkpoint()
                live_guard.checkpoint()
        # The active runtime must be exactly the reviewed release as well.
        profile.verify_release_file(sys.argv[0])
        if job['kind'] == 'opening':
            from .opening import OpeningRunner
            if plan.get('security') is not None:
                if secret is None or not job.get('security_vault_dir'):
                    raise ValueError('The security stage requires an unlocked vault')
                from .credential_vault import CredentialVault
                from .security_transport import SecurityTransport
                from .security_workflow import SecurityCoordinator
                from .setup_transport import SetupTransport
                vault_path = Path(job['security_vault_dir']).absolute()
                with CredentialVault(vault_path, secret, create=not (vault_path/'vault.json').exists()) as vault:
                    secret = None
                    transport = SetupTransport()
                    security_transport = SecurityTransport(profile, range_deployment=job.get('range_deployment', False))
                    security_transport.credential_observer = transport.set_management_password
                    security = SecurityCoordinator(plan['security'], profile, vault, security_transport,
                                                   checkpoint=permit.checkpoint)
                    report = OpeningRunner(plan, profile, Path(job['runtime']), transport=transport, security=security,
                                           checkpoint=permit.checkpoint).execute(
                        path.parent/'state', job['approved_digest'], started_at=started)
            else:
                report = OpeningRunner(plan, profile, Path(job['runtime']), checkpoint=permit.checkpoint).execute(path.parent / 'state',
                    job['approved_digest'], started_at=started)
        else:
            report = SetupRunner(plan, profile, checkpoint=checkpoint).execute(
                path.parent / 'state', job['approved_digest'], started_at=started,
                only_services=job.get('only_services'), redo=job.get('redo') is True)
        try:
            permit.checkpoint()
        except SetupPaused as exc:
            report = dict(report, status='paused', pause_reason=str(exc), automatic_resume=False)
        write_private_json(report_path, report)
        from .recording import emit
        emit('setup_worker_result', report)
        return 0 if report['status'] in {'passed', 'ready'} else 2
    except Exception as exc:
        from .recording import emit
        emit('setup_worker_failed', {'error_type': type(exc).__name__, 'elapsed_seconds': time.time() - started})
        write_private_json(report_path, {'status': 'paused' if isinstance(exc, SetupPaused) else 'failed', 'error_type': type(exc).__name__,
            'reason': str(exc)[:500], 'elapsed_seconds': time.time() - started})
        return 2
