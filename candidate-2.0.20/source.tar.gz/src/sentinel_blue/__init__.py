"""Sentinel Blue defensive competition tooling."""

__version__ = "2.0.20"
