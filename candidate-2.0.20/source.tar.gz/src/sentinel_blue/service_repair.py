"""Evidence-based service diagnosis and declarative, bounded repair contracts.

Diagnosis never treats probe error text as commands or trusts the first scan as
a repair source. Mutations require an approved baseline and explicit per-service
authority; the executor independently verifies the native state and saved bytes.
"""

from __future__ import annotations

import hashlib
import ipaddress
from pathlib import PurePosixPath, PureWindowsPath
from typing import Any
from urllib.parse import urlparse

from .json_codec import canonical_json_bytes
from .policy import SHA256
from .probe_evidence import matching_probe_health, probe_name

MAX_REPAIR_FILES = 16
MAX_REPAIR_VALIDATION_SECONDS = 120

# The native service manager already records why a unit stopped. systemd's
# `Result=` verdict, exit status, sub-state and restart counter are collected in
# every observation but were previously discarded, so a scored service that
# systemd is refusing to start looked exactly like one that had simply been
# stopped (issue #13). Each verdict becomes a named finding with its evidence.
NATIVE_FAULT_CODES = {
    "start-limit-hit": "service_start_refused_by_limit",
    "oom-kill": "service_killed_for_memory",
    "resources": "host_resources_exhausted",
    "exit-code": "service_exited_with_error",
    "signal": "service_killed_by_signal",
    "core-dump": "service_killed_by_signal",
    "timeout": "service_start_timed_out",
    "watchdog": "service_watchdog_timeout",
    "protocol": "service_startup_protocol_violation",
}

# Sub-states systemd reports while it is cycling a unit it cannot keep running.
RESTART_LOOP_SUBSTATES = frozenset({"auto-restart", "auto-restart-queued"})
NATIVE_RESTART_LOOP_DELTA = 3

# Restarting is the right response to a program that crashed once. It is
# provably the wrong response to these: systemd refuses a unit past its start
# limit, a host out of memory or resources repeats the kill, a unit already
# cycling is being restarted by systemd itself, and a bind fails while another
# process owns the port. Recovery holds and names the cause instead of spending
# its attempt budget on a restart that cannot succeed.
RESTART_FUTILE_CODES = {
    "service_start_refused_by_limit":
        "the service manager is refusing to start this unit until its failure state is cleared",
    "service_killed_for_memory":
        "the service was killed for host memory; a restart repeats the condition",
    "host_resources_exhausted":
        "the host could not supply the resources this service needs to start",
    "service_restart_looping":
        "the service manager is already restarting this unit in a loop",
    "listening_port_occupied":
        "another process holds the listening port on an overlapping local endpoint; bind ownership needs review before restarting",
    "service_filesystem_full":
        "the filesystem holding this service's files has no room, so it cannot write or start",
    "service_filesystem_inodes_exhausted":
        "the filesystem holding this service's files has no free inodes, so it cannot create files",
    "service_filesystem_read_only":
        "the filesystem holding this service's files is mounted read-only",
    # A unit still stopping keeps its own listener and blocks any start queued
    # behind the stop (units with TimeoutStopSec=0, such as redis-server, can
    # stay here indefinitely when they cannot save on shutdown).
    "service_stop_stuck":
        "the service manager is still stopping this unit, so a restart would wait behind the stop",
}

# A restart loop, and the start limit that ends one, are what a service with
# Restart=always or on-failure does when the configuration it reads is broken.
# Found live on 2.0.5: a corrupted redis.conf put redis-server into exactly this
# and repair was "held for review" indefinitely, although restoring that file is
# the fix. When the repair restores a changed file, these no longer hold it; a
# plain restart still is held, since it cannot change the outcome.
CONFIGURATION_EXPLAINED_CODES = frozenset({"service_restart_looping", "service_start_refused_by_limit"})

# A filesystem this close to full stops a service from writing. These are the
# thresholds at which a restart is refused, not the ones at which an operator is
# warned; detection.py warns earlier and more gently.
SERVICE_FILESYSTEM_EXHAUSTED_FRACTION = 0.01
SERVICE_FILESYSTEM_EXHAUSTED_BYTES = 16 * 1024 * 1024

# Short operator-facing phrases for the same causes, for a table cell rather
# than a report. They complete the sentence "the service is down because ...".
FAULT_SUMMARIES = {
    "service_start_refused_by_limit": "the service manager is refusing to start it past its restart limit",
    "service_restart_looping": "the service manager is restarting it in a loop",
    "service_killed_for_memory": "it was killed for host memory",
    "host_resources_exhausted": "the host could not supply the resources it needs",
    "service_exited_with_error": "it exited with an error status",
    "service_killed_by_signal": "it was killed by a signal",
    "service_start_timed_out": "it timed out while starting",
    "service_watchdog_timeout": "its watchdog expired",
    "service_startup_protocol_violation": "it did not meet its startup contract",
    "native_failure_reason_unrecognized": "the service manager reported a failure this release does not recognize",
    "listening_port_occupied": "another process holds its declared port",
    "socket_activation_holds_port": "a socket unit is holding its declared port",
    "service_filesystem_full": "the filesystem holding its files is full",
    "service_filesystem_inodes_exhausted": "the filesystem holding its files is out of inodes",
    "service_filesystem_read_only": "the filesystem holding its files is read-only",
    "service_stop_stuck": "it is stuck stopping; its own process still holds the port",
}


def fault_summary(findings: list[dict[str, Any]]) -> str:
    """One short phrase naming the most specific observed cause, or ''.

    A cause that blocks a restart outranks one that does not: an operator with
    one line of text needs the reason the service will stay down.
    """
    blocking = [item for item in findings if item.get("code") in RESTART_FUTILE_CODES]
    for finding in [*blocking, *findings]:
        phrase = FAULT_SUMMARIES.get(finding.get("code", ""))
        if phrase:
            evidence = finding.get("evidence") or {}
            port, status = evidence.get("port"), evidence.get("exit_code")
            if port is not None:
                return f"{phrase} ({port})"
            if status is not None:
                return f"{phrase} ({status})"
            return phrase
    return ""


def path_key(value: str) -> str:
    if not isinstance(value, str) or not value or len(value) > 1024 or "\x00" in value:
        raise ValueError("repair requires bounded absolute paths")
    windows = PureWindowsPath(value)
    path = windows if windows.is_absolute() else PurePosixPath(value)
    if not path.is_absolute() or ".." in path.parts:
        raise ValueError("repair requires absolute paths without parent traversal")
    return path.as_posix().casefold() if windows.is_absolute() else path.as_posix()


def normalize_repair_policy(value: Any, manifest: dict[str, Any]) -> dict[str, Any]:
    fields = {"restore_files", "restart_unhealthy", "validation_timeout_seconds"}
    optional = {"allow_unrelated_payload_errors", "attempt_limits", "restore_start_mode", "unmask", "host_files"}
    if not isinstance(value, dict) or not fields <= set(value) or set(value) - fields - optional:
        raise ValueError("repair_policy requires restore_files, restart_unhealthy and validation_timeout_seconds")
    files = value["restore_files"]
    if not isinstance(files, list) or len(files) > MAX_REPAIR_FILES:
        raise ValueError("repair_policy permits at most 16 configuration files")
    keys = [path_key(path) for path in files]
    required = {path_key(path) for path in manifest.get("required_files", [])}
    if len(set(keys)) != len(keys) or not set(keys) <= required:
        raise ValueError("repair files must be unique declared required_files")
    if type(value["restart_unhealthy"]) is not bool:
        raise ValueError("restart_unhealthy must be an explicit boolean")
    timeout = value["validation_timeout_seconds"]
    if type(timeout) is not int or not 5 <= timeout <= MAX_REPAIR_VALIDATION_SECONDS:
        raise ValueError("repair validation timeout must be an integer from 5 to 120 seconds")
    result = {"restore_files": list(files), "restart_unhealthy": value["restart_unhealthy"],
              "validation_timeout_seconds": timeout}
    if "allow_unrelated_payload_errors" in value:
        if type(value["allow_unrelated_payload_errors"]) is not bool:
            raise ValueError("allow_unrelated_payload_errors requires an explicit boolean")
        result["allow_unrelated_payload_errors"] = value["allow_unrelated_payload_errors"]
    if "attempt_limits" in value:
        from .recovery_limits import normalize_attempt_limits
        result["attempt_limits"] = normalize_attempt_limits(value["attempt_limits"])
    if "restore_start_mode" in value:
        if value["restore_start_mode"] not in ("enabled", "auto", "manual"):
            raise ValueError("restore_start_mode must be enabled, auto or manual")
        result["restore_start_mode"] = value["restore_start_mode"]
    if "unmask" in value:
        # Unmasking is its own grant. A mask is the strongest "never start this"
        # a Linux host can express, so a profile that restores startup modes
        # does not also undo masks unless it says so.
        if type(value["unmask"]) is not bool:
            raise ValueError("unmask requires an explicit boolean")
        if value["unmask"] and result.get("restore_start_mode") != "enabled":
            raise ValueError("unmask requires restore_start_mode enabled")
        result["unmask"] = value["unmask"]
    if "host_files" in value:
        # Host-wide files a manifest carries only so the baseline covers them
        # and an operator can restore them from an alert: accounts, sudoers,
        # hosts, SSH keys. This service's restart and repair neither require
        # them to match nor restore them. Found live on 2.0.5: local setup puts
        # them on the first service, so one `useradd` by the red team changed
        # /etc/passwd and held that service's repair for good.
        host = value["host_files"]
        if not isinstance(host, list) or len(host) > 256 or any(not isinstance(path, str) for path in host):
            raise ValueError("repair_policy host_files must be a list of at most 256 paths")
        host_keys = [path_key(path) for path in host]
        if len(set(host_keys)) != len(host_keys) or not set(host_keys) <= required or set(host_keys) & set(keys):
            raise ValueError("host_files must be unique declared required_files outside restore_files")
        result["host_files"] = list(host)
    return result


def recovery_files(manifest: dict[str, Any]) -> list[str]:
    """The required files a service's own restart and repair depend on."""
    host = {path_key(path) for path in (manifest.get("repair_policy") or {}).get("host_files", [])}
    return [path for path in manifest["required_files"] if path_key(path) not in host]


def _one(rows: list[dict[str, Any]], field: str, value: str) -> dict[str, Any]:
    matches = [row for row in rows if row.get(field) == value]
    if len(matches) != 1:
        raise ValueError(f"missing or ambiguous {field}: {value}")
    return matches[0]


def _manifest(profile: Any, host: str, service: str) -> dict[str, Any]:
    return _one([row for row in profile.services if row["host"] == host], "service_id", service)


def local_probe(probe: dict[str, Any], host_addresses: frozenset[str] | set[str] = frozenset()) -> bool:
    """A numeric loopback target, or one of this host's own addresses, checks this host.

    A connection from a host to its own address never leaves it, so a failure
    there is the application's, not the network's. `host_addresses` comes from
    the same host's interface inventory; without it only loopback counts.
    """
    target = str(probe.get("target", ""))
    try:
        host = urlparse(target).hostname if "://" in target else target
        address = ipaddress.ip_address(host or "")
    except ValueError:
        return False
    return address.is_loopback or str(address) in host_addresses


def host_addresses(telemetry: dict[str, Any]) -> frozenset[str]:
    """This host's own unicast addresses, from its interface inventory."""
    found = set()
    for row in telemetry.get("interfaces", []) if isinstance(telemetry, dict) else []:
        for value in (row.get("addresses", []) if isinstance(row, dict) else [])[:64]:
            try:
                address = ipaddress.ip_interface(str(value)).ip
            except ValueError:
                continue
            if not (address.is_loopback or address.is_multicast or address.is_unspecified or address.is_link_local):
                found.add(str(address))
    return frozenset(found)


def probe_health(specs: list[dict[str, Any]], telemetry: dict[str, Any]) -> list[bool | None]:
    """True, False, or None where the transaction produced no evidence.

    A check that could not be attempted — a scoring client that is not installed
    on this host, say — reports None. It never contacted the service, so calling
    it False would show a healthy service as down and let recovery restart it.
    """
    return matching_probe_health(specs, telemetry.get("probes", []))


def unavailable_transactions(specs: list[dict[str, Any]],
                             telemetry: dict[str, Any]) -> list[dict[str, Any]]:
    """Declared transactions this host reported it could not attempt."""
    result = []
    for spec in specs[:32]:
        for row in telemetry.get("probes", [])[:1024]:
            if (isinstance(row, dict) and row.get("executed") is False
                    and row.get("name") == probe_name(spec)
                    and row.get("target") == spec.get("target")):
                result.append({"name": str(row.get("name", ""))[:256],
                               "detail": str(row.get("detail", ""))[:300]})
                break
    return result


def local_probe_port(spec: dict[str, Any]) -> int | None:
    """The exact TCP port a loopback transaction checks, or None when unstated.

    Only an explicit port or an http(s) URL is used. A guessed port would turn
    an unrelated listener into a false accusation, so anything else is unknown.
    """
    if not isinstance(spec, dict) or not local_probe(spec):
        return None
    port = spec.get("port")
    if type(port) is int and 1 <= port <= 65535:
        return port
    target = str(spec.get("target", ""))
    if "://" not in target:
        return None
    try:
        parsed = urlparse(target)
    except ValueError:
        return None
    if parsed.scheme not in {"http", "https"}:
        return None
    try:
        explicit = parsed.port
    except ValueError:
        return None
    return explicit or (443 if parsed.scheme == "https" else 80)


def declared_local_ports(manifest: dict[str, Any]) -> list[int]:
    if not isinstance(manifest, dict):
        raise ValueError("service manifest must be an object")
    specs = manifest.get("expected_transactions", [])
    if not isinstance(specs, list) or len(specs) > 32 or any(not isinstance(spec, dict) for spec in specs):
        raise ValueError("expected_transactions must be a bounded list of probe objects")
    ports = [local_probe_port(spec) for spec in specs]
    return sorted({port for port in ports if port is not None})


def local_probe_endpoint(spec: dict[str, Any]) -> tuple[str, str, int] | None:
    """Known transport and numeric local destination, NOT the daemon bind policy."""
    port = local_probe_port(spec)
    if port is None:
        return None
    kind = str(spec.get('kind', '')).casefold()
    if kind == 'dns':
        protocol = spec.get('transport', 'udp')
        if protocol not in {'tcp', 'udp'}:
            return None
    elif kind in {'tcp', 'http', 'https', 'ftp', 'banner', 'smtp', 'tls', 'transaction',
                  'ssh-login', 'smb', 'mysql', 'postgres'}:
        protocol = 'tcp'
    else:
        return None  # ICMP and unspecified/multi-transport checks imply no TCP bind.
    target = spec['target']
    try:
        host = urlparse(target).hostname if '://' in target else target
        address = ipaddress.ip_address(host)
    except (ValueError, TypeError):
        return None
    if isinstance(address, ipaddress.IPv6Address) and address.ipv4_mapped is not None:
        address = address.ipv4_mapped
    return protocol, str(address), port


def _endpoint_overlap(endpoint: str, listener: str) -> str:
    """Return overlapping, disjoint, or unknown; never guess IPv6 dual-stack mode."""
    if not isinstance(listener, str):
        return 'invalid'
    text = listener.strip().strip('[]')
    if text in {'', '*'}:
        return 'unknown'
    try:
        target = ipaddress.ip_address(endpoint)
        held = ipaddress.ip_address(text)
    except ValueError:
        return 'invalid'
    if isinstance(held, ipaddress.IPv6Address) and held.ipv4_mapped is not None:
        held = held.ipv4_mapped
    if target.version != held.version:
        return 'unknown' if held.version == 6 and held.is_unspecified else 'disjoint'
    if held.is_unspecified or held == target:
        return 'overlapping'
    # A distinct loopback can coexist with a specific bind to the probe address.
    # It could still affect a wildcard daemon: retain advisory uncertainty only.
    return 'unknown' if held.is_loopback else 'disjoint'


def port_conflict_findings(service: str, manifest: dict[str, Any],
                           telemetry: dict[str, Any]) -> list[dict[str, Any]]:
    """Report observed endpoint overlap separately from unknown daemon bind policy.

    This does not prove the daemon's configured bind address, SO_REUSEPORT policy,
    socket-activation contract or IPv6-only option. Definitive endpoint overlap
    still holds automatic repair for owner/bind review; disjoint/unknown address
    evidence alone does not invent a restart-futility reason.
    """
    findings: list[dict[str, Any]] = []
    listeners = telemetry.get('listeners', [])
    if not isinstance(listeners, list):
        return findings
    declared_local_ports(manifest)  # Retain the bounded manifest validation.
    endpoints = {value for spec in manifest.get('expected_transactions', [])
                 if (value := local_probe_endpoint(spec)) is not None}
    for protocol, address, port in sorted(endpoints):
        selected = None
        rank = -1
        for row in listeners[:4096]:
            if not isinstance(row, dict) or type(row.get('port')) is not int or row['port'] != port:
                continue
            if str(row.get('protocol', '')).casefold().removesuffix('6') != protocol:
                continue
            overlap = _endpoint_overlap(address, row.get('address'))
            if overlap in {'disjoint', 'invalid'}:
                continue
            holder = str(row.get('process', ''))[:200]
            socket_activated = 'pid=1,' in holder or 'pid=1)' in holder
            code = ('listener_bind_overlap_unverified' if overlap == 'unknown' else
                    'socket_activation_holds_port' if socket_activated else 'listening_port_occupied')
            candidate_rank = 0 if overlap == 'unknown' else 1 if socket_activated else 2
            if candidate_rank <= rank:
                continue
            rank = candidate_rank
            selected = {'code': code, 'subject': service,
                'evidence': {'port': port, 'protocol': protocol, 'address': str(row.get('address', ''))[:64],
                    'expected_address': address, 'holder': holder or 'unattributed',
                    'endpoint_overlap': overlap, 'daemon_bind_policy': 'unverified'}}
        if selected is not None:
            findings.append(selected)
    return findings


def _covering_mount(path: str, mounts: list[str]) -> str | None:
    """The longest declared mount point that contains this path."""
    try:
        target = PurePosixPath(path)
    except (TypeError, ValueError):
        return None
    if not target.is_absolute():
        return None
    best = None
    for mount in mounts:
        try:
            candidate = PurePosixPath(mount)
        except (TypeError, ValueError):
            continue
        if not candidate.is_absolute():
            continue
        if target == candidate or candidate in target.parents:
            if best is None or len(candidate.parts) > len(PurePosixPath(best).parts):
                best = mount
    return best


def host_capacity_findings(service: str, manifest: dict[str, Any],
                           telemetry: dict[str, Any]) -> list[dict[str, Any]]:
    """Name a filesystem fault under this service's own declared files.

    Only the filesystems actually holding the service's required files and data
    are considered, so a full volume elsewhere on the host is not blamed for this
    service. Absent capacity telemetry produces nothing; unknown is not healthy.
    """
    rows = telemetry.get("filesystems")
    if not isinstance(rows, list) or not rows:
        return []
    capacity: dict[str, dict[str, Any]] = {}
    for row in rows[:64]:
        if isinstance(row, dict) and isinstance(row.get("mount_point"), str):
            capacity[row["mount_point"]] = row
    if not capacity:
        return []
    mounts = list(capacity)
    declared = [*manifest.get("required_files", [])[:64], *manifest.get("required_data", [])[:64]]
    findings: list[dict[str, Any]] = []
    for mount in sorted({m for path in declared if (m := _covering_mount(str(path), mounts))}):
        row = capacity[mount]
        total, free = row.get("total_bytes"), row.get("free_bytes")
        inodes_total, inodes_free = row.get("total_inodes"), row.get("free_inodes")
        evidence = {"mount_point": mount, "free_bytes": free, "total_bytes": total,
                    "free_inodes": inodes_free, "total_inodes": inodes_total}
        if row.get("read_only") is True:
            findings.append({"code": "service_filesystem_read_only", "subject": service,
                             "evidence": evidence})
            continue
        if (isinstance(total, int) and isinstance(free, int) and total > 0
                and free / total <= SERVICE_FILESYSTEM_EXHAUSTED_FRACTION
                and free <= SERVICE_FILESYSTEM_EXHAUSTED_BYTES):
            findings.append({"code": "service_filesystem_full", "subject": service,
                             "evidence": evidence})
        elif (isinstance(inodes_total, int) and isinstance(inodes_free, int) and inodes_total > 0
                and inodes_free / inodes_total <= SERVICE_FILESYSTEM_EXHAUSTED_FRACTION):
            findings.append({"code": "service_filesystem_inodes_exhausted", "subject": service,
                             "evidence": evidence})
    return findings


def native_fault_findings(service: str, current: dict[str, Any], prior: dict[str, Any],
                          *, running: bool = False) -> list[dict[str, Any]]:
    """Name why the service manager says this unit stopped (issue #13).

    Every field here is already collected; none of it is command output that is
    ever executed. An unrecognized verdict stays unknown rather than guessing.
    A running unit keeps the verdict of its last failure, so that verdict is not
    reported as a current fault; a climbing restart counter still is.
    """
    findings: list[dict[str, Any]] = []
    verdict = str(current.get("result", "unknown")).strip().casefold()[:128]
    substate = str(current.get("substate", "unknown")).strip().casefold()[:64]
    restarts = current.get("restart_count", 0)
    before = prior.get("restart_count", 0)
    delta = restarts - before if type(restarts) is int and type(before) is int else None
    exit_code = current.get("exit_code")
    if substate in RESTART_LOOP_SUBSTATES or (delta is not None and delta >= NATIVE_RESTART_LOOP_DELTA):
        findings.append({"code": "service_restart_looping", "subject": service,
                         "evidence": {"substate": substate, "restarts": restarts,
                                      "restarts_since_baseline": delta}})
    if running:
        return findings
    code = NATIVE_FAULT_CODES.get(verdict)
    if code == "service_exited_with_error" and (exit_code is None or exit_code == 0):
        # systemd reports `exit-code` with a zero status for a unit whose main
        # process succeeded but whose type contract was not met. That is a
        # startup-contract fault, not an application error.
        code = "service_startup_protocol_violation"
    if code:
        evidence = {"native_result": verdict}
        if type(exit_code) is int:
            evidence["exit_code"] = exit_code
        if substate != "unknown":
            evidence["substate"] = substate
        findings.append({"code": code, "subject": service, "evidence": evidence})
    elif verdict not in {"", "unknown", "success"}:
        findings.append({"code": "native_failure_reason_unrecognized", "subject": service,
                         "evidence": {"native_result": verdict}})
    return findings


def restart_futility(findings: list[dict[str, Any]]) -> str:
    """The first evidence-based blocking reason for restart, or an empty string."""
    for finding in findings:
        reason = RESTART_FUTILE_CODES.get(finding.get("code", ""))
        if reason:
            evidence = finding.get("evidence") or {}
            port = evidence.get("port")
            return f"{reason} (port {port})" if port else reason
    return ""


def restart_blockers(service: str, manifest: dict[str, Any], current: dict[str, Any],
                     prior: dict[str, Any], telemetry: dict[str, Any]) -> list[dict[str, Any]]:
    """Fault findings a mutation path must consider before restarting."""
    running = str(current.get("state", "")) == "running"
    findings = native_fault_findings(service, current, prior, running=running)
    # A filesystem fault under the service's own files blocks it whether or not
    # the service is currently running: a running service cannot write, and a
    # stopped one cannot start.
    findings.extend(host_capacity_findings(service, manifest, telemetry))
    if str(current.get("state", "")).casefold() == "deactivating":
        # Its listener is its own, not another process's: it has not finished
        # stopping. Name that instead of an owner conflict it does not have.
        findings.append({"code": "service_stop_stuck", "subject": service,
                         "evidence": {"substate": str(current.get("substate", "unknown"))[:64]}})
        return findings
    if not running:
        findings.extend(port_conflict_findings(service, manifest, telemetry))
    return findings


def diagnose_service(profile: Any, agent_id: str, service: str,
                     baseline: dict[str, Any] | None, telemetry: dict[str, Any],
                     *, now: float | None = None) -> dict[str, Any]:
    """Structured observations, not a claim to have proven an attack's cause."""
    from .service_recovery import _fresh
    import time
    findings: list[dict[str, Any]] = []
    try:
        manifest = _manifest(profile, agent_id, service)
        _fresh(telemetry, time.time() if now is None else now,
               allow_payload_issues=manifest.get("repair_policy", {}).get("allow_unrelated_payload_errors", False),
               service=service)
        current = _one(telemetry.get("services", []), "name", service)
        if not baseline:
            raise ValueError("approved baseline is unavailable")
        prior = _one(baseline.get("services", []), "name", service)
        if prior.get("state") != "running":
            findings.append({"code": "no_running_baseline", "subject": service})
        if str(current.get("start_mode", "")).casefold() in {"disabled", "masked", "masked-runtime"}:
            findings.append({"code": "startup_configuration_changed", "subject": service})
        if current.get("state") in {"stopped", "inactive", "failed"}:
            findings.append({"code": "service_stopped", "subject": service})
        elif current.get("state") != "running":
            findings.append({"code": "native_state_unknown", "subject": service})
        # Why it stopped, from the service manager's own verdict and the
        # declared listening port. These explain the state finding above; they
        # never authorize a mutation on their own (issue #13).
        findings.extend(restart_blockers(service, manifest, current, prior, telemetry))
        visited: set[str] = set()
        active: set[str] = set()

        def dependencies(item: dict[str, Any]) -> None:
            name = item["service_id"]
            if name in active:
                raise ValueError("service dependency cycle")
            if name in visited:
                return
            if len(visited) + len(active) >= 128:
                raise ValueError("service dependency diagnosis budget exceeded")
            active.add(name)
            for dependency in item["dependencies"]:
                child = _manifest(profile, agent_id, dependency)
                dependencies(child)
                row = _one(telemetry.get("services", []), "name", dependency)
                if row.get("state") != "running":
                    findings.append({"code": "dependency_unavailable", "subject": dependency})
                elif not all(value is True for value in probe_health(child["expected_transactions"], telemetry)):
                    findings.append({"code": "dependency_unhealthy", "subject": dependency})
            active.remove(name)
            visited.add(name)

        dependencies(manifest)
        for name in manifest["required_accounts"]:
            row = _one(telemetry.get("accounts", []), "name", name)
            if row.get("enabled") is not True:
                findings.append({"code": "required_account_unavailable", "subject": name})
        for path in manifest["required_files"]:
            before = _one(baseline.get("integrity", []), "path", path)
            matches = [row for row in telemetry.get("integrity", []) if row.get("path") == path]
            if not matches:
                findings.append({"code": "configuration_missing", "subject": path})
            elif len(matches) != 1 or matches[0].get("readable") is False:
                findings.append({"code": "configuration_unverified", "subject": path})
            elif any(matches[0].get(field, "") != before.get(field, "")
                     for field in ("sha256", "security_descriptor_sha256")):
                findings.append({"code": "configuration_changed", "subject": path})
        health = probe_health(manifest["expected_transactions"], telemetry)
        own = host_addresses(telemetry)
        local = [value for spec, value in zip(manifest["expected_transactions"], health) if local_probe(spec, own)]
        if current.get("state") == "running":
            if any(value is False for value in local):
                findings.append({"code": "local_application_unhealthy", "subject": service})
            elif any(value is False for value in health):
                findings.append({"code": "external_path_or_access_failure" if local and all(local)
                                 else "application_failure_location_unknown", "subject": service})
        if any(value is None for value in health):
            findings.append({"code": "transaction_evidence_missing", "subject": service})
        return {"code": "healthy" if not findings else findings[0]["code"], "findings": findings,
                "repair_order": list(dict.fromkeys(item["subject"] for item in findings
                                                   if item["code"].startswith("dependency_"))) + [service]}
    except (KeyError, TypeError, ValueError, RecursionError) as exc:
        return {"code": "insufficient_evidence", "findings": findings,
                "reason": str(exc)[:500], "repair_order": []}


def _approved_files(contract: dict[str, Any], baseline: dict[str, Any],
                    telemetry: dict[str, Any]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    files, changed = [], []
    windows = str(telemetry.get("platform", "")).casefold().startswith("windows")
    for path in contract["files"]:
        before = _one(baseline.get("integrity", []), "path", path)
        digest, security = before.get("sha256", ""), before.get("security_descriptor_sha256", "")
        if not SHA256.fullmatch(digest) or windows and not SHA256.fullmatch(security):
            raise ValueError(f"required file lacks approved content/security metadata: {path}")
        files.append({"path": path, "sha256": digest, "security_descriptor_sha256": security})
        rows = [row for row in telemetry.get("integrity", []) if row.get("path") == path]
        if len(rows) > 1 or rows and (rows[0].get("readable") is False or not SHA256.fullmatch(rows[0].get("sha256", ""))):
            raise ValueError(f"required file is unreadable or ambiguous: {path}")
        current = rows[0] if rows else None
        if current is not None and current.get("sha256") == digest and current.get("security_descriptor_sha256", "") == security:
            continue
        observed_security = current.get("security_descriptor_sha256", "") if current else ""
        if not windows and current and bool(security) != bool(observed_security):
            raise ValueError(f"file security evidence requires explicit baseline review: {path}")
        if windows and current and not SHA256.fullmatch(observed_security):
            raise ValueError(f"changed file lacks Windows security metadata: {path}")
        changed.append({"path": path, "baseline_sha256": digest,
                        "baseline_security_descriptor_sha256": security,
                        "observed_sha256": current.get("sha256") if current else None,
                        "observed_security_descriptor_sha256": observed_security,
                        "observed_missing": current is None})
    return files, changed


def _check_file_authority(profile: Any, agent_id: str, manifest: dict[str, Any],
                          changed: list[dict[str, Any]]) -> None:
    allowed = {path_key(path) for path in manifest["repair_policy"]["restore_files"]}
    for item in changed:
        key = path_key(item["path"])
        if key not in allowed:
            raise ValueError(f"file repair is not authorized: {item['path']}")
        for other in profile.services:
            if other["host"] != agent_id:
                continue
            if other["service_id"] != manifest["service_id"] and key in {
                path_key(path) for path in other["required_files"]
            }:
                raise ValueError("shared configuration requires a coordinated multi-service contract")
            for data in other["required_data"]:
                root = path_key(data).rstrip("/")
                if key == root or key.startswith(root + "/"):
                    raise ValueError("service repair cannot overwrite declared business data")


MASKED_START_MODES = frozenset({"masked", "masked-runtime"})


def repair_parameters(profile: Any, agent_id: str, service: str, baseline: dict[str, Any],
                      telemetry: dict[str, Any], *, automated: bool = True,
                      now: float | None = None) -> dict[str, Any]:
    """The exact repair for one service, or a stated reason there is none.

    `automated` selects which manifest list grants the authority: the automatic
    list for the recovery planner, the approval list for a repair an operator
    approves from an alert. Each is checked against the list it came from, the
    same way the controller admits every other operator-approved action.
    """
    from .service_recovery import _fresh, check_recovery_observation, recovery_contract
    import time
    manifest = _manifest(profile, agent_id, service)
    if (automated and str(telemetry.get("platform", "")).casefold().startswith("linux")
            and ("rollback_service_repair" not in manifest["approval_actions"]
                 or not profile.action_allowed("rollback_service_repair", automated=False, autonomy_mode="approval-based"))):
        raise ValueError("approve rollback_service_repair before enabling automatic coordinated repair")
    policy = manifest.get("repair_policy")
    if not policy:
        raise ValueError("coordinated repair requires an explicit repair_policy")
    instant = time.time() if now is None else now
    _fresh(telemetry, instant, allow_payload_issues=policy.get("allow_unrelated_payload_errors", False),
           service=service)
    contract = recovery_contract(profile, agent_id, service, action="repair_service",
                                 authority="allowed_automatic_actions" if automated else "approval_actions")
    prior = _one(baseline.get("services", []), "name", service)
    current = _one(telemetry.get("services", []), "name", service)
    if prior.get("state") != "running":
        raise ValueError("repair requires an approved running-service baseline")
    # A restart the service manager or the host will defeat is held and named
    # before any less specific refusal (issue #13).
    blockers = restart_blockers(service, manifest, current, prior, telemetry)
    try:
        _restored, explained = _approved_files(contract, baseline, telemetry)
    except (KeyError, TypeError, ValueError):
        explained = []          # the file check below names the problem
    if explained:
        blockers = [item for item in blockers if item.get("code") not in CONFIGURATION_EXPLAINED_CODES]
    futile = restart_futility(blockers)
    if futile:
        raise ValueError(f"{futile}; repair is held for review")
    state = current.get("state")
    stopped = {"stopped"}
    if str(telemetry.get("platform", "")).casefold().startswith("linux"):
        stopped.update({"inactive", "failed"})
    if state not in stopped | {"running"}:
        raise ValueError("unknown native state holds repair")
    start_mode = str(current.get("start_mode", "")).casefold()
    startup = None
    if start_mode in {"disabled"} | MASKED_START_MODES:
        desired = policy.get("restore_start_mode")
        windows = str(telemetry.get("platform", "")).casefold().startswith("windows")
        allowed = {"auto", "manual"} if windows else {"enabled"}
        # A mask is repaired only on Linux and only with its own explicit grant.
        observed_allowed = {"disabled"} | (MASKED_START_MODES if not windows and policy.get("unmask") is True else set())
        if (state not in stopped or start_mode not in observed_allowed or desired not in allowed
            or str(prior.get("start_mode", "")).casefold() != desired):
            raise ValueError("disabled or masked service needs an exact approved startup-configuration contract")
        startup = {"observed": start_mode, "desired": desired}
    files, changed = _approved_files(contract, baseline, telemetry)
    _check_file_authority(profile, agent_id, manifest, changed)
    from .restore_health import refusal as restore_refusal
    unavailable = restore_refusal(telemetry, [item['path'] for item in changed])
    if unavailable:
        raise ValueError(unavailable)
    if state == "running":
        health = probe_health(contract["probes"], telemetry)
        failed_locally = any(value is False and local_probe(spec, host_addresses(telemetry))
                             for spec, value in zip(contract["probes"], health))
        # This text is the Services tab's Recovery column for every healthy
        # service; the old wording read as if something were required.
        if not failed_locally and all(value is True for value in health):
            raise ValueError("running and its checks pass; nothing to recover")
        if not policy["restart_unhealthy"] or not failed_locally:
            raise ValueError("running service needs authorized restart and a failed local application transaction")
    guard = {"files": files, "dependencies": contract["dependencies"],
             "dependency_probes": contract["dependency_probes"], "required_accounts": contract["required_accounts"],
             "boot_id": telemetry["boot_id"], "sequence": telemetry["sequence"], "observed_at": telemetry["observed_at"]}
    if policy.get("allow_unrelated_payload_errors") is True:
        guard["allow_unrelated_payload_errors"] = True
    if "attempt_limits" in policy:
        guard["attempt_limits"] = dict(policy["attempt_limits"])
    parameters = {"service": service, "probes": contract["probes"], "recovery_guard": guard,
                  "repair": {"restore_files": changed, "observed_state": "running" if state == "running" else "stopped",
                             "restart_unhealthy": policy["restart_unhealthy"],
                             "validation_timeout_seconds": policy["validation_timeout_seconds"]}}
    if startup is not None:
        parameters["repair"]["startup"] = startup
    check_recovery_observation(parameters, telemetry, now=instant)
    return parameters


def validate_repair_shape(parameters: dict[str, Any]) -> None:
    from .policy import validate_action_parameters
    if set(parameters) != {"service", "probes", "recovery_guard", "repair"}:
        raise ValueError("service repair requires its exact guarded contract")
    value = parameters["repair"]
    fields = {"restore_files", "observed_state", "restart_unhealthy", "validation_timeout_seconds"}
    if not isinstance(value, dict) or not fields <= set(value) or set(value) - fields - {"startup"}:
        raise ValueError("service repair plan fields are invalid")
    if "startup" in value:
        startup = value["startup"]
        if (not isinstance(startup, dict) or set(startup) != {"observed", "desired"}
            or startup.get("observed") not in {"disabled"} | MASKED_START_MODES
            or startup.get("desired") not in ("enabled", "auto", "manual")
            or startup["observed"] in MASKED_START_MODES and startup["desired"] != "enabled"):
            raise ValueError("service startup repair plan is invalid")
    if value["observed_state"] not in {"running", "stopped"} or type(value["restart_unhealthy"]) is not bool:
        raise ValueError("service repair state or restart authority is invalid")
    timeout = value["validation_timeout_seconds"]
    if type(timeout) is not int or not 5 <= timeout <= MAX_REPAIR_VALIDATION_SECONDS:
        raise ValueError("service repair validation timeout is invalid")
    files = value["restore_files"]
    if not isinstance(files, list) or len(files) > MAX_REPAIR_FILES:
        raise ValueError("service repair file budget exceeded")
    keys = []
    for item in files:
        if not isinstance(item, dict) or set(item) != {
            "path", "baseline_sha256", "baseline_security_descriptor_sha256", "observed_sha256",
            "observed_security_descriptor_sha256", "observed_missing"
        }:
            raise ValueError("service repair file observation is incomplete")
        validate_action_parameters("restore_integrity", item)
        if item["observed_missing"] != (item["observed_sha256"] is None):
            raise ValueError("service repair missing-file evidence is inconsistent")
        keys.append(path_key(item["path"]))
    if len(set(keys)) != len(keys):
        raise ValueError("service repair contains duplicate file targets")


def validate_repair_contract(profile: Any, agent_id: str, parameters: dict[str, Any],
                            telemetry: dict[str, Any], *, automated: bool = True) -> None:
    """Agent recomputes the plan from the signed baseline pins and its observation."""
    from .policy import validate_action_parameters
    validate_action_parameters("repair_service", parameters)
    guard = parameters["recovery_guard"]
    current = _one(telemetry.get("services", []), "name", parameters["service"])
    baseline = {"services": [{"name": parameters["service"], "state": "running",
                              "restart_count": current.get("restart_count", 0)}],
                "integrity": guard["files"]}
    if "startup" in parameters["repair"]:
        baseline["services"][0]["start_mode"] = parameters["repair"]["startup"]["desired"]
    expected = repair_parameters(profile, agent_id, parameters["service"], baseline, telemetry,
                                 automated=automated)
    # A newer observation can authorize the same fault, but cannot change the
    # plan, boot, file state, dependencies or policy while an action is queued.
    for field in ("sequence", "observed_at"):
        expected["recovery_guard"][field] = guard[field]
    if expected != parameters:
        raise ValueError("service repair differs from the exact manifest and observation")
    from .service_recovery import check_recovery_observation
    check_recovery_observation(parameters, telemetry)


def plan_digest(parameters: dict[str, Any]) -> str:
    return hashlib.sha256(canonical_json_bytes(parameters)).hexdigest()
