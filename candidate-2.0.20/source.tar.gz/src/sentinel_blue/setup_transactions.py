"""Compile durable, per-attempt rollback for the built-in service adapters."""
from __future__ import annotations
from .runtime_environment import target_python_shell

import base64
import hashlib
import ipaddress
import json
import zlib
from importlib.resources import files

TOKEN = 'SENTINEL_SETUP_TRANSACTION_ID_171'
# Bound with the transaction identity: 'setup' for a first run, 'redo' when the
# approved setup is run again to put back what it established. Not part of the
# reviewed spec, so a redo runs exactly the approved plan.
MODE = 'SENTINEL_SETUP_MODE_206'
RECIPES = frozenset({'linux-service', 'linux-nginx', 'linux-service-pack',
                     'windows-service', 'windows-firewall', 'windows-iis'})


def commands(recipe, options, root, apply, *, context=None):
    if recipe not in RECIPES:
        return None
    from .setup_recipes import _source
    spec = {'version': 1, 'recipe': recipe, 'apply_sha256': hashlib.sha256(apply.encode()).hexdigest()}
    spec['ledger_context'] = context or {}
    if recipe == 'linux-service':
        spec.update(service=options['service'], files=[{
            'path': row['path'], 'sha256': hashlib.sha256(_source(root, row['source']).encode()).hexdigest(),
            'mode': row.get('mode', '0644'), 'previous_sha256': row['previous_sha256'],
            **{key: row[key] for key in ('create_owner', 'create_group', 'readable_by') if key in row}
        } for row in options.get('files', [])])
    elif recipe == 'linux-nginx':
        from .application_setup import linux_nginx
        linux_nginx(options, root, metadata=spec)
    elif recipe == 'linux-service-pack':
        # A pack mutates exactly what a linux-service task mutates — hash-pinned
        # configuration files and one unit — so it earns the same durable
        # ownership and rollback contract, built from the same metadata.
        from .linux_service_packs import build
        build(options.get('catalog_id', ''),
              {key: value for key, value in options.items() if key != 'catalog_id'},
              root, metadata=spec)
    elif recipe == 'windows-service':
        spec['service'] = options['service']
    elif recipe == 'windows-firewall':
        spec['name'] = options['name']
        spec['rules'] = ['Sentinel-' + options['name'] + '-' + f'{i:03d}' for i in range(len(options['allow']))]
    elif recipe == 'windows-iis':
        spec.update(name='Sentinel-' + options['name'], service='W3SVC',
                    address=str(ipaddress.ip_address(options['listen_address'])), port=options['port'],
                    certificate=options.get('certificate_thumbprint'),
                    content_sha256=hashlib.sha256(_source(root, options['content']).encode()).hexdigest())
    if recipe.startswith('linux-'):
        from pathlib import PurePosixPath
        suffixes = ('.service', '.socket', '.mount', '.automount', '.target', '.timer', '.path', '.scope', '.slice', '.device', '.swap')
        if not spec['service'].endswith(suffixes):
            spec['service'] += '.service'
        for row in spec['files']:
            row['path'] = str(PurePosixPath(row['path']))
    encoded = base64.b64encode(json.dumps(spec, sort_keys=True).encode()).decode()
    if recipe.startswith('linux-'):
        # Each embedded program is compressed. The recipe's own script already
        # carries its files, and base64 of base64 made a stock redis.conf
        # overflow the plan's per-string limit.
        def packed(data: bytes) -> str:
            return base64.b64encode(zlib.compress(data, 9)).decode()
        payload = packed(apply.encode())
        source = packed(files('sentinel_blue').joinpath('setup_linux_transaction.py').read_bytes())
        ledger_source = packed(files('sentinel_blue').joinpath('mutation_ledger.py').read_bytes())
        def build(phase):
            return (f"set -eu\n{target_python_shell()} -I -B - <<'SENTINEL_OWNED_SETUP'\nimport base64,json,sys,types,zlib\n"
                    "def unpack(v):\n return zlib.decompress(base64.b64decode(v,validate=True))\n"
                    f"ledger=types.ModuleType('sentinel_mutation_ledger');sys.modules[ledger.__name__]=ledger\nexec(compile(unpack('{ledger_source}'),'sentinel-ledger','exec'),ledger.__dict__)\n"
                    f"ns={{'__name__':'sentinel_setup_transaction'}}\nexec(compile(unpack('{source}'),'sentinel-setup-transaction','exec'),ns)\n"
                    f"ns['run']('{phase}',json.loads(base64.b64decode('{encoded}')),'{TOKEN}',"
                    + (f"unpack('{payload}').decode()" if phase == 'apply' else "None") + f",mode='{MODE}')\n"
                    "SENTINEL_OWNED_SETUP\n")
    else:
        source = files('sentinel_blue').joinpath('setup_windows_transaction.ps1').read_text(encoding='utf-8')
        source += '\n' + files('sentinel_blue').joinpath('mutation_ledger_windows.ps1').read_text(encoding='utf-8')
        # The native child keeps legacy exit statements inside its own process.
        powershell_payload = base64.b64encode(apply.encode('utf-16le')).decode()
        def build(phase):
            return (source + f"\n$sbSpec = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('{encoded}')) | ConvertFrom-Json\n"
                    f"Invoke-SentinelTransaction '{phase}' '{TOKEN}' $sbSpec '{powershell_payload}'\n")
    scripts = {phase: build(phase) for phase in ('admit', 'apply', 'rollback', 'commit')}
    from .json_codec import MAX_JSON_STRING_CHARS
    if max(len(script) for script in scripts.values()) > MAX_JSON_STRING_CHARS:
        raise ValueError(f"{spec.get('service') or spec.get('name') or recipe}: the files this step writes are too "
                         f"large to carry in one reviewed setup step (about {MAX_JSON_STRING_CHARS // 1024} KiB "
                         "after compression); split the configuration or adopt the service without generating it")
    return scripts


def bind(script, transaction_id, *, redo=False):
    import re
    if not re.fullmatch('[0-9a-f]{32}', transaction_id):
        raise ValueError('Invalid setup transaction identity')
    if type(redo) is not bool:
        raise ValueError('Invalid setup mode')
    return script.replace(TOKEN, transaction_id).replace(MODE, 'redo' if redo else 'setup')
