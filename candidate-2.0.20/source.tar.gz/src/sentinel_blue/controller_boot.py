"""Exact owned controller boot registration, using native OS supervision."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

from .recovery import _read_regular_bytes, _require_private_directory
from .state import read_private_json


def arguments_from_config(path):
    path = Path(path).absolute()
    _require_private_directory(path.parent)
    data = json.loads(_read_regular_bytes(path, maximum=65536))
    if not isinstance(data, dict) or set(data) != {'controller_arguments'}:
        raise ValueError('Controller configuration requires only controller_arguments')
    arguments = data['controller_arguments']
    if (not isinstance(arguments, list) or len(arguments) > 256
            or any(not isinstance(x, str) or not x or len(x) > 4096 or any(c in x for c in '\x00\r\n') for x in arguments)
            or any(x.split('=')[0] in {'--token', '--operator-token', '--supervisor-child'} for x in arguments)):
        raise ValueError('Use literal controller arguments and private credential files')
    from .__main__ import parser
    try:
        args = parser().parse_args(['controller', *arguments])
    except SystemExit:
        raise ValueError('Controller boot arguments are invalid') from None
    # Service-manager working directories differ from interactive sessions.
    for name in ('database', 'event_profile', 'token_file', 'operator_token_file', 'tls_cert', 'tls_key',
                 'tls_ca_file', 'recovery_key_file', 'recovery_anchor', 'history_directory',
                 'backup_directory', 'supervisor_directory', 'probe_config', 'model', 'observer_config'):
        value = getattr(args, name, None)
        if value and not Path(value).is_absolute():
            raise ValueError('Controller boot paths must be absolute: ' + name)
    if '--supervise' not in arguments:
        arguments = [*arguments, '--supervise']
    return arguments, args


def artifacts_from_config(path):
    from .controller_restore import ARTIFACT_ROLES
    _, args = arguments_from_config(path)
    return {name: getattr(args, name) for name in ARTIFACT_ROLES if getattr(args, name, None)}


def _digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def binding(config, runtime, *, ledger_directory=None):
    from .event_profile import load_event_profile
    from .config_validation import validate_bound_transport
    from .runtime_environment import python_command
    arguments, args = arguments_from_config(config)
    profile = load_event_profile(args.event_profile)
    profile.require_runtime_ready(range_deployment=args.range_deployment)
    profile.verify_release_file(runtime)
    validate_bound_transport(profile, role='controller', ca_file=args.tls_ca_file,
                             tls_cert=args.tls_cert, tls_key=args.tls_key, syslog_bind=args.syslog_bind)
    runtime = Path(runtime).absolute()
    _require_private_directory(Path(config).absolute().parent)
    if runtime.is_symlink() or not runtime.is_file():
        raise ValueError('Boot runtime must be an exact regular file')
    material = {str(Path(config).absolute()): _digest(config), str(runtime): _digest(runtime)}
    for path in artifacts_from_config(config).values():
        raw = _read_regular_bytes(Path(path), maximum=16 * 1024 * 1024, private=False)
        material[str(Path(path).absolute())] = hashlib.sha256(raw).hexdigest()
    from .mutation_ledger import default_directory
    ledger_path = Path(ledger_directory or default_directory())
    if not ledger_path.is_absolute():
        raise ValueError('Controller boot ledger path must be absolute')
    return {'schema': 2, 'runtime': str(runtime), 'config': str(Path(config).absolute()),
            'ledger_directory': str(ledger_path),
            'python': python_command(), 'arguments': arguments, 'files': material,
            'profile_fingerprint': profile.fingerprint}


def systemd_unit(command, ledger_path):
    def quote(value):
        if any(c in value for c in '\x00\n\r'):
            raise ValueError('Unsafe boot command')
        return '"' + value.replace('\\', '\\\\').replace('"', '\\"').replace('%', '%%').replace('$', '$$') + '"'
    return ('[Unit]\nDescription=Sentinel Blue controller\nWants=network-online.target\nAfter=network-online.target\n'
            # Never stop restarting: a start limit would leave the controller
            # down for the rest of an event after a few quick failures.
            'StartLimitIntervalSec=0\n[Service]\nType=simple\nUser=root\nUMask=0077\n'
            'Environment=' + quote('SENTINEL_LEDGER_DIR=' + str(ledger_path)) + '\n'
            'ExecStart=' + ' '.join(quote(x) for x in command) + '\n'
            'Restart=always\nRestartSec=10\nTimeoutStopSec=30\nKillMode=control-group\n'
            'NoNewPrivileges=true\n[Install]\nWantedBy=multi-user.target\n')


def install(config, runtime):
    from .mutation_ledger import MutationLedger
    from .mutation_ledger import _harden_new_windows_file, _sync_directory
    def _atomic(path, data):
        # Creation is exclusive: an object appearing after review is a conflict.
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_BINARY', 0), 0o600)
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        _harden_new_windows_file(path)
        _sync_directory(path.parent)
    from .withdrawal_native import NativeObjects, object_target
    ledger = MutationLedger()
    value = binding(config, runtime, ledger_directory=ledger.directory)
    native = NativeObjects(ledger)
    receipt = Path(config).absolute().with_name('controller-boot-binding.json')
    if receipt.exists() or receipt.is_symlink():
        raise ValueError('Existing boot binding must be reviewed, not overwritten')
    command = [*value['python'], str(Path(runtime).absolute()), 'controller-boot-run',
               '--config', str(Path(config).absolute()), '--runtime', str(Path(runtime).absolute()),
               '--ledger-directory', str(ledger.directory)]
    unit = Path('/etc/systemd/system/sentinel-blue-controller.service')
    if os.name == 'nt':
        from .launcher import _windows_task_action, _powershell_executable
        task = {'task_path': '\\', 'task_name': 'SentinelBlueController'}
        if native.task(task) is not None:
            raise ValueError('Existing controller task requires ownership review')
        target = object_target(files=[str(receipt)], tasks=[task])
        script = ("$ErrorActionPreference='Stop'\n" + _windows_task_action(command[0], command[1:]) +
                  "\n$trigger=New-ScheduledTaskTrigger -AtStartup\n"
                  "$settings=New-ScheduledTaskSettingsSet -StartWhenAvailable -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew\n"
                  "Register-ScheduledTask -TaskName 'SentinelBlueController' -TaskPath '\\' -Action $action -Trigger $trigger -Settings $settings -User 'SYSTEM' -RunLevel Highest | Out-Null\n")
        def register():
            _atomic(receipt, json.dumps(value, sort_keys=True).encode())
            subprocess.run([_powershell_executable(), '-NoProfile', '-NonInteractive', '-Command', script],
                           check=True, timeout=60, capture_output=True)
            return {'installed': True, 'registration': 'SentinelBlueController', 'starts_at_next_boot': True}
    else:
        if not Path('/run/systemd/system').is_dir() or os.geteuid() != 0:
            raise ValueError('A native systemd host and administrative identity are required')
        if unit.exists() or unit.is_symlink() or native.service(unit.name)['exists']:
            raise ValueError('Existing controller service requires ownership review')
        target = object_target(files=[str(unit), str(receipt)], services=[unit.name])
        def register():
            _atomic(receipt, json.dumps(value, sort_keys=True).encode())
            _atomic(unit, systemd_unit(command, ledger.directory).encode())
            subprocess.run(['systemctl', 'daemon-reload'], check=True, timeout=30, capture_output=True)
            subprocess.run(['systemctl', 'enable', '--', unit.name], check=True, timeout=30, capture_output=True)
            return {'installed': True, 'registration': unit.name, 'starts_at_next_boot': True}
    with ledger.lock():
        if ledger.automation_paused():
            raise ValueError('Pause/Withdraw blocks installation of automatic boot persistence')
        result = ledger.mutate(native.name, target, register, snapshot=native.snapshot,
                               ownership='sentinel_artifact', context={'controller_boot': True})
    return {**result, 'receipt': str(receipt), 'ledger_head': ledger.head()}


UNIT = 'sentinel-blue-controller.service'


def activity_only(observed, expected, unit=UNIT):
    """The registration differs from its record only in whether it runs now.

    Found live on 2.0.6: after `systemctl stop` (or the controller exiting) the
    recorded post-state still said "running", so status reported a mismatch
    and removal was held for review, although nothing Sentinel installed had
    changed. Only the service's running state and its state-change time may
    differ; the unit file, receipt, enablement and configuration may not.
    """
    if not isinstance(observed, dict) or not isinstance(expected, dict) or set(observed) != set(expected):
        return False
    try:
        old, new = expected['services'][unit], observed['services'][unit]
    except (KeyError, TypeError):
        return False
    if set(observed['services']) != set(expected['services']) or not isinstance(new, dict) or not isinstance(old, dict):
        return False
    immutable = lambda value: {k: v for k, v in value.items() if k not in {'active', 'revision'}}
    return (new.get('exists') is True and immutable(new) == immutable(old)
            and all(observed.get(key) == expected.get(key) for key in observed if key != 'services'))


def registrations(ledger, *, include_states=False, include_held=False):
    """Committed boot registrations this host's ledger owns.

    Identity comes from the ledger's own recorded context and ownership, never
    from the presence of a unit file — an object Sentinel did not install is not
    Sentinel's to remove. ``include_states`` loads the recorded pre/post state,
    which a comparison against the live object needs.
    """
    statuses = {'committed', 'conflict'} if include_held else {'committed'}
    return [row for row in ledger.actions(include_states=include_states)
            if row.get('status') in statuses
            and row.get('ownership') == 'sentinel_artifact'
            and (row.get('context') or {}).get('controller_boot') is True]


def status(ledger=None):
    """What is actually registered to start this controller at boot.

    Answers the question an operator previously had no way to ask: does a
    registration exist, does the native object still match what was recorded,
    and can it be removed without a full withdrawal.
    """
    from .mutation_ledger import MutationLedger
    from .withdrawal_native import NativeObjects
    ledger = ledger or MutationLedger()
    with ledger.lock():
        rows = registrations(ledger, include_states=True, include_held=True)
        native = NativeObjects(ledger)
        entries = []
        for row in rows:
            target = row.get('target', {})
            try:
                observed = native.snapshot(target)
                unchanged = observed == row.get('after') or activity_only(observed, row.get('after'))
                reason = '' if unchanged else (
                    'the registered objects no longer match what was recorded; '
                    'removal is held for human review')
            except (OSError, ValueError, RuntimeError) as exc:
                unchanged, reason = False, str(exc)[:300]
            if row['status'] == 'conflict':
                reason = ('held for review by an earlier conflict; '
                          + ('only its running state differs, so removing it releases the hold' if unchanged
                             else reason or 'it changed after Sentinel installed it'))
            entries.append({
                'action_id': row['action_id'],
                'held': row['status'] == 'conflict',
                'files': list(target.get('files', [])),
                'services': list(target.get('services', [])),
                'tasks': list(target.get('tasks', [])),
                'matches_record': unchanged,
                'removable': bool(unchanged) and not ledger.paused(),
                'reason': reason,
            })
        return {'registered': bool(entries), 'registrations': entries,
                'withdrawal_review_active': ledger.paused(),
                'ledger_directory': str(ledger.directory), 'ledger_head': ledger.head()}


def uninstall(*, action_id=None, ledger=None):
    """Remove exactly the boot registration, without withdrawing the host.

    Previously the only route to this was a full Withdraw, which removes every
    Sentinel artifact on the host — so replacing a registration meant tearing
    down the whole installation, or hand-editing systemd and leaving the
    ownership ledger and the receipt describing something that no longer exists.

    The reversal itself is the same evidenced undo a withdrawal performs: the
    exact recorded pre-state, ownership proven against the observed post-state,
    refused and recorded for review if anything changed since installation.
    """
    from .mutation_ledger import MutationLedger, OwnershipConflict
    from .withdrawal import _restore_one
    ledger = ledger or MutationLedger()
    with ledger.lock():
        if ledger.paused():
            raise ValueError(
                'A withdrawal review is in progress on this host; finish or cancel it '
                'before removing the boot registration separately')
        rows = registrations(ledger, include_held=True)
        if not rows:
            raise ValueError(
                'This ledger records no controller boot registration. A unit or task this '
                'ledger did not install is not Sentinel\'s to remove; review it by hand')
        if action_id is None:
            if len(rows) != 1:
                identities = ', '.join(sorted(row['action_id'] for row in rows))
                raise ValueError(
                    f'This ledger records {len(rows)} boot registrations; name one with '
                    f'--action-id ({identities})')
            action_id = rows[0]['action_id']
        elif not any(row['action_id'] == action_id for row in rows):
            raise ValueError('That action is not a committed controller boot registration')
        target = next(row['target'] for row in rows if row['action_id'] == action_id)
        row = next(row for row in rows if row['action_id'] == action_id)
        if row['status'] == 'conflict':
            # Held by an earlier release only because the controller had
            # stopped (see activity_only). Everything Sentinel installed is
            # still exactly as recorded, so the hold is released and recorded;
            # anything else stays held.
            from .withdrawal_native import NativeObjects
            recorded = next(item for item in registrations(ledger, include_states=True, include_held=True)
                            if item['action_id'] == action_id)
            observed = NativeObjects(ledger).snapshot(target)
            if observed != recorded.get('after') and not activity_only(observed, recorded.get('after')):
                raise OwnershipConflict('The boot registration changed after Sentinel installed it; '
                                        'removal stays held for review')
            ledger.append('rebased', action_id=action_id, expected_after=ledger.store(observed),
                          prior_expected_after=ledger.store(recorded['after']),
                          reason='controller_running_state_changed')
            ledger.append('committed', action_id=action_id, after_hash=ledger.store(observed),
                          validation={'success': True, 'released_hold': 'only the controller running state had changed'})
    # The identity is proven above, so this scoped artifact is reversed without
    # the host-wide withdrawal pause. Every other guard still applies.
    result = _restore_one(ledger, action_id, require_pause=False)
    return {**result, 'removed': {'files': list(target.get('files', [])),
                                  'services': list(target.get('services', [])),
                                  'tasks': list(target.get('tasks', []))},
            'starts_at_next_boot': False, 'ledger_head': ledger.head()}


def _systemd_invocation():
    """Bind this boot wrapper to the service manager's current invocation.

    An inherited environment value alone cannot authorize a ledger update.
    MainPID must name this process, and the kernel identity is checked again
    with the native object snapshot immediately before recording the start.
    """
    from .mutation_ledger import OwnershipConflict
    from .process_identity import inspect_process_identity
    invocation = os.environ.get('INVOCATION_ID')
    if not sys.platform.startswith('linux') or invocation is None:
        return None  # Preserve direct/legacy boot-run use without claiming a unit.
    if not re.fullmatch(r'[0-9a-f]{32}', invocation) or invocation == '0' * 32:
        raise OwnershipConflict('Invalid native controller invocation')
    result = subprocess.run(
        ['systemctl', 'show', '--property=MainPID,InvocationID,ActiveState,SubState',
         '--', 'sentinel-blue-controller.service'],
        check=True, capture_output=True, text=True, timeout=15)
    fields = dict(line.split('=', 1) for line in result.stdout.splitlines() if '=' in line)
    expected = {'MainPID': str(os.getpid()), 'InvocationID': invocation,
                'ActiveState': 'active', 'SubState': 'running'}
    if fields != expected:
        raise OwnershipConflict('This process is not the active native controller invocation')
    return {'service': 'sentinel-blue-controller.service', 'invocation_id': invocation,
            'process': inspect_process_identity(os.getpid())}


def _record_native_start(ledger, config):
    """Record only a proven activation of an otherwise unchanged owned unit.

    Starting an installed systemd unit changes active/revision without passing
    through a Sentinel mutation adapter. Preserve the original undo state and
    append its new exact guard, with invocation evidence, before launching the
    controller. A changed file, startup setting, unrelated writer or withdrawal
    pause still prevents ownership being claimed.
    """
    from .mutation_ledger import OwnershipConflict
    from .withdrawal_native import NativeObjects, object_target
    proof = _systemd_invocation()
    if proof is None:
        return
    unit = 'sentinel-blue-controller.service'
    target = object_target(files=['/etc/systemd/system/' + unit,
                           str(Path(config).absolute().with_name('controller-boot-binding.json'))],
                           services=[unit])
    with ledger.lock():
        if ledger.paused():
            raise ValueError('Withdraw prevents controller boot')
        rows = [row for row in registrations(ledger, include_states=True)
                if row.get('adapter') == NativeObjects.name and row.get('target') == target]
        if len(rows) != 1:
            raise OwnershipConflict('Native controller startup requires one exact owned registration')
        row = rows[0]
        before, expected = row['before'], row['after']
        if (before['services'][unit]['exists'] or
                any(value is not None for value in before['files'].values())):
            raise OwnershipConflict('Native controller registration was not exclusively created by Sentinel')
        for other in ledger.actions():
            if (other['sequence'] > row['sequence'] and other['status'] not in {'undone', 'cancelled'}
                    and set(other['target'].get('objects', ())) & set(target['objects'])):
                raise OwnershipConflict('Another action owns part of the native controller registration')
        native = NativeObjects(ledger)
        observed = native.snapshot(target)
        old, new = expected['services'][unit], observed['services'][unit]
        immutable = lambda value: {k: v for k, v in value.items() if k not in {'active', 'revision'}}
        if (not new['exists'] or new['active'] is not True or
                immutable(new) != immutable(old) or
                any(observed[key] != expected[key] for key in ('files', 'tasks', 'persistence'))):
            raise OwnershipConflict('Native controller objects changed; human review is required')
        if _systemd_invocation() != proof or native.snapshot(target) != observed:
            raise OwnershipConflict('Native controller changed while proving its startup')
        if ledger.paused():
            raise ValueError('Withdraw prevents controller boot')
        if observed != expected:
            ledger.append('rebased', action_id=row['action_id'],
                          expected_after=ledger.store(observed), prior_expected_after=ledger.store(expected),
                          reason='verified_systemd_start', invocation=proof,
                          validation={'success': True, 'ownership_proven': True})


def run(args):
    if args.command == 'controller-boot-install':
        print(json.dumps(install(args.config, args.runtime), indent=2))
        return 0
    if args.command in {'controller-boot-status', 'controller-boot-uninstall'}:
        from .mutation_ledger import MutationLedger
        directory = getattr(args, 'ledger_directory', None)
        ledger = MutationLedger(Path(directory)) if directory else MutationLedger()
        if args.command == 'controller-boot-status':
            print(json.dumps(status(ledger), indent=2))
        else:
            print(json.dumps(
                uninstall(action_id=getattr(args, 'action_id', None), ledger=ledger), indent=2))
        return 0
    from .mutation_ledger import MutationLedger, default_directory
    receipt = Path(args.config).absolute().with_name('controller-boot-binding.json')
    saved = json.loads(_read_regular_bytes(receipt, maximum=65536))
    saved_schema = saved.get('schema')
    if saved_schema not in {1, 2}:
        raise ValueError('Unsupported controller boot binding; reviewed rebinding is required')
    # A registration written by an earlier release records schema 1 and pins no
    # ledger, so its startup command supplies no --ledger-directory. Keep that
    # exact prior behaviour instead of failing every boot after an upgrade; the
    # config, runtime, arguments, profile and file digests are still verified.
    if args.ledger_directory is None:
        if saved_schema != 1:
            raise ValueError('This boot binding pins an exact ledger; --ledger-directory is required')
        ledger_path = Path(default_directory())
    else:
        ledger_path = Path(args.ledger_directory)
    if not ledger_path.is_absolute():
        raise ValueError('Controller boot ledger path must be absolute')
    current = binding(args.config, args.runtime, ledger_directory=ledger_path)
    if saved_schema == 1:
        # Compare on the schema the registration was reviewed under. A legacy
        # binding never covered the ledger path, so it cannot authorize one.
        current = {key: value for key, value in current.items() if key != 'ledger_directory'}
        current['schema'] = 1
    if current != saved:
        raise ValueError('Controller boot inputs changed; reviewed rebinding is required')
    ledger = MutationLedger(ledger_path)
    if ledger.paused():
        raise ValueError('Withdraw prevents controller boot')
    _record_native_start(ledger, args.config)
    command = [*current['python'], current['runtime'], 'controller', *current['arguments']]
    environment = dict(os.environ, SENTINEL_LEDGER_DIR=str(ledger_path))
    return subprocess.call(command, env=environment)
