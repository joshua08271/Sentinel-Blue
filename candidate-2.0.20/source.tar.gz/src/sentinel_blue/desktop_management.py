"""Linux GUI for explicit dedicated controller / agent-only workspaces."""
from __future__ import annotations
import json
import os
from pathlib import Path
from .state import read_private_json, read_private_text, write_private_json


class ManagementControls:
    def _remember_isolated(self, path):
        self.isolated_role_path = str(Path(path).absolute())
        write_private_json(self.directory/'last-isolated-role.json', {'path': self.isolated_role_path})
        self.local_context.set(False)
        self.local_prepare_button.configure(state='disabled')
        self.local_status.set('Dedicated role selected. Local combined controller+agent setup is disabled in this window.')

    def _restore_isolated_selection(self):
        self.isolated_role_path = None
        try:
            data = read_private_json(self.directory/'last-isolated-role.json', 8192)
            path = Path(data['path'])
            if not path.is_absolute():
                raise ValueError('Invalid saved role path')
            config = read_private_json(path, 65536)
            if config.get('role') not in {'controller', 'agent'}:
                raise ValueError('Invalid saved role')
            self._remember_isolated(path)
        except FileNotFoundError:
            pass
        except (OSError, ValueError, KeyError, TypeError):
            self.local_status.set('Saved dedicated role could not be verified; inspect it before preparing another session.')
            self.local_prepare_button.configure(state='disabled')

    def dedicated_management(self, join=False):
        from . import management_workspace as workspace
        from . import management_role
        if self.local_workspace is not None or self.local_wizard_busy or self.job_path is not None:
            self.note('Finish and reconcile the current local/setup session first. Dedicated mode is not an in-place migration.')
            return
        tk, ttk = self.tk, self.ttk
        window = tk.Toplevel(self.root); window.title('Dedicated controller and agent-only setup')
        window.geometry('1000x780'); window.minsize(840, 650)
        ttk.Label(window, text='Controller on a separate trusted team host • Agents on defended VMs',
                  font=('Segoe UI', 14, 'bold'), padding=12).pack(anchor='w')
        ttk.Label(window, text='Requires event authorization, distinct IPv4 addresses and reachable HTTPS. '
                  'No hypervisor, firewall, scoring-server, or running-service changes are made by preparation.',
                  wraplength=940, padding=(12,0,12,8)).pack(anchor='w')
        book = ttk.Notebook(window); book.pack(fill='both', expand=True, padx=12)
        tabs = {}
        for name in ('1 Prepare controller', '2 Approve / start', '3 Join agent', 'Status / stop'):
            tab = ttk.Frame(book, padding=12); book.add(tab, text=name); tabs[name] = tab
        messages = tk.Text(window, height=8, wrap='word', padx=10, pady=8)
        messages.pack(fill='x', padx=12, pady=10)
        def say(text):
            if not window.winfo_exists():
                return
            messages.delete('1.0','end'); messages.insert('1.0', str(text))
            self.note(str(text).splitlines()[0])
        def submit(fn, done):
            def result(value):
                if window.winfo_exists():
                    done(value)
            def failure(exc):
                say(str(exc))
            if not self.submit(fn, result, failure, preserve=True):
                say('Another operation is pending; nothing was started.')
        # Preparation uses existing reviewed service manifests, never guesses them.
        form = tabs['1 Prepare controller']
        inv = self._entry(form,0,'Network inventory',self.inventory_path.get(),browse=True)
        prof = self._entry(form,1,'Source event profile',self.profile_path.get(),browse=True)
        runtime = self._entry(form,2,'Application .pyz',self.runtime_path.get(),browse=True)
        ip = self._entry(form,3,'Management IPv4 address')
        port = self._entry(form,4,'HTTPS port','8765')
        operators = self._entry(form,5,'Other operator IPv4 sources (comma separated)')
        reference = self._entry(form,6,'Management-host authorization reference')
        confirm = tk.BooleanVar(value=False)
        ttk.Checkbutton(form,text='This is a separate, authorized team management host with no scored services, '
                        'shared guest-writable storage, or reused guest admin credentials.',variable=confirm).grid(
                        row=7,column=0,columnspan=3,sticky='w',pady=8)
        current = tk.StringVar(value=getattr(self,'isolated_role_path',None) or '')
        def prepared(config):
            path = str(Path(config['directory'])/'role.json'); current.set(path); self._remember_isolated(path)
            book.select(tabs['2 Approve / start'])
            say('Candidate prepared; no controller or agent is running.\n' + config['directory'] +
                '\nReview candidate-profile.json. Live competition approval was not carried forward. '
                'Existing local state was not migrated.')
        def prepare():
            values = (inv.get(), prof.get(), runtime.get(), ip.get().strip(), port.get(),
                      [x.strip() for x in operators.get().split(',') if x.strip()], confirm.get(), reference.get().strip())
            def work():
                inventory = read_private_json(values[0], 2*1024*1024)
                from .event_profile import load_event_profile
                profile = load_event_profile(values[1])
                return workspace.prepare(self.directory/'isolated', values[2], inventory, profile, values[3], int(values[4]),
                    values[5],confirmed=values[6],authorization_reference=values[7])
            submit(work, prepared)
        ttk.Button(form,text='Prepare isolated candidate (no deployment)',command=prepare).grid(row=8,column=1,sticky='w',pady=12)
        # Finalization is separate from preparation and process startup.
        form = tabs['2 Approve / start']
        ttk.Label(form,text='Review the candidate first. A live profile needs fresh external approval of its exact '
                  'topology, CA and release hash. Only a disposable range can be approved here.',wraplength=870).grid(
                  row=0,column=0,columnspan=3,sticky='w',pady=8)
        self._management_path_row(form,1,'Role configuration',current)
        final = self._entry(form,2,'Externally approved profile (live event)',browse=True)
        range_name = self._entry(form,3,'Range operator identity (range only)')
        def finalized(config):
            self._remember_isolated(current.get())
            d = Path(config['directory'])
            say('Approved workspace and per-agent join files created; no processes started.\n'
                + str(d/'agent-exports') + '\nProvide each VM only its own ZIP. Never copy this whole workspace.\n'
                + read_private_text(d/'EXPORTS-SHA256.txt',16384))
        def approve():
            path, approved, name = current.get(), final.get().strip(), range_name.get().strip()
            if not self.messagebox.askyesno('Confirm reviewed isolation',
                'Finalize only the exact reviewed candidate? This does not approve competition use without the required '
                'event authorization. Never distribute the controller workspace to a guest.', parent=window):
                return
            submit(lambda: workspace.finalize(path, approved_profile=approved or None, range_operator=name or None), finalized)
        ttk.Button(form,text='Finalize approved profile and create join files',command=approve).grid(row=4,column=1,sticky='w',pady=8)
        def start():
            path = current.get()
            if not self.messagebox.askyesno('Start isolated role',
                'Start only this saved role? A controller opens the approved HTTPS listener. An agent connects to it. '
                'This installs no boot registration and does not deploy services.',parent=window):
                return
            try:
                permit = self.job_control.permit(self.job_control.admit())
            except (OSError, ValueError, RuntimeError) as exc:
                say(str(exc)); return
            def work():
                permit.checkpoint()
                return management_role.start(path)
            submit(work, lambda p: say('Role launcher started. Use Status and verify fresh telemetry; process launch is not service readiness.'))
        def connect():
            path = current.get()
            def connected(data):
                self.local_context.set(False)
                self.origin.set(data['origin']); self.principal.set(data['principal']); self.epoch.set(str(data['epoch']))
                self.ca_path.set(data['ca_file']); self.operator_key.set(read_private_text(data['operator_file'],4096).strip())
                self.profile_path.set(data['event_profile']); self.inventory_path.set(data['inventory']); self.runtime_path.set(data['runtime'])
                self.range_mode.set(data['range_deployment'])
                self.connect()
                say('Management connection selected. Verify the controller reports ready and each intended agent appears.')
            submit(lambda: workspace.connection(path), connected)
        ttk.Button(form,text='Start saved role',command=start).grid(row=5,column=1,sticky='w',pady=8)
        ttk.Button(form,text='Connect this GUI to management',command=connect).grid(row=6,column=1,sticky='w',pady=8)
        # A guest receives neither the management workspace nor an operator key.
        form = tabs['3 Join agent']
        ttk.Label(form,text='Run this tab inside the intended defended Linux VM using the complete offline .run. '
                  'First stop/reconcile any old local session. Import only this VM’s ZIP from the trusted management host. '
                  'Use Start here → Open as administrator before starting privileged agent work.',wraplength=870).grid(
                  row=0,column=0,columnspan=3,sticky='w',pady=8)
        package = self._entry(form,1,'This VM’s .sentinel-agent.zip',browse=True)
        expected = self._entry(form,2,'Expected SHA-256 from management EXPORTS-SHA256.txt')
        guest_runtime = self._entry(form,3,'This VM’s application .pyz',self.runtime_path.get(),browse=True)
        def imported(config):
            path = str(Path(config['directory'])/'role.json'); current.set(path); self._remember_isolated(path)
            say('Agent-only workspace imported; no controller or operator credentials were imported.\n'
                + path + '\nUse Start saved role, then verify this agent from the management GUI. '
                'Keep the original private join ZIP secure; its bootstrap ticket is sensitive until consumed/revoked.')
            book.select(tabs['Status / stop'])
        def join_agent():
            if os.geteuid() != 0:
                say('Use Start here → Open as administrator on this guest before importing its runtime workspace.'); return
            p, sha, rt = package.get(), expected.get().strip(), guest_runtime.get()
            if not self.messagebox.askyesno('Confirm agent-only import',
                'Confirm the checksum came independently from your authorized management host and that old local '
                'monitoring/pending repairs are stopped or reconciled. No existing state is migrated or deleted.',parent=window):
                return
            submit(lambda: workspace.import_agent(self.directory/'isolated',rt,p,expected_sha256=sha), imported)
        ttk.Button(form,text='Verify and import only this agent',command=join_agent).grid(row=4,column=1,sticky='w',pady=12)
        form = tabs['Status / stop']
        self._management_path_row(form,0,'Role configuration',current)
        ttk.Button(form,text='Start saved role',command=start).grid(row=1,column=1,sticky='w',pady=8)
        def show():
            path=current.get()
            submit(lambda: management_role.status(path),lambda value:say(json.dumps(value,indent=2)))
        ttk.Button(form,text='Refresh exact process status',command=show).grid(row=2,column=1,sticky='w',pady=8)
        def stop():
            path=current.get()
            if self.messagebox.askyesno('Stop this role',
                'Request graceful stop of this exact role? Stopping the controller constrains all connected agents. '
                'This is not withdrawal; wait for stopped status before changing components.',parent=window):
                submit(lambda:management_role.stop(path),lambda value:say(json.dumps(value,indent=2)))
        ttk.Button(form,text='Request graceful stop',command=stop).grid(row=3,column=1,sticky='w',pady=8)
        ttk.Button(form,text='Connect management GUI',command=connect).grid(row=4,column=1,sticky='w',pady=8)
        def forget():
            path=current.get()
            def work():
                if management_role.status(path).get('alive'):
                    raise ValueError('Stop the current role and verify before clearing this selection')
            def cleared(_):
                (self.directory/'last-isolated-role.json').unlink(missing_ok=True)
                self.isolated_role_path=None; current.set('')
                self.local_prepare_button.configure(state='normal')
                say('Role selection cleared. All saved state remains; no files or deployments were removed.')
            submit(work,cleared)
        ttk.Button(form,text='Clear stopped role selection (keep evidence)',command=forget).grid(row=5,column=1,sticky='w',pady=8)
        say('Preparation never moves an existing controller. Use a separate authorized management host with independently protected credentials.')
        if join:
            book.select(tabs['3 Join agent'])

    def _management_path_row(self, form, row, label, variable):
        self.ttk.Label(form,text=label).grid(row=row,column=0,sticky='w',padx=(0,14),pady=7)
        self.ttk.Entry(form,textvariable=variable).grid(row=row,column=1,sticky='ew',pady=7)
        self.ttk.Button(form,text='Browse',command=lambda:self._browse(variable)).grid(row=row,column=2,padx=8)
        form.columnconfigure(1,weight=1)
