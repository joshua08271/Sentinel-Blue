"""Deadline-aware initial provisioning of an explicitly inventoried network."""

from __future__ import annotations

import argparse
import hashlib
import ipaddress
import json
import math
import os
import re
import stat
import sys
import time
import uuid
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from contextlib import contextmanager
from dataclasses import asdict
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from . import __version__
from .event_profile import EventProfile, load_event_profile
from .json_codec import canonical_json_bytes
from .job_control import SetupPaused
from .launcher import load_inventory
from .probes import run_probe
from .setup_recipes import compile_recipe, compile_commit
from .setup_transactions import commands as transaction_commands, bind as bind_transaction
from .setup_transport import CommandResult, SetupTransport
from .state import read_private_json, write_private_json


PLAN_VERSION = 1
# Scheduling-loop pause poll (2.0.9); mutation boundaries are always checked.
PAUSE_POLL_SECONDS = 2.0
ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,95}$")
TERMINAL = {"ready", "failed", "uncertain", "blocked", "deadline", "reboot-required", "changed", "paused",
            "not-selected"}


def _identifier(value: Any, label: str) -> str:
    if not isinstance(value, str) or not ID.fullmatch(value):
        raise ValueError(f"{label} requires a simple identifier")
    return value


def _seconds(value: Any, label: str, maximum: int = 1800) -> float:
    if type(value) not in {int, float} or not math.isfinite(value) or not 0 < value <= maximum:
        raise ValueError(f"{label} must be positive and at most {maximum} seconds")
    return float(value)


def plan_digest(plan: dict) -> str:
    return hashlib.sha256(canonical_json_bytes(plan, max_bytes=32 * 1024 * 1024)).hexdigest()


def compile_hosts(inventory: dict, profile: EventProfile, root: Path) -> dict:
    """Validate explicit management targets independently of provisioning inputs."""
    from .runtime_environment import host_python
    from .control_plane import validate_inventory
    validate_inventory(inventory, profile)
    profile.assert_inventory_networks(inventory.get("authorized_networks", []))
    hosts = {}
    addresses = set()
    for source in inventory.get("hosts", []):
        if not isinstance(source, dict):
            raise ValueError("invalid setup host")
        name = _identifier(source.get("name"), "host name")
        address = str(ipaddress.ip_address(source.get("address")))
        if name in hosts or address in addresses:
            raise ValueError("setup host names and addresses must be unique")
        addresses.add(address)
        profile.assert_target(address)
        platform = source.get("platform")
        route = source.get("transport")
        if platform not in {"linux", "windows"}:
            raise ValueError(f"setup adapter required for host {name}: {platform}")
        if route not in {"local", "ssh", "winrm"}:
            raise ValueError(f"setup adapter required for host {name}: {route}")
        profile.assert_route(route)
        if route == "local" and not ipaddress.ip_address(address).is_loopback:
            raise ValueError("local setup requires a loopback target")
        if route == "ssh" and platform != "linux" or route == "winrm" and platform != "windows":
            raise ValueError("setup transport/platform mismatch")
        host = {key: source[key] for key in (
            "name", "address", "platform", "transport", "agent_id", "username", "key_file",
            "known_hosts_file", "accept_new_host_key", "credential_file", "port", "sudo",
        ) if key in source}
        for boolean in ("sudo", "accept_new_host_key"):
            if boolean in host and type(host[boolean]) is not bool:
                raise ValueError(f"host {boolean} must be a boolean")
        if host.get("accept_new_host_key"):
            raise ValueError("setup requires an already verified SSH host key")
        for field in ("key_file", "known_hosts_file", "credential_file"):
            if host.get(field):
                path = Path(host[field]).expanduser()
                host[field] = str(path if path.is_absolute() else (root / path).absolute())
        if platform == "linux":
            host["python"] = host_python(source)
        host["address"] = address
        hosts[name] = host
    if not hosts or len(hosts) > 64:
        raise ValueError("setup requires 1 to 64 explicitly inventoried hosts")
    return hosts


def compile_plan(inventory: dict, profile: EventProfile, root: Path) -> dict:
    """Compile literal scripts and bind every task/probe to the reviewed profile."""
    profile.assert_inventory_networks(inventory.get("authorized_networks", []))
    setup = inventory.get("setup")
    if not isinstance(setup, dict) or set(setup) - {"budget_seconds", "max_parallel_hosts", "tasks"}:
        raise ValueError("inventory requires a setup object with tasks")
    budget = _seconds(setup.get("budget_seconds", 1800), "setup budget")
    workers = setup.get("max_parallel_hosts", 4)
    if type(workers) is not int or not 1 <= workers <= 16:
        raise ValueError("max_parallel_hosts must be from 1 to 16")
    hosts = compile_hosts(inventory, profile, root)
    raw_tasks = setup.get("tasks")
    if not isinstance(raw_tasks, list) or not raw_tasks or len(raw_tasks) > 256:
        raise ValueError("setup requires 1 to 256 tasks")
    tasks = {}
    covered = set()
    manifest_keys = {(m["host"], m["service_id"]) for m in profile.services}
    for row in raw_tasks:
        if not isinstance(row, dict) or set(row) - {
            "id", "host", "requires", "recipe", "options", "service_id", "estimate_seconds",
            "timeout_seconds", "health_wait_seconds",
        }:
            raise ValueError("invalid setup task fields")
        task_id = _identifier(row.get("id"), "task id")
        if task_id in tasks:
            raise ValueError("duplicate setup task id")
        if row.get("host") not in hosts:
            raise ValueError(f"unknown setup host for {task_id}")
        host = hosts[row["host"]]
        requires = row.get("requires", [])
        if not isinstance(requires, list) or len(requires) > 256 or len(set(requires)) != len(requires):
            raise ValueError("requires must contain unique task ids")
        requires = [_identifier(x, "dependency") for x in requires]
        recipe = row.get("recipe")
        options = row.get("options", {})
        from .runtime_environment import target_runtime
        with target_runtime(host.get('python')):
            check, apply, rollback = compile_recipe(recipe, options, root, host["platform"])
            probes = []
            service_key = None
            if row.get("service_id"):
                if recipe in {"linux-packages", "windows-features", "windows-python"}:
                    raise ValueError("package/feature installation cannot establish service readiness")
                matches = [m for m in profile.services if m["service_id"] == row["service_id"]
                           and m["host"] in {host["address"], host.get("agent_id")}]
                if len(matches) != 1:
                    raise ValueError(f"task {task_id} requires an unambiguous approved service manifest")
                manifest = matches[0]
                service_key = [manifest["host"], manifest["service_id"]]
                key = tuple(service_key)
                if key in covered:
                    raise ValueError("a service can have only one final setup task")
                covered.add(key)
                if recipe in {"linux-service", "windows-service"} and options.get("service") != manifest["service_id"]:
                    raise ValueError("native setup service must match its approved manifest")
                native_app = {'linux-nginx': 'nginx', 'windows-iis': 'W3SVC'}.get(recipe)
                native_ids = {native_app, 'nginx.service'} if recipe == 'linux-nginx' else {native_app}
                if native_app is not None and manifest['service_id'] not in native_ids:
                    raise ValueError('Application setup must match its native service manifest')
                if recipe == 'linux-service-pack':
                    # The catalog knows which unit this pack configures; it must be
                    # the unit the approved manifest names, not a second service.
                    from .linux_service_catalog import entry as catalog_entry
                    unit = catalog_entry(options.get('catalog_id', ''))['unit']
                    if manifest['service_id'] not in {unit, unit + '.service'}:
                        raise ValueError(
                            f'This service pack configures {unit}, which is not the approved '
                            f'manifest service {manifest["service_id"]}')
                if recipe in {'linux-nginx', 'linux-service-pack'}:
                    from .service_ports import validate_manifest_ports
                    catalog_id = 'nginx' if recipe == 'linux-nginx' else options.get('catalog_id')
                    validate_manifest_ports(catalog_id, options, manifest, host)
                probes = json.loads(json.dumps(manifest["expected_transactions"]))
                for probe in probes:
                    if probe.get("kind") not in {"http", "https", "tcp", "tls", "dns", "transaction", "ftp", "banner", "smtp",
                                                 "icmp", "ssh-login", "smb", "mysql", "postgres", "dns-update"}:
                        raise ValueError("setup requires a real supported application/transport probe")
                    target = probe.get("host", probe.get("target", ""))
                    if probe.get("kind") in {"http", "https"}:
                        target = urlparse(probe.get("target", "")).hostname
                    # Literal endpoints remain reachable before event DNS is built,
                    # avoid unbounded name resolution, and cannot redirect by DNS.
                    try:
                        address = str(ipaddress.ip_address(target))
                    except ValueError as exc:
                        raise ValueError("setup probe endpoints must be literal scoped IP addresses") from exc
                    profile.assert_target(address)
            if recipe == 'linux-router':
                if not service_key:
                    raise ValueError('Router setup requires a manifest and external verification probes')
                if manifest['service_id'] != 'sentinel-router-' + options['name']:
                    raise ValueError('Router manifest must identify its managed sentinel-router service')
                ports = {item['port'] for item in options.get('management', [])}
                if not any(probe.get('kind') in {'tcp', 'ssh-login'} and probe.get('target', probe.get('host')) == host['address']
                           and probe.get('port', 22 if probe.get('kind') == 'ssh-login' else None) in ports for probe in probes):
                    raise ValueError('Router setup requires a fresh management connection probe')
                if options.get('forward') or options.get('routes') or options.get('masquerade'):
                    if not any((urlparse(probe.get('target', '')).hostname if probe.get('kind') in {'http', 'https'}
                                else probe.get('host', probe.get('target'))) != host['address'] for probe in probes):
                        raise ValueError('Routing setup requires a declared downstream transaction probe')
            if probes and recipe == 'runbook' and rollback is None:
                raise ValueError('A service setup runbook requires an explicit reviewed rollback command')
            transaction = transaction_commands(recipe, options, root, apply, context={'run_id': hashlib.sha256(canonical_json_bytes(inventory, max_bytes=4*1024*1024)).hexdigest(), 'task_id': task_id, 'requires': requires})
            if transaction is not None:
                apply, rollback = transaction['apply'], transaction['rollback']
            tasks[task_id] = {
                "id": task_id, "host": row["host"], "requires": requires, "recipe": recipe,
                "configuration": json.loads(json.dumps(options)),
                "check": check, "apply": apply, "rollback": rollback, "probes": probes,
                "service_key": service_key,
                "estimate_seconds": _seconds(row.get("estimate_seconds", 120), "task estimate"),
                "timeout_seconds": _seconds(row.get("timeout_seconds", 600), "task timeout"),
                "health_wait_seconds": _seconds(row.get("health_wait_seconds", 60), "health wait", 300),
            }
            tasks[task_id]['owned_transaction'] = transaction is not None
            if transaction is not None:
                tasks[task_id]['admit'] = transaction['admit']
            if recipe == 'linux-router':
                from .route_verification import compile_paths
                tasks[task_id]['route_paths'] = compile_paths(options, probes, host['address'], profile)
            commit = transaction['commit'] if transaction is not None else compile_commit(recipe, options)
            if commit is not None:
                tasks[task_id]['commit'] = commit
                if recipe == 'linux-router' and tasks[task_id]['health_wait_seconds'] + 20 >= options.get('rollback_seconds', 120):
                    raise ValueError('Router rollback deadline must allow health checks and confirmation')
    order = []
    visiting = set()
    visited = set()

    def visit(name: str) -> None:
        if name not in tasks:
            raise ValueError(f"missing setup dependency: {name}")
        if name in visiting:
            raise ValueError("setup dependency cycle")
        if name in visited:
            return
        visiting.add(name)
        for dependency in tasks[name]["requires"]:
            visit(dependency)
        visiting.remove(name)
        visited.add(name)
        order.append(name)

    for task_id in tasks:
        visit(task_id)
    cost = {}
    host_cost = {name: 0.0 for name in hosts}
    for name in order:
        task = tasks[name]
        cost[name] = max((cost[x] for x in task["requires"]), default=0) + task["estimate_seconds"]
        host_cost[task["host"]] += task["estimate_seconds"]
    lower_bound = max(max(cost.values()), max(host_cost.values()), sum(host_cost.values()) / workers)
    from .json_codec import MAX_JSON_TOTAL_STRING_CHARS
    carried = sum(len(value) for task in tasks.values() for value in task.values() if isinstance(value, str))
    if carried > MAX_JSON_TOTAL_STRING_CHARS * 9 // 10:
        # Said here, with the remedy, rather than as a bare JSON error when the
        # plan is hashed for approval.
        raise ValueError(f"this setup plan carries {carried:,} characters of scripts, more than one reviewed plan "
                         f"can hold (about {MAX_JSON_TOTAL_STRING_CHARS * 9 // 10:,}); set up fewer services at once, "
                         "or adopt some instead of generating their configuration")
    return {
        "plan_version": PLAN_VERSION, "release_version": __version__,
        "profile_fingerprint": profile.fingerprint, "profile_id": profile.profile_id,
        "budget_seconds": budget, "max_parallel_hosts": workers,
        "estimated_lower_bound_seconds": round(lower_bound, 3),
        "estimate_within_budget": lower_bound <= budget,
        "hosts": hosts, "tasks": [tasks[x] for x in order],
        "uncovered_services": [list(x) for x in sorted(manifest_keys - covered)],
    }


def summarize_plan(plan: dict) -> dict:
    return {
        key: plan[key] for key in (
            "profile_id", "budget_seconds", "max_parallel_hosts", "estimated_lower_bound_seconds",
            "estimate_within_budget", "uncovered_services",
        )
    } | {
        "plan_sha256": plan_digest(plan),
        "tasks": [{"id": t["id"], "host": t["host"], "recipe": t["recipe"],
                   "requires": t["requires"], "service_key": t["service_key"],
                   "configuration": t.get('configuration', {}),
                   "timeout_seconds": t["timeout_seconds"],
                   "check_sha256": hashlib.sha256(t["check"].encode()).hexdigest(),
                   "apply_sha256": hashlib.sha256(t["apply"].encode()).hexdigest(),
                   "rollback_available": t["rollback"] is not None} for t in plan["tasks"]],
        "estimate_note": "Planning lower bound only; downloads, reboots, and observed host speed determine actual time.",
    }


@contextmanager
def _locked_state(directory: Path):
    directory = directory.absolute()
    for path in [directory, *directory.parents]:
        if path.is_symlink():
            raise ValueError("setup state cannot use symlink directories")
    guard = None
    if os.name == 'nt':
        # Python 3.13 mkdir(0700) adds the current user as a separate ACE.
        # Create with our native two-principal DACL so reopening can verify it.
        from .credential_vault import private_directory
        guard = private_directory(directory)
    else:
        directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    if os.name == "posix":
        details = directory.stat()
        if details.st_uid != os.geteuid() or details.st_mode & 0o077:
            raise ValueError("setup state directory must be owned by this user and private (0700)")
    path = directory / "setup.lock"
    descriptor = None
    try:
        descriptor = os.open(path, os.O_RDWR | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0), 0o600)
        if not stat.S_ISREG(os.fstat(descriptor).st_mode):
            raise ValueError("invalid setup state lock")
        if os.name == "posix":
            import fcntl
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        else:
            import msvcrt
            os.write(descriptor, b"0")
            os.lseek(descriptor, 0, os.SEEK_SET)
            msvcrt.locking(descriptor, msvcrt.LK_NBLCK, 1)
        yield directory / "setup-state.json"
    except BlockingIOError as exc:
        raise ValueError("another setup process owns this state directory") from exc
    finally:
        if descriptor is not None:
            os.close(descriptor)
        if guard is not None:
            guard.close()


class SetupRunner:
    def __init__(self, plan: dict, profile: EventProfile, *, transport=None, probe=None, progress=None,
                 on_host_ready=None, checkpoint=None):
        self.plan = plan
        self.profile = profile
        self.transport = transport or SetupTransport()
        self.probe = probe or run_probe
        self.progress = progress or (lambda _: None)
        self.on_host_ready = on_host_ready
        self.checkpoint = checkpoint or (lambda: None)
        self.pause_reason = ''
        self._next_pause_poll = 0.0
        self.started_monotonic = 0.0
        self.remaining_at_start = 0.0

    def remaining(self) -> float:
        return max(0.0, self.remaining_at_start - (time.monotonic() - self.started_monotonic))

    def paused(self):
        # 2.0.9: the scheduling loop polls at most every PAUSE_POLL_SECONDS and
        # stops polling once paused. Task admission and every pre-apply
        # checkpoint remain unthrottled, so each mutation boundary is checked
        # fresh; a redo worker no longer signs ~4 controller requests a second.
        if self.pause_reason:
            return True
        now = time.monotonic()
        if now < self._next_pause_poll:
            return False
        self._next_pause_poll = now + PAUSE_POLL_SECONDS
        try:
            self.checkpoint()
        except SetupPaused as exc:
            self.pause_reason = str(exc)
        return bool(self.pause_reason)

    def _command(self, host: dict, script: str, seconds: float) -> CommandResult:
        return self.transport.execute(host, script, min(seconds, self.remaining()))

    def _healthy(self, task: dict, host: dict, seconds: float) -> tuple[bool, list[dict]]:
        deadline = time.monotonic() + min(seconds, self.remaining())
        if seconds <= 0 or self.remaining() <= 0:
            return False, [{"kind": "deadline", "healthy": False}]
        feature_query = (task.get("recipe") == "windows-features" and
                         host.get("platform") == "windows")
        # ServerManager can need more than thirty continuous seconds on a
        # small Windows host. Two fresh thirty-second processes repeat its
        # startup cost. Use the same sixty-second total allowance continuously,
        # sharing it with any retry after an early uncertain return.
        native_deadline = min(deadline, time.monotonic() + (60 if feature_query else 30))
        result = self._command(host, task["check"], max(0, native_deadline - time.monotonic()))
        attempts = 1
        available = min(self.remaining(), native_deadline - time.monotonic())
        # Only this compiler-owned read may retry, once, inside its original
        # native allowance and the original caller deadline. Mutations do not.
        if result.uncertain and feature_query and available >= 0.25:
            result = self._command(host, task["check"], available)
            attempts += 1
        if time.monotonic() >= native_deadline:
            return False, [{"kind": "native-check", "healthy": False,
                            "returncode": result.returncode, "uncertain": True, "attempts": attempts},
                           {"kind": "deadline", "healthy": False}]
        if result.uncertain or result.returncode != 0:
            return False, [{"kind": "native-check", "healthy": False, "returncode": result.returncode,
                            "uncertain": result.uncertain, "attempts": attempts}]
        checks = ([{"kind": "native-check", "healthy": True, "attempts": attempts,
                    "retried_read_only_query": True}] if attempts > 1 else [])
        for index, source in enumerate(task["probes"]):
            available = min(self.remaining(), deadline - time.monotonic())
            if available < 0.25:
                return False, checks + [{"kind": "deadline", "healthy": False}]
            spec = dict(source)
            spec["timeout"] = min(float(spec.get("timeout", 3)), 3, available)
            if str(index) in task.get('route_paths', {}):
                from .route_verification import verify
                checks.append(verify(self, task, host, index, spec, deadline))
                continue
            probe = self.probe(spec, list(self.profile.authorized_networks),
                               authorized_hosts=self.profile.authorized_hosts,
                               excluded_hosts=self.profile.excluded_hosts)
            checks.append({"kind": spec["kind"], "healthy": probe.healthy,
                           "latency_ms": probe.latency_ms})
        if time.monotonic() >= deadline or self.remaining() <= 0:
            return False, checks + [{"kind": "deadline", "healthy": False}]
        return all(x["healthy"] for x in checks), checks

    def _recheck(self, selected: list[dict]) -> dict[str, tuple[bool, list[dict]]]:
        """Check independent hosts concurrently, with one command per host."""
        groups: dict[str, list[dict]] = {}
        for task in selected:
            groups.setdefault(task["host"], []).append(task)

        def check_host(tasks):
            results = {}
            for task in tasks:
                try:
                    results[task["id"]] = self._healthy(
                        task, self.plan["hosts"][task["host"]], self.remaining())
                except Exception as exc:
                    results[task["id"]] = (False, [{"kind": "check-error", "healthy": False,
                                                   "error": type(exc).__name__}])
            return results

        results = {}
        with ThreadPoolExecutor(max_workers=self.plan["max_parallel_hosts"]) as pool:
            futures = [pool.submit(check_host, tasks) for tasks in groups.values()]
            for future in futures:
                results.update(future.result())
        return results

    def _task(self, task: dict) -> dict:
        task = dict(task)
        transaction_id = task.get('transaction_id') or uuid.uuid4().hex
        if task.get('owned_transaction'):
            for phase in ('admit', 'apply', 'rollback', 'commit'):
                task[phase] = bind_transaction(task[phase], transaction_id, redo=getattr(self, 'redo', False))
        try:
            self.checkpoint()
            result = self._task_transaction(task)
            if task.get('owned_transaction'):
                result['transaction_id'] = transaction_id
            return result
        except SetupPaused as exc:
            # Checkpoints precede mutation admission. Once admitted, one task
            # finishes verification and any owned rollback without interruption.
            # A refusal here pauses the whole run at once, not at the next poll.
            self.pause_reason = self.pause_reason or str(exc)
            return {'status': 'paused', 'changed': False, 'reason': str(exc)}

    def _task_transaction(self, task: dict) -> dict:
        started = time.monotonic()
        host = self.plan["hosts"][task["host"]]
        limit = min(task["timeout_seconds"], self.remaining())
        if limit <= 0:
            return {"status": "deadline", "changed": False, "seconds": 0}
        if task.get('admit'):
            admitted = self._command(host, task['admit'], min(10, limit))
            if admitted.uncertain or admitted.returncode != 0:
                return {'status': 'uncertain', 'changed': False, 'admission': asdict(admitted),
                        'reason': 'an earlier owned transaction or unavailable admission check requires reconciliation'}
        healthy, checks = self._healthy(task, host, limit)
        initial_check_seconds = time.monotonic() - started
        if healthy:
            if task.get('commit') and not task.get('owned_transaction'):
                self.checkpoint()
                confirmed, checks = self._healthy(task, host, min(limit, self.remaining()))
                if not confirmed:
                    return {'status': 'failed', 'changed': False, 'checks': checks,
                            'reason': 'router confirmation lost fresh external health'}
                committed = self._command(host, task['commit'], min(20, self.remaining()))
                if committed.uncertain or committed.returncode != 0:
                    return {'status': 'uncertain' if committed.uncertain else 'failed', 'changed': False,
                            'commit': asdict(committed), 'reason': 'router confirmation did not complete'}
            return {"status": "ready", "changed": False, "seconds": time.monotonic() - started,
                    "checks": checks, "already_ready": True,
                    "initial_check_seconds": initial_check_seconds}
        if any(check.get('uncertain') is True for check in checks):
            # A timed-out read is not evidence that provisioning is needed.
            # Keep the host held rather than starting a potentially expensive
            # install after the readiness query and its bounded retry failed.
            return {"status": "uncertain", "changed": False,
                    "seconds": time.monotonic() - started,
                    "initial_check_seconds": initial_check_seconds, "checks": checks,
                    "reason": "initial readiness check did not complete; no setup mutation started"}
        from .mutation_tracking import active
        if active() and not task.get('owned_transaction') and task['recipe'] != 'linux-router':
            return {'status': 'held', 'changed': False, 'checks': checks,
                    'reason': 'This recipe has no exact durable mutation/rollback contract; apply is held for human review'}
        available = min(limit - (time.monotonic() - started), self.remaining())
        # Keep recovery time inside the original task and overall deadlines.
        # An uncertain apply is held for reconciliation and is never replayed.
        reserve = min(90, available / 4) if task['rollback'] else 0
        operation_deadline = time.monotonic() + available - reserve
        available -= reserve
        if available <= 0:
            return {"status": "deadline", "changed": False, "seconds": time.monotonic() - started}
        self.checkpoint()
        applied = self._command(host, task["apply"], available)
        record = {"changed": True, "apply": asdict(applied),
                  "initial_check_seconds": initial_check_seconds}
        if applied.uncertain:
            return record | {"status": "uncertain", "seconds": time.monotonic() - started,
                             "reason": "mutation completion is unknown; do not replay automatically"}
        if applied.returncode == 30:
            return record | {"status": "reboot-required", "seconds": time.monotonic() - started}
        if applied.returncode != 0:
            recovered = self._rollback(task, host, record, reserve)
            return record | {"status": "failed" if recovered else "uncertain", "seconds": time.monotonic() - started,
                             "reason": "setup command failed; inspect the reviewed runbook on the host"}
        grace_end = min(operation_deadline, time.monotonic() + task["health_wait_seconds"])
        health_started = time.monotonic()
        # Installed packages/features are persistent state. One fresh native
        # verification suffices; scored services still require two observations.
        observations = 1 if task["recipe"] in {"linux-packages", "windows-features", "windows-python"} else 2
        consecutive = 0
        while time.monotonic() < grace_end and self.remaining() > 0:
            try:
                healthy, checks = self._healthy(task, host, grace_end - time.monotonic())
            except Exception as exc:
                healthy, checks = False, [{'kind': 'verification-error', 'healthy': False, 'error_type': type(exc).__name__}]
            consecutive = consecutive + 1 if healthy else 0
            if consecutive >= observations:
                if task.get('commit'):
                    committed = self._command(host, task['commit'], min(20, self.remaining()))
                    record['commit'] = asdict(committed)
                    if committed.uncertain or committed.returncode != 0:
                        return record | {'status': 'uncertain',
                                         'reason': 'setup confirmation failed; reconcile the retained transaction before further changes'}
                return record | {"status": "ready", "seconds": time.monotonic() - started, "checks": checks,
                                 "health_check_seconds": time.monotonic() - health_started}
            time.sleep(min(0.5, max(0, grace_end - time.monotonic()), self.remaining()))
        recovered = self._rollback(task, host, record, reserve)
        return record | {"status": "uncertain" if not recovered else "deadline" if self.remaining() <= 0 else "failed",
                         "seconds": time.monotonic() - started, "checks": checks,
                         "reason": "required health checks did not stabilize"}

    def _rollback(self, task, host, record, reserve):
        if not task['rollback']:
            record['rollback_status'] = 'not-available'
            return True  # Package/feature prerequisites have no service probes.
        if self.remaining() <= 0:
            record['rollback_status'] = 'unconfirmed'
            return False
        try:
            result = self._command(host, task['rollback'], min(90, max(reserve, 0.25), self.remaining()))
            record['rollback'] = asdict(result)
            confirmed = not result.uncertain and result.returncode == 0
        except Exception as exc:
            record['rollback_error_type'] = type(exc).__name__
            confirmed = False
        record['rollback_status'] = 'completed' if confirmed else 'unconfirmed'
        return confirmed

    def _chosen_tasks(self, only_services) -> set[str] | None:
        """The approved tasks for these (host, service) pairs, and what they require.

        A setup redo (2.0.6) runs only the services repair could not fix, so an
        unrelated task of the approved plan is neither re-attempted nor able to
        fail the redo. The plan itself, and its approved digest, are unchanged.
        """
        if only_services is None:
            return None
        if (not isinstance(only_services, (list, tuple)) or not only_services or len(only_services) > 256
                or any(not isinstance(pair, (list, tuple)) or len(pair) != 2
                       or not all(isinstance(value, str) and value for value in pair) for pair in only_services)):
            raise ValueError("only_services must list 1 to 256 [host, service] pairs")
        wanted = {(host, service) for host, service in only_services}
        by_id = {task["id"]: task for task in self.plan["tasks"]}
        def matches(task):
            key = task.get("service_key")
            if not key:
                return False
            host = self.plan["hosts"].get(task["host"], {})
            return any((name, key[1]) in wanted for name in (key[0], task["host"], host.get("address"),
                                                             host.get("agent_id")) if name)
        stack = [name for name, task in by_id.items() if matches(task)]
        if not stack:
            raise ValueError("none of the requested services has a setup task in the approved plan")
        chosen: set[str] = set()
        while stack:
            name = stack.pop()
            if name not in chosen:
                chosen.add(name)
                stack.extend(by_id[name]["requires"])
        return chosen

    def execute(self, state_dir: Path, approved_digest: str, *, resume: bool = False,
                started_at: float | None = None, only_services=None, redo: bool = False) -> dict:
        if type(redo) is not bool or (redo and (resume or self.on_host_ready is not None)):
            raise ValueError("a setup redo is a fresh run of setup tasks only")
        # A redo may replace a file its approved step owns in any state (see
        # setup_linux_transaction.preflight_apply); a first setup never does.
        self.redo = redo
        if resume and self.on_host_ready is not None:
            raise ValueError("host completion mutations cannot be replayed through setup resume")
        if resume and only_services is not None:
            raise ValueError("a partial setup run is started fresh, never resumed")
        digest = plan_digest(self.plan)
        if digest != approved_digest or self.plan["profile_fingerprint"] != self.profile.fingerprint:
            raise ValueError("setup plan changed or does not match the approved profile/digest")
        chosen = self._chosen_tasks(only_services)
        if chosen is not None and self.on_host_ready is not None:
            raise ValueError("a partial setup run cannot complete hosts")
        if not self.profile.allows("initial_provisioning"):
            raise ValueError("event profile must explicitly permit initial_provisioning")
        with _locked_state(state_dir) as state_path:
            if isinstance(self.transport, SetupTransport):
                self.transport.log_dir = state_path.parent / "private-command-output"
            now = time.time()
            if started_at is not None and (type(started_at) not in {int, float} or
                                          not math.isfinite(started_at) or not 0 < started_at <= now):
                raise ValueError("setup start time must be a finite timestamp no later than now")
            if state_path.exists():
                if not resume:
                    raise ValueError("setup state already exists; use --resume to retain its original deadline")
                state = read_private_json(state_path)
                if state.get('pause_reason'):
                    raise ValueError('Paused setup requires review and a new plan; automatic resume is refused')
                if state.get("plan_sha256") != digest:
                    raise ValueError("existing setup state belongs to another plan")
                if started_at is not None and started_at != state.get("started_at"):
                    raise ValueError("resume cannot change the original start time")
                if set(state.get("tasks", {})) != {t["id"] for t in self.plan["tasks"]}:
                    raise ValueError("setup state task inventory is inconsistent")
                if type(state.get("last_wall_time")) not in {int, float} or now < state["last_wall_time"] - 0.5:
                    raise ValueError("clock moved backwards; review the setup deadline")
                if not math.isfinite(state.get("started_at", float("nan"))) or state["started_at"] > now:
                    raise ValueError("invalid setup start time")
                expected_deadline = state["started_at"] + self.plan["budget_seconds"]
                if state.get("deadline_at") != expected_deadline:
                    raise ValueError("persisted setup deadline was changed")
                for row in state["tasks"].values():
                    if row.get("status") == "running":
                        row.update(status="uncertain", reason="previous process ended during this task")
                    elif row.get("status") == "blocked" and row.get("changed") is False:
                        row.update(status="pending")
                    elif row.get("status") not in TERMINAL | {"pending"}:
                        raise ValueError("invalid persisted setup task status")
            else:
                if resume:
                    raise ValueError("no setup state exists to resume")
                initial_time = now if started_at is None else started_at
                state = {"plan_sha256": digest, "started_at": initial_time,
                         "deadline_at": initial_time + self.plan["budget_seconds"], "last_wall_time": now,
                         "tasks": {t["id"]: {"status": "pending"} if chosen is None or t["id"] in chosen else
                                   {"status": "not-selected", "changed": False,
                                    "reason": "this run covers only the services it was started for"}
                                   for t in self.plan["tasks"]}}
                if chosen is not None:
                    state["only_services"] = sorted([list(pair) for pair in only_services])
            self.remaining_at_start = max(0, state["deadline_at"] - now)
            self.started_monotonic = time.monotonic()

            def persist():
                state["last_wall_time"] = time.time()
                write_private_json(state_path, state)
                from .recording import emit
                emit('setup_progress', state)

            persist()
            host_results = {}
            host_preflight_seconds = {}
            def preflight_host(host):
                started = time.monotonic()
                try:
                    result = self.transport.preflight(host, min(20, self.remaining()))
                    healthy = result.returncode == 0 and not result.uncertain
                except Exception:
                    healthy = False
                return healthy, round(time.monotonic() - started, 3)
            state["host_preflight"] = host_results
            # Completed stages are rechecked on resume; drift never silently
            # grants permission to repeat an earlier mutation.
            if resume:
                with ThreadPoolExecutor(max_workers=self.plan["max_parallel_hosts"]) as pool:
                    futures = {pool.submit(preflight_host, host): name
                               for name, host in self.plan["hosts"].items()}
                    for future, name in futures.items():
                        host_results[name], host_preflight_seconds[name] = future.result()
                ready = [t for t in self.plan["tasks"] if state["tasks"][t["id"]]["status"] == "ready"]
                for name, (healthy, checks) in self._recheck(ready).items():
                    if not healthy:
                        state["tasks"][name].update(status="changed", checks=checks)
            persist()
            tasks = {t["id"]: t for t in self.plan["tasks"]}
            unsafe_hosts = {tasks[name]["host"] for name, row in state["tasks"].items()
                            if row["status"] in {"uncertain", "reboot-required"}}
            pending = {name for name, row in state["tasks"].items() if row["status"] == "pending"}
            active = {}
            preflights = {}
            completions = {}
            completed_hosts = {}
            state["host_completions"] = completed_hosts
            untested_hosts = [] if resume else [
                name for name in self.plan["hosts"]
                if chosen is None or any(task["host"] == name and task["id"] in chosen for task in self.plan["tasks"])]
            busy = set()
            def complete_host(name):
                started = time.monotonic()
                # Every task already passed native and transaction checks. Final
                # checks still run after deployment; repeating all probes here
                # would add another serialized round to the opening clock.
                if self.remaining() <= 0:
                    return {"status": "deadline"}
                self.checkpoint()
                value = self.on_host_ready(name, self.remaining())
                if not isinstance(value, dict) or value.get("status") != "completed":
                    return {"status": "uncertain", "result": value}
                if self.remaining() <= 0:
                    return {"status": "deadline", "result": value}
                return {**value, "seconds": round(time.monotonic() - started, 3)}
            with ThreadPoolExecutor(max_workers=self.plan["max_parallel_hosts"]) as pool:
                while pending or active or preflights or untested_hosts or completions or (
                        self.on_host_ready is not None and len(completed_hosts) < len(self.plan["hosts"])):
                    if self.paused() and not state.get('pause_reason'):
                        state['pause_reason'] = self.pause_reason
                        for name in pending:
                            state['tasks'][name] = {'status': 'paused', 'changed': False, 'reason': self.pause_reason}
                        pending.clear()
                        for host in untested_hosts:
                            host_results[host] = False
                        untested_hosts.clear()
                        if self.on_host_ready is not None:
                            for host in self.plan['hosts']:
                                if host not in completed_hosts:
                                    completed_hosts[host] = {'status': 'paused'}
                        persist()
                    if self.on_host_ready is not None:
                        for host in self.plan["hosts"]:
                            if host in completed_hosts or host in busy or host not in host_results:
                                continue
                            rows = [state["tasks"][name] for name, task in tasks.items() if task["host"] == host]
                            if (not host_results[host] or host in unsafe_hosts or self.remaining() <= 0 or
                                    any(row["status"] in TERMINAL - {"ready"} for row in rows)):
                                completed_hosts[host] = {"status": "blocked"}
                                persist()
                            elif (all(row["status"] == "ready" for row in rows) and
                                  len(active) + len(preflights) + len(completions) < self.plan["max_parallel_hosts"]):
                                completed_hosts[host] = {"status": "running"}
                                persist()  # durable BEFORE the deployment may mutate
                                busy.add(host)
                                completions[pool.submit(complete_host, host)] = host
                    for name in list(tasks):
                        if name not in pending:
                            continue
                        task = tasks[name]
                        host = task["host"]
                        dependency_status = [state["tasks"][x]["status"] for x in task["requires"]]
                        reason = None
                        status = "blocked"
                        if self.remaining() <= 0:
                            status, reason = "deadline", "original setup deadline exhausted"
                        elif host in host_results and not host_results[host]:
                            reason = "management access is unavailable; host was not changed"
                        elif host in unsafe_hosts:
                            reason = "another task on this host has an uncertain outcome or requires reboot"
                        elif any(x in TERMINAL - {"ready"} for x in dependency_status):
                            reason = "a required setup dependency did not become ready"
                        if reason:
                            state["tasks"][name] = {"status": status, "reason": reason, "changed": False}
                            pending.remove(name)
                            persist()
                            continue
                        if (host not in host_results or host in busy or
                                len(active) + len(preflights) + len(completions) >= self.plan["max_parallel_hosts"] or
                                any(x != "ready" for x in dependency_status)):
                            continue
                        pending.remove(name)
                        busy.add(host)
                        transaction_id = uuid.uuid4().hex
                        state["tasks"][name] = {"status": "running", "started_at": time.time(), 'transaction_id': transaction_id}
                        persist()  # durable BEFORE a worker may mutate the host
                        self.progress({"task": name, "status": "running", "remaining_seconds": round(self.remaining(), 1)})
                        active[pool.submit(self._task, dict(task, transaction_id=transaction_id))] = name
                    # Give an already reachable host its first task immediately;
                    # a slow login on another host never creates a global barrier.
                    while untested_hosts and len(active) + len(preflights) + len(completions) < self.plan["max_parallel_hosts"]:
                        host = untested_hosts.pop(0)
                        if self.remaining() <= 0:
                            host_results[host] = False
                            continue
                        preflights[pool.submit(preflight_host, self.plan["hosts"][host])] = host
                    if active or preflights or completions:
                        finished, _ = wait([*active, *preflights, *completions], timeout=0.25, return_when=FIRST_COMPLETED)
                        for future in finished:
                            if future in completions:
                                host = completions.pop(future)
                                busy.remove(host)
                                try:
                                    completed_hosts[host] = future.result()
                                except Exception as exc:
                                    completed_hosts[host] = {"status": "uncertain", "error": type(exc).__name__}
                                if completed_hosts[host]["status"] != "completed":
                                    unsafe_hosts.add(host)
                                persist()
                                continue
                            if future in preflights:
                                host = preflights.pop(future)
                                host_results[host], host_preflight_seconds[host] = future.result()
                                persist()
                                continue
                            name = active.pop(future)
                            busy.remove(tasks[name]["host"])
                            try:
                                result = future.result()
                            except Exception as exc:
                                result = {"status": "uncertain", "reason": "task raised " + type(exc).__name__}
                            result.setdefault('transaction_id', state['tasks'][name]['transaction_id'])
                            state["tasks"][name] = result
                            if result["status"] in {"uncertain", "reboot-required"}:
                                unsafe_hosts.add(tasks[name]["host"])
                            persist()
                            self.progress({"task": name, "status": result["status"], "remaining_seconds": round(self.remaining(), 1)})
                    elif pending:
                        raise RuntimeError("setup scheduler could not advance a validated dependency graph")
            # Revalidate all scored endpoints after the last mutation. Early
            # success cannot hide a service broken by a later setup stage.
            final_started = time.monotonic()
            selected = [t for t in self.plan["tasks"]
                        if t["service_key"] and state["tasks"][t["id"]]["status"] == "ready" and not self.paused()]
            for name, (healthy, checks) in self._recheck(selected).items():
                row = state["tasks"][name]
                row["final_checks"] = checks
                if not healthy:
                    row["status"] = "deadline" if self.remaining() <= 0 else "changed"
            final_check_seconds = time.monotonic() - final_started
            elapsed = now - state["started_at"] + (time.monotonic() - self.started_monotonic)
            all_ready = all(row["status"] == "ready" for name, row in state["tasks"].items()
                            if chosen is None or name in chosen)
            completion_ready = self.on_host_ready is None or (
                len(completed_hosts) == len(self.plan["hosts"]) and
                all(row["status"] == "completed" for row in completed_hosts.values()))
            paused = self.paused()
            complete = not paused and all_ready and completion_ready and not self.plan["uncovered_services"] and elapsed < self.plan["budget_seconds"]
            report = {
                "version": __version__, "status": "paused" if paused else "ready" if complete else "incomplete",
                "plan_sha256": digest, "profile_id": self.profile.profile_id,
                "elapsed_seconds": round(elapsed, 3), "budget_seconds": self.plan["budget_seconds"],
                "under_30_minutes": complete and elapsed < 1800,
                "under_3_minutes": complete and elapsed < 180,
                "all_declared_services_ready": all_ready and not self.plan["uncovered_services"],
                "uncovered_services": self.plan["uncovered_services"],
                "tasks_ready": sum(row["status"] == "ready" for row in state["tasks"].values()),
                "task_count": len(state["tasks"]), "tasks": state["tasks"],
                "host_preflight": host_results,
                "host_completions": completed_hosts,
                "host_preflight_seconds": host_preflight_seconds,
                "final_check_seconds": round(final_check_seconds, 3),
                "full_competition_readiness_proven": False,
                "clock_scope": "management preflight, provisioning, health checks, and time between resumptions; inventory preparation excluded",
            }
            if chosen is not None:
                report.update(only_services=state["only_services"], selected_tasks=sorted(chosen),
                              task_count=len(chosen),
                              tasks_ready=sum(state["tasks"][name]["status"] == "ready" for name in chosen))
            if paused:
                state['pause_reason'] = self.pause_reason
                report.update(pause_reason=self.pause_reason, automatic_resume=False)
            state["last_report"] = report
            persist()
            from .recording import emit
            emit('setup_result', report)
            return report


def run(args: argparse.Namespace) -> int:
    root = Path(args.inventory).absolute().parent
    inventory = load_inventory(args.inventory)
    profile = load_event_profile(args.event_profile or args.inventory)
    plan = compile_plan(inventory, profile, root)
    if args.plan_out:
        write_private_json(args.plan_out, plan)
    if not args.execute:
        print(json.dumps(summarize_plan(plan), indent=2))
        return 0
    profile.require_runtime_ready(range_deployment=args.range_deployment)
    profile.verify_release_file(sys.argv[0])
    if not args.approve_plan or not args.state_dir:
        raise ValueError("--execute requires --approve-plan SHA256 and --state-dir")
    runner = SetupRunner(plan, profile, progress=lambda row: print(json.dumps(row), file=sys.stderr, flush=True))
    report = runner.execute(Path(args.state_dir), args.approve_plan, resume=args.resume,
                            started_at=args.started_at)
    if args.output:
        write_private_json(args.output, report)
    print(json.dumps(report, indent=2))
    return 0 if report["status"] == "ready" else 2
