"""Explainable defensive detections and recommendation generation."""

from __future__ import annotations

import hashlib
import re
from typing import Any

from .protocol import AlertCandidate
from .process_identity import validate_process_identity
from .risk import RiskModel
from .validation import ModelBoundAlertCandidate


# The default agent interval, and half the default 90-second staleness window.
COLLECTION_PRESSURE_SECONDS = 15.0
COLLECTION_PRESSURE_CRITICAL_SECONDS = 45.0

# Host headroom. A filesystem under 10% free is heading for trouble; under 3%
# writes are already failing on most configurations. The absolute floor keeps a
# very large volume from alerting while it still holds tens of gigabytes.
CAPACITY_LOW_FRACTION = 0.10
CAPACITY_CRITICAL_FRACTION = 0.03
CAPACITY_AMPLE_FREE_BYTES = 8 * 1024**3
MEMORY_LOW_FRACTION = 0.10
MEMORY_CRITICAL_FRACTION = 0.03


def _is_builtin_privileged(account: dict[str, Any], platform_name: str) -> bool:
    """Recognize built-ins by identity; a familiar spelling is not evidence."""
    name = str(account.get("name", ""))
    identity = str(account.get("account_id", ""))
    system = platform_name.casefold()
    if name == "root" and identity == "0" and not system.startswith("windows"):
        return True
    return (
        name.casefold() == "administrator"
        and not system.startswith("linux")
        and re.fullmatch(r"S-1-5-21-\d+-\d+-\d+-500", identity, flags=re.IGNORECASE) is not None
    )


def _confidence(model: RiskModel, features: dict[str, float], floor: float = 0.5) -> float:
    return round(max(floor, min(0.99, model.predict(features))), 3)


def detect(
    telemetry: dict[str, Any],
    baseline: dict[str, Any] | None,
    protected_accounts: set[str],
    model: RiskModel | None = None,
    *,
    identity_guards: list[dict] | None = None,
    persistence_policy: dict | None = None,
) -> list[AlertCandidate]:
    model = model or RiskModel()
    candidates: list[AlertCandidate] = []
    from .identity_guard import analyze_protected_access
    candidates.extend(analyze_protected_access(telemetry, protected_accounts, identity_guards or [], model))
    from .persistence_security import analyze_persistence_trust
    candidates.extend(analyze_persistence_trust(telemetry, persistence_policy, model))
    from .analyzers import analyze_all
    baseline_accounts = {
        account.get("name", "").casefold(): account
        for account in (baseline or {}).get("accounts", [])
    }
    current_accounts = {
        account.get("name", "").casefold(): account for account in telemetry.get("accounts", [])
    }

    platform_name = str(telemetry.get("platform", ""))
    variants: dict[str, set[tuple[str, str]]] = {}
    for account in telemetry.get("accounts", []):
        name = str(account.get("name", ""))
        variants.setdefault(name.casefold(), set()).add((name, str(account.get("account_id", ""))))

    # Retain every row. Linux names that differ only by case must not overwrite
    # one another or inherit a protected-name exemption through case folding.
    for account in telemetry.get("accounts", []):
        normalized = str(account.get("name", "")).casefold()
        ambiguous_identity = len(variants.get(normalized, ())) > 1
        if not account.get("privileged"):
            identifier = str(account.get("account_id", ""))
            login_candidate = bool(account.get("enabled") and account.get("source", "local") == "local" and
                                   (platform_name.lower().startswith("windows") or
                                    (identifier.isdigit() and int(identifier) > 0)))
            if login_candidate and (normalized not in protected_accounts or ambiguous_identity):
                features = {"protected_identity": float(ambiguous_identity)}
                candidates.append(ModelBoundAlertCandidate(
                    kind="unverified_login_account", title="Login-capable account requires identity review",
                    summary=f"{account.get('name', 'unknown')} is not bound to the approved account inventory.",
                    severity="high" if ambiguous_identity else "medium", confidence=0.7,
                    model_features=features,
                    evidence={"account": account, "baseline_independent": True,
                              "new_since_baseline": normalized not in baseline_accounts,
                              "identity_ambiguous": ambiguous_identity},
                    recommendation="Check the event account roster and native UID/SID. An unfamiliar account is not by itself evidence of red-team ownership; preserve required service identities.",
                    recommended_action="snapshot"))
            continue
        if normalized in protected_accounts and not ambiguous_identity:
            continue
        is_builtin = _is_builtin_privileged(account, platform_name)
        is_new = normalized not in baseline_accounts
        # Built-in root/Administrator accounts are expected to exist. Their
        # interactive use is reviewed separately, where source and session
        # evidence are available.
        if is_builtin and not ambiguous_identity:
            continue
        features = {
            "unknown_privileged_account": 1.0,
            "new_privileged_account": 1.0 if is_new else 0.0,
            "protected_identity": 0.0,
        }
        confidence = _confidence(model, features, 0.68)
        candidates.append(
            ModelBoundAlertCandidate(
                kind="unverified_privileged_account",
                title="Unverified privileged account",
                summary=(
                    f"{account.get('name', 'unknown')} has root/Administrator-equivalent "
                    "access and requires identity verification."
                ),
                severity="high",
                confidence=confidence,
                model_features=features,
                evidence={
                    "account": account,
                    "new_since_baseline": is_new,
                    "identity_ambiguous": ambiguous_identity,
                    "identity_variants": [
                        {"name": name, "account_id": identity}
                        for name, identity in sorted(variants[normalized])
                    ] if ambiguous_identity else [],
                    "reported_enabled": account.get("enabled", True),
                },
                recommendation=(
                    "Verify the identity against the event account list. Existing baseline "
                    "membership and a disabled login do not establish trust. Until verified, "
                    "observe or quarantine only its interactive session; do not disable "
                    "service processes or the account itself."
                ),
                recommended_action="snapshot",
            )
        )

    for session in telemetry.get("sessions", []):
        normalized = session.get("username", "").casefold()
        if not session.get("interactive", True) or not session.get("privileged"):
            continue
        if normalized in protected_accounts:
            continue
        source = session.get("source", "unknown")
        external = source not in {"", "local", "localhost", "127.0.0.1", "::1", "unknown"}
        indicators: list[str] = []
        if external:
            indicators.append("external_interactive_origin")
        account = current_accounts.get(normalized, {})
        if account and normalized not in baseline_accounts and not _is_builtin_privileged(account, platform_name):
            indicators.append("new_unverified_privileged_account")
        for event in telemetry.get("security_events", []):
            category = str(event.get("category", "")).casefold()
            event_account = str(event.get("account", "")).casefold()
            event_remote = str(event.get("remote_address", "unknown"))
            if event_account != normalized:
                continue
            if category == "auth_success" and external and event_remote == source:
                indicators.append("matching_external_authentication")
            elif category in {"account_created", "privilege_change"}:
                indicators.append(f"security_event_{category}")
        indicators = list(dict.fromkeys(indicators))
        try:
            identity = validate_process_identity(session.get("process_identity"))
            identity_supported = identity["process_id"] == session.get("process_id")
        except ValueError:
            identity_supported = False
        restriction_supported = len(indicators) >= 2 and identity_supported
        features = {
            "interactive_privileged_session": 1.0,
            "external_source": 1.0 if external else 0.0,
            "protected_identity": 0.0,
        }
        candidates.append(
            ModelBoundAlertCandidate(
                kind="unverified_privileged_session",
                title="Privileged interactive session needs verification",
                summary=f"{session.get('username', 'unknown')} opened a privileged session from {source}.",
                severity="critical" if external else "high",
                confidence=_confidence(model, features, 0.72),
                model_features=features,
                evidence={
                    "session": session,
                    "behavioral_indicators": indicators,
                    "restriction_threshold": 2,
                    "restriction_supported": restriction_supported,
                    "process_identity_supported": identity_supported,
                },
                recommendation=(
                    "Review the account, source, and session activity. "
                    + (
                        "Multiple independent indicators support an approved, session-scoped "
                        "quarantine while preserving services."
                        if restriction_supported
                        else (
                            "Do not restrict the session until immutable process identity is "
                            "available and another independent behavioral indicator corroborates it."
                        )
                    )
                ),
                recommended_action="quarantine_session" if restriction_supported else "snapshot",
            )
        )

    if baseline:
        baseline_running = {
            service.get("name", ""): service
            for service in baseline.get("services", [])
            if service.get("state") == "running"
        }
        current_services = {
            service.get("name", ""): service for service in telemetry.get("services", [])
        }
        for name, prior in baseline_running.items():
            current = current_services.get(name)
            if current and current.get("state") == "running":
                continue
            features = {"critical_service_stopped": 1.0}
            candidates.append(
                ModelBoundAlertCandidate(
                    kind="baseline_service_stopped",
                    title="Baseline service is not running",
                    summary=f"Service {name} was running in the baseline and is now unavailable.",
                    severity="high",
                    confidence=_confidence(model, features, 0.8),
                    model_features=features,
                    evidence={"service": name, "baseline": prior, "current": current},
                    recommendation=(
                        "Validate the service dependency chain and scoring reachability, then "
                        "approve a snapshot and service-specific recovery action."
                    ),
                    recommended_action="restart_service",
                )
            )

        baseline_integrity = {
            item.get("path", ""): item for item in baseline.get("integrity", []) if item.get("path")
        }
        current_integrity = {
            item.get("path", ""): item for item in telemetry.get("integrity", []) if item.get("path")
        }
        for path, previous in baseline_integrity.items():
            current = current_integrity.get(path)
            content_changed = current is None or current.get("sha256") != previous.get("sha256")
            baseline_security_digest = previous.get("security_descriptor_sha256", "")
            observed_security_digest = (
                current.get("security_descriptor_sha256", "") if current else None
            )
            security_metadata_changed = current is None or (
                observed_security_digest != baseline_security_digest
            )
            if not content_changed and not security_metadata_changed:
                continue
            change_types = []
            if content_changed:
                change_types.append("content")
            if security_metadata_changed:
                change_types.append("security_metadata")
            security_baseline_upgrade = bool(
                current and not baseline_security_digest and observed_security_digest
            )
            security_observation_unverified = bool(current and baseline_security_digest
                                                   and not observed_security_digest)
            observation_material = "\x00".join(
                (
                    str(current.get("sha256", "")) if current else "__missing__",
                    str(observed_security_digest or "__missing__"),
                )
            )
            features = {"integrity_change": 1.0}
            candidates.append(
                ModelBoundAlertCandidate(
                    kind="critical_file_changed",
                    title="Security-critical file changed",
                    summary=(
                        f"{path} is missing from telemetry."
                        if current is None
                        else (
                            f"{path} security metadata requires explicit baseline approval."
                            if security_baseline_upgrade and not content_changed
                            else f"{path} no longer matches the approved host baseline."
                        )
                    ),
                    severity="critical",
                    confidence=_confidence(model, features, 0.86),
                    model_features=features,
                    evidence={
                        "path": path,
                        "baseline": previous,
                        "current": current,
                        "baseline_sha256": previous.get("sha256"),
                        "observed_sha256": current.get("sha256") if current else None,
                        "baseline_security_descriptor_sha256": baseline_security_digest,
                        "observed_security_descriptor_sha256": observed_security_digest,
                        "observed_missing": current is None,
                        "security_metadata_changed": security_metadata_changed,
                        "security_baseline_upgrade": security_baseline_upgrade,
                        "security_observation_unverified": security_observation_unverified,
                        "change_types": change_types,
                        "change_observation_sha256": hashlib.sha256(
                            observation_material.encode("utf-8")
                        ).hexdigest(),
                    },
                    recommendation=(
                        "Preserve the changed file for evidence, restore only from the locally "
                        "verified approved restore point, and revalidate scored services."
                    ),
                    recommended_action=("snapshot" if security_baseline_upgrade or security_observation_unverified
                                        else "restore_integrity"),
                )
            )

        def default_routes(source: dict[str, Any]) -> set[tuple[str, str, str]]:
            return {
                (
                    str(route.get("destination", "")),
                    str(route.get("gateway", "")),
                    str(route.get("interface", "")),
                )
                for route in source.get("routes", [])
                if route.get("destination") in {"default", "0.0.0.0/0", "::/0"}
            }

        old_defaults = default_routes(baseline)
        new_defaults = default_routes(telemetry)
        if old_defaults and new_defaults != old_defaults:
            features = {"default_route_change": 1.0}
            candidates.append(
                ModelBoundAlertCandidate(
                    kind="default_route_changed",
                    title="Default route changed",
                    summary="The host default gateway or egress interface differs from its baseline.",
                    severity="critical",
                    confidence=_confidence(model, features, 0.85),
                    model_features=features,
                    evidence={"baseline": sorted(old_defaults), "current": sorted(new_defaults)},
                    recommendation=(
                        "Confirm the change against the competition topology before restoring the "
                        "previous route. An incorrect automatic route rollback can disconnect scoring."
                    ),
                    recommended_action="snapshot",
                )
            )

        old_listeners = {
            (str(item.get("protocol", "tcp")), str(item.get("address", "")), int(item.get("port", 0)))
            for item in baseline.get("listeners", [])
            if item.get("port")
        }
        for item in telemetry.get("listeners", []):
            key = (
                str(item.get("protocol", "tcp")),
                str(item.get("address", "")),
                int(item.get("port", 0)),
            )
            if not key[2] or key in old_listeners:
                continue
            features = {"new_listener": 1.0}
            candidates.append(
                ModelBoundAlertCandidate(
                    kind="new_network_listener",
                    title="New listening service",
                    summary=f"A new {key[0]} listener appeared on {key[1]}:{key[2]}.",
                    severity="medium",
                    confidence=_confidence(model, features, 0.58),
                    model_features=features,
                    evidence={"listener": item},
                    recommendation="Identify the owning process and verify that the listener is required.",
                    recommended_action="observe",
                )
            )

    for probe in telemetry.get("probes", [])[:1024]:
        # A check that could not be attempted is reported above as missing
        # evidence; calling it a failed probe would say the service is down.
        if not isinstance(probe, dict) or probe.get("healthy", False) or probe.get("executed") is False:
            continue
        features = {"probe_failure": 1.0}
        candidates.append(
            ModelBoundAlertCandidate(
                kind="service_probe_failed",
                title="Service health probe failed",
                summary=f"{probe.get('name', 'service')} failed its validation check.",
                severity="critical",
                confidence=_confidence(model, features, 0.88),
                model_features=features,
                evidence={"probe": probe},
                recommendation=(
                    "Check the local service, dependencies, firewall path, and credentials before "
                    "approving service-specific recovery."
                ),
                recommended_action="snapshot",
            )
        )

    # A collection that takes longer than the agent's own interval cannot keep
    # its schedule, and one approaching the staleness window leaves recovery
    # deciding on evidence that is about to expire (issue #22). Report the
    # pressure while it is still only pressure.
    collection_seconds = telemetry.get("collection_seconds")
    if isinstance(collection_seconds, (int, float)) and collection_seconds >= COLLECTION_PRESSURE_SECONDS:
        severe = collection_seconds >= COLLECTION_PRESSURE_CRITICAL_SECONDS
        features = {"collector_failure": 1.0}
        candidates.append(
            ModelBoundAlertCandidate(
                kind="collection_pressure",
                title="Host collection is slower than its schedule",
                summary=(
                    f"Collecting this observation took {collection_seconds:.1f}s, which is "
                    + ("over half the freshness window; recovery may act on stale evidence or be held."
                       if severe else
                       "longer than the default collection interval, so observations fall behind.")
                ),
                severity="high" if severe else "medium",
                confidence=_confidence(model, features, 0.6),
                model_features=features,
                evidence={"collection_seconds": collection_seconds,
                          "interval_reference_seconds": COLLECTION_PRESSURE_SECONDS,
                          "freshness_reference_seconds": COLLECTION_PRESSURE_CRITICAL_SECONDS * 2},
                recommendation=(
                    "Review host load and collection coverage before relying on automatic recovery; "
                    "reduce protected paths or inventory scope if the host cannot keep up."
                ),
                recommended_action="observe",
            )
        )

    # A filesystem with no room, no inodes, or a host with no memory headroom
    # stops services, corrupts writes and defeats restarts. The agent now
    # observes this instead of leaving it to be inferred from a service's exit.
    for row in telemetry.get("filesystems", [])[:64]:
        if not isinstance(row, dict):
            continue
        mount = str(row.get("mount_point", "unknown"))[:512]
        for kind, total_field, free_field, unit in (
            ("space", "total_bytes", "free_bytes", "space"),
            ("inodes", "total_inodes", "free_inodes", "inodes"),
        ):
            total, free = row.get(total_field), row.get(free_field)
            if not isinstance(total, int) or not isinstance(free, int) or total <= 0:
                continue
            fraction = free / total
            if fraction > CAPACITY_LOW_FRACTION:
                continue
            severe = fraction <= CAPACITY_CRITICAL_FRACTION
            # A very large volume can sit under the percentage and still hold
            # plenty; an absolute floor keeps that from crying wolf.
            if kind == "space" and free >= CAPACITY_AMPLE_FREE_BYTES:
                continue
            features = {"collector_failure": 1.0}
            candidates.append(
                ModelBoundAlertCandidate(
                    kind="host_capacity_low",
                    title=f"Filesystem {mount} is nearly out of {unit}",
                    summary=(
                        f"{mount} has {fraction * 100:.1f}% of its {unit} free"
                        + ("; writes are failing or about to fail, which stops services "
                           "and defeats restarts." if severe else
                           ", which will stop services if it keeps falling.")
                    ),
                    severity="high" if severe else "medium",
                    confidence=_confidence(model, features, 0.65 if severe else 0.55),
                    model_features=features,
                    evidence={"mount_point": mount, "measure": kind, "free": free,
                              "total": total, "free_fraction": round(fraction, 4),
                              "read_only": bool(row.get("read_only", False))},
                    recommendation=(
                        "Identify and clear what is consuming the filesystem before restarting "
                        "services on it. Rotating or truncating logs is usually reversible; "
                        "deleting evidence is not."
                    ),
                    recommended_action="observe",
                )
            )
    memory = telemetry.get("memory")
    if isinstance(memory, dict):
        total, available = memory.get("total_bytes"), memory.get("available_bytes")
        if isinstance(total, int) and isinstance(available, int) and total > 0:
            fraction = available / total
            if fraction <= MEMORY_LOW_FRACTION:
                severe = fraction <= MEMORY_CRITICAL_FRACTION
                features = {"collector_failure": 1.0}
                candidates.append(
                    ModelBoundAlertCandidate(
                        kind="host_memory_pressure",
                        title="Host memory headroom is low",
                        summary=(
                            f"{fraction * 100:.1f}% of host memory is available"
                            + ("; the kernel is likely to kill a service before a restart can help."
                               if severe else ", so a memory spike may stop a service.")
                        ),
                        severity="high" if severe else "medium",
                        confidence=_confidence(model, features, 0.65 if severe else 0.55),
                        model_features=features,
                        evidence={"available_bytes": available, "total_bytes": total,
                                  "available_fraction": round(fraction, 4),
                                  "swap_free_bytes": memory.get("swap_free_bytes", 0),
                                  "swap_total_bytes": memory.get("swap_total_bytes", 0)},
                        recommendation=(
                            "Find what is consuming memory before restarting anything; a restart "
                            "into the same pressure is killed again."
                        ),
                        recommended_action="observe",
                    )
                )

    # A scored transaction that could not be attempted is missing evidence, not a
    # failing service. It is reported on its own so it is never mistaken for one.
    unattempted = [row for row in telemetry.get("probes", [])[:1024]
                   if isinstance(row, dict) and row.get("executed") is False]
    if unattempted:
        names = ", ".join(sorted({str(row.get("name", "unnamed"))[:64] for row in unattempted})[:8])
        features = {"collector_failure": 1.0}
        candidates.append(
            ModelBoundAlertCandidate(
                kind="scoring_check_unavailable",
                title="A scored transaction cannot be checked on this host",
                summary=(
                    f"{len(unattempted)} declared transaction(s) could not be attempted: {names}. "
                    "These services are unverified, not known to be down."
                ),
                severity="high",
                confidence=_confidence(model, features, 0.7),
                model_features=features,
                evidence={"transactions": [
                    {"name": str(row.get("name", ""))[:256], "detail": str(row.get("detail", ""))[:300]}
                    for row in unattempted[:8]]},
                recommendation=(
                    "Install the named scoring client on this host, or change the transaction to "
                    "one this host can perform. Until then these services carry no evidence, and "
                    "automatic recovery will not act on them."
                ),
                recommended_action="observe",
            )
        )

    diagnostics = list(telemetry.get("collector_errors") or [])
    provenance = telemetry.get("collector_issue_sources")
    backups = []
    if isinstance(provenance, list) and len(provenance) == len(diagnostics):
        backups = [error for error, source in zip(diagnostics, provenance) if source == "restore_points"]
        diagnostics = [error for error, source in zip(diagnostics, provenance) if source != "restore_points"]
    from .restore_health import evidence as restore_evidence
    restore_health = restore_evidence(telemetry)
    lost = sorted(restore_health['lost'])
    rebuilt = sorted(restore_health['rebuilt'])
    authority_lost = restore_health['authority'] != 'available' or not restore_health['complete']
    if backups or lost or rebuilt or authority_lost:
        features = {"collector_failure": 1.0}
        candidates.append(
            ModelBoundAlertCandidate(
                kind="restore_point_deleted",
                title="Sentinel restoration capability requires attention",
                summary=(("Authenticated restore metadata/coverage is unavailable; file restoration is held. " if authority_lost else "")
                         + f"Backups of {len(lost) + len(rebuilt)} approved file(s) changed availability. "
                         + (f"{len(rebuilt)} rebuilt from verified backup or baseline-matching bytes. " if rebuilt else "")
                         + (f"{len(lost)} cannot be restored by repair: {', '.join(lost[:4])}"
                            + (" …" if len(lost) > 4 else "") + "." if lost else "")).strip(),
                severity="high" if lost or authority_lost else "medium",
                confidence=_confidence(model, features, 0.9),
                model_features=features,
                evidence={"lost": lost, "rebuilt": rebuilt, "authority": restore_health["authority"],
                          "complete": restore_health["complete"]},
                recommendation=(
                    "Restore-point content or metadata is unavailable. Investigate the loss before approving changes. A lost "
                    "restore point is rebuilt automatically once its file matches the approved baseline "
                    "again: a setup redo rewrites files that setup itself writes (a pack's generated "
                    "configuration); a file Sentinel only adopted has to be put back by hand. Until then "
                    "repair cannot restore that file, and it is not offered."
                ),
                recommended_action="observe",
            )
        )

    if diagnostics:
        features = {"collector_failure": 1.0}
        candidates.append(
            ModelBoundAlertCandidate(
                kind="telemetry_degraded",
                title="Telemetry collection is incomplete",
                summary="One or more host collectors failed; conclusions may be incomplete.",
                severity="medium",
                confidence=_confidence(model, features, 0.55),
                model_features=features,
                evidence={"errors": diagnostics},
                recommendation="Inspect collector errors before approving a disruptive response.",
                recommended_action="observe",
            )
        )

    candidates.extend(analyze_all(telemetry, baseline, protected_accounts, model))

    return candidates


def lost_restore_points(telemetry: dict[str, Any]) -> set[str]:
    """Complete bounded identities, never shortened display diagnostics."""
    from .restore_health import evidence
    return set(evidence(telemetry)['lost'])
