"""Local, bounded, read-only range evidence. Never authority for actions or learning.

Each committed event survives a process crash. Portable ZIPs contain JSON only;
SHA-256 chains detect damage, not a privileged adversary replacing all evidence.
"""
from __future__ import annotations

import atexit
import base64
import contextlib
import errno
import hashlib
import json
import logging
import math
import os
import re
import shutil
import sqlite3
import sys
import threading
import time
import uuid
import zipfile
from pathlib import Path

from . import __version__
from .credential_vault import private_directory
from .state import _fsync_directory, _replace_with_retry

FORMAT = 'sentinel-blue-recording-v1'
MAX_EVENT = 256 * 1024
MAX_TOTAL = 512 * 1024 * 1024
MAX_EVENTS = 250000
CHUNK = 128 * 1024
ENV = 'SENTINEL_BLUE_RECORDING_DIRECTORY'
COVERAGE = {
    'mode': 'local structured evidence; no automatic external upload',
    'sources': ['agent observations before delivery', 'controller accepted observations',
                'action dispatch and results', 'operator decisions', 'setup results',
                'service probes', 'independent native audit and protected-file activity', 'external observer reports', 'collector errors', 'process heartbeat and lifecycle'],
    'limits': ['Only this recorder and connected agents are covered.',
               'Observations are sampled; changes between samples can be missed.',
               'Remote agent observations not delivered to the controller remain on that agent.',
               'No packet payloads, keystrokes, screen recording, arbitrary application logs, or raw command output.',
               'Secrets and unstructured strings are omitted. Structured host and service identities remain private.',
               'No observations while the machine is off or this component is stopped.',
               'Root/SYSTEM can alter evidence. Hashes are integrity checks, not trusted attestation.'],
    'maximum_event_bytes': MAX_EVENT, 'maximum_list_items': 1024,
    'heartbeat_seconds': 10, 'automatic_export_min_seconds': 60,
    'automatic_export_max_seconds': 900,
    'automatic_export_policy': 'Shared across components; interval adapts to the previous export duration. Journal commits remain immediate.',
}
# Strings are retained ONLY in known structured fields. Unknown messages and
# command output cannot accidentally turn a session export into a secret dump.
STRING_FIELDS = frozenset(('agent_id hostname platform agent_version profile_id profile_fingerprint '
    'boot_id payload_sha256 sha256 digest version release_sha256 session_id action_id alert_id '
    'name service service_id host state status kind type operation actor subject decision resolution '
    'action_type recommended_action autonomy_mode identity path source destination address ip network '
    'username protocol method process_name severity reason_code error_type component result_code '
    'event_id event_type rule_id category outcome native_state health collector code scope format '
    'principal_id record_id transaction_id approved_digest plan_sha256 mode role template_sha256 target '
    'previous_hash event_hash id startup_type executable architecture units '
    'start_mode substate result groups addresses gateway interface hardware_address process owner account '
    'remote_address account_id account_domain provider rules_sha256 security_descriptor_sha256 '
    'collector_issue_sources collector_issue_owners active_stage runtime_sha256 audit_type access_mask syscall classification observer_id check_id configuration_sha256 '
    'rollback_status rollback_error_type router in_interface out_interface').split())
SENSITIVE = re.compile(r'(?:password|passphrase|secret|token|credential|authorization|private.?key|signature|cookie|environment|command|cmdline|stdout|stderr|raw|content|message|reason|detail|error|output)', re.I)
SAFE_SPECIAL = {'error_type', 'reason_code', 'credential_epoch', 'collector_errors', 'detail', 'errors'}
PRIORITY_FIELDS = frozenset(('telemetry agent_id boot_id sequence observed_at collected_at '
    'probes collector_errors service_health action_id action result success stable_health rolled_back '
    'health state status kind version').split())


def _json(value):
    return json.dumps(value, ensure_ascii=True, allow_nan=False, sort_keys=True, separators=(',', ':')).encode('utf-8')


def _omitted(value, reason):
    # Do not export hashes of passwords, which could enable offline guessing.
    return {'omitted': reason, 'items': len(value) if isinstance(value, (list, dict, str, bytes)) else 1}


def sanitize(value, field='', depth=0, budget=None):
    if budget is None:
        budget = [12000]
    budget[0] -= 1
    if depth > 12 or budget[0] < 0:
        return _omitted(value, 'structure_limit')
    if SENSITIVE.search(field) and field not in SAFE_SPECIAL:
        return _omitted(value, 'sensitive_field')
    if value is None or type(value) in (bool, int):
        return value
    if type(value) is float:
        return value if math.isfinite(value) else {'omitted': 'nonfinite_number'}
    if isinstance(value, str):
        if field not in STRING_FIELDS:
            return _omitted(value, 'unstructured_text')
        # Identifier fields also exclude common credential-bearing forms.
        if len(value) > 512 or any(ord(c) < 32 for c in value) or re.search(
                r'(?i)(?:bearer\s|-----BEGIN|://[^/\s]+@|(?:password|token|secret|sig)=|[?&][^=]+=)', value):
            return _omitted(value, 'unsafe_identifier')
        return value
    if isinstance(value, dict):
        result = {}
        # Large inventories must not consume the node budget before health and
        # action outcomes are visited. Original order is retained within groups.
        ordered = sorted(value.items(), key=lambda item: item[0] not in PRIORITY_FIELDS)
        for i, (key, item) in enumerate(ordered):
            if i >= 1024 or budget[0] < 0:
                result['_recording_omitted_fields'] = len(value) - i
                break
            # Dynamic dictionary keys may themselves contain arbitrary text.
            name = str(key)
            if not re.fullmatch(r'[A-Za-z0-9_.:/@ -]{1,160}', name) or SENSITIVE.search(name) and name not in SAFE_SPECIAL:
                name = '_omitted_field_' + str(i)
                result[name] = _omitted(item, 'sensitive_field')
            else:
                result[name] = sanitize(item, name, depth + 1, budget)
        return result
    if isinstance(value, (list, tuple)):
        result = [sanitize(x, field, depth + 1, budget) for x in value[:1024]]
        if len(value) > 1024:
            result.append({'omitted': 'list_limit', 'items': len(value) - 1024})
        return result
    return _omitted(value, 'unsupported_type')


def bounded_payload(value):
    """Retain bounded partial evidence instead of dropping a whole observation.

    First shorten the largest ordinary collection. Health/action collections
    are shortened only if ordinary inventory cannot make the event fit. Every
    removed tail carries a count; the result still obeys the event byte limit.
    """
    limit = MAX_EVENT - 2048
    while len(_json(value)) > limit:
        lists, mappings = [], []
        def visit(node, protected=False):
            if isinstance(node, list):
                if len(node) > 1:
                    lists.append((not protected, len(_json(node)), node))
                for item in node:
                    visit(item, protected)
            elif isinstance(node, dict):
                if len(node) > 1:
                    mappings.append((not protected, len(_json(node)), node))
                for key, item in node.items():
                    visit(item, protected or key in PRIORITY_FIELDS - {'telemetry'})
        visit(value)
        if lists:
            _, _, target = max(lists, key=lambda item: item[:2])
            omitted = 0
            if isinstance(target[-1], dict) and target[-1].get('omitted') == 'event_size_limit':
                omitted = target.pop()['items']
            keep = len(target) // 2
            omitted += len(target) - keep
            target[keep:] = [{'omitted': 'event_size_limit', 'items': omitted}]
        elif mappings:
            _, _, target = max(mappings, key=lambda item: item[:2])
            previous = target.pop('_recording_size_limit', {})
            keys = sorted(target, key=lambda key: key in PRIORITY_FIELDS)
            removed = max(1, len(keys)//2)
            for key in keys[:removed]:
                del target[key]
            target['_recording_size_limit'] = {
                'omitted': 'event_size_limit', 'items': previous.get('items', 0) + removed}
        else:
            # Sanitized leaves are at most 512 characters, so this only guards
            # unexpected future sanitizer types rather than normal telemetry.
            return {'omitted': 'event_size_limit', 'original_sanitized_bytes': len(_json(value))}
    return value


class ExportBusy(TimeoutError):
    """Another local component is currently publishing a recording snapshot."""


class Recorder:
    def __init__(self, directory, *, role='runtime', maximum_bytes=MAX_TOTAL,
                 maximum_events=MAX_EVENTS, free_floor=64*1024*1024, background=True):
        self.directory = Path(directory).absolute()
        self.guard = private_directory(self.directory)
        self.export_directory = self.directory / 'export-lock'
        self.export_guard = private_directory(self.export_directory)
        self.path = self.directory / 'sessions.sqlite3'
        if self.path.is_symlink() or self.path.exists() and self.path.stat().st_nlink != 1:
            raise ValueError('Recorder database must be a private regular file')
        self.lock = threading.RLock()
        self.export_lock = threading.Lock()
        self.role = role
        self.source = role + ':' + uuid.uuid4().hex
        self.runtime_sha256 = runtime_digest()
        self.maximum_bytes, self.maximum_events = int(maximum_bytes), int(maximum_events)
        self.free_floor = int(free_floor)
        if not 16384 <= self.maximum_bytes <= 2*1024**3 or not 4 <= self.maximum_events <= 1000000:
            raise ValueError('Invalid recorder capacity')
        self.errors = 0
        self.last_error = ''
        self.closed = False
        self.stop_event = threading.Event()
        self.export_requested = threading.Event()
        self.connection = sqlite3.connect(self.path, timeout=2.0, check_same_thread=False)
        self.connection.row_factory = sqlite3.Row
        if os.name == 'posix':
            self.path.chmod(0o600)
        self.connection.executescript('''
            PRAGMA journal_mode=WAL;
            PRAGMA synchronous=FULL;
            PRAGMA trusted_schema=OFF;
            PRAGMA wal_autocheckpoint=128;
            CREATE TABLE IF NOT EXISTS sessions(
                id TEXT PRIMARY KEY, started REAL NOT NULL, stopped REAL,
                events INTEGER NOT NULL DEFAULT 0, bytes INTEGER NOT NULL DEFAULT 0,
                dropped INTEGER NOT NULL DEFAULT 0, last_hash TEXT NOT NULL DEFAULT '',
                last_at REAL, export_seq INTEGER NOT NULL DEFAULT 0, export_stopped REAL);
            CREATE TABLE IF NOT EXISTS control(id INTEGER PRIMARY KEY CHECK(id=1), current TEXT);
            INSERT OR IGNORE INTO control(id,current) VALUES(1,NULL);
            CREATE TABLE IF NOT EXISTS events(
                session TEXT NOT NULL, sequence INTEGER NOT NULL, document BLOB NOT NULL,
                PRIMARY KEY(session,sequence));
            CREATE TABLE IF NOT EXISTS archived_sessions(
                session TEXT PRIMARY KEY, filename TEXT NOT NULL,
                sha256 TEXT NOT NULL, archived_at REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS snapshot_schedule(
                session TEXT PRIMARY KEY, finished REAL NOT NULL, duration REAL NOT NULL);
        ''')
        self.connection.execute('PRAGMA max_page_count=' + str((2*self.maximum_bytes+8*1024*1024)//4096))
        self.connection.commit()
        self.thread = None
        # A stopped session stays stopped after a component restart. Only an
        # explicit Start creates the next session; active sessions resume.
        if self.status().get('session_id') is None:
            self.start()
        self.emit('component_start', {'role': role, 'version': __version__,
                  'release_sha256': runtime_digest(), 'process_id': os.getpid()})
        if background:
            self.thread = threading.Thread(target=self._loop, name='sentinel-recording', daemon=True)
            self.thread.start()

    def _current(self):
        return self.connection.execute('SELECT s.* FROM sessions s JOIN control c ON c.current=s.id WHERE c.id=1').fetchone()

    def start(self):
        prior = self.status()
        archived = None
        if prior.get('state') == 'stopped':
            # A weekly session must not silently inherit a nearly full quota.
            # Finalize and verify the previous portable evidence before reusing
            # journal pages. A missing/corrupt export never authorizes deletion.
            path = self.export()
            manifest = inspect_bundle(path)
            with path.open('rb') as stream:
                digest = hashlib.file_digest(stream,'sha256').hexdigest()
            archived = (manifest, path.name, digest)
        with self.lock, self.connection:
            self.connection.execute('BEGIN IMMEDIATE')
            row = self._current()
            if row is not None and row['stopped'] is None:
                return self._status(row)
            if archived is not None:
                manifest, filename, digest = archived
                if (row is None or manifest['session_id'] != row['id'] or
                        manifest['events'] != row['events'] or manifest['last_hash'] != row['last_hash'] or
                        manifest['stopped_at'] != row['stopped']):
                    raise ValueError('Previous recording changed during archive verification')
                self.connection.execute('INSERT OR REPLACE INTO archived_sessions VALUES(?,?,?,?)',
                                        (row['id'], filename, digest, time.time()))
                self.connection.execute('DELETE FROM events WHERE session=?', (row['id'],))
            used = self.connection.execute('''SELECT COALESCE(SUM(bytes),0),COALESCE(SUM(events),0)
                FROM sessions WHERE id NOT IN (SELECT session FROM archived_sessions)''').fetchone()
            if used[0] >= self.maximum_bytes or used[1] >= self.maximum_events or shutil.disk_usage(self.directory).free < self.free_floor:
                raise OSError('Recorder storage is full; preserve and move previous recordings before starting a new recording directory')
            identifier = uuid.uuid4().hex
            self.connection.execute('INSERT INTO sessions(id,started) VALUES(?,?)', (identifier,time.time()))
            self.connection.execute('UPDATE control SET current=? WHERE id=1', (identifier,))
        self.emit('session_start', {'version': __version__, 'release_sha256': runtime_digest()})
        self.export_requested.set()
        return self.status()

    def _status(self, row):
        if row is None:
            return {'state':'not_started', 'session_id':None}
        result = {'session_id':row['id'], 'state':'stopped' if row['stopped'] is not None else 'recording',
                  'started_at':row['started'], 'stopped_at':row['stopped'], 'events':row['events'],
                  'recorded_bytes':row['bytes'], 'dropped_events':row['dropped'],
                  'last_event_at':row['last_at'], 'export_sequence':row['export_seq'],
                  'export_ready': row['stopped'] is not None and row['export_stopped'] == row['stopped'] and row['export_seq'] == row['events'],
                  'maximum_bytes':self.maximum_bytes, 'maximum_events':self.maximum_events,
                  'storage_errors_this_process':self.errors, 'last_error_type':self.last_error,
                  'export_name':f"Sentinel-Blue-recording-{row['id']}.zip"}
        if row['dropped'] or self.errors:
            result['coverage_degraded'] = True
        return result

    def status(self):
        with self.lock:
            result = self._status(self._current())
            result['archived_sessions'] = self.connection.execute('SELECT COUNT(*) FROM archived_sessions').fetchone()[0]
            schedule = self.connection.execute('SELECT finished,duration FROM snapshot_schedule WHERE session=?', (result.get('session_id'),)).fetchone()
            if schedule:
                result.update(last_export_at=schedule['finished'], last_export_seconds=schedule['duration'],
                    next_automatic_export_at=schedule['finished']+max(60,min(900,schedule['duration']*9)))
            return result

    def emit(self, kind, payload=None):
        if self.closed:
            return False
        try:
            clean = bounded_payload(sanitize(payload or {}))
            with self.lock, self.connection:
                # Stopped components need no writer lock while a new Start is
                # recycling pages from a large, verified previous recording.
                row = self._current()
                if row is None or row['stopped'] is not None:
                    return False
                self.connection.execute('BEGIN IMMEDIATE')
                row = self._current()
                if row is None or row['stopped'] is not None:
                    return False
                now = time.time()
                doc = {'session_id':row['id'], 'sequence':row['events']+1, 'at':now,
                       'monotonic':time.monotonic(), 'source':self.source, 'kind':str(kind)[:80],
                       'previous_hash':row['last_hash'], 'source_write_failures':self.errors,
                       'source_last_error_type':self.last_error, 'source_version':__version__,
                       'source_runtime_sha256':self.runtime_sha256, 'data':clean}
                body = _json(doc)
                doc['event_hash'] = hashlib.sha256(body).hexdigest()
                encoded = _json(doc) + b'\n'
                used = self.connection.execute('''SELECT SUM(bytes),SUM(events) FROM sessions
                    WHERE id NOT IN (SELECT session FROM archived_sessions)''').fetchone()
                physical = sum(p.stat().st_size for p in (self.path,Path(str(self.path)+'-wal')) if p.exists())
                if used[0] + len(encoded) > self.maximum_bytes or used[1] >= self.maximum_events or physical > 2*self.maximum_bytes+8*1024*1024 or shutil.disk_usage(self.directory).free < self.free_floor:
                    self.connection.execute('UPDATE sessions SET dropped=dropped+1 WHERE id=?', (row['id'],))
                    return False
                self.connection.execute('INSERT INTO events VALUES(?,?,?)', (row['id'], doc['sequence'], encoded))
                self.connection.execute('UPDATE sessions SET events=events+1,bytes=bytes+?,last_hash=?,last_at=? WHERE id=?',
                                        (len(encoded),doc['event_hash'],now,row['id']))
            return True
        except Exception as exc:
            self.errors += 1
            self.last_error = type(exc).__name__
            # Do not break defense if the independent evidence disk is full.
            # A process crash during failure may lose this in-memory counter.
            return False

    def stop(self):
        with self.lock:
            self.emit('session_stop', {'role':self.role})
            with self.connection:
                self.connection.execute('BEGIN IMMEDIATE')
                self.connection.execute('UPDATE sessions SET stopped=COALESCE(stopped,?) WHERE id=(SELECT current FROM control WHERE id=1)', (time.time(),))
        self.export_requested.set()
        return self.status()

    def _loop(self):
        next_export = 0.
        while not self.stop_event.wait(1):
            now = time.monotonic()
            if not hasattr(self, '_last_heartbeat') or now - self._last_heartbeat >= 10:
                self.emit('heartbeat', {'role':self.role, 'storage_errors':self.errors})
                self._last_heartbeat = now
            if self.export_requested.is_set() or now >= next_export:
                self.export_requested.clear()
                try:
                    if not self.status().get('export_ready'):
                        self.export(wait_seconds=0, automatic=True)
                    self.last_error = ''
                except ExportBusy:
                    self.export_requested.set()
                except Exception as exc:
                    self.errors += 1
                    self.last_error = type(exc).__name__
                # Schedule from completion, not the time before a potentially
                # slow export. Every process consults the same durable schedule.
                due = self.status().get('next_automatic_export_at', time.time()+60)
                next_export = time.monotonic()+max(1,min(900,due-time.time()))

    @contextlib.contextmanager
    def _export_lease(self, wait_seconds):
        from .state import AgentProcessLock
        lease = AgentProcessLock(self.export_directory)
        deadline = time.monotonic() + wait_seconds
        while True:
            try:
                lease.acquire()
                break
            except RuntimeError as exc:
                cause = exc.__cause__
                if not isinstance(cause, OSError) or cause.errno not in {errno.EACCES, errno.EAGAIN}:
                    raise
                if time.monotonic() >= deadline:
                    raise ExportBusy('Another component is saving this recording') from None
                time.sleep(.05)
        try:
            yield
        finally:
            lease.close()

    def export(self, *, wait_seconds=600, automatic=False):
        # Separate read transaction provides an exact consistent snapshot while
        # writers continue. It is bounded by session capacity, with one exporter.
        with self.export_lock, self._export_lease(wait_seconds):
            began = time.monotonic()
            with contextlib.closing(sqlite3.connect(self.path, timeout=1)) as reader:
                reader.row_factory = sqlite3.Row
                reader.execute('PRAGMA query_only=ON')
                reader.execute('BEGIN')
                row = reader.execute('SELECT s.* FROM sessions s JOIN control c ON c.current=s.id').fetchone()
                if row is None:
                    raise ValueError('No recording session')
                manifest = self._status(row)
                existing = self.directory / manifest['export_name']
                if manifest['export_ready'] and existing.is_file():
                    reader.rollback()
                    return existing
                if automatic and row['stopped'] is None and existing.is_file():
                    schedule = reader.execute('SELECT finished,duration FROM snapshot_schedule WHERE session=?', (row['id'],)).fetchone()
                    if schedule and 0 <= time.time()-schedule['finished'] < max(60,min(900,schedule['duration']*9)):
                        reader.rollback()
                        return existing
                if shutil.disk_usage(self.directory).free < self.free_floor + row['bytes']:
                    raise OSError('Insufficient space for an atomic evidence export')
                destination = self.directory / manifest['export_name']
                temporary = self.directory / ('.export-' + uuid.uuid4().hex + '.tmp')
                if destination.is_symlink():
                    raise ValueError('Export destination must not be a symlink')
                counts, sources, streams, omitted = {}, {}, {}, 0
                previous_hash, checked_events = '', 0
                whole = hashlib.sha256()
                try:
                    with open(temporary, 'xb') as handle:
                        if os.name == 'posix':
                            os.chmod(temporary,0o600)
                        with zipfile.ZipFile(handle,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as archive:
                            with archive.open('events.jsonl','w',force_zip64=True) as output:
                                for event in reader.execute('SELECT document FROM events WHERE session=? ORDER BY sequence',(row['id'],)):
                                    raw = bytes(event[0]); doc = json.loads(raw)
                                    claimed = doc.pop('event_hash'); checked_events += 1
                                    if doc['sequence'] != checked_events or doc['session_id'] != row['id'] or doc['previous_hash'] != previous_hash or hashlib.sha256(_json(doc)).hexdigest() != claimed:
                                        raise ValueError('Journal integrity failed; previous export retained')
                                    previous_hash = claimed
                                    doc['event_hash'] = claimed
                                    output.write(raw); whole.update(raw)
                                    counts[doc['kind']] = counts.get(doc['kind'],0)+1
                                    src = sources.setdefault(doc['source'],{'first_at':doc['at'],'last_at':doc['at'],'events':0,'longest_gap_seconds':0,'clean_component_stop':False,'clock_reversals':0,'write_failures':0})
                                    if 'source_version' in doc:
                                        src['version'] = doc['source_version']
                                        src['runtime_sha256'] = doc['source_runtime_sha256']
                                    src['longest_gap_seconds'] = max(src['longest_gap_seconds'],max(0,doc['at']-src['last_at']))
                                    src['write_failures'] = max(src['write_failures'],doc.get('source_write_failures',0))
                                    src['clock_reversals'] += int(doc['at'] < src['last_at'])
                                    src['last_at'] = doc['at']; src['events'] += 1
                                    src['clean_component_stop'] |= doc['kind'] == 'component_stop'
                                    if doc['kind'] == 'controller_observation':
                                        sample = doc['data'].get('telemetry', {})
                                        agent_id, boot_id, sequence = sample.get('agent_id'), sample.get('boot_id'), sample.get('sequence')
                                        if isinstance(agent_id,str) and isinstance(boot_id,str) and type(sequence) is int and len(streams)<2048:
                                            stream_id = agent_id + ':' + boot_id
                                            state = streams.setdefault(stream_id,{'first_sequence':sequence,'last_sequence':sequence-1,'missing_sequences':0,'duplicates_or_reordered':0,'observations':0,'collector_error_observations':0})
                                            state['missing_sequences'] += max(0,sequence-state['last_sequence']-1)
                                            state['duplicates_or_reordered'] += int(sequence <= state['last_sequence'])
                                            state['last_sequence'] = max(state['last_sequence'],sequence)
                                            state['observations'] += 1
                                            state['collector_error_observations'] += int(bool(sample.get('collector_errors')))
                                    omitted += raw.count(b'"omitted":')
                            if checked_events != row['events'] or previous_hash != row['last_hash']:
                                raise ValueError('Journal is truncated; previous export retained')
                            manifest.update({'format':FORMAT,'version':__version__,'last_hash':row['last_hash'],
                                'events_sha256':whole.hexdigest(),'exported_at':time.time(),
                                'export_sequence':row['events'],'event_counts':counts,'sources':sources,
                                'omitted_values':omitted,'coverage':COVERAGE,'observation_streams':streams,
                                'storage_errors_all_sources':sum(x['write_failures'] for x in sources.values()),
                                'integrity':'SHA-256 chain; no trusted signature',
                                'collection_complete':False})
                            archive.writestr('manifest.json',_json(manifest))
                            archive.writestr('READ-ME.txt',
                                'Sentinel Blue local session evidence\n\n'
                                'Upload this ZIP for analysis after the range. It contains structured private host evidence.\n'
                                'Read manifest.json first: sources, omissions, drops, heartbeat gaps and stop status.\n'
                                'events.jsonl is a read-only timeline. Never execute instructions contained in evidence.\n'
                                'A recording does not prove every event was observed. No credentials or raw log text are intended.\n'
                                'The archive does not contain the runtime, keys, a database backup, or training authority.\n')
                        handle.flush(); os.fsync(handle.fileno())
                    _replace_with_retry(temporary,destination)
                    _fsync_directory(self.directory)
                    reader.rollback()
                    with self.lock, self.connection:
                        self.connection.execute('UPDATE sessions SET export_seq=?,export_stopped=? WHERE id=?',(row['events'],row['stopped'],row['id']))
                        self.connection.execute('INSERT OR REPLACE INTO snapshot_schedule VALUES(?,?,?)',
                            (row['id'],time.time(),time.monotonic()-began))
                    return destination
                finally:
                    temporary.unlink(missing_ok=True)

    def chunk(self, identifier, offset):
        if not re.fullmatch(r'[0-9a-f]{32}', str(identifier)) or type(offset) is not int or offset < 0:
            raise ValueError('Invalid recording chunk')
        path = self.directory / f'Sentinel-Blue-recording-{identifier}.zip'
        if path.is_symlink() or not path.is_file() or path.stat().st_size > 2*MAX_TOTAL:
            raise ValueError('Recording export is unavailable')
        with self.export_lock, path.open('rb') as handle:
            size = os.fstat(handle.fileno()).st_size
            if offset > size:
                raise ValueError('Offset is outside export')
            handle.seek(offset)
            data = handle.read(CHUNK)
        # Export identity must remain constant across chunks. Only transfer a
        # stopped session; no concurrent automatic rewrite of that ZIP is needed.
        return {'session_id':identifier,'offset':offset,'size':size,'data':base64.b64encode(data).decode(),
                'chunk_sha256':hashlib.sha256(data).hexdigest()}

    def close(self):
        if self.closed:
            return
        self.emit('component_stop', {'role':self.role})
        self.stop_event.set()
        if self.thread:
            self.thread.join(timeout=15)
        if self.thread and self.thread.is_alive():
            # Leave the connection alive for the daemon rather than race close.
            return
        with contextlib.suppress(Exception):
            # Component exit must not recompress a shared active journal that
            # another component just saved. Explicit Stop still forces the end.
            self.export(automatic=True)
        with self.lock:
            self.closed = True
            self.connection.close()
        if self.guard:
            self.guard.close()
        if self.export_guard:
            self.export_guard.close()


def runtime_digest():
    path = Path(sys.argv[0])
    if path.is_file() and path.suffix == '.pyz':
        with path.open('rb') as handle:
            return hashlib.file_digest(handle,'sha256').hexdigest()
    return ''


_current = None
_startup_error = ''


def current():
    return _current


def emit(kind, payload=None):
    return _current.emit(kind,payload) if _current else False


def status():
    if _current:
        try:
            return _current.status()
        except Exception as exc:
            return {'state':'unavailable','last_error_type':type(exc).__name__}
    return {'state':'unavailable','last_error_type':_startup_error or 'not_initialized'}


class RecordingLogHandler(logging.Handler):
    def emit(self, record):
        # Store the static logging template (not interpolated arguments) only as
        # a fingerprint. The exception class and source location aid diagnosis.
        emit('runtime_log', {'component':record.name,'severity':record.levelname,
             'line':record.lineno,'template_sha256':hashlib.sha256(str(record.msg).encode()).hexdigest(),
             'error_type':record.exc_info[0].__name__ if record.exc_info else None})


def initialize(args):
    global _current, _startup_error
    if _current is not None:
        return _current
    role = args.command
    explicit = getattr(args,'recording_directory',None) or os.environ.get(ENV)
    if explicit:
        directory = Path(explicit)
    elif role == 'controller':
        directory = Path(args.database).absolute().parent / 'recordings'
    elif role == 'agent':
        directory = Path(args.state_dir).absolute() / 'recordings'
    elif role == 'desktop-worker':
        directory = Path(args.job).absolute().parent / 'recordings'
    else:
        directory = Path.home()/'.sentinel-blue-desktop'/'recordings'
    try:
        # mkdir(parents=True, mode=0700) only protects the final component.
        # Recording starts before the GUI and otherwise creates its parent
        # under the user's umask (often 0755), which the GUI correctly refuses.
        # Validate/create the shared root first; never chmod an existing unsafe
        # directory or weaken the vault's ownership checks.
        if not explicit and role not in {'controller', 'agent', 'desktop-worker'}:
            desktop_guard = private_directory(directory.parent)
            if desktop_guard is not None:
                desktop_guard.close()
        _current = Recorder(directory,role=role)
        os.environ[ENV] = str(directory)
        logging.getLogger().addHandler(RecordingLogHandler())
        atexit.register(_current.close)
        if getattr(args,'event_profile',None):
            from .event_profile import load_event_profile
            profile = load_event_profile(args.event_profile)
            emit('profile_binding',{'profile_id':profile.profile_id,'profile_fingerprint':profile.fingerprint,
                 'release_sha256':profile.release.get('sha256'), 'version':__version__})
        return _current
    except Exception as exc:
        _startup_error = type(exc).__name__
        logging.getLogger(__name__).error('Recording unavailable (%s); defense continues',_startup_error)
        return None


def inspect_bundle(path):
    """Bounded JSON inspection; never extract files, execute, restore or train."""
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        if 'session.json' in names:
            return _inspect_session(archive)
        if set(names) != {'manifest.json','events.jsonl','READ-ME.txt'} or len(names) != 3:
            raise ValueError('Unexpected or duplicate recording members')
        sizes = {x.filename:x.file_size for x in archive.infolist()}
        if sizes['manifest.json'] > 4*1024*1024 or sizes['events.jsonl'] > 2*MAX_TOTAL or sizes['READ-ME.txt'] > 16384:
            raise ValueError('Recording exceeds inspection limits')
        manifest = json.loads(archive.read('manifest.json'))
        if manifest.get('format') != FORMAT or type(manifest.get('events')) is not int or not 0<=manifest['events']<=1000000:
            raise ValueError('Invalid recording manifest')
        previous, count, whole = '', 0, hashlib.sha256()
        with archive.open('events.jsonl') as handle:
            while True:
                raw = handle.readline(MAX_EVENT+1)
                if not raw:
                    break
                if len(raw)>MAX_EVENT or not raw.endswith(b'\n'):
                    raise ValueError('Invalid or oversized recording event')
                doc = json.loads(raw); count += 1
                digest = doc.pop('event_hash',None)
                if doc.get('sequence') != count or doc.get('session_id') != manifest.get('session_id') or doc.get('previous_hash') != previous:
                    raise ValueError('Recording sequence or lineage is damaged')
                if hashlib.sha256(_json(doc)).hexdigest() != digest:
                    raise ValueError('Recording event checksum differs')
                previous = digest; whole.update(raw)
                if count>1000000:
                    raise ValueError('Too many recording events')
        if count != manifest['events'] or previous != manifest['last_hash'] or whole.hexdigest()!=manifest['events_sha256']:
            raise ValueError('Recording is incomplete or damaged')
        return dict(manifest,verified=True)


def add_cli(subcommands):
    command = subcommands.add_parser('recording-inspect',help='verify a local recording ZIP without executing it')
    command.add_argument('--bundle',required=True)
    review = subcommands.add_parser('recording-review',help='review verified activity, alert context and coverage gaps')
    review.add_argument('--bundle',required=True)
    review.add_argument('--output',required=True)
    export = subcommands.add_parser('recording-export',help='recover a portable recording from its local journal')
    export.add_argument('--directory',required=True)
    export.add_argument('--stop',action='store_true')


def run(args):
    if args.command == 'recording-inspect':
        print(json.dumps(inspect_bundle(args.bundle),indent=2))
    else:
        recorder = Recorder(args.directory,role='export',background=False)
        try:
            if args.stop:
                recorder.stop()
            path = recorder.export()
            print(json.dumps({'file':str(path),'manifest':inspect_bundle(path)},indent=2))
        finally:
            recorder.close()


def make_session_bundle(destination, recordings):
    """Combine local UI/setup and controller evidence as one portable ZIP."""
    destination = Path(destination).absolute()
    guard = private_directory(destination.parent)
    if any(x.is_symlink() for x in (destination, *destination.parents)):
        raise ValueError('Session export cannot use symlink paths')
    temporary = destination.with_name('.session-' + uuid.uuid4().hex + '.tmp')
    summaries = []
    seen = set()
    try:
        with open(temporary,'xb') as handle:
            if os.name == 'posix':
                os.chmod(temporary,0o600)
            with zipfile.ZipFile(handle,'w',compression=zipfile.ZIP_STORED) as archive:
                for index, recording in enumerate(recordings):
                    manifest = inspect_bundle(recording)
                    if manifest['session_id'] in seen:
                        continue
                    seen.add(manifest['session_id'])
                    name = f'recording-{index+1}.zip'
                    with open(recording,'rb') as source:
                        digest = hashlib.file_digest(source,'sha256').hexdigest()
                    archive.write(recording,name)
                    summaries.append({'name':name,'sha256':digest,'session_id':manifest['session_id'],
                                      'events':manifest['events'],'dropped_events':manifest['dropped_events'],
                                      'sources':manifest['sources']})
                archive.writestr('session.json',_json({'format':'sentinel-blue-session-v1','version':__version__,
                    'created_at':time.time(),'recordings':summaries,'coverage':COVERAGE}))
            handle.flush(); os.fsync(handle.fileno())
        _replace_with_retry(temporary,destination)
        _fsync_directory(destination.parent)
        return destination
    finally:
        temporary.unlink(missing_ok=True)
        if guard:
            guard.close()


def _inspect_session(archive):
    import tempfile
    entries = archive.infolist()
    if len(entries)>5 or len({x.filename for x in entries}) != len(entries):
        raise ValueError('Invalid session members')
    if archive.getinfo('session.json').file_size > 4*1024*1024:
        raise ValueError('Oversized session metadata')
    summary = json.loads(archive.read('session.json'))
    recordings = summary.get('recordings')
    if summary.get('format') != 'sentinel-blue-session-v1' or not isinstance(recordings,list) or not 1<=len(recordings)<=4:
        raise ValueError('Invalid session metadata')
    expected = {'session.json'} | {x.get('name') for x in recordings}
    if set(archive.namelist()) != expected:
        raise ValueError('Unexpected session files')
    verified = []
    for row in recordings:
        if not re.fullmatch(r'recording-[1-4]\.zip',row['name']) or archive.getinfo(row['name']).file_size>2*MAX_TOTAL:
            raise ValueError('Invalid recording member')
        with tempfile.TemporaryFile() as target, archive.open(row['name']) as source:
            digest=hashlib.sha256(); total=0
            while data:=source.read(1024*1024):
                total+=len(data)
                if total>2*MAX_TOTAL:raise ValueError('Oversized nested recording')
                digest.update(data);target.write(data)
            if digest.hexdigest()!=row['sha256']:raise ValueError('Nested recording checksum differs')
            target.seek(0)
            # Nested session containers are not valid evidence members.
            with zipfile.ZipFile(target) as nested:
                if 'session.json' in nested.namelist():raise ValueError('Nested session container')
            target.seek(0);manifest=inspect_bundle(target)
            if manifest['session_id']!=row['session_id']:raise ValueError('Session identity differs')
            verified.append(manifest)
    return dict(summary,verified=True,verified_recordings=verified)
