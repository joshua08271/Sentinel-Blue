"""What each Linux competition service is, and what this release can do with it.

This is the support registry the provisioning roadmap calls F03. It exists so
three questions have one answer instead of three: what does this service need on
a host, what can Sentinel actually do with it, and has that been proven.

Two facts are kept apart on purpose.

``capability`` is what the code can do — ``adopt`` means detect, validate,
monitor and restart an existing installation without writing configuration;
``configure`` additionally generates reviewed configuration files through the
same hash-pinned, validated, reversible path the nginx adapter already uses.

``native_tested`` is whether that has been proven against the real product on a
real host. Every entry in this release is ``False``. A service is never called
supported because a catalog row exists, because a package is installed, or
because a port answers — the roadmap is explicit that a recipe name is not an
accepted setup capability, and this module refuses to imply otherwise.
"""

from __future__ import annotations

import re
from typing import Any

# Package managers this catalog knows how to name packages for. A host running
# something else is reported unsupported rather than guessed at.
MANAGERS = ("apt", "dnf", "yum", "zypper", "pacman")

SERVICE_ID = re.compile(r"[a-z0-9][a-z0-9-]{0,63}\Z")

ADOPT = "adopt"
CONFIGURE = "configure"
CAPABILITIES = (ADOPT, CONFIGURE)


def _entry(service_id, label, family, *, unit, capability=ADOPT, packages=None,
           config_paths=(), data_paths=(), ports=(), validate_argv=None,
           transactions=(), clients=(), notes="", conflicts=(), requires=()):
    return {
        "id": service_id,
        "label": label,
        "family": family,
        "unit": unit,
        "capability": capability,
        # Proven against the real product on a real host. Nothing here is.
        "native_tested": False,
        "packages": dict(packages or {}),
        # Configuration this adapter may write or compare. Never data.
        "config_paths": list(config_paths),
        # State that must survive setup: mailboxes, zone journals, databases.
        # A pack that would destroy one of these is held, not attempted.
        "data_paths": list(data_paths),
        "ports": list(ports),
        # Run before reload. A service with no lint has None and is reloaded
        # only after its own configuration test, never blindly.
        "validate_argv": list(validate_argv) if validate_argv else None,
        # Scoring transactions this service is normally checked with, by probe
        # kind, so the GUI can propose real checks rather than a port test.
        "transactions": list(transactions),
        # Probe kinds whose client must exist on the checking host.
        "clients": list(clients),
        "conflicts": list(conflicts),
        "requires": list(requires),
        "notes": notes,
    }


# ---------------------------------------------------------------- DNS (S01)
_DNS = [
    _entry("bind9", "BIND 9 authoritative/recursive DNS", "dns",
           unit="named", capability=CONFIGURE,
           packages={"apt": ["bind9", "bind9-utils"], "dnf": ["bind", "bind-utils"],
                     "yum": ["bind", "bind-utils"], "zypper": ["bind"], "pacman": ["bind"]},
           config_paths=["/etc/bind/named.conf.local", "/etc/named.conf"],
           data_paths=["/var/lib/bind", "/var/named"],
           ports=[53], validate_argv=["/usr/sbin/named-checkconf"],
           transactions=["dns", "dns-update"], clients=["dns-update"],
           conflicts=["dnsmasq", "unbound"],
           notes="Existing zone data and dynamic journals are preserved. New owned static zones "
                 "use /etc/bind; adoption pins existing zone bytes. Active includes are checked."),
    _entry("unbound", "Unbound recursive resolver", "dns",
           unit="unbound", capability=CONFIGURE,
           packages={"apt": ["unbound"], "dnf": ["unbound"], "yum": ["unbound"],
                     "zypper": ["unbound"], "pacman": ["unbound"]},
           config_paths=["/etc/unbound/unbound.conf.d"], ports=[53],
           validate_argv=["/usr/sbin/unbound-checkconf"],
           transactions=["dns"], conflicts=["bind9", "dnsmasq"],
           notes="Recursive only. Authoritative zones belong to BIND."),
    _entry("dnsmasq", "dnsmasq DNS and DHCP", "dns",
           unit="dnsmasq", capability=CONFIGURE,
           packages={"apt": ["dnsmasq"], "dnf": ["dnsmasq"], "yum": ["dnsmasq"],
                     "zypper": ["dnsmasq"], "pacman": ["dnsmasq"]},
           config_paths=["/etc/dnsmasq.d"], data_paths=["/var/lib/misc/dnsmasq.leases"],
           ports=[53, 67], validate_argv=["/usr/sbin/dnsmasq", "--test"],
           transactions=["dns"], conflicts=["bind9", "unbound", "isc-dhcp-server"],
           notes="Serves DNS and DHCP from one daemon. Existing leases are preserved."),
]

# ------------------------------------------------------- DHCP and time (S02, S03)
_DHCP_TIME = [
    _entry("isc-dhcp-server", "ISC DHCP server", "dhcp",
           unit="isc-dhcp-server", capability=CONFIGURE,
           packages={"apt": ["isc-dhcp-server"], "dnf": ["dhcp-server"], "yum": ["dhcp"],
                     "zypper": ["dhcp-server"], "pacman": ["dhcp"]},
           config_paths=["/etc/dhcp/dhcpd.conf"], data_paths=["/var/lib/dhcp/dhcpd.leases"],
           ports=[67], validate_argv=["/usr/sbin/dhcpd", "-t", "-cf", "/etc/dhcp/dhcpd.conf"],
           conflicts=["dnsmasq", "kea-dhcp4"],
           notes="Live leases are preserved. Enabling DHCP on a shared range affects "
                 "every host on it, so this pack is held without explicit event approval."),
    _entry("kea-dhcp4", "Kea DHCPv4 server", "dhcp",
           unit="kea-dhcp4-server",
           packages={"apt": ["kea-dhcp4-server"], "dnf": ["kea"], "yum": ["kea"],
                     "zypper": ["kea"], "pacman": ["kea"]},
           config_paths=["/etc/kea/kea-dhcp4.conf"], data_paths=["/var/lib/kea"],
           ports=[67], conflicts=["isc-dhcp-server", "dnsmasq"],
           notes="Adoption and validation only; its JSON configuration model is not generated."),
    _entry("chrony", "chrony time service", "time",
           unit="chronyd", capability=CONFIGURE,
           packages={"apt": ["chrony"], "dnf": ["chrony"], "yum": ["chrony"],
                     "zypper": ["chrony"], "pacman": ["chrony"]},
           config_paths=["/etc/chrony/chrony.conf", "/etc/chrony.conf"], ports=[123],
           conflicts=["ntpd", "systemd-timesyncd"],
           notes="Clock correctness gates Kerberos, certificates and DHCP leases, so "
                 "this is a prerequisite for several other packs rather than an extra."),
    _entry("ntpd", "ntpd / ntpsec time service", "time",
           unit="ntpsec",
           packages={"apt": ["ntpsec"], "dnf": ["ntpsec"], "yum": ["ntp"],
                     "zypper": ["ntp"], "pacman": ["ntp"]},
           config_paths=["/etc/ntpsec/ntp.conf", "/etc/ntp.conf"], ports=[123],
           conflicts=["chrony", "systemd-timesyncd"]),
    _entry("systemd-timesyncd", "systemd-timesyncd", "time",
           unit="systemd-timesyncd",
           config_paths=["/etc/systemd/timesyncd.conf.d"], ports=[123],
           conflicts=["chrony", "ntpd"],
           notes="The default client on many distributions. It is catalogued because "
                 "it conflicts with chrony and ntpd, so a selection that installs one "
                 "over a running instance of this is caught before the plan is built."),
]

# ------------------------------------------------------------ web and runtimes (S04, S06)
_WEB = [
    _entry("nginx", "nginx HTTP/HTTPS", "web",
           unit="nginx", capability=CONFIGURE,
           packages={"apt": ["nginx"], "dnf": ["nginx"], "yum": ["nginx"],
                     "zypper": ["nginx"], "pacman": ["nginx"]},
           config_paths=["/etc/nginx/conf.d"], ports=[80, 443],
           validate_argv=["/usr/sbin/nginx", "-t"],
           transactions=["http", "https", "tls"], conflicts=["apache2"],
           notes="The existing 1.9.75 adapter. Unrelated vhosts are preserved."),
    _entry("apache2", "Apache HTTP Server", "web",
           unit="apache2", capability=CONFIGURE,
           packages={"apt": ["apache2"], "dnf": ["httpd"], "yum": ["httpd"],
                     "zypper": ["apache2"], "pacman": ["apache"]},
           config_paths=["/etc/apache2/sites-available", "/etc/httpd/conf.d"],
           ports=[80, 443], validate_argv=["/usr/sbin/apachectl", "-t"],
           transactions=["http", "https", "tls"], conflicts=["nginx"],
           notes="Unit and paths differ between Debian (apache2) and RHEL (httpd); "
                 "the pack refuses rather than guessing when it cannot tell."),
    _entry("php-fpm", "PHP-FPM application runtime", "runtime",
           unit="php-fpm",
           packages={"apt": ["php-fpm"], "dnf": ["php-fpm"], "yum": ["php-fpm"],
                     "zypper": ["php-fpm"], "pacman": ["php-fpm"]},
           config_paths=["/etc/php/*/fpm/pool.d", "/etc/php-fpm.d"],
           requires=["nginx"],
           notes="Pool naming is version-dependent; adoption and validation only."),
    _entry("tomcat", "Apache Tomcat", "runtime",
           unit="tomcat9",
           packages={"apt": ["tomcat9"], "dnf": ["tomcat"], "yum": ["tomcat"],
                     "zypper": ["tomcat"], "pacman": ["tomcat9"]},
           config_paths=["/etc/tomcat9", "/etc/tomcat"], data_paths=["/var/lib/tomcat9/webapps"],
           ports=[8080], transactions=["http"],
           notes="Deployed applications are data, never replaced by setup."),
    _entry("gunicorn", "Python WSGI application unit", "runtime",
           unit="sentinel-gunicorn", capability=CONFIGURE,
           config_paths=["/etc/systemd/system/sentinel-gunicorn.service"],
           ports=[8000], transactions=["http"],
           notes="Generates a systemd unit for a supplied application, not the "
                 "application itself. The event's artifact is used as given."),
]

# -------------------------------------------------------------- databases (S07, S08)
_DATABASE = [
    _entry("mariadb", "MariaDB / MySQL", "database",
           unit="mariadb", capability=CONFIGURE,
           packages={"apt": ["mariadb-server"], "dnf": ["mariadb-server"],
                     "yum": ["mariadb-server"], "zypper": ["mariadb"], "pacman": ["mariadb"]},
           config_paths=["/etc/mysql/mariadb.conf.d", "/etc/my.cnf.d"],
           data_paths=["/var/lib/mysql"], ports=[3306],
           transactions=["mysql"], clients=["mysql"], conflicts=["postgresql"],
           notes="The data directory is never reinitialized. A populated directory "
                 "refuses destructive setup; only configuration is written."),
    _entry("postgresql", "PostgreSQL", "database",
           unit="postgresql", capability=CONFIGURE,
           packages={"apt": ["postgresql"], "dnf": ["postgresql-server"],
                     "yum": ["postgresql-server"], "zypper": ["postgresql-server"],
                     "pacman": ["postgresql"]},
           config_paths=["/etc/postgresql", "/var/lib/pgsql/data/pg_hba.conf"],
           data_paths=["/var/lib/postgresql", "/var/lib/pgsql"], ports=[5432],
           transactions=["postgres"], clients=["postgres"], conflicts=["mariadb"],
           notes="pg_hba and listen configuration only. Cluster initialization, WAL "
                 "and migrations are data-aware operations held for a person."),
    _entry("redis", "Redis", "cache",
           unit="redis-server", capability=CONFIGURE,
           packages={"apt": ["redis-server"], "dnf": ["redis"], "yum": ["redis"],
                     "zypper": ["redis"], "pacman": ["redis"]},
           config_paths=["/etc/redis/redis.conf"], data_paths=["/var/lib/redis"],
           ports=[6379], transactions=["tcp"],
           notes="Binding and authentication. An installer must never expose an "
                 "unauthenticated public endpoint, so an exposed bind requires a hash-pinned ACL file."),
    _entry("memcached", "Memcached", "cache",
           unit="memcached",
           packages={"apt": ["memcached"], "dnf": ["memcached"], "yum": ["memcached"],
                     "zypper": ["memcached"], "pacman": ["memcached"]},
           config_paths=["/etc/memcached.conf"], ports=[11211], transactions=["tcp"]),
    _entry("mongodb", "MongoDB", "database",
           unit="mongod",
           packages={"apt": ["mongodb-server"], "dnf": ["mongodb-server"],
                     "yum": ["mongodb-server"], "zypper": ["mongodb"], "pacman": ["mongodb-bin"]},
           config_paths=["/etc/mongod.conf"], data_paths=["/var/lib/mongodb"],
           ports=[27017], transactions=["tcp"],
           notes="Adoption and validation only; its storage model needs a data-aware pack."),
]

# ------------------------------------------------------------------- mail (S10)
_MAIL = [
    _entry("postfix", "Postfix SMTP", "mail",
           unit="postfix", capability=CONFIGURE,
           packages={"apt": ["postfix"], "dnf": ["postfix"], "yum": ["postfix"],
                     "zypper": ["postfix"], "pacman": ["postfix"]},
           config_paths=["/etc/postfix/main.cf"],
           data_paths=["/var/spool/postfix", "/var/mail"], ports=[25, 587],
           validate_argv=["/usr/sbin/postfix", "check"],
           transactions=["smtp"], conflicts=["exim4"],
           notes="The mail queue and existing user mail are preserved. Relay rules are "
                 "written explicitly; an open relay is never a generated outcome."),
    _entry("dovecot", "Dovecot IMAP/POP3", "mail",
           unit="dovecot", capability=CONFIGURE,
           packages={"apt": ["dovecot-imapd", "dovecot-pop3d"], "dnf": ["dovecot"],
                     "yum": ["dovecot"], "zypper": ["dovecot"], "pacman": ["dovecot"]},
           config_paths=["/etc/dovecot/conf.d"], data_paths=["/var/mail", "/home"],
           ports=[110, 143, 993, 995], validate_argv=["/usr/bin/doveconf", "-n"],
           transactions=["tcp", "tls"], requires=["postfix"],
           notes="Mailboxes are data. Retrieval protocols and TLS only."),
    _entry("exim4", "Exim MTA", "mail",
           unit="exim4",
           packages={"apt": ["exim4"], "dnf": ["exim"], "yum": ["exim"],
                     "zypper": ["exim"], "pacman": ["exim"]},
           config_paths=["/etc/exim4"], data_paths=["/var/spool/exim4"],
           ports=[25], transactions=["smtp"], conflicts=["postfix"]),
]

# --------------------------------------------------- transfer and sharing (S12, S14, S15)
_TRANSFER = [
    _entry("vsftpd", "vsftpd FTP/FTPS", "transfer",
           unit="vsftpd", capability=CONFIGURE,
           packages={"apt": ["vsftpd"], "dnf": ["vsftpd"], "yum": ["vsftpd"],
                     "zypper": ["vsftpd"], "pacman": ["vsftpd"]},
           config_paths=["/etc/vsftpd.conf"], data_paths=["/srv/ftp", "/home"],
           ports=[21], transactions=["ftp"], conflicts=["proftpd"],
           notes="Anonymous write is never enabled as a shortcut. Shared files are preserved."),
    _entry("proftpd", "ProFTPD", "transfer",
           unit="proftpd",
           packages={"apt": ["proftpd-core"], "dnf": ["proftpd"], "yum": ["proftpd"],
                     "zypper": ["proftpd"], "pacman": ["proftpd"]},
           config_paths=["/etc/proftpd/proftpd.conf"], data_paths=["/srv/ftp"],
           ports=[21], transactions=["ftp"], conflicts=["vsftpd"]),
    _entry("openssh-server", "OpenSSH server and SFTP", "access",
           unit="ssh", capability=CONFIGURE,
           packages={"apt": ["openssh-server"], "dnf": ["openssh-server"],
                     "yum": ["openssh-server"], "zypper": ["openssh"], "pacman": ["openssh"]},
           config_paths=["/etc/ssh/sshd_config.d"], ports=[22],
           validate_argv=["/usr/sbin/sshd", "-t"], transactions=["ssh-login"],
           clients=["ssh-login"],
           notes="Host keys are never rotated to make setup succeed, and the "
                 "management path is verified before a reload can remove it."),
    _entry("samba", "Samba SMB file services", "sharing",
           unit="smbd", capability=CONFIGURE,
           packages={"apt": ["samba"], "dnf": ["samba"], "yum": ["samba"],
                     "zypper": ["samba"], "pacman": ["samba"]},
           config_paths=["/etc/samba/smb.conf"], data_paths=["/srv/samba"],
           ports=[139, 445], validate_argv=["/usr/bin/testparm", "-s"],
           transactions=["smb"], clients=["smb"],
           notes="Share definitions and permissions. Existing content and ownership "
                 "are preserved; group membership is modelled separately."),
    _entry("nfs-server", "NFS exports", "sharing",
           unit="nfs-server", capability=CONFIGURE,
           packages={"apt": ["nfs-kernel-server"], "dnf": ["nfs-utils"],
                     "yum": ["nfs-utils"], "zypper": ["nfs-kernel-server"], "pacman": ["nfs-utils"]},
           config_paths=["/etc/exports.d"], data_paths=["/srv/nfs"], ports=[2049],
           validate_argv=["/usr/sbin/exportfs", "-s"],
           notes="Exports only. A bad export is reversed without unmounting storage "
                 "or deleting content."),
    _entry("tftpd-hpa", "TFTP server", "transfer",
           unit="tftpd-hpa",
           packages={"apt": ["tftpd-hpa"], "dnf": ["tftp-server"], "yum": ["tftp-server"],
                     "zypper": ["tftp"], "pacman": ["tftp-hpa"]},
           config_paths=["/etc/default/tftpd-hpa"], data_paths=["/srv/tftp"], ports=[69],
           notes="Only by explicit scope; TFTP is unauthenticated by design."),
]

# ----------------------------------------------------------- directory and auth (S17, S18)
_DIRECTORY = [
    _entry("slapd", "OpenLDAP directory", "directory",
           unit="slapd",
           packages={"apt": ["slapd", "ldap-utils"], "dnf": ["openldap-servers"],
                     "yum": ["openldap-servers"], "zypper": ["openldap2"], "pacman": ["openldap"]},
           config_paths=["/etc/ldap/slapd.d"], data_paths=["/var/lib/ldap"],
           ports=[389, 636], transactions=["tcp", "tls"],
           notes="Directory objects and UID/GID mappings are data. Adoption and "
                 "validation only; a failed join must not overwrite directory identity."),
    _entry("sssd", "SSSD domain integration", "directory",
           unit="sssd",
           packages={"apt": ["sssd"], "dnf": ["sssd"], "yum": ["sssd"],
                     "zypper": ["sssd"], "pacman": ["sssd"]},
           config_paths=["/etc/sssd/sssd.conf"], requires=["chrony"],
           notes="Client-side domain integration. Requires correct time."),
    _entry("krb5-kdc", "Kerberos KDC", "directory",
           unit="krb5-kdc",
           packages={"apt": ["krb5-kdc"], "dnf": ["krb5-server"], "yum": ["krb5-server"],
                     "zypper": ["krb5-server"], "pacman": ["krb5"]},
           config_paths=["/etc/krb5.conf"], data_paths=["/var/lib/krb5kdc"],
           ports=[88], requires=["chrony"],
           notes="Principals and keytabs are secrets; never generated here."),
    _entry("freeradius", "FreeRADIUS", "directory",
           unit="freeradius",
           packages={"apt": ["freeradius"], "dnf": ["freeradius"], "yum": ["freeradius"],
                     "zypper": ["freeradius-server"], "pacman": ["freeradius"]},
           config_paths=["/etc/freeradius"], ports=[1812, 1813],
           notes="Shared secrets are never broadcast or defaulted to make a check pass."),
]

# ------------------------------------------------------ proxy, broker, logging (S28-S30, X01)
_SUPPORTING = [
    _entry("haproxy", "HAProxy load balancer", "proxy",
           unit="haproxy", capability=CONFIGURE,
           packages={"apt": ["haproxy"], "dnf": ["haproxy"], "yum": ["haproxy"],
                     "zypper": ["haproxy"], "pacman": ["haproxy"]},
           config_paths=["/etc/haproxy/haproxy.cfg"], ports=[80, 443],
           validate_argv=["/usr/sbin/haproxy", "-c", "-f", "/etc/haproxy/haproxy.cfg"],
           transactions=["http", "https"],
           notes="Never migrates a scored service to another host without permission."),
    _entry("squid", "Squid forward proxy", "proxy",
           unit="squid",
           packages={"apt": ["squid"], "dnf": ["squid"], "yum": ["squid"],
                     "zypper": ["squid"], "pacman": ["squid"]},
           config_paths=["/etc/squid/squid.conf"], ports=[3128],
           validate_argv=["/usr/sbin/squid", "-k", "parse"]),
    _entry("rsyslog", "rsyslog", "logging",
           unit="rsyslog", capability=CONFIGURE,
           packages={"apt": ["rsyslog"], "dnf": ["rsyslog"], "yum": ["rsyslog"],
                     "zypper": ["rsyslog"], "pacman": ["rsyslog"]},
           config_paths=["/etc/rsyslog.d"], data_paths=["/var/log"], ports=[514],
           validate_argv=["/usr/sbin/rsyslogd", "-N1"],
           notes="Existing logs are preserved and ingestion is bounded; setup must "
                 "not exhaust storage or interfere with scored traffic."),
    _entry("rabbitmq-server", "RabbitMQ broker", "broker",
           unit="rabbitmq-server",
           packages={"apt": ["rabbitmq-server"], "dnf": ["rabbitmq-server"],
                     "yum": ["rabbitmq-server"], "zypper": ["rabbitmq-server"],
                     "pacman": ["rabbitmq"]},
           config_paths=["/etc/rabbitmq"], data_paths=["/var/lib/rabbitmq"],
           ports=[5672], transactions=["tcp"],
           notes="Durable queues are data; reconfiguration must not drop them."),
    _entry("mosquitto", "Mosquitto MQTT broker", "broker",
           unit="mosquitto", capability=CONFIGURE,
           packages={"apt": ["mosquitto"], "dnf": ["mosquitto"], "yum": ["mosquitto"],
                     "zypper": ["mosquitto"], "pacman": ["mosquitto"]},
           config_paths=["/etc/mosquitto/conf.d"], data_paths=["/var/lib/mosquitto"],
           ports=[1883], transactions=["tcp"],
           notes="Anonymous access is never enabled to make a check pass."),
    _entry("cups", "CUPS printing", "printing",
           unit="cups",
           packages={"apt": ["cups"], "dnf": ["cups"], "yum": ["cups"],
                     "zypper": ["cups"], "pacman": ["cups"]},
           config_paths=["/etc/cups/cupsd.conf"], data_paths=["/var/spool/cups"],
           ports=[631], notes="Existing queues and jobs are preserved; no physical printing."),
    _entry("docker", "Docker engine", "container",
           unit="docker",
           packages={"apt": ["docker.io"], "dnf": ["docker"], "yum": ["docker"],
                     "zypper": ["docker"], "pacman": ["docker"]},
           config_paths=["/etc/docker/daemon.json"], data_paths=["/var/lib/docker"],
           conflicts=["podman"],
           notes="Adoption only. Moving a scored service into a container is disabled "
                 "unless the event profile explicitly authorizes it."),
    _entry("podman", "Podman", "container",
           unit="podman",
           packages={"apt": ["podman"], "dnf": ["podman"], "yum": ["podman"],
                     "zypper": ["podman"], "pacman": ["podman"]},
           config_paths=["/etc/containers"], data_paths=["/var/lib/containers"],
           conflicts=["docker"]),
]

CATALOG = {row["id"]: row for row in
           [*_DNS, *_DHCP_TIME, *_WEB, *_DATABASE, *_MAIL, *_TRANSFER, *_DIRECTORY, *_SUPPORTING]}

FAMILIES = tuple(sorted({row["family"] for row in CATALOG.values()}))


def entry(service_id: str) -> dict[str, Any]:
    if not isinstance(service_id, str) or not SERVICE_ID.fullmatch(service_id):
        raise ValueError("invalid catalog service id")
    if service_id not in CATALOG:
        raise ValueError(f"no catalog entry for service: {service_id}")
    return dict(CATALOG[service_id])


def catalog_rows(*, family: str | None = None, capability: str | None = None) -> list[dict[str, Any]]:
    """Every known service, newest information first for the operator."""
    rows = [dict(row) for row in CATALOG.values()]
    if family is not None:
        rows = [row for row in rows if row["family"] == family]
    if capability is not None:
        rows = [row for row in rows if row["capability"] == capability]
    return sorted(rows, key=lambda row: (row["family"], row["id"]))


def packages_for(service_id: str, manager: str) -> list[str]:
    """Package names for one manager, or a refusal rather than a guess."""
    row = entry(service_id)
    if manager not in MANAGERS:
        raise ValueError(f"unsupported package manager: {manager}")
    packages = row["packages"].get(manager)
    if not packages:
        raise ValueError(
            f"{row['label']} has no reviewed package name for {manager}; "
            "install it by hand and re-run adoption")
    return list(packages)


def conflicting(selection: list[str]) -> list[dict[str, str]]:
    """Pairs in this selection that cannot both own a port or role on one host."""
    chosen = [service_id for service_id in selection if service_id in CATALOG]
    found = []
    for service_id in chosen:
        for other in CATALOG[service_id]["conflicts"]:
            if other in chosen and {service_id, other} not in [set(pair.values()) for pair in found]:
                found.append({"service": service_id, "conflicts_with": other})
    return found


def missing_requirements(selection: list[str]) -> list[dict[str, str]]:
    """Services a selection depends on but did not include."""
    chosen = set(service_id for service_id in selection if service_id in CATALOG)
    return [{"service": service_id, "requires": needed}
            for service_id in sorted(chosen)
            for needed in CATALOG[service_id]["requires"] if needed not in chosen]


def support_summary(state_dir=None, *, contexts=None, runtime=None) -> dict[str, Any]:
    """The honest state of this catalog, for anything that reports readiness.

    ``native_tested`` on a catalog row is a property of the source: it is False for
    every entry and stays False, because shipping a pack proves nothing. What can
    change is what a *particular host* has proven, and that lives in acceptance
    receipts rather than in this table. Pass ``state_dir`` to have those counted.
    """
    rows = list(CATALOG.values())
    summary = {
        "services": len(rows),
        "families": len(FAMILIES),
        "configure": sum(row["capability"] == CONFIGURE for row in rows),
        "adopt_only": sum(row["capability"] == ADOPT for row in rows),
        "native_tested": sum(row["native_tested"] for row in rows),
        "accepted_here": [],
        "statement": (
            "Every entry is implemented but not native-tested. A service is supported "
            "only after its pack passes the acceptance matrix against the real product "
            "on the target platform; a catalog row is not support."
        ),
    }
    if state_dir is None:
        return summary
    try:
        from .pack_acceptance import summary as acceptance_summary
        accepted = acceptance_summary(state_dir, contexts=contexts, runtime=runtime)
    except (OSError, ValueError, ImportError):
        return summary
    summary["accepted_here"] = accepted["accepted"]
    summary["stale_here"] = accepted["stale"]
    if accepted["accepted"]:
        summary["statement"] = (
            f"{len(accepted['accepted'])} of {accepted['total']} configuring services have "
            "passed the acceptance matrix against the real product on this host: "
            + ", ".join(accepted["accepted"])
            + ". Every other entry is implemented but unproven here, and a catalog row is "
              "not support."
        )
        if accepted["stale"]:
            summary["statement"] += (
                f" {len(accepted['stale'])} earlier acceptance(s) no longer describe what is "
                "installed and do not count."
            )
    return summary
