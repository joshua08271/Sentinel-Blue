"""Bounded service recovery from approved manifests and fresh observations."""

from __future__ import annotations

import hashlib
import math
import threading
import time
from typing import Any

from .event_profile import EventProfile
from .json_codec import canonical_json_bytes
from .policy import SERVICE_NAME, SHA256
from .probe_evidence import matching_probe_health


RECOVERY_CONFIRMATIONS = 2
RECOVERY_COOLDOWN_SECONDS = 300
RECOVERY_WINDOW_SECONDS = 3600
RECOVERY_MAX_ATTEMPTS = 3
RECOVERY_FRESHNESS_SECONDS = 90
# Validation window for an automatic start of a manifest without a repair
# policy; a repair policy's validation_timeout_seconds (5..120) takes precedence.
START_VALIDATION_SECONDS = 30


def _one(rows: list[dict[str, Any]], key: str, value: str) -> dict[str, Any]:
    matches = [row for row in rows if row.get(key) == value]
    if len(matches) != 1:
        raise ValueError(f"missing or ambiguous {key}: {value}")
    return matches[0]


def recovery_contract(profile: EventProfile, agent_id: str, service: str,
                      *, action: str = "restart_service",
                      authority: str = "allowed_automatic_actions") -> dict[str, Any]:
    if not profile.services_confirmed:
        raise ValueError("service manifests are not confirmed")
    if authority not in {"allowed_automatic_actions", "approval_actions"}:
        raise ValueError("recovery authority must name a manifest action list")
    manifests = [item for item in profile.services if item["host"] == agent_id]
    target = _one(manifests, "service_id", service)
    if not SERVICE_NAME.fullmatch(service):
        raise ValueError("invalid native service name")
    if action not in target[authority]:
        raise ValueError("manifest does not authorize automatic service recovery"
                         if authority == "allowed_automatic_actions"
                         else "manifest does not authorize operator-approved service recovery")
    visited: set[str] = set()
    active: set[str] = set()
    dependencies: list[dict[str, Any]] = []

    def visit(item: dict[str, Any]) -> None:
        name = item["service_id"]
        if name in active:
            raise ValueError("service dependency cycle")
        if name in visited:
            return
        if len(visited) + len(active) >= 128:
            raise ValueError("service dependency budget exceeded")
        if not SERVICE_NAME.fullmatch(name) or name.startswith("-"):
            raise ValueError("invalid dependency service name")
        active.add(name)
        for dependency in item["dependencies"]:
            visit(_one(manifests, "service_id", dependency))
        active.remove(name)
        visited.add(name)
        if name != service:
            dependencies.append(item)

    visit(target)
    dependency_probes = [probe for item in dependencies for probe in item["expected_transactions"]]
    if len(dependency_probes) > 256:
        raise ValueError("dependency probe budget exceeded")
    if not target["required_files"]:
        raise ValueError("automatic recovery requires approved configuration files")
    chain = [target, *dependencies]
    from .service_repair import recovery_files
    files = sorted({path for item in chain for path in recovery_files(item)})
    accounts = sorted({name for item in chain for name in item["required_accounts"]})
    if len(files) > 256 or len(accounts) > 256:
        raise ValueError("dependency configuration budget exceeded")
    return {
        "probes": target["expected_transactions"],
        "files": files,
        "dependencies": [item["service_id"] for item in dependencies],
        "dependency_probes": dependency_probes,
        "required_accounts": accounts,
    }


def _fresh(telemetry: dict[str, Any], now: float, *, allow_payload_issues: bool = False,
           service: str | None = None) -> None:
    """Require a fresh, sequenced, complete sample for recovering ``service``.

    Given the service, a payload-coverage gap that belongs to another service
    or to no service does not hold it (see ``recovery_blocking``).
    """
    observed = telemetry.get("observed_at")
    if (
        type(observed) not in {int, float}
        or not math.isfinite(observed)
        or not 0 <= now - observed <= RECOVERY_FRESHNESS_SECONDS
        or telemetry.get("boot_id") in {None, "", "unknown"}
        or type(telemetry.get("sequence")) is not int
        or telemetry["sequence"] < 1
    ):
        raise ValueError("service recovery needs fresh sequenced telemetry")
    from .telemetry_diagnostics import recovery_blocking
    if recovery_blocking(telemetry, allow_payload=allow_payload_issues is True, service=service):
        raise ValueError("incomplete collection holds service recovery")


def recovery_parameters(
    profile: EventProfile, agent_id: str, service: str,
    baseline: dict[str, Any], telemetry: dict[str, Any], *, now: float | None = None,
) -> dict[str, Any]:
    # The manifest's payload opt-out applies to this restart-only path too; it
    # was dropped here before 2.0.16 (review bug 14).
    policy = next((row.get("repair_policy") or {} for row in profile.services
                   if row.get("host") == agent_id and row.get("service_id") == service), {})
    allow_payload = policy.get("allow_unrelated_payload_errors") is True
    _fresh(telemetry, time.time() if now is None else now, allow_payload_issues=allow_payload, service=service)
    contract = recovery_contract(profile, agent_id, service)
    previous = _one(baseline.get("services", []), "name", service)
    current = _one(telemetry.get("services", []), "name", service)
    # A restart the service manager or the host will defeat is held and named
    # before any less specific refusal, so the operator is told the cause rather
    # than that the state was not one recovery handles (issue #13).
    from .service_repair import restart_blockers, restart_futility
    manifest = _one([row for row in profile.services if row["host"] == agent_id],
                    "service_id", service)
    futile = restart_futility(restart_blockers(service, manifest, current, previous, telemetry))
    if futile:
        raise ValueError(f"{futile}; recovery is held for review")
    stopped_states = {"stopped"}
    if str(telemetry.get("platform", "")).casefold().startswith("linux"):
        stopped_states.update({"inactive", "failed"})
    if previous.get("state") != "running" or current.get("state") not in stopped_states:
        raise ValueError("recovery requires an explicitly stopped approved running service")
    if str(current.get("start_mode", "")).casefold() in {"disabled", "masked", "masked-runtime"}:
        raise ValueError("disabled or masked service needs configuration review")
    files = []
    for path in contract["files"]:
        prior = _one(baseline.get("integrity", []), "path", path)
        item = _one(telemetry.get("integrity", []), "path", path)
        digest = prior.get("sha256", "")
        security = prior.get("security_descriptor_sha256", "")
        if not SHA256.fullmatch(digest) or item.get("sha256") != digest or item.get("readable") is False:
            raise ValueError(f"required file is changed or unverified: {path}")
        if security != item.get("security_descriptor_sha256", ""):
            raise ValueError(f"required file security metadata changed: {path}")
        if str(telemetry.get("platform", "")).casefold().startswith("windows") and not SHA256.fullmatch(security):
            raise ValueError(f"required file lacks approved Windows security metadata: {path}")
        files.append({"path": path, "sha256": digest, "security_descriptor_sha256": security})
    guard = {
        "files": files,
        "dependencies": contract["dependencies"],
        "dependency_probes": contract["dependency_probes"],
        "required_accounts": contract["required_accounts"],
        "boot_id": telemetry["boot_id"],
        "sequence": telemetry["sequence"],
        "observed_at": telemetry["observed_at"],
    }
    if str(telemetry.get("platform", "")).casefold().startswith("linux"):
        if ("rollback_service" not in manifest["approval_actions"]
                or not profile.action_allowed("rollback_service", automated=False,
                                               autonomy_mode="approval-based")):
            raise ValueError("approve rollback_service before enabling recorded automatic starts")
        guard["recorded_undo"] = True
    if "attempt_limits" in manifest.get("repair_policy", {}):
        guard["attempt_limits"] = dict(manifest["repair_policy"]["attempt_limits"])
    if allow_payload:
        guard["allow_unrelated_payload_errors"] = True
    # The start is validated for as long as the manifest's repair window allows
    # (2.0.17). A fixed 5 s window rolled back services that need longer to
    # become healthy, and stopped the service it had just started.
    guard["validation_timeout_seconds"] = policy.get("validation_timeout_seconds", START_VALIDATION_SECONDS)
    parameters = {"service": service, "probes": contract["probes"], "recovery_guard": guard}
    check_recovery_observation(parameters, telemetry, now=now)
    return parameters


def check_recovery_deadline(parameters: dict[str, Any], *, now: float | None = None) -> None:
    """Do not begin a forward mutation using a guard that aged during preflight.

    This is an admission check, not permission to abandon an already admitted
    transaction or to suppress its rollback. Unguarded, operator-reviewed actions
    retain their existing contract.
    """
    if not isinstance(parameters, dict):
        raise ValueError("service recovery parameters must be an object")
    guard = parameters.get("recovery_guard")
    if guard is None:
        return
    instant = time.time() if now is None else now
    observed = guard.get("observed_at") if isinstance(guard, dict) else None
    if (type(instant) not in {int, float} or not math.isfinite(instant)
        or type(observed) not in {int, float} or not math.isfinite(observed)
        or not 0 <= instant - observed <= RECOVERY_FRESHNESS_SECONDS):
        raise ValueError("service recovery guard expired during preflight; fresh diagnosis is required")


def _guard_manifest(parameters: dict[str, Any]) -> dict[str, Any]:
    """What the executor can check on its own: the files and probes in its guard.

    Narrower than the agent's approved manifest by design - `required_data` is
    empty because the executor was never given the business-data paths. A
    malformed guard is a refusal, not a crash, because every caller of this path
    reports a held restart by catching ValueError.
    """
    guard = parameters.get("recovery_guard")
    if not isinstance(guard, dict):
        raise ValueError("queued restart carries no usable recovery guard")
    files = guard.get("files")
    if not isinstance(files, list) or any(
            not isinstance(item, dict) or not isinstance(item.get("path"), str)
            for item in files):
        raise ValueError("recovery guard file list is missing or malformed")
    probes = parameters.get("probes", [])
    if not isinstance(probes, list):
        raise ValueError("queued restart probe contract is malformed")
    return {"expected_transactions": probes,
            "required_files": [item["path"] for item in files],
            "required_data": []}


def check_restart_target(parameters: dict[str, Any], telemetry: dict[str, Any], *,
                         manifest: dict[str, Any] | None = None) -> None:
    """Recheck a queued restart against the latest available target observation.

    The dependency guard alone does not describe the target's current condition.
    A newer sample may report a disabled/masked target, a new native restart
    blocker or exhausted business-data storage after the original plan was made.
    The agent supplies the authoritative manifest, including required_data. The
    executor can independently check only the files/probes bound in its guard.
    No startup policy is changed here and no new telemetry is manufactured.
    """
    if not isinstance(parameters, dict):
        raise ValueError("queued restart parameters are missing or malformed")
    service = parameters.get("service")
    if not isinstance(service, str) or not service:
        raise ValueError("queued restart names no target service")
    rows = telemetry.get("services") if isinstance(telemetry, dict) else None
    if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
        raise ValueError("current target service observation is missing or malformed")
    current = _one(rows, "name", service)
    # Test the type before any set membership below: a non-string state makes
    # `in` raise on an unhashable value before the guard can refuse it, and a
    # refusal has to arrive as a stated reason rather than an internal error.
    state = current.get("state")
    if not isinstance(state, str):
        raise ValueError("current target service state is missing or malformed")
    # An already recovered service is validation-only in ActionExecutor. A stale
    # Result= value must not turn its historical failure into a new repair.
    if state == "running":
        return
    stopped = {"stopped"}
    if str(telemetry.get("platform", "")).casefold().startswith("linux"):
        stopped.update({"inactive", "failed"})
    if state not in stopped:
        raise ValueError("current target service state is not a confirmed stopped state")
    if str(current.get("start_mode", "")).casefold() in {"disabled", "masked", "masked-runtime"}:
        raise ValueError("target was disabled or masked after diagnosis; startup configuration needs review")
    if manifest is None:
        manifest = _guard_manifest(parameters)
    if not isinstance(manifest, dict):
        raise ValueError("the approved service manifest is missing or malformed")
    from .service_repair import restart_blockers, restart_futility
    # Old guard schemas do not contain a baseline restart counter. Do not invent
    # one (zero would blame historical restarts); current native loop substates
    # remain checked. The controller still checks baseline-relative counters.
    reason = restart_futility(restart_blockers(service, manifest, current, current, telemetry))
    if reason:
        raise ValueError(f"{reason}; queued restart is held for a fresh diagnosis")


def check_recovery_observation(
    parameters: dict[str, Any], telemetry: dict[str, Any], *, now: float | None = None,
) -> None:
    instant = time.time() if now is None else now
    guard = parameters["recovery_guard"]
    _fresh(telemetry, instant, allow_payload_issues=guard.get("allow_unrelated_payload_errors", False),
           service=parameters.get("service"))
    if (
        telemetry["boot_id"] != guard["boot_id"]
        or telemetry["sequence"] < guard["sequence"]
        or not 0 <= instant - guard["observed_at"] <= RECOVERY_FRESHNESS_SECONDS
    ):
        raise ValueError("service recovery observation is stale or belongs to another boot")
    for name in guard["dependencies"]:
        if _one(telemetry.get("services", []), "name", name).get("state") != "running":
            raise ValueError(f"dependency is not running: {name}")
    if any(value is not True for value in matching_probe_health(
            guard["dependency_probes"], telemetry.get("probes", []))):
        raise ValueError("dependency application health is unavailable")
    for name in guard["required_accounts"]:
        if _one(telemetry.get("accounts", []), "name", name).get("enabled") is not True:
            raise ValueError(f"required account is unavailable: {name}")


def validate_automatic_recovery(
    profile: EventProfile, agent_id: str, parameters: dict[str, Any], telemetry: dict[str, Any]
) -> None:
    """Agent-side policy cannot be weakened by omitting a controller guard."""
    contract = recovery_contract(profile, agent_id, parameters["service"])
    guard = parameters.get("recovery_guard")
    if not isinstance(guard, dict) or parameters.get("probes") != contract["probes"]:
        raise ValueError("automatic service recovery lacks its exact manifest contract")
    for field in ("dependencies", "dependency_probes", "required_accounts"):
        if guard.get(field) != contract[field]:
            raise ValueError(f"automatic service recovery {field} differs from manifest")
    if [item["path"] for item in guard["files"]] != contract["files"]:
        raise ValueError("automatic service recovery files differ from manifest")
    check_recovery_observation(parameters, telemetry)
    manifest = _one([row for row in profile.services if row["host"] == agent_id],
                    "service_id", parameters["service"])
    from .recovery_limits import normalize_attempt_limits
    expected_limits = normalize_attempt_limits(manifest.get("repair_policy", {}).get("attempt_limits"))
    if normalize_attempt_limits(guard.get("attempt_limits")) != expected_limits:
        raise ValueError("automatic restart attempt limits differ from its approved manifest")
    # The validation window is pinned to the manifest like the limits above.
    # A guard without one was signed by 2.0.16 or earlier and keeps its 5 s.
    if "validation_timeout_seconds" in guard and guard["validation_timeout_seconds"] != (
            manifest.get("repair_policy") or {}).get("validation_timeout_seconds", START_VALIDATION_SECONDS):
        raise ValueError("automatic restart validation window differs from its approved manifest")
    if str(telemetry.get("platform", "")).casefold().startswith("linux") and guard.get("recorded_undo") is not True:
        raise ValueError("Linux automatic restart requires the recorded-undo guard")
    check_restart_target(parameters, telemetry, manifest=manifest)


HEALTHY_STATUS = "nothing to recover; running and its checks pass"


class ServiceRecoveryPlanner:
    """A restart clears confirmations; durable action budgets remain in Store."""

    def __init__(self, profile: EventProfile, *, restart_only: bool = False):
        self.profile = profile
        self.restart_only = restart_only
        self._observations: dict[tuple[str, str], dict[str, Any]] = {}
        self._status: dict[tuple[str, str], str] = {}
        self._diagnoses: dict[tuple[str, str], dict[str, Any]] = {}
        self._reasoning: dict[tuple[str, str], dict[str, Any]] = {}
        self._lock = threading.Lock()

    def observe(self, agent_id: str, baseline: dict[str, Any] | None,
                approved: bool, telemetry: dict[str, Any], *, now: float | None = None) -> dict[str, dict[str, Any]]:
        """``now`` is the current time on the agent's clock (the controller
        passes its measured offset); omitted, this host's clock is used."""
        ready = {}
        binding = hashlib.sha256(canonical_json_bytes(baseline)).hexdigest() if baseline else ""
        sample = hashlib.sha256(canonical_json_bytes(telemetry)).hexdigest()
        with self._lock:
            for manifest in self.profile.services:
                if manifest["host"] != agent_id:
                    continue
                service = manifest["service_id"]
                key = (agent_id, service)
                from .service_repair import diagnose_service, repair_parameters
                self._diagnoses[key] = diagnose_service(self.profile, agent_id, service, baseline, telemetry, now=now)
                try:
                    if not approved or not baseline:
                        raise ValueError("baseline is not approved")
                    if not self.restart_only and "repair_service" in manifest["allowed_automatic_actions"]:
                        parameters = repair_parameters(self.profile, agent_id, service, baseline, telemetry, now=now)
                    else:
                        parameters = recovery_parameters(self.profile, agent_id, service, baseline, telemetry, now=now)
                except (KeyError, TypeError, ValueError) as exc:
                    self._observations.pop(key, None)
                    # Shown in the Services tab for every service: say plainly
                    # that a healthy one needs nothing, whichever planner ran.
                    self._status[key] = (HEALTHY_STATUS if approved and baseline
                                         and self._diagnoses[key].get("code") == "healthy" else str(exc))
                    continue
                prior = self._observations.get(key, {})
                # A changing fault is not a second confirmation of the first.
                material = {key: value for key, value in parameters.items() if key != "recovery_guard"}
                guard = {key: value for key, value in parameters["recovery_guard"].items()
                         if key not in {"sequence", "observed_at"}}
                fault = hashlib.sha256(canonical_json_bytes([material, guard])).hexdigest()
                sequence = telemetry["sequence"]
                exact_retry = (
                    prior.get("sample") == sample
                    and prior.get("baseline") == binding
                    and prior.get("fault") == fault
                )
                consecutive = (
                    prior.get("boot_id") == telemetry["boot_id"]
                    and prior.get("fault") == fault
                    and prior.get("baseline") == binding
                    and prior.get("sequence") == sequence - 1
                    and 0 < telemetry["observed_at"] - prior.get("observed_at", 0) <= RECOVERY_FRESHNESS_SECONDS
                )
                # An interrupted derivation may replay this exact sample. It
                # supplies no new evidence and must preserve the confirmation
                # already established before the interruption.
                if exact_retry:
                    count = prior["count"]
                elif consecutive:
                    count = min(RECOVERY_CONFIRMATIONS, prior.get("count", 0) + 1)
                else:
                    count = 1
                self._observations[key] = {
                    "boot_id": telemetry["boot_id"], "sequence": sequence,
                    "baseline": binding, "observed_at": telemetry["observed_at"], "count": count,
                    "fault": fault, "sample": sample,
                }
                self._status[key] = "ready" if count >= RECOVERY_CONFIRMATIONS else "awaiting consecutive observations"
                if count >= RECOVERY_CONFIRMATIONS:
                    ready[service] = parameters
            from .recovery_reasoning import reason_recovery
            observations = {
                name: {"diagnosis": self._diagnoses[(host, name)], "status": self._status[(host, name)],
                       "parameters": ready.get(name)}
                for host, name in self._status if host == agent_id
            }
            reasoning = reason_recovery(self.profile, agent_id, baseline, telemetry,
                                        approved=approved, observations=observations)
            for row in reasoning["services"]:
                self._reasoning[(agent_id, row["service"])] = row
            # Only reorder already-authorized planner candidates. Reasoning
            # cannot manufacture a repair or bypass observation requirements.
            ordered = [name for name in reasoning["repair_order"] if name in ready]
            ready = {name: ready[name] for name in [*ordered, *(name for name in ready if name not in ordered)]}
        return ready

    def status(self) -> list[dict[str, str]]:
        with self._lock:
            return [{"agent_id": host, "service": service, "status": status,
                     "diagnosis": self._diagnoses.get((host, service), {}),
                     "reasoning": self._reasoning.get((host, service), {})}
                    for (host, service), status in sorted(self._status.items())]

    def hold(self, agent_id: str, service: str, reason: str, *, reset_confirmations: bool = True) -> None:
        with self._lock:
            if reset_confirmations:
                self._observations.pop((agent_id, service), None)
            self._status[(agent_id, service)] = reason
            if (agent_id, service) in self._reasoning:
                self._reasoning[(agent_id, service)].update(state="held", reason=reason, candidate=None)
