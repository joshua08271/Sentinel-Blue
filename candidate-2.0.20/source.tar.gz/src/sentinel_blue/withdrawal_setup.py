"""Long-lived inverses for the narrowly owned setup transaction adapters."""
from __future__ import annotations
import copy
from pathlib import Path
from .mutation_ledger import OwnershipConflict, LedgerError
from .withdrawal_native import semantic


class LinuxSetupAdapter:
    name = 'setup-linux-v1'
    def __init__(self, ledger):
        self.ledger = ledger

    def snapshot(self, target):
        from .setup_linux_transaction import ledger_capture
        return ledger_capture(target['spec'])

    def restore(self, target, before, expected):
        from . import setup_linux_transaction as native
        if self.snapshot(target) != expected:
            raise OwnershipConflict('Linux setup object changed after Sentinel')
        base = native.ROOT / target['token']
        state = native.read(base / 'state.json')
        if state['spec'] != target['spec'] or state['status'] != 'committed':
            raise OwnershipConflict('Private setup transaction is not the recorded committed action')
        if semantic(state['before']) != semantic(before['native']):
            raise LedgerError('Setup before-state differs from the authenticated ledger')
        # The caller already wrote and flushed undo intent. Permit precisely
        # this committed transaction through the old, object-scoped inverse.
        state = copy.deepcopy(state)
        state['status'] = 'applied'
        native.restore(base, target['spec'], state, target['token'], expected=expected)
        result = self.snapshot(target)
        if semantic(result) != semantic(before):
            raise LedgerError('Linux setup inverse failed exact validation')
        return result


class WindowsSetupAdapter:
    name = 'setup-windows-v1'
    def __init__(self, ledger):
        self.ledger = ledger

    def _request(self, target, operation):
        from .security_native import powershell_json
        from importlib.resources import files
        source = files('sentinel_blue').joinpath('setup_windows_transaction.ps1').read_text(encoding='utf-8')
        if operation == 'snapshot':
            source += '\nConvertTo-Json -InputObject (Get-SBSnapshot $p.spec) -Depth 32 -Compress\n'
        else:
            source += r"""
$root=Join-Path ([Environment]::GetFolderPath('CommonApplicationData')) 'SentinelBlueSetupTransactions'
$base=Join-Path $root $p.token
$state=Read-SBState (Join-Path $base 'state.json')
if($state.status -cne 'committed' -or -not (Test-SBEqual $state.spec $p.spec)){throw 'Untrusted committed transaction'}
if(-not (Test-SBEqual (Get-SBSnapshot $p.spec) $p.expected)){throw 'Object changed before withdrawal'}
if(-not (Test-SBEqual $state.before $p.before)){throw 'Before-state differs from authenticated ledger'}
$state.status='applied'
Restore-SBOwned $state $p.spec $p.token $base $root
ConvertTo-Json -InputObject (Get-SBSnapshot $p.spec) -Depth 32 -Compress
"""
        return powershell_json(source, target)

    def snapshot(self, target):
        return self._request(target, 'snapshot')

    def matches_pre(self, before, after):
        if isinstance(before, dict) and 'sitePresent' in before:
            before = {k: v for k, v in before.items() if k != 'configuration'}
            after = {k: v for k, v in after.items() if k != 'configuration'}
        return semantic(before) == semantic(after)

    def restore(self, target, before, expected):
        if self.snapshot(target) != expected:
            raise OwnershipConflict('Windows setup object changed after Sentinel')
        result = self._request(dict(target, before=before, expected=expected), 'restore')
        # IIS owns a narrow site, pool, binding and content. The whole config
        # hash is a conservative conflict guard, never a whole-config inverse.
        compare_before, compare_result = copy.deepcopy(before), copy.deepcopy(result)
        if target['spec']['recipe'] == 'windows-iis':
            compare_before.pop('configuration', None)
            compare_result.pop('configuration', None)
        if semantic(compare_result) != semantic(compare_before):
            raise LedgerError('Windows setup inverse failed exact validation')
        return result
