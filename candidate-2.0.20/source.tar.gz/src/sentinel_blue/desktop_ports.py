"""Beginner-facing port editor. Produces reviewed data, never runs setup."""
from __future__ import annotations
import copy

from .service_ports import capability, fields_for, port_text, resolve_ports
from .linux_service_catalog import CATALOG


class PortEditor:
    def __init__(self, parent, widgets, service_id, options, *, on_save, context_provider=None,
                 saved_choices=None):
        self.tk, self.ttk = widgets
        self.service_id, self.options = service_id, copy.deepcopy(options)
        self.on_save, self.context_provider = on_save, context_provider
        self.initial_context = self._context()
        self.window = self.tk.Toplevel(parent)
        self.window.title("Service ports — " + CATALOG[service_id]["label"])
        self.window.geometry("790x580")
        self.window.minsize(680, 480)
        self.window.transient(parent.winfo_toplevel())
        background = self.ttk.Style(self.window).lookup("TFrame", "background") or self.window.cget("background")
        self.window.configure(background=background)
        self.window.protocol("WM_DELETE_WINDOW", self.close)
        self.rows = {}
        self.result = None
        self.error = self.tk.StringVar(master=self.window, value="")
        self.explanation = self.tk.StringVar(master=self.window, value="")
        self.alternate = self.tk.BooleanVar(master=self.window, value=False)
        # Reserve the controls before the variable-height content. Long mail
        # configurations remain reachable at small desktop resolutions.
        footer = self.ttk.Frame(self.window)
        footer.pack(side="bottom", fill="x", padx=16, pady=14)
        self.save_button = self.ttk.Button(footer, text="Save port choices", command=self.save)
        self.save_button.pack(side="left")
        self.ttk.Button(footer, text="Preview choices", command=self.preview).pack(side="left", padx=8)
        self.ttk.Button(footer, text="Cancel", command=self.close).pack(side="right")
        holder = self.ttk.Frame(self.window)
        holder.pack(fill="both", expand=True)
        self.canvas = self.tk.Canvas(holder, highlightthickness=0, background=background)
        scrollbar = self.ttk.Scrollbar(holder, orient="vertical", command=self.canvas.yview)
        scrollbar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.canvas.configure(yscrollcommand=scrollbar.set)
        self.body = self.ttk.Frame(self.canvas)
        item = self.canvas.create_window((0, 0), window=self.body, anchor="nw")
        self.body.bind("<Configure>", lambda _event: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda event: self.canvas.itemconfigure(item, width=event.width))
        info = capability(service_id, options)
        self.ttk.Label(self.body, text=CATALOG[service_id]["label"], font=("TkDefaultFont", 14, "bold")).pack(anchor="w", padx=16, pady=(14, 5))
        self.ttk.Label(self.body, text=info["reason"], wraplength=735, justify="left").pack(anchor="w", padx=16)
        self.ttk.Label(self.body, text="Automatic keeps a required or configured port, otherwise uses the standard. "
                       "Manual lets you type a number. Saving does not change the server.",
                       wraplength=735, justify="left").pack(anchor="w", padx=16, pady=8)
        table = self.ttk.Frame(self.body)
        table.pack(fill="x", padx=16, pady=8)
        for col, title in enumerate(("Connection", "Selection", "Port number", "Standard")):
            self.ttk.Label(table, text=title).grid(row=0, column=col, sticky="w", padx=5, pady=5)
        saved_choices = saved_choices or {}
        for index, field in enumerate(fields_for(service_id, options), 1):
            old = saved_choices.get(field.key, {})
            mode = self.tk.StringVar(master=self.window, value="Manual" if old.get("mode") == "manual" else "Automatic")
            value = self.tk.StringVar(master=self.window, value=str(options.get(field.key, field.default)))
            self.ttk.Label(table, text=field.label, wraplength=280).grid(row=index, column=0, sticky="w", padx=5, pady=5)
            selector = self.ttk.Combobox(table, values=("Automatic", "Manual"), state="readonly", width=12, textvariable=mode)
            selector.grid(row=index, column=1, sticky="ew", padx=5, pady=5)
            box = self.ttk.Entry(table, width=10, textvariable=value)
            box.grid(row=index, column=2, sticky="w", padx=5, pady=5)
            self.ttk.Label(table, text=str(field.default)).grid(row=index, column=3, sticky="w", padx=5, pady=5)
            self.rows[field.key] = {"mode": mode, "value": value, "box": box, "selector": selector}
            selector.bind("<<ComboboxSelected>>", lambda _event: self.preview())
            box.bind("<KeyRelease>", lambda _event: self.preview())
        table.columnconfigure(0, weight=1)
        self.ttk.Checkbutton(self.body, variable=self.alternate,
            text="Allow an alternate only for a service observed absent (requires recent host data)",
            command=self.preview).pack(anchor="w", padx=16, pady=5)
        self.ttk.Label(self.body, textvariable=self.explanation, wraplength=735, justify="left").pack(anchor="w", padx=16, pady=8)
        self.ttk.Label(self.body, textvariable=self.error, wraplength=735, justify="left", foreground="#a21d25").pack(anchor="w", padx=16, pady=5)
        self.preview()

    def _context(self):
        context = self.context_provider() if self.context_provider else {}
        if not isinstance(context, dict):
            raise ValueError("Port context is unavailable.")
        return context

    def choices(self):
        result = {}
        for key, row in self.rows.items():
            if row["mode"].get() == "Manual":
                result[key] = {"mode": "manual", "port": port_text(row["value"].get())}
            else:
                result[key] = {"mode": "auto"}
        return result

    def preview(self):
        for row in self.rows.values():
            row["box"].configure(state="normal" if row["mode"].get() == "Manual" else "readonly")
        try:
            context = self._context()
            if context.get("host") != self.initial_context.get("host"):
                raise ValueError("The selected host changed. Close this dialog and review ports on that host.")
            if context.get("configuration_digest") != self.initial_context.get("configuration_digest"):
                raise ValueError("Service parameters changed. Close this dialog and review the updated settings.")
            options, report = resolve_ports(self.service_id, self.options, self.choices(),
                required=context.get("required"), reserved=context.get("reserved"),
                observation=context.get("observation"), allow_alternates=self.alternate.get(),
                service_presence=context.get("service_presence", "unknown"))
            self.result = options, report
            for decision in report["decisions"]:
                if decision["mode"] == "auto":
                    self.rows[decision["key"]]["value"].set(str(decision["port"]))
            lines = [f"{row['label']}: {row['port']} — {row['reason']}" for row in report["decisions"]]
            if not report["listener_data_current"]:
                lines.append("No current complete listener inventory: suggested ports are NOT verified free.")
            lines.append(context.get("notice", ""))
            lines.append("Firewall rules, scoring checks and other clients are not silently rewritten. Setup will refuse an inconsistent approved port.")
            self.explanation.set("\n".join(x for x in lines if x))
            self.error.set("")
            self.save_button.configure(state="normal")
        except (ValueError, TypeError, KeyError, OSError) as exc:
            self.result = None
            self.error.set(str(exc))
            self.save_button.configure(state="disabled")

    def save(self):
        self.preview()  # current host/context and literal final values, not stale preview
        if self.result is None:
            return
        options, report = self.result
        try:
            self.on_save(options, report, self.choices())
        except (ValueError, TypeError, KeyError, OSError) as exc:
            self.error.set(str(exc))
            return
        self.close()

    def close(self):
        window = self.window
        if window is None:
            return
        try:
            if window.winfo_exists():
                window.destroy()
        except self.tk.TclError:
            pass  # Parent may already have destroyed the interpreter on this GUI thread.
        finally:
            self.rows.clear()
            self.error = self.explanation = self.alternate = None
            self.save_button = None
            self.canvas = self.body = None
            self.on_save = self.context_provider = None
            self.window = None
