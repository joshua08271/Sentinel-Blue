"""Linux service parameters collected as fields, file pickers and small tables."""
from __future__ import annotations
import copy
import hashlib
import json
from pathlib import Path
import uuid

# label/type/default. Empty text fields are omitted, letting the recipe state
# which genuinely required input is missing. The recipe remains authoritative.
def field(label, kind='text', default=''):
    return (label, kind, default)


SCHEMAS = {
 'nginx': {'name': field('Site name', default='sentinel-site'),
    'listen_address': field('Listen address', default='0.0.0.0'),
    'content': field('Website index HTML file', 'source'),
    'tls_certificate': field('TLS certificate file (optional)', 'source'),
    'tls_key': field('TLS private key file (optional)', 'source')},
 'apache2': {'server_name': field('Server / domain name'), 'document_root': field('Website directory on target'),
    'listen_address': field('Listen address', default='0.0.0.0'), 'manage_listener': field('Add the listening directive', 'bool', False),
    'tls_certificate_path': field('Certificate path on target'), 'tls_key_path': field('Private key path on target')},
 'openssh-server': {'permit_root_login': field('Allow root login', 'bool', False),
    'password_authentication': field('Allow password login', 'bool', True),
    'allow_users': field('Allowed users (one per line)', 'list'), 'allow_groups': field('Allowed groups (one per line)', 'list'),
    'sftp_only_group': field('SFTP-only group (optional)')},
 'mariadb': {'bind_address': field('Listen address', default='127.0.0.1'), 'require_tls': field('Require TLS', 'bool', False)},
 'postgresql': {'config_directory': field('Cluster configuration directory, e.g. /etc/postgresql/16/main'),
    'listen_addresses': field('Listen addresses (one per line)', 'list', ['127.0.0.1']),
    'allowed_networks': field('Allowed client networks (one CIDR per line)', 'list'),
    'auth_method': field('Authentication method', 'choice:scram-sha-256|md5|cert', 'scram-sha-256'),
    'ssl_certificate_path': field('Certificate path on target'), 'ssl_key_path': field('Private key path on target'),
    'ssl_ca_path': field('CA certificate path on target')},
 'redis': {'bind_address': field('Listen address', default='127.0.0.1'),
    'protected_mode': field('Protected mode', 'bool', True), 'acl_file': field('ACL path on target'),
    'acl_sha256': field('Expected SHA-256 of ACL file')},
 'bind9': {'zone': field('DNS zone'), 'mode': field('Zone mode', 'choice:create-owned|adopt-existing', 'create-owned'),
    'soa_mname': field('Primary nameserver hostname'), 'soa_rname': field('SOA contact hostname (optional)'),
    'records': field('Records: name, type, value, optional MX priority — one per line', 'records'),
    'allow_query': field('Allowed query networks (one per line)', 'list', ['127.0.0.0/8']),
    'allow_transfer': field('Allowed transfer networks (one per line)', 'list', ['none']),
    'zone_file': field('Existing zone path on target (adopt mode)'), 'zone_sha256': field('Existing zone SHA-256 (adopt mode)'),
    'listener_config': field('named.conf.options snapshot for port changes', 'source')},
 'unbound': {'interface': field('Listen IP address', default='127.0.0.1'),
    'access_control': field('Allowed query networks (one per line)', 'list', ['127.0.0.0/8']),
    'forwarders': field('Forwarder IP addresses (one per line)', 'list')},
 'dnsmasq': {'interface': field('Network interface', default='lo'), 'domain': field('DNS domain'),
    'addresses': field('DNS records: hostname = IP address — one per line', 'mapping'),
    'no_dhcp': field('Keep DHCP disabled', 'bool', True)},
 'isc-dhcp-server': {'subnet': field('Network address'), 'netmask': field('Network mask'),
    'range_start': field('First leased address'), 'range_end': field('Last leased address'),
    'routers': field('Router IPs (one per line)', 'list'), 'dns_servers': field('DNS server IPs (one per line)', 'list'),
    'lease_seconds': field('Lease duration in seconds', 'int', 3600),
    'authorized': field('This DHCP server is explicitly authorized on this segment', 'bool', False)},
 'chrony': {'sources': field('Approved time sources (one per line)', 'list'),
    'allow': field('Allowed client networks (one per line)', 'list')},
 'postfix': {'myhostname': field('Mail server hostname'), 'mydomain': field('Mail domain'),
    'mynetworks': field('Trusted relay networks (one CIDR per line)', 'list', ['127.0.0.0/8']),
    'message_size_limit': field('Maximum message size in bytes', 'int', 10240000),
    'main_config': field('Current main.cf snapshot', 'source'), 'master_config': field('Current master.cf snapshot', 'source'),
    'smtp_listener': field('Existing SMTP listener name', default='smtp')},
 'dovecot': {'protocols': field('Protocols (imap, pop3, lmtp, submission): one per line', 'list', ['imap']),
    'mail_location': field('Mailbox location'), 'ssl_certificate_path': field('Certificate path on target'),
    'ssl_key_path': field('Private key path on target')},
 'vsftpd': {'anonymous_enable': field('Allow anonymous login', 'bool', False),
    'local_enable': field('Allow local accounts', 'bool', True), 'write_enable': field('Allow uploads', 'bool', False),
    'chroot_local_user': field('Confine local users to their home', 'bool', True),
    'ssl_enable': field('Require encrypted logins and data', 'bool', False), 'rsa_cert_file': field('Certificate path on target')},
 'samba': {'share': field('Share name'), 'path': field('Shared directory on target'),
    'valid_users': field('Allowed users (one per line)', 'list'), 'read_only': field('Read only', 'bool', True),
    'browseable': field('Visible in browse lists', 'bool', True), 'create_mask': field('File permissions', default='0644'),
    'directory_mask': field('Directory permissions', default='0755')},
 'nfs-server': {'export_path': field('Exported directory'), 'clients': field('Allowed client networks (one per line)', 'list'),
    'read_only': field('Read only', 'bool', True), 'squash': field('Identity mapping', 'choice:root_squash|all_squash|no_root_squash', 'root_squash')},
 'haproxy': {'main_config': field('Current haproxy.cfg snapshot (merge into active main config)', 'source'),
    'mode': field('Proxy protocol', 'choice:http|tcp', 'http'),
    'backends': field('Backends: IP address, port — one per line', 'backends')},
 'rsyslog': {'forward_to': field('Destination server IP'), 'protocol': field('Transport', 'choice:tcp|udp', 'tcp'),
    'facility': field('Facility selector', default='*.*')},
 'mosquitto': {'bind_address': field('Listen IP', default='127.0.0.1'),
    'allow_anonymous': field('Allow anonymous clients (loopback only)', 'bool', False),
    'password_file': field('MQTT password file path on target')},
 'gunicorn': {'application': field('Python application, e.g. app:application'),
    'working_directory': field('Application directory'), 'user': field('Service account'),
    'bind_address': field('Listen address', default='127.0.0.1'), 'workers': field('Worker processes', 'int', 2)},
}

COMMON = {'previous_sha256': field('Current file being replaced (choose it to record its checksum)', 'digest'),
          'previous_files': field('Existing files: target path = SHA-256 or absent — one per line', 'mapping'),
          'activation': field('Parent configuration snapshots (choose current files)', 'snapshots')}


def display_value(kind, value):
    if kind == 'source':
        return value.get('path', '') if isinstance(value, dict) else ''
    if kind == 'snapshots':
        return '\n'.join(value) if isinstance(value, dict) else ''
    if kind == 'list':
        return '\n'.join(str(x) for x in value) if isinstance(value, list) else str(value)
    if kind == 'mapping':
        return '\n'.join(f'{k} = {v}' for k, v in value.items()) if isinstance(value, dict) else str(value)
    if kind == 'backends':
        return '\n'.join(f"{r['address']}, {r['port']}" for r in value) if isinstance(value, list) else str(value)
    if kind == 'records':
        return '\n'.join(', '.join(str(r[k]) for k in ('name', 'type', 'value', 'priority') if k in r) for r in value) if isinstance(value, list) else str(value)
    return str(value)


def parse_value(kind, value):
    if kind == 'bool':
        return bool(value)
    value = value.strip()
    if not value:
        return None
    if kind == 'int':
        if not value.isascii() or not value.isdigit():
            raise ValueError('Enter a whole positive number.')
        return int(value)
    if kind == 'list':
        return [x.strip() for x in value.splitlines() if x.strip()]
    if kind == 'mapping':
        result = {}
        for line in value.splitlines():
            key, sep, val = line.partition('=')
            if not sep or not key.strip() or key.strip() in result:
                raise ValueError('Use one unique name = value per line.')
            result[key.strip()] = val.strip()
        return result
    if kind in {'backends', 'records'}:
        result = []
        for line in value.splitlines():
            row = [x.strip() for x in line.split(',')]
            if kind == 'backends':
                if len(row) != 2:
                    raise ValueError('Each backend needs IP address, port.')
                result.append({'address': row[0], 'port': parse_value('int', row[1])})
            else:
                if len(row) not in {3, 4}:
                    raise ValueError('Each DNS record needs name, type, value, and optionally MX priority.')
                result.append(dict(zip(('name', 'type', 'value'), row[:3]), **({'priority': parse_value('int', row[3])} if len(row) == 4 else {})))
        return result
    return value


def snapshot_file(path, directory):
    """Copy an operator-selected file into private storage and pin those bytes."""
    from .credential_vault import private_directory
    from .state import _atomic_bytes
    source = Path(path)
    if not source.is_file() or source.stat().st_size > 1024 * 1024:
        raise ValueError('Choose a text file no larger than 1 MiB.')
    data = source.read_bytes()
    if len(data) > 1024 * 1024 or '\x00' in data.decode('utf-8'):
        raise ValueError('Choose a UTF-8 text file without NUL characters.')
    directory = Path(directory)/'form-inputs'
    guard = private_directory(directory)
    try:
        target = directory/(uuid.uuid4().hex + '.txt')
        _atomic_bytes(target, data)
        return {'path': str(target.absolute()), 'sha256': hashlib.sha256(data).hexdigest()}
    finally:
        if guard:
            guard.close()


class ServiceForm:
    def __init__(self, panel, sid):
        from tkinter import filedialog, messagebox
        from .linux_service_catalog import CATALOG
        self.panel, self.sid = panel, sid
        self.tk, self.ttk = panel.tk, panel.ttk
        self.original = copy.deepcopy(panel.options.get(sid, {}))
        self.sources = {key: copy.deepcopy(value) for key, value in self.original.items()
                        if key == 'activation' or isinstance(value, dict) and set(value) == {'path', 'sha256'}}
        self.window = self.tk.Toplevel(panel.tree)
        self.window.title('Configure ' + CATALOG[sid]['label'])
        self.window.geometry('800x650'); self.window.minsize(650, 480)
        footer = self.ttk.Frame(self.window, padding=12); footer.pack(side='bottom', fill='x')
        self.ttk.Button(footer, text='Validate & save', command=self.save).pack(side='left')
        self.ttk.Button(footer, text='Cancel', command=self.window.destroy).pack(side='right')
        self.error = self.tk.StringVar(value='Use Ports for manual or automatic port choices. Saving does not change services.')
        self.ttk.Label(footer, textvariable=self.error, wraplength=540).pack(side='left', padx=10)
        canvas = self.tk.Canvas(self.window, highlightthickness=0, background='#101923')
        bar = self.ttk.Scrollbar(self.window, orient='vertical', command=canvas.yview)
        bar.pack(side='right', fill='y'); canvas.pack(fill='both', expand=True)
        canvas.configure(yscrollcommand=bar.set)
        body = self.ttk.Frame(canvas, padding=16)
        item = canvas.create_window((0, 0), window=body, anchor='nw')
        body.bind('<Configure>', lambda _: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>', lambda e: canvas.itemconfigure(item, width=e.width))
        body.columnconfigure(0, weight=1)
        schema = dict(SCHEMAS.get(sid, {}))
        if sid != 'nginx':
            schema.update(COMMON)
        else:
            for key in ('previous_content_sha256', 'previous_config_sha256', 'previous_certificate_sha256', 'previous_key_sha256'):
                schema[key] = field(key.replace('_', ' ').capitalize())
        self.schema, self.inputs = schema, {}
        advanced = self.ttk.Frame(body)
        self.advanced_visible = self.tk.BooleanVar(value=False)
        normal_count = len(schema) - (len(COMMON) if sid != 'nginx' else 4)
        def toggle_advanced():
            if self.advanced_visible.get(): advanced.grid(row=normal_count*2+1, column=0, sticky='ew')
            else: advanced.grid_remove()
        self.ttk.Checkbutton(body, text='Review existing configuration / advanced file settings',
            variable=self.advanced_visible, command=toggle_advanced).grid(row=normal_count*2, column=0, sticky='w', pady=16)
        advanced.columnconfigure(0, weight=1)
        for i, (key, (label, kind, default)) in enumerate(schema.items()):
            value = self.original.get(key, default)
            parent = body if i < normal_count else advanced
            row_index = i*2 if i < normal_count else (i-normal_count)*2
            self.ttk.Label(parent, text=label, wraplength=690).grid(row=row_index, column=0, sticky='w', pady=(9, 2))
            if kind == 'bool':
                variable = self.tk.BooleanVar(value=bool(value))
                self.ttk.Checkbutton(parent, text='Enabled', variable=variable).grid(row=row_index+1, column=0, sticky='w')
            elif kind in {'list', 'mapping', 'backends', 'records'}:
                line = self.ttk.Frame(parent); line.grid(row=row_index+1, column=0, sticky='ew')
                widget = self.tk.Text(line, height=3, wrap='word', background='#172636', foreground='#edf3f8', insertbackground='white')
                widget.insert('1.0', display_value(kind, value)); widget.pack(side='left', fill='x', expand=True)
                if key == 'previous_files':
                    def previous_files(w=widget):
                        names = filedialog.askopenfilenames(parent=self.window)
                        try:
                            current = parse_value('mapping', w.get('1.0', 'end')) or {}
                            for name in names:
                                current[str(Path(name).absolute())] = snapshot_file(name, panel.options_root)['sha256']
                            w.delete('1.0', 'end'); w.insert('1.0', display_value('mapping', current))
                        except (ValueError, OSError, UnicodeError) as exc:
                            messagebox.showerror('File needs attention', str(exc), parent=self.window)
                    self.ttk.Button(line, text='Choose files…', command=previous_files).pack(side='left', padx=6)
                variable = widget
            else:
                variable = self.tk.StringVar(value=display_value(kind, value))
                row = self.ttk.Frame(parent); row.grid(row=row_index+1, column=0, sticky='ew')
                if kind.startswith('choice:'):
                    self.ttk.Combobox(row, textvariable=variable, values=kind.split(':', 1)[1].split('|'), state='readonly').pack(fill='x', expand=True)
                else:
                    self.ttk.Entry(row, textvariable=variable, state='readonly' if kind in {'source', 'snapshots'} else 'normal').pack(side='left', fill='x', expand=True)
                if kind in {'source', 'snapshots'}:
                    def browse(k=key, v=variable, t=kind):
                        names = filedialog.askopenfilenames(parent=self.window) if t == 'snapshots' else [filedialog.askopenfilename(parent=self.window)]
                        if not names or not names[0]: return
                        try:
                            if t == 'source': self.sources[k] = snapshot_file(names[0], panel.options_root)
                            else:
                                self.sources[k] = {str(Path(n).absolute()): snapshot_file(n, panel.options_root) for n in names}
                            v.set(display_value(t, self.sources[k]))
                        except (ValueError, OSError, UnicodeError) as exc:
                            messagebox.showerror('File needs attention', str(exc), parent=self.window)
                    self.ttk.Button(row, text='Choose file(s)…', command=browse).pack(side='left', padx=6)
                    def clear(k=key, v=variable):
                        self.sources.pop(k, None); v.set('')
                    self.ttk.Button(row, text='Clear', command=clear).pack(side='left')
                elif kind == 'digest':
                    def digest(v=variable):
                        name = filedialog.askopenfilename(parent=self.window)
                        if name:
                            try: v.set(snapshot_file(name, panel.options_root)['sha256'])
                            except (ValueError, OSError, UnicodeError) as exc:
                                messagebox.showerror('File needs attention', str(exc), parent=self.window)
                    self.ttk.Button(row, text='Choose current file…', command=digest).pack(side='left', padx=6)
            self.inputs[key] = variable

    def save(self):
        from .setup_recipes import compile_recipe
        options = copy.deepcopy(self.original)
        try:
            for key, (_label, kind, _default) in self.schema.items():
                variable = self.inputs[key]
                if kind in {'source', 'snapshots'}:
                    value = self.sources.get(key)
                else:
                    raw = variable.get('1.0', 'end') if isinstance(variable, self.tk.Text) else variable.get()
                    value = parse_value(kind, raw)
                if value is None or value == {}:
                    options.pop(key, None)
                else:
                    options[key] = value
            from .service_ports import fields_for
            active_fields = fields_for(self.sid, options)
            if self.sid == 'dovecot':
                # Hidden port fields belong to a protocol/TLS selection. Retain
                # custom values only for listeners which remain enabled.
                valid_ports = {f.key for f in active_fields}
                for key in ('imap_port', 'imaps_port', 'pop3_port', 'pop3s_port',
                            'submission_port', 'submissions_port'):
                    if key not in valid_ports:
                        options.pop(key, None)
            for f in active_fields:
                options.setdefault(f.key, f.default)
            recipe = 'linux-nginx' if self.sid == 'nginx' else 'linux-service-pack'
            actual = dict(options, manager='apt')
            if self.sid != 'nginx': actual['catalog_id'] = self.sid
            compile_recipe(recipe, actual, self.panel.options_root, 'linux')
        except (ValueError, TypeError, KeyError, OSError) as exc:
            self.error.set('Needs your input: ' + str(exc)[:400]); return
        self.panel.options[self.sid] = options
        self.panel.port_requirements.pop(self.sid, None)
        if self.sid not in self.panel.selection:
            self.panel.selection.append(self.sid)
        self.panel.refresh()
        self.window.destroy()


def response_explanation(row):
    """Plain language above raw evidence; no guessed approval reasons."""
    detail = row.get('detail') or {}
    reason = next((detail.get(k) for k in ('reason', 'summary', 'description') if isinstance(detail.get(k), str) and detail.get(k)), '')
    kind = row.get('kind')
    if kind == 'baseline':
        blockers = detail.get('baseline_readiness', {}).get('blockers', [])
        if blockers:
            return (reason or '; '.join(str(x) for x in blockers),
                    'Wait for setup and fresh service checks to finish. Resolve any reported failures, then refresh before approving.')
        return ('Sentinel needs your confirmation that the initial inventory is an acceptable recovery baseline.',
                'Review the host and services, then approve only if this is the state you want to preserve.')
    if kind == 'outcome':
        return (reason or 'The previous connection ended without a confirmed result.',
                'Check the affected service and say whether the action actually ran. This avoids an unsafe duplicate change.')
    if kind == 'undo-review':
        return (reason or 'An undo failed after it had begun changing the host, so Resume of this service is held.',
                'Check the service and its files. Once the agent reports no interrupted change, mark it reviewed; '
                'automatic recovery can then be resumed.')
    if kind == 'external-check':
        return (reason or 'An independent service check is failing or its evidence is stale.',
                'Check service reachability and the observer connection; refresh after correcting the cause.')
    action = str(detail.get('recommended_action', '')).replace('_', ' ')
    return (reason or 'Review the recorded evidence before deciding whether a change is appropriate.',
            ('Recommended: ' + action + '. ' if action else '') + 'Approve the recommendation, observe without changing anything, or reject it.')
