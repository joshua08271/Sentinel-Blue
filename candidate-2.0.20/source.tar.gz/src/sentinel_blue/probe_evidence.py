"""Shared three-state probe evidence used by repair decisions and attestations.

An unavailable or malformed observation is neither healthy nor a service fault.
Legacy wire rows may omit ``executed``; validation has always defaulted that
field to True. An explicit False (or an invalid type) must never prove success
or justify stopping a running service.
"""
from __future__ import annotations

from typing import Any
from .protocol import ProbeResult


def _field(row: Any, name: str, default: Any = None) -> Any:
    if isinstance(row, dict):
        return row.get(name, default)
    if isinstance(row, ProbeResult):
        return getattr(row, name, default)
    return default


def probe_verdict(row: Any) -> bool | None:
    """Return True for measured success, False for measured failure, else None."""
    healthy = _field(row, "healthy")
    if _field(row, "executed", True) is not True or type(healthy) is not bool:
        return None
    return healthy


def probe_name(spec: Any) -> Any:
    """The name a check is reported under when its specification names none.

    That is its target, plus its port when the port is a separate field. Found
    live on 2.0.6: Redis and PostgreSQL were both checked by TCP on 127.0.0.1,
    both checks were reported as "127.0.0.1", neither could be told apart, and
    both services stayed "unverified", so the baseline could never be approved.
    The agent and every reader of its results use this one function.
    """
    if not isinstance(spec, dict):
        return None
    if "name" in spec:
        return spec["name"]
    target, port = spec.get("target"), spec.get("port")
    if isinstance(target, str) and type(port) is int and "://" not in target:
        host = f"[{target}]" if ":" in target and not target.startswith("[") else target
        return f"{host}:{port}"
    return target


def _identity(row: Any, *, specification: bool = False) -> tuple[str, str] | None:
    target = _field(row, "target")
    name = probe_name(row) if specification else _field(row, "name")
    if not isinstance(target, str) or not isinstance(name, str):
        return None
    return name, target


def matching_probe_health(specs: list[dict[str, Any]], rows: Any,
                          *, exact: bool = False) -> list[bool | None]:
    """Match each declared probe once; missing, duplicate or invalid rows are unknown.

    Telemetry may contain unrelated observations. Executor batches instead use
    ``exact=True`` and must contain precisely the requested identities. Matching
    does not depend on completion order. Bounds mirror the current probe and
    telemetry budgets; exceeding them is missing evidence, not a partial pass.
    """
    # `rows` arrive from the wire and are already treated as untrusted. `specs`
    # come from a guard or a manifest, which are validated upstream - but this is
    # the shared surface every repair decision now passes through, so it does not
    # rely on that. A malformed contract is missing evidence, never a pass.
    if not isinstance(specs, (list, tuple)):
        return []
    unknown: list[bool | None] = [None for _ in specs]
    if (len(specs) > 256 or not isinstance(rows, (list, tuple)) or len(rows) > 1024
            or (exact and len(rows) != len(specs))):
        return unknown
    expected = [_identity(spec, specification=True) for spec in specs]
    if any(key is None for key in expected) or len(set(expected)) != len(expected):
        return unknown
    grouped: dict[tuple[str, str], list[Any]] = {}
    for row in rows:
        key = _identity(row)
        if key is None:
            if exact:
                return unknown
            continue
        grouped.setdefault(key, []).append(row)
    if exact and set(grouped) != set(expected):
        return unknown
    return [probe_verdict(grouped[key][0]) if len(grouped.get(key, [])) == 1 else None
            for key in expected]


def all_probes_healthy(specs: list[dict[str, Any]], rows: Any,
                       *, allow_empty: bool = False) -> bool:
    """Every requested transaction must have a matching, executed success.

    An empty contract is the trap here: with nothing declared there is nothing to
    fail, so a naive `all()` reports healthy on no evidence at all. Callers that
    need application evidence get the safe answer by default - an empty contract
    is False. A caller for which "nothing declared" genuinely means "nothing to
    check", such as restoring a file that declares no probes, says so explicitly
    with ``allow_empty=True`` rather than relying on a subtlety.
    """
    if not isinstance(specs, (list, tuple)) or not isinstance(rows, (list, tuple)):
        return False
    if not specs:
        return bool(allow_empty) and not rows
    if len(rows) != len(specs):
        return False
    return all(value is True for value in matching_probe_health(specs, rows, exact=True))
