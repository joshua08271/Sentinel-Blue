"""Linux-only graphical first-run workflow; Windows keeps its existing UI."""
from __future__ import annotations
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import uuid

from .state import read_private_json, write_private_json


def plan_description(plan, baseline_files=(), repair_coverage=None, autonomy='approval-based'):
    lines = ['Review changes to this Linux VM', '',
             'Only the selected services below are included. The existing setup engine validates each change and retains its rollback evidence.', '']
    for task in plan['tasks']:
        opts = task['configuration']
        ports = [f'{k.replace("_", " ")}: {v}' for k, v in opts.items() if k == 'port' or k.endswith('_port')]
        lines += [task['id'].removeprefix('sentinel-') + ' · ' + task['host'],
                  '  ' + ('Generate configuration and start the service' if task['recipe'] != 'linux-service' else 'Start/adopt existing service; retain its configuration'),
                  '  ' + (', '.join(ports) if ports else 'Retain the current listener configuration'),
                  '  Verification: ' + ', '.join(str(p.get('kind', 'unknown')) for p in task['probes']), '']
    lines += ['Baseline approval saves private backups of monitored configuration files. '
              'Use Withdraw to review restoring changes made during setup.']
    if repair_coverage:
        when = ('A failed service is repaired automatically; every repair is journaled and rolled back if its check fails. '
                'If Sentinel\'s own controller stops unexpectedly, it restarts in this approved mode; a saved Pause stays paused.'
                if autonomy == 'guarded-autonomous' else
                'A failed service is offered for repair on Recovery; nothing is restored until you approve it.')
        lines += ['', 'Repair: restore the files below from that backup, re-enable the unit (including from a mask), '
                  'restart it and validate it with its check. ' + when,
                  'Host-wide files (accounts, sudo, SSH keys) are monitored and alerted on, never restored by a service repair.',
                  'If a repair cannot fix a service, redo its approved setup from Recovery.', '']
        for unit, coverage in sorted(repair_coverage.items()):
            lines.append('  ' + unit + ': ' + (str(len(coverage['restorable'])) + ' file(s) restorable'
                                                if coverage['restorable'] else 'unit state and restart only'))
            lines += ['    ' + path for path in coverage['restorable']]
            for warning in coverage.get('discovery_issues', []):
                lines.append('    WARNING: ' + warning)
            if coverage.get('alert_only'):
                lines.append('    beyond the 16-file repair limit, alert only: ' + ', '.join(coverage['alert_only']))
    if baseline_files:
        lines += ['', 'Files included in baseline backup review:', *('  ' + path for path in baseline_files), '']
    lines += ['Native server software must already be installed. Sentinel includes its Python runtime, not every server package.',
              'TCP checks establish listener reachability only. Use application checks for login, database or scoring acceptance.',
              'This creates a local lab profile. It does not claim competition approval or external reachability.']
    return '\n'.join(lines)


class LinuxSetupControls:
    def _linux_start(self):
        from .linux_workspace import is_proxmox_host
        self.local_workspace = None
        self.local_session_process = None
        self.local_wizard_busy = False
        self.local_checks = {}
        self.local_ports = None
        self.local_selection_digest = None
        self.local_status = self.tk.StringVar(value='Choose services, review the changes, then start local setup.')
        self.local_context = self.tk.BooleanVar(value=True)
        self.local_autonomy = self.tk.StringVar(value='approval-based')
        tab = self.tabs['Start here']
        self.ttk.Label(tab, text='Set up this Linux VM', style='Title.TLabel').pack(anchor='w')
        self.ttk.Label(tab, text='Use this window for setup, service health, alerts, credentials and recovery. '
            'Download and open Sentinel inside the Linux VM desktop shown in the Proxmox console.',
            wraplength=790).pack(anchor='w', pady=(8, 14))
        self.ttk.Label(tab, textvariable=self.local_status, wraplength=790, style='Subtitle.TLabel').pack(anchor='w', pady=8)
        mode = self.ttk.Frame(tab); mode.pack(fill='x', pady=4)
        self.ttk.Label(mode, text='Recovery mode').pack(side='left')
        self.ttk.Combobox(mode, textvariable=self.local_autonomy, state='readonly',
            values=('approval-based', 'guarded-autonomous'), width=25).pack(side='left', padx=10)
        self.ttk.Label(mode, text='Automatic recovery still requires a reviewed baseline.', wraplength=410).pack(side='left')
        controls = self.ttk.Frame(tab); controls.pack(fill='x', pady=12)
        self.ttk.Button(controls, text='1  Choose services & ports', command=lambda: self.notebook.select(self.tabs['Service setup'])).pack(side='left')
        self.local_prepare_button = self.ttk.Button(controls, text='2  Review local setup', command=self.prepare_local_setup)
        self.local_prepare_button.pack(side='left', padx=8)
        second = self.ttk.Frame(tab); second.pack(fill='x', pady=4)
        self.ttk.Button(second, text='Refresh this VM’s service inventory', command=self.refresh_local_inventory).pack(side='left')
        self.ttk.Button(second, text='Reconnect saved local session', command=self.reconnect_local).pack(side='left', padx=8)
        self.ttk.Button(second, text='Stop local monitoring', command=self.stop_local_monitoring).pack(side='left')
        self.ttk.Separator(tab).pack(fill='x', pady=16)
        self.ttk.Label(tab, text='Already have a controller or competition inventory?', font=('Segoe UI', 13, 'bold')).pack(anchor='w')
        self.ttk.Label(tab, text='Use Connection to connect to it. Use Setup to import its inventory and approved event profile. '
            'Service choices then stay bound to that host and its required ports.', wraplength=790).pack(anchor='w', pady=8)
        network_controls = self.ttk.Frame(tab); network_controls.pack(fill='x')
        self.ttk.Button(network_controls, text='Use existing network / controller', command=self.use_existing_network).pack(side='left')
        self.ttk.Button(network_controls, text='Dedicated management…', command=self.dedicated_management).pack(side='left', padx=8)
        self.ttk.Button(network_controls, text='Join as agent…', command=lambda: self.dedicated_management(join=True)).pack(side='left')
        admin = 'Administrator access is active.' if os.geteuid() == 0 else 'Review is available. Applying changes requires administrator access.'
        self.ttk.Label(tab, text=admin, wraplength=790).pack(anchor='w', pady=(18, 6))
        if os.geteuid() != 0:
            self.ttk.Button(tab, text='Open as administrator…', command=self.open_as_administrator).pack(anchor='w')
        if is_proxmox_host():
            self.local_status.set('This is the Proxmox host. Open Sentinel in the Linux guest VM desktop to use local setup.')
            self.local_prepare_button.configure(state='disabled')
        self.service_panel.options_root = self.directory
        self.service_panel.observe({}, host='local-linux')
        self.refresh_local_inventory()
        self._restore_isolated_selection()

    def use_existing_network(self):
        self.local_context.set(False)
        self.notebook.select(self.tabs['Connection'])
        self.note('Connect to the existing controller, then select its host and load the approved inventory on Setup.')

    def refresh_local_inventory(self):
        from .linux_workspace import local_observation
        def ready(value):
            self.local_ports = value['observation']
            self.service_panel.local_addresses = tuple(value.get('addresses', ()))
            if self.local_context.get() and self.client is None:
                self.service_panel.observe(value['presence'], host='local-linux')
            self.local_status.set('Local inventory refreshed. Choose services and configure their parameters before reviewing setup.')
        self.submit(local_observation, ready)

    def _local_selection(self):
        from .setup import plan_digest
        return plan_digest({'selected': self.service_panel.selection, 'options': self.service_panel.options,
                            'custom': self.service_panel.custom_services,
                            'checks': self.local_checks, 'autonomy': self.local_autonomy.get()})

    def prepare_local_setup(self):
        from .linux_workspace import prepare_workspace, is_proxmox_host
        if getattr(self, 'isolated_role_path', None):
            self.note('A dedicated role is selected. Use its controls; do not create a combined local session.'); return
        if is_proxmox_host():
            self.note('Open Sentinel inside the guest VM desktop. Local setup is unavailable on the Proxmox host.'); return
        if self.local_wizard_busy or self.job_path is not None or self.setup_starting:
            self.note('Wait for the current preparation or setup job to finish.'); return
        if self.local_workspace is not None or self.client is not None:
            self.note('A controller session is already selected. Use the existing inventory and Setup review for further changes.'); return
        report = self.service_panel.report()
        if not report['ready']:
            self.note('Choose at least one service and resolve its parameter issues: ' + '; '.join(report['blocking'])[:350]); return
        selection = list(self.service_panel.selection)
        custom = copy.deepcopy(self.service_panel.custom_services)
        own_addresses = tuple(self.service_panel.local_addresses)
        options = copy.deepcopy(self.service_panel.options)
        presence = dict(self.service_panel.presence)
        checks = copy.deepcopy(self.local_checks)
        port_observation = copy.deepcopy(self.local_ports)
        runtime = self.runtime_path.get()
        autonomy = self.local_autonomy.get()
        digest = self._local_selection()
        self.local_wizard_busy = True
        self.local_status.set('Preparing local credentials, service checks and a reviewable plan…')
        def ready(result):
            self.local_wizard_busy = False
            config, plan = result
            if self._local_selection() != digest:
                self.note('Service choices changed during preparation. Review the new choices again.'); return
            self.local_workspace = config
            self.local_selection_digest = digest
            self.local_context.set(True)
            self.inventory_path.set(config['inventory']); self.profile_path.set(config['event_profile'])
            self.range_mode.set(True); self.setup_kind.set('setup')
            values = self._setup_values()
            self.plan = (values, plan)
            self.start_setup.configure(state='normal', text='3  Approve & start local setup')
            self._setup_report(plan_description(plan, config.get('baseline_capture_paths', ()),
                                                config.get('repair_coverage'), config.get('autonomy', autonomy)))
            self.notebook.select(self.tabs['Setup'])
            self.local_status.set('Plan prepared. Review it on Setup, then approve to start. No services have changed.')
        def failed(exc):
            self.local_wizard_busy = False
            self.local_status.set('Setup needs your input. ' + str(exc)[:300])
        if not self.submit(lambda: prepare_workspace(self.directory/'sessions', runtime, selection, options, presence, checks, autonomy, port_observation, custom, own_addresses), ready, failed):
            self.local_wizard_busy = False

    def start_local_session(self, continuation):
        from .desktop_jobs import detach
        from .linux_workspace import (client_for, activate_reviewed_session, require_available_local_ports,
                                      request_session_stop, session_runner_alive)
        from .job_control import SetupPaused
        if self.local_wizard_busy:
            self.note('Local startup is already in progress.'); return
        if self._local_selection() != self.local_selection_digest:
            self.note('Service choices changed after review. Discard the prepared plan and review again.'); return
        if os.geteuid() != 0:
            self.messagebox.showerror('Administrator access required',
                'Use Start here → Open as administrator, then review the plan in that window.', parent=self.root); return
        try:
            permit = self.job_control.permit(self.job_control.admit())
        except (OSError, ValueError, SetupPaused) as exc:
            self.note(str(exc)); return
        config = copy.deepcopy(self.local_workspace)
        generation = self.generation
        self.local_wizard_busy = True
        self.local_status.set('Starting the private controller and local agent…')
        # Every stop this launch writes names it, so it can never stop a later
        # start of the same session (2.0.18).
        launch_id = uuid.uuid4().hex
        def launch():
            directory = Path(config['directory'])
            first_start = not (directory/'session-status.json').exists()
            permit.checkpoint()
            require_available_local_ports(config)
            permit.checkpoint()
            process = detach(['linux-desktop-session', '--session', str(directory/'session.json'),
                              '--launch-id', launch_id])
            try:
                # The session may first stop processes an earlier run left
                # behind (up to ORPHAN_STOP_SECONDS) before starting its own.
                from .linux_workspace import ORPHAN_STOP_SECONDS
                deadline = time.monotonic() + 50 + ORPHAN_STOP_SECONDS
                while time.monotonic() < deadline:
                    permit.checkpoint()
                    try:
                        status = read_private_json(directory/'session-status.json', 4096)
                    except (OSError, ValueError):
                        status = {}
                    if not isinstance(status, dict):
                        status = {}
                    if status.get('launch_id') != launch_id:
                        # Written by an earlier run of this session (2.0.18): its
                        # "failed" or "running" says nothing about this launch,
                        # unless this launch's runner exited because that run
                        # still holds the session; then use it, as before.
                        if not (process.poll() is not None and status.get('state') == 'running'
                                and session_runner_alive(config)):
                            status = {}
                    if status.get('state') == 'running':
                        client = client_for(config)
                        client.dashboard()
                        if first_start:
                            activate_reviewed_session(config, client, permit.checkpoint)
                        write_private_json(self.directory/'last-local-session.json', {'path': str(directory/'session.json')})
                        return process, client
                    if status.get('state') == 'failed' or process.poll() is not None:
                        code = process.poll()
                        raise RuntimeError(status.get('reason') or 'The local session exited before readiness'
                                           + (f' (exit status {code}).' if code is not None else '.'))
                    time.sleep(.2)
                raise RuntimeError('Local startup timed out. Inspect the saved session before retrying.')
            except Exception:
                # Every failed startup has a bounded owner-driven stop path.
                request_session_stop(config, launch_id=launch_id)
                raise
        def ready(result):
            self.local_wizard_busy = False
            self.local_session_process, client = result
            try:
                permit.checkpoint()
            except SetupPaused as exc:
                request_session_stop(config, launch_id=launch_id)
                self.local_status.set('Startup stopped: ' + str(exc)); return
            if self.generation != generation:
                self.note('Local monitoring started while the window was locked or changed. Reconnect the saved session to continue setup.')
                return
            self.client = client
            self.origin.set(config['origin']); self.principal.set(config['principal'])
            self.ca_path.set(config['ca_file']); self.epoch.set(str(config['epoch']))
            self.generation += 1; self.next_poll = 0
            self.local_status.set('Local monitoring is running. Review alerts and baseline requests as they appear.')
            continuation()
        def failed(exc):
            self.local_wizard_busy = False
            self.local_status.set('Local startup needs attention: ' + str(exc)[:350])
        if not self.submit(launch, ready, failed, preserve=True):
            self.local_wizard_busy = False

    def reconnect_local(self):
        from .linux_workspace import client_for
        def reconnect():
            saved = read_private_json(self.directory/'last-local-session.json', 4096)
            config = read_private_json(saved['path'], 2*1024*1024)
            client = client_for(config)
            snapshot = client.dashboard()
            return config, client, snapshot
        def ready(result):
            config, self.client, snapshot = result
            self.local_workspace = config; self.local_context.set(True)
            self.inventory_path.set(config['inventory']); self.profile_path.set(config['event_profile'])
            self.runtime_path.set(config['runtime']); self.range_mode.set(True)
            self.service_panel.observe({}, host='local-linux')
            self.service_panel.selection = list(config['selection']); self.service_panel.options = copy.deepcopy(config['options'])
            self.service_panel.custom_services = copy.deepcopy(config.get('custom_services', []))
            self.service_panel.refresh()
            self.local_checks = copy.deepcopy(config.get('checks', {}))
            self.local_autonomy.set(config.get('autonomy', 'approval-based'))
            self.local_selection_digest = self._local_selection()
            self.origin.set(config['origin']); self.principal.set(config['principal']); self.ca_path.set(config['ca_file'])
            self.generation += 1; self.next_poll = 0
            self.render(snapshot); self.notebook.select(self.tabs['Services'])
            self.local_status.set('Reconnected to the saved running local session.')
        self.submit(reconnect, ready)

    def stop_local_monitoring(self):
        if not self.local_workspace:
            self.note('Reconnect to a saved local session first.'); return
        if self.job_path is not None or self.setup_starting or self.local_wizard_busy:
            self.note('Pause or finish the active setup job before stopping local monitoring.'); return
        if not self.messagebox.askyesno('Stop local monitoring',
                'Stop this local controller and agent? Configured services stay running. '
                'Use Withdraw to review removal or restore owned changes.', parent=self.root): return
        config = self.local_workspace
        from .linux_workspace import request_running_session_stop
        request_running_session_stop(config)
        self.client = None; self.generation += 1
        self.local_status.set('Stop requested. Service configuration and action records are retained.')
        self.note('Local monitoring stop requested. Existing services continue independently.')

    def discard_local_plan(self):
        if self.local_wizard_busy or self.job_path is not None or self.client is not None:
            self.note('Finish or stop the current session before preparing a new one.'); return
        self.local_workspace = None; self.local_selection_digest = None; self.plan = None
        self.inventory_path.set(''); self.profile_path.set('')
        self.start_setup.configure(state='disabled', text='Approve and start in background')
        self.notebook.select(self.tabs['Service setup'])
        self.note('Prepared plan discarded. Select services and review the next plan on Start here.')

    def open_as_administrator(self):
        installed = Path('/opt/sentinel-blue/Start-Sentinel-Blue.sh')
        try:
            if installed.is_file() and installed.parent == Path(sys.argv[0]).absolute().parent:
                command = ['/usr/bin/pkexec', str(installed), 'desktop', '--foreground']
            else:
                # The desktop's normal polkit authentication is still required.
                # Pass only display routing explicitly; never copy the full user
                # environment into an administrator process.
                runtime = Path(sys.argv[0]).absolute()
                launcher = runtime.parent/'Start-Sentinel-Blue.sh'
                if not launcher.is_file() or not os.environ.get('DISPLAY'):
                    raise ValueError('Open the complete offline Linux bundle inside the VM desktop.')
                command = ['/usr/bin/pkexec', '--disable-internal-agent', '/usr/bin/env',
                           'DISPLAY=' + os.environ['DISPLAY']]
                authority = os.environ.get('XAUTHORITY')
                if not authority:
                    conventional = Path.home()/'.Xauthority'
                    authority = str(conventional) if conventional.is_file() else None
                if authority:
                    command.append('XAUTHORITY=' + authority)
                command += ['/bin/sh', str(launcher), 'desktop', '--foreground']
            subprocess.Popen(command,
                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                start_new_session=True)
            self.note('An administrator window was requested. Complete the desktop authentication prompt.')
        except (ValueError, OSError) as exc:
            self.messagebox.showerror('Graphical administrator launch', str(exc), parent=self.root)

    def edit_service_check(self):
        from .linux_workspace import default_probe
        from .linux_service_catalog import CATALOG
        chosen = self.service_panel.tree.selection()
        if not chosen:
            self.note('Select a service row first.'); return
        sid = chosen[0]
        if sid.startswith('custom:'):
            # A custom service's check is part of its declaration.
            self.service_panel.edit_custom(sid.removeprefix('custom:')); return
        try:
            probe = self.local_checks.get(sid) or default_probe(sid, self.service_panel.options.get(sid, {}))
        except ValueError:
            probe = {'kind': 'tcp', 'target': '127.0.0.1', 'port': ''}
        window = self.tk.Toplevel(self.root); window.title('Service check — ' + CATALOG[sid]['label'])
        window.geometry('700x540')
        body = self.ttk.Frame(window, padding=16); body.pack(fill='both', expand=True)
        self.ttk.Label(body, text='Choose the check that establishes readiness. TCP checks only test an open listener. '
            'DNS uses an expected answer; HTTP checks status and optionally page content.', wraplength=650).grid(row=0, column=0, columnspan=3, pady=8)
        kind = self.tk.StringVar(value=probe['kind'])
        self.ttk.Label(body, text='Check type').grid(row=1, column=0, sticky='w')
        self.ttk.Combobox(body, textvariable=kind, state='readonly', values=('tcp', 'http', 'https', 'dns')).grid(row=1, column=1, sticky='ew')
        target = self._entry(body, 2, 'Target IP or full HTTP(S) URL', probe.get('target', '127.0.0.1'))
        port = self._entry(body, 3, 'Port (TCP / DNS)', str(probe.get('port', '')))
        query = self._entry(body, 4, 'DNS query name', probe.get('query', ''))
        expected = self._entry(body, 5, 'DNS answers (comma separated)', ', '.join(probe.get('expected_answers', [])))
        content = self._entry(body, 6, 'HTTP expected page text (optional)', probe.get('expected_body', ''))
        ca = self._entry(body, 7, 'HTTPS CA certificate', probe.get('ca_file', ''), browse=True)
        error = self.tk.StringVar(value='Checks are saved with the reviewed setup plan.')
        self.ttk.Label(body, textvariable=error, wraplength=620).grid(row=8, column=0, columnspan=3, pady=12)
        def save():
            try:
                from .custom_services import local_check
                check = local_check(kind.get(), target.get(), port.get(), query=query.get(), answers=expected.get(),
                                    expected_body=content.get(), ca_file=ca.get(),
                                    local_addresses=self.service_panel.local_addresses)
                self.local_checks[sid] = check
                window.destroy(); self.note('Saved the service check for ' + CATALOG[sid]['label'])
            except (ValueError, OSError) as exc: error.set(str(exc))
        self.ttk.Button(body, text='Save check', command=save).grid(row=9, column=0, sticky='w')
