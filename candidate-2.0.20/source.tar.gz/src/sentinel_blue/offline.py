"""Local dependency checks; never download software or contact a service."""
from __future__ import annotations

import importlib
import importlib.metadata
import json
import platform
import sqlite3
import sys


def check_dependencies(*, desktop=False):
    checks = []
    for name in ('tkinter', 'cryptography', 'paramiko', 'smbprotocol', 'spnego'):
        try:
            module = importlib.import_module(name)
            if name == 'cryptography':
                from cryptography.hazmat.primitives.ciphers.aead import AESGCM
                from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
                key = Scrypt(salt=b'sentinel-offline', length=32, n=32768, r=8, p=1).derive(b'local-check-only')
                cipher = AESGCM(key)
                nonce = b'check-only!!'
                assert cipher.decrypt(nonce, cipher.encrypt(nonce, b'local', b'check'), b'check') == b'local'
            elif name == 'tkinter':
                module.Tcl().eval('info patchlevel')
                if desktop:
                    root = module.Tk()
                    try:
                        from tkinter import ttk
                        ttk.Label(root, text='Sentinel Blue offline check').pack()
                        root.update()
                    finally:
                        root.destroy()
            elif name == 'spnego':
                # Exercise the NTLM backend used by optional SMB checks.
                module.client('sentinel-offline', 'local-check-only', protocol='ntlm').step()
            checks.append({'component': name, 'available': True})
        except Exception as exc:
            checks.append({'component': name, 'available': False, 'error_type': type(exc).__name__})
    with sqlite3.connect(':memory:') as connection:
        connection.execute('CREATE TABLE offline_check(value TEXT)')
        connection.execute('INSERT INTO offline_check VALUES (?)', ('local',))
        assert connection.execute('SELECT value FROM offline_check').fetchone()[0] == 'local'
    return {'passed': all(row['available'] for row in checks), 'network_access_required': False,
            'python': platform.python_version(), 'platform': sys.platform,
            'architecture': platform.machine(), 'isolated_python': bool(sys.flags.isolated),
            'desktop_checked': desktop, 'checks': checks, 'sqlite': sqlite3.sqlite_version}


def run(args):
    report = check_dependencies(desktop=args.desktop)
    print(json.dumps(report, indent=2))
    return 0 if report['passed'] else 2
