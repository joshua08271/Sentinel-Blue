"""Bounded, read-only setup guards. Embedded into the reviewed remote script.

These checks establish configuration activation/prerequisites, not full native
acceptance or scorer availability. The ordinary setup engine still requires its
approved external transactions before committing a change.
"""
from __future__ import annotations

import base64
import glob
import hashlib
import itertools
import json
import os
from pathlib import Path
import re
import shlex
import stat
import subprocess


def _read(path, *, secret=False, directory=False):
    p = Path(path)
    if not p.is_absolute() or '..' in p.parts:
        raise ValueError('check requires an absolute canonical path')
    for parent in (p, *p.parents):
        if parent.is_symlink():
            raise ValueError('required path contains a symlink: ' + str(p))
    if directory:
        if not p.is_dir():
            raise ValueError('required directory is missing: ' + str(p))
        return b''
    fd = os.open(p, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_NONBLOCK', 0))
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1 or before.st_size > 1024 * 1024:
            raise ValueError('required file is not a bounded regular file: ' + str(p))
        if secret and (before.st_uid != 0 or before.st_mode & 0o027):
            raise ValueError('secret must be root-owned, not group-writable or accessible to others: ' + str(p))
        data = os.read(fd, 1024 * 1024 + 1)
        after = os.fstat(fd)
        if len(data) > 1024 * 1024 or (before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns):
            raise ValueError('required file changed during verification')
        return data
    finally:
        os.close(fd)


def validate_acl(data):
    """Require explicit default handling and password hashes; never log ACL content."""
    default_seen = False
    users_seen = set()
    for line in data.decode('utf-8').splitlines():
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        words = shlex.split(line)
        if len(words) < 3 or words[0] != 'user':
            raise ValueError('Redis ACL contains an unsupported rule')
        if words[1] in users_seen:
            raise ValueError('Redis ACL must define each user exactly once')
        users_seen.add(words[1])
        default_seen |= words[1] == 'default'
        rules = words[2:]
        if not rules or rules[0] != 'reset':
            raise ValueError('Redis ACL users must start with reset to avoid inherited authentication')
        if 'nopass' in rules or any(w.startswith('>') for w in rules):
            raise ValueError('Redis ACL must use password hashes, never nopass or plaintext passwords')
        enabled, password = False, False
        for word in rules:
            if word == 'reset':
                enabled, password = False, False
            elif word == 'on':
                enabled = True
            elif word == 'off':
                enabled = False
            elif word == 'resetpass':
                password = False
            elif re.fullmatch(r'#[0-9a-fA-F]{64}', word):
                password = True
            elif word.startswith(('!', '<')):
                raise ValueError('Redis ACL password removal requires a separately reviewed policy')
        if enabled and not password:
            raise ValueError('every enabled Redis ACL user must require a password hash')
    if not default_seen:
        raise ValueError('Redis ACL must explicitly disable or password-protect the default user')


def _command(argv):
    # The generated standalone script injects this same bounded helper before
    # loading the checker. Runtime imports use the packaged implementation.
    try:
        from .bounded_capture import capture_command, CaptureError
    except ImportError:
        capture_command = globals()['capture_command']
        CaptureError = globals()['CaptureError']
    try:
        code, data = capture_command(argv, 20, limit=1024 * 1024, merge_stderr=True)
    except CaptureError as exc:
        raise ValueError('native configuration check failed: ' + exc.reason) from None
    if code:
        raise ValueError('native configuration check failed: ' + Path(argv[0]).name)
    return data.decode('utf-8', errors='replace')


def _redis_config(path, seen=None):
    seen = set() if seen is None else seen
    path = str(Path(path))
    if path in seen or len(seen) >= 32:
        raise ValueError('Redis include cycle or include-count limit')
    seen.add(path)
    values = {}
    for line in _read(path).decode('utf-8').splitlines():
        if not line.strip() or line.lstrip().startswith('#'):
            continue
        words = shlex.split(line)
        if not words:
            continue
        if words[0].lower() == 'include':
            if len(words) != 2 or not Path(words[1]).is_absolute():
                raise ValueError('Redis include must be one absolute path')
            matches = sorted(glob.glob(words[1]))
            if not matches:
                raise ValueError('Redis include resolves to no files')
            for child in matches:
                values.update(_redis_config(child, seen))
        else:
            values[words[0].lower()] = ' '.join(words[1:])
    return values


def _unit_config_inputs(unit, executable):
    """Read systemd's launch configuration; reject wrappers/unsupported expansion.

    This is configuration admission, not an assertion about a running daemon.
    No text read from systemd or EnvironmentFile is executed as shell code.
    """
    def show(prop):
        return _command(['/usr/bin/systemctl', 'show', '--property=' + prop,
                         '--value', '--', unit]).strip()
    command = show('ExecStart')
    matches = re.findall(r'\{\s*path=([^;]+?)\s*;\s*argv\[\]=(.*?)\s*;\s*(?:ignore_errors|start_time)=', command, re.S)
    if len(matches) != 1 or matches[0][0].strip() != executable:
        raise ValueError('cannot verify the native ' + unit + ' launch configuration; wrappers require a reviewed adapter')
    if show('RootDirectory') not in {'', '/'} or show('RootImage') or show('UnsetEnvironment'):
        raise ValueError('service root/environment overrides require a separately reviewed adapter')
    environment = {}
    for assignment in shlex.split(show('Environment')):
        if '=' not in assignment:
            raise ValueError('invalid service environment')
        key, value = assignment.split('=', 1)
        if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', key):
            raise ValueError('invalid environment variable name')
        environment[key] = value
    env_files = show('EnvironmentFiles')
    paths = re.findall(r'(\S+)\s+\(ignore_errors=(yes|no)\)', env_files)
    if len(paths) > 8 or re.sub(r'\S+\s+\(ignore_errors=(?:yes|no)\)', '', env_files).strip():
        raise ValueError('unsupported service EnvironmentFiles layout')
    for filename, optional in paths:
        if not filename.startswith('/') or any(c in filename for c in ('%', '*', '?', '[', '\\')):
            raise ValueError('service environment file needs an exact absolute path')
        try:
            content = _read(filename).decode('utf-8')
        except FileNotFoundError:
            if optional == 'yes':
                continue
            raise
        for line in content.splitlines():
            line = line.strip()
            if not line or line.startswith(('#', ';')):
                continue
            if '=' not in line or line.endswith('\\'):
                raise ValueError('unsupported multiline service environment')
            key, value = line.split('=', 1)
            key = key.strip()
            if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', key):
                raise ValueError('unsupported service environment assignment')
            words = shlex.split(value, comments=False)
            # systemd does not execute shell expansion. Refuse ambiguous formats
            # rather than substituting shell semantics for EnvironmentFile.
            if len(words) > 1 or any(c in value for c in ('$', '`', '\\')):
                raise ValueError('unsupported service environment quoting or expansion')
            environment[key] = words[0] if words else ''
    argv = []
    for token in shlex.split(matches[0][1]):
        variable = re.fullmatch(r'\$([A-Za-z_][A-Za-z0-9_]*)', token)
        if variable:
            argv.extend(shlex.split(environment.get(variable[1], '')))
        else:
            token = re.sub(r'\$\{([A-Za-z_][A-Za-z0-9_]*)\}',
                           lambda match: environment.get(match[1], ''), token)
            if '$' in token or '%' in token or '\\' in token:
                raise ValueError('unsupported native command expansion')
            argv.append(token)
    if not argv or argv[0] != executable:
        raise ValueError('native launch executable differs from the approved adapter')
    return argv


def _haproxy_checks(spec):
    argv = _unit_config_inputs('haproxy.service', '/usr/sbin/haproxy')
    inputs = []
    pos = 1
    while pos < len(argv):
        token = argv[pos]
        if token == '-f':
            if pos + 1 >= len(argv):
                raise ValueError('HAProxy -f is missing its configuration path')
            inputs.append(argv[pos + 1])
            pos += 2
        elif token.startswith('-f') and len(token) > 2:
            inputs.append(token[2:])
            pos += 1
        else:
            # These change how input paths resolve; no guessed -C/-L/fd input.
            if token == '--' or token.startswith(('-C', '--')):
                raise ValueError('unsupported HAProxy launch option requires explicit review')
            pos += 1
    if not inputs or len(inputs) > 32:
        raise ValueError('HAProxy configuration inputs are missing or exceed their bound')
    loaded = []
    for filename in inputs:
        path = Path(filename)
        if not path.is_absolute() or '..' in path.parts:
            raise ValueError('HAProxy input must be an absolute canonical path')
        if path.is_dir():
            _read(filename, directory=True)
            children = list(itertools.islice(path.iterdir(), 129))
            if len(children) > 128:
                raise ValueError('HAProxy configuration directory exceeds its input bound')
            loaded.extend(str(child) for child in sorted(children) if child.name.endswith('.cfg') and not child.name.startswith('.'))
        else:
            loaded.append(filename)
    for filename in spec['generated']:
        if filename not in loaded:
            raise ValueError('HAProxy does not load the generated configuration; supply a reviewed main_config snapshot or activate its exact input')
        content = _read(filename).decode('utf-8')
        if re.search(r'(?m)^\s*\.(?:if|elif|else|endif)\b', content):
            raise ValueError('conditional HAProxy generated-input activation requires explicit review')
        if spec['haproxy_expected'] not in content:
            raise ValueError('HAProxy active input does not contain the reviewed frontend/backend')
    # Revalidate the actual launch input list, not only the catalog's default.
    _command(['/usr/sbin/haproxy', '-c', *[item for name in inputs for item in ('-f', name)]])


def _samba_checks(spec):
    # Verbose effective configuration contains inherited/default share values;
    # read one bounded dump rather than trusting an existing port listener.
    argv = _unit_config_inputs('smbd.service', '/usr/sbin/smbd')
    config = '/etc/samba/smb.conf'
    selected = []
    position = 1
    while position < len(argv):
        token = argv[position]
        if token.startswith(('--option', '-s=')) or token == '--':
            raise ValueError('Samba command-line overrides require a separately reviewed adapter')
        if token in {'-s', '--configfile'}:
            if position + 1 >= len(argv):
                raise ValueError('Samba launch is missing its configfile argument')
            selected.append(argv[position + 1]); position += 2
        elif token.startswith('--configfile='):
            selected.append(token.split('=', 1)[1]); position += 1
        elif token.startswith('-s') and len(token) > 2:
            selected.append(token[2:]); position += 1
        else:
            position += 1
    if len(selected) > 1:
        raise ValueError('ambiguous Samba launch configuration')
    if selected:
        config = selected[0]
    if not Path(config).is_absolute() or '..' in Path(config).parts:
        raise ValueError('Samba configfile must be an absolute canonical path')
    active = _command(['/usr/bin/testparm', '-s', '-v', config])
    sections = {}
    current = None
    for line in active.splitlines():
        match = re.fullmatch(r'\s*\[([^]\r\n]+)\]\s*', line)
        if match:
            current = match[1].casefold()
            if current in sections:
                raise ValueError('ambiguous effective Samba share section')
            sections[current] = {}
        elif current is not None and '=' in line:
            key, value = line.split('=', 1)
            sections[current][key.strip().casefold()] = value.strip()
    desired = spec['samba_share']
    share = sections.get(desired['name'].casefold())
    if share is None:
        raise ValueError('Samba did not load the requested share; a reviewed parent include is required')
    for key, expected in desired.items():
        if key == 'name':
            continue
        value = share.get(key)
        if value is None:
            raise ValueError('Samba effective share setting is missing: ' + key)
        if isinstance(expected, bool):
            actual = {'yes': True, 'true': True, '1': True, 'no': False, 'false': False, '0': False}.get(value.casefold())
        elif isinstance(expected, list):
            actual = shlex.split(value.replace(',', ' '))
        elif key.endswith('mask'):
            try:
                actual, expected = int(value, 8), int(expected, 8)
            except ValueError:
                raise ValueError('invalid Samba effective mask') from None
        else:
            actual = value
        if actual != expected:
            raise ValueError('Samba effective share differs from reviewed setting: ' + key)
    if spec.get('smb_ports'):
        ports = sections.get('global', {}).get('smb ports', '').split()
        if ports != [str(value) for value in spec['smb_ports']]:
            raise ValueError('Samba did not load the reviewed SMB ports')


def run_checks(spec, phase):
    for requirement in spec.get('checked_files', []):
        data = _read(requirement['path'], secret=requirement.get('secret', False),
                     directory=requirement.get('directory', False))
        if requirement.get('sha256') and hashlib.sha256(data).hexdigest() != requirement['sha256']:
            raise ValueError('required file digest changed: ' + requirement['path'])
        if requirement.get('redis_acl'):
            validate_acl(data)
    for unit in spec.get('dependency_units', []):
        _command(['/usr/bin/systemctl', 'is-active', '--quiet', '--', unit])
    if phase == 'preflight':
        for requirement in spec.get('mode_preconditions', []):
            current = os.stat(requirement['path'], follow_symlinks=False)
            desired = int(requirement['mode'], 8)
            if desired & ~stat.S_IMODE(current.st_mode):
                raise ValueError('%s has mode %04o; writing it as %s means its permissions would be widened; '
                                 'supply a file_modes entry no wider than its current mode'
                                 % (requirement['path'], stat.S_IMODE(current.st_mode), requirement['mode']))
        # These packs emit Debian-layout configuration only. Package metadata for
        # RPM/SUSE/Arch is not authorization to apply Debian files there.
        release = _read('/etc/os-release').decode() if not Path('/etc/os-release').is_symlink() else Path('/usr/lib/os-release').read_text()
        fields = dict(line.split('=', 1) for line in release.splitlines() if '=' in line)
        ids = (fields.get('ID', '') + ' ' + fields.get('ID_LIKE', '')).replace('"', '').split()
        if not {'debian', 'ubuntu', 'kali'} & set(ids):
            raise ValueError('this service pack requires a reviewed Debian-family layout')
        return
    service = spec['service_id']
    if service == 'apache2':
        listing = _command(['/usr/sbin/apachectl', '-t', '-D', 'DUMP_INCLUDES'])
        for path in spec['generated']:
            if path.startswith('/etc/apache2/sites-enabled/') and not re.search(r'(?m)^\s*\([^\n)]*\)\s+' + re.escape(path) + r'\s*$', listing):
                raise ValueError('Apache did not load the generated site; active include is required')
        vhosts = _command(['/usr/sbin/apachectl', '-t', '-D', 'DUMP_VHOSTS'])
        if spec['apache_site'] not in vhosts:
            raise ValueError('Apache did not report the requested virtual host')
    elif service == 'bind9':
        zone = spec['bind_zone']
        config = _command(['/usr/sbin/named-checkconf', '-p', '-x', '/etc/bind/named.conf'])
        # Bind the file to this zone block, not an unrelated zone elsewhere.
        block = re.search(r'zone\s+"' + re.escape(zone['name']) + r'"(?:\s+IN)?\s*\{(.*?)(?=\n\};)', config, re.S)
        if block is None or f'file "{zone["path"]}"' not in block.group(1):
            raise ValueError('BIND did not load the requested zone declaration')
        _command(['/usr/sbin/named-checkzone', zone['name'], zone['path']])
        if spec.get('bind_port') and not re.search(r'(?m)^\s*port\s+' + str(spec['bind_port']) + r'\s*;', config):
            raise ValueError('BIND did not load the reviewed default DNS port')
    elif service == 'redis':
        active = _redis_config('/etc/redis/redis.conf')
        for key, value in spec['redis_expected'].items():
            if active.get(key) != value:
                raise ValueError('Redis active configuration does not match the reviewed ' + key)
        if 'aclfile' in spec['redis_expected'] and any(key in active for key in ('requirepass', 'user')):
            raise ValueError('existing Redis inline ACL/password conflicts with the reviewed ACL file')
    elif service == 'postfix':
        for line in spec['postfix_desired'].splitlines():
            if line.strip() and not line.startswith('#'):
                key, value = (part.strip() for part in line.split('=', 1))
                actual = _command(['/usr/sbin/postconf', '-h', key]).strip()
                if actual != value:
                    raise ValueError('Postfix effective setting differs: ' + key)
        if spec.get('postfix_smtp_port'):
            port = spec['postfix_smtp_port']
            active = _command(['/usr/sbin/postconf', '-M', str(port) + '/inet']).split()
            if len(active) < 8 or active[0] != str(port) or active[1] != 'inet' or active[7] != 'smtpd':
                raise ValueError('Postfix did not load the reviewed SMTP listener')
    elif service == 'samba':
        _samba_checks(spec)
    elif service == 'haproxy':
        _haproxy_checks(spec)
    elif service in {'postgresql', 'isc-dhcp-server'}:
        # Explicit parent activation is required. A standalone snippet is not an
        # installation; no silent fallback to "service running" is permitted.
        for parent, include in spec.get('activation_lines', {}).items():
            active = _read(parent).decode('utf-8').splitlines()
            if include not in (line.strip() for line in active):
                raise ValueError('configuration include has not been activated in ' + parent)
            if parent.endswith('/pg_hba.conf'):
                first = next((line.strip() for line in active if line.strip() and not line.lstrip().startswith('#')), '')
                if first != include:
                    raise ValueError('reviewed PostgreSQL HBA rules must precede existing match rules')
        if service == 'postgresql':
            directory = Path(spec['postgres_cluster'])
            version, cluster = directory.parts[-2:]
            # 'show' alone only prints its usage and fails (found live on 2.0.6,
            # where it failed every PostgreSQL setup). 'show all' reads
            # postgresql.conf and its include directory and fails on a bad line.
            _command(['/usr/bin/pg_conftool', version, cluster, 'show', 'all'])


def check_scripts(service_id, generated, extra):
    """Compiler only. Embed the fixed validator into the hash-bound remote script."""
    from importlib.resources import files
    from .runtime_environment import target_python_shell
    spec = {**extra, 'service_id': service_id, 'generated': list(generated)}
    if service_id == 'postfix':
        # Only the generated parameter set is checked, not unrelated preserved settings.
        marker = '# Managed by Sentinel Blue. Reviewed setup plan; remove through Sentinel.'
        spec['postfix_desired'] = generated['/etc/postfix/main.cf'].rsplit(marker, 1)[-1]
    source = files('sentinel_blue').joinpath('service_pack_checks.py').read_text(encoding='utf-8')
    bounded = files('sentinel_blue').joinpath('bounded_capture.py').read_text(encoding='utf-8')
    helper = base64.b64encode(bounded.encode()).decode()
    encoded = base64.b64encode(source.encode()).decode()
    payload = base64.b64encode(json.dumps(spec, sort_keys=True).encode()).decode()
    def script(phase):
        return (f"{target_python_shell()} -I -B - <<'SENTINEL_PACK_CHECK'\nimport base64,json\n"
                f"ns={{'__name__':'sentinel_pack_check'}}\nexec(compile(base64.b64decode('{helper}'),'sentinel-bounded-capture','exec'),ns)\n"
                f"exec(compile(base64.b64decode('{encoded}'),'sentinel-pack-check','exec'),ns)\n"
                f"ns['run_checks'](json.loads(base64.b64decode('{payload}')), '{phase}')\n"
                "SENTINEL_PACK_CHECK\n")
    return script('preflight'), script('configuration')
