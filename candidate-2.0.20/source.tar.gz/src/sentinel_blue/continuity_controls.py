"""Independent local/SSH/WinRM Pause, separate from withdrawal ownership."""
import json
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path


def local_control(ledger, paused, reason):
    if not isinstance(reason, str) or not 1 <= len(reason) <= 256:
        raise ValueError('A bounded operator reason is required')
    with ledger.lock():
        if not paused and ledger.paused():
            raise ValueError('Continuity Resume cannot clear a Withdraw latch')
        ledger.append('continuity_pause' if paused else 'continuity_resume', reason=reason)
        pending = [x['action_id'] for x in ledger.actions() if x['status'] in
                   {'prepared', 'applied', 'uncertain', 'undo_prepared', 'boot_prepared', 'quiesce_prepared'}]
        return {'paused': ledger.automation_paused(), 'drained': not pending,
                'unknown_actions': pending, 'head': ledger.head()}


def network_pause(inventory, profile, directory, *, range_deployment=False):
    from .withdrawal import coordinator_from_files
    from .state import write_private_json
    coordinator = coordinator_from_files(inventory, profile, directory, range_deployment=range_deployment)
    result = {'operation_id': uuid.uuid4().hex, 'at': time.time(), 'hosts': {}}
    with ThreadPoolExecutor(max_workers=min(16, len(coordinator.hosts))) as pool:
        pending = {pool.submit(coordinator.request, host, {'operation': 'continuity-pause',
                   'reason': 'Operator independent network Pause'}): host for host in coordinator.hosts}
        for future in as_completed(pending):
            host = pending[future]
            try:
                result['hosts'][host] = future.result()
            except Exception as exc:
                result['hosts'][host] = {'held': True, 'error': str(exc)[:256]}
    result['complete'] = all(x.get('paused') is True and x.get('drained') is True for x in result['hosts'].values())
    write_private_json(Path(directory) / 'pause-receipt.json', result)
    return result


def run(args):
    from .mutation_ledger import MutationLedger
    result = local_control(MutationLedger(args.ledger_directory), args.command == 'continuity-pause', args.reason)
    print(json.dumps(result, indent=2))
    return 0 if result['drained'] else 2
