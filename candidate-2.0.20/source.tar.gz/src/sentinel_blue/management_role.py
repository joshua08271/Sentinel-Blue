"""One explicit background role, with private bounded logs and exact stop identity.

Does not install a service, open a firewall, restart failed agents or mutate
scored services. The ordinary controller supervisor and agent govern their own
work. Closing the GUI does not stop this role. Reboots need explicit restart.
"""
from __future__ import annotations
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import signal
import select
import subprocess
import threading
import time

from .management_workspace import role_arguments
from .state import AgentProcessLock, read_private_json, write_private_json
from .process_identity import inspect_process_identity, signal_verified_process


def start(config_path):
    from .desktop_jobs import detach
    config, _ = role_arguments(config_path)
    d = Path(config['directory'])
    previous = status(config_path)
    if previous.get('alive') or previous.get('child_alive'):
        raise ValueError('This isolated role is already running; reconnect instead')
    return detach(['isolated-role-session', '--config', str(d/'role.json')])


def status(config_path):
    d = Path(config_path).absolute().parent
    try:
        value = read_private_json(d/'role-status.json', 16384)
    except FileNotFoundError:
        return {'state': 'not-started', 'alive': False}
    identity = value.get('identity')
    try:
        value['alive'] = bool(identity and inspect_process_identity(identity['process_id']) == identity)
    except (OSError, ValueError, KeyError):
        value['alive'] = False
    child = value.get('child_identity')
    try:
        value['child_alive'] = bool(child and inspect_process_identity(child['process_id']) == child)
    except (OSError, ValueError, KeyError):
        value['child_alive'] = False
    return value


def stop(config_path):
    value = status(config_path)
    identity = value.get('identity') if value.get('alive') else value.get('child_identity') if value.get('child_alive') else None
    if identity is None:
        raise ValueError('The exact recorded role process is not running')
    signal_verified_process(identity['process_id'], identity, 'terminate')
    return {'state': 'stop-requested', 'note': 'Await confirmation; this stops monitoring, not withdrawal'}


def run(args):
    path = Path(args.config).absolute()
    config, arguments = role_arguments(path)
    d = path.parent
    lock = AgentProcessLock(d).acquire()
    halted = threading.Event()
    previous_signals = {}
    for sig in (signal.SIGTERM, signal.SIGINT):
        previous_signals[sig] = signal.signal(sig, lambda *_: halted.set())
    identity = inspect_process_identity(os.getpid())
    log_path = d/'role.log'
    if log_path.is_symlink() or any((d/f'role.log.{i}').is_symlink() for i in (1,2,3)):
        lock.close()
        raise ValueError('Role log paths must not be links')
    oldmask = os.umask(0o077)
    try:
        log = RotatingFileHandler(log_path, maxBytes=2*1024*1024, backupCount=3, encoding='utf-8')
    finally:
        os.umask(oldmask)
    logger = logging.Logger('isolated-role'); logger.addHandler(log)
    child = None
    drain_done = threading.Event()
    reader = None
    def record(state, **extra):
        if child is not None and 'child_identity' not in extra:
            try:
                extra['child_identity'] = inspect_process_identity(child.pid)
            except (OSError, ValueError):
                pass
        write_private_json(d/'role-status.json', {'schema': 1, 'role': config['role'], 'identity': identity,
            'state': state, 'updated_at': time.time(), **extra})
    def drain():
        # Fixed-size chunks, not readline: an unbounded line cannot exhaust RAM.
        while not drain_done.is_set():
            ready, _, _ = select.select([child.stdout], [], [], .25)
            if not ready:
                continue
            chunk = os.read(child.stdout.fileno(), 4096)
            if not chunk:
                return
            logger.info(chunk.decode('utf-8', 'replace').rstrip())
    try:
        from .runtime_environment import python_command
        record('starting')
        child = subprocess.Popen([*python_command(), config['runtime'], *arguments],
            stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            close_fds=True, start_new_session=True, bufsize=0)
        reader = threading.Thread(target=drain, daemon=True); reader.start()
        record('process-started', child_identity=inspect_process_identity(child.pid),
               note='Verify controller readiness / fresh agent telemetry separately')
        while child.poll() is None:
            if halted.wait(.25):
                record('stopping', note='Waiting for ordinary runtime shutdown; no automatic destructive kill')
                child.terminate()
                # Keep wrapper/lock/evidence alive until the actual child exits.
                # An unresponsive runtime remains visibly stopping, not success.
                while child.poll() is None:
                    time.sleep(.25)
                break
        reader.join(timeout=2)
        record('stopped' if child.returncode in (0, -signal.SIGTERM) else 'failed', returncode=child.returncode)
    except BaseException as exc:
        logger.error('Role failed: %s', type(exc).__name__)
        if child is not None and child.poll() is None:
            child.terminate()
        record('failed', error_type=type(exc).__name__)
        raise
    finally:
        drain_done.set()
        if reader is not None:
            reader.join(timeout=1)
        if child is not None and child.stdout:
            child.stdout.close()
        log.close()
        lock.close()
        for sig, old in previous_signals.items():
            signal.signal(sig, old)
