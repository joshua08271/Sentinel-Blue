"""Whether a Linux service pack has been proven against the real product.

Every catalog row says ``native_tested: False``, and until now that was the only
thing it could say: nothing in the tree could record that a pack had been run
against a real BIND or Postfix, so proving one on a lab host left no trace and
the next person had to take it on trust.

This module is the record. A **receipt** says that one pack, built from one exact
set of reviewed options, passed the acceptance matrix below against a named
product version on a particular host, using a particular runtime. The harness in
``tools/service_pack_acceptance.py`` produces them; this module reads them back
and decides whether one still describes what is installed now.

Three rules hold, and the code enforces rather than documents them.

**A receipt is evidence, never permission.** Nothing here unlocks, enables or
relaxes any behaviour. A pack with a receipt compiles, refuses and rolls back
exactly as one without. The only thing a receipt changes is what is *reported* to
the operator, which is the whole point: the difference between "this has been
proven here" and "nobody knows".

**A receipt describes one pack as it was, not a pack by name.** It carries a
fingerprint of the generated configuration and scripts for the reviewed options.
Change an option, change the builder, or upgrade the runtime, and the fingerprint
no longer matches: the receipt goes stale and the pack reads untested again. It
can never vouch for something other than what was actually run.

**A stale or unreadable receipt is untested, not accepted.** Every failure to
parse, verify or match resolves to the cautious answer.
"""

from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import stat
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .linux_service_catalog import CONFIGURE, entry

SCHEMA = 2

DIRECTORY = "acceptance"

# A receipt older than this is reported as expired. Competition images are
# rebuilt and products are updated; an acceptance from a year ago describes a
# machine that no longer exists.
MAXIMUM_AGE_DAYS = 180

MAXIMUM_RECEIPT_BYTES = 256 * 1024


# --------------------------------------------------------------- the matrix
# Ordered. Each entry is one question a lab host can answer and this sandbox
# cannot. `required` steps must all pass before a receipt is written; the others
# need a second host, a reboot, or a product feature that may not be present,
# and are recorded as skipped with their reason.
MATRIX: tuple[dict[str, Any], ...] = (
    {"id": "preflight", "required": True,
     "asks": "the product is installed, its unit is known to systemd, and the host is the Debian family this pack targets"},
    {"id": "initial-state", "required": True,
     "asks": "whether this is a fresh installation or an adoption of existing configuration, recorded because they are different acceptances"},
    {"id": "compile", "required": True,
     "asks": "the reviewed options compile through the real recipe to a plan the executor accepts"},
    {"id": "pre-state", "required": True,
     "asks": "the exact digest of every file the pack will write or activate, captured before anything changes"},
    {"id": "apply", "required": True,
     "asks": "the plan applies through the ordinary transaction, with its ownership recorded in the ledger"},
    {"id": "config-test", "required": True,
     "asks": "the product's own configuration test accepts the result"},
    {"id": "service-active", "required": True,
     "asks": "the unit is active after the change, not merely reloaded without complaint"},
    {"id": "positive-transaction", "required": True,
     "asks": "a real client transaction against the running service succeeds"},
    {"id": "denied-transaction", "required": True,
     "asks": "the weakening this pack refuses to generate is actually refused by the running product"},
    {"id": "effective-settings", "required": True,
     "asks": "the product's own report of its effective configuration matches what was generated"},
    {"id": "identical-reapply", "required": True,
     "asks": "applying the same plan again changes nothing and does not restart the service"},
    {"id": "approved-update", "required": True,
     "asks": "a changed, approved plan changes only what was approved and leaves the rest byte-identical"},
    {"id": "outside-edit-refused", "required": True,
     "asks": "an edit made outside Sentinel is detected and refused, not silently overwritten"},
    {"id": "interrupted-setup", "required": True,
     "asks": "a failure forced part way through leaves the exact pre-state, with nothing half-written"},
    {"id": "restart-survives", "required": True,
     "asks": "the service restarts cleanly and its configuration is unchanged afterwards"},
    {"id": "rollback", "required": True,
     "asks": "the owned rollback restores every file to its captured pre-state digest"},
    {"id": "withdrawal", "required": True,
     "asks": "withdrawal removes what this pack owns and leaves the host as it was found"},
    {"id": "reboot-survives", "required": False,
     "asks": "the service comes back after a real reboot with the same effective configuration"},
    {"id": "independent-client", "required": False,
     "asks": "a client on a separate authorized host completes the scored transaction"},
)

REQUIRED = tuple(step["id"] for step in MATRIX if step["required"])
OPTIONAL = tuple(step["id"] for step in MATRIX if not step["required"])
STEPS = tuple(step["id"] for step in MATRIX)

VERDICTS = ("passed", "failed", "skipped")

DIGEST = re.compile(r"[0-9a-f]{64}\Z")
IDENTIFIER = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}\Z")


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _stamp(moment: datetime | None = None) -> str:
    return (moment or _now()).strftime("%Y-%m-%dT%H:%M:%SZ")


def _parse_stamp(value: Any) -> datetime | None:
    if not isinstance(value, str):
        return None
    try:
        return datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
    except ValueError:
        return None


# ------------------------------------------------------------- identities

def host_key(machine_id: str | None = None) -> str:
    """A stable, non-reversible name for this host.

    The machine id is not stored: a receipt should say "the host you ran this on"
    without carrying an identifier that means something elsewhere.
    """
    if machine_id is None:
        for candidate in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
            try:
                machine_id = Path(candidate).read_text(encoding="utf-8").strip()
            except OSError:
                continue
            if machine_id:
                break
    if not machine_id:
        # No machine id: bind to the node name instead and say so by prefixing.
        return "node:" + hashlib.sha256(
            ("sentinel-acceptance:" + platform.node()).encode()).hexdigest()[:32]
    return hashlib.sha256(("sentinel-acceptance:" + machine_id).encode()).hexdigest()[:32]


def platform_identity(release_text: str | None = None) -> dict[str, str]:
    """The os-release fields that decide whether a pack's layout applies here."""
    if release_text is None:
        for candidate in ("/etc/os-release", "/usr/lib/os-release"):
            try:
                release_text = Path(candidate).read_text(encoding="utf-8")
                break
            except OSError:
                continue
    fields: dict[str, str] = {}
    for line in (release_text or "").splitlines():
        if "=" not in line:
            continue
        key, _, value = line.partition("=")
        fields[key.strip()] = value.strip().strip('"').strip("'")
    return {
        "id": fields.get("ID", "unknown"),
        "version_id": fields.get("VERSION_ID", "unknown"),
        "machine": platform.machine(),
    }


def pack_contract(service_id: str, options: dict[str, Any], root: Path) -> dict[str, Any]:
    """Use the same recipe and ownership metadata as production setup.

    Do not route nginx through the generic pack builder. Keep command bytes out
    of receipts: they can contain private configuration or credential material.
    """
    from .setup_recipes import compile_recipe
    from .setup_transactions import commands

    row = entry(service_id)
    if row["capability"] != CONFIGURE or not isinstance(options, dict):
        raise ValueError("acceptance requires a configuring service and reviewed options")
    if "catalog_id" in options:
        raise ValueError("the service selects its catalog identity")
    recipe = "linux-nginx" if service_id == "nginx" else "linux-service-pack"
    params = dict(options) if service_id == "nginx" else dict(options, catalog_id=service_id)
    check, apply, rollback = compile_recipe(recipe, params, Path(root), "linux")
    metadata: dict[str, Any] = {}
    if service_id == "nginx":
        from .application_setup import linux_nginx
        linux_nginx(options, Path(root), metadata=metadata)
    else:
        from .linux_service_packs import build
        build(service_id, options, Path(root), metadata=metadata)
    transaction = commands(recipe, params, Path(root), apply)
    if transaction is None:
        raise ValueError("the service has no durable setup contract")
    return {"recipe": recipe, "service": metadata["service"],
            "files": metadata.get("files", []), "check": check, "apply": apply,
            "rollback": rollback or "", "transaction": transaction}


def pack_fingerprint(service_id: str, options: dict[str, Any], root: Path) -> str:
    material = {"service_id": service_id, "options": options,
                "contract": pack_contract(service_id, options, root)}
    return hashlib.sha256(json.dumps(material, sort_keys=True, ensure_ascii=True,
                                    allow_nan=False).encode()).hexdigest()


def runtime_fingerprint(runtime: str | Path | None = None) -> str:
    """Hash the actual zipapp, never the invoking test/acceptance script.

    Source runs use a visibly distinct whole-package fingerprint, not the version
    string. Native acceptance CLI requires an explicit zipapp.
    """
    if runtime is not None:
        candidate = Path(runtime)
        if not candidate.is_file() or candidate.is_symlink():
            raise ValueError("runtime fingerprint requires an existing regular artifact")
        return hashlib.sha256(candidate.read_bytes()).hexdigest()
    loader = globals().get("__loader__")
    archive = getattr(loader, "archive", None)
    if archive:
        return runtime_fingerprint(archive)
    root = Path(__file__).resolve().parent
    digest = hashlib.sha256()
    for path in sorted(root.rglob("*")):
        if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc":
            digest.update(path.relative_to(root).as_posix().encode() + b"\0")
            digest.update(hashlib.sha256(path.read_bytes()).digest())
    return "source:" + digest.hexdigest()


# --------------------------------------------------------------- receipts

def directory(state_dir: str | Path) -> Path:
    return Path(state_dir) / DIRECTORY


def path_for(state_dir: str | Path, service_id: str) -> Path:
    if not IDENTIFIER.fullmatch(str(service_id)):
        raise ValueError("a receipt is named after a catalog service")
    return directory(state_dir) / f"{service_id}.json"


def build_receipt(service_id: str, *, options: dict[str, Any], results: dict[str, Any],
                  product_version: str, fingerprint: str, runtime: str,
                  operator: str, moment: datetime | None = None) -> dict[str, Any]:
    """Assemble a receipt. Raises unless every required step actually passed."""
    row = entry(service_id)
    if not isinstance(options, dict) or not isinstance(results, dict):
        raise ValueError("options and results must be objects")
    if not isinstance(runtime, str) or not re.fullmatch(r"(?:source:)?[0-9a-f]{64}", runtime):
        raise ValueError("receipt requires an exact runtime fingerprint")
    if row["capability"] != CONFIGURE:
        raise ValueError(f"{row['label']} generates no configuration, so there is nothing to accept")
    if not isinstance(fingerprint, str) or not DIGEST.fullmatch(fingerprint):
        raise ValueError("a receipt requires the pack fingerprint it was produced from")
    if not isinstance(product_version, str) or not product_version.strip():
        raise ValueError("record the product version the pack was proven against")
    if not isinstance(operator, str) or not operator.strip():
        raise ValueError("record who ran the acceptance")

    steps = {}
    for step in MATRIX:
        outcome = results.get(step["id"])
        if not isinstance(outcome, dict):
            raise ValueError(f"no result recorded for acceptance step {step['id']}")
        verdict = outcome.get("verdict")
        if not isinstance(verdict, str) or verdict not in VERDICTS:
            raise ValueError(f"step {step['id']} has no usable verdict")
        if step["required"] and verdict != "passed":
            raise ValueError(
                f"step {step['id']} is {verdict}; a receipt is only written when every "
                "required step passes")
        steps[step["id"]] = {
            "verdict": verdict,
            "detail": str(outcome.get("detail", ""))[:500],
        }
    return {
        "schema": SCHEMA,
        "service_id": service_id,
        "unit": row["unit"],
        "recorded_at": _stamp(moment),
        "operator": operator.strip()[:120],
        "product_version": product_version.strip()[:120],
        "pack_fingerprint": fingerprint,
        "runtime": runtime,
        "host_key": host_key(),
        "platform": platform_identity(),
        "options": json.loads(json.dumps(options, sort_keys=True, allow_nan=False)),
        "steps": steps,
    }


def _private_receipt_directory(state_dir: str | Path, *, create=False) -> Path:
    """Never chmod or follow an unknown receipt directory to make evidence fit."""
    target = directory(state_dir).absolute()
    for parent in reversed((target, *target.parents)):
        if not parent.exists():
            if not create:
                raise FileNotFoundError(str(parent))
            try:
                parent.mkdir(mode=0o700)
                created = True
            except FileExistsError:
                created = False
            if created:
                # A setgid parent can add 02000 despite mkdir(0700). Normalize
                # only the directory this call just created, never an old one.
                before = parent.lstat()
                fd = os.open(parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) |
                             getattr(os, "O_NOFOLLOW", 0))
                try:
                    opened = os.fstat(fd)
                    if (opened.st_dev, opened.st_ino) != (before.st_dev, before.st_ino):
                        raise ValueError("new receipt directory was replaced")
                    os.fchmod(fd, 0o700)
                finally:
                    os.close(fd)
        info = parent.lstat()
        if not stat.S_ISDIR(info.st_mode) or parent.is_symlink():
            raise ValueError("receipt directory ancestry must not contain symlinks")
    info = target.lstat()
    if stat.S_IMODE(info.st_mode) != 0o700 or (hasattr(os, "geteuid") and info.st_uid != os.geteuid()):
        raise ValueError("existing receipt storage is not private and owned; review it without relaxing guards")
    return target


def write(state_dir: str | Path, receipt: dict[str, Any]) -> Path:
    from .state import write_private_json

    target = path_for(state_dir, receipt["service_id"])
    _private_receipt_directory(state_dir, create=True)
    write_private_json(target, receipt)
    return target


def read(state_dir: str | Path, service_id: str) -> dict[str, Any] | None:
    """Load one receipt. Anything unreadable is treated as absent."""
    from .state import read_private_json

    try:
        target = path_for(state_dir, service_id)
    except ValueError:
        return None
    try:
        _private_receipt_directory(state_dir)
        if not target.is_file():
            return None
        payload = read_private_json(target, MAXIMUM_RECEIPT_BYTES)
    except (OSError, ValueError, TypeError, RecursionError):
        return None
    if not isinstance(payload, dict) or type(payload.get("schema")) is not int or payload.get("schema") != SCHEMA:
        return None
    if payload.get("service_id") != service_id:
        return None
    return payload


def _receipt_problem(receipt: dict[str, Any]) -> str | None:
    """Bound and validate nested evidence before trusting any field."""
    if type(receipt.get("schema")) is not int or receipt["schema"] != SCHEMA:
        return "receipt schema requires reacceptance"
    for name in ("service_id", "unit", "operator", "product_version", "runtime", "host_key"):
        value = receipt.get(name)
        if not isinstance(value, str) or not value.strip() or len(value) > 256 or any(not c.isprintable() for c in value):
            return f"unusable receipt field: {name}"
    if not isinstance(receipt.get("recorded_at"), str) or len(receipt["recorded_at"]) > 64:
        return "unusable receipt timestamp"
    try:
        if receipt["unit"] != entry(receipt["service_id"])["unit"]:
            return "receipt unit differs from its catalog identity"
    except (KeyError, ValueError):
        return "unknown receipt service"
    if not re.fullmatch(r"(?:source:)?[0-9a-f]{64}", receipt["runtime"]):
        return "unusable runtime fingerprint"
    if not isinstance(receipt.get("pack_fingerprint"), str) or not DIGEST.fullmatch(receipt["pack_fingerprint"]):
        return "unusable pack fingerprint"
    if not isinstance(receipt.get("options"), dict):
        return "unusable options object"
    identity = receipt.get("platform")
    if not isinstance(identity, dict) or any(not isinstance(identity.get(k), str) or
        not identity[k] or len(identity[k]) > 128 for k in ("id", "version_id", "machine")):
        return "unusable platform identity"
    steps = receipt.get("steps")
    if not isinstance(steps, dict) or len(steps) > len(STEPS) or set(steps) - set(STEPS):
        return "unusable steps object"
    for name in STEPS:
        item = steps.get(name)
        if not isinstance(item, dict) or not isinstance(item.get("verdict"), str) or item["verdict"] not in VERDICTS:
            return f"unusable or missing step: {name}"
        if not isinstance(item.get("detail", ""), str) or len(item.get("detail", "")) > 500:
            return f"unusable step detail: {name}"
    try:
        if len(json.dumps(receipt, allow_nan=False).encode()) > MAXIMUM_RECEIPT_BYTES:
            return "receipt exceeds the evidence budget"
    except (ValueError, TypeError, RecursionError):
        return "unusable JSON evidence"
    return None


def status(state_dir: str | Path, service_id: str, *, fingerprint: str | None = None,
           runtime: str | None = None, product_version: str | None = None,
           moment: datetime | None = None) -> dict[str, Any]:
    """Historical evidence counts only against independent CURRENT context.

    Runtime defaults to the actual loaded artifact. Current desired pack and
    observed product version must be supplied; receipt values are never used as
    their own expected values. Missing context is untested, not accepted.
    """
    answer = {"service_id": service_id, "state": "untested",
              "reason": "no usable acceptance has been recorded on this host",
              "native_tested": False, "recorded_at": None, "product_version": None}
    receipt = read(state_dir, service_id)
    if receipt is None:
        return answer
    problem = _receipt_problem(receipt)
    if problem:
        answer.update(reason=problem)
        return answer
    answer.update(recorded_at=receipt["recorded_at"], product_version=receipt["product_version"])
    recorded = _parse_stamp(receipt.get("recorded_at"))
    if recorded is None:
        answer.update(state="stale", reason="the receipt has no usable timestamp")
        return answer
    age = (moment or _now()) - recorded
    if age.total_seconds() > MAXIMUM_AGE_DAYS * 86400 or age.total_seconds() < 0:
        answer.update(state="stale", reason="receipt is expired or dated in the future")
        return answer
    if receipt["host_key"] != host_key() or receipt["platform"] != platform_identity():
        answer.update(state="stale", reason="the receipt describes a different host or platform")
        return answer
    expected_runtime = runtime if runtime is not None else runtime_fingerprint()
    if receipt["runtime"] != expected_runtime:
        answer.update(state="stale", reason="a different runtime was accepted")
        return answer
    if fingerprint is not None and receipt["pack_fingerprint"] != fingerprint:
        answer.update(state="stale", reason="the pack or its reviewed options have changed")
        return answer
    if product_version is not None and receipt["product_version"] != product_version:
        answer.update(state="stale", reason="the observed product version has changed")
        return answer
    missing = [name for name in REQUIRED if receipt["steps"][name]["verdict"] != "passed"]
    if missing:
        answer.update(state="stale", reason="required steps not passed: " + ", ".join(missing[:3]))
        return answer
    if (not isinstance(fingerprint, str) or not DIGEST.fullmatch(fingerprint) or
            not isinstance(product_version, str) or not product_version.strip()):
        answer.update(reason="historical receipt only: current desired configuration and observed product version are required")
        return answer
    answer.update(state="accepted", native_tested=True,
                  reason=f"tested configuration matches supplied current context for {product_version}; evidence dated {receipt['recorded_at']}")
    return answer


def summary(state_dir: str | Path, service_ids=None, *, contexts=None, runtime=None) -> dict[str, Any]:
    """No-current-context summaries do not silently promote historical receipts.

    contexts maps each service to {options, root, product_version}; options come
    from the current reviewed configuration and product_version from a current
    observation. Neither is taken from a receipt. This does not inspect live
    effective configuration or assert that an installed service is healthy.
    """
    from .linux_service_catalog import CATALOG
    if service_ids is None:
        service_ids = sorted(sid for sid, row in CATALOG.items() if row["capability"] == CONFIGURE)
    if contexts is not None and not isinstance(contexts, dict):
        raise ValueError("current acceptance contexts must be an object")
    current_runtime = runtime if runtime is not None else runtime_fingerprint()
    states = {}
    for sid in service_ids:
        context = (contexts or {}).get(sid)
        fingerprint, product = None, None
        if context is not None:
            try:
                if not isinstance(context, dict) or not isinstance(context.get("options"), dict) or not isinstance(context.get("root"), str):
                    raise ValueError("current context requires options and a source root")
                fingerprint = pack_fingerprint(sid, context["options"], Path(context["root"]))
                product = context.get("product_version")
            except (OSError, ValueError, TypeError, KeyError, RecursionError):
                states[sid] = {"service_id": sid, "state": "untested", "native_tested": False,
                               "reason": "current configuration cannot be fingerprinted"}
                continue
        states[sid] = status(state_dir, sid, fingerprint=fingerprint,
                             product_version=product, runtime=current_runtime)
        if states[sid]["state"] == "accepted":
            recorded = read(state_dir, sid)
            if not recorded or recorded.get("options") != context["options"]:
                states[sid].update(state="untested", native_tested=False,
                                   reason="recorded options do not match supplied current options")
    accepted = sorted(sid for sid, row in states.items() if row["state"] == "accepted")
    stale = sorted(sid for sid, row in states.items() if row["state"] == "stale")
    total = len(states)
    line = (f"{len(accepted)} of {total} configuring services match current acceptance context; "
            f"{total - len(accepted)} are unproven here" if accepted else
            f"none of the {total} configuring services has current verified acceptance context; "
            "a recipe name is not an accepted setup capability")
    if not contexts:
        line += "; no current configuration/product context supplied; historical receipts cannot count"
    if stale:
        line += f"; {len(stale)} stale receipt(s) do not count"
    return {"total": total, "accepted": accepted, "stale": stale,
            "untested": sorted(set(states) - set(accepted) - set(stale)),
            "states": states, "statement": line}
