"""Standalone owned Linux service rollback; invoked over the reviewed transport.

Private snapshots and resource claims survive the apply process. An uncertain
process is never replayed. Rollback refuses intervening file/configuration edits.
Installed package prerequisites are deliberately retained.
"""
from __future__ import annotations
import base64
import copy
import contextlib
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import time
import uuid

ROOT = Path('/var/lib/sentinel-blue-setup-transactions')
MAX_FILE = 4 * 1024 * 1024


def secure_directory(path, create=False):
    if not path.exists():
        if not create:
            raise ValueError('Required trusted directory is absent')
        secure_directory(path.parent, create=True)
        path.mkdir(mode=0o700)
    for parent in (path, *path.parents):
        info = parent.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
            raise ValueError(untrusted_directory_reason(parent, info))


def untrusted_directory_reason(path, info):
    """Why setup will not change files under this directory, in plain words."""
    if not stat.S_ISDIR(info.st_mode):
        why = 'is not a plain directory'
    elif info.st_uid != 0:
        why = f'is owned by uid {info.st_uid}, not root'
    else:
        why = 'can be written by a group or by other accounts'
    return (f'Setup rollback requires root-owned, non-writable directories: {path} {why}. '
            'Another account able to change it could redirect what setup writes as root')


def trusted_parent(path):
    parent = path.parent
    while not parent.exists() and not parent.is_symlink():
        parent = parent.parent
    secure_directory(parent)


def _revision(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_gid,
            info.st_nlink, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def _read_file(path):
    """Return metadata, bytes and revision from one bounded, stable descriptor.

    O_NOFOLLOW alone does not prevent a FIFO open from blocking. Validate the
    nonblocking descriptor before reading, then detect replacement/modification.
    Keep revision separate from the persisted fingerprint: copied backups have
    different inodes/timestamps and are compared by content and metadata.
    """
    trusted_parent(path)
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except FileNotFoundError:
        return None, None, None
    try:
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or st.st_nlink != 1 or st.st_size > MAX_FILE or st.st_mode & 0o022:
            raise ValueError('Unsafe or oversized setup file')
        data = bytearray()
        while len(data) <= MAX_FILE:
            block = os.read(fd, min(65536, MAX_FILE + 1 - len(data)))
            if not block:
                break
            data.extend(block)
        if len(data) > MAX_FILE:
            raise ValueError('Setup file exceeds the snapshot limit')
        attrs = {name: base64.b64encode(os.getxattr(fd, name)).decode() for name in sorted(os.listxattr(fd))}
        if _revision(st) != _revision(os.fstat(fd)) or _revision(st) != _revision(path.lstat()):
            raise ValueError('Setup file changed during its bounded read')
        info = {'sha256': hashlib.sha256(data).hexdigest(), 'uid': st.st_uid, 'gid': st.st_gid,
                'mode': stat.S_IMODE(st.st_mode), 'xattrs': attrs}
        return info, bytes(data), [st.st_dev, st.st_ino, st.st_ctime_ns, st.st_mtime_ns]
    finally:
        os.close(fd)


def fingerprint(path):
    return _read_file(path)[0]


def save(path, value):
    secure_directory(path.parent)
    temporary = path.with_name('.' + path.name + '.' + uuid.uuid4().hex)
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        with os.fdopen(fd, 'w') as stream:
            json.dump(value, stream, sort_keys=True)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        temporary.unlink(missing_ok=True)


def read(path):
    info, data, _ = _read_file(path)
    if info is None or info['uid'] != 0 or info['mode'] & 0o077:
        raise ValueError('Untrusted setup transaction record')
    return json.loads(data)


def command(*args, allowed=(0,)):
    result = subprocess.run(args, capture_output=True, text=True, timeout=45,
                            env={'PATH': '/usr/sbin:/usr/bin:/sbin:/bin', 'LANG': 'C.UTF-8'})
    if result.returncode not in allowed:
        raise RuntimeError('Owned service command failed: ' + args[0])
    return result


def service_state(name):
    result = command('systemctl', 'show', '--property=LoadState,ActiveState,UnitFileState', '--', name, allowed=(0, 4))
    fields = dict(line.split('=', 1) for line in result.stdout.splitlines() if '=' in line)
    if set(fields) != {'LoadState', 'ActiveState', 'UnitFileState'}:
        raise ValueError('Service state query did not complete')
    exists = fields.get('LoadState') != 'not-found'
    active = fields.get('ActiveState')
    if active not in {'active', 'inactive', 'failed'}:
        raise ValueError('Service is in a transitional state; review before setup')
    enabled = fields.get('UnitFileState', '')
    if exists and enabled not in {'enabled', 'disabled', 'static', 'indirect', 'masked', 'masked-runtime', 'enabled-runtime', 'alias', ''}:
        raise ValueError('Unsupported existing service enablement state')
    content = command('systemctl', 'cat', '--', name, allowed=(0, 1)).stdout if exists else ''
    return {'exists': exists, 'active': active == 'active', 'enabled': enabled,
            'configuration_sha256': hashlib.sha256(content.encode()).hexdigest()}


def capture(spec):
    return {'files': {row['path']: fingerprint(Path(row['path'])) for row in spec['files']},
            'service': service_state(spec['service'])}


def resources(spec):
    values = ['service:' + spec['service']] + ['file:' + row['path'] for row in spec['files']]
    return [hashlib.sha256(value.encode()).hexdigest() for value in sorted(set(values))]


def release(state, token):
    for key in state['resources']:
        p = ROOT / ('resource-' + key + '.json')
        if p.exists() and read(p) != {'transaction': token}:
            raise ValueError('Setup resource ownership changed')
    for key in state['resources']:
        (ROOT / ('resource-' + key + '.json')).unlink(missing_ok=True)


def revisions(snapshot):
    return {p: None if row is None else row['revision']
            for p, row in snapshot['file_evidence'].items()}


def check_live_files(spec, native_files, expected_revisions):
    if set(native_files) != {x['path'] for x in spec['files']} or set(expected_revisions) != set(native_files):
        raise ValueError('Exact setup file ownership evidence is missing')
    for raw, old in native_files.items():
        current, _, revision = _read_file(Path(raw))
        if current != old or revision != expected_revisions[raw]:
            raise ValueError('Setup file revision changed after apply; automatic operation is held')


def restore(base, spec, state, token, *, expected=None, on_restored=None):
    if state['status'] not in {'applied', 'apply-failed'}:
        raise ValueError('Transaction has an unknown or committed outcome; reconcile it before rollback')
    if expected is not None:
        if state['after'] != expected['native']:
            raise ValueError('Native setup state differs from authenticated applied evidence')
        exact = revisions(expected)
    else:
        exact = state.get('after_revisions', {})
    current = capture(spec)
    check_live_files(spec, state['after']['files'], exact)
    for key in ('exists', 'enabled', 'configuration_sha256'):
        if current['service'][key] != state['after']['service'][key]:
            raise ValueError('Service configuration changed after apply; rollback is held')
    for i, row in enumerate(spec['files']):
        original = state['before']['files'][row['path']]
        if original is not None and fingerprint(base / ('file-' + str(i))) != original:
            raise ValueError('Private setup backup integrity changed')
    # The expected live state advances only after a proved local inverse. A
    # changed third object is never adopted as our restoration checkpoint.
    live_files = copy.deepcopy(state['after']['files'])
    live_revisions = copy.deepcopy(exact)
    def control(*args):
        check_live_files(spec, live_files, live_revisions)
        result = command(*args)
        check_live_files(spec, live_files, live_revisions)
        return result
    if current['service']['active'] and not state['before']['service']['active']:
        control('systemctl', 'stop', '--', spec['service'])
    if current['service']['exists'] and not state['before']['service']['exists']:
        control('systemctl', 'disable', '--', spec['service'])
    for i, row in enumerate(spec['files']):
        path = Path(row['path']); original = state['before']['files'][row['path']]
        check_live_files(spec, live_files, live_revisions)
        if original == live_files[row['path']]:
            continue
        if original is None:
            path.unlink()
        else:
            secure_directory(path.parent)
            temp = path.with_name('.sentinel-restore-' + uuid.uuid4().hex)
            try:
                shutil.copy2(base / ('file-' + str(i)), temp, follow_symlinks=False)
                os.chown(temp, original['uid'], original['gid'])
                os.chmod(temp, original['mode'])
                if fingerprint(temp) != original:
                    raise ValueError('Restoration metadata did not match its backup')
                check_live_files(spec, live_files, live_revisions)
                os.replace(temp, path)
            finally:
                temp.unlink(missing_ok=True)
        info, _, revision = _read_file(path)
        if info != original:
            raise ValueError('Restored setup file changed at installation')
        live_files[row['path']] = info; live_revisions[row['path']] = revision
    name = spec['service']; before = state['before']['service']
    control('systemctl', 'daemon-reload')
    present = service_state(name)
    if present['exists']:
        if before['enabled'] not in {'masked', 'masked-runtime'}:
            control('systemctl', 'unmask', '--', name)
        control('systemctl', 'restart' if before['active'] else 'stop', '--', name)
        if before['enabled'] == 'enabled':
            control('systemctl', 'enable', '--', name)
        elif before['enabled'] == 'enabled-runtime':
            control('systemctl', 'disable', '--', name)
            control('systemctl', 'enable', '--runtime', '--', name)
        elif before['enabled'] in {'disabled', 'masked', 'masked-runtime'} or not before['exists']:
            control('systemctl', 'disable', '--', name)
        if before['enabled'] in {'masked', 'masked-runtime'}:
            control('systemctl', 'mask', *(['--runtime'] if before['enabled'] == 'masked-runtime' else []), '--', name)
    restored = ledger_capture(spec)
    check_live_files(spec, live_files, live_revisions)
    if (restored['native']['files'] != state['before']['files']
            or restored['native']['service']['active'] != before['active']):
        raise RuntimeError('Owned rollback did not restore the declared files/service state')
    if before['exists'] and any(restored['native']['service'][key] != before[key]
                               for key in ('enabled', 'configuration_sha256')):
        raise RuntimeError('Service enablement or unit configuration was not restored')
    terminal = dict(state, status='rolled-back', restored_revisions=revisions(restored))
    # Durable completion precedes native publication/releasing claims. On crash
    # a retry can authenticate this receipt rather than guess from matching bytes.
    if on_restored is not None:
        on_restored(terminal, restored)
    check_live_files(spec, live_files, live_revisions)
    save(base / 'state.json', terminal)
    release(terminal, token)
    state.update(terminal)
    return restored


@contextlib.contextmanager
def transaction_lock(*, create=True):
    if not ROOT.exists() and not ROOT.is_symlink() and not create:
        yield
        return
    secure_directory(ROOT, create=create)
    fd = os.open(ROOT / 'lock', os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    try:
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or st.st_uid != 0 or st.st_nlink != 1 or st.st_mode & 0o077:
            raise ValueError('Untrusted transaction lock')
        deadline = time.monotonic() + 5
        while True:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() >= deadline:
                    raise ValueError('Another owned setup command is active') from None
                time.sleep(0.05)
        yield
    finally:
        os.close(fd)


def preflight_apply(spec, token, admitted, *, redo=False):
    """Read-only admission; callers hold the ledger/native locks before prepare.

    Repeated in the native executor after the durable prepare. A subsequent
    race/failure is NOT reclassified as a proved harmless refusal.

    A first setup changes a file only from its reviewed before-state. A redo
    runs the same approved step again to put back what it established, after
    damage repair could not undo (found live on 2.0.6: a corrupted generated
    file whose restore point was deleted was refused here, so the redo could
    never fix it). It may therefore replace a file in any state; the damaged
    bytes are kept in this transaction's private record and the ledger, and
    rollback returns them exactly.
    """
    base = ROOT / token
    if base.exists() or base.is_symlink():
        raise ValueError('A setup transaction cannot be replayed')
    keys = resources(spec)
    if any((ROOT / ('resource-' + key + '.json')).exists()
           or (ROOT / ('resource-' + key + '.json')).is_symlink() for key in keys):
        raise ValueError('An earlier setup transaction still owns this service or file')
    for row in spec['files']:
        original = admitted['native']['files'][row['path']]
        if redo:
            continue
        if original is None:
            if row['previous_sha256'] != 'absent':
                raise ValueError('Reviewed existing setup file is absent')
        elif original['sha256'] not in {row['sha256'], row['previous_sha256']}:
            raise ValueError('Setup file differs from the reviewed before/after hashes')
    return keys


def _apply_matches(phase, spec, apply):
    """The apply script is carried only by the apply phase (2.0.6).

    Admission, rollback and confirmation never run it: they act on the private
    record and the authenticated ledger, which the spec's apply_sha256 already
    binds. Carrying the script in all four phases put a plan with two service
    packs over the plan's total size limit. Any phase that is handed the script
    still has it checked.
    """
    if apply is None:
        return phase != 'apply'
    return isinstance(apply, str) and hashlib.sha256(apply.encode()).hexdigest() == spec['apply_sha256']


def _run(phase, spec, token, apply, *, lock_held=False, expected=None, on_restored=None, redo=False):
    if os.geteuid() != 0 or not re.fullmatch('[0-9a-f]{32}', token):
        raise PermissionError('Owned setup requires root and a bound transaction identity')
    if not _apply_matches(phase, spec, apply):
        raise ValueError('Setup command identity changed')
    if phase not in {'admit', 'apply', 'rollback', 'commit'}:
        raise ValueError('Invalid setup transaction phase')
    if phase == 'admit' and not ROOT.exists() and not ROOT.is_symlink():
        return
    with contextlib.nullcontext() if lock_held else transaction_lock():
        base = ROOT / token
        if phase == 'admit':
            if any((ROOT / ('resource-' + key + '.json')).exists() or (ROOT / ('resource-' + key + '.json')).is_symlink() for key in resources(spec)):
                raise ValueError('An earlier transaction must be reconciled before readiness or another setup')
            return
        if phase == 'apply':
            admitted = ledger_capture(spec)
            if expected is not None and admitted != expected:
                raise ValueError('Setup changed after authenticated admission')
            keys = preflight_apply(spec, token, admitted, redo=redo)
            before = admitted['native']
            secure_directory(base, create=True)
            for i, row in enumerate(spec['files']):
                original = before['files'][row['path']]
                if original is not None:
                    backup = base / ('file-' + str(i))
                    shutil.copy2(row['path'], backup, follow_symlinks=False)
                    os.chown(backup, original['uid'], original['gid'])
                    if fingerprint(backup) != original:
                        raise ValueError('Setup file changed during its snapshot')
            state = {'status': 'prepared', 'spec': spec, 'before': before, 'resources': keys}
            save(base / 'state.json', state)
            for key in keys:
                save(ROOT / ('resource-' + key + '.json'), {'transaction': token})
            environment = dict(os.environ)
            environment.pop('SENTINEL_SETUP_REDO', None)
            if redo:
                environment['SENTINEL_SETUP_REDO'] = '1'
            code = subprocess.run(['/bin/sh'], input=apply, text=True, env=environment).returncode
            if code == 43:
                # The shell could not prove its inverse safe. Never reinterpret
                # its current (possibly third-party) bytes as Sentinel-owned.
                state['status'] = 'rollback-held'
                save(base / 'state.json', state)
                raise ValueError('Failed setup rollback is held; retain snapshots and reconcile ownership')
            observed = ledger_capture(spec)
            state['after'] = observed['native']
            state['after_revisions'] = revisions(observed)
            for row in spec['files']:
                actual = state['after']['files'][row['path']]
                if actual != before['files'][row['path']] and (actual is None or actual['sha256'] != row['sha256']):
                    raise ValueError('Unexpected file mutation; keep snapshots for reconciliation')
            state['status'] = 'applied' if code == 0 else 'apply-failed'
            save(base / 'state.json', state)
            if code:
                restore(base, spec, state, token, on_restored=on_restored)
                raise SystemExit(code)
            return
        secure_directory(base)
        state = read(base / 'state.json')
        if state['spec'] != spec:
            raise ValueError('Setup rollback does not match its private record')
        if phase == 'rollback':
            restore(base, spec, state, token, expected=expected, on_restored=on_restored)
        else:
            raise ValueError('Service confirmation requires the authenticated ledger coordinator')


def ledger_capture(spec):
    native = capture(spec)
    evidence = {}
    for row in spec['files']:
        path = Path(row['path'])
        info, data, revision = _read_file(path)
        if info != native['files'][row['path']]:
            raise ValueError('Setup file changed during durable ledger capture')
        evidence[row['path']] = (None if info is None else
            {'bytes': base64.b64encode(data).decode(), 'revision': revision})
    return {'native': native, 'file_evidence': evidence}


def _semantic(value):
    if isinstance(value, dict):
        return {k: _semantic(v) for k, v in value.items() if k != 'revision'}
    if isinstance(value, list):
        return [_semantic(v) for v in value]
    return value


def _action(ledger, spec, token):
    row = next((a for a in ledger.actions(include_states=True)
                if a['action_id'] == 'setup-' + token), None)
    if (row is None or row.get('adapter') != 'setup-linux-v1'
            or row['target'].get('spec') != spec or row['target'].get('token') != token):
        raise ValueError('No matching authenticated setup ownership record')
    return row


def _check_record(row, state):
    if (state.get('spec') != row['target']['spec']
            or state.get('resources') != resources(row['target']['spec'])
            or state.get('before') != row['before']['native']
            or 'after' in row and state.get('after') != row['after']['native']):
        raise ValueError('Private setup record differs from authenticated ownership')


def _bound_record(ledger, row, state):
    _check_record(row, state)
    key = row['target'].get('native_record_hash')
    if key:
        original = ledger.state(key)
        compared = {k: v for k, v in state.items() if k not in {'status', 'restored_revisions'}}
        if compared != {k: v for k, v in original.items() if k != 'status'}:
            raise ValueError('Private setup lifecycle data differs from its authenticated record')


def _event(ledger, action_id, kind):
    found = [e for e in ledger.read() if e.get('action_id') == action_id and e['kind'] == kind]
    return found[-1] if found else None


def _no_later_owner(ledger, row):
    objects = set(row['target']['objects'])
    if any(a['sequence'] > row['sequence'] and a['status'] not in {'undone', 'cancelled'}
           and objects.intersection(a['target'].get('objects', [])) for a in ledger.actions()):
        raise ValueError('A later action owns this setup object; reconcile it first')


def _unfinished_confirmation(ledger, objects):
    for row in ledger.actions():
        if (row['adapter'] == 'setup-linux-v1' and row['status'] == 'committed'
                and set(objects).intersection(row['target'].get('objects', []))
                and _event(ledger, row['action_id'], 'setup_confirmation_intent')
                and not _event(ledger, row['action_id'], 'setup_confirmation_published')):
            raise ValueError('Finish the preceding authenticated setup confirmation before new admission')


def _complete_confirmation(ledger, spec, token):
    row = _action(ledger, spec, token)
    if row['status'] != 'committed':
        return False
    intent = _event(ledger, row['action_id'], 'setup_confirmation_intent')
    if intent is None:
        return False  # Old committed records are not evidence of interrupted new work.
    if _event(ledger, row['action_id'], 'setup_confirmation_published'):
        return True
    _no_later_owner(ledger, row)
    pending = ledger.state(intent['setup_pending_hash'])
    committed = ledger.state(intent['setup_committed_hash'])
    expected = ledger.state(intent['setup_expected_hash'])
    if (pending.get('status') != 'applied' or committed != dict(pending, status='committed')
            or expected != row['after']):
        raise ValueError('Setup confirmation proof differs from the authenticated decision')
    _bound_record(ledger, row, pending)
    path = ROOT / token / 'state.json'
    if read(path) not in (pending, committed) or ledger_capture(spec) != expected:
        raise ValueError('Setup changed during interrupted confirmation; publication held')
    if read(path) != committed:
        save(path, committed)
    if read(path) != committed or ledger_capture(spec) != expected:
        raise ValueError('Setup changed before resource release; confirmation held')
    release(committed, token)
    if read(path) != committed or ledger_capture(spec) != expected:
        raise ValueError('Setup changed before confirmation acknowledgement; review required')
    ledger.append('setup_confirmation_published', action_id=row['action_id'],
                  setup_committed_hash=intent['setup_committed_hash'])
    return True


def _record_restoration(ledger, spec, token, terminal, restored):
    row = _action(ledger, spec, token)
    if row['status'] not in {'prepared', 'applied', 'uncertain'}:
        raise ValueError('Setup inverse has no pending authenticated action')
    _bound_record(ledger, row, terminal)
    if _semantic(restored) != _semantic(row['before']):
        raise ValueError('Setup inverse differs from the authenticated before-state')
    ledger.append('setup_rollback_completed', action_id=row['action_id'],
        setup_terminal_hash=ledger.store(terminal), setup_restored_hash=ledger.store(restored))


def _reconcile_restoration(ledger, spec, token):
    row = _action(ledger, spec, token)
    receipt = _event(ledger, row['action_id'], 'setup_rollback_completed')
    if receipt is None:
        return False
    if row['status'] == 'cancelled':
        return True  # Never release a subsequent transaction's resource claims.
    if row['status'] not in {'prepared', 'applied', 'uncertain'}:
        raise ValueError('Completed inverse conflicts with current ledger status')
    _no_later_owner(ledger, row)
    restored = ledger.state(receipt['setup_restored_hash'])
    terminal = ledger.state(receipt['setup_terminal_hash'])
    _bound_record(ledger, row, terminal)
    current_state = read(ROOT / token / 'state.json')
    _bound_record(ledger, row, current_state)
    if (terminal.get('status') != 'rolled-back'
            or current_state.get('status') not in {'applied', 'apply-failed', 'rolled-back'}
            or _semantic(restored) != _semantic(row['before']) or ledger_capture(spec) != restored):
        raise ValueError('Setup restoration completion no longer matches; review required')
    save(ROOT / token / 'state.json', terminal)
    if ledger_capture(spec) != restored:
        raise ValueError('Restored setup changed before resource release')
    release(terminal, token)
    # Rebase only predecessors whose entire semantic state is this admitted
    # inverse's before-state. A same-byte outside replacement is never enough.
    objects = set(row['target']['objects'])
    for prior in ledger.actions(include_states=True):
        if (prior['adapter'] == 'setup-linux-v1' and prior['status'] == 'committed'
                and prior['sequence'] < row['sequence']
                and objects.intersection(prior['target'].get('objects', []))):
            observed = ledger_capture(prior['target']['spec'])
            if _semantic(observed) == _semantic(prior['after']):
                # Every intersecting file/service must have been admitted as
                # precisely the prior owned post-state, not a third-party edit.
                admitted = row['before']
                shared = set(observed['file_evidence']) & set(admitted['file_evidence'])
                owned = all(admitted['file_evidence'][p] == prior['after']['file_evidence'][p]
                            for p in shared)
                if owned and ledger_capture(spec) == restored:
                    ledger.append('rebased', action_id=prior['action_id'],
                                  expected_after=ledger.store(observed), inverse_action=row['action_id'])
    if ledger_capture(spec) != restored:
        raise ValueError('Restored setup changed before ledger cancellation')
    ledger.append('cancelled', action_id=row['action_id'], restored_hash=ledger.store(restored),
                  validation={'success': True, 'authenticated_completion': True})
    return True


def run(phase, spec, token, apply, *, ledger_directory=None, mode='setup'):
    if mode not in {'setup', 'redo'}:
        raise ValueError('Invalid setup mode')
    redo = mode == 'redo'
    try:
        from .mutation_ledger import MutationLedger
    except ImportError:
        from sentinel_mutation_ledger import MutationLedger
    if (os.geteuid() != 0 or not re.fullmatch('[0-9a-f]{32}', token)
            or phase not in {'admit', 'apply', 'commit', 'rollback'}
            or not _apply_matches(phase, spec, apply)):
        raise ValueError('Invalid or changed authenticated setup request')
    ledger = MutationLedger(ledger_directory)
    action_id = 'setup-' + token
    objects = ['service:' + spec['service']] + ['file:' + x['path'] for x in spec['files']]
    with ledger.lock(), transaction_lock(create=phase != 'admit'):
        if phase in {'admit', 'apply'}:
            if ledger.paused():
                raise ValueError('Emergency withdrawal has paused setup mutations')
            _unfinished_confirmation(ledger, objects)
        if phase == 'apply':
            before = ledger_capture(spec)
            preflight_apply(spec, token, before, redo=redo)
            target = {'spec': spec, 'token': token, 'objects': objects}
            try:
                ledger.prepare('setup-linux-v1', target, before, action_id=action_id, context=spec.get('ledger_context', {}))
            except RuntimeError as exc:
                raise ValueError(str(exc)) from exc
            try:
                _run(phase, spec, token, apply, lock_held=True, expected=before, redo=redo,
                     on_restored=lambda state, current: _record_restoration(ledger, spec, token, state, current))
                state = read(ROOT / token / 'state.json')
                after = ledger_capture(spec)
                if state['after'] != after['native'] or state['after_revisions'] != revisions(after):
                    raise ValueError('Setup changed before durable applied evidence')
                target['native_record_hash'] = ledger.store(state)
                ledger.append('applied', action_id=action_id, target=target,
                              after_hash=ledger.store(after), validation={'success': True, 'external': False})
            except BaseException as exc:
                # A durable applied/committed decision is never downgraded merely
                # because its acknowledgement failed. Missing proof still holds.
                if not _reconcile_restoration(ledger, spec, token):
                    row = _action(ledger, spec, token)
                    if row['status'] == 'prepared':
                        ledger.append('uncertain', action_id=action_id, reason=type(exc).__name__)
                raise
        elif phase == 'commit':
            row = _action(ledger, spec, token)
            _no_later_owner(ledger, row)
            if row['status'] == 'committed':
                _complete_confirmation(ledger, spec, token)
                state = read(ROOT / token / 'state.json'); _bound_record(ledger, row, state)
                if state['status'] != 'committed' or ledger_capture(spec) != row['after']:
                    raise ValueError('Committed setup changed; reconfirmation held')
                return
            if row['status'] != 'applied':
                raise ValueError('Only authenticated applied setup can confirm')
            state = read(ROOT / token / 'state.json'); _bound_record(ledger, row, state)
            if state['status'] != 'applied' or ledger_capture(spec) != row['after']:
                raise ValueError('Setup changed before external-health confirmation')
            intent = _event(ledger, action_id, 'setup_confirmation_intent')
            pending_hash = ledger.store(state); expected_hash = ledger.store(row['after'])
            committed_hash = ledger.store(dict(state, status='committed'))
            if intent is None:
                ledger.append('setup_confirmation_intent', action_id=action_id,
                    setup_pending_hash=pending_hash, setup_expected_hash=expected_hash,
                    setup_committed_hash=committed_hash)
            elif any(intent[k] != v for k, v in (('setup_pending_hash', pending_hash),
                    ('setup_expected_hash', expected_hash), ('setup_committed_hash', committed_hash))):
                raise ValueError('Setup confirmation intent no longer matches')
            if read(ROOT / token / 'state.json') != state or ledger_capture(spec) != row['after']:
                raise ValueError('Setup changed before durable confirmation decision')
            ledger.commit(action_id, row['after'], {'success': True, 'external_health_confirmed': True})
            _complete_confirmation(ledger, spec, token)
        elif phase == 'rollback':
            if (not (ROOT / token).exists() and not (ROOT / token).is_symlink()
                    and not any(event.get('action_id') == action_id for event in ledger.read())):
                # Apply refused before its durable prepare: no private record,
                # no claim and no ledger action exist, because every one of
                # them is written before the first change. Nothing to undo; a
                # failed rollback here used to make a clean refusal "uncertain",
                # which holds every later setup and all recovery on the host.
                print('Sentinel setup: this step was refused before it changed anything; nothing to roll back.')
                return
            row = _action(ledger, spec, token)
            if row['status'] == 'committed':
                if (_event(ledger, action_id, 'setup_confirmation_intent')
                        and not _event(ledger, action_id, 'setup_confirmation_published')):
                    _complete_confirmation(ledger, spec, token)
                raise ValueError('A committed setup requires Emergency Restore & Withdraw, not pending rollback')
            if _reconcile_restoration(ledger, spec, token):
                return
            if row['status'] != 'applied':
                raise ValueError('Uncertain setup lacks authenticated completion proof; rollback held')
            _no_later_owner(ledger, row)
            state = read(ROOT / token / 'state.json'); _bound_record(ledger, row, state)
            _run(phase, spec, token, apply, lock_held=True, expected=row['after'],
                 on_restored=lambda state, current: _record_restoration(ledger, spec, token, state, current))
            if not _reconcile_restoration(ledger, spec, token):
                raise ValueError('Setup rollback completion could not be authenticated')
        else:
            _run(phase, spec, token, apply, lock_held=True)


def _difference(before, current):
    """Name, in plain words, how the objects differ from their before-state."""
    notes = []
    was, now = before['native']['service'], current['native']['service']
    if was.get('active') != now.get('active'):
        notes.append('the service is ' + ('running' if now.get('active') else 'stopped')
                     + ' but was ' + ('running' if was.get('active') else 'stopped') + ' before this setup')
    if was.get('enabled') != now.get('enabled'):
        notes.append(f"its startup is {now.get('enabled') or 'unknown'} but was {was.get('enabled') or 'unknown'}")
    if was.get('exists') != now.get('exists') or was.get('configuration_sha256') != now.get('configuration_sha256'):
        notes.append('its unit definition changed')
    for path in sorted(before['file_evidence']):
        if _semantic(before['file_evidence'][path]) != _semantic(current['file_evidence'].get(path)):
            notes.append(f'{path} changed')
    return '; '.join(notes) or 'its recorded state differs'


def _took_effect(spec, state, current):
    """The interrupted apply's own after-state is in place and is the approved one.

    Its private record says the apply finished, the host now matches what that
    record says it achieved, the service is running, and every file holds the
    approved content. Recording that as done grants ownership of nothing but the
    reviewed setup's intended result.
    """
    if state.get('status') != 'applied' or 'after' not in state:
        return False
    if _semantic(current['native']) != _semantic(state['after']):
        return False
    service = current['native']['service']
    if not service.get('exists') or not service.get('active'):
        return False
    for row in spec['files']:
        info = current['native']['files'].get(row['path'])
        if info is None or info.get('sha256') != row['sha256']:
            return False
    return True


def reconcile_uncertain(*, ledger_directory=None):
    """Close uncertain setups on evidence, never on assumption.

    An uncertain transaction is one whose outcome could not be proven. It holds
    every later setup and all automatic recovery on the host, and it is never
    replayed or undone blindly. It is closed here in one of two cases:

    * **Nothing remains changed.** Its service and every file it covers are,
      state for state and byte for byte, what was recorded before it began.
      Its claims are released and it is recorded cancelled.
    * **It took effect.** The apply finished, the host matches the after-state
      it recorded, the service runs and every file holds its approved content.
      It is recorded applied and committed, so Withdraw can still reverse it.

    Anything else stays held, with the difference named, for review.
    """
    try:
        from .mutation_ledger import MutationLedger
    except ImportError:
        from sentinel_mutation_ledger import MutationLedger
    if os.geteuid() != 0:
        raise PermissionError('Reconciling setup transactions requires root')
    ledger = MutationLedger(ledger_directory)
    report = []
    with ledger.lock(), transaction_lock(create=False):
        for row in ledger.actions(include_states=True):
            if row.get('adapter') != 'setup-linux-v1' or row['status'] != 'uncertain':
                continue
            spec, token = row['target']['spec'], row['target']['token']
            entry = {'action_id': row['action_id'], 'service': spec['service']}
            try:
                _no_later_owner(ledger, row)
                current = ledger_capture(spec)
                record = ROOT / token / 'state.json'
                state = read(record) if record.exists() else None
                if state is not None:
                    _check_record(row, state)
                if _semantic(current) == _semantic(row['before']):
                    if state is not None:
                        release(state, token)
                        save(record, dict(state, status='reconciled'))
                    if _semantic(ledger_capture(spec)) != _semantic(row['before']):
                        raise ValueError('its objects changed during reconciliation')
                    ledger.append('cancelled', action_id=row['action_id'], restored_hash=ledger.store(current),
                                  validation={'success': True, 'authenticated_completion': False,
                                              'reconciled': 'objects match their recorded before-state'})
                    entry.update(result='reconciled', outcome='nothing changed')
                elif state is not None and _took_effect(spec, state, current):
                    target = dict(row['target'], native_record_hash=ledger.store(state))
                    ledger.append('applied', action_id=row['action_id'], target=target,
                                  after_hash=ledger.store(current),
                                  validation={'success': True, 'external': False,
                                              'reconciled': "objects match the apply's own after-state and approved content"})
                    committed = dict(state, status='committed')
                    save(record, committed)
                    release(committed, token)
                    if ledger_capture(spec) != current:
                        raise ValueError('its objects changed during reconciliation')
                    ledger.commit(row['action_id'], current,
                                  {'success': True, 'reconciled': 'approved setup found in effect'})
                    entry.update(result='reconciled', outcome='took effect')
                else:
                    raise ValueError(_difference(row['before'], current))
            except (OSError, ValueError, RuntimeError) as exc:
                entry.update(result='held', reason=str(exc)[:300])
            report.append(entry)
    return report
