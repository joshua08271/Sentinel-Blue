"""Exact declared routing objects, never a whole interface or firewall restore."""
from __future__ import annotations
import copy
from pathlib import Path
from .mutation_ledger import OwnershipConflict, LedgerError
from .withdrawal_native import semantic


class RouterAdapter:
    name = 'router-v1'
    def __init__(self, ledger):
        self.ledger = ledger

    def snapshot(self, target):
        from .network_native import ledger_snapshot
        return ledger_snapshot(target['spec'])

    def restore(self, target, before, expected):
        from . import network_native as native
        if self.snapshot(target) != expected:
            raise OwnershipConflict('A declared router object changed after Sentinel')
        base, service, table = native.names(target['spec'])
        state = __import__('json').loads(native.read(base / 'state.json'))
        if state.get('ledger_action_id') != target['action_id'] or state['status'] != 'committed' or 'before' not in state:
            raise OwnershipConflict('Router has no matching committed ownership record')
        # Bind the mutable recovery record to immutable recorded pre-state.
        if state['before'] != self.ledger.state(target['rollback_before_hash']):
            raise LedgerError('Router inverse record differs from the authenticated ledger')
        state = copy.deepcopy(state)
        state['status'] = 'pending'
        if target['spec']['forwarding']:
            # Long-lived withdrawal has authenticated before/after snapshots,
            # unlike an ambiguous legacy pending timer. Preserve that existing
            # path without trusting a mutable forwarding receipt.
            previous, after = before['forwarding'], expected['forwarding']
            if (previous not in {'0', '1'} or after != '1'
                    or state['before']['forwarding'] != previous):
                raise LedgerError('Router forwarding inverse differs from authenticated snapshots')
            state['forwarding_change'] = {'before': previous, 'after': after,
                'status': 'unchanged' if previous == after else 'applied'}
        # Pending write receipts are mutable and may predate this helper. Rebuild
        # them from the authenticated, exactly matched full-object snapshots.
        if all(key in before and key in expected for key in ('table', 'routes', 'addresses')):
            state['changes'] = native.authenticated_journal(target['spec'], before, expected)
            state['controls'] = {'timer': 'applied', 'service': 'applied'}
        elif before.get('files') or expected.get('files'):
            raise LedgerError('Router withdrawal lacks authenticated per-file inverse evidence')
        native.rollback(target['spec'], state)
        after = self.snapshot(target)
        # Compare the exact revisions produced by the native inverse as well as
        # the restored semantics. Never write metadata a second time.
        restored_files = {raw: change['after'] if change['status'] == 'restored' else change['before']
                          for raw, change in state.get('changes', {}).get('files', {}).items()}
        if after['files'] != restored_files:
            raise OwnershipConflict('Router helper changed after the native inverse; review required')
        if semantic(after) != semantic(before):
            raise LedgerError('Router inverse failed exact object validation')
        return after
