"""Bounded fingerprints of files referenced by native startup and processes.

Only paths and hashes leave this collector; command arguments are never emitted.
This is inventory, not a verdict on the intent of an unfamiliar program.
"""

from __future__ import annotations

import itertools
import re
import os
import stat
import time
from pathlib import Path, PureWindowsPath

import threading

from .protocol import PersistenceItem
from .restoration import RestorePointStore, native_identity


SCRIPT_SUFFIXES = {'.sh', '.bash', '.ksh', '.zsh', '.py', '.pyw', '.pyz', '.pyzw',
                   '.ps1', '.psm1', '.bat', '.cmd', '.vbs', '.js', '.wsf', '.hta',
                   '.php', '.phtml', '.pl', '.rb', '.lua'}

# Installers can exceed the small configuration-file limit. Hash them through
# pinned handles, streaming at most one MiB at a time, under a shared allowance.
MAX_PAYLOAD_FILE_BYTES = 512 * 1024 * 1024
MAX_PAYLOAD_TOTAL_BYTES = 512 * 1024 * 1024


MAX_CACHED_FINGERPRINTS = 512
# Every cached fingerprint is re-read within this window even when the file's
# identity is unchanged, and at most this many are re-read in any single pass so
# expiry cannot produce one very expensive collection.
FINGERPRINT_REVALIDATE_SECONDS = 900.0
FINGERPRINT_REVALIDATIONS_PER_PASS = 4


class _FingerprintCache:
    """Reuse a fingerprint only while a file's exact native identity is unchanged.

    Re-reading every running executable on every collection dominated collection
    time on hosts with large programs, and a slow collection delays recovery
    (issue #22). A cached fingerprint is reused only when the device, inode,
    size, mode, owner, group, modification time and inode-change time all match
    the previous observation, so an in-place rewrite, a replacement, a metadata
    change, or a restored modification time all miss the cache. Entries are
    re-read anyway on a rotating schedule, bounding how long an identity-
    preserving substitution could go unreported. Restoration, quarantine and
    integrity capture never consult this cache; they always read the file.
    """

    def __init__(self):
        self._lock = threading.Lock()
        self._entries = {}
        self.hits = 0
        self.misses = 0
        self.revalidations = 0

    def lookup(self, key, identity, now, budget):
        with self._lock:
            entry = self._entries.get(key)
            if entry is None or entry['identity'] != identity:
                self.misses += 1
                return None
            # A clock that moved backwards must not park an entry in the cache
            # forever; an age outside the window in either direction re-reads.
            age = now - entry['verified_at']
            if not 0 <= age < FINGERPRINT_REVALIDATE_SECONDS:
                if budget['remaining'] <= 0:
                    # Keep the known value for this pass rather than spend an
                    # unbounded amount of time re-reading everything at once.
                    self.hits += 1
                    return entry['fingerprint']
                budget['remaining'] -= 1
                self.revalidations += 1
                self.misses += 1
                return None
            self._entries[key] = self._entries.pop(key)
            self.hits += 1
            return entry['fingerprint']

    def store(self, key, identity, fingerprint, now):
        with self._lock:
            self._entries.pop(key, None)
            self._entries[key] = {'identity': identity, 'fingerprint': fingerprint, 'verified_at': now}
            while len(self._entries) > MAX_CACHED_FINGERPRINTS:
                self._entries.pop(next(iter(self._entries)))

    def reset(self):
        with self._lock:
            self._entries.clear()
            self.hits = self.misses = self.revalidations = 0


FINGERPRINTS = _FingerprintCache()


def _cacheable_identity(path):
    """Native identity of a regular, non-symlink file, or None."""
    try:
        info = os.lstat(path)
    except OSError:
        return None
    return native_identity(info) if stat.S_ISREG(info.st_mode) else None


# Which service a payload-coverage gap belongs to (2.0.16). Recovery of one
# service is held only by gaps that can concern it, so a single unrelated
# process running from a deleted executable no longer holds every service.
PAYLOAD_OWNER_NONE = ''              # belongs to no service (a login session, cron)
PAYLOAD_OWNER_ANY = '*'              # cannot be attributed: may concern any service
PAYLOAD_OWNER_ANY_RUNNING = '*running'  # an uninspected running process: may concern
                                        # any service that has running processes
SERVICE_UNIT = re.compile(r'[A-Za-z0-9:_.\\@-]{1,248}\.service')
MAX_ISSUE_OWNERS = 8


def valid_payload_owner(value):
    return (isinstance(value, str) and (value in {PAYLOAD_OWNER_NONE, PAYLOAD_OWNER_ANY, PAYLOAD_OWNER_ANY_RUNNING}
                                        or SERVICE_UNIT.fullmatch(value) is not None))


class PayloadCoverageIssue(str):
    """Typed provenance retained until the collector serializes diagnostics.

    ``owner`` is a systemd service unit, ``PAYLOAD_OWNER_NONE``,
    ``PAYLOAD_OWNER_ANY`` (the default, so an unattributed gap keeps holding
    every service) or ``PAYLOAD_OWNER_ANY_RUNNING``.
    """
    source = 'payload_fingerprint'

    def __new__(cls, text, owner=PAYLOAD_OWNER_ANY):
        issue = super().__new__(cls, text)
        issue.owner = owner if valid_payload_owner(owner) else PAYLOAD_OWNER_ANY
        return issue


def process_service_unit(entry):
    """The system service a /proc entry belongs to, from its cgroup path.

    Returns the first ``*.service`` component (``/system.slice/web.service``
    gives ``web.service``; a user manager gives ``user@UID.service``), ''
    for a process outside any service (a login session), ``None`` when the
    process has exited, and ``PAYLOAD_OWNER_ANY_RUNNING`` when unreadable.
    """
    try:
        with (entry / 'cgroup').open('rb') as stream:
            raw = stream.read(8193)
    except FileNotFoundError:
        # Gone with its /proc entry: the process exited. Otherwise the host
        # has no cgroup file, and the process cannot be attributed.
        return None if not entry.exists() else PAYLOAD_OWNER_ANY_RUNNING
    except OSError:
        return PAYLOAD_OWNER_ANY_RUNNING
    if len(raw) > 8192:
        return PAYLOAD_OWNER_ANY_RUNNING
    try:
        text = raw.decode('utf-8', 'strict')
    except UnicodeError:
        return PAYLOAD_OWNER_ANY_RUNNING
    for line in text.splitlines():
        parts = line.split(':', 2)
        if len(parts) != 3 or parts[1] not in {'', 'name=systemd'}:
            continue
        for component in parts[2].split('/'):
            if SERVICE_UNIT.fullmatch(component):
                return component
        return PAYLOAD_OWNER_NONE
    return PAYLOAD_OWNER_ANY_RUNNING


def _owners_issue(errors, text, owners):
    """Append one issue per owner; past the bound, one unattributed issue."""
    for owner in _bounded_owners(owners):
        errors.append(PayloadCoverageIssue(text, owner))


class PayloadReadBudget:
    def __init__(self, deadline, maximum=MAX_PAYLOAD_TOTAL_BYTES):
        self.deadline = deadline
        self.remaining_bytes = maximum

    def check(self):
        if time.monotonic() >= self.deadline:
            raise TimeoutError('payload fingerprint time budget exhausted')

    def consume(self, count):
        self.remaining_bytes -= count
        if self.remaining_bytes < 0:
            raise ValueError('payload fingerprint aggregate byte budget exhausted')
        self.check()


def _fingerprint_error(kind, path, exc, owner=PAYLOAD_OWNER_ANY):
    # Prefer the reason over a long pathname. The collection boundary otherwise
    # truncated the useful part of installer errors out of the telemetry.
    reason = ' '.join(str(exc).split())[:144] or type(exc).__name__
    return PayloadCoverageIssue(f'{kind} fingerprint failed: {type(exc).__name__}: {reason}; path={str(path)[:80]}',
                                owner)


def _distribution_alias(path):
    """Recognize only the standard, root-owned merged-/usr directory links."""
    if os.name != 'posix' or len(path.parts)<3:
        return path, None
    name=path.parts[1]
    if name not in {'lib','lib64','bin','sbin'}:
        return path, None
    alias=Path('/')/name
    before=alias.lstat()
    if not stat.S_ISLNK(before.st_mode):
        return path, None
    target=os.readlink(alias)
    if before.st_uid != 0 or target not in {'usr/'+name,'/usr/'+name}:
        raise ValueError('distribution directory link does not match its expected native layout')
    signature=(before.st_dev,before.st_ino,before.st_uid,before.st_ctime_ns,target)
    return Path('/usr')/name/Path(*path.parts[2:]), (alias,signature)


def _alias_unchanged(alias):
    path, signature = alias
    info=path.lstat()
    return (info.st_dev,info.st_ino,info.st_uid,info.st_ctime_ns,os.readlink(path))==signature


def referenced_paths(text: str, *, windows: bool = False, scripts_only: bool = False) -> list[str]:
    """Extract literal absolute file references; never expand or execute syntax."""
    matches = re.findall(r'''"([^"\r\n]+)"|'([^'\r\n]+)'|([^\s;|<>"']+)''', text[:262144])
    paths = []
    for match in matches:
        token = next(part for part in match if part)
        if windows:
            token = re.split(r'(?i)(?<=\.dll),',token,maxsplit=1)[0]
        if not windows and '=' in token:
            token = token.split('=', 1)[1]
        token = token.lstrip('-+!:@') if not windows else token
        path = PureWindowsPath(token) if windows else Path(token)
        if (path.is_absolute() and len(token) <= 512 and not any(c in token for c in ('$','%','*','?','\x00'))
                and (not scripts_only or path.suffix.lower() in SCRIPT_SUFFIXES)):
            if token not in paths:
                paths.append(token)
    return paths


def windows_startup_payload_paths(command):
    paths=referenced_paths(command,windows=True)
    windows=os.environ.get('WINDIR',r'C:\Windows').casefold()+'\\'
    executable_suffixes=SCRIPT_SUFFIXES|{'.exe','.com','.dll','.pyd','.scr','.msi'}
    return [path for index,path in enumerate(paths)
            if PureWindowsPath(path).suffix.lower() in executable_suffixes
            and (PureWindowsPath(path).suffix.lower() in SCRIPT_SUFFIXES or not path.casefold().startswith(windows))
            or index==0 and not PureWindowsPath(path).suffix and not path.casefold().startswith(windows)]


def fingerprint_references(references, errors, *, kind='startup-payload', max_files=256, seconds=5.0,
                           owners=None):
    """Read bounded regular files with the same race/alias checks as quarantine.

    ``owners`` maps a reference to the services it belongs to. A gap is
    reported once per owner so that it holds only the recovery it concerns;
    without an owner a gap may concern any service.
    """
    import hashlib
    deadline = time.monotonic() + seconds
    budget = PayloadReadBudget(deadline)
    now = time.time()
    revalidations = {'remaining': FINGERPRINT_REVALIDATIONS_PER_PASS}
    owners = owners or {}

    def owned(name):
        return owners.get(name) or {PAYLOAD_OWNER_ANY}

    items, seen, aliases = [], set(), set()
    for position, name in enumerate(references):
        if name in seen:
            continue
        if len(seen) >= max_files or time.monotonic() >= deadline:
            _owners_issue(errors, f'{kind} inventory reached its file/time bound',
                          {owner for rest in references[position:] if rest not in seen for owner in owned(rest)})
            break
        seen.add(name)
        path = Path(name)
        try:
            # Windows must enter the pinned no-reparse reader before any path
            # probe: is_file() can follow a malicious junction/UNC reference.
            if os.name != 'nt' and not path.is_file():
                continue
            native_path, alias = _distribution_alias(path)
            if os.name == 'nt':
                from .restoration import _windows_read_file_snapshot
                # Multiple hard links are normal for installed Windows programs.
                # Read only, under a pinned handle; quarantine stays single-link.
                budget.check()
                if budget.remaining_bytes <= 0:
                    raise ValueError('payload fingerprint aggregate byte budget exhausted')
                digest, _ = _windows_read_file_snapshot(
                    native_path, min(MAX_PAYLOAD_FILE_BYTES, budget.remaining_bytes),
                    capture_security=False, allow_hard_links=True,
                    read_budget=budget, hash_only=True)
                fingerprint = digest.hex()
                metadata = {}
            else:
                # Running executables are commonly larger than a restorable
                # configuration file. Stream the digest under the same aggregate
                # budget instead of reporting a coverage error for every large
                # program, which previously blocked baseline approval.
                budget.check()
                identity = _cacheable_identity(native_path)
                fingerprint = (FINGERPRINTS.lookup(str(native_path), identity, now, revalidations)
                               if identity is not None else None)
                if fingerprint is not None:
                    metadata = {'uid': identity[4]}
                else:
                    if budget.remaining_bytes <= 0:
                        raise ValueError('payload fingerprint aggregate byte budget exhausted')
                    fingerprint, metadata, read = RestorePointStore._hash_target(
                        native_path, maximum=min(MAX_PAYLOAD_FILE_BYTES, budget.remaining_bytes))
                    budget.consume(read)
                    # Cache the identity observed with the bytes, not a later stat.
                    if metadata.get('identity') is not None:
                        FINGERPRINTS.store(str(native_path), metadata['identity'], fingerprint, now)
            if alias:
                if not _alias_unchanged(alias):
                    raise ValueError('distribution directory alias changed during inventory')
                if str(alias[0]) not in aliases:
                    aliases.add(str(alias[0]))
                    items.append(PersistenceItem(kind+'-path-link',str(alias[0]),'0',True,
                        hashlib.sha256(alias[1][-1].encode()).hexdigest()))
            items.append(PersistenceItem(kind, str(path), str(metadata.get('uid', 'unknown')),
                                         True, fingerprint))
        except FileNotFoundError as exc:
            if os.name != 'nt':
                for owner in _bounded_owners(owned(name)):
                    errors.append(_fingerprint_error(kind, path, exc, owner))
        except (OSError, ValueError) as exc:
            # A failed read is visible and cannot silently establish coverage.
            for owner in _bounded_owners(owned(name)):
                errors.append(_fingerprint_error(kind, path, exc, owner))
    return items


def _bounded_owners(owners):
    owners = sorted(set(owners))
    return owners if 1 <= len(owners) <= MAX_ISSUE_OWNERS else [PAYLOAD_OWNER_ANY]


def startup_file_owner(item):
    """The service whose startup a persistence file's references belong to.

    A service unit file or its drop-in belongs to that service; cron, shell
    and login startup files belong to no service. Other systemd files (a
    socket or path unit) may start any service, so they stay unattributed.
    """
    if item.kind != 'systemd-file':
        return PAYLOAD_OWNER_NONE
    path = Path(item.name)
    if SERVICE_UNIT.fullmatch(path.name):
        return path.name
    if path.parent.name.endswith('.service.d') and SERVICE_UNIT.fullmatch(path.parent.name[:-2]):
        return path.parent.name[:-2]
    return PAYLOAD_OWNER_ANY


def linux_startup_payloads(entries, errors):
    references, owners = [], {}
    deadline = time.monotonic() + 3.0
    for item in entries:
        if time.monotonic() >= deadline:
            errors.append('startup reference parsing reached its time bound')
            break
        if item.kind not in {'startup-file', 'cron', 'user-cron', 'shell-startup', 'systemd-file'}:
            continue
        try:
            data, _ = RestorePointStore._read_target(Path(item.name))
            text = data[:262144].decode('utf-8', 'strict')
        except (OSError, ValueError, UnicodeError):
            continue
        for path in referenced_paths(text):
            if (Path(path).suffix.lower() in SCRIPT_SUFFIXES or
                    path.startswith(('/opt/', '/srv/', '/home/', '/root/', '/tmp/', '/var/tmp/', '/usr/local/'))):
                references.append(path)
                owners.setdefault(path, set()).add(startup_file_owner(item))
    return fingerprint_references(references, errors, owners=owners)


def _unscanned_issue(errors, text, first, rest, *, seconds=0.5, maximum=8192):
    """Report a scan bound once per service that has an uninspected process.

    Reading only each remaining process's cgroup is cheap, so a bound that an
    attacker can reach with many processes in a login session no longer holds
    the recovery of every running service. What this pass cannot attribute
    (its own bound, an unreadable cgroup, more than MAX_ISSUE_OWNERS
    services) stays unattributed to any running service.
    """
    deadline = time.monotonic() + seconds
    owners, count = set(), 0
    for entry in itertools.chain((first,), rest):
        count += 1
        if count > maximum or time.monotonic() >= deadline:
            owners.add(PAYLOAD_OWNER_ANY_RUNNING)
            break
        owner = process_service_unit(entry)
        if owner is not None:
            owners.add(owner)
        if len(owners) > MAX_ISSUE_OWNERS:
            break
    if len(owners) > MAX_ISSUE_OWNERS:
        owners = {PAYLOAD_OWNER_ANY_RUNNING}
    for owner in sorted(owners):
        errors.append(PayloadCoverageIssue(text, owner))


class _LazyUnit:
    """Resolve a process's owning service once, on first use."""
    def __init__(self, entry):
        self.entry, self.resolved, self.value = entry, False, None

    def __call__(self):
        if not self.resolved:
            self.value, self.resolved = process_service_unit(self.entry), True
        return self.value


def linux_process_payloads(errors, *, proc_root=Path('/proc')):
    """Inventory script arguments and non-distribution running executables.

    Relative script arguments are anchored to the process's observed cwd. Native
    process links locate candidates only; fingerprinting still refuses arbitrary
    symlinks, and this inventory never authorizes killing a PID or removing a file.
    """
    references, owners = [], {}
    deadline = time.monotonic() + 1.0

    def issue(text, owner):
        owner = owner() if callable(owner) else owner
        # A process that exited while being inspected has no gap to report.
        if owner is not None:
            errors.append(PayloadCoverageIssue(text, owner))

    def reference(path, owner):
        owner = owner()
        references.append(path)
        owners.setdefault(path, set()).add(PAYLOAD_OWNER_ANY_RUNNING if owner is None else owner)

    try:
        entries = (p for p in proc_root.iterdir() if p.name.isdigit())
        for index, entry in enumerate(entries):
            if index >= 4096 or time.monotonic() >= deadline:
                # Name the services whose processes were left uninspected.
                _unscanned_issue(errors, 'process payload enumeration reached its process/time bound',
                                 entry, entries)
                break
            if len(references) >= 512:
                _unscanned_issue(errors, 'process payload reference inventory reached its bound', entry, entries)
                break
            # Read the owning service only for a process that has a payload
            # reference or gap; most processes run distribution binaries.
            unit = _LazyUnit(entry)
            try:
                executable = os.readlink(entry / 'exe')
                if executable.endswith(' (deleted)'):
                    issue('running executable was unlinked; on-disk payload coverage is incomplete', unit)
                    # Replacing a service binary leaves the process on the old
                    # unlinked inode, so nothing referenced the file now at that
                    # path and the replacement went uninventoried. Fingerprint
                    # the current file as well; the running image is still gone,
                    # which is why the coverage issue above is also reported.
                    replaced = executable[:-len(' (deleted)')]
                    if (replaced.startswith(('/opt/', '/srv/', '/home/', '/root/', '/tmp/', '/var/tmp/', '/usr/local/'))
                            and replaced not in references):
                        try:
                            if stat.S_ISREG(os.lstat(replaced).st_mode):
                                reference(replaced, unit)
                        except OSError:
                            pass  # Nothing at that path now; the note above stands.
                elif executable.startswith(('/opt/', '/srv/', '/home/', '/root/', '/tmp/', '/var/tmp/', '/usr/local/')):
                    reference(executable, unit)
            except FileNotFoundError:
                pass  # Kernel threads and processes that already exited.
            except OSError:
                issue('a running executable reference could not be inspected', unit)
            try:
                with (entry / 'cmdline').open('rb') as stream:
                    raw = stream.read(32769)
                if len(raw) > 32768:
                    issue('process command reference exceeded its byte bound', unit)
                    continue
                # NUL-separated arguments remain separate, including quoted paths.
                for arg in raw.split(b'\0'):
                    text = arg.decode('utf-8', 'strict')
                    path = Path(text)
                    if path.suffix.lower() not in SCRIPT_SUFFIXES or len(text) > 512 or text.startswith('-'):
                        continue
                    if not path.is_absolute():
                        cwd = Path(os.readlink(entry / 'cwd'))
                        if not cwd.is_absolute() or str(cwd).endswith(' (deleted)'):
                            issue('relative process payload has no stable working directory', unit)
                            continue
                        path = cwd / path
                    reference(str(path), unit)
                    if len(references) >= 512:
                        # This process's remaining arguments go uninspected.
                        issue('process payload reference inventory reached its bound', unit)
                        break
            except FileNotFoundError:
                continue
            except (OSError, UnicodeError, ValueError):
                issue('a process payload command reference could not be inspected', unit)
    except OSError:
        errors.append('process payload references unavailable')
    return fingerprint_references(references, errors, kind='process-payload', max_files=128, seconds=3.0,
                                  owners=owners)
