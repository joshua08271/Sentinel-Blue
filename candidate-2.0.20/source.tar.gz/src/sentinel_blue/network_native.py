"""Standalone native router transaction; also installed as its own boot/rollback helper.

Only the named Sentinel table, declared additional routes/addresses, and IPv4
forwarding are changed. The systemd rollback timer outlives SSH and the desktop.
"""
from __future__ import annotations

import base64
import contextlib
import copy
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import time
import uuid


def command(arguments, data=None, *, allowed=(0,), timeout=15):
    result = subprocess.run(arguments, input=data, text=True, capture_output=True, timeout=timeout,
                            env={'PATH': '/usr/sbin:/usr/bin:/sbin:/bin', 'LANG': 'C.UTF-8'})
    if result.returncode not in allowed:
        raise RuntimeError('Native router command failed: ' + arguments[0] + ' (exit ' + str(result.returncode) + ')')
    return result


def digest(value):
    return hashlib.sha256(value if isinstance(value, bytes) else json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def secure(path, *, create=False):
    if create:
        ancestor = path
        while not ancestor.exists() and not ancestor.is_symlink():
            ancestor = ancestor.parent
        secure(ancestor)
        path.mkdir(mode=0o700, parents=True, exist_ok=True)
    for parent in (path, *path.parents):
        info = parent.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
            raise ValueError('Router state and configuration require trusted root-owned directories')


def read(path):
    flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK
    fd = os.open(path, flags)
    try:
        info = os.fstat(fd)
        limit = 4 * 1024 * 1024
        if not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or info.st_nlink != 1 or info.st_size > limit or info.st_mode & 0o022:
            raise ValueError('Unsafe router state or configuration file')
        data = bytearray()
        while len(data) <= limit:
            block = os.read(fd, min(65536, limit + 1 - len(data)))
            if not block:
                break
            data.extend(block)
        if len(data) > limit:
            raise ValueError('Router state or configuration exceeds the read limit')
        def revision(st):
            return (st.st_dev, st.st_ino, st.st_mode, st.st_uid, st.st_gid,
                    st.st_nlink, st.st_size, st.st_mtime_ns, st.st_ctime_ns)
        if revision(info) != revision(os.fstat(fd)) or revision(info) != revision(path.lstat()):
            raise ValueError('Router state or configuration changed during read')
        return bytes(data)
    finally:
        os.close(fd)


def write(path, value, mode=0o600):
    secure(path.parent)
    if path.is_symlink():
        raise ValueError('Router files cannot be symbolic links')
    temporary = path.with_name('.' + path.name + '.' + uuid.uuid4().hex)
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, mode)
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(value)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        temporary.unlink(missing_ok=True)


def save(path, value):
    raw = json.dumps(value, sort_keys=True).encode()
    if len(raw) > 4 * 1024 * 1024:
        raise ValueError('Router state exceeds its durable read limit; review required')
    write(path, raw)


def names(spec):
    name = spec['name']
    if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{0,31}', name):
        raise ValueError('Invalid router name')
    base = Path('/var/lib/sentinel-blue-network') / name
    service = 'sentinel-router-' + name
    return base, service, 'sentinel_blue_' + name


def table_data(table, *, json_output=False):
    result = command(['nft', *(['-j'] if json_output else []), 'list', 'table', 'inet', table], allowed=(0, 1))
    if result.returncode:
        # Distinguish an absent table from a broken netlink/permission query.
        tables = json.loads(command(['nft', '-j', 'list', 'tables']).stdout)
        if any(row.get('table', {}).get('name') == table and row['table'].get('family') == 'inet' for row in tables['nftables']):
            raise RuntimeError('Router table query did not complete')
        return None
    return json.loads(result.stdout) if json_output else result.stdout


def table_fingerprint(table):
    data = table_data(table, json_output=True)
    if data is None:
        return None
    def clean(value):
        if isinstance(value, list):
            return [clean(x) for x in value if not isinstance(x, dict) or 'metainfo' not in x]
        if isinstance(value, dict):
            return {key: clean(item) for key, item in value.items() if key not in {'handle', 'index', 'packets', 'bytes'}}
        return value
    return digest(clean(data))


def route_present(row):
    existing = json.loads(command(['ip', '-j', '-4', 'route', 'show', 'exact', row['destination']]).stdout)
    if not existing:
        return False
    if len(existing) != 1 or existing[0].get('gateway') != row['via'] or existing[0].get('dev') != row['interface']:
        raise ValueError('A declared route conflicts with an existing route; review is required')
    return True


def address_present(row):
    ip, prefix = row['address'].split('/')
    data = json.loads(command(['ip', '-j', '-4', 'address', 'show', 'dev', row['interface']]).stdout)
    return any(item.get('local') == ip and item.get('prefixlen') == int(prefix) for interface in data for item in interface.get('addr_info', []))


def route_argv(row, operation):
    return ['ip', '-4', 'route', operation, row['destination'], 'via', row['via'], 'dev', row['interface']]


def address_argv(row, operation):
    return ['ip', '-4', 'address', operation, row['address'], 'dev', row['interface']]


def units(base, service, seconds):
    interpreter = str(Path(sys.executable).absolute())
    if not re.fullmatch(r'/[A-Za-z0-9_./ -]+', interpreter) or '..' in Path(interpreter).parts:
        raise ValueError('Router helper interpreter must be a safe absolute path')
    interpreter = '"' + interpreter + '" -I -B'
    runner = str(base / 'native.py')
    state = str(base / 'state.json')
    header = '[Unit]\nDescription=Sentinel Blue declared router\nAfter=network-online.target\nWants=network-online.target\n'
    return {
        Path('/etc/systemd/system') / (service + '.service'): header + f'[Service]\nType=oneshot\nExecStart={interpreter} {runner} boot {state}\nRemainAfterExit=yes\n[Install]\nWantedBy=multi-user.target\n',
        Path('/etc/systemd/system') / (service + '-rollback.service'): '[Unit]\nDescription=Sentinel Blue pending network rollback\nStartLimitIntervalSec=0\n[Service]\nType=oneshot\nRestart=on-failure\nRestartSec=2s\n' + f'ExecStart={interpreter} {runner} rollback {state}\n',
        Path('/etc/systemd/system') / (service + '-rollback.timer'): '[Unit]\nDescription=Sentinel Blue network confirmation deadline\n[Timer]\n' + f'OnActiveSec={seconds}s\nAccuracySec=1s\nUnit={service}-rollback.service\n[Install]\nWantedBy=timers.target\n',
    }


def verify(spec, state, *, boot_check=False):
    base, service, table = names(spec)
    if state is None or state.get('status') not in {'pending', 'committed'} or state.get('spec') != spec:
        return False
    if table_fingerprint(table) != state.get('table_fingerprint'):
        return False
    if state['status'] == 'committed':
        try:
            ledger = mutation_ledger()
            with ledger.lock():
                committed_action(ledger, state, files_only=True, boot_check=boot_check)
        except (OSError, RuntimeError, ValueError, KeyError, TypeError):
            return False
    if state['status'] == 'pending':
        changes = state.get('changes')
        if changes is None or changes.get('version') != 1:
            return False
        for kind, target, change in journal_entries(changes):
            if change.get('status') != 'applied' or observe_change(spec, kind, target) != change.get('after'):
                return False
    if spec['forwarding'] and forwarding_value() != '1':
        return False
    if not all(route_present(row) for row in spec['routes']) or not all(address_present(row) for row in spec['addresses']):
        return False
    for path, expected in state.get('files', {}).items():
        if digest(read(Path(path))) != expected:
            return False
    return command(['systemctl', 'is-enabled', '--quiet', service + '.service'], allowed=(0, 1)).returncode == 0


def forwarding_value():
    value = Path('/proc/sys/net/ipv4/ip_forward').read_text().strip()
    if value not in {'0', '1'}:
        raise ValueError('IPv4 forwarding observation is invalid')
    return value


def rollback_forwarding_value(spec, state):
    """Return only a proven owned inverse; absent/ambiguous receipts fail closed."""
    if not spec['forwarding']:
        return None
    change = state.get('forwarding_change')
    if change is None:
        # Older records cannot prove a 0->1 write. A pre-existing 1 never
        # required an inverse, so preserve it (and any subsequent outside edit).
        if state['before']['forwarding'] == '1':
            return None
        raise ValueError('IPv4 forwarding write ownership is unknown; rollback needs review')
    if (change.get('before') != state['before']['forwarding'] or change.get('after') != '1'
            or change.get('before') not in {'0', '1'}):
        raise ValueError('IPv4 forwarding ownership receipt is invalid')
    status = change.get('status')
    if status in {'unchanged', 'not-written'}:
        return None
    if status == 'restored':
        if forwarding_value() != change['before']:
            raise ValueError('IPv4 forwarding changed after rollback; review required')
        return None
    if status != 'applied' or change['before'] == change['after']:
        raise ValueError('IPv4 forwarding write outcome is uncertain; rollback needs review')
    if forwarding_value() != change['after']:
        raise ValueError('IPv4 forwarding changed after setup; rollback needs review')
    return change['before']


def semantic(value):
    """Revision-free equality is used only to validate a completed restoration."""
    if isinstance(value, dict):
        return {key: semantic(item) for key, item in value.items() if key != 'revision'}
    if isinstance(value, list):
        return [semantic(item) for item in value]
    return value


def file_record(path):
    secure(path.parent)
    try:
        info = path.lstat()
    except FileNotFoundError:
        return None
    value = read(path)
    attrs = {name: base64.b64encode(os.getxattr(path, name, follow_symlinks=False)).decode()
             for name in os.listxattr(path, follow_symlinks=False)}
    def rev(st):
        return [st.st_dev, st.st_ino, st.st_ctime_ns, st.st_mtime_ns]
    if rev(info) != rev(path.lstat()):
        raise ValueError('Router helper changed during ownership capture')
    return {'bytes': base64.b64encode(value).decode(),
            'metadata': {'mode': stat.S_IMODE(info.st_mode), 'uid': info.st_uid,
                         'gid': info.st_gid, 'xattrs': attrs}, 'revision': rev(info)}


def replace_owned_file(path, value, expected, *, metadata=None):
    """Stage an exact file and recheck ownership immediately before replacement."""
    secure(path.parent)
    if file_record(path) != expected:
        raise ValueError('Router helper changed before write; rollback needs review')
    creation_metadata = metadata is None
    metadata = copy.deepcopy(metadata) if metadata is not None else {'mode': 0o600, 'uid': 0, 'gid': 0, 'xattrs': {}}
    temporary = path.with_name('.' + path.name + '.' + uuid.uuid4().hex)
    fd = os.open(temporary, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        with os.fdopen(fd, 'wb', closefd=False) as stream:
            stream.write(value)
            stream.flush()
        os.fchown(fd, metadata['uid'], metadata['gid'])
        os.fchmod(fd, metadata['mode'])
        if creation_metadata:
            # Preserve security labels/default attributes assigned by the target
            # filesystem rather than stripping them from a newly created helper.
            metadata['xattrs'] = {name: base64.b64encode(os.getxattr(fd, name)).decode()
                                  for name in os.listxattr(fd)}
        for name in os.listxattr(fd):
            if name not in metadata.get('xattrs', {}):
                os.removexattr(fd, name)
        for name, encoded in metadata.get('xattrs', {}).items():
            os.setxattr(fd, name, base64.b64decode(encoded, validate=True))
        os.fsync(fd)
        if file_record(path) != expected:
            raise ValueError('Router helper changed at write boundary; rollback needs review')
        os.replace(temporary, path)
        installed = os.fstat(fd)
        record = file_record(path)
        if (record is None or record['revision'] != [installed.st_dev, installed.st_ino,
                installed.st_ctime_ns, installed.st_mtime_ns]
                or record['bytes'] != base64.b64encode(value).decode()
                or record['metadata'] != metadata):
            raise ValueError('Router helper changed before post-state receipt')
        directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
        return record
    finally:
        os.close(fd)
        temporary.unlink(missing_ok=True)


def table_snapshot(table):
    raw = table_data(table)
    return re.sub(r'counter packets [0-9]+ bytes [0-9]+', 'counter packets 0 bytes 0', raw) if raw is not None else None


def route_snapshot(row):
    value = json.loads(command(['ip', '-j', '-4', 'route', 'show', 'exact', row['destination']]).stdout)
    if not isinstance(value, list) or any(not isinstance(item, dict) for item in value):
        raise ValueError('Invalid route ownership observation')
    return value


def address_snapshot(row):
    address, prefix = row['address'].split('/')
    entries = json.loads(command(['ip', '-j', '-4', 'address', 'show', 'dev', row['interface']]).stdout)
    return [item for interface in entries for item in interface.get('addr_info', [])
            if item.get('local') == address and item.get('prefixlen') == int(prefix)]


def journal_entries(changes):
    yield 'table', None, changes['table']
    for raw, change in changes['files'].items():
        yield 'file', raw, change
    for kind in ('routes', 'addresses'):
        for change in changes[kind]:
            yield kind, change['row'], change


def observe_change(spec, kind, target):
    if kind == 'file':
        return file_record(Path(target))
    if kind == 'table':
        return table_snapshot(names(spec)[2])
    return route_snapshot(target) if kind == 'routes' else address_snapshot(target)


def check_change(spec, kind, target, change):
    status = change.get('status')
    if status == 'not-written':
        # A planned route/address/table is not an owned mutation. Never remove
        # it merely because somebody else created it before our failed apply.
        if kind == 'file' and observe_change(spec, kind, target) != change['before']:
            raise ValueError('Unwritten router helper changed; rollback needs review')
        return False
    if status not in {'applied', 'restored'} or 'after' not in change:
        raise ValueError('Router write outcome is uncertain; rollback needs review')
    if observe_change(spec, kind, target) != change['after']:
        raise ValueError('Router object changed after setup; rollback needs review')
    return status == 'applied'


def perform_change(spec, state, kind, target, change, operation):
    base = names(spec)[0]
    if change.get('status') != 'not-written' or observe_change(spec, kind, target) != change['before']:
        raise ValueError('Router object changed before setup write; review required')
    change['status'] = 'writing'
    save(base / 'state.json', state)
    if observe_change(spec, kind, target) != change['before']:
        raise ValueError('Router object changed at setup write boundary; review required')
    produced = operation()
    after = produced if kind == 'file' else observe_change(spec, kind, target)
    if kind == 'file' and observe_change(spec, kind, target) != produced:
        raise ValueError('Router helper changed before ownership receipt')
    if kind == 'table' and after is None:
        raise ValueError('Router table write was not observed')
    if kind == 'routes' and (len(after) != 1 or after[0].get('gateway') != target['via']
                             or after[0].get('dev') != target['interface']):
        raise ValueError('Router route write was not observed')
    if kind == 'addresses' and len(after) != 1:
        raise ValueError('Router address write was not observed')
    change.update(status='applied', after=after)
    save(base / 'state.json', state)


def rollback_journal(spec, state):
    changes = state.get('changes')
    if changes is None:
        # Compatibility for a forwarding-only record with no possible other
        # mutations. Nonempty legacy pending records cannot prove write ownership.
        previous = state['before']
        if (state.get('files') or previous.get('files') or previous.get('added_routes')
                or previous.get('added_addresses') or previous.get('table') is not None
                or state.get('table_fingerprint') or table_data(names(spec)[2]) is not None):
            raise ValueError('Router pending record lacks per-object ownership; rollback needs review')
        changes = {'version': 1, 'files': {}, 'routes': [], 'addresses': [],
                   'table': {'status': 'not-written', 'before': None}}
    if (changes.get('version') != 1 or set(changes['files']) != set(state.get('files', {}))
            or [x['row'] for x in changes['routes']] != state['before']['added_routes']
            or [x['row'] for x in changes['addresses']] != state['before']['added_addresses']):
        raise ValueError('Router ownership journal is inconsistent; rollback needs review')
    previous = state['before']
    previous_table = previous['table']
    previous_table = re.sub(r'counter packets [0-9]+ bytes [0-9]+', 'counter packets 0 bytes 0', previous_table) if previous_table is not None else None
    if changes['table'].get('before') != previous_table:
        raise ValueError('Router table inverse differs from its ownership receipt')
    for raw, change in changes['files'].items():
        old = change.get('before')
        if ((None if old is None else old['bytes']) != previous['files'].get(raw)
                or ('file_records' in previous and old != previous['file_records'].get(raw))):
            raise ValueError('Router file inverse differs from its ownership receipt')
    for kind in ('routes', 'addresses'):
        if any(change.get('before') != [] for change in changes[kind]):
            raise ValueError('A router addition has invalid preceding-state evidence')
    if any(status not in {'not-written', 'applied', 'restored'} for status in state.get('controls', {}).values()):
        raise ValueError('Router service-control outcome is uncertain; rollback needs review')
    for kind, target, change in journal_entries(changes):
        check_change(spec, kind, target, change)
    return changes


def restore_change(spec, state, kind, target, change):
    if not check_change(spec, kind, target, change):
        return
    base, _service, table = names(spec)
    change['status'] = 'restoring'
    save(base / 'state.json', state)
    if observe_change(spec, kind, target) != change['after']:
        raise ValueError('Router object changed at rollback write boundary; review required')
    if kind == 'table':
        text = ('delete table inet ' + table + '\n' if change['after'] is not None else '')
        text += state['before']['table'] or ''
        if text:
            command(['nft', '--file', '-'], text)
    elif kind in {'routes', 'addresses'}:
        command(route_argv(target, 'del') if kind == 'routes' else address_argv(target, 'del'))
    elif change['before'] is None:
        Path(target).unlink()
        directory = os.open(Path(target).parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    else:
        old = change['before']
        replace_owned_file(Path(target), base64.b64decode(old['bytes'], validate=True),
                           change['after'], metadata=old['metadata'])
    restored = observe_change(spec, kind, target)
    if semantic(restored) != semantic(change['before']):
        raise ValueError('Router inverse did not restore exact recorded state')
    change.update(status='restored', after=restored)
    save(base / 'state.json', state)


def authenticated_journal(spec, before, expected):
    """Called only after an adapter verifies authenticated ledger snapshots."""
    def receipt(old, new):
        return {'before': old, 'after': new, 'status': 'not-written' if old == new else 'applied'}
    return {'version': 1,
            'files': {raw: receipt(old, expected['files'][raw]) for raw, old in before['files'].items()},
            'table': receipt(before['table'], expected['table']),
            'routes': [dict(receipt([], expected['routes'][row['destination']]), row=row)
                       for row in spec['routes'] if not before['routes'][row['destination']]],
            'addresses': [dict(receipt([], expected['addresses'][row['interface'] + ':' + row['address']]), row=row)
                          for row in spec['addresses'] if not before['addresses'][row['interface'] + ':' + row['address']]]}


def install_runtime(spec, *, pending=None):
    _base, _service, table = names(spec)
    changes = pending.get('changes') if pending is not None else None
    for kind, present, argv in (('addresses', address_present, address_argv), ('routes', route_present, route_argv)):
        for row in spec[kind]:
            if not present(row):
                if changes is None:
                    command(argv(row, 'add'))
                else:
                    receipt = next((x for x in changes[kind] if x['row'] == row), None)
                    if receipt is None:
                        raise ValueError('A pre-existing router object disappeared before apply')
                    perform_change(spec, pending, kind, row, receipt, lambda row=row, argv=argv: command(argv(row, 'add')))
            elif changes is not None and any(x['row'] == row for x in changes[kind]):
                raise ValueError('A planned router addition appeared before its write; review required')
    text = ('delete table inet ' + table + '\n' if table_data(table) is not None else '') + spec['ruleset']
    command(['nft', '--check', '--file', '-'], text)
    if changes is None:
        command(['nft', '--file', '-'], text)
    else:
        perform_change(spec, pending, 'table', None, changes['table'], lambda: command(['nft', '--file', '-'], text))
    if spec['forwarding']:
        if pending is None:
            command(['sysctl', '-w', 'net.ipv4.ip_forward=1'])
        else:
            change = pending['forwarding_change']
            if forwarding_value() != change['before']:
                raise ValueError('IPv4 forwarding changed before setup write; review required')
            if change['before'] != change['after']:
                base, _service, _table = names(spec)
                change['status'] = 'writing'
                save(base / 'state.json', pending)
                if forwarding_value() != change['before']:
                    raise ValueError('IPv4 forwarding changed at setup write boundary; review required')
                command(['sysctl', '-w', 'net.ipv4.ip_forward=1'])
                if forwarding_value() != change['after']:
                    raise ValueError('IPv4 forwarding changed before post-state confirmation')
                change['status'] = 'applied'
                save(base / 'state.json', pending)


def rollback(spec, state, *, record_completion=False):
    base, service, table = names(spec)
    if state is None or state.get('status') != 'pending':
        return
    if state.get('spec') != spec:
        raise ValueError('Rollback does not match the pending router configuration')
    previous = state['before']
    if record_completion and state.get('ledger_action_id'):
        with mutation_ledger().lock():
            rollback_action(mutation_ledger(), spec, state)
    rollback_forwarding_value(spec, state)  # Preflight before any rollback mutation.
    changes = rollback_journal(spec, state)  # Always preflight, including early failures.
    state['changes'] = changes
    restore_change(spec, state, 'table', None, changes['table'])
    for kind in ('routes', 'addresses'):
        for change in reversed(changes[kind]):
            restore_change(spec, state, kind, change['row'], change)
    restore_forwarding = rollback_forwarding_value(spec, state)  # Recheck at the write boundary.
    if restore_forwarding is not None:
        state['forwarding_change']['status'] = 'restoring'
        save(base / 'state.json', state)
        # Saving the intent also takes time: do not overwrite a later outside change.
        if forwarding_value() != state['forwarding_change']['after']:
            raise ValueError('IPv4 forwarding changed before rollback write; review required')
        command(['sysctl', '-w', 'net.ipv4.ip_forward=' + restore_forwarding])
        if forwarding_value() != restore_forwarding:
            raise ValueError('IPv4 forwarding rollback did not retain its expected state')
        state['forwarding_change']['status'] = 'restored'
        save(base / 'state.json', state)
    # Only undo service-control steps that were attempted by this transaction.
    controls = state.get('controls', {})
    for key, args in (('timer', ['systemctl', 'disable', '--now', service + '-rollback.timer']),
                      ('service', ['systemctl', 'disable', service + '.service'])):
        if controls.get(key) in {'writing', 'applied'}:
            # Recheck helpers before a service command can consume them.
            for raw, change in changes['files'].items():
                check_change(spec, 'file', raw, change)
            command(args, allowed=(0, 1))
            controls[key] = 'restored'
            save(base / 'state.json', state)
    for raw, change in changes['files'].items():
        restore_change(spec, state, 'file', raw, change)
    old = previous.get('state')
    # Keep the pending identity until object AND service-control restoration finish.
    command(['systemctl', 'daemon-reload'])
    if old and old['status'] == 'committed':
        command(['systemctl', 'enable', service + '.service'])
    # Final service controls can consume files or race with an outside writer.
    # Withdrawal must check the same completed receipts as setup rollback.
    rollback_journal(spec, state)
    rollback_forwarding_value(spec, state)
    restored_state = old or {'status': 'rolled-back', 'spec': spec}
    if record_completion and state.get('ledger_action_id'):
        record_rollback_completion(spec, state, restored_state)
    save(base / 'state.json', restored_state)


def apply(spec, state, source, *, action_id=None):
    base, service, table = names(spec)
    if state and state.get('status') == 'pending':
        raise ValueError('A router transaction is pending; verify or roll it back before another setup')
    if verify(spec, state):
        return
    if state and state.get('status') == 'committed' and not verify(state['spec'], state):
        raise ValueError('Existing managed router state changed; review is required')
    if state and state.get('status') == 'committed':
        with mutation_ledger().lock():
            committed_action(mutation_ledger(), state)
    previous_table = table_data(table)
    if previous_table is not None and (not state or state.get('status') != 'committed'):
        raise ValueError('Existing router table has no trusted ownership record')
    content = {**units(base, service, spec['rollback_seconds']), base/'native.py': source}
    before_files = {}
    before_records = {}
    for path in content:
        secure(path.parent)
        before_records[str(path)] = file_record(path)
        if path.exists() or path.is_symlink():
            value = read(path)
            if not state or digest(value) != state.get('files', {}).get(str(path)):
                raise ValueError('Existing router helper/configuration is not owned by this transaction')
            before_files[str(path)] = base64.b64encode(value).decode()
        else:
            before_files[str(path)] = None
    added_routes = [row for row in spec['routes'] if not route_present(row)]
    added_addresses = [row for row in spec['addresses'] if not address_present(row)]
    pending = {'status': 'pending', 'spec': spec, 'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
               'expires_monotonic': time.monotonic() + spec['rollback_seconds'],
               'before': {'state': copy.deepcopy(state) if state and state.get('status') == 'committed' else None,
                          'table': previous_table, 'forwarding': forwarding_value(),
                          'files': before_files, 'file_records': before_records, 'added_routes': added_routes, 'added_addresses': added_addresses},
               'files': {str(path): digest(value.encode()) for path, value in content.items()}}
    pending['changes'] = {'version': 1,
        'files': {raw: {'status': 'not-written', 'before': record} for raw, record in before_records.items()},
        'routes': [{'row': row, 'status': 'not-written', 'before': []} for row in added_routes],
        'addresses': [{'row': row, 'status': 'not-written', 'before': []} for row in added_addresses],
        'table': {'status': 'not-written', 'before': re.sub(r'counter packets [0-9]+ bytes [0-9]+', 'counter packets 0 bytes 0', previous_table) if previous_table is not None else None}}
    pending['controls'] = {'timer': 'not-written', 'service': 'not-written'}
    if action_id is not None:
        pending['ledger_action_id'] = action_id
    prior_forwarding = pending['before']['forwarding']
    if prior_forwarding not in {'0', '1'}:
        raise ValueError('IPv4 forwarding observation is invalid')
    pending['forwarding_change'] = {'before': prior_forwarding, 'after': '1',
        'status': 'unchanged' if not spec['forwarding'] or prior_forwarding == '1' else 'not-written'}
    # Recheck the prior authenticated object state after staging observations.
    if state and state.get('status') == 'committed':
        with mutation_ledger().lock():
            committed_action(mutation_ledger(), state)
    if action_id is not None:
        with mutation_ledger().lock():
            rollback_action(mutation_ledger(), spec, pending)
    # Persistent ownership and rollback intent precede all native network writes.
    save(base/'state.json', pending)
    try:
        for path, value in content.items():
            change = pending['changes']['files'][str(path)]
            perform_change(spec, pending, 'file', str(path), change,
                           lambda path=path, value=value, change=change: replace_owned_file(path, value.encode(), change['before']))
        command(['systemctl', 'daemon-reload'])
        for key, args in (('timer', ['systemctl', 'enable', '--now', service + '-rollback.timer']),
                          ('service', ['systemctl', 'enable', service + '.service'])):
            pending['controls'][key] = 'writing'
            save(base / 'state.json', pending)
            command(args)
            pending['controls'][key] = 'applied'
            save(base / 'state.json', pending)
            if key == 'timer':
                command(['systemctl', 'is-active', '--quiet', service + '-rollback.timer'])
        install_runtime(spec, pending=pending)
        pending['table_fingerprint'] = table_fingerprint(table)
        save(base/'state.json', pending)
        if not verify(spec, pending):
            raise RuntimeError('Native router verification failed')
    except BaseException:
        try:
            rollback(spec, pending, record_completion=action_id is not None)
        except BaseException as conflict:
            pending['rollback_hold'] = type(conflict).__name__
            save(base / 'state.json', pending)
            raise
        raise


def _run(phase, spec, source, *, action_id=None):
    if os.geteuid() != 0:
        raise PermissionError('Native router provisioning requires root')
    base, service, _table = names(spec)
    if phase == 'check' and not base.exists():
        raise SystemExit(10)
    secure(base, create=True)
    fd = os.open(base/'lock', os.O_RDWR | os.O_CREAT | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    try:
        # A completed rollback publishes its state before systemd finishes the
        # final reload. Wait briefly for that owner, then inspect fresh state.
        lock_deadline = time.monotonic() + 5
        while True:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() >= lock_deadline:
                    raise RuntimeError('Another native router transaction is still active') from None
                time.sleep(0.05)
        state_path = base/'state.json'
        state = json.loads(read(state_path)) if state_path.exists() else None
        if phase == 'check':
            raise SystemExit(0 if verify(spec, state) else 10)
        if phase == 'apply':
            apply(spec, state, source, action_id=action_id)
        elif phase == 'rollback':
            rollback(spec, state, record_completion=True)
        elif phase in {'activate', 'commit'}:
            if not verify(spec, state):
                raise ValueError('Router changed before confirmation')
            if state['status'] == 'pending':
                if state['boot_id'] != Path('/proc/sys/kernel/random/boot_id').read_text().strip() or time.monotonic() >= state['expires_monotonic']:
                    rollback(spec, state, record_completion=True)
                    raise ValueError('Router confirmation deadline expired')
                if phase == 'activate':
                    state['activation_approved'] = True
                    save(state_path, state)
                    return
                # The durable ledger commit is the confirmation decision. Native
                # publication and timer cleanup may be retried from its bound intent.
                confirm_pending(mutation_ledger(), spec, state)
                return
            raise ValueError('Native confirmation requires an authenticated pending transaction')
        elif phase == 'boot':
            if not state or state.get('spec') != spec:
                raise ValueError('Router boot configuration is untrusted')
            if state['status'] == 'pending':
                if (state.get('activation_approved') is True
                        and state['boot_id'] == Path('/proc/sys/kernel/random/boot_id').read_text().strip()
                        and time.monotonic() < state['expires_monotonic'] and verify(spec, state)):
                    return
                rollback(spec, state, record_completion=True)
            elif state['status'] == 'committed':
                for path, expected in state['files'].items():
                    if digest(read(Path(path))) != expected:
                        raise ValueError('Router boot helper integrity changed')
                install_runtime(spec)
                if not verify(spec, state, boot_check=True):
                    raise ValueError('Router boot verification failed')
        else:
            raise ValueError('Unsupported native router phase')
    finally:
        os.close(fd)



def ledger_snapshot(spec):
    import stat
    base, service, table = names(spec)
    state = {'files': {}, 'table': None, 'routes': {}, 'addresses': {}, 'forwarding': None}
    for path in [*units(base, service, spec['rollback_seconds']), base / 'native.py']:
        if path.is_symlink():
            raise ValueError('Router object became a symlink')
        if not path.exists():
            state['files'][str(path)] = None
            continue
        info = path.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            raise ValueError('Router object is not a unique regular file')
        value = read(path)
        attrs = {name: base64.b64encode(os.getxattr(path, name, follow_symlinks=False)).decode() for name in os.listxattr(path, follow_symlinks=False)}
        check = path.lstat()
        revision = [info.st_dev, info.st_ino, info.st_ctime_ns, info.st_mtime_ns]
        if revision != [check.st_dev, check.st_ino, check.st_ctime_ns, check.st_mtime_ns]:
            raise ValueError('Router file changed during capture')
        state['files'][str(path)] = {'bytes': base64.b64encode(value).decode(),
             'metadata': {'mode': stat.S_IMODE(info.st_mode), 'uid': info.st_uid, 'gid': info.st_gid, 'xattrs': attrs}, 'revision': revision}
    raw = table_data(table)
    # Traffic counters are measurements, outside the owned rule configuration.
    state['table'] = re.sub(r'counter packets [0-9]+ bytes [0-9]+', 'counter packets 0 bytes 0', raw) if raw is not None else None
    for row in spec['routes']:
        state['routes'][row['destination']] = json.loads(command(['ip','-j','-4','route','show','exact',row['destination']]).stdout)
    for row in spec['addresses']:
        address, prefix = row['address'].split('/')
        entries = json.loads(command(['ip','-j','-4','address','show','dev',row['interface']]).stdout)
        state['addresses'][row['interface'] + ':' + row['address']] = [item for interface in entries for item in interface.get('addr_info', []) if item.get('local') == address and item.get('prefixlen') == int(prefix)]
    if spec['forwarding']:
        state['forwarding'] = forwarding_value()
    return state


def mutation_ledger():
    try:
        from .mutation_ledger import MutationLedger
    except ImportError:
        from sentinel_mutation_ledger import MutationLedger
    return MutationLedger()


def committed_action(ledger, state, *, files_only=False, boot_check=False):
    """Bind live objects and recovery metadata to a committed authenticated action.

    File revisions are compared exactly. Revision-free comparisons are reserved
    for a proven inverse, never admission of an update or routine confirmation.
    """
    action = next((row for row in ledger.actions(include_states=True)
                   if row['action_id'] == state.get('ledger_action_id')
                   and row['status'] in ({'committed', 'boot_prepared'} if boot_check and files_only else {'committed'})
                   and row.get('adapter') == 'router-v1'), None)
    if (action is None or action['target'].get('spec') != state.get('spec')
            or action['target'].get('action_id') != action['action_id']):
        raise ValueError('Router has no matching authenticated ownership record')
    if state.get('before') != ledger.state(action['target'].get('rollback_before_hash')):
        raise ValueError('Router recovery metadata differs from authenticated ownership')
    expected = action['after']
    if files_only:
        current = {raw: file_record(Path(raw)) for raw in expected['files']}
        same = current == expected['files']
    else:
        same = ledger_snapshot(state['spec']) == expected
    if not same:
        raise ValueError('Committed router objects changed after Sentinel; review is required')
    expected_files = {raw: digest(base64.b64decode(record['bytes'], validate=True))
                      for raw, record in expected['files'].items() if record is not None}
    if state.get('files') != expected_files:
        raise ValueError('Router helper manifest differs from authenticated ownership')
    return action


def rollback_action(ledger, spec, state):
    """Authenticate a pending inverse BEFORE touching objects or recording success."""
    action = next((row for row in ledger.actions(include_states=True)
                   if row['action_id'] == state.get('ledger_action_id')), None)
    if (action is None or action.get('adapter') != 'router-v1'
            or action['status'] not in {'prepared', 'applied', 'uncertain'}
            or action['target'].get('spec') != spec
            or action['target'].get('action_id') != action['action_id']):
        raise ValueError('Router rollback has no matching authenticated action')
    target = action['target']
    if 'previous_state_hash' not in target:
        raise ValueError('Legacy router rollback lacks authenticated preceding state; review required')
    old = ledger.state(target['previous_state_hash'])
    if state['before'].get('state') != old:
        raise ValueError('Router preceding state differs from authenticated admission')
    before = action['before']
    native_before = state['before']
    if (native_before.get('file_records') != before['files']
            or {raw: None if record is None else record['bytes']
                for raw, record in before['files'].items()} != native_before.get('files')
            or (re.sub(r'counter packets [0-9]+ bytes [0-9]+', 'counter packets 0 bytes 0',
                       native_before['table']) if native_before['table'] is not None else None) != before['table']
            or (spec['forwarding'] and native_before['forwarding'] != before['forwarding'])
            or native_before['added_routes'] != [row for row in spec['routes']
                                               if not before['routes'][row['destination']]]
            or native_before['added_addresses'] != [row for row in spec['addresses']
                  if not before['addresses'][row['interface'] + ':' + row['address']]]):
        raise ValueError('Router inverse differs from authenticated preceding objects')
    return action


def record_rollback_completion(spec, pending, restored_state):
    """Durable completion precedes publishing restored state, closing the crash gap."""
    ledger = mutation_ledger()
    with ledger.lock():
        action = rollback_action(ledger, spec, pending)
        rollback_journal(spec, pending)  # Recheck after final service-control calls.
        rollback_forwarding_value(spec, pending)
        current = ledger_snapshot(spec)
        if semantic(current) != semantic(action['before']):
            raise ValueError('Router restoration differs from authenticated preceding objects')
        ledger.append('router_rollback_completed', action_id=action['action_id'],
                      restored_hash=ledger.store(current),
                      restored_state_hash=ledger.store(restored_state),
                      pending_state_hash=ledger.store(pending))


def reconcile_rollbacks(ledger, spec):
    """Finish recorded clean inverses; never infer success from a mutable status.

    The completion event is hash-chained; its exact file revisions must still
    match. Retrying a crash after publication/rebase is idempotent. Old uncertain
    actions without a completion event remain held for explicit recovery.
    """
    base, _service, _table = names(spec)
    state_path = base / 'state.json'
    actions = {row['action_id']: row for row in ledger.actions(include_states=True)}
    for event in ledger.read():
        if event['kind'] != 'router_rollback_completed':
            continue
        action = actions.get(event.get('action_id'))
        if (action is None or action.get('adapter') != 'router-v1'
                or action['target'].get('spec', {}).get('name') != spec['name']
                or action['status'] == 'cancelled'):
            continue
        if action['status'] not in {'prepared', 'applied', 'uncertain'}:
            raise ValueError('Router rollback completion conflicts with its ledger lifecycle')
        restored = ledger.state(event['restored_state_hash'])
        pending = ledger.state(event['pending_state_hash'])
        rollback_action(ledger, action['target']['spec'], pending)
        old = ledger.state(action['target']['previous_state_hash'])
        expected_state = old or {'status': 'rolled-back', 'spec': action['target']['spec']}
        current = ledger_snapshot(action['target']['spec'])
        if (restored != expected_state or current != ledger.state(event['restored_hash'])
                or semantic(current) != semantic(action['before'])):
            raise ValueError('Router changed after recorded rollback; reconciliation needs review')
        actual_state = json.loads(read(state_path))
        if actual_state != pending and actual_state != restored:
            raise ValueError('Router lifecycle state changed after rollback; review required')
        prior, previous_current = None, None
        if restored.get('status') == 'committed':
            prior = next((row for row in ledger.actions(include_states=True)
                          if row['action_id'] == restored.get('ledger_action_id')
                          and row['status'] == 'committed' and row.get('adapter') == 'router-v1'), None)
            previous_current = ledger_snapshot(restored['spec'])
            if (prior is None or prior['target'].get('spec') != restored['spec']
                    or restored.get('before') != ledger.state(prior['target'].get('rollback_before_hash'))
                    or semantic(previous_current) != semantic(prior['after'])):
                raise ValueError('Restored router differs from its authenticated committed state')
        # Snapshot again before publishing/rebasing: do not bless later edits.
        if ledger_snapshot(action['target']['spec']) != current:
            raise ValueError('Router changed at reconciliation boundary')
        if prior is not None and ledger_snapshot(restored['spec']) != previous_current:
            raise ValueError('Previous router changed at reconciliation boundary')
        if actual_state != restored:
            save(state_path, restored)
        if prior is not None and prior['after'] != previous_current:
            ledger.append('rebased', action_id=prior['action_id'], expected_after=ledger.store(previous_current),
                          inverse_action=action['action_id'])
        ledger.append('cancelled', action_id=action['action_id'], restored_hash=ledger.store(current),
                      validation={'success': True, 'restoration_authenticated': True})
        actions[action['action_id']]['status'] = 'cancelled'


def committed_state(pending):
    """The retained inverse is part of the authenticated confirmation intent."""
    state = {k: copy.deepcopy(pending[k]) for k in (
        'spec', 'files', 'table_fingerprint', 'before', 'ledger_action_id',
        'forwarding_change', 'changes', 'controls') if k in pending}
    state['status'] = 'committed'
    return state


def confirmation_intent(ledger, action_id):
    intents = [event for event in ledger.read()
               if event['kind'] == 'router_confirmation_prepared'
               and event.get('action_id') == action_id]
    if len(intents) > 1:
        raise ValueError('Router confirmation has ambiguous intent records')
    return intents[0] if intents else None


def finish_confirmation(ledger, intent, *, boot_check=False):
    """Finish only a ledger-committed decision; never promote an applied action.

    The intent, exact admitted objects and original native pending state are bound
    before the ledger commit. A failed stop/publication leaves those proofs intact.
    On a real boot only volatile network objects may be absent; persistent helpers
    and the inverse must still match exactly before the normal boot path runs.
    """
    action_id = intent['action_id']
    pending = ledger.state(intent['confirmation_pending_hash'])
    committed = ledger.state(intent['confirmation_state_hash'])
    spec = pending['spec']
    base, service, _table = names(spec)
    state_path = base / 'state.json'
    if (pending.get('status') != 'pending' or pending.get('ledger_action_id') != action_id
            or committed != committed_state(pending)):
        raise ValueError('Router confirmation intent has inconsistent lifecycle state')
    action = committed_action(ledger, committed, files_only=boot_check)
    if (action['action_id'] != action_id
            or action.get('validation', {}).get('confirmation_intent_hash') != intent['hash']
            or action['after'] != ledger.state(intent['confirmation_objects_hash'])):
        raise ValueError('Router confirmation differs from its authenticated object state')
    if unresolved_router_actions(ledger, spec):
        raise ValueError('Router confirmation has unresolved competing ownership')
    def check():
        actual = json.loads(read(state_path))
        if actual != pending and actual != committed:
            raise ValueError('Router lifecycle changed during confirmation; review required')
        committed_action(ledger, committed, files_only=boot_check)
        return actual
    check()
    # A nonzero stop result is not completion. Retain the committed decision and
    # pending state so a retry (including the timer itself) can finish safely.
    command(['systemctl', 'disable', '--now', service + '-rollback.timer'])
    actual = check()
    if actual != committed:
        save(state_path, committed)
    if check() != committed:
        raise ValueError('Router confirmation publication did not retain its state')
    ledger.append('router_confirmation_published', action_id=action_id,
                  confirmation_intent_hash=intent['hash'])


def confirm_pending(ledger, spec, pending):
    """Authenticate and record confirmation before stopping its rollback timer."""
    with ledger.lock():
        action = rollback_action(ledger, spec, pending)
        if action['status'] != 'applied' or 'after' not in action:
            raise ValueError('Router confirmation requires an authenticated applied action')
        if pending['before'] != ledger.state(action['target'].get('rollback_before_hash')):
            raise ValueError('Router confirmation inverse differs from authenticated ownership')
        if any(row['action_id'] != action['action_id'] for row in unresolved_router_actions(ledger, spec)):
            raise ValueError('Router confirmation has unresolved competing ownership')
        intent = confirmation_intent(ledger, action['action_id'])
        def check():
            if (json.loads(read(names(spec)[0] / 'state.json')) != pending
                    or ledger_snapshot(spec) != action['after'] or not verify(spec, pending)):
                raise ValueError('Router changed before durable confirmation')
            if (pending['boot_id'] != Path('/proc/sys/kernel/random/boot_id').read_text().strip()
                    or time.monotonic() >= pending['expires_monotonic']):
                raise ValueError('Router confirmation deadline expired before durable decision')
        check()
        if intent is None:
            intent = ledger.append('router_confirmation_prepared', action_id=action['action_id'],
                confirmation_pending_hash=ledger.store(pending),
                confirmation_state_hash=ledger.store(committed_state(pending)),
                confirmation_objects_hash=ledger.store(action['after']))
        elif (ledger.state(intent['confirmation_pending_hash']) != pending
              or ledger.state(intent['confirmation_state_hash']) != committed_state(pending)
              or ledger.state(intent['confirmation_objects_hash']) != action['after']):
            raise ValueError('Router changed after its confirmation intent; review required')
        check()
        ledger.commit(action['action_id'], action['after'],
                      {'success': True, 'external_health_confirmed': True,
                       'confirmation_intent_hash': intent['hash']})
        finish_confirmation(ledger, intent)


def reconcile_confirmations(ledger, spec, *, boot_check=False):
    """Complete a proven durable decision; historical unproven states stay held."""
    events = ledger.read()
    published = {event.get('confirmation_intent_hash') for event in events
                 if event['kind'] == 'router_confirmation_published'}
    actions = {row['action_id']: row for row in ledger.actions()}
    for intent in events:
        if intent['kind'] != 'router_confirmation_prepared' or intent['hash'] in published:
            continue
        action = actions.get(intent.get('action_id'))
        if (action is None or action.get('adapter') != 'router-v1'
                or action['target'].get('spec', {}).get('name') != spec['name']):
            continue
        # Applied intent has not decided: its timer remains armed, and ordinary
        # rollback/deadline handling is still valid. Do not commit it implicitly.
        if action['status'] in {'prepared', 'applied', 'uncertain', 'cancelled', 'undone'}:
            continue
        if (action['status'] != 'committed'
                or action.get('validation', {}).get('confirmation_intent_hash') != intent['hash']):
            raise ValueError('Router confirmation completion lacks an authenticated decision')
        finish_confirmation(ledger, intent, boot_check=boot_check)


def unresolved_router_actions(ledger, spec):
    return [row for row in ledger.actions() if row.get('adapter') == 'router-v1'
            and row['target'].get('spec', {}).get('name') == spec['name']
            and row['status'] in {'prepared', 'applied', 'uncertain', 'undo_prepared',
                                  'quiesce_prepared', 'boot_prepared', 'conflict'}]


def run(phase, spec, source):
    ledger = mutation_ledger()
    with ledger.lock():
        base, service, table = names(spec)
        state_path = base / 'state.json'
        if phase != 'check':
            reconcile_rollbacks(ledger, spec)
            reconcile_confirmations(ledger, spec, boot_check=phase == 'boot')
        existing = json.loads(read(state_path)) if state_path.exists() else None
        if phase == 'check':
            if existing and existing.get('status') == 'committed' and unresolved_router_actions(ledger, spec):
                raise SystemExit(10)
            return _run(phase, spec, source)
        if phase == 'activate' and existing and existing.get('status') == 'committed':
            committed_action(ledger, existing)
            if existing['spec'] != spec or unresolved_router_actions(ledger, spec) or not verify(spec, existing):
                raise ValueError('Router confirmation has unresolved or changed ownership')
            return
        if phase == 'apply':
            if ledger.paused():
                raise ValueError('Emergency withdrawal paused new router configuration')
            if existing and existing.get('status') == 'committed':
                committed_action(ledger, existing)
            if verify(spec, existing) and not unresolved_router_actions(ledger, spec):
                return
            action_id = 'router-' + uuid.uuid4().hex
            target = {'spec': spec, 'action_id': action_id, 'objects': ['nft:inet:' + table] + ['route:' + x['destination'] for x in spec['routes']] + ['address:' + x['interface'] + ':' + x['address'] for x in spec['addresses']] + (['sysctl:net.ipv4.ip_forward'] if spec['forwarding'] else []),
                      'previous_state_hash': ledger.store(existing if existing and existing.get('status') == 'committed' else None)}
            before = ledger_snapshot(spec)
            ledger.prepare('router-v1', target, before, action_id=action_id)
            try:
                _run(phase, spec, source, action_id=action_id)
                state = json.loads(read(state_path))
                state['ledger_action_id'] = action_id
                save(state_path, state)
                target['rollback_before_hash'] = ledger.store(state['before'])
                ledger.append('applied', action_id=action_id, target=target, after_hash=ledger.store(ledger_snapshot(spec)), validation={'success': True, 'external': False})
            except BaseException as exc:
                try:
                    reconcile_rollbacks(ledger, spec)
                except BaseException as recovery_error:
                    ledger.append('uncertain', action_id=action_id, reason=type(recovery_error).__name__)
                    raise recovery_error from exc
                row = next(row for row in ledger.actions() if row['action_id'] == action_id)
                if row['status'] != 'cancelled':
                    ledger.append('uncertain', action_id=action_id, reason=type(exc).__name__)
                raise
            return
        if phase == 'commit':
            if not existing or not existing.get('ledger_action_id'):
                raise ValueError('Router commit requires a durable mutation ledger')
            if existing.get('status') == 'committed':
                committed_action(ledger, existing)
                if existing['spec'] != spec or unresolved_router_actions(ledger, spec) or not verify(spec, existing):
                    raise ValueError('Router confirmation has unresolved or changed ownership')
                return  # Authenticated idempotent confirmation; do not commit twice.
            try:
                _run(phase, spec, source)
            except BaseException:
                reconcile_rollbacks(ledger, spec)
                raise
            return  # confirm_pending owns both durable commit and native publication.
        if phase == 'rollback':
            _run(phase, spec, source)
            reconcile_rollbacks(ledger, spec)
            if unresolved_router_actions(ledger, spec):
                raise ValueError('Router rollback has unresolved ledger ownership; review required')
            return
        if phase == 'boot' and existing and existing.get('status') == 'committed':
            if existing.get('spec') != spec:
                raise ValueError('Router boot configuration is untrusted')
            # The boot path may reinstall missing volatile network objects, but
            # it must never adopt changed persistent helpers or inverse metadata.
            committed_action(ledger, existing, files_only=True)
            if unresolved_router_actions(ledger, spec):
                raise ValueError('Router startup has unresolved ownership')
            if table_data(table) is not None and table_fingerprint(table) != existing.get('table_fingerprint'):
                raise ValueError('Router startup refuses an intervening firewall modification')
            ledger.append('boot_prepared', action_id=existing['ledger_action_id'], boot_before_hash=ledger.store(ledger_snapshot(spec)))
            try:
                _run(phase, spec, source)
            except BaseException as exc:
                ledger.append('uncertain', action_id=existing['ledger_action_id'], reason=type(exc).__name__)
                raise
            after = ledger_snapshot(spec)
            ledger.append('rebased', action_id=existing['ledger_action_id'], expected_after=ledger.store(after), inverse_action='declared_router_boot')
            ledger.append('boot_committed', action_id=existing['ledger_action_id'], validation={'success': True})
            return
        try:
            result = _run(phase, spec, source)
        except BaseException:
            reconcile_rollbacks(ledger, spec)
            raise
        reconcile_rollbacks(ledger, spec)
        return result


if __name__ == '__main__':
    if len(sys.argv) != 3 or sys.argv[1] not in {'boot', 'rollback'}:
        raise SystemExit(20)
    state = json.loads(read(Path(sys.argv[2])))
    expected = names(state['spec'])[0] / 'state.json'
    if Path(sys.argv[2]) != expected:
        raise SystemExit(20)
    run(sys.argv[1], state['spec'], Path(__file__).read_text())
