"""Independent network-wide emergency removal and selective restoration.

The management channel remains available if the controller is stopped. A review
pauses admission on every declared host and binds the complete inventory to a
digest. Conflicts never authorize force, broad VM restore, or an arbitrary script.
"""
from __future__ import annotations
import argparse
import base64
from concurrent.futures import ThreadPoolExecutor, as_completed
import copy
from dataclasses import asdict
import json
import os
from pathlib import Path
import shlex
import sys
import time
import uuid

from .mutation_ledger import MutationLedger, LedgerError, OwnershipConflict, digest, canonical
from .withdrawal_native import adapter_for, semantic
from .state import read_private_json, write_private_json

MODES = ('remove', 'restore-withdraw')


def _row(ledger, action_id):
    row = next((x for x in ledger.actions(include_states=True) if x['action_id'] == action_id), None)
    if row is None:
        raise LedgerError('Action was not recorded by this host')
    return row


def _overlay_owned(predicted, before, after):
    if semantic(predicted) == semantic(before):
        return copy.deepcopy(after)
    if isinstance(predicted, dict) and isinstance(before, dict) and isinstance(after, dict):
        for key in set(predicted) & set(before) & set(after):
            predicted[key] = _overlay_owned(predicted[key], before[key], after[key])
    return predicted


def _covered_by_later(row, current, actions):
    predicted = copy.deepcopy(row['after'])
    objects = set(row['target'].get('objects', []))
    for later in actions:
        if (later['sequence'] > row['sequence'] and later['status'] == 'committed' and later.get('after') is not None and
            later['adapter'] == row['adapter'] and objects.intersection(later['target'].get('objects', []))):
            predicted = _overlay_owned(predicted, later['before'], later['after'])
    if predicted == current:
        return True
    def project(value, shape):
        if isinstance(shape, dict) and isinstance(value, dict):
            if not set(shape).issubset(value):
                return object()
            return {key: project(value[key], child) for key, child in shape.items()}
        return value
    # Defer old guards until a later committed action over the same objects is
    # reversed. This is NOT permission to undo the old action: its exact guard
    # is checked again then, so an intervening teammate version is preserved.
    for later in reversed(actions):
        if (later['sequence'] > row['sequence'] and later['status'] == 'committed' and
            later['adapter'] == row['adapter'] and objects and objects.issubset(set(later['target'].get('objects', []))) and
            project(later['after'], current) == current):
            return True
    return False


def _prior_guard_was_owned(prior_after, next_before):
    comparisons = []
    def visit(left, right):
        if isinstance(left, dict) and isinstance(right, dict):
            for key in set(left) & set(right):
                visit(left[key], right[key])
        else:
            comparisons.append(left == right)
    visit(prior_after, next_before)
    return bool(comparisons) and all(comparisons)


def _boot_running_state_only(row, current):
    """A controller boot registration that only started or stopped since recorded."""
    if (row.get('ownership') != 'sentinel_artifact'
            or (row.get('context') or {}).get('controller_boot') is not True):
        return False
    from .controller_boot import activity_only
    return activity_only(current, row.get('after'))


def inventory(ledger):
    result = []
    all_actions = ledger.actions(include_states=True)
    for row in all_actions:
        public = {k: v for k, v in row.items() if k not in {'before', 'after'}}
        if row['status'] in {'committed', 'conflict'}:
            try:
                current = adapter_for(row['adapter'], ledger).snapshot(row['target'])
                public['current_hash'] = ledger.store(current)
                public['matches_post'] = current == row['after'] or _boot_running_state_only(row, current)
                # An already exited owned process is safe to finalize; PID reuse
                # produces an explicit conflict in the native identity adapter.
                if row['adapter'] == 'sentinel-process-v1' and current is None:
                    public['matches_post'] = True
                if not public['matches_post'] and _covered_by_later(row, current, all_actions):
                    public['deferred_until_later_actions_reverse'] = True
                elif not public['matches_post']:
                    public['conflict'] = 'Object was modified after Sentinel; human review required'
                    public['another_actor_modified'] = True
            except (OSError, ValueError, RuntimeError) as exc:
                public['matches_post'] = False
                public['conflict'] = str(exc)[:300]
        elif row['status'] in {'prepared', 'applied', 'uncertain', 'undo_prepared', 'quiesce_prepared', 'boot_prepared'}:
            public['conflict'] = 'Interrupted operation requires reconciliation; it will not be replayed'
        if public.get('conflict') and row['status'] == 'committed':
            ledger.append('conflict', action_id=row['action_id'], reason=public['conflict'],
                          another_actor_modified=public.get('another_actor_modified', False),
                          prior_status='committed')
            public['status'] = 'conflict'
        result.append(public)
    return {'actions': result, 'head': ledger.head(), 'paused': ledger.paused(),
            'ledger_path': str(ledger.directory), 'evidence_retained': True}


def _reapplied_setup(ledger, row, current):
    """The earlier setup step this one re-applied, or None.

    A setup redo runs the same reviewed step again, after damage it could not
    otherwise undo. Its recorded before-state is that damage. Undoing it
    literally would put the damage back and then leave the original step's
    inverse held, because the host would no longer be in that step's
    post-state. When the redo re-established exactly the original step's
    post-state (same reviewed step, same resulting state, still in place), it
    is absorbed instead: the original's inverse then restores the state from
    before Sentinel. The damaged version stays in the ledger as evidence.
    """
    if row['adapter'] != 'setup-linux-v1':
        return None
    objects = set(row['target'].get('objects', []))
    for prior in sorted(ledger.actions(include_states=True), key=lambda item: item['sequence'], reverse=True):
        if prior['sequence'] >= row['sequence'] or not objects.intersection(prior['target'].get('objects', [])):
            continue
        # Only the nearest earlier action on these objects can be the one re-applied.
        if (prior['adapter'] == 'setup-linux-v1' and prior['status'] == 'committed'
                and prior['target'].get('spec') == row['target'].get('spec')
                and prior.get('after') is not None
                and semantic(prior['after']) == semantic(row['after']) == semantic(current)):
            return prior
        return None
    return None


def _restore_one(ledger, action_id, *, require_pause=True):
    """Reverse one committed action to its exact recorded pre-state.

    ``require_pause`` may only be relaxed for a scoped, self-contained Sentinel
    artifact whose objects are exclusively its own — today, the controller boot
    registration. The host-wide pause exists so a full withdrawal drains every
    admitted mutation before removing anything; a single artifact instead relies
    on the ledger lock held here, the ownership-conflict check in ``prepare``,
    and the post-state comparison below, all of which still apply. Callers must
    prove the action's identity before passing False.
    """
    with ledger.lock():
        if require_pause and not ledger.paused():
            raise LedgerError('Pause and drain this host before withdrawal')
        row = _row(ledger, action_id)
        if row['status'] == 'undone':
            return {'action_id': action_id, 'status': 'undone', 'already_completed': True}
        if row['status'] != 'committed':
            raise OwnershipConflict('Only committed, uncontested actions can be reversed')
        if any(action_id in x.get('dependencies', []) and x['status'] not in {'undone', 'cancelled'} for x in ledger.actions()):
            raise OwnershipConflict('A dependent local action must be resolved before its prerequisite')
        native = adapter_for(row['adapter'], ledger)
        current = native.snapshot(row['target'])
        if current != row['after'] and _boot_running_state_only(row, current):
            # Found live on 2.0.6: a stopped boot controller read as "changed
            # after inventory", so neither Withdraw nor removing the
            # registration could reverse it. Only its running state differs.
            ledger.append('rebased', action_id=action_id, expected_after=ledger.store(current),
                          prior_expected_after=ledger.store(row['after']),
                          reason='controller_running_state_changed', validation={'success': True})
            row = _row(ledger, action_id)
        if current != row['after'] and not (row['adapter'] == 'sentinel-process-v1' and current is None):
            ledger.append('conflict', action_id=action_id, reason='Post-state changed before undo', another_actor_modified=True)
            raise OwnershipConflict('Object changed after inventory; undo held for human review')
        prior = _reapplied_setup(ledger, row, current)
        if prior is not None:
            ledger.append('undo_prepared', action_id=action_id, expected_after=ledger.store(current))
            ledger.append('undone', action_id=action_id, restored_hash=ledger.store(current),
                          validation={'success': True, 'absorbed_by': prior['action_id'],
                                      'reason': 'setup redo of an earlier step; its inverse restores the pre-Sentinel state'})
            ledger.append('rebased', action_id=prior['action_id'], expected_after=ledger.store(current),
                          inverse_action=action_id)
            return {'action_id': action_id, 'status': 'undone', 'absorbed_by': prior['action_id']}
        # Once this event is durable, a crash makes the outcome uncertain. A
        # retry never assumes that matching old bytes imply ownership of them.
        ledger.append('undo_prepared', action_id=action_id, expected_after=ledger.store(current))
        try:
            from .mutation_tracking import suppressed
            with suppressed():
                restored = native.restore(row['target'], row['before'], current)
            matches = native.matches_pre(row['before'], restored) if hasattr(native, 'matches_pre') else semantic(restored) == semantic(row['before'])
            if not matches:
                raise LedgerError('Exact pre-state validation failed')
            ledger.append('undone', action_id=action_id, restored_hash=ledger.store(restored), validation={'success': True})
            # Legitimate reverse traversal of two Sentinel edits to the SAME
            # object changes inode/ctime. Rebase only predecessors whose entire
            # semantic post-state is exactly what this recorded inverse produced.
            objects = set(row['target'].get('objects', []))
            for prior in ledger.actions(include_states=True):
                if (prior['status'] == 'committed' and prior['sequence'] < row['sequence'] and
                    objects.intersection(prior['target'].get('objects', []))):
                    observed = adapter_for(prior['adapter'], ledger).snapshot(prior['target'])
                    if (semantic(observed) == semantic(prior['after']) and
                        _prior_guard_was_owned(prior['after'], row['before'])):
                        ledger.append('rebased', action_id=prior['action_id'], expected_after=ledger.store(observed),
                                      inverse_action=action_id)
            return {'action_id': action_id, 'status': 'undone'}
        except (OSError, ValueError, RuntimeError) as exc:
            ledger.append('conflict', action_id=action_id, reason=str(exc)[:300],
                          another_actor_modified=isinstance(exc, OwnershipConflict), prior_status='undo_prepared')
            raise


def guest(request, ledger=None):
    ledger = ledger or MutationLedger()
    operation = request['operation']
    with ledger.lock():
        if request.get('pinned'):
            ledger.read(request['pinned'])
        if operation == 'install-begin':
            from .withdrawal_native import NativeObjects, canonical_file
            target = request['target']
            native = NativeObjects(ledger)
            key = ledger.prepare(native.name, target, native.snapshot(target), action_id=request['action_id'],
                                 ownership='sentinel_artifact', context={'installation': True, 'expected_files': {canonical_file(k): v for k, v in request.get('expected_files', {}).items()}})
            return {'action_id': key, 'status': 'prepared', 'head': ledger.head()}
        if operation == 'install-finish':
            import hashlib
            from .withdrawal_native import NativeObjects
            row = _row(ledger, request['action_id'])
            if row['status'] != 'prepared' or not row.get('context', {}).get('installation'):
                raise LedgerError('No prepared Sentinel installation matches this receipt')
            after = NativeObjects(ledger).snapshot(row['target'])
            for filename, expected in row['context'].get('expected_files', {}).items():
                state = after['files'][filename]
                actual = hashlib.sha256(base64.b64decode(state['bytes'])).hexdigest() if state else None
                if actual != expected:
                    ledger.append('uncertain', action_id=row['action_id'], reason='Installed bytes differ from the reviewed deployment')
                    raise OwnershipConflict('Installed bytes do not prove Sentinel ownership')
            ledger.commit(row['action_id'], after, {'success': True, 'installation_verified': True})
            return {'status': 'committed', 'head': ledger.head()}
        if operation == 'continuity-pause':
            from .continuity_controls import local_control
            return local_control(ledger, True, request['reason'])
        if operation == 'pause':
            result = ledger.pause(request['operation_id'])
            # Keep a private helper outside installation paths so later imports
            # and receipts still work after the original zipapp is removed.
            import zipfile
            source = Path(sys.argv[0]).absolute()
            if source.is_file() and zipfile.is_zipfile(source):
                from .mutation_ledger import _atomic
                helper = ledger.directory / 'withdrawal-helper.pyz'
                _atomic(helper, source.read_bytes())
                result['helper_runtime'] = str(helper)
            return result
        if operation in {'can-cancel-review', 'cancel-review'}:
            return ledger.cancel_review(request['operation_id'], check_only=operation == 'can-cancel-review')
        if operation == 'inventory':
            return inventory(ledger)
        if operation == 'undo':
            result = _restore_one(ledger, request['action_id'])
            return {**result, 'head': ledger.head()}
        if operation == 'quiesce':
            row = _row(ledger, request['action_id'])
            if row['ownership'] not in {'sentinel_artifact', 'sentinel_process'}:
                raise LedgerError('Cannot stop a legitimate configured application during Remove')
            if row['adapter'] == 'sentinel-process-v1':
                result = _restore_one(ledger, row['action_id'])
            elif row['status'] == 'committed':
                native = adapter_for(row['adapter'], ledger)
                # A file-only publication has no supervisor to stop. Leave its
                # exact guard untouched until newer credential actions reverse;
                # their recorded inverses may legitimately restore these files.
                files_only = (row['adapter'] == 'native-objects-v1' and
                              not row['target'].get('services') and not row['target'].get('tasks'))
                if not hasattr(native, 'quiesce') or files_only:
                    result = {'status': 'no_startup_objects'}
                else:
                    if not ledger.paused():
                        raise LedgerError('Withdrawal admission is not paused')
                    ledger.append('quiesce_prepared', action_id=row['action_id'])
                    after = native.quiesce(row['target'], row['before'], row['after'])
                    ledger.append('rebased', action_id=row['action_id'], expected_after=ledger.store(after),
                                  inverse_action='owned_runtime_stop')
                    ledger.append('quiesced', action_id=row['action_id'])
                    result = {'status': 'stopped'}
            else:
                raise OwnershipConflict('An installation object requires human review before stopping')
            return {**result, 'head': ledger.head()}
        if operation == 'evidence':
            # Retrieve a bounded, authenticated file chunk over the approved
            # management transport. A caller cannot turn this into arbitrary IO.
            name = request['name']
            allowed = {'events.jsonl', 'head.json', 'authentication.key'}
            if name not in allowed and not (name.startswith('states/') and len(name) == 71 and all(c in '0123456789abcdef' for c in name[7:])):
                raise LedgerError('Invalid evidence object')
            path = ledger.directory / name
            from .mutation_ledger import _read, MAX_STATE
            data = _read(path, MAX_STATE if name.startswith('states/') else 512 * 1024 * 1024)
            offset = request.get('offset', 0)
            if type(offset) is not int or offset < 0 or offset > len(data):
                raise LedgerError('Invalid evidence offset')
            return {'data': base64.b64encode(data[offset:offset+262144]).decode(), 'size': len(data),
                    'sha256': __import__('hashlib').sha256(data).hexdigest()}
        raise ValueError('Unknown withdrawal operation')


class NetworkGuest:
    """Reuse verified SSH/WinRM transports; no controller or cloud dependency."""
    def __init__(self, hosts, directory, transport=None):
        from .setup_transport import SetupTransport
        self.hosts, self.directory = hosts, Path(directory)
        self.helpers = {}
        self.directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.transport = transport or SetupTransport(log_dir=self.directory)

    def __call__(self, name, request):
        host = self.hosts[name]
        encoded = base64.b64encode(canonical(request)).decode()
        runtime = self.helpers.get(name) or host.get('runtime', r'C:\ProgramData\SentinelBlue\sentinel-blue.pyz' if host['platform'] == 'windows' else '/opt/sentinel-blue/sentinel-blue.pyz')
        from .runtime_environment import host_python
        python = host.get('python', 'py.exe') if host['platform'] == 'windows' else host_python(host)
        if host['platform'] == 'windows':
            from .setup_transport import _ps
            script = ("$ErrorActionPreference='Stop'\n" +
                      "$r=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('" + encoded + "'))\n" +
                      "$r | & " + _ps(python) + (' -3' if python == 'py.exe' else '') + ' ' + _ps(runtime) +
                      " withdraw-guest\nif($LASTEXITCODE -ne 0){throw 'Withdrawal guest failed'}\n")
            script = script.replace(' ' + _ps(runtime) + ' withdraw-guest', ' -I -B ' + _ps(runtime) + ' withdraw-guest')
        else:
            script = 'set -eu\n' + shlex.quote(python) + ' -I -B ' + shlex.quote(runtime) + " withdraw-guest <<'SENTINEL_WITHDRAW_REQUEST'\n" + canonical(request).decode() + '\nSENTINEL_WITHDRAW_REQUEST\n'
        if host.get('ledger_directory'):
            from pathlib import PureWindowsPath, PurePosixPath
            value = host['ledger_directory']
            path_type = PureWindowsPath if host['platform'] == 'windows' else PurePosixPath
            if not isinstance(value, str) or not path_type(value).is_absolute() or any(c in value for c in '\0\r\n'):
                raise ValueError('Withdrawal ledger directory must be an exact absolute path')
            if host['platform'] == 'windows':
                script = '$env:SENTINEL_LEDGER_DIR=' + _ps(value) + '\n' + script
            else:
                script = 'export SENTINEL_LEDGER_DIR=' + shlex.quote(value) + '\n' + script
        if host.get('transport') == 'winrm':
            result = self.transport.execute_receipt(host, script, 180, 'SENTINEL_WITHDRAW_RESULT=')
        else:
            result = self.transport.execute(host, script, 180)
        if result.uncertain or result.returncode != 0 or not result.output_log:
            raise LedgerError('Host did not confirm withdrawal; private transport evidence retained')
        path = self.directory / result.output_log
        raw = path.read_bytes()
        lines = [x[len(b'SENTINEL_WITHDRAW_RESULT='):] for x in raw.splitlines() if x.startswith(b'SENTINEL_WITHDRAW_RESULT=')]
        if len(lines) != 1:
            raise LedgerError('Host returned no unique withdrawal receipt')
        response = json.loads(lines[0])
        if not response.get('success'):
            raise LedgerError(response.get('error', 'Host refused withdrawal'))
        answer = response['result']
        if answer.get('helper_runtime'):
            self.helpers[name] = answer['helper_runtime']
        return answer


class WithdrawalCoordinator:
    def __init__(self, hosts, request, directory, *, verify=None):
        self.hosts, self.request, self.directory = hosts, request, Path(directory)
        if not 1 <= len(hosts) <= 64:
            raise ValueError('Withdrawal requires 1 to 64 explicitly declared hosts')
        self.directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.verify = verify

    def _save(self, name, value):
        write_private_json(self.directory / name, value)

    def review(self, mode):
        if mode not in MODES:
            raise ValueError('Choose Remove Sentinel or Restore & Withdraw')
        report = {'version': 1, 'mode': mode, 'operation_id': uuid.uuid4().hex, 'created_at': time.time(),
                  'hosts': {}, 'scope_hash': digest(self.hosts), 'conflicts': [], 'order': []}
        def pause(name):
            return self.request(name, {'operation': 'pause', 'operation_id': report['operation_id']})
        with ThreadPoolExecutor(max_workers=min(16, len(self.hosts))) as pool:
            jobs = {pool.submit(pause, name): name for name in self.hosts}
            for future in as_completed(jobs):
                name = jobs[future]
                try:
                    report['hosts'][name] = {'pause': future.result()}
                except Exception as exc:
                    report['hosts'][name] = {'error': str(exc)[:300]}
        # Inventory EVERY host before planning any inverse anywhere.
        for name, host in report['hosts'].items():
            try:
                if not host.get('pause', {}).get('paused') or not host['pause'].get('drained'):
                    raise LedgerError('Host has not paused and drained all admitted mutations')
                host['inventory'] = self.request(name, {'operation': 'inventory', 'pinned': host['pause']['head']})
            except Exception as exc:
                host['error'] = str(exc)[:300]
                report['conflicts'].append({'host': name, 'reason': host['error']})
        actions = {}
        aliases = {}
        for name, host in report['hosts'].items():
            for action in host.get('inventory', {}).get('actions', []):
                key = name + '/' + action['action_id']
                actions[key] = (name, action)
                ctx = action.get('context', {})
                if ctx.get('run_id') and ctx.get('task_id'):
                    aliases[(ctx['run_id'], ctx['task_id'])] = key
        edges = {}
        for key, (name, action) in actions.items():
            deps = []
            for dependency in action.get('dependencies', []):
                qualified = dependency if '/' in dependency else name + '/' + dependency
                if qualified not in actions:
                    report['conflicts'].append({'action': key, 'reason': 'Dependency is outside the inventoried network: ' + qualified})
                else:
                    deps.append(qualified)
            ctx = action.get('context', {})
            for task in ctx.get('requires', []):
                dependency = aliases.get((ctx.get('run_id'), task))
                if dependency:
                    deps.append(dependency)
                else:
                    report['conflicts'].append({'action': key, 'reason': 'Setup dependency has no inventoried action receipt: ' + task})
            edges[key] = sorted(set(deps))
        ordered, visiting, visited = [], set(), set()
        def visit(key):
            if key in visiting:
                raise LedgerError('Cross-host rollback dependency cycle')
            if key in visited:
                return
            visiting.add(key)
            for dep in edges[key]:
                visit(dep)
            visiting.remove(key)
            visited.add(key)
            ordered.append(key)
        for key in sorted(actions, key=lambda x: (actions[x][1].get('time_ns', 0), x)):
            visit(key)
        report['order'] = list(reversed(ordered))
        report['dependencies'] = edges
        for key, (name, action) in actions.items():
            if action.get('conflict'):
                report['conflicts'].append({'host': name, 'action': key, 'reason': action['conflict']})
        report['review_digest'] = digest(report)
        self._save('review.json', report)
        return report

    def cancel_review(self, review):
        if (self.directory / 'result.json').exists():
            raise LedgerError('Execution has started; use a fresh recovery review')
        if isinstance(self.request, NetworkGuest):
            self.request.helpers.update({name: row['pause']['helper_runtime'] for name, row in review['hosts'].items() if row.get('pause', {}).get('helper_runtime')})
        for name in self.hosts:
            self.request(name, {'operation': 'can-cancel-review', 'operation_id': review['operation_id']})
        results = {}
        for name in self.hosts:
            results[name] = self.request(name, {'operation': 'cancel-review', 'operation_id': review['operation_id']})
        report = {'status': 'cancelled', 'hosts': results, 'operation_id': review['operation_id']}
        self._save('cancelled.json', report)
        return report

    def _backup_evidence(self, name, pinned):
        # Recovery copies are private and independent of each target. Secrets
        # never appear in the normal recorder or a public release package.
        import hashlib
        from .mutation_ledger import _atomic
        destination = self.directory / 'evidence' / digest(name)[:24]
        destination.mkdir(mode=0o700, parents=True, exist_ok=True)
        def download(filename):
            offset, chunks, size, expected = 0, [], None, None
            while size is None or offset < size:
                reply = self.request(name, {'operation': 'evidence', 'name': filename, 'offset': offset, 'pinned': pinned})
                if size is not None and (reply['size'] != size or reply['sha256'] != expected):
                    raise LedgerError('Recovery evidence changed during its transfer')
                size, expected = reply['size'], reply['sha256']
                if size > 512 * 1024 * 1024:
                    raise LedgerError('Recovery evidence exceeds its transfer limit')
                chunk = base64.b64decode(reply['data'], validate=True)
                if not chunk and offset != size:
                    raise LedgerError('Recovery evidence transfer did not advance')
                chunks.append(chunk)
                offset += len(chunk)
            data = b''.join(chunks)
            if len(data) != size or hashlib.sha256(data).hexdigest() != expected:
                raise LedgerError('Recovery evidence transfer failed integrity validation')
            path = destination / filename
            path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            _atomic(path, data)
            return data
        events = download('events.jsonl')
        download('authentication.key')
        download('head.json')
        states = set()
        for line in events.splitlines():
            body = json.loads(base64.b64decode(json.loads(line)['payload'], validate=True))
            def collect(value):
                if isinstance(value, dict):
                    for key, item in value.items():
                        if key in {'before_hash', 'after_hash', 'expected_after', 'restored_hash', 'rollback_before_hash',
                                   'native_record_hash', 'setup_pending_hash', 'setup_expected_hash',
                                   'setup_committed_hash', 'setup_terminal_hash', 'setup_restored_hash'} and isinstance(item, str):
                            states.add(item)
                        else:
                            collect(item)
                elif isinstance(value, list):
                    for item in value:
                        collect(item)
            collect(body)
        for state in sorted(states):
            download('states/' + state)
        archive = MutationLedger(destination)
        archive.read(pinned)
        archive.actions(include_states=True)
        return {'host': name, 'head': archive.head(), 'directory': str(destination), 'verified': True}

    def execute(self, review, approved_digest):
        unsigned = {k: v for k, v in review.items() if k != 'review_digest'}
        if approved_digest != digest(unsigned) or approved_digest != review['review_digest'] or review['scope_hash'] != digest(self.hosts):
            raise LedgerError('Reviewed network inventory or scope changed')
        result_path = self.directory / 'result.json'
        if result_path.exists():
            previous = read_private_json(result_path, 4 * 1024 * 1024)
            if previous.get('review_digest') != approved_digest:
                raise LedgerError('This recovery directory belongs to another withdrawal')
            # Never replay an uncertain remote call, even when its local receipt
            # was not persisted. Re-inventory and review a new operation instead.
            if previous.get('status') != 'complete':
                raise LedgerError('An interrupted withdrawal requires a fresh network inventory; do not replay it')
            return previous
        result = {'review_digest': approved_digest, 'operation_id': review['operation_id'], 'mode': review['mode'],
                  'status': 'in_progress', 'actions': [], 'conflicts': list(review['conflicts']),
                  'external_verification': [], 'evidence_retained': True}
        self._save('result.json', result)
        if any('error' in row for row in review['hosts'].values()):
            result['status'] = 'held'
            self._save('result.json', result)
            return result
        heads = {}
        if isinstance(self.request, NetworkGuest):
            self.request.helpers.update({name: row['pause']['helper_runtime'] for name, row in review['hosts'].items() if row.get('pause', {}).get('helper_runtime')})
        for name, row in review['hosts'].items():
            expected = row['inventory']['head']
            current = self.request(name, {'operation': 'inventory', 'pinned': expected})
            if current['head'] != expected:
                raise OwnershipConflict('Network ledger changed after review; review again')
            heads[name] = expected
        result['recovery_copies'] = []
        for name in self.hosts:
            result['recovery_copies'].append(self._backup_evidence(name, heads[name]))
            self._save('result.json', result)
        actions = {name + '/' + a['action_id']: (name, a) for name, h in review['hosts'].items()
                   for a in h['inventory']['actions']}
        blocked = {x['action'] for x in result['conflicts'] if 'action' in x}
        def block(key):
            if key in blocked:
                return
            blocked.add(key)
            for dep in review['dependencies'].get(key, []):
                block(dep)
        for key in list(blocked):
            for dep in review['dependencies'].get(key, []):
                block(dep)
        def perform(key, operation):
            name, action = actions[key]
            if key in blocked or action['status'] in {'undone', 'cancelled'}:
                return False
            receipt = {'action': key, 'operation': operation, 'status': 'in_progress'}
            result['actions'].append(receipt)
            self._save('result.json', result)
            try:
                response = self.request(name, {'operation': operation, 'action_id': action['action_id'], 'pinned': heads[name]})
                heads[name] = response['head']
                receipt.update(response)
                receipt['status'] = response['status']
                if operation == 'quiesce' and action['adapter'] == 'sentinel-process-v1':
                    action['status'] = 'undone'
                return True
            except Exception as exc:
                receipt.update(status='held', reason=str(exc)[:300])
                result['conflicts'].append({'action': key, 'host': name, 'reason': str(exc)[:300]})
                block(key)
                return False
            finally:
                self._save('result.json', result)
        # Disable only recorded Sentinel startup registrations before stopping
        # their exact process identities. A supervisor cannot restart a child.
        for key in review['order']:
            _, action = actions[key]
            if action['ownership'] == 'sentinel_artifact':
                perform(key, 'quiesce')
        for key in sorted(review['order'], key=lambda k: 0 if actions[k][1].get('target', {}).get('role') == 'controller-supervisor' else 1):
            if actions[key][1]['ownership'] == 'sentinel_process':
                perform(key, 'quiesce')
        if review['mode'] == 'restore-withdraw':
            for key in review['order']:
                if actions[key][1]['ownership'] == 'configuration':
                    perform(key, 'undo')
            # Verification runs from the operator/observer, outside the guests.
            try:
                checks = self.verify() if self.verify else []
                result['external_verification'] = checks
                verified = bool(checks) and all(x.get('healthy') is True and x.get('external') is True for x in checks)
            except Exception as exc:
                verified = False
                result['external_verification'] = [{'healthy': False, 'reason': str(exc)[:300]}]
            if not verified:
                result['conflicts'].append({'reason': 'Independent service verification failed or was unavailable; installation and evidence retained'})
                result['status'] = 'held'
                self._save('result.json', result)
                return result
        # Reports and exact recovery evidence remain outside installation roots.
        # Configurations are deliberately untouched by Remove Sentinel.
        for key in review['order']:
            if actions[key][1]['ownership'] in {'sentinel_artifact', 'sentinel_credential', 'sentinel_control'}:
                perform(key, 'undo')
        result['status'] = 'partial' if result['conflicts'] else 'complete'
        result['heads'] = heads
        result['recovery_copies'] = [self._backup_evidence(name, heads[name]) for name in self.hosts]
        self._save('result.json', result)
        return result


def add_cli(subcommands):
    command = subcommands.add_parser('withdraw', help='review or execute network-wide Emergency Remove / Restore & Withdraw')
    command.add_argument('--inventory', required=True)
    command.add_argument('--event-profile', required=True)
    command.add_argument('--directory', required=True, help='private recovery report directory outside Sentinel installation paths')
    command.add_argument('--mode', choices=MODES, default='restore-withdraw')
    command.add_argument('--approved-digest', help='execute this exact paused inventory; omit to pause and review')
    command.add_argument('--range-deployment', action='store_true')
    command.add_argument('--cancel-review', action='store_true', help='cancel an unexecuted withdrawal review; keeps the ordinary Pause controls independent')
    helper = subcommands.add_parser('withdraw-guest', help=argparse.SUPPRESS)
    helper.add_argument('--request-b64', help=argparse.SUPPRESS)


def coordinator_from_files(inventory_path, profile_path, directory, *, range_deployment=False):
    from .launcher import load_inventory
    from .event_profile import load_event_profile
    from .setup import compile_hosts
    raw = load_inventory(inventory_path)
    profile = load_event_profile(profile_path)
    profile.require_runtime_ready(range_deployment=range_deployment)
    hosts = compile_hosts(raw, profile, Path(inventory_path).absolute().parent)
    for row in raw['hosts']:
        name = row.get('name', row.get('address'))
        if name in hosts:
            for key in ('python', 'runtime', 'ledger_directory'):
                if key in row:
                    hosts[name][key] = row[key]
    if not any(x.get('transport') == 'local' for x in hosts.values()):
        local_ledger = MutationLedger()
        if any(x['ownership'] == 'sentinel_process' and x['status'] == 'committed' for x in local_ledger.actions()):
            import platform
            hosts['sentinel-controller-local'] = {'name': 'sentinel-controller-local', 'address': '127.0.0.1',
                'platform': 'windows' if os.name == 'nt' else 'linux', 'transport': 'local',
                'runtime': str(Path(sys.argv[0]).absolute()), 'python': sys.executable}
    request = NetworkGuest(hosts, Path(directory) / 'private-transport')
    def verify():
        from .probes import run_probes
        checks = []
        for manifest in profile.services:
            matched = [(name, host) for name, host in hosts.items() if manifest['host'] in {host['address'], host.get('agent_id')}]
            if len(matched) != 1:
                raise LedgerError('An approved service is outside the inventoried withdrawal network')
            name, host = matched[0]
            probes = manifest['expected_transactions']
            import ipaddress, socket
            address = ipaddress.ip_address(host['address'])
            with socket.socket(socket.AF_INET6 if address.version == 6 else socket.AF_INET, socket.SOCK_DGRAM) as route:
                route.connect((str(address), 9))
                same_machine = ipaddress.ip_address(route.getsockname()[0]) == address
            if (host.get('transport') == 'local' or same_machine or address.is_loopback) and probes:
                raise LedgerError('A separate observer is required to externally verify a local service host')
            for result in run_probes(probes, list(profile.authorized_networks),
                                     authorized_hosts=list(profile.authorized_hosts), excluded_hosts=list(profile.excluded_hosts)):
                checks.append({**asdict(result), 'host': name, 'service_id': manifest['service_id'], 'external': True})
        return checks
    return WithdrawalCoordinator(hosts, request, directory, verify=verify)


def run(args):
    if args.command == 'withdraw-guest':
        try:
            raw = base64.b64decode(args.request_b64, validate=True) if args.request_b64 else sys.stdin.buffer.read(1024 * 1024 + 1)
            if len(raw) > 1024 * 1024:
                raise ValueError('Withdrawal request too large')
            response = {'success': True, 'result': guest(json.loads(raw))}
        except (OSError, ValueError, RuntimeError) as exc:
            response = {'success': False, 'error': str(exc)[:300]}
        print('SENTINEL_WITHDRAW_RESULT=' + canonical(response).decode())
        return 0 if response['success'] else 2
    from .event_profile import load_event_profile
    load_event_profile(args.event_profile).verify_release_file(sys.argv[0])
    coordinator = coordinator_from_files(args.inventory, args.event_profile, args.directory, range_deployment=args.range_deployment)
    if args.cancel_review:
        if args.approved_digest:
            raise ValueError('Choose cancellation or execution')
        review = read_private_json(Path(args.directory) / 'review.json', 4 * 1024 * 1024)
        result = coordinator.cancel_review(review)
    elif args.approved_digest:
        review = read_private_json(Path(args.directory) / 'review.json', 4 * 1024 * 1024)
        result = coordinator.execute(review, args.approved_digest)
    else:
        result = coordinator.review(args.mode)
    print(json.dumps(result, indent=2))
    return 0 if result.get('status') in {None, 'complete', 'cancelled'} else 2
