"""Durable, private, append-only mutation evidence (stdlib; also embedded in setup).

Events are hash chained and authenticated with a separate local key. Pinned heads
on the coordinator detect removal of a suffix. An administrator who can replace
both all evidence and its keys is outside this local tamper-evidence boundary.
No secrets or snapshots are sent to the ordinary, redacted activity recorder.
"""
from __future__ import annotations
import base64
import contextlib
import errno
import math
import hashlib
import hmac
import json
import logging
import os
from pathlib import Path
import socket
import stat
import threading
import time
import uuid

ZERO = '0' * 64
MAX_EVENT = 1024 * 1024
MAX_STATE = 64 * 1024 * 1024
# A contended ledger silently stalls whatever is waiting on it — a scheduled
# recovery backup, most importantly — so say so while it is still only a delay.
CONTENTION_WARNING_SECONDS = 5.0
MAX_LOCK_HOLDER_BYTES = 512
_LOCKS = {}
_LOCKS_GUARD = threading.Lock()
LOG = logging.getLogger(__name__)


def _holder_description(path):
    """Describe whoever last took this lock, for a person to act on.

    The lock file is advisory and writable by this host's Sentinel processes, so
    its contents are formatted defensively and never used for a decision.
    """
    try:
        fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_NONBLOCK', 0))
        try:
            if not stat.S_ISREG(os.fstat(fd).st_mode):
                return 'the holding process did not identify itself'
            record = json.loads(os.read(fd, MAX_LOCK_HOLDER_BYTES) or b'{}')
        finally:
            os.close(fd)
        if not isinstance(record, dict):
            return 'the holding process did not identify itself'
        pid, host = record.get('pid'), record.get('host')
        since = record.get('since')
        if type(pid) is not int or not 0 < pid < 2 ** 31:
            return 'the holding process did not identify itself'
        age = ''
        if type(since) in (int, float) and 0 < since <= time.time():
            age = f' for {time.time() - since:.0f}s'
        where = f' on {str(host)[:64]}' if isinstance(host, str) and host else ''
        return f'process {pid}{where} has held it{age}'
    except (OSError, ValueError, TypeError):
        return 'the holding process did not identify itself'


class LedgerError(RuntimeError):
    pass


class LedgerBusy(LedgerError):
    """The ledger lock stayed held for the caller's whole timeout."""


class OwnershipConflict(LedgerError):
    pass


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True,
                      allow_nan=False).encode('utf-8')


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def default_directory():
    override = os.environ.get('SENTINEL_LEDGER_DIR')
    if override:
        return Path(override).absolute()
    if os.name == 'nt':
        return Path(os.environ.get('PROGRAMDATA', r'C:\ProgramData')) / 'SentinelBlueLedger'
    if os.geteuid() == 0:
        return Path('/var/lib/sentinel-blue-ledger')
    return Path.home() / '.local' / 'state' / 'sentinel-blue-ledger'


def _sync_directory(path):
    if os.name != 'nt':
        fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)


def _private(path, directory=False):
    info = path.lstat()
    expected = stat.S_ISDIR if directory else stat.S_ISREG
    if not expected(info.st_mode) or path.is_symlink() or (not directory and info.st_nlink != 1):
        raise LedgerError('Unsafe ledger object')
    if os.name != 'nt' and (info.st_uid != os.geteuid() or info.st_mode & 0o077):
        raise LedgerError('Ledger evidence must be private and owned by this account')
    if os.name == 'nt' and getattr(info, 'st_file_attributes', 0) & 0x400:
        raise LedgerError('Reparse points are forbidden in ledger evidence')
    if os.name == 'nt':
        from .win_state import _NativeWindowsStateBackend, _classify_security
        backend = _NativeWindowsStateBackend()
        handle = backend.open_node(str(path), allow_data_writers=True)
        try:
            _classify_security(backend.security_state(handle), directory=directory, root=False)
        finally:
            backend.close(handle)


def _harden_new_windows_file(path):
    if os.name == 'nt':
        from .win_state import _NativeWindowsStateBackend
        backend = _NativeWindowsStateBackend()
        handle = backend.open_node(str(path), write_security=True, allow_data_writers=True)
        try:
            backend.apply_private_security(handle, False)
        finally:
            backend.close(handle)



def _atomic(path, data):
    tmp = path.with_name('.' + path.name + '-' + uuid.uuid4().hex)
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        _harden_new_windows_file(tmp)
        if path.exists() or path.is_symlink():
            _private(path)
        os.replace(tmp, path)
        _sync_directory(path.parent)
    finally:
        tmp.unlink(missing_ok=True)


def _read(path, maximum):
    _private(path)
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0))
    with os.fdopen(fd, 'rb') as stream:
        data = stream.read(maximum + 1)
    if len(data) > maximum:
        raise LedgerError('Ledger evidence exceeds its bounded read limit')
    return data


class MutationLedger:
    def __init__(self, directory=None, *, host=None):
        self.directory = Path(directory or default_directory()).absolute()
        # No symlink/reparse ancestor may redirect evidence into another tree.
        for parent in (self.directory, *self.directory.parents):
            if parent.is_symlink() or (parent.exists() and getattr(parent.lstat(), 'st_file_attributes', 0) & 0x400):
                raise LedgerError('Unsafe ledger ancestor')
        if os.name == 'nt':
            from .win_state import acquire_windows_state_tree
            guard = acquire_windows_state_tree(self.directory, initialize=True, maximum_entries=65536, maximum_depth=16)
            if guard is not None:
                guard.close()
        else:
            self.directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        _private(self.directory, True)
        self.blobs = self.directory / 'states'
        if os.name == 'nt':
            # Python 3.13's mkdir(0700) creates an OWNER RIGHTS rule. Ledger
            # trees require the existing exact System/Administrators policy,
            # so create this child atomically through that native guard too.
            guard = acquire_windows_state_tree(self.blobs, initialize=True,
                                               maximum_entries=65536, maximum_depth=16)
            if guard is not None:
                guard.close()
        else:
            self.blobs.mkdir(mode=0o700, exist_ok=True)
        _private(self.blobs, True)
        self.events_path = self.directory / 'events.jsonl'
        self.key_path = self.directory / 'authentication.key'
        self.head_path = self.directory / 'head.json'
        self.host = host or socket.gethostname()
        with _LOCKS_GUARD:
            self._mutex, self._local = _LOCKS.setdefault(str(self.directory), (threading.RLock(), threading.local()))
        self._contention_warnings = 0
        self._contention_timeouts = 0
        with self.lock():
            if not self.key_path.exists():
                if self.events_path.exists() or self.head_path.exists():
                    raise LedgerError('Ledger authentication key is missing; do not initialize over evidence')
                _atomic(self.key_path, os.urandom(32))
            self.key = _read(self.key_path, 32)
            if len(self.key) != 32:
                raise LedgerError('Invalid ledger authentication key')
            self.read()

    @contextlib.contextmanager
    def lock(self, timeout=60):
        # One budget includes both thread and process contention; it does not
        # limit work inside the caller's critical section or filesystem latency.
        if type(timeout) not in (int, float) or not math.isfinite(timeout) or timeout < 0:
            raise ValueError('Ledger lock timeout must be a finite nonnegative number')
        started = time.monotonic()
        deadline = started + timeout
        path = self.directory / 'writer.lock'
        warned = False

        def contention(stage):
            nonlocal warned
            waited = time.monotonic() - started
            if not warned and waited >= CONTENTION_WARNING_SECONDS:
                warned = True
                self._contention_warnings += 1
                LOG.warning('Waiting %.1fs for the mutation ledger at %s (%s); %s. '
                            'Pause and drain the shared ledger holder; SENTINEL_LEDGER_DIR '
                            "must continue to identify this host's existing evidence.",
                            waited, self.directory, stage, _holder_description(path))
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                self._contention_timeouts += 1
                raise LedgerBusy(
                    f'The mutation ledger at {self.directory} stayed locked for '
                    f'{timeout:g}s ({stage}); {_holder_description(path)}. '
                    'Pause and drain the holder. Do not change SENTINEL_LEDGER_DIR '
                    'to bypass pending mutation evidence.') from None
            return remaining

        acquired = self._mutex.acquire(blocking=False)
        while not acquired:
            remaining = contention('in-process mutex')
            acquired = self._mutex.acquire(timeout=min(0.05, remaining))
        try:
            if getattr(self._local, 'depth', 0):
                self._local.depth += 1
                try:
                    yield
                finally:
                    self._local.depth -= 1
                return
            # A zero timeout means one immediate attempt at each lock stage.
            if timeout and time.monotonic() >= deadline:
                contention('in-process mutex')
            new_lock = not path.exists()
            fd = os.open(path, os.O_CREAT | os.O_RDWR | getattr(os, 'O_NOFOLLOW', 0), 0o600)
            try:
                if new_lock:
                    _harden_new_windows_file(path)
                _private(path)
                if os.name == 'nt' and os.fstat(fd).st_size == 0:
                    os.write(fd, b'\0')
                    os.fsync(fd)
                first_attempt = True
                while True:
                    if not first_attempt or timeout:
                        if time.monotonic() >= deadline:
                            contention('OS file lock')
                    first_attempt = False
                    try:
                        if os.name == 'nt':
                            import msvcrt
                            os.lseek(fd, 0, 0)
                            msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
                        else:
                            import fcntl
                            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                        break
                    except OSError as exc:
                        if exc.errno not in {errno.EACCES, errno.EAGAIN, errno.EWOULDBLOCK, errno.EDEADLK}:
                            raise
                        time.sleep(min(0.05, contention('OS file lock')))
                held = time.monotonic() - started
                if held >= CONTENTION_WARNING_SECONDS:
                    LOG.warning('Acquired the mutation ledger at %s after %.1fs of contention',
                                self.directory, held)
                self._record_holder(fd)
                self._local.depth = 1
                try:
                    yield
                finally:
                    self._local.depth = 0
                    if os.name == 'nt':
                        os.lseek(fd, 0, 0)
                        msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
            finally:
                os.close(fd)
        finally:
            self._mutex.release()

    def _record_holder(self, fd):
        """Leave the holder's identity in the lock file for the next waiter.

        Advisory only: it names a process for a person to look at and is never
        trusted for a decision. A failure here must not fail the mutation.
        """
        try:
            record = canonical({'pid': os.getpid(), 'host': self.host,
                                'since': round(time.time(), 3)})[:MAX_LOCK_HOLDER_BYTES]
            os.lseek(fd, 0, 0)
            os.write(fd, record)
            os.truncate(fd, len(record))
        except OSError:
            pass

    def contention(self):
        """Observed lock contention for this process, for operator display."""
        return {'warnings': self._contention_warnings, 'timeouts': self._contention_timeouts}

    def _write_head(self, head):
        signed = dict(head, mac=hmac.new(self.key, canonical(head), hashlib.sha256).hexdigest())
        _atomic(self.head_path, canonical(signed))

    def _read_head(self):
        signed = json.loads(_read(self.head_path, 4096))
        head = {k: signed[k] for k in ('sequence', 'hash')}
        if not hmac.compare_digest(signed.get('mac', ''), hmac.new(self.key, canonical(head), hashlib.sha256).hexdigest()):
            raise LedgerError('Durable ledger head authentication failed')
        return head

    def read(self, pinned=None):
        """Reject corrupt/torn tails; never silently truncate or replay them."""
        with self.lock():
            events, previous = [], ZERO
            if self.events_path.exists():
                _private(self.events_path)
                with self.events_path.open('rb') as stream:
                    while True:
                        line = stream.readline(MAX_EVENT + 1)
                        if not line:
                            break
                        if len(line) > MAX_EVENT or not line.endswith(b'\n'):
                            raise LedgerError('Incomplete or oversized ledger append; human reconciliation required')
                        try:
                            record = json.loads(line)
                            raw = base64.b64decode(record['payload'], validate=True)
                            calculated = hashlib.sha256(previous.encode('ascii') + raw).hexdigest()
                            mac = hmac.new(self.key, calculated.encode('ascii'), hashlib.sha256).hexdigest()
                            if (record['sequence'] != len(events) + 1 or record['previous'] != previous or
                                record['hash'] != calculated or not hmac.compare_digest(record['mac'], mac)):
                                raise ValueError('chain')
                            body = json.loads(raw)
                            if body.get('version') != 1:
                                raise ValueError('version')
                            events.append({**body, 'sequence': record['sequence'], 'hash': calculated})
                            previous = calculated
                        except (KeyError, TypeError, ValueError) as exc:
                            raise LedgerError('Ledger authentication or chain verification failed') from exc
            if self.events_path.exists() and not self.head_path.exists():
                raise LedgerError('Durable ledger head is missing')
            for anchor in ([self._read_head()] if self.head_path.exists() else []) + ([pinned] if pinned else []):
                seq = anchor.get('sequence')
                if type(seq) is not int or seq < 0 or seq > len(events) or anchor.get('hash') != (events[seq-1]['hash'] if seq else ZERO):
                    raise LedgerError('Ledger was rolled back or differs from its durable pinned head')
            # A crash after the durable append but before the checkpoint is safe:
            # advance the checkpoint only after validating the entire prefix.
            head = {'sequence': len(events), 'hash': previous}
            if not self.head_path.exists() or self._read_head() != head:
                self._write_head(head)
            return events

    def head(self):
        events = self.read()
        return {'sequence': len(events), 'hash': events[-1]['hash'] if events else ZERO}

    def append(self, kind, **fields):
        with self.lock():
            events = self.read()
            previous = events[-1]['hash'] if events else ZERO
            body = {'version': 1, 'kind': kind, 'time_ns': time.time_ns(), 'host': self.host, **fields}
            raw = canonical(body)
            hashed = hashlib.sha256(previous.encode('ascii') + raw).hexdigest()
            row = {'sequence': len(events) + 1, 'previous': previous,
                   'payload': base64.b64encode(raw).decode('ascii'), 'hash': hashed,
                   'mac': hmac.new(self.key, hashed.encode('ascii'), hashlib.sha256).hexdigest()}
            data = canonical(row) + b'\n'
            if len(data) > MAX_EVENT:
                raise LedgerError('Ledger event exceeds its size limit')
            new_events = not self.events_path.exists()
            fd = os.open(self.events_path, os.O_WRONLY | os.O_APPEND | os.O_CREAT | getattr(os, 'O_NOFOLLOW', 0), 0o600)
            try:
                if new_events:
                    _harden_new_windows_file(self.events_path)
                _private(self.events_path)
                remaining = memoryview(data)
                while remaining:
                    count = os.write(fd, remaining)
                    if count <= 0:
                        raise OSError('Ledger append did not advance')
                    remaining = remaining[count:]
                os.fsync(fd)
            finally:
                os.close(fd)
            _sync_directory(self.directory)
            self._write_head({'sequence': row['sequence'], 'hash': hashed})
            return {**body, 'sequence': row['sequence'], 'hash': hashed}

    def store(self, value):
        raw = canonical(value)
        if len(raw) > MAX_STATE:
            raise LedgerError('Exact state exceeds the rollback evidence limit; mutation refused')
        key = hashlib.sha256(raw).hexdigest()
        path = self.blobs / key
        if path.exists():
            if _read(path, MAX_STATE) != raw:
                raise LedgerError('Rollback state blob was modified')
        else:
            _atomic(path, raw)
        return key

    def state(self, key):
        if not isinstance(key, str) or len(key) != 64 or any(x not in '0123456789abcdef' for x in key):
            raise LedgerError('Invalid state hash')
        raw = _read(self.blobs / key, MAX_STATE)
        if hashlib.sha256(raw).hexdigest() != key:
            raise LedgerError('Rollback state blob integrity failed')
        return json.loads(raw)

    def actions(self, *, include_states=False):
        actions = {}
        for event in self.read():
            key, kind = event.get('action_id'), event['kind']
            if kind == 'prepared':
                if key in actions:
                    raise LedgerError('Duplicate action identity')
                actions[key] = {**event, 'status': 'prepared', 'another_actor_modified': False}
            elif key in actions:
                row = actions[key]
                if kind in {'committed', 'uncertain', 'undo_prepared', 'undone', 'conflict', 'cancelled', 'quiesce_prepared', 'quiesced', 'applied', 'boot_prepared', 'boot_committed'}:
                    row.update({k: v for k, v in event.items() if k not in {'kind', 'sequence', 'hash', 'time_ns'}})
                    row['status'] = 'committed' if kind in {'quiesced', 'boot_committed'} else kind
                elif kind == 'rebased':
                    row['expected_after'] = event['expected_after']
                row['last_sequence'] = event['sequence']
        if include_states:
            for row in actions.values():
                row['before'] = self.state(row['before_hash'])
                if row.get('after_hash'):
                    row['after'] = self.state(row.get('expected_after', row['after_hash']))
        return list(actions.values())

    def paused(self):
        paused = False
        for event in self.read():
            if event['kind'] == 'withdrawal_pause':
                paused = True
            elif event['kind'] in {'withdrawal_review_cancelled', 'withdrawal_released'}:
                paused = False
        return paused

    def withdrawal_operation(self):
        """The operation id of the withdrawal pausing this host, or None."""
        if not self.paused():
            return None
        pauses = [x for x in self.read() if x['kind'] == 'withdrawal_pause']
        return pauses[-1].get('operation_id') if pauses else None

    def release_after_withdrawal(self, operation_id, *, check_only=False):
        """Admit Sentinel on this host again after an executed withdrawal.

        An executed withdrawal leaves the host paused on purpose: nothing of
        Sentinel's restarts, re-enrolls or sets up until a person decides it
        may. Until 2.0.5 nothing could record that decision short of deleting
        the ledger, which also destroys the evidence. This records it. It
        refuses while any action is in flight, changes no object, and leaves
        every conflict the withdrawal held on record.
        """
        with self.lock():
            events = self.read()
            pauses = [i for i, x in enumerate(events) if x['kind'] == 'withdrawal_pause']
            if not pauses or not self.paused():
                raise LedgerError('No withdrawal is pausing this host')
            if events[pauses[-1]].get('operation_id') != operation_id:
                raise LedgerError('That is not the withdrawal pausing this host')
            if not any(x['kind'] in {'undo_prepared', 'quiesce_prepared', 'undone', 'quiesced'}
                       for x in events[pauses[-1] + 1:]):
                raise LedgerError('This withdrawal was only reviewed; cancel the review instead')
            pending = [x['action_id'] for x in self.actions()
                       if x['status'] in {'prepared', 'applied', 'uncertain', 'undo_prepared', 'quiesce_prepared', 'boot_prepared'}]
            if pending:
                raise LedgerError('An interrupted mutation requires reconciliation before admission can resume')
            held = [x['action_id'] for x in self.actions() if x['status'] == 'conflict']
            if not check_only:
                self.append('withdrawal_released', operation_id=operation_id)
            return {'status': 'can_release' if check_only else 'released', 'held_conflicts': held,
                    'head': self.head()}

    def automation_paused(self):
        if self.paused():
            return True
        paused = False
        for event in self.read():
            if event['kind'] == 'continuity_pause':
                paused = True
            elif event['kind'] == 'continuity_resume':
                paused = False
        return paused

    def pause(self, operation_id):
        with self.lock():
            self.append('withdrawal_pause', operation_id=operation_id)
            pending = [x['action_id'] for x in self.actions() if x['status'] in {'prepared', 'applied', 'uncertain', 'undo_prepared', 'quiesce_prepared', 'boot_prepared'}]
            return {'paused': True, 'drained': not pending, 'pending': pending, 'head': self.head()}

    def cancel_review(self, operation_id, *, check_only=False):
        with self.lock():
            events = self.read()
            pauses = [i for i, x in enumerate(events) if x['kind'] == 'withdrawal_pause']
            if not pauses or events[pauses[-1]]['operation_id'] != operation_id:
                raise LedgerError('This withdrawal review is no longer current')
            if any(x['kind'] in {'undo_prepared', 'quiesce_prepared'} for x in events[pauses[-1]+1:]):
                raise LedgerError('Withdrawal already changed objects; review recovery instead of resuming admission')
            if any(x['status'] in {'prepared', 'applied', 'uncertain', 'undo_prepared', 'quiesce_prepared', 'boot_prepared'} for x in self.actions()):
                raise LedgerError('An interrupted mutation requires reconciliation before admission can resume')
            if not check_only:
                self.append('withdrawal_review_cancelled', operation_id=operation_id)
            return {'status': 'can_cancel' if check_only else 'cancelled', 'head': self.head()}

    def prepare(self, adapter, target, before, *, action_id=None, ownership='configuration', dependencies=(), inverse=None, context=None):
        with self.lock():
            if self.paused():
                raise LedgerError('Emergency withdrawal paused mutations on this host')
            if ownership not in {'configuration', 'sentinel_artifact', 'sentinel_credential', 'sentinel_process', 'sentinel_control'}:
                raise LedgerError('Unknown ownership category')
            action_id = action_id or uuid.uuid4().hex
            rows = self.actions(include_states=True)
            if any(x['action_id'] == action_id for x in rows):
                raise LedgerError('Action identity cannot be replayed')
            dependencies = list(dependencies)
            objects = set(target.get('objects', [digest(target)]))
            for row in rows:
                if objects.intersection(row['target'].get('objects', [digest(row['target'])])):
                    if row['status'] in {'prepared', 'applied', 'uncertain', 'undo_prepared', 'quiesce_prepared', 'boot_prepared', 'conflict'}:
                        raise OwnershipConflict('An earlier action has unresolved ownership')
                    if row['status'] == 'committed' and row['action_id'] not in dependencies:
                        dependencies.append(row['action_id'])
            return self.append('prepared', action_id=action_id, adapter=adapter, target=target,
                               before_hash=self.store(before), ownership=ownership, dependencies=dependencies,
                               inverse=inverse or {'adapter': adapter, 'operation': 'restore_exact_pre_state'},
                               context=context or {}, another_actor_modified=False)['action_id']

    def commit(self, action_id, after, validation):
        with self.lock():
            row = next((x for x in self.actions() if x['action_id'] == action_id), None)
            if not row or row['status'] not in {'prepared', 'applied'}:
                raise LedgerError('Only a prepared action can commit')
            event = self.append('committed', action_id=action_id, after_hash=self.store(after), validation=validation)
            if row['ownership'] == 'sentinel_control':
                # A recorded resume closes its recorded suspension. Emergency
                # Remove must not briefly re-suspend an already released user.
                current_before = self.state(row['before_hash'])
                chain = []
                for prior in reversed(self.actions(include_states=True)):
                    if prior['action_id'] == action_id or prior['target'] != row['target']:
                        continue
                    if prior['status'] != 'committed' or prior['ownership'] != 'sentinel_control' or prior['after'] != current_before:
                        break
                    chain.append(prior)
                    current_before = prior['before']
                    if current_before == after:
                        for owned in chain:
                            self.append('undone', action_id=owned['action_id'], restored_hash=self.store(after),
                                        validation={'success': True}, inverse_action=action_id)
                        self.append('cancelled', action_id=action_id, reason='Closed recorded temporary containment', validation={'success': True})
                        break
            return event

    def mutate(self, adapter, target, operation, *, snapshot, validate=None, **metadata):
        """Write-ahead admission and full-duration exclusion of pause/other writers."""
        with self.lock():
            before = snapshot(target)
            action_id = self.prepare(adapter, target, before, **metadata)
            try:
                result = operation()
                after = snapshot(target)
                validation = validate(result, before, after) if validate else {'success': True}
                if not validation.get('ownership_proven', True):
                    raise OwnershipConflict('Observed post-state was not produced by the admitted mutation')
                if after == before:
                    self.append('cancelled', action_id=action_id, after_hash=self.store(after), validation=validation, reason='No object state changed')
                else:
                    self.commit(action_id, after, validation)
                return result
            except BaseException as exc:
                self.append('uncertain', action_id=action_id, reason=type(exc).__name__, validation={'success': False})
                raise
