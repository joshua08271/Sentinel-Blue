"""Dependency-free host telemetry collectors for Linux and Windows."""

from __future__ import annotations

import json
import hashlib
import fnmatch
import os
import platform
import re
import socket
import stat
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from contextvars import ContextVar
from pathlib import Path
from typing import Any, Callable, TypeVar

try:
    import pwd
except ImportError:  # pragma: no cover - Windows does not provide pwd
    pwd = None  # type: ignore[assignment]

try:
    import grp
except ImportError:  # pragma: no cover - Windows does not provide grp
    grp = None  # type: ignore[assignment]

from .protocol import (
    Account,
    FilesystemCapacity,
    FirewallState,
    IntegrityItem,
    Interface,
    Listener,
    MemoryCapacity,
    Neighbor,
    PersistenceItem,
    ProcessObservation,
    Route,
    SecurityEvent,
    Service,
    Session,
    Telemetry,
)
from .posix_security import capture_xattrs, security_digest
from .process_identity import inspect_process_identity
from .windows_queries import WINDOWS_QUERIES
from .windows_query_batch import QueryResult, decode_rows, read_query_batch

MAX_WINDOWS_INTEGRITY_FILE_BYTES = 32 * 1024 * 1024
MAX_WINDOWS_INTEGRITY_TOTAL_BYTES = 128 * 1024 * 1024
WINDOWS_INTEGRITY_BUDGET_SECONDS = 10.0
MAX_INTEGRITY_PATHS = 256
MAX_INTEGRITY_DISCOVERY_ENTRIES = 4096
MAX_POSIX_INTEGRITY_FILE_BYTES = 32 * 1024 * 1024
MAX_POSIX_INTEGRITY_TOTAL_BYTES = 128 * 1024 * 1024
POSIX_INTEGRITY_BUDGET_SECONDS = 10.0
WINDOWS_INVENTORY_BUDGET_SECONDS = 75.0
_windows_deadline: ContextVar[float | None] = ContextVar("windows_inventory_deadline", default=None)
_windows_query_cache: ContextVar[Any] = ContextVar("windows_inventory_queries", default=None)


class _WindowsQueryCache:
    """One lazy native snapshot, discarded at the end of this collection."""
    def __init__(self, deadline: float):
        self.deadline = deadline
        self.results: dict[str, QueryResult] | None = None
        self.lock = threading.Lock()

    def read(self, script: str) -> list[dict[str, Any]]:
        name = next((name for name, body in WINDOWS_QUERIES.items() if body == script), None)
        if name is None:
            raise RuntimeError("query is outside this Windows inventory snapshot")
        with self.lock:
            if self.results is None:
                self.results = read_query_batch(self.deadline)
        record = self.results.get(name)
        if record is None or record.error:
            raise RuntimeError(record.error if record else "Windows inventory section did not complete")
        if time.monotonic() >= self.deadline:
            raise RuntimeError("Windows inventory query completed after its collection budget")
        return record.rows


@contextmanager
def _windows_query_snapshot():
    deadline = _windows_deadline.get()
    if deadline is None:
        raise RuntimeError("Windows snapshot requires the original inventory deadline")
    token = _windows_query_cache.set(_WindowsQueryCache(deadline))
    try:
        yield
    finally:
        _windows_query_cache.reset(token)


@contextmanager
def _windows_inventory_budget():
    """Share one finite query budget without carrying state into the next cycle."""
    current = _windows_deadline.get()
    deadline = current if current is not None else time.monotonic() + WINDOWS_INVENTORY_BUDGET_SECONDS
    token = _windows_deadline.set(deadline)
    try:
        yield deadline
    finally:
        _windows_deadline.reset(token)


def _run(command: list[str], timeout: float = 8.0) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        text=True,
        capture_output=True,
        timeout=timeout,
        check=False,
        # Avoid inheriting a background task's below-normal scheduling class.
        # Normal priority still shares the CPU with the applications we monitor.
        creationflags=(
            getattr(subprocess, "CREATE_NO_WINDOW", 0)
            | getattr(subprocess, "NORMAL_PRIORITY_CLASS", 0)
        ),
    )


def _linux_accounts(errors: list[str] | None = None) -> list[Account]:
    if pwd is None:
        return []
    privileged_names: set[str] = set()
    known_groups: dict[str, tuple[int, set[str]]] = {}
    for group in ("sudo", "wheel", "admin"):
        try:
            result = _run(["getent", "group", group])
        except (OSError, subprocess.SubprocessError) as exc:
            if errors is not None:
                errors.append(f"Linux account privilege inventory unavailable ({type(exc).__name__})")
            continue
        if result.returncode == 2:
            continue  # getent's missing-key result; not all distributions have all three groups.
        if result.returncode != 0 or result.stderr.strip():
            if errors is not None:
                errors.append("Linux account privilege inventory unavailable")
            continue
        fields = result.stdout.strip().split(":")
        try:
            if len(fields) != 4 or fields[0] != group or not fields[2].isdigit():
                raise ValueError('Invalid privileged group record')
            gid = int(fields[2])
            members = {name for name in fields[3].split(",") if name}
            known_groups[group] = (gid, members)
            privileged_names.update(members)
        except ValueError:
            if errors is not None:
                errors.append("Linux account privilege inventory malformed")
    accounts: list[Account] = []
    try:
        if grp is None:
            raise OSError('Group enumeration unavailable')
        group_entries = grp.getgrall()
    except OSError:
        group_entries = []
        if errors is not None:
            errors.append("Linux account group inventory unavailable; supplementary membership incomplete")
    for entry in pwd.getpwall():
        disabled_shell = entry.pw_shell.endswith(("/false", "/nologin"))
        groups: list[str] = []
        groups = sorted(
            {
                item.gr_name
                for item in group_entries
                if entry.pw_name in item.gr_mem or item.gr_gid == entry.pw_gid
            } | {name for name, (gid, members) in known_groups.items()
                 if entry.pw_gid == gid or entry.pw_name in members}
        )
        accounts.append(
            Account(
                name=entry.pw_name,
                account_id=str(entry.pw_uid),
                privileged=(
                    entry.pw_uid == 0
                    or entry.pw_name in privileged_names
                    or bool(set(groups) & {"sudo", "wheel", "admin"})
                ),
                enabled=not disabled_shell,
                source="local",
                groups=groups,
            )
        )
    return accounts


def _linux_sessions(privileged: set[str], errors: list[str] | None = None) -> list[Session]:
    try:
        result = _run(["who", "-u"])
    except (OSError, subprocess.SubprocessError) as exc:
        if errors is not None:
            errors.append(f"Linux session inventory unavailable ({type(exc).__name__})")
        return []
    if result.returncode != 0:
        if errors is not None:
            errors.append("Linux session inventory unavailable")
        return []
    sessions: list[Session] = []
    for line in result.stdout.splitlines():
        parts = line.split()
        if len(parts) < 2:
            continue
        username = parts[0]
        source = "local"
        if parts[-1].startswith("(") and parts[-1].endswith(")"):
            source = parts[-1][1:-1]
        process_id = None
        for value in parts[4:]:
            if value.isdigit():
                process_id = int(value)
                break
        process_identity = None
        if process_id is not None:
            try:
                process_identity = inspect_process_identity(
                    process_id, boot_id=_boot_id("linux")
                )
            except (OSError, PermissionError, RuntimeError, ValueError) as exc:
                if errors is not None:
                    errors.append(
                        f"session process identity unavailable for PID {process_id}: {exc}"
                    )
        sessions.append(
            Session(
                username=username,
                source=source,
                session_id=parts[1],
                process_id=process_id,
                privileged=username.casefold() in privileged,
                process_identity=process_identity,
            )
        )
    return sessions


def _linux_services(errors: list[str]) -> list[Service]:
    try:
        result = _run(
            [
                "systemctl",
                "list-units",
                "--type=service",
                "--all",
                "--no-legend",
                "--no-pager",
                "--plain",
                "--full",
            ],
            timeout=15,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        errors.append(f"systemctl service inventory unavailable ({type(exc).__name__})")
        return []
    if result.returncode != 0:
        errors.append("systemctl service inventory unavailable")
        return []
    start_modes: dict[str, str] = {}
    installed_names: list[str] = []
    try:
        unit_files = _run(
            [
                "systemctl",
                "list-unit-files",
                "--type=service",
                "--no-legend",
                "--no-pager",
                "--plain",
                "--full",
            ],
            timeout=15,
        )
        if unit_files.returncode == 0:
            for line in unit_files.stdout.splitlines():
                fields = line.split()
                if len(fields) >= 2:
                    start_modes[fields[0]] = fields[1]
                    installed_names.append(fields[0])
        else:
            errors.append("systemctl service startup inventory unavailable")
    except (OSError, subprocess.TimeoutExpired):
        errors.append("systemctl service startup inventory unavailable")
    parsed: list[tuple[str, str, str]] = []
    for line in result.stdout.splitlines():
        parts = line.split(None, 4)
        if len(parts) < 4:
            continue
        parsed.append((parts[0], parts[2], parts[3]))
    details: dict[str, dict[str, str]] = {}
    # Query all returned loaded units, in bounded argv batches under one budget.
    # Installed but unloaded units stay unknown: loading alias/generated entries
    # simply to inspect them can fail or change the service manager's inventory.
    names = list(dict.fromkeys(name for name, _active, _substate in parsed[:2000]))
    detail_deadline = time.monotonic() + 20.0
    for offset in range(0, len(names), 512):
        batch = names[offset:offset + 512]
        remaining = detail_deadline - time.monotonic()
        if remaining <= 0:
            errors.append("systemctl service failure metadata budget exhausted; coverage is incomplete")
            break
        try:
            detail_result = _run(
                ["systemctl", "show", "--no-pager",
                 "--property=Id,ActiveState,SubState,UnitFileState,NRestarts,Result,ExecMainStatus,RemainAfterExit",
                 *batch], timeout=remaining)
            if time.monotonic() >= detail_deadline:
                errors.append("systemctl service failure metadata arrived after its budget; coverage is incomplete")
                break
            if detail_result.returncode != 0:
                errors.append("systemctl service failure metadata unavailable for a batch; coverage is incomplete")
                continue
            if detail_result.stderr.strip():
                errors.append("systemctl service failure metadata has diagnostics; coverage is incomplete")
            received: dict[str, dict[str, str]] = {}
            duplicate_ids: set[str] = set()
            record: dict[str, str] = {}
            invalid_record = False
            malformed = False
            for line in [*detail_result.stdout.splitlines(), ""]:
                if not line.strip():
                    if record:
                        name = record.get("Id")
                        if name not in batch:
                            malformed = True
                        elif invalid_record or name in received:
                            duplicate_ids.add(name)
                        else:
                            received[name] = record
                    record = {}
                    invalid_record = False
                elif "=" in line:
                    key, value = line.split("=", 1)
                    if key in record:
                        malformed = invalid_record = True
                    record[key] = value
                else:
                    malformed = invalid_record = True
            for name in duplicate_ids:
                received.pop(name, None)
            if malformed or duplicate_ids or set(received) != set(batch):
                errors.append("systemctl service failure metadata is partial or malformed; coverage is incomplete")
            details.update(received)
        except (OSError, subprocess.SubprocessError) as exc:
            errors.append(f"systemctl service failure metadata unavailable ({type(exc).__name__}); coverage is incomplete")
    # systemd may garbage-collect a stopped static unit from list-units even
    # while its unit file remains installed.  Preserve those identities so a
    # baseline service cannot disappear from telemetry at the moment it stops.
    # Do not include unloaded names in the batched `systemctl show`: some valid
    # alias and generated unit-file entries make that command return nonzero.
    loaded_names = {name for name, _active, _substate in parsed}
    if len(loaded_names | set(installed_names)) > 2000:
        errors.append("Linux service inventory exceeded its 2000-entry limit; coverage is incomplete")
    for name in installed_names:
        if name not in loaded_names and len(parsed) < 2000:
            parsed.append((name, "inactive", "dead"))
            loaded_names.add(name)
    services: list[Service] = []
    for name, active, substate in parsed[:2000]:
        detail = details.get(name, {})
        def observed_integer(key, maximum):
            raw = detail.get(key, "")
            if (not raw or len(raw) > 10 or not raw.isascii() or not raw.isdigit()
                    or int(raw) > maximum):
                return None
            return int(raw)
        restarts = observed_integer("NRestarts", 2**31 - 1)
        exit_status = observed_integer("ExecMainStatus", 2**32 - 1)
        verdict = detail.get("Result") or "unknown"
        # A loaded unit whose requested fields are missing is incomplete evidence.
        # Do not make a root-cause/restart decision from fabricated success or zero.
        if name in names and (restarts is None or exit_status is None or verdict == "unknown"):
            if "systemctl service failure fields missing or malformed; coverage is incomplete" not in errors:
                errors.append("systemctl service failure fields missing or malformed; coverage is incomplete")
        # A unit that finished starting and stays active by design
        # (RemainAfterExit=yes, "active (exited)") is up. Ubuntu's
        # postgresql.service is one: it starts and restarts the real clusters
        # and is never "running" itself. Found live on 2.0.6: it read as
        # "active", which nothing treats as up, so PostgreSQL could never
        # be baselined or repaired.
        up = substate == "running" or (
            active == "active" and substate == "exited" and detail.get("RemainAfterExit") == "yes")
        services.append(
            Service(
                name=name,
                state="running" if up else active,
                start_mode=(
                    start_modes.get(name)
                    or detail.get("UnitFileState")
                    or "unknown"
                ),
                substate=detail.get("SubState") or substate or "unknown",
                result=verdict,
                restart_count=restarts,
                exit_code=exit_status,
            )
        )
    return services[:2000]


def _windows_json(script: str, timeout: float = 60.0) -> Any:
    deadline = _windows_deadline.get()
    if deadline is not None:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise RuntimeError("Windows inventory query budget exhausted")
        timeout = min(timeout, remaining)
    cache = _windows_query_cache.get()
    if cache is not None:
        return cache.read(script)
    try:
        result = _run(
            ["powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive", "-Command",
             "$ErrorActionPreference = 'Stop'\n" + script],
            timeout=timeout,
        )
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(f"PowerShell collector timed out after {timeout:g} seconds") from exc
    if deadline is not None and time.monotonic() > deadline:
        raise RuntimeError("Windows inventory query completed after its collection budget")
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "PowerShell command failed")
    if result.stderr.strip():
        # PowerShell can exit successfully after a non-terminating error and
        # still emit partial JSON. Never turn that into a complete observation.
        raise RuntimeError("PowerShell collector reported errors: " + result.stderr.strip())
    return decode_rows(result.stdout)


def _windows_accounts(errors: list[str]) -> list[Account]:
    script = WINDOWS_QUERIES["ACCOUNTS"]
    try:
        rows = _windows_json(script)
        if not rows:
            raise ValueError("Windows account inventory returned no records")
        return [
            Account(
                name=str(item.get("Name", "unknown")),
                account_id=str(item.get("SID", "")),
                privileged=bool(item.get("Privileged")),
                enabled=bool(item.get("Enabled", True)),
                source="local",
                groups=["Administrators"] if bool(item.get("Privileged")) else [],
            )
            for item in rows
        ]
    except Exception as exc:
        errors.append(f"Windows account inventory failed: {exc}")
        return []


def _windows_services(errors: list[str]) -> list[Service]:
    script = WINDOWS_QUERIES["SERVICES"]
    try:
        rows = _windows_json(script)
        if not rows:
            raise ValueError("Windows service inventory returned no records")
        return [
            Service(
                name=str(item.get("Name", "unknown")),
                state="running" if str(item.get("State", "")).casefold() == "running" else str(item.get("State", "unknown")).casefold(),
                start_mode=str(item.get("StartMode", "unknown")),
                substate=str(item.get("Status", "unknown")).casefold(),
                result=(
                    "success"
                    if int(item.get("ExitCode", 0) or 0) == 0
                    else "exit-code"
                ),
                restart_count=max(0, int(item.get("RestartCount", 0) or 0)),
                exit_code=max(0, int(item.get("ExitCode", 0) or 0)),
            )
            for item in rows
        ]
    except Exception as exc:
        errors.append(f"Windows service inventory failed: {exc}")
        return []


def _windows_sessions(accounts: list[Account], errors: list[str], *, boot_id: str | None = None) -> list[Session]:
    privileged = {account.name.casefold() for account in accounts if account.privileged}
    script = WINDOWS_QUERIES["SESSIONS"]
    try:
        sessions: list[Session] = []
        if boot_id is None:
            boot_id = _boot_id("windows")
        for item in _windows_json(script):
            raw_user = str(item.get("UserName", ""))
            username = raw_user.split("\\")[-1] if raw_user else "unknown"
            process_id = int(item["Id"]) if item.get("Id") is not None else None
            process_identity = None
            if process_id is not None:
                try:
                    process_identity = inspect_process_identity(
                        process_id, boot_id=boot_id
                    )
                except (OSError, PermissionError, RuntimeError, ValueError) as exc:
                    errors.append(
                        f"session process identity unavailable for PID {process_id}: {exc}"
                    )
            sessions.append(
                Session(
                    username=username,
                    source="unknown",
                    session_id=str(item.get("SessionId", "")),
                    process_id=process_id,
                    privileged=username.casefold() in privileged,
                    interactive=True,
                    process_identity=process_identity,
                )
            )
        return sessions
    except Exception as exc:
        errors.append(f"Windows interactive-session inventory failed: {exc}")
        return []


def _fallback_interfaces(errors: list[str]) -> list[Interface]:
    interfaces: dict[str, set[str]] = {}
    try:
        for _, name in socket.if_nameindex():
            interfaces.setdefault(name, set())
    except OSError as exc:
        errors.append(f"interface names unavailable: {exc}")
    try:
        for family, _, _, _, address in socket.getaddrinfo(socket.gethostname(), None):
            if family in {socket.AF_INET, socket.AF_INET6}:
                interfaces.setdefault("host", set()).add(str(address[0]))
    except OSError as exc:
        errors.append(f"interface addresses unavailable: {exc}")
    if len(interfaces) > 512 or any(len(v) > 64 for v in interfaces.values()):
        errors.append("fallback interface/address limit exceeded; coverage incomplete")
    return [Interface(name=name, addresses=sorted(addresses)[:64])
            for name, addresses in sorted(interfaces.items())[:512]]


def _kernel_interfaces() -> list[Interface]:
    """Interface addresses from the kernel (ioctl and /proc), without iproute2."""
    import fcntl
    import struct
    addresses: dict[str, list[str]] = {name: [] for _, name in socket.if_nameindex()}
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        for name in addresses:
            request = struct.pack("256s", name.encode()[:15])
            try:
                local = socket.inet_ntoa(fcntl.ioctl(probe.fileno(), 0x8915, request)[20:24])
                mask = fcntl.ioctl(probe.fileno(), 0x891B, request)[20:24]
            except OSError:
                continue  # no IPv4 address on this interface
            addresses[name].append(f"{local}/{bin(int.from_bytes(mask, 'big')).count('1')}")
    finally:
        probe.close()
    inet6 = Path("/proc/net/if_inet6")
    if inet6.exists():
        for line in inet6.read_text().splitlines():
            fields = line.split()
            if len(fields) >= 6 and fields[5] in addresses:
                addresses[fields[5]].append(f"{_hex_ipv6(fields[0], proc_net=False)}/{int(fields[2], 16)}")
    return [Interface(name=name, addresses=sorted(values)[:64]) for name, values in sorted(addresses.items())[:512]]


def _linux_interfaces(errors: list[str]) -> list[Interface]:
    try:
        reply = _run(["ip", "-j", "address", "show"], timeout=15)
    except FileNotFoundError:
        try:
            return _kernel_interfaces()   # iproute2 is not installed
        except (OSError, ValueError) as exc:
            errors.append(f"interface inventory unavailable ({type(exc).__name__}); fallback address mapping incomplete")
            return _fallback_interfaces(errors)
    except (OSError, subprocess.SubprocessError) as exc:
        errors.append(f"interface inventory unavailable ({type(exc).__name__}); fallback address mapping incomplete")
        return _fallback_interfaces(errors)
    try:
        if reply.returncode != 0:
            raise ValueError('provider failed')
        rows = json.loads(reply.stdout)
        if not isinstance(rows, list):
            raise ValueError('provider did not return an interface list')
        if reply.stderr.strip():
            errors.append("interface inventory provider reported diagnostics; coverage incomplete")
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        errors.append(f"interface inventory unavailable ({type(exc).__name__}); fallback address mapping incomplete")
        return _fallback_interfaces(errors)
    if len(rows) > 512:
        errors.append("interface inventory exceeds the 512-interface limit; coverage incomplete")
    result: list[Interface] = []
    seen = set()
    for row in rows[:512]:
        if (not isinstance(row, dict) or not isinstance(row.get('ifname'), str)
                or not row['ifname'] or len(row['ifname']) > 128 or row['ifname'] in seen):
            errors.append("interface inventory has an invalid/duplicate identity; coverage incomplete")
            continue
        name = row['ifname']; seen.add(name)
        address_rows = row.get('addr_info')
        if not isinstance(address_rows, list):
            errors.append("interface inventory address list unavailable; coverage incomplete")
            address_rows = []
        if len(address_rows) > 64:
            errors.append("interface inventory exceeds the 64-address per-interface limit; coverage incomplete")
        addresses = []
        for item in address_rows[:64]:
            try:
                import ipaddress
                if not isinstance(item, dict) or not isinstance(item.get('local'), str):
                    raise ValueError('invalid address record')
                address = ipaddress.ip_address(item['local'])
                prefix = item.get('prefixlen')
                if prefix is not None and (type(prefix) is not int or not 0 <= prefix <= address.max_prefixlen):
                    raise ValueError('invalid prefix')
                if item.get('family', 'inet' if address.version == 4 else 'inet6') != ('inet' if address.version == 4 else 'inet6'):
                    raise ValueError('mismatched family')
                addresses.append(str(address) + (f'/{prefix}' if prefix is not None else ''))
            except (ValueError, TypeError):
                errors.append("interface inventory has an invalid address; coverage incomplete")
        result.append(Interface(name=name, addresses=addresses))
    return result


def _windows_interfaces(errors: list[str]) -> list[Interface]:
    script = WINDOWS_QUERIES["INTERFACES"]
    try:
        grouped: dict[str, set[str]] = {}
        for row in _windows_json(script):
            name = str(row.get("InterfaceAlias", "unknown"))
            address = str(row.get("IPAddress", ""))
            if not address:
                continue
            prefix = row.get("PrefixLength")
            grouped.setdefault(name, set()).add(
                f"{address}/{prefix}" if prefix is not None else address
            )
        return [Interface(name=name, addresses=sorted(addresses)) for name, addresses in sorted(grouped.items())]
    except Exception as exc:
        errors.append(f"Windows interface inventory failed: {exc}")
        return _fallback_interfaces(errors)


def _json_command(command: list[str], errors: list[str], label: str, *, result=None) -> list[dict[str, Any]]:
    try:
        if result is None:
            result = _run(command, timeout=15)
        if result.returncode != 0 or not result.stdout.strip():
            errors.append(f"{label} unavailable")
            return []
        value = json.loads(result.stdout)
        if isinstance(value, dict):
            return [value]
        return value if isinstance(value, list) else []
    except (OSError, ValueError, subprocess.TimeoutExpired, json.JSONDecodeError) as exc:
        errors.append(f"{label} failed: {exc}")
        return []


def _linux_topology(errors: list[str], network: list[str] | None = None) -> tuple[list[Route], list[Neighbor], list[Listener]]:
    """Routes and neighbors report into `network`; listeners into `errors`."""
    routes, neighbors = _linux_routes(errors if network is None else network)
    return routes, neighbors, _linux_listeners(errors)


def _hex_ipv4(value: str) -> str:
    return socket.inet_ntoa(int(value, 16).to_bytes(4, "little"))


def _hex_ipv6(value: str, *, proc_net: bool = True) -> str:
    raw = bytes.fromhex(value)
    if proc_net:  # /proc/net/tcp6 stores four host-order 32-bit words
        raw = b"".join(raw[i:i + 4][::-1] for i in range(0, 16, 4))
    return socket.inet_ntop(socket.AF_INET6, raw)


def _kernel_routes(errors: list[str]) -> tuple[list[Route], list[Neighbor]]:
    """Routes and IPv4 neighbors from the kernel's own tables, without iproute2."""
    routes: list[Route] = []
    neighbors: list[Neighbor] = []
    try:
        for line in Path("/proc/net/route").read_text().splitlines()[1:]:
            f = line.split()
            if len(f) < 8:
                continue
            prefix = bin(int(f[7], 16)).count("1")
            destination = _hex_ipv4(f[1])
            routes.append(Route(destination="default" if destination == "0.0.0.0" and prefix == 0 else f"{destination}/{prefix}",
                                gateway="" if _hex_ipv4(f[2]) == "0.0.0.0" else _hex_ipv4(f[2]),
                                interface=f[0], metric=int(f[6]) if f[6].isdigit() else None))
    except (OSError, ValueError) as exc:
        errors.append(f"route inventory failed: {type(exc).__name__}")
    ipv6 = Path("/proc/net/ipv6_route")
    if ipv6.exists():
        try:
            for line in ipv6.read_text().splitlines():
                f = line.split()
                if len(f) < 10 or f[9] == "lo":
                    continue
                prefix = int(f[1], 16)
                destination = _hex_ipv6(f[0], proc_net=False)
                gateway = _hex_ipv6(f[4], proc_net=False)
                routes.append(Route(destination="default" if destination == "::" and prefix == 0 else f"{destination}/{prefix}",
                                    gateway="" if gateway == "::" else gateway, interface=f[9], metric=int(f[5], 16)))
        except (OSError, ValueError) as exc:
            errors.append(f"IPv6 route inventory failed: {type(exc).__name__}")
    try:
        for line in Path("/proc/net/arp").read_text().splitlines()[1:]:
            f = line.split()
            if len(f) >= 6:
                neighbors.append(Neighbor(address=f[0], hardware_address=f[3], interface=f[5],
                                          state="reachable" if f[2] != "0x0" else "incomplete"))
    except OSError as exc:
        errors.append(f"neighbor inventory failed: {type(exc).__name__}")
    if Path("/proc/net/if_inet6").exists() and Path("/proc/net/if_inet6").read_text().strip():
        errors.append("IPv6 neighbor inventory needs iproute2 (ip); IPv4 neighbors were read from the kernel")
    return routes, neighbors


def _linux_routes(errors: list[str]) -> tuple[list[Route], list[Neighbor]]:
    command = ["ip", "-j", "route", "show"]
    try:
        reply = _run(command, timeout=15)
    except FileNotFoundError:
        return _kernel_routes(errors)   # iproute2 is not installed
    except (OSError, subprocess.SubprocessError) as exc:
        errors.append(f"route inventory failed: {exc}")
        route_rows = []
    else:
        route_rows = _json_command(command, errors, "route inventory", result=reply)
    neighbor_rows = _json_command(["ip", "-j", "neigh", "show"], errors, "neighbor inventory")
    routes = [
        Route(
            destination=str(row.get("dst", "default")),
            gateway=str(row.get("gateway", "")),
            interface=str(row.get("dev", "")),
            metric=int(row["metric"]) if str(row.get("metric", "")).isdigit() else None,
        )
        for row in route_rows
    ]
    neighbors = [
        Neighbor(
            address=str(row.get("dst", "")),
            hardware_address=str(row.get("lladdr", "")),
            interface=str(row.get("dev", "")),
            state=str(row.get("state", "unknown")),
        )
        for row in neighbor_rows
        if row.get("dst")
    ]
    return routes, neighbors


MAX_LINUX_LISTENERS = 2000


KERNEL_SOCKET_STATES = {"LISTEN": "0A", "UNCONN": "07"}


def _kernel_listeners(protocol: str, state: str, errors: list[str], room: int) -> list[Listener]:
    rows: list[Listener] = []
    label = f"{protocol.upper()} listener inventory"
    for name, family6 in ((protocol, False), (protocol + "6", True)):
        path = Path("/proc/net") / name
        if not path.exists():
            continue  # IPv6 disabled: no table, nothing listening on it
        try:
            lines = path.read_text().splitlines()[1:]
        except OSError as exc:
            errors.append(f"{label} failed ({type(exc).__name__})")
            continue
        for line in lines:
            fields = line.split()
            if len(fields) < 4 or fields[3] != KERNEL_SOCKET_STATES[state]:
                continue
            try:
                address, port = fields[1].rsplit(":", 1)
                host = _hex_ipv6(address) if family6 else _hex_ipv4(address)
                number = int(port, 16)
            except ValueError:
                errors.append(f"{label} contains unparsed rows; coverage incomplete")
                continue
            if protocol == "udp" and number == 0:
                continue
            if len(rows) >= room:
                errors.append(f"{label} truncated at the combined listener limit")
                return rows
            rows.append(Listener(protocol=protocol, address=host, port=number))
    return rows


def _linux_listeners(errors: list[str]) -> list[Listener]:
    """Collect both transports without relying on a nonportable ss JSON flag.

    Separate queries keep a failed UDP inventory from erasing valid TCP evidence
    (or vice versa). Any failure, unexpected row, stderr diagnostic or clipping
    is a coverage error, so partial evidence cannot authorize a port choice.
    Process names are intentionally not requested: they are not needed for port
    conflicts and may be unavailable to an unprivileged collector.
    """
    listeners: list[Listener] = []
    for protocol, option, state in (("tcp", "-lnt", "LISTEN"),
                                    ("udp", "-lnu", "UNCONN")):
        label = f"{protocol.upper()} listener inventory"
        try:
            result = _run(["ss", "-H", option], timeout=15)
        except FileNotFoundError:
            # Minimal and container images often lack iproute2. The kernel's
            # own socket tables are the same evidence ss reads.
            listeners.extend(_kernel_listeners(protocol, state, errors, MAX_LINUX_LISTENERS - len(listeners)))
            continue
        except (OSError, subprocess.SubprocessError) as exc:
            errors.append(f"{label} failed ({type(exc).__name__})")
            continue
        if result.returncode != 0:
            errors.append(f"{label} unavailable")
            continue
        if result.stderr.strip():
            errors.append(f"{label} reported diagnostics; coverage incomplete")
        invalid = clipped = False
        for line in result.stdout.splitlines():
            if not line.strip():
                continue
            parts = line.split()
            # Most ss versions omit Netid for a single-transport query; tolerate
            # its explicit form as well, but never infer a different protocol.
            if parts and parts[0] in {"tcp", "tcp6", "udp", "udp6"}:
                if parts.pop(0).removesuffix("6") != protocol:
                    invalid = True
                    continue
            if (len(parts) != 5 or parts[0] != state
                    or not parts[1].isascii() or not parts[1].isdigit()
                    or not parts[2].isascii() or not parts[2].isdigit()):
                invalid = True
                continue
            try:
                address, port_text = parts[3].rsplit(":", 1)
                if not address or not port_text.isascii() or not port_text.isdigit():
                    raise ValueError("nonnumeric listener endpoint")
                port = int(port_text)
                if not 1 <= port <= 65535:
                    raise ValueError("listener port out of range")
                if address.startswith("[") and address.endswith("]"):
                    address = address[1:-1]
            except ValueError:
                invalid = True
                continue
            if len(listeners) < MAX_LINUX_LISTENERS:
                listeners.append(Listener(protocol=protocol, address=address, port=port))
            else:
                clipped = True
        if invalid:
            errors.append(f"{label} contains unparsed rows; coverage incomplete")
        if clipped:
            errors.append(f"{label} truncated at the combined listener limit")
    return listeners


def _windows_topology(errors: list[str]) -> tuple[list[Route], list[Neighbor], list[Listener]]:
    # Reuse one PowerShell host and its network module for the related queries.
    # Each section retains an explicit error so a partial batch cannot look fresh
    # and complete merely because the enclosing process exited successfully.
    script = WINDOWS_QUERIES["TOPOLOGY"]
    try:
        batch = _windows_json(script)
        if len(batch) != 1 or not isinstance(batch[0], dict):
            raise ValueError("incomplete topology batch")
        state = batch[0]
        sections = {"Routes", "Neighbors", "Listeners"}
        if state.get("Schema") != 1 or not sections.issubset(state):
            raise ValueError("incomplete topology sections")
        failures = state.get("Errors")
        if (
            not isinstance(failures, dict)
            or not set(failures).issubset(sections)
            or any(not isinstance(value, str) or not value for value in failures.values())
        ):
            raise ValueError("invalid topology error records")
    except Exception as exc:
        errors.append(f"Windows topology inventory failed: {exc}")
        return [], [], []

    def rows_for(section: str) -> list[dict[str, Any]]:
        if section in failures:
            raise RuntimeError(failures[section])
        rows = state[section]
        if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
            raise ValueError(f"incomplete topology section: {section}")
        return rows

    try:
        routes = [
            Route(
                destination=str(row.get("DestinationPrefix", "")),
                gateway=str(row.get("NextHop", "")),
                interface=str(row.get("InterfaceAlias", "")),
                metric=int(row["RouteMetric"]) if row.get("RouteMetric") is not None else None,
            )
            for row in rows_for("Routes")
        ]
    except Exception as exc:
        errors.append(f"Windows route inventory failed: {exc}")
        routes = []
    try:
        neighbors = [
            Neighbor(
                address=str(row.get("IPAddress", "")),
                hardware_address=str(row.get("LinkLayerAddress", "")),
                interface=str(row.get("InterfaceAlias", "")),
                state=str(row.get("State", "unknown")),
            )
            for row in rows_for("Neighbors")
        ]
    except Exception as exc:
        errors.append(f"Windows neighbor inventory failed: {exc}")
        neighbors = []
    try:
        listeners = [
            Listener(
                protocol="tcp",
                address=str(row.get("LocalAddress", "")),
                port=int(row.get("LocalPort", 0)),
                process=str(row.get("OwningProcess", "")),
            )
            for row in rows_for("Listeners")
            if row.get("LocalPort")
        ]
    except Exception as exc:
        errors.append(f"Windows listener inventory failed: {exc}")
        listeners = []
    return routes, neighbors, listeners


def _linux_processes(errors: list[str]) -> list[ProcessObservation]:
    observations: list[ProcessObservation] = []
    proc = Path("/proc")
    try:
        from .process_identity import _linux_namespace_depth, _linux_proc_path
        namespace_depth = _linux_namespace_depth()
        entries = sorted((item for item in proc.iterdir() if item.name.isdigit()), key=lambda item: int(item.name))
    except OSError as exc:
        errors.append(f"process inventory unavailable: {exc}")
        return []
    if len(entries) > 4096:
        errors.append("Linux process inventory exceeded its 4096-entry limit; coverage is incomplete")
    visible_ids: dict[int, int] = {}
    for entry in entries[:4096]:
        try:
            values: dict[str, str] = {}
            for line in (entry / "status").read_text(encoding="utf-8", errors="replace").splitlines():
                if ":" in line:
                    key, value = line.split(":", 1)
                    values[key] = value.strip()
            process_id = int(entry.name)
            if namespace_depth > 1:
                identifiers = values.get("NSpid", "").split()
                if len(identifiers) < namespace_depth:
                    continue
                local_pid = int(identifiers[namespace_depth - 1])
                # pidfd resolution rejects a sibling with the same local PID.
                if _linux_proc_path(local_pid) != entry:
                    continue
                visible_ids[process_id] = local_pid
                process_id = local_pid
            fields = values.get("Uid", "").split()
            if len(fields) != 4 or any(not x.isdecimal() for x in fields):
                errors.append("Linux process UID evidence is incomplete")
                continue
            uids = [int(x) for x in fields]
            if any(x > 4294967295 for x in uids):
                errors.append("Linux process UID evidence is invalid")
                continue
            uid, effective_uid, saved_uid, filesystem_uid = uids
            capabilities = values.get("CapEff")
            if capabilities is not None and not re.fullmatch(r"[0-9A-Fa-f]{1,16}", capabilities):
                errors.append("Linux process capability evidence is invalid")
                capabilities = None
            username = str(uid)
            if pwd is not None:
                try:
                    username = pwd.getpwuid(uid).pw_name
                except KeyError:
                    pass
            try:
                executable = os.readlink(entry / "exe")
            except OSError:
                executable = ""
            observations.append(
                ProcessObservation(
                    name=values.get("Name", entry.name),
                    path=executable,
                    username=username,
                    process_id=process_id,
                    parent_id=int(values.get("PPid", "0")),
                    # Conservative observation: current or retained root identity,
                    # or any effective Linux capability. Not a namespace/access-policy evaluator.
                    privileged=0 in uids or (capabilities is not None and int(capabilities, 16) != 0),
                    real_uid=uid, effective_uid=effective_uid, saved_uid=saved_uid,
                    filesystem_uid=filesystem_uid, effective_capabilities=capabilities,
                )
            )
        except (OSError, ValueError, IndexError):
            continue
    if namespace_depth > 1:
        for observation in observations:
            observation.parent_id = visible_ids.get(observation.parent_id, 0)
    return observations


def _windows_processes(errors: list[str]) -> list[ProcessObservation]:
    script = WINDOWS_QUERIES["PROCESSES"]
    try:
        rows = _windows_json(script)
        if len(rows) > 4096:
            errors.append("Windows process inventory exceeded its 4096-entry limit; coverage is incomplete")
        return [
            ProcessObservation(
                name=str(item.get("Name", "unknown")),
                path=str(item.get("ExecutablePath") or ""),
                username=str(item.get("UserName") or "unknown"),
                process_id=int(item.get("ProcessId", 0)),
                parent_id=int(item.get("ParentProcessId", 0)),
                privileged=bool(item.get("Privileged", False)),
            )
            for item in rows[:4096]
            if int(item.get("ProcessId", 0)) > 0
        ]
    except Exception as exc:
        errors.append(f"Windows process inventory failed: {exc}")
        return []


def _file_persistence(path: Path, kind: str, owner: str = "unknown") -> PersistenceItem | None:
    try:
        # Hash links themselves. A startup alias must not redirect a bounded
        # inventory read to an arbitrary file/device controlled by an attacker.
        if path.is_symlink():
            return PersistenceItem(kind=kind + "-link", name=str(path), owner=owner,
                                   sha256=hashlib.sha256(os.readlink(path).encode()).hexdigest())
        from .restoration import RestorePointStore
        from .payload_inventory import _distribution_alias, _alias_unchanged
        native_path, alias = _distribution_alias(path)
        data, metadata = RestorePointStore._read_target(native_path)
        if alias and not _alias_unchanged(alias):
            raise ValueError('startup directory alias changed during inventory')
        digest = hashlib.sha256(data).hexdigest()
        if pwd is not None:
            try:
                owner = pwd.getpwuid(metadata['uid']).pw_name
            except KeyError:
                pass
        return PersistenceItem(kind=kind, name=str(path), owner=owner, sha256=digest)
    except (OSError, ValueError):
        return None


def _linux_persistence(errors: list[str]) -> list[PersistenceItem]:
    items: list[PersistenceItem] = []
    # Default configuration aliases are captured through their canonical files.
    # Retain the link identity independently so retargeting remains observable.
    for path in _linux_default_integrity_paths():
        try:
            if path.is_symlink():
                item = _file_persistence(path, "protected-config")
                if item:
                    items.append(item)
                else:
                    errors.append("persistence inventory could not safely read a configuration alias")
        except OSError:
            errors.append("persistence inventory could not inspect a configuration alias")
    for fixed in (Path("/etc/crontab"), Path("/etc/rc.local"), Path("/etc/profile"),
                  Path("/etc/bash.bashrc"), Path("/etc/ld.so.preload")):
        item = _file_persistence(fixed, "startup-file") if fixed.is_file() else None
        if item:
            items.append(item)
    for directory, kind in (
        (Path("/etc/cron.d"), "cron"),
        (Path("/etc/cron.hourly"), "cron"),
        (Path("/etc/cron.daily"), "cron"),
        (Path("/etc/cron.weekly"), "cron"),
        (Path("/etc/cron.monthly"), "cron"),
        (Path("/etc/profile.d"), "shell-startup"),
        (Path("/etc/pam.d"), "authentication-config"),
        (Path("/etc/sudoers.d"), "sudoers"),
        (Path("/etc/ssh/sshd_config.d"), "ssh-config"),
        (Path("/var/spool/cron"), "user-cron"),
        (Path("/var/spool/cron/crontabs"), "user-cron"),
        (Path("/etc/systemd/system"), "systemd-file"),
        (Path("/usr/lib/systemd/system"), "systemd-file"),
        (Path("/lib/systemd/system"), "systemd-file"),
    ):
        try:
            candidates = directory.rglob("*") if kind == "systemd-file" else directory.iterdir()
            from heapq import nsmallest
            # Keep the deterministic first entries without retaining the entire
            # enumeration in memory; one extra entry proves overflow.
            candidates = nsmallest(1025, candidates)
            if len(candidates) > 1024:
                errors.append("Linux persistence source exceeded its 1024-entry limit; coverage is incomplete: " + str(directory))
            for path in candidates[:1024]:
                # A masked service points to /dev/null, and a broken alias may
                # be an important later edit. Hash the link itself even when
                # its destination is not a regular file.
                present = path.is_symlink() or path.is_file()
                item = _file_persistence(path, kind) if present else None
                if item:
                    items.append(item)
                elif present:
                    errors.append("persistence inventory could not safely read a startup entry")
        except FileNotFoundError:
            continue
        except OSError:
            errors.append("Linux persistence directory inventory unavailable; coverage is incomplete")
    if pwd is not None:
        # Service-account UIDs are not a trust boundary. An attacker can place
        # authorized keys or shell startup files under those homes too.
        users = list(pwd.getpwall())
        if len(users) > 256:
            errors.append("persistence user inventory exceeded 256 accounts")
        for user in users[:256]:
            home_path = Path(user.pw_dir)
            if not home_path.is_absolute():
                continue
            for suffix, kind in ((".ssh/authorized_keys", "authorized-keys"), (".profile", "shell-startup"),
                                 (".bashrc", "shell-startup"), (".bash_profile", "shell-startup"),
                                 (".zshrc", "shell-startup")):
                path = home_path / suffix
                try:
                    present = path.is_file()
                except OSError:
                    errors.append("persistence inventory could not inspect a user startup path")
                    continue
                if present:
                    item = _file_persistence(path, kind, user.pw_name)
                    if item:
                        items.append(item)
                    else:
                        errors.append("persistence inventory could not safely read a user startup entry")
    try:
        result = _run(
            [
                "systemctl",
                "list-unit-files",
                "--state=enabled",
                "--type=service",
                "--type=timer",
                "--no-legend",
                "--no-pager",
            ],
            timeout=15,
        )
        if result.returncode == 0:
            lines = result.stdout.splitlines()
            if len(lines) > 2048:
                errors.append("Linux persistence unit inventory exceeded its 2048-entry limit; coverage is incomplete")
            for line in lines[:2048]:
                fields = line.split()
                if fields:
                    items.append(
                        PersistenceItem(
                            kind="systemd-unit",
                            name=fields[0],
                            owner="root",
                            enabled=True,
                        )
                    )
        else:
            errors.append("Linux persistence unit inventory unavailable; coverage is incomplete")
    except (OSError, subprocess.SubprocessError):
        errors.append("Linux persistence unit inventory unavailable; coverage is incomplete")
    from .payload_inventory import linux_startup_payloads, linux_process_payloads
    items.extend(linux_startup_payloads(items, errors))
    items.extend(linux_process_payloads(errors))
    if len(items) > 4096:
        errors.append("persistence inventory exceeded its 4096-entry bound")
    return items[:4096]


def _windows_persistence(errors: list[str]) -> list[PersistenceItem]:
    script = WINDOWS_QUERIES["PERSISTENCE"]
    try:
        native = _windows_json(script)
        items = [
            PersistenceItem(
                kind=str(item.get("Kind", "scheduled-task")),
                name=str(item.get("Name", "unknown")),
                owner=str(item.get("Owner") or "unknown"),
                enabled=bool(item.get("Enabled", True)),
                sha256=str(item.get("SHA256") or ""),
            )
            for item in native if item.get('Kind') not in {'process-reference','startup-folder'}
        ]
        from .payload_inventory import fingerprint_references, windows_startup_payload_paths
        folders = [row for row in native if row.get('Kind') == 'startup-folder']
        if folders:
            from .windows_startup import startup_folder_inventory
            items.extend(startup_folder_inventory(folders, errors))
        references = [path for row in native if row.get('Kind') != 'process-reference'
                      for command in row.get('References', [])
                      for path in windows_startup_payload_paths(str(command))]
        items.extend(fingerprint_references(references, errors))
        process_rows = [row for row in native if row.get('Kind') == 'process-reference']
        if len(process_rows) > 4096:
            errors.append('Windows process payload inventory exceeded its process bound')
        running = [path for row in process_rows[:4096]
                   for command in row.get('References', [])
                   for path in windows_startup_payload_paths(str(command))]
        items.extend(fingerprint_references(running, errors, kind='process-payload', max_files=128, seconds=3.0))
        if len(items) > 4096:
            errors.append('Windows persistence inventory exceeded its entry bound')
        return items[:4096]
    except Exception as exc:
        errors.append(f"Windows persistence inventory failed: {exc}")
        return []


def _stable_firewall_digest(output: str) -> str:
    normalized = re.sub(
        r"\bcounter\s+packets\s+\d+\s+bytes\s+\d+\b",
        "counter packets * bytes *",
        output,
        flags=re.IGNORECASE,
    )
    return hashlib.sha256(normalized.encode()).hexdigest()


# Filesystems a scored service normally depends on. Each is probed only if it
# exists; duplicates that resolve to the same device are reported once.
CAPACITY_PATHS = ("/", "/var", "/var/log", "/var/lib", "/tmp", "/srv", "/home", "/boot")
MAX_CAPACITY_FILESYSTEMS = 16


def _linux_capacity(errors: list[str]) -> tuple[list[FilesystemCapacity], MemoryCapacity]:
    """Observe free space, free inodes and memory headroom.

    Read-only and never fatal: a host that will not answer for one mount point
    still reports the others. Nothing here is derived from command output.
    """
    filesystems: list[FilesystemCapacity] = []
    devices: set[int] = set()
    for name in CAPACITY_PATHS:
        path = Path(name)
        try:
            if not path.is_dir():
                continue
            device = os.stat(path).st_dev
            if device in devices:
                continue
            stats = os.statvfs(path)
        except OSError:
            continue
        devices.add(device)
        # f_bavail is the space an unprivileged process may actually use; f_bfree
        # includes the root reserve and would overstate the real headroom.
        filesystems.append(
            FilesystemCapacity(
                mount_point=name,
                device=f"{os.major(device)}:{os.minor(device)}",
                total_bytes=stats.f_frsize * stats.f_blocks,
                free_bytes=stats.f_frsize * stats.f_bavail,
                total_inodes=stats.f_files,
                free_inodes=stats.f_favail,
                read_only=bool(stats.f_flag & os.ST_RDONLY),
            )
        )
        if len(filesystems) >= MAX_CAPACITY_FILESYSTEMS:
            break
    if not filesystems:
        errors.append("filesystem capacity is unavailable")
    memory = MemoryCapacity()
    try:
        wanted = {"MemTotal": 0, "MemAvailable": 0, "SwapTotal": 0, "SwapFree": 0}
        with Path("/proc/meminfo").open("r", encoding="utf-8", errors="replace") as handle:
            for index, line in enumerate(handle):
                if index > 128:
                    break
                key, _, rest = line.partition(":")
                if key in wanted:
                    value = rest.strip().split()
                    # Every documented /proc/meminfo size is reported in kB.
                    if len(value) == 2 and value[0].isdigit() and value[1] == "kB":
                        wanted[key] = int(value[0]) * 1024
        memory = MemoryCapacity(
            total_bytes=wanted["MemTotal"], available_bytes=wanted["MemAvailable"],
            swap_total_bytes=wanted["SwapTotal"], swap_free_bytes=wanted["SwapFree"],
        )
        if not memory.total_bytes:
            errors.append("host memory capacity is unavailable")
    except (OSError, ValueError):
        errors.append("host memory capacity is unavailable")
    return filesystems, memory


# nftables 1.0.7+ prints this to stderr for every table iptables-nft owns, which
# is any table ufw, Docker or an ordinary `iptables -A ... -m state` rule made.
# It is a courtesy note, not a failed query: the table is still listed, rules and
# all, on stdout. Treating it as a diagnostic made every such host report
# incomplete collection, which blocks baseline approval and holds all recovery.
IPTABLES_NFT_NOTICE = re.compile(
    r"# Warning: table (ip|ip6|inet|arp|bridge|netdev) ([A-Za-z0-9_.-]{1,64}) "
    r"is managed by iptables-nft, do not touch!")


def _only_iptables_nft_notices(stderr: str, stdout: str) -> bool:
    """True when every stderr line names an iptables-nft table that stdout lists."""
    lines = [line.strip() for line in stderr.splitlines() if line.strip()]
    if not lines or len(lines) > 64:
        return False
    for line in lines:
        match = IPTABLES_NFT_NOTICE.fullmatch(line)
        if match is None or not re.search(
                r"(?m)^table " + re.escape(match[1]) + " " + re.escape(match[2]) + r" \{$", stdout):
            return False
    return True


def _linux_firewall(errors: list[str]) -> FirewallState:
    failures: list[str] = []
    for provider, command in (
        ("nftables", ["nft", "list", "ruleset"]),
        ("iptables", ["iptables-save"]),
        ("ufw", ["ufw", "status"]),
    ):
        try:
            result = _run(command, timeout=15)
        except FileNotFoundError:
            continue  # An optional provider may not be installed.
        except (OSError, subprocess.SubprocessError) as exc:
            failures.append(f"{provider} firewall query unavailable ({type(exc).__name__})")
            continue
        if result.returncode != 0:
            failures.append(f"{provider} firewall query failed; coverage is incomplete")
            continue
        if result.stderr.strip() and not (
                provider == "nftables" and _only_iptables_nft_notices(result.stderr, result.stdout)):
            failures.append(f"{provider} firewall query has diagnostics; coverage is incomplete")
            continue  # A warned/partial ruleset is not complete firewall evidence.
        output = result.stdout.strip()
        if provider == "ufw":
            status = output.splitlines()[0].strip().casefold() if output else ""
            if status not in {"status: active", "status: inactive"}:
                failures.append("ufw firewall status is malformed; coverage is incomplete")
                continue
            enabled = status == "status: active"
        else:
            enabled = bool(output)
        errors.extend(failures)
        # A failed higher-priority query cannot be disproved by an empty fallback.
        # An observed nonempty provider still establishes the presence of rules.
        if failures and not enabled:
            return FirewallState(enabled=None, provider=provider,
                detail="fallback has no active rules; another provider is unverified")
        return FirewallState(enabled=enabled, provider=provider,
            rules_sha256=_stable_firewall_digest(output),
            detail="rules present" if enabled else "no active rules detected")
    errors.extend(failures)
    errors.append("Linux firewall inventory unavailable; state is unknown")
    return FirewallState(enabled=None, detail="firewall inventory unavailable")


def _windows_firewall(errors: list[str]) -> FirewallState:
    script = WINDOWS_QUERIES["FIREWALL"]
    try:
        rows = _windows_json(script, timeout=60.0)
        if len(rows) != 1 or not isinstance(rows[0], dict):
            raise ValueError("incomplete firewall inventory")
        state = rows[0]
        filters = state.get("Filters")
        expected_filters = {"Address", "Port", "Application", "Service", "Interface", "InterfaceType", "Security"}
        if state.get("Schema") != 2 or not isinstance(filters, dict) or set(filters) != expected_filters:
            raise ValueError("incomplete firewall filter inventory")
        if not isinstance(state.get("Rules"), list) or any(not isinstance(value, list) for value in filters.values()):
            raise ValueError("malformed firewall inventory")
        profiles = state.get("Profiles", [])
        if not isinstance(profiles, list) or not profiles or any(not isinstance(item, dict) or not isinstance(item.get("Enabled"), bool) for item in profiles):
            raise ValueError("incomplete firewall profile inventory")
        encoded = json.dumps(_canonical_firewall_state(state), separators=(",", ":"), sort_keys=True)
        enabled = bool(profiles) and all(bool(item.get("Enabled")) for item in profiles)
        return FirewallState(
            enabled=enabled,
            provider="Windows Defender Firewall",
            rules_sha256=hashlib.sha256(encoded.encode()).hexdigest(),
            detail=", ".join(f"{item.get('Name')}={item.get('Enabled')}" for item in profiles),
        )
    except Exception as exc:
        errors.append(f"Windows firewall inventory failed: {exc}")
        return FirewallState(False, provider="Windows Defender Firewall", detail="inventory failed")


def _canonical_firewall_state(value: Any) -> Any:
    """NetSecurity inventories and condition arrays are unordered sets."""
    if isinstance(value, dict):
        return {key: _canonical_firewall_state(item) for key, item in value.items()}
    if isinstance(value, list):
        normalized = [_canonical_firewall_state(item) for item in value]
        return sorted(normalized, key=lambda item: json.dumps(item, separators=(",", ":"), sort_keys=True))
    return value


def _boot_id(system: str) -> str:
    if system != "windows":
        try:
            return Path("/proc/sys/kernel/random/boot_id").read_text(encoding="utf-8").strip()
        except OSError:
            return "unknown"
    try:
        rows = _windows_json(WINDOWS_QUERIES["BOOT"])
        return str(rows[0].get("LastBootUpTime", "unknown")) if rows else "unknown"
    except Exception:
        return "unknown"


def _clean_event_text(value: Any, limit: int = 512) -> str:
    return " ".join(str(value).split())[:limit]


def _linux_security_events(errors: list[str]) -> list[SecurityEvent]:
    try:
        result = _run(
            [
                "journalctl",
                "--since=-5 minutes",
                "--output=json",
                "--no-pager",
                "--lines=512",
            ],
            timeout=20,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        errors.append('Linux security-event journal read failed: '+type(exc).__name__)
        from .activity_evidence import capture_audit
        capture_audit([], source='linux-journal', available=False, error_type=type(exc).__name__)
        return []
    if result.returncode != 0:
        errors.append('Linux security-event journal read failed with nonzero exit status')
        from .activity_evidence import capture_audit
        capture_audit([], source='linux-journal', available=False, error_type='JournalReadFailed')
        return []
    patterns = (
        ("account_created", "success", re.compile(r"(?:new user|useradd).*?name[= :]([A-Za-z0-9_.@-]+)", re.I)),
        ("account_deleted", "success", re.compile(r"(?:delete user|userdel).*?([A-Za-z0-9_.@-]+)", re.I)),
        ("privilege_change", "success", re.compile(r"(?:added|add).*?([A-Za-z0-9_.@-]+).*?(?:sudo|wheel|admin)", re.I)),
        ("privilege_change", "success", re.compile(r"(?:sudoers|visudo|gpasswd|usermod).*?([A-Za-z0-9_.@-]+)", re.I)),
        ("audit_policy_changed", "success", re.compile(r"(?:auditd|audit rules?).*?(?:changed|reloaded|stopped)", re.I)),
        ("auth_failure", "failure", re.compile(r"Failed password for (?:invalid user )?([^ ]+) from ([0-9A-Fa-f:.]+)", re.I)),
        ("auth_success", "success", re.compile(r"Accepted \S+ for ([^ ]+) from ([0-9A-Fa-f:.]+)", re.I)),
        ("audit_cleared", "success", re.compile(r"(?:audit log.*clear|logs? cleared)", re.I)),
    )
    events: list[SecurityEvent] = []
    audit_rows = []
    from .activity_evidence import linux_audit_row, capture_audit
    for line in result.stdout.splitlines()[-512:]:
        try:
            row = json.loads(line)
        except (json.JSONDecodeError, TypeError):
            continue
        if not isinstance(row, dict):
            continue
        native = linux_audit_row(row)
        if native:
            audit_rows.append(native)
        message = _clean_event_text(row.get("MESSAGE", ""))
        if not message:
            continue
        category = outcome = ""
        match: re.Match[str] | None = None
        for candidate_category, candidate_outcome, pattern in patterns:
            matched = pattern.search(message)
            if matched:
                category, outcome, match = candidate_category, candidate_outcome, matched
                break
        if not category:
            continue
        account = match.group(1) if match and match.lastindex else "unknown"
        remote = match.group(2) if match and (match.lastindex or 0) >= 2 else "unknown"
        raw_time = str(row.get("__REALTIME_TIMESTAMP", "0"))
        occurred = int(raw_time) / 1_000_000 if raw_time.isdigit() else time.time()
        stable = "|".join(
            (
                str(row.get("_BOOT_ID", "")),
                raw_time,
                str(row.get("SYSLOG_IDENTIFIER", "")),
                message,
            )
        )
        raw_uid = str(row.get("_UID", ""))
        actor = raw_uid or "unknown"
        if raw_uid.isdigit() and pwd is not None:
            try:
                actor = pwd.getpwuid(int(raw_uid)).pw_name
            except KeyError:
                pass
        events.append(
            SecurityEvent(
                event_id="linux-" + hashlib.sha256(stable.encode()).hexdigest()[:32],
                category=category,
                outcome=outcome,
                account=_clean_event_text(account, 128),
                actor=_clean_event_text(actor, 128),
                remote_address=_clean_event_text(remote, 256),
                occurred_at=occurred,
                detail=message,
            )
        )
    capture_audit(audit_rows + [dict(event_id=e.event_id, category=e.category, outcome=e.outcome,
        account=e.account, actor=e.actor, remote_address=e.remote_address, occurred_at=e.occurred_at)
        for e in events], source='linux-journal', queried=len(result.stdout.splitlines()), limit=512)
    return events[-256:]


def _windows_security_events(errors: list[str]) -> list[SecurityEvent]:
    from .windows_audit import logon_audit_policy
    try:
        policy = logon_audit_policy()
        if not policy['success'] or not policy['failure']:
            errors.append('Windows successful/failed logon auditing is disabled or incomplete')
    except (OSError,ValueError):
        errors.append('Windows logon audit policy could not be verified')
    from .activity_evidence import windows_policy_coverage
    windows_policy_coverage()
    script = WINDOWS_QUERIES["SECURITY_EVENTS"]
    try:
        native_events = _windows_json(script)
        from .activity_evidence import capture_windows
        capture_windows(native_events)
        # Enforce age against the native event timestamp in Python. Keep the
        # bounded native query independent of PowerShell DateTime conversion.
        now = time.time()
        native_events = [item for item in native_events
                         if now-300 <= float(item.get('OccurredAt',0) or 0) <= now+5]
        if len(native_events) > 256:
            errors.append('Windows security-event inventory exceeded its 256-event telemetry bound')
        return [
            SecurityEvent(
                event_id=_clean_event_text(item.get("EventId", "unknown"), 256),
                category=_clean_event_text(item.get("Category", "unknown"), 64),
                outcome=_clean_event_text(item.get("Outcome", "observed"), 64),
                account=_clean_event_text(item.get("Account") or "unknown", 128),
                account_id=_clean_event_text(item.get("AccountId") or "", 256),
                account_domain=_clean_event_text(item.get("AccountDomain") or "", 256),
                actor=_clean_event_text(item.get("Actor") or "unknown", 128),
                remote_address=_clean_event_text(item.get("RemoteAddress") or "unknown", 256),
                occurred_at=max(0.0, float(item.get("OccurredAt", 0) or 0)),
                detail=_clean_event_text(item.get("Detail", ""), 512),
            )
            for item in native_events
        ][:256]
    except Exception as exc:
        errors.append(f"Windows security-event inventory failed: {exc}")
        from .activity_evidence import capture_audit
        capture_audit([], source='windows-security', available=False, error_type=type(exc).__name__)
        return []


def _windows_inventory(errors: list[str], *, boot_id: str | None = None) -> tuple[
    list[Account],
    list[Session],
    list[Service],
    list[Route],
    list[Neighbor],
    list[Listener],
    list[ProcessObservation],
    list[PersistenceItem],
    FirewallState,
    list[Interface],
    list[SecurityEvent],
]:
    """Bound native helper contention and merge complete inventory errors in order."""
    deadline = _windows_deadline.get()
    if deadline is None:
        deadline = time.monotonic() + WINDOWS_INVENTORY_BUDGET_SECONDS
    jobs = (
        lambda local: _windows_services(local),
        lambda local: _windows_topology(local),
        lambda local: _windows_processes(local),
        lambda local: _windows_persistence(local),
        lambda local: _windows_firewall(local),
        lambda local: _windows_interfaces(local),
        lambda local: _windows_security_events(local),
    )
    query_cache = _windows_query_cache.get()

    def execute(job: Any) -> tuple[Any, list[str]]:
        local_errors: list[str] = []
        token = _windows_deadline.set(deadline)
        cache_token = _windows_query_cache.set(query_cache)
        try:
            return job(local_errors), local_errors
        finally:
            _windows_query_cache.reset(cache_token)
            _windows_deadline.reset(token)

    accounts, account_errors = execute(_windows_accounts)

    # On a single CPU, overlapping PowerShell/CIM helpers made otherwise valid
    # inventories time out and held recovery. Keep each query bounded without
    # dropping a collector or trusting its prior result as a fresh observation.
    workers = min(2, max(1, os.cpu_count() or 1))
    with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="sb-win-collect") as pool:
        results = list(pool.map(execute, jobs))
    # A session scan must not observe our short-lived inventory PowerShell
    # helpers after they exit. Its own PowerShell process is excluded by $PID;
    # every remaining session still needs the normal exact process identity.
    results.insert(1, execute(lambda local: _windows_sessions(accounts, local) if boot_id is None
                             else _windows_sessions(accounts, local, boot_id=boot_id)))
    errors.extend(account_errors)
    for _value, local_errors in results:
        errors.extend(local_errors)
    services, sessions, topology, processes, persistence, firewall, interfaces, events = (
        value for value, _local_errors in results
    )
    routes, neighbors, listeners = topology
    return (
        accounts,
        sessions,
        services,
        routes,
        neighbors,
        listeners,
        processes,
        persistence,
        firewall,
        interfaces,
        events,
    )


def _discover_integrity_paths(root: Path, pattern: str) -> list[Path]:
    """Expand fixed watch patterns without hiding directory access failures."""
    remaining = MAX_INTEGRITY_DISCOVERY_ENTRIES

    def walk(directory: Path, parts: list[str]):
        nonlocal remaining
        part, *tail = parts
        if not any(mark in part for mark in "*?["):
            target = directory / part
            if tail:
                yield from walk(target, tail)
            else:
                try:
                    target.lstat()
                except (FileNotFoundError, NotADirectoryError):
                    return
                yield target
            return
        try:
            entries = os.scandir(directory)
        except (FileNotFoundError, NotADirectoryError):
            return  # Optional application directories need not be installed.
        with entries:
            for entry in entries:
                remaining -= 1
                if remaining < 0:
                    raise ValueError("integrity discovery entry limit exceeded; coverage is incomplete")
                if fnmatch.fnmatchcase(entry.name, part):
                    target = directory / entry.name
                    if tail:
                        yield from walk(target, tail)
                    else:
                        yield target

    return sorted(walk(root, pattern.split("/")))


def _linux_default_integrity_paths() -> list[Path]:
    return [Path(path) for path in (
        "/etc/passwd", "/etc/group", "/etc/sudoers", "/etc/ssh/sshd_config",
        "/etc/crontab", "/etc/hosts", "/root/.ssh/authorized_keys",
        "/etc/nginx/nginx.conf", "/etc/apache2/apache2.conf",
        "/etc/httpd/conf/httpd.conf", "/etc/samba/smb.conf", "/etc/named.conf",
        "/etc/my.cnf", "/etc/mysql/my.cnf", "/etc/chrony.conf",
    )]


def _integrity_paths(
    system: str, extra_paths: list[str] | None = None, *, errors: list[str] | None = None
) -> list[Path]:
    # Watcher hints may use a bounded subset, but collection must explicitly
    # report every loss of coverage so it cannot authorize automatic repair.
    diagnostics = errors if errors is not None else []
    protected: list[Path] = []
    for raw in extra_paths or []:
        if not isinstance(raw, str) or "\x00" in raw or not Path(raw).is_absolute():
            diagnostics.append("integrity protected path must be an absolute path without NUL")
            continue
        protected.append(Path(raw))
    if system == "windows":
        windows = Path(os.environ.get("WINDIR", r"C:\Windows"))
        user_profile = Path(os.environ.get("USERPROFILE", str(Path.home())))
        program_data = Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData"))
        candidates = [
            windows / "System32/drivers/etc/hosts",
            windows / "System32/inetsrv/config/applicationHost.config",
            program_data / "ssh/sshd_config",
            program_data / "ssh/administrators_authorized_keys",
            user_profile / "Documents/WindowsPowerShell/profile.ps1",
            user_profile / ".ssh/authorized_keys",
        ]
    else:
        candidates = []
        for path in _linux_default_integrity_paths():
            # A distribution may install defaults such as mysql/my.cnf through
            # alternatives. Only automatic hints resolve aliases: explicitly
            # approved protected paths keep their exact original authority.
            if path.is_symlink():
                try:
                    path = path.resolve(strict=True)
                except (OSError, RuntimeError):
                    pass  # Collection reports the unresolved target normally.
            candidates.append(path)
        for root, pattern in (
            (Path("/etc/postgresql"), "*/main/postgresql.conf"),
            (Path("/etc/postgresql"), "*/main/pg_hba.conf"),
            (Path("/etc/systemd/system"), "*.service"),
            (Path("/etc/sudoers.d"), "*"),
            (Path("/var/named"), "*.zone"),
        ):
            try:
                for discovered in _discover_integrity_paths(root, pattern):
                    # Installed service aliases are not writable restore targets.
                    # Monitor/capture the canonical file; the alias remains in
                    # persistence telemetry. A new destination is a new path
                    # requiring manifest and baseline review. Explicit protected
                    # paths are never silently redirected by this discovery step.
                    if root == Path("/etc/systemd/system") and discovered.is_symlink():
                        try:
                            discovered = discovered.resolve(strict=True)
                            # systemd represents a mask with a link to /dev/null.
                            # The link remains in persistence telemetry, but the
                            # device is not configuration to capture or restore.
                            # Explicit protected paths still fail closed below.
                            if discovered == Path("/dev/null"):
                                continue
                        except (OSError, RuntimeError):
                            pass
                    candidates.append(discovered)
            except (OSError, ValueError) as exc:
                diagnostics.append(f"integrity path discovery failed for {root}: {exc}")
    unique: list[Path] = []
    seen: set[str] = set()
    for path in [*protected, *candidates]:
        # Windows directories can opt into case-sensitive names. Without
        # filesystem identity evidence, case variants remain distinct targets.
        normalized = str(path)
        if normalized not in seen:
            if len(unique) >= MAX_INTEGRITY_PATHS:
                diagnostics.append(
                    f"integrity path limit of {MAX_INTEGRITY_PATHS} exceeded; coverage is incomplete"
                )
                break
            seen.add(normalized)
            unique.append(path)
    return unique


def integrity_watch_paths(extra_paths: list[str] | None = None) -> list[str]:
    """Return bounded watcher hints; collection reports any missing coverage."""
    system = platform.system().casefold()
    return [str(path) for path in _integrity_paths(system, extra_paths)]


class _IntegrityBudget:
    """One cycle's read allowance, including bytes from rejected snapshots."""

    def __init__(self, system: str = "linux") -> None:
        windows = system == "windows"
        self.label = "Windows" if windows else "POSIX"
        self.deadline = time.monotonic() + (
            WINDOWS_INTEGRITY_BUDGET_SECONDS if windows else POSIX_INTEGRITY_BUDGET_SECONDS
        )
        self.remaining_bytes = (
            MAX_WINDOWS_INTEGRITY_TOTAL_BYTES if windows else MAX_POSIX_INTEGRITY_TOTAL_BYTES
        )

    def check(self) -> None:
        if time.monotonic() >= self.deadline:
            raise TimeoutError(f"{self.label} integrity collection time budget exhausted")

    def consume(self, count: int) -> None:
        self.remaining_bytes -= count
        if self.remaining_bytes < 0:
            raise ValueError(f"{self.label} integrity collection byte budget exhausted")
        self.check()


def _file_snapshot_identity(value: os.stat_result) -> tuple[int, ...]:
    # Access time changes on normal reads and is deliberately excluded.
    return (value.st_dev, value.st_ino, value.st_mode, value.st_uid, value.st_gid,
            value.st_size, value.st_mtime_ns, value.st_ctime_ns)


def _posix_integrity_item(path: Path, budget: _IntegrityBudget) -> IntegrityItem | None:
    """Hash a bounded regular-file snapshot; reject concurrent changes.

    Deadlines are checked between operations. A blocked filesystem call still
    depends on the OS. Existing monitored symlink paths remain supported, with
    the final pathname required to identify the same snapshot as the open file.
    """
    budget.check()
    flags = os.O_RDONLY | getattr(os, "O_NONBLOCK", 0) | getattr(os, "O_CLOEXEC", 0)
    try:
        descriptor = os.open(path, flags)
    except FileNotFoundError:
        return None
    try:
        before = os.fstat(descriptor)
        if not stat.S_ISREG(before.st_mode):
            raise ValueError("integrity target is not a regular file")
        if before.st_size > MAX_POSIX_INTEGRITY_FILE_BYTES:
            raise ValueError("integrity file exceeds the per-file byte limit")
        # Leave room for one bounded EOF check. This also rejects pseudo-files
        # whose reported size does not describe their readable contents.
        if before.st_size >= budget.remaining_bytes:
            raise ValueError("POSIX integrity collection byte budget exhausted")
        digest = hashlib.sha256()
        received = 0
        while received <= before.st_size:
            budget.check()
            chunk = os.read(descriptor, min(131072, before.st_size + 1 - received))
            budget.consume(len(chunk))
            if not chunk:
                break
            received += len(chunk)
            if received > before.st_size:
                raise ValueError("integrity file changed while being read or reports an unsupported size")
            digest.update(chunk)
        if received != before.st_size:
            raise ValueError("integrity file changed while being read")
        attrs = capture_xattrs(descriptor, budget)
        security = security_digest({'mode': stat.S_IMODE(before.st_mode),
                                    'uid': before.st_uid, 'gid': before.st_gid, 'xattrs': attrs})
        if attrs != capture_xattrs(descriptor, budget):
            raise ValueError("integrity security metadata changed while being read")
        after = os.fstat(descriptor)
        named = path.stat()
        budget.check()
        identity = _file_snapshot_identity(before)
        if identity != _file_snapshot_identity(after) or identity != _file_snapshot_identity(named):
            raise ValueError("integrity file changed while being read")
        return IntegrityItem(path=str(path), sha256=digest.hexdigest(),
                             size=received, modified_at=float(after.st_mtime),
                             security_descriptor_sha256=security)
    finally:
        os.close(descriptor)


def _integrity(
    system: str, errors: list[str], extra_paths: list[str] | None = None
) -> list[IntegrityItem]:
    items: list[IntegrityItem] = []
    budget = _IntegrityBudget(system)
    for path in _integrity_paths(system, extra_paths, errors=errors):
        try:
            budget.check()
            if system != "windows":
                item = _posix_integrity_item(path, budget)
                if item is not None:
                    items.append(item)
                continue
            digest = hashlib.sha256()
            security_descriptor_sha256 = ""
            if system == "windows":
                from .restoration import _windows_read_file_snapshot_if_present

                if budget.remaining_bytes <= 0:
                    raise ValueError("Windows integrity collection byte budget exhausted")
                result = _windows_read_file_snapshot_if_present(
                    path,
                    min(MAX_WINDOWS_INTEGRITY_FILE_BYTES, budget.remaining_bytes - 1),
                    allow_security_failure=True,
                    read_budget=budget,
                )
                budget.check()
                if result is None:
                    continue
                data, snapshot = result
                digest.update(data)
                size = int(snapshot["size"])
                modified_at = float(snapshot["modified_at"])
                security_descriptor = snapshot.get("windows_security_descriptor")
                if isinstance(security_descriptor, str) and security_descriptor:
                    security_descriptor_sha256 = hashlib.sha256(
                        security_descriptor.encode("utf-8")
                    ).hexdigest()
                security_error = str(snapshot.get("security_descriptor_error") or "")
                if security_error:
                    errors.append(
                        f"integrity security metadata read failed for {path}: {security_error}"
                    )
            budget.check()
            items.append(
                IntegrityItem(
                    path=str(path),
                    sha256=digest.hexdigest(),
                    size=size,
                    modified_at=modified_at,
                    security_descriptor_sha256=security_descriptor_sha256,
                )
            )
        except (OSError, ValueError) as exc:
            errors.append(f"integrity read failed for {path}: {exc}")
            if time.monotonic() >= budget.deadline or budget.remaining_bytes <= 0:
                break
    return items


_LinuxResult = TypeVar('_LinuxResult')


def _linux_section(label: str, errors: list[str], query: Callable[[], _LinuxResult],
                   unavailable: _LinuxResult) -> _LinuxResult:
    """Keep other sections running, with missing evidence explicitly untrusted."""
    try:
        return query()
    except (OSError, subprocess.SubprocessError) as exc:
        # Command arguments and output can contain secrets or untrusted text.
        errors.append(f"Linux {label} inventory unavailable ({type(exc).__name__}); coverage incomplete")
        return unavailable


def collect(
    agent_id: str,
    probe_specs: list[dict[str, Any]] | None = None,
    authorized_networks: list[str] | None = None,
    integrity_paths: list[str] | None = None,
    authorized_hosts: list[str] | tuple[str, ...] | None = None,
    excluded_hosts: list[str] | tuple[str, ...] | None = None,
) -> Telemetry:
    # Date the oldest part of this observation. Dating completion instead would
    # let a slow inventory refresh the apparent age of already-stale evidence.
    observed_at = time.time()
    started = time.monotonic()
    errors: list[str] = []
    system = platform.system().casefold()
    if system == "windows":
        with _windows_inventory_budget(), _windows_query_snapshot():
            boot_id = _boot_id(system)
            if boot_id == "unknown":
                errors.append("Windows boot identity is unavailable")
            (
                accounts,
                sessions,
                services,
                routes,
                neighbors,
                listeners,
                processes,
                persistence,
                firewall,
                interfaces,
                security_events,
            ) = _windows_inventory(errors, boot_id=boot_id)
        # Windows capacity collection is not implemented yet; absent capacity is
        # reported as unknown rather than as healthy headroom.
        filesystems, memory = [], MemoryCapacity()
    else:
        accounts = _linux_section('account', errors, lambda: _linux_accounts(errors), [])
        privileged = {item.name.casefold() for item in accounts if item.privileged}
        sessions = _linux_section('session', errors, lambda: _linux_sessions(privileged, errors), [])
        services = _linux_section('service', errors, lambda: _linux_services(errors), [])
        # Firewall, route, neighbor and interface gaps are recorded as network
        # inventory issues: reported, but never a hold on service recovery.
        network: list[str] = []
        routes, neighbors, listeners = _linux_section('topology', errors, lambda: _linux_topology(errors, network),
                                                      ([], [], []))
        processes = _linux_section('process', errors, lambda: _linux_processes(errors), [])
        persistence = _linux_section('persistence', errors, lambda: _linux_persistence(errors), [])
        firewall = _linux_section('firewall', network, lambda: _linux_firewall(network), FirewallState(enabled=None))
        interfaces = _linux_section('interface', network, lambda: _linux_interfaces(network), [])
        from .telemetry_diagnostics import NetworkInventoryIssue
        errors.extend(NetworkInventoryIssue(item) for item in network)
        security_events = _linux_section('security event', errors, lambda: _linux_security_events(errors), [])
        filesystems, memory = _linux_section('capacity', errors, lambda: _linux_capacity(errors), ([], MemoryCapacity()))
    probes = []
    if probe_specs:
        from .probes import run_probes

        probes = run_probes(
            probe_specs,
            authorized_networks or [],
            authorized_hosts=authorized_hosts,
            excluded_hosts=excluded_hosts,
        )
    integrity = _integrity(system, errors, integrity_paths)
    # Collector diagnostics can include attacker-controlled command output and
    # verbose platform exception text.  Normalize them at the collection
    # boundary so a failed sub-collector can never make the complete telemetry
    # record invalid on the wire.
    from .telemetry_diagnostics import normalize_diagnostics_with_owners
    bounded_errors, issue_sources, issue_owners = normalize_diagnostics_with_owners(errors)
    from .activity_evidence import drain as drain_activity
    return Telemetry(
        agent_id=agent_id,
        hostname=socket.gethostname(),
        platform=f"{platform.system()} {platform.release()}",
        observed_at=observed_at,
        accounts=accounts,
        sessions=sessions,
        services=services,
        interfaces=interfaces,
        routes=routes,
        neighbors=neighbors,
        listeners=listeners,
        integrity=integrity,
        probes=probes,
        processes=processes,
        persistence=persistence,
        security_events=security_events,
        activity_evidence=drain_activity(),
        firewall=firewall,
        filesystems=filesystems,
        memory=memory,
        collector_errors=bounded_errors,
        collector_issue_sources=issue_sources,
        collector_issue_owners=issue_owners,
        boot_id=boot_id if system == "windows" else _boot_id(system),
        collection_seconds=round(time.monotonic() - started, 3),
    )


def machine_identity() -> str:
    candidates = [Path("/etc/machine-id"), Path("/var/lib/dbus/machine-id")]
    for path in candidates:
        try:
            value = path.read_text(encoding="utf-8").strip()
            if value:
                return value
        except OSError:
            continue
    return f"{socket.gethostname()}:{platform.system()}:{os.getenv('COMPUTERNAME', '')}"
