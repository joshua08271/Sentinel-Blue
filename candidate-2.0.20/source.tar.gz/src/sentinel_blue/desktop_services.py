"""Choosing which Linux services to set up, and saying honestly what that means.

The operator picks services from the support catalog; this module turns that
selection into the same reviewed plan the setup engine already consumes. There is
no second execution path: a selection becomes a plan fragment, the plan goes
through the existing review and approval, and the existing guarded engine runs it.

What the panel must never do is imply more capability than exists. Every row
carries whether its configuration can be generated at all, and whether the pack
has been proven against the real product — which, in this release, none has.
"""

from __future__ import annotations

from typing import Any
import copy
import json
import re
from pathlib import Path

from .linux_service_catalog import (
    ADOPT, CONFIGURE, CATALOG, FAMILIES, catalog_rows, conflicting,
    missing_requirements, support_summary)

# What the agent reports for a unit, mapped to what an operator needs to know.
PRESENT_STATES = {"running", "active"}
STOPPED_STATES = {"stopped", "inactive", "failed", "dead"}
PRESENCE_DETAIL = {
    "running": "the unit is running on this host",
    "installed": "the unit exists but is not running",
    "absent": "not in this host's service inventory",
    "unknown": "no usable service inventory from this host yet",
}


def host_units(telemetry: dict[str, Any]) -> dict[str, str]:
    """Unit name to reported state, for the host this selection targets."""
    units = {}
    for row in (telemetry or {}).get("services", [])[:4096]:
        if isinstance(row, dict) and isinstance(row.get("name"), str):
            name = row["name"][:256]
            units[name] = str(row.get("state", "unknown"))[:64]
            if name.endswith(".service"):
                units[name[: -len(".service")]] = units[name]
    return units


def catalog_presence(telemetry: dict[str, Any], *, now=None) -> dict[str, str]:
    """Which catalogued services this host reports, and in what state.

    Bounded to the catalog, so the dashboard carries at most one short entry per
    known service rather than a host's whole unit inventory.
    """
    if now is not None:
        stamp = (telemetry or {}).get("observed_at")
        if type(stamp) not in {int, float} or not 0 <= now - stamp <= 90:
            return {}
    units = host_units(telemetry)
    if not units:
        return {}
    return {service_id: installed_state(service_id, units)["state"]
            for service_id in CATALOG}


def installed_state(service_id: str, units: dict[str, str]) -> dict[str, Any]:
    """Whether this catalogued service is already on the host.

    Absent from a service inventory means absent from the inventory — not
    "not installed". A host whose collector failed reports unknown, because
    installing over an unknown state is how existing configuration is lost.
    """
    row = CATALOG.get(service_id)
    if row is None:
        return {"state": "unknown", "detail": "not in the catalog"}
    if not units:
        return {"state": "unknown", "detail": "no service inventory from this host yet"}
    unit = row["unit"]
    reported = units.get(unit, units.get(unit + ".service"))
    if reported is None:
        return {"state": "absent", "detail": f"{unit} is not in this host's service inventory"}
    if reported in PRESENT_STATES:
        return {"state": "running", "detail": f"{unit} is {reported}"}
    if reported in STOPPED_STATES:
        return {"state": "installed", "detail": f"{unit} is installed and {reported}"}
    return {"state": "unknown", "detail": f"{unit} reports {reported}"}


def display_rows(*, family: str | None = None, presence: dict[str, str] | None = None,
                 selection: list[str] | None = None) -> list[dict[str, Any]]:
    """One row per catalogued service, as the panel shows it."""
    presence = presence or {}
    chosen = set(selection or [])
    rows = []
    for row in catalog_rows(family=family):
        state = presence.get(row["id"], "unknown")
        rows.append({
            "id": row["id"],
            "selected": row["id"] in chosen,
            "family": row["family"],
            "label": row["label"],
            "unit": row["unit"],
            "ports": ", ".join(str(value) for value in row["ports"]) or "-",
            "capability": row["capability"],
            # The word an operator reads. "Configure" is what the code can do;
            # it is never the word "supported", which this release has not earned.
            "capability_label": ("Adopt and verify" if row["capability"] == ADOPT
                                 else "Generate configuration"),
            "installed": state,
            "installed_detail": PRESENCE_DETAIL.get(state, "state unknown"),
            "tested": "not native-tested",
            "notes": row["notes"],
        })
    return rows


def selection_report(selection: list[str], *, presence: dict[str, str] | None = None,
                     manager: str | None = None,
                     options: dict[str, dict[str, Any]] | None = None) -> dict[str, Any]:
    """Everything that should be true before this selection becomes a plan."""
    known = [service_id for service_id in selection if service_id in CATALOG]
    unknown = [service_id for service_id in selection if service_id not in CATALOG]
    presence = presence or {}
    rows = [CATALOG[service_id] for service_id in known]
    blocking: list[str] = []
    warnings: list[str] = []

    if unknown:
        blocking.append("not in the catalog: " + ", ".join(sorted(unknown)))
    from .service_ports import distinct_configured_endpoints
    for pair in conflicting(known):
        if distinct_configured_endpoints(pair["service"], pair["conflicts_with"], options):
            continue
        blocking.append(
            f"{CATALOG[pair['service']]['label']} and "
            f"{CATALOG[pair['conflicts_with']]['label']} cannot both own their role on one host")
    for pair in conflicting(known + [sid for sid, state in presence.items() if state == "running" and sid in CATALOG and sid not in known]):
        if pair["service"] in known or pair["conflicts_with"] in known:
            if pair["service"] not in known or pair["conflicts_with"] not in known:
                blocking.append("Existing running service conflicts with selection: " + pair["service"] + " / " + pair["conflicts_with"])
    for item in missing_requirements(known):
        if presence.get(item["requires"]) == "running":
            warnings.append("Existing dependency must be verified at execution: " + item["requires"])
            continue
        blocking.append(
            f"{CATALOG[item['service']]['label']} depends on "
            f"{CATALOG[item['requires']]['label']}, which is not selected")

    from .service_ports import endpoint_set
    assignments = {}
    if options is not None:
        for sid in known:
            if sid not in options:
                continue
            try:
                for endpoint in endpoint_set(sid, options[sid]):
                    if endpoint in assignments and assignments[endpoint] != sid:
                        blocking.append(f"Selected listener {endpoint[0]}/{endpoint[1]} is shared by {assignments[endpoint]} and {sid}; choose distinct ports")
                    assignments[endpoint] = sid
            except ValueError as exc:
                blocking.append(str(exc))
    adopt_only = [row["label"] for row in rows if row["capability"] == ADOPT]
    if adopt_only:
        warnings.append(
            "adoption and verification only, no configuration is generated: "
            + ", ".join(sorted(adopt_only)))
    unknown_state = [row["label"] for row in rows
                     if presence.get(row["id"], "unknown") == "unknown"]
    if unknown_state:
        warnings.append(
            "current state unknown on this host, so setup cannot tell adoption from "
            "installation: " + ", ".join(sorted(unknown_state)))
    data = sorted({path for row in rows for path in row["data_paths"]})
    if data:
        warnings.append("preserved, never written by setup: " + ", ".join(data))

    packages: dict[str, list[str]] = {}
    if manager and manager != "apt":
        blocking.append("No reviewed native layout for " + manager + "; package-name metadata does not authorize Debian unit/configuration paths")
    if manager:
        for row in rows:
            names = row["packages"].get(manager)
            if names:
                packages[row["id"]] = list(names)
            elif row["packages"]:
                blocking.append(
                    f"{row['label']} has no reviewed package name for {manager}")
    return {
        "selected": sorted(known),
        "families": sorted({row["family"] for row in rows}),
        "configure": sorted(row["id"] for row in rows if row["capability"] == CONFIGURE and (options is None or row["id"] in options)),
        "adopt_only": sorted(row["id"] for row in rows if row["capability"] == ADOPT or (options is not None and row["id"] not in options)),
        "clients_required": sorted({client for row in rows for client in row["clients"]}),
        "packages": packages,
        "data_preserved": data,
        "blocking": blocking,
        "warnings": warnings,
        "ready": not blocking and bool(known),
        "native_tested": False,
        "statement": support_summary()["statement"],
    }


def service_plan(selection: list[str], host: str, *, manager: str | None = None,
                 options: dict[str, dict[str, Any]] | None = None,
                 presence: dict[str, str] | None = None,
                 custom: list[dict[str, Any]] | None = None, local_addresses=()) -> dict[str, Any]:
    """Turn a selection into a plan fragment for the ordinary review path.

    This produces tasks, not changes. Nothing here is executed: the fragment is
    reviewed, approved and run by the same engine every other plan uses.

    `custom` adds services outside the catalog (see custom_services); each is
    adopted through the same `linux-service` recipe an adopt-only row uses.
    """
    from .custom_services import normalize_custom_services, custom_task
    custom_rows = normalize_custom_services(custom, catalog_units=catalog_units(), local_addresses=local_addresses)
    if not isinstance(host, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,95}", host):
        raise ValueError("service plan requires an explicit simple host identity")
    supplied = options or {}
    if not isinstance(supplied, dict) or set(supplied) - set(selection) or any(not isinstance(v, dict) for v in supplied.values()):
        raise ValueError("service options must be objects belonging to selected services")
    if not selection and custom_rows:
        report = {"blocking": [], "selected": [], "statement": "", "data_preserved": [],
                  "clients_required": [], "warnings": [], "configure": [], "adopt_only": []}
    else:
        report = selection_report(selection, manager=manager, presence=presence, options=supplied)
    if report["blocking"]:
        raise ValueError("; ".join(report["blocking"]))
    if not report["selected"] and not custom_rows:
        raise ValueError("choose at least one service")
    tasks = []
    for service_id in report["selected"]:
        row = CATALOG[service_id]
        task: dict[str, Any] = {
            "id": f"sentinel-{service_id}",
            "host": host,
            "requires": [f"sentinel-{name}" for name in row["requires"]
                         if name in report["selected"]],
            "service_id": row["unit"],
        }
        if row["capability"] == CONFIGURE and service_id in supplied:
            if "catalog_id" in supplied[service_id] or "manager" in supplied[service_id]:
                raise ValueError("catalog_id and manager are selected by the plan, not per-service options")
            task["recipe"] = "linux-nginx" if service_id == "nginx" else "linux-service-pack"
            task["options"] = (({"catalog_id": service_id} if service_id != "nginx" else {})
                               | copy.deepcopy(supplied[service_id]) | {"manager": manager or "apt"})
        else:
            # Adoption: confirm the unit is the approved one and running. No
            # configuration is written, so nothing needs a rollback contract.
            task["recipe"] = "linux-service"
            # Unmask as well as enable: setup is also the fallback when repair
            # cannot fix a unit, and a masked unit is one it must bring back.
            task["options"] = {"service": row["unit"], "enable": True, "unmask": True}
        external = [name for name in row["requires"] if name not in report["selected"]]
        if external:
            if task["recipe"] == "linux-service-pack":
                task["options"]["existing_dependencies"] = external
            elif task["recipe"] == "linux-service":
                task["options"]["validate_argv"] = ["/usr/bin/systemctl", "is-active", "--quiet", "--",
                    *[CATALOG[name]["unit"] for name in external]]
        tasks.append(task)
    taken = {task["service_id"] for task in tasks} | {task["service_id"] + ".service" for task in tasks}
    for row in custom_rows:
        if row["unit"] in taken:
            raise ValueError(f"{row['unit']} is already part of this plan")
        tasks.append(custom_task(row, host))
    return {
        "schema": 1,
        "generated_by": "service-selection",
        "host": host,
        "tasks": tasks,
        "custom_services": custom_rows,
        "review_notes": {
            "native_tested": False,
            "statement": report["statement"],
            "data_preserved": report["data_preserved"],
            "clients_required": report["clients_required"],
            "warnings": report["warnings"],
            "configure": report["configure"], "adopt_only": report["adopt_only"],
            "existing_dependencies": sorted({name for sid in report["selected"] for name in CATALOG[sid]["requires"] if name not in report["selected"]}),
        },
    }


def catalog_units() -> frozenset[str]:
    """Unit names the catalog already covers, with and without .service."""
    return frozenset(name for row in CATALOG.values() for name in (row["unit"], row["unit"] + ".service"))


def summary_line(report: dict[str, Any]) -> str:
    """One line for the panel footer; the operator reads this before anything else."""
    custom = report.get("custom", [])
    if not report["selected"] and not custom:
        return "No services selected."
    parts = [f"{len(report['selected'])} selected",
             f"{len(report['configure'])} generate configuration",
             f"{len(report['adopt_only'])} adopt-only"]
    if custom:
        parts.append(f"{len(custom)} custom")
    if report["blocking"]:
        return " · ".join(parts) + f" · {len(report['blocking'])} blocking issue(s) — resolve before review"
    return (" · ".join(parts)
            + " · none native-tested; review the plan and prove each service on your lab")


CUSTOM_PREFIX = "custom:"


class ServiceSelectionPanel:
    """The Setup tab's service chooser.

    Selection produces a reviewed plan fragment. It never applies anything, and
    the Approve button on the Setup tab remains the only route to execution.
    """

    COLUMNS = (("selected", "Use", 44), ("family", "Family", 90), ("label", "Service", 230),
               ("capability_label", "What Sentinel can do", 170),
               ("installed", "On host", 90), ("ports", "Planned / default ports", 145))

    def __init__(self, parent, widgets, *, on_change=None, port_context_provider=None):
        self.tk, self.ttk = widgets
        self.on_change = on_change
        self.port_context_provider = port_context_provider
        self.port_choices = {}
        self.port_reports = {}
        self.port_requirements = {}
        self.active_host = None
        self.host_configurations = {}
        self.port_editor = None
        self.selection: list[str] = []
        self.options: dict[str, dict[str, Any]] = {}
        # Services outside the catalog, as normalize_custom_service returns them.
        self.custom_services: list[dict[str, Any]] = []
        self.custom_editor = None
        # This VM's own addresses, which a custom check may target besides
        # 127.0.0.1. Empty for a remote host: then only loopback is accepted.
        self.local_addresses: tuple[str, ...] = ()
        self.options_root = Path.cwd()
        self.presence: dict[str, str] = {}
        self.family = self.tk.StringVar(value="all")
        self.summary = self.tk.StringVar(value="No services selected.")
        frame = self.ttk.Frame(parent)
        frame.pack(fill="both", expand=True)
        controls = self.ttk.Frame(frame)
        controls.pack(fill="x")
        self.ttk.Label(controls, text="Family").pack(side="left")
        chooser = self.ttk.Combobox(controls, textvariable=self.family, state="readonly",
                                    values=("all", *FAMILIES), width=14)
        chooser.pack(side="left", padx=6)
        chooser.bind("<<ComboboxSelected>>", lambda _event: self.refresh())
        self.ttk.Button(controls, text="Clear selection", command=self.clear).pack(side="left")
        self.ttk.Button(controls, text="Configure selected service…", command=self._edit_options).pack(side="left", padx=6)
        # A scored service that is not in the catalog: its unit, files and check.
        self.ttk.Button(controls, text="Add custom service…", command=self.add_custom).pack(side="left", padx=(12, 0))
        self.ttk.Button(controls, text="Remove custom service", command=self.remove_custom).pack(side="left", padx=6)
        port_controls = self.ttk.Frame(frame)
        port_controls.pack(fill="x", pady=(8, 0))
        self.ttk.Button(port_controls, text="Ports: Automatic / Manual…", command=self._edit_ports).pack(side="left")
        self.ttk.Button(port_controls, text="Automatic for selected…", command=self._automatic_ports).pack(side="left", padx=8)
        self.ttk.Label(port_controls, text="Choose ports here; apply only after Setup review.").pack(side="left", padx=4)
        import sys
        linux_desktop = sys.platform.startswith('linux')
        table = self.ttk.Frame(frame) if linux_desktop else frame
        self.tree = self.ttk.Treeview(
            table, columns=[name for name, _label, _width in self.COLUMNS],
            show="headings", height=12, selectmode="browse")
        for name, label, width in self.COLUMNS:
            self.tree.heading(name, text=label)
            self.tree.column(name, width=width, anchor="w")
        # Summary and detail are reserved against the bottom before the list
        # takes the rest, so a long catalog never hides why a choice is blocked.
        self.detail = self.tk.Text(frame, height=4, wrap="word", bg="#172636", fg="#edf3f8",
                                   relief="flat", padx=10, pady=6)
        self.detail.pack(side="bottom", fill="x", pady=4)
        self.detail.configure(state="disabled")
        self.ttk.Label(frame, textvariable=self.summary, wraplength=900,
                       justify="left").pack(side="bottom", anchor="w")
        if linux_desktop:
            bar = self.ttk.Scrollbar(table, orient='vertical', command=self.tree.yview)
            bar.pack(side='right', fill='y')
            horizontal = self.ttk.Scrollbar(table, orient='horizontal', command=self.tree.xview)
            horizontal.pack(side='bottom', fill='x')
            self.tree.configure(yscrollcommand=bar.set, xscrollcommand=horizontal.set)
            self.tree.pack(fill="both", expand=True)
            table.pack(fill='both', expand=True, pady=8)
        else:
            self.tree.pack(fill='both', expand=True, pady=8)
        self.tree.bind("<Double-1>", self.toggle)
        self.tree.bind("<space>", self.toggle)
        self.refresh()

    # -- state -------------------------------------------------------------
    def observe(self, presence, *, host=None):
        """Adopt the latest host presence map so 'On host' reflects reality."""
        if host is not None and self.active_host != host:
            if self.active_host is not None:
                self.host_configurations[self.active_host] = copy.deepcopy((self.selection, self.options, self.port_choices, self.port_reports, self.port_requirements, self.custom_services))
            (self.selection, self.options, self.port_choices, self.port_reports, self.port_requirements, self.custom_services) = copy.deepcopy(
                self.host_configurations.get(host, ([], {}, {}, {}, {}, [])))
            self.active_host = host
        self.presence = presence or {}
        self.refresh()

    def toggle(self, _event=None):
        chosen = self.tree.selection()
        if not chosen:
            return "break"
        service_id = chosen[0]
        if service_id.startswith(CUSTOM_PREFIX):
            self.edit_custom(service_id.removeprefix(CUSTOM_PREFIX))
            return "break"
        if service_id in self.selection:
            self.selection.remove(service_id)
            self.options.pop(service_id, None)
            self.port_choices.pop(service_id, None)
            self.port_reports.pop(service_id, None)
            self.port_requirements.pop(service_id, None)
        else:
            self.selection.append(service_id)
        self.refresh()
        if self.on_change is not None:
            self.on_change(list(self.selection))
        return "break"

    def clear(self):
        self.selection = []
        self.custom_services = []
        self.options = {}
        self.port_choices = {}
        self.port_reports = {}
        self.port_requirements = {}
        self.refresh()
        if self.on_change is not None:
            self.on_change([])

    def report(self):
        report = selection_report(self.selection, presence=self.presence, options=self.options)
        for sid, reason in self.port_requirements.items():
            if sid in self.selection:
                report["blocking"].append(CATALOG[sid]["label"] + ": port saved; complete other service parameters: " + reason)
        report["custom"] = [row["unit"] for row in self.custom_services]
        report["ready"] = bool(report["selected"] or report["custom"]) and not report["blocking"]
        return report

    # -- services outside the catalog --------------------------------------
    def _custom_selected(self):
        chosen = self.tree.selection()
        if chosen and chosen[0].startswith(CUSTOM_PREFIX):
            return chosen[0].removeprefix(CUSTOM_PREFIX)
        return None

    def save_custom(self, spec, *, replacing=None):
        """Validate one declared service against the others and keep it.

        Raises ValueError with the operator-facing reason; nothing is kept then.
        """
        from .custom_services import normalize_custom_service, normalize_custom_services
        row = normalize_custom_service(spec, catalog_units=catalog_units(), local_addresses=self.local_addresses)
        rows = [r for r in self.custom_services if r["unit"] != replacing]
        if any(r["unit"] == row["unit"] for r in rows):
            raise ValueError(f"{row['unit']} has already been added.")
        rows.append(row)
        normalize_custom_services(rows, catalog_units=catalog_units(), local_addresses=self.local_addresses)
        self.custom_services = rows
        self.refresh()
        if self.on_change is not None:
            self.on_change(list(self.selection))
        return row

    def add_custom(self):
        self.edit_custom(None)

    def remove_custom(self):
        unit = self._custom_selected()
        if unit is None:
            from tkinter import messagebox
            messagebox.showinfo("Remove custom service", "Select a custom service row first.",
                                parent=self.tree.winfo_toplevel())
            return
        self.custom_services = [row for row in self.custom_services if row["unit"] != unit]
        self.refresh()
        if self.on_change is not None:
            self.on_change(list(self.selection))

    def edit_custom(self, unit):
        """The form for one service outside the catalog. Saving changes nothing on the host."""
        from .custom_services import local_check, CHECK_KINDS
        existing = next((row for row in self.custom_services if row["unit"] == unit), None)
        if self.custom_editor is not None:
            try:
                self.custom_editor.destroy()
            except Exception:
                pass
        dialog = self.tk.Toplevel(self.tree)
        self.custom_editor = dialog
        dialog.title("Custom service" + (" — " + existing["label"] if existing else ""))
        dialog.geometry("720x620")
        body = self.ttk.Frame(dialog, padding=14)
        body.pack(fill="both", expand=True)
        body.columnconfigure(1, weight=1)
        self.ttk.Label(body, wraplength=680, justify="left", text=(
            "Name the systemd unit that runs the service, the configuration files that belong to it, and "
            "the check that proves it works. Setup adopts the unit and starts it. Repair restores those files "
            "to their approved state, re-enables the unit (including from a mask) and restarts it, and the "
            "check decides whether the repair worked. Account, sudo, SSH and boot files cannot be listed: "
            "they stay monitored, never overwritten by a service repair.")).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 10))
        check = (existing or {}).get("check", {"kind": "tcp", "target": "127.0.0.1", "port": ""})
        fields = {}
        def entry(row, label, value):
            self.ttk.Label(body, text=label).grid(row=row, column=0, sticky="w", pady=3)
            var = self.tk.StringVar(value=value)
            self.ttk.Entry(body, textvariable=var).grid(row=row, column=1, sticky="ew", pady=3)
            return var
        fields["unit"] = entry(1, "systemd unit", (existing or {}).get("unit", ""))
        fields["label"] = entry(2, "Label (optional)", (existing or {}).get("label", ""))
        self.ttk.Label(body, text="Configuration files\n(one per line)").grid(row=3, column=0, sticky="nw", pady=3)
        files = self.tk.Text(body, height=6, wrap="none")
        files.grid(row=3, column=1, sticky="nsew", pady=3)
        files.insert("1.0", "\n".join((existing or {}).get("files", [])))
        self.ttk.Label(body, text="Check type").grid(row=4, column=0, sticky="w", pady=3)
        fields["kind"] = self.tk.StringVar(value=check.get("kind", "tcp"))
        self.ttk.Combobox(body, textvariable=fields["kind"], state="readonly", values=CHECK_KINDS).grid(row=4, column=1, sticky="w", pady=3)
        fields["target"] = entry(5, "Target (127.0.0.1, this VM's address, or a full URL)", check.get("target", "127.0.0.1"))
        fields["port"] = entry(6, "Port (TCP / DNS)", str(check.get("port", "")))
        fields["query"] = entry(7, "DNS query name", check.get("query", ""))
        fields["answers"] = entry(8, "DNS answers (comma separated)", ", ".join(check.get("expected_answers", [])))
        fields["body"] = entry(9, "HTTP expected page text (optional)", check.get("expected_body", ""))
        fields["ca"] = entry(10, "HTTPS CA certificate file", check.get("ca_file", ""))
        error = self.tk.StringVar(value="Saved with the reviewed setup plan. Nothing on this host changes until you approve it.")
        self.ttk.Label(body, textvariable=error, wraplength=680, justify="left").grid(row=11, column=0, columnspan=2, sticky="w", pady=10)
        def save():
            try:
                probe = local_check(fields["kind"].get(), fields["target"].get(), fields["port"].get(),
                                    query=fields["query"].get(), answers=fields["answers"].get(),
                                    expected_body=fields["body"].get(), ca_file=fields["ca"].get(),
                                    local_addresses=self.local_addresses)
                spec = {"unit": fields["unit"].get().strip(), "check": probe,
                        "files": [line.strip() for line in files.get("1.0", "end").splitlines() if line.strip()]}
                if fields["label"].get().strip():
                    spec["label"] = fields["label"].get().strip()
                self.save_custom(spec, replacing=unit)
            except (ValueError, OSError) as exc:
                error.set(str(exc))
                return
            self.custom_editor = None
            dialog.destroy()
        controls = self.ttk.Frame(body)
        controls.grid(row=12, column=0, columnspan=2, sticky="w")
        self.ttk.Button(controls, text="Save custom service", command=save).pack(side="left")
        self.ttk.Button(controls, text="Cancel", command=dialog.destroy).pack(side="left", padx=6)
        dialog.save = save
        dialog.fields = fields
        dialog.files = files
        dialog.error = error
        return dialog

    def refresh(self):
        family = None if self.family.get() == "all" else self.family.get()
        rows = display_rows(family=family, presence=self.presence, selection=self.selection)
        keep = self.tree.selection()
        self.tree.delete(*self.tree.get_children())
        for row in rows:
            from .service_ports import configured_ports, capability
            sid = row["id"]
            try:
                ports = ", ".join(str(v) for v in configured_ports(sid, self.options.get(sid, {})).values()) or row["ports"]
            except ValueError:
                ports = "needs review"
            self.tree.insert("", "end", iid=row["id"], values=(
                "yes" if row["selected"] else "", row["family"], row["label"],
                ("Configure (parameters saved)" if row["id"] in self.options else "Adopt/start only; no parameters"), row["installed"], ports + (" (planned)" if sid in self.port_reports else "")))
        if family is None:
            from .custom_services import check_port
            # Listed first: the operator added these by hand and expects to see them.
            for index, row in enumerate(self.custom_services):
                self.tree.insert("", index, iid=CUSTOM_PREFIX + row["unit"], values=(
                    "yes", "custom", row["label"], "Adopt and repair; " + str(len(row["files"])) + " file(s)",
                    self.presence.get(row["unit"], "declared"), str(check_port(row["check"])) + " (" + row["check"]["kind"] + " check)"))
        for identity in keep:
            if self.tree.exists(identity):
                self.tree.selection_set(identity)
        report = self.report()
        self.summary.set(summary_line(report))
        lines = []
        for item in report["blocking"]:
            lines.append("BLOCKING · " + item)
        for item in report["warnings"]:
            lines.append("· " + item)
        if report["clients_required"]:
            lines.append("· scoring clients needed on the checking host: "
                         + ", ".join(report["clients_required"]))
        for row in self.custom_services:
            lines.append("· custom " + row["unit"] + ": repair restores " + (str(len(row["files"])) + " declared file(s) and "
                         if row["files"] else "") + "its unit file, re-enables it and restarts it; "
                         + row["check"]["kind"].upper() + " check decides success")
        if not lines:
            lines.append("Double-click a service to select it, or use Add custom service… for one that is "
                         "not listed. Nothing is changed until you review and approve a plan.")
        self.detail.configure(state="normal")
        self.detail.delete("1.0", "end")
        self.detail.insert("1.0", "\n".join(lines))
        self.detail.configure(state="disabled")

    def _ports_context(self, service_id):
        from .service_ports import endpoint_set
        context = self.port_context_provider(service_id, self.options.get(service_id, {})) if self.port_context_provider else {}
        context = dict(context)
        context.setdefault("host", self.active_host)
        context["service_presence"] = self.presence.get(service_id, "unknown")
        import hashlib, json
        context["configuration_digest"] = hashlib.sha256(json.dumps(self.options.get(service_id, {}), sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        reserved = set(context.get("reserved", set()))
        for sid in self.selection:
            if sid != service_id and sid in self.options:
                reserved.update(endpoint_set(sid, self.options[sid]))
        context["reserved"] = reserved
        return context

    def _automatic_ports(self):
        from tkinter import messagebox
        from .service_ports import capability, resolve_ports
        from .setup_recipes import compile_recipe
        saved, skipped, failures = [], [], []
        for sid in list(self.selection):
            try:
                options = self.options.get(sid, {})
                if not capability(sid, options)["editable"]:
                    skipped.append(sid)
                    continue
                context = self._ports_context(sid)
                result, report = resolve_ports(sid, options, {}, required=context.get("required"),
                    reserved=context.get("reserved"), observation=context.get("observation"),
                    service_presence=context.get("service_presence", "unknown"))
                self.options[sid] = result
                self.port_choices[sid] = {row["key"]: {"mode": "auto"} for row in report["decisions"]}
                self.port_reports[sid] = report
                saved.append(sid)
                recipe = "linux-nginx" if sid == "nginx" else "linux-service-pack"
                try:
                    compile_recipe(recipe, dict(result, manager="apt", **({"catalog_id": sid} if sid != "nginx" else {})), self.options_root, "linux")
                    self.port_requirements.pop(sid, None)
                except (ValueError, TypeError, KeyError, OSError) as exc:
                    self.port_requirements[sid] = str(exc)[:300]
            except (ValueError, TypeError, KeyError, OSError) as exc:
                failures.append(sid + ": " + str(exc))
        self.refresh()
        messagebox.showinfo("Automatic port choices (not applied)",
            "Saved: " + (", ".join(saved) or "none") + "\nPorts unchanged: " + (", ".join(skipped) or "none")
            + ("\nNeeds review: " + "; ".join(failures) if failures else "")
            + "\nComplete any remaining service parameters, then use ordinary Setup review.", parent=self.tree.winfo_toplevel())

    def _edit_ports(self):
        chosen = self.tree.selection()
        if not chosen:
            return
        from tkinter import messagebox
        from .service_ports import capability
        from .desktop_ports import PortEditor
        service_id = chosen[0]
        if service_id.startswith(CUSTOM_PREFIX):
            self.edit_custom(service_id.removeprefix(CUSTOM_PREFIX))
            return
        try:
            info = capability(service_id, self.options.get(service_id, {}))
            if not info["editable"]:
                messagebox.showinfo("Ports kept unchanged", info["reason"], parent=self.tree.winfo_toplevel())
                return
            def save(options, report, choices):
                self.options[service_id] = options
                self.port_choices[service_id] = choices
                self.port_reports[service_id] = report
                if service_id not in self.selection:
                    self.selection.append(service_id)
                try:
                    from .setup_recipes import compile_recipe
                    recipe = "linux-nginx" if service_id == "nginx" else "linux-service-pack"
                    actual = dict(options, manager="apt")
                    if service_id != "nginx":
                        actual["catalog_id"] = service_id
                    compile_recipe(recipe, actual, self.options_root, "linux")
                    self.port_requirements.pop(service_id, None)
                except (ValueError, TypeError, KeyError, OSError) as exc:
                    self.port_requirements[service_id] = str(exc)[:300]
                self.refresh()
                if self.on_change:
                    self.on_change(list(self.selection))
            if self.port_editor is not None and self.port_editor.window is not None:
                self.port_editor.close()
            self.port_editor = PortEditor(self.tree, (self.tk, self.ttk), service_id,
                self.options.get(service_id, {}), on_save=save,
                saved_choices=self.port_choices.get(service_id),
                context_provider=lambda: self._ports_context(service_id))
        except (ValueError, TypeError, KeyError, OSError) as exc:
            messagebox.showerror("Ports require review", str(exc), parent=self.tree.winfo_toplevel())

    def _edit_options(self):
        """Edit data only. Compilation validates types; execution remains on Setup."""
        import sys
        if sys.platform.startswith('linux'):
            chosen = self.tree.selection()
            if not chosen:
                return
            if chosen[0].startswith(CUSTOM_PREFIX):
                self.edit_custom(chosen[0].removeprefix(CUSTOM_PREFIX))
                return
            from tkinter import messagebox
            if CATALOG[chosen[0]]['capability'] != CONFIGURE:
                messagebox.showinfo('Adopt existing service',
                    'This adapter can start and verify an existing installation. It does not generate its configuration.',
                    parent=self.tree.winfo_toplevel())
                return
            if self.port_editor is not None:
                self.port_editor.close()
            from .linux_service_forms import ServiceForm
            ServiceForm(self, chosen[0])
            return
        chosen = self.tree.selection()
        if not chosen:
            return
        service_id = chosen[0]
        if service_id.startswith(CUSTOM_PREFIX):
            self.edit_custom(service_id.removeprefix(CUSTOM_PREFIX))
            return
        from tkinter import messagebox
        if CATALOG[service_id]["capability"] != CONFIGURE:
            messagebox.showinfo("Adoption only", "This service has no configuration adapter. No configuration will be generated.")
            return
        if self.port_editor is not None and self.port_editor.window is not None:
            self.port_editor.close()
        dialog = self.tk.Toplevel(self.tree)
        dialog.title("Reviewed parameters — " + CATALOG[service_id]["label"])
        dialog.geometry("760x500")
        self.ttk.Label(dialog, text="Enter a JSON parameter object. Use hash-pinned file references, not pasted passwords. "
                       "Use the Ports button for numeric port fields. Saving does not execute setup. Missing or unsupported values are rejected.",
                       wraplength=710).pack(padx=12, pady=12)
        text = self.tk.Text(dialog, wrap="word")
        text.pack(fill="both", expand=True, padx=12)
        text.insert("1.0", json.dumps(self.options.get(service_id, {}), indent=2))
        controls = self.ttk.Frame(dialog)
        controls.pack(fill="x", padx=12, pady=12)
        def save():
            try:
                from .json_codec import strict_json_loads
                from .setup_recipes import compile_recipe
                options = strict_json_loads(text.get("1.0", "end"), max_bytes=65536)
                plan = service_plan([service_id] + [sid for sid in self.selection if sid != service_id],
                                    "parameter-review", manager="apt",
                                    options={**self.options, service_id: options}, presence=self.presence)
                task = next(t for t in plan["tasks"] if t["id"] == "sentinel-" + service_id)
                compile_recipe(task["recipe"], task["options"], self.options_root, "linux")
            except (ValueError, TypeError, KeyError, OSError) as exc:
                messagebox.showerror("Parameters require correction", str(exc), parent=dialog)
                return
            self.options[service_id] = options
            self.port_requirements.pop(service_id, None)
            self.port_choices.pop(service_id, None)
            self.port_reports.pop(service_id, None)
            if service_id not in self.selection:
                self.selection.append(service_id)
            dialog.destroy()
            self.refresh()
        self.ttk.Button(controls, text="Validate and save parameters", command=save).pack(side="left")
        self.ttk.Button(controls, text="Cancel", command=dialog.destroy).pack(side="left", padx=6)


def merge_service_fragment(inventory, fragment):
    """Create a full inventory copy without changing scope, probes or existing tasks.

    The caller must run ordinary prepare()/compile_plan() with the approved event
    profile before offering execution. This function grants no authority.
    """
    if not isinstance(inventory, dict) or not isinstance(inventory.get("hosts"), list):
        raise ValueError("load a complete scoped inventory before merging")
    if not isinstance(fragment, dict) or fragment.get("schema") != 1 or fragment.get("generated_by") != "service-selection":
        raise ValueError("only a service-selection fragment can be merged")
    hosts = [h for h in inventory["hosts"] if isinstance(h, dict) and fragment.get("host") in {h.get("name"), h.get("agent_id")}]
    if len(hosts) != 1 or hosts[0].get("platform") != "linux":
        raise ValueError("fragment must bind to exactly one authorized Linux inventory host")
    tasks = fragment.get("tasks")
    if not isinstance(tasks, list) or not tasks or len(tasks) > 64:
        raise ValueError("fragment requires 1 to 64 reviewed tasks")
    merged = copy.deepcopy(inventory)
    setup = merged.setdefault("setup", {"tasks": []})
    if not isinstance(setup, dict) or not isinstance(setup.get("tasks"), list):
        raise ValueError("existing setup tasks are malformed")
    existing = {task.get("id") for task in setup["tasks"] if isinstance(task, dict)}
    new = set()
    for task in tasks:
        if not isinstance(task, dict) or task.get("host") != fragment["host"]:
            raise ValueError("fragment task escaped its selected host")
        identity = task.get("id")
        if not isinstance(identity, str) or identity in existing or identity in new:
            raise ValueError("duplicate task identity; existing tasks are never overwritten")
        if task.get("recipe") not in {"linux-service", "linux-service-pack", "linux-nginx"}:
            raise ValueError("fragment contains a non-catalog recipe")
        new.add(identity)
        copied = copy.deepcopy(task)
        copied["host"] = hosts[0]["name"]
        setup["tasks"].append(copied)
    return merged
