"""Linux operator-selected service actions: reviewed plans, never arbitrary commands.

All writes use the existing signed queue, agent contracts and durable repair
journal. An action-center start deliberately uses a no-file coordinated repair
so it has an exact transaction to undo. Client-supplied action parameters are
never executed. Review receipts are bounded, principal/profile bound, short
lived and one-use (a lost response can retrieve the same queued action).
"""
from __future__ import annotations

import copy
import hashlib
import hmac
import time
import uuid

from .json_codec import canonical_json_bytes
from .policy import validate_action_parameters, action_risk
from .service_repair import repair_parameters
from .service_recovery import _fresh
from .validation import validate_agent_id

REVIEW_LIFETIME = 90
MAX_REVIEWS = 128
CHOICES = {
    'check': 'Run the declared service checks (no configuration changes)',
    'start': 'Start a stopped service, with a recorded undo',
    'repair': 'Restore approved configuration/startup and recover the service',
    'undo': 'Undo the selected recorded service repair',
}
FORWARD_EFFECTS = frozenset({'restart_service', 'repair_service', 'rollback_service', 'rollback_service_repair'})


def _digest(value):
    return hashlib.sha256(canonical_json_bytes(value)).hexdigest()


def _selection(value):
    if not isinstance(value, dict) or set(value) != {'agent_id', 'service', 'choice', 'action_id'}:
        raise ValueError('selection requires agent_id, service, choice and action_id only')
    value = dict(value)
    validate_agent_id(value['agent_id'])
    for key, bound in [('service', 128), ('action_id', 128)]:
        if (not isinstance(value[key], str) or len(value[key]) > bound
                or any(ord(c) < 32 for c in value[key])):
            raise ValueError('invalid service/action identity')
    if not value['service'] or not isinstance(value['choice'], str) or value['choice'] not in CHOICES:
        raise ValueError('select a declared service and supported action')
    if (value['choice'] == 'undo') != bool(value['action_id']):
        raise ValueError('only undo requires a specific recorded action ID')
    return value


def _manifest(app, agent, service):
    rows = [row for row in app.event_profile.services
            if row['host'] == agent and row['service_id'] == service]
    if not app.event_profile.services_confirmed or len(rows) != 1:
        raise ValueError('select one unambiguous confirmed service on its exact agent')
    return rows[0]


def _sample(app, agent, service=None):
    if not app.store.agent_enabled(agent):
        raise PermissionError('agent is not enrolled and enabled')
    sample = app.store.latest_telemetry_for_agent(agent) or {}
    if not str(sample.get('platform', '')).casefold().startswith('linux'):
        raise PermissionError('the action center currently requires a Linux agent')
    _fresh(sample, app.agent_now(agent), service=service)
    if app._strict_release_binding and app.store.path != ':memory:':
        if app.store.agent_binding(agent, require_fresh=True,
                                  freshness_seconds=app.health_stale_after) is None:
            raise PermissionError('current agent release binding is unavailable')
    return sample


def _authority(app, agent, action_type, parameters):
    if not app.event_profile.action_allowed(action_type, automated=False,
            autonomy_mode=app.autonomy_mode, emergency_stopped=app.emergency_stopped):
        raise PermissionError('current event permission, governance or Emergency Stop holds this action')
    if not app._service_manifest_policy(agent, action_type, parameters, automated=False)[0]:
        raise PermissionError('the service manifest has not approved this action')
    if action_type not in {'validate_service', 'rollback_service_repair', 'rollback_service', 'rollback_integrity'} and not app._post_recovery_observation(agent):
        raise PermissionError('fresh post-controller-recovery evidence is required')
    validate_action_parameters(action_type, parameters)


def _rows_since(app, agent, created):
    # Query the full action table rather than trusting a truncated dashboard.
    rows = app.store._connection.execute(
        'SELECT action_id FROM actions WHERE agent_id=? AND created_at>=? '
        'ORDER BY created_at DESC, action_id DESC LIMIT 1025', (agent, created)).fetchall()
    if len(rows) > 1024:
        raise ValueError('action history exceeds the bounded undo review; reconcile first')
    return [app.store.get_action(row['action_id']) for row in rows]


def _belongs(app, agent, service, item):
    kind, params = item.get('action_type'), item.get('parameters') or {}
    if kind in FORWARD_EFFECTS and params.get('service') == service:
        return True
    if kind in {'restore_integrity', 'rollback_integrity'}:
        from .service_automation import affected
        return service in affected(app.event_profile, agent, 'restore_integrity', params)
    return False


def _undo_candidate(item):
    result = item.get('result') or {}
    if not isinstance(result, dict):
        return False
    before = result.get('pre_state') or {}
    if (item.get('status') != 'completed' or item.get('result_source') not in {'agent', 'agent-offline'}
            or result.get('success') is not True or result.get('dry_run') is True
            or result.get('rolled_back') is True or result.get('interrupted') is True
            or not isinstance(before, dict) or not before.get('transaction_id')):
        return False
    if item.get('action_type') == 'restart_service':
        from .journaled_recovery import START_JOURNAL
        record = result.get('record')
        return (before.get('journal_kind') == START_JOURNAL and isinstance(record, dict)
                and record.get('journal_kind') == START_JOURNAL)
    return item.get('action_type') in {'repair_service', 'restore_integrity'}


def _undo_plan(app, selection, sample):
    original = app.store.get_action(selection['action_id'])
    agent, service = selection['agent_id'], selection['service']
    if (not original or original['agent_id'] != agent or not _belongs(app, agent, service, original)):
        raise ValueError('no recorded recovery matches this service and action ID')
    if not _undo_candidate(original):
        raise ValueError('no successful, real, still-committed repair journal is available for undo')
    result, before = original['result'], original['result']['pre_state']
    if original.get('profile_fingerprint') != app.event_profile.fingerprint:
        raise PermissionError('original repair belongs to another profile; use its matching recovery workflow')
    if app._strict_release_binding and app.store.path != ':memory:':
        binding = app.store.agent_binding(agent, require_fresh=True, freshness_seconds=app.health_stale_after)
        if binding is None or (int(original['credential_epoch']), str(original['profile_id']),
                str(original['profile_fingerprint']), str(original['agent_version'])) != app.store._binding_values(binding):
            raise PermissionError('original repair belongs to an older agent identity')
    from .service_automation import never_delivered
    for row in _rows_since(app, agent, original['created_at']):
        if row['action_id'] == original['action_id'] or never_delivered(row):
            continue
        if (_belongs(app, agent, service, row)
                and row.get('status') in {'queued', 'dispatched', 'outcome_unknown', 'completed', 'failed'}):
            raise ValueError('a later service action exists; undo is not allowed over subsequent work')
    params = original['parameters']
    effects = params.get('repair', {}).get('restore_files', [])
    kind = original['action_type']
    if kind == 'restore_integrity':
        effects = [params]
    for effect in effects:
        observed = [x for x in sample.get('integrity', []) if x.get('path') == effect['path']]
        if (len(observed) != 1 or observed[0].get('sha256') != effect['baseline_sha256']
                or observed[0].get('security_descriptor_sha256') != effect['baseline_security_descriptor_sha256']):
            raise ValueError('a repaired file changed or is unverified; undo will not overwrite a third state')
    if kind == 'restore_integrity':
        parameters = {'transaction_id': before['transaction_id'], 'path': params['path']}
        if 'probes' in params:
            parameters['probes'] = copy.deepcopy(params['probes'])
        action_type = 'rollback_integrity'
        previous_state = 'unchanged by this file-only action'
    else:
        parameters = {key: before[key] for key in ('service', 'desired_state', 'transaction_id')}
        if parameters['service'] != service:
            raise ValueError('recorded undo identity differs from the selected service')
        action_type = 'rollback_service_repair'
        previous_state = before['desired_state']
        if kind == 'restart_service':
            from .journaled_recovery import START_JOURNAL
            parameters['journal_kind'] = START_JOURNAL
            action_type = 'rollback_service'
            for pin in params['recovery_guard']['files']:
                rows = [x for x in sample.get('integrity', []) if x.get('path') == pin['path']]
                if (len(rows) != 1 or rows[0].get('sha256') != pin['sha256']
                        or rows[0].get('security_descriptor_sha256') != pin['security_descriptor_sha256']):
                    raise ValueError('start inputs changed; undo will not stop a service after conflicting edits')
    return action_type, parameters, {
        'original_action_id': original['action_id'], 'transaction_id': before['transaction_id'],
        'restore_previous_files': [x['path'] for x in effects],
        'restore_previous_service_state': previous_state,
        'original_plan_sha256': (result.get('record') or {}).get('plan_sha256'),
        'pause_automatic_recovery': True,
        'warning': 'Undo restores the recorded before-state, which can be unhealthy. It is not a VM snapshot, '
                   'does not restore lost process memory or user data, and refuses later conflicting changes. '
                   'Automatic recovery and setup redo for this service remain paused until explicit resume.',
    }


def _hold_inverse(app, agent, service, action_type, parameters, reason):
    from .service_automation import affected, update_with_details, cancel_queued, agent_report
    services = {service}
    if action_type == 'rollback_integrity':
        services |= affected(app.event_profile, agent, 'restore_integrity', parameters)
    for target in sorted(services):
        # An explicit undo approval also re-synchronizes a controller whose
        # state fell behind the agent's floor, carrying its holds (R214-01b).
        state, details = update_with_details(app.store, app.event_profile, agent, target, True, reason,
                                             transaction_id=parameters['transaction_id'],
                                             report=agent_report(app, agent))
        if details['resynchronized_from_agent_floor'] is not None:
            app.store.audit('controller', 'resynchronize_service_automation', agent + '/' + target,
                            {'revision': state['revision'], **details})
        cancel_queued(app.store, app.event_profile, agent, target)


def _build(app, selection):
    agent, service, choice = selection['agent_id'], selection['service'], selection['choice']
    manifest = _manifest(app, agent, service)
    sample = _sample(app, agent, service)
    if choice == 'check':
        if not manifest['expected_transactions']:
            raise ValueError('no service transactions are declared')
        action_type, parameters = 'validate_service', {'service': service, 'probes': copy.deepcopy(manifest['expected_transactions'])}
        effect = {'checks': copy.deepcopy(manifest['expected_transactions']),
                  'warning': 'Runs the approved probes only. Some application probes authenticate or exercise '
                             'the service; this is not a baseline capture and has no configuration undo.'}
    elif choice == 'undo':
        action_type, parameters, effect = _undo_plan(app, selection, sample)
    else:
        holds = app.store.setup_redo_holds([(agent, service)]).get((agent, service), [])
        if holds:
            raise PermissionError('; '.join(holds))
        if app.store.baseline_status(agent) != 'approved':
            raise PermissionError('a verified approved baseline is required')
        parameters = repair_parameters(app.event_profile, agent, service,
            app.store.get_baseline(agent) or {}, sample, automated=False, now=app.agent_now(agent))
        if 'rollback_service_repair' not in manifest['approval_actions']:
            raise PermissionError('approve this service\'s rollback_service_repair permission before using an undoable action')
        if choice == 'start' and (parameters['repair']['observed_state'] != 'stopped'
                or parameters['repair']['restore_files'] or parameters['repair'].get('startup')):
            raise ValueError('start-only requires a stopped service with unchanged approved files/startup; review Repair instead')
        budget = app.store.service_recovery_budget_status(agent, service,
            manifest.get('repair_policy', {}).get('attempt_limits'))
        if not budget['allowed']:
            raise PermissionError(f"{budget['reason']}; retry_at={budget.get('retry_at')}. No history is cleared.")
        action_type = 'repair_service'
        effect = {'restore_approved_files': [x['path'] for x in parameters['repair']['restore_files']],
                  'startup': parameters['repair'].get('startup'),
                  'previous_state': parameters['repair']['observed_state'], 'desired_state': 'running',
                  'checks': parameters['probes'], 'budget': budget,
                  'warning': 'Stops/starts only this service as necessary, restores only approved files, '
                             'records its exact before-state, validates, and attempts automatic rollback if validation fails. '
                             'A failed or unknown rollback remains held, not force-retried.'}
    _authority(app, agent, action_type, parameters)
    semantic = copy.deepcopy(parameters)
    # A newer observation of the SAME plan is permitted; changed effects, boot,
    # source bytes, metadata, dependencies, policy or profile require re-review.
    if 'recovery_guard' in semantic:
        for key in ('sequence', 'observed_at'):
            semantic['recovery_guard'].pop(key, None)
    identity = {'selection': selection, 'profile': app.event_profile.fingerprint,
                'action_type': action_type, 'plan': semantic, 'boot_id': sample.get('boot_id')}
    return action_type, parameters, effect, _digest(identity)


class OperatorRecovery:
    """Controller mixin. The HTTP handler supplies its authenticated principal."""
    def review_service_action(self, payload, principal):
        selection = _selection(payload)
        with self._action_egress_lock, self._governance_lock, self.store._lock:
            kind, parameters, effect, digest = _build(self, selection)
            cache = self.__dict__.setdefault('_service_action_reviews', {})
            now = time.monotonic()
            for key in list(cache):
                if now >= cache[key]['expires_monotonic']:
                    del cache[key]
            if len(cache) >= MAX_REVIEWS:
                raise ValueError('service action review capacity reached; let old reviews expire')
            identifier = uuid.uuid4().hex
            cache[identifier] = {'selection': selection, 'principal': principal,
                'digest': digest, 'profile': self.event_profile.fingerprint, 'epoch': self.operator_credential_epoch,
                'expires_monotonic': now + REVIEW_LIFETIME, 'action_id': None}
            return {'review_id': identifier, 'review_sha256': digest, 'expires_in_seconds': REVIEW_LIFETIME,
                'selection': selection, 'action_type': kind, 'effects': effect,
                'requires_authorization_code': self.event_profile.environment == 'live-competition' and action_risk(kind) == 'high',
                'authorization_subject': identifier,
                'undo': 'exact-journal' if kind == 'repair_service' else 'none' if kind == 'validate_service' else 'consumes-original-undo'}

    def execute_service_action(self, payload, principal):
        if not isinstance(payload, dict) or set(payload) != {'review_id', 'review_sha256', 'reason', 'authorization_code'}:
            raise ValueError('execute requires the review ID/hash, reason and authorization_code only')
        reason = payload['reason']
        if (not isinstance(reason, str) or not 3 <= len(reason.strip()) <= 500
                or any(ord(c) < 32 for c in reason)):
            raise ValueError('enter a printable operator reason (3–500 characters)')
        if not isinstance(payload['authorization_code'], str) or len(payload['authorization_code']) > 256:
            raise ValueError('invalid authorization code')
        if any(not isinstance(payload[key], str) or len(payload[key]) > 128 for key in ('review_id', 'review_sha256')):
            raise ValueError('invalid review identity')
        with self._action_egress_lock, self._governance_lock, self.store._lock:
            review = self.__dict__.setdefault('_service_action_reviews', {}).get(payload['review_id'])
            if (review is None or review['principal'] != principal or time.monotonic() >= review['expires_monotonic']
                    or review['profile'] != self.event_profile.fingerprint or review['epoch'] != self.operator_credential_epoch
                    or not hmac.compare_digest(review['digest'], payload['review_sha256'])):
                raise PermissionError('review expired, changed, or belongs to another operator/profile; review again')
            if review['action_id'] is not None:
                # Retry after a lost reply returns the same ID, never a new write.
                return {'status': 'already_queued', 'action_id': review['action_id']}
            kind, parameters, effect, digest = _build(self, review['selection'])
            if not hmac.compare_digest(digest, review['digest']):
                raise PermissionError('the reviewed effects or host state changed; review the new plan')
            self.store.audit(principal, 'approve_service_action', payload['review_id'], {
                'selection': review['selection'], 'review_sha256': digest, 'reason': reason.strip()})
            if review['selection']['choice'] == 'undo':
                _hold_inverse(self, review['selection']['agent_id'], review['selection']['service'],
                              kind, parameters, reason.strip())
            identifier = self._queue_action_locked(review['selection']['agent_id'], kind, parameters,
                automated=False, authorization_code=payload['authorization_code'],
                authorization_subject=payload['review_id'])
            if not identifier:
                raise PermissionError('the controller did not admit the action')
            review['action_id'] = identifier
            self.store.audit(principal, 'queue_service_action', identifier, {
                'review_id': payload['review_id'], 'selection': review['selection']})
            return {'status': 'queued', 'action_id': identifier,
                    'message': 'Queued, not yet executed. Inspect its agent result before calling it successful.'}

    def service_action_history(self, payload):
        if not isinstance(payload, dict) or set(payload) != {'agent_id', 'service'}:
            raise ValueError('history requires agent_id and service only')
        agent = validate_agent_id(payload['agent_id'])
        service = payload['service']
        _manifest(self, agent, service)
        with self._governance_lock, self.store._lock:
            rows = self.store._connection.execute(
                'SELECT action_id FROM actions WHERE agent_id=? ORDER BY created_at DESC, action_id DESC LIMIT 513',
                (agent,)).fetchall()
            result = []
            items = [self.store.get_action(row['action_id']) for row in rows[:512]]
            inverses = {}
            for item in items:
                params = item.get('parameters') or {}
                if item['action_type'] in {'rollback_service', 'rollback_service_repair', 'rollback_integrity'} and params.get('transaction_id'):
                    key = (item['action_type'], params['transaction_id'], item.get('profile_fingerprint'),
                           item.get('credential_epoch'), item.get('agent_version'))
                    inverses.setdefault(key, item)  # newest record in this bounded view
            for item in items:
                params = item.get('parameters') or {}
                if not (_belongs(self, agent, service, item) or (item['action_type'] == 'validate_service' and params.get('service') == service)):
                    continue
                receipt = item.get('result') or {}
                if not isinstance(receipt, dict):
                    receipt = {'message': 'Unreadable result; reconcile before another change.'}
                before = receipt.get('pre_state') or {}
                candidate = _undo_candidate(item)
                undo_status = 'Review' if candidate else 'No'
                unavailable = None if candidate else 'No successful exact journal, or already rolled back/failed/queued'
                if candidate:
                    inverse_type = {'restart_service': 'rollback_service', 'repair_service': 'rollback_service_repair',
                                    'restore_integrity': 'rollback_integrity'}[item['action_type']]
                    inverse = inverses.get((inverse_type, before['transaction_id'], item.get('profile_fingerprint'),
                                            item.get('credential_epoch'), item.get('agent_version')))
                    if inverse is not None:
                        inv_result = inverse.get('result') or {}
                        undone = (inverse['status'] == 'completed' and inverse.get('result_source') in {'agent', 'agent-offline'}
                                  and isinstance(inv_result, dict) and inv_result.get('success') is True
                                  and not inv_result.get('dry_run') and not inv_result.get('interrupted'))
                        candidate = False
                        undo_status = 'Undone' if undone else 'Pending' if inverse['status'] in {'queued', 'dispatched'} else 'Held'
                        unavailable = ('Recorded undo completed' if undone else 'Existing inverse requires completion or reconciliation')
                        if inverse['status'] == 'failed' and isinstance(inv_result, dict):
                            if inv_result.get('review_required') is not True:
                                undo_status = 'Failed'
                                unavailable = 'The undo failed and left nothing to review; it is not offered again'
                            elif self.store.undo_review(inverse['action_id']) is not None:
                                undo_status = 'Reviewed'
                                unavailable = 'The undo failed after it began and was reviewed; it is not offered again'
                            else:
                                unavailable = 'The undo failed after it began; review it on the Alerts & verification tab'
                result.append({'action_id': item['action_id'], 'action_type': item['action_type'],
                    'status': item['status'], 'created_at': item['created_at'],
                    'automated': bool(item.get('automated')),
                    'undo_unavailable_reason': unavailable, 'undo_status': undo_status,
                    'success': receipt.get('success'), 'rolled_back': receipt.get('rolled_back'),
                    'dry_run': receipt.get('dry_run'), 'stable_health': receipt.get('stable_health'),
                    'message': str(receipt.get('message', 'Awaiting agent result'))[:1200],
                    'undo_candidate': candidate, 'undo_requires_fresh_review': True})
            from .service_automation import snapshot, inverse_readiness, sync_status
            control = snapshot(self.store, self.event_profile, agent)
            sync = sync_status(self, agent, control)
            return {'actions': result, 'truncated': len(rows) > 512,
                    'service_automation': control,
                    'automation_sync': sync,
                    'automatic_recovery_enabled': bool(self.auto_recover_services
                        and not self.emergency_stopped and not control['services'].get(service, {}).get('paused')
                        and not sync['behind'] and service not in sync['latched']
                        and any(self.event_profile.action_allowed(kind, automated=True, autonomy_mode=self.autonomy_mode)
                                and kind in _manifest(self, agent, service)['allowed_automatic_actions']
                                and inverse_readiness(self.event_profile, agent, kind, {'service': service}) is None
                                for kind in ('restart_service', 'repair_service'))),
                    'note': 'Undo eligibility is freshly rechecked; queued/failed/unknown is not successful. '
                            'Legacy starts without an exact repair journal are not offered a pretend undo.'}

    def set_service_automation(self, payload, principal):
        """Signed operator state change, limited to pausing/resuming existing grants."""
        if (not isinstance(payload, dict) or set(payload) != {'agent_id', 'service', 'paused', 'reason', 'expected_revision'}
                or type(payload['paused']) is not bool or type(payload['expected_revision']) is not int):
            raise ValueError('automation change requires an exact service, Boolean pause, reason and revision')
        agent = validate_agent_id(payload['agent_id']); service = payload['service']
        manifest = _manifest(self, agent, service)
        with self._action_egress_lock, self._governance_lock, self.store._lock:
            if not payload['paused']:
                _sample(self, agent, service)
                if self.emergency_stopped or self.autonomy_mode == 'observe':
                    raise PermissionError('global governance must permit recovery before this service can resume')
                from .service_automation import inverse_readiness
                if not any(self.event_profile.action_allowed(kind, automated=True, autonomy_mode='guarded-autonomous')
                           and kind in manifest['allowed_automatic_actions']
                           and inverse_readiness(self.event_profile, agent, kind, {'service': service}) is None
                           for kind in ('restart_service', 'repair_service')):
                    raise PermissionError('no automatic service recovery is authorized by this profile')
                if self.store.baseline_status(agent) != 'approved':
                    raise PermissionError('a verified approved baseline is required before resuming')
                holds = self.store.setup_redo_holds([(agent, service)]).get((agent, service), [])
                if holds:
                    raise PermissionError('; '.join(holds))
                # Completed history is not a lifetime gate on resuming. Only
                # outstanding work and failed inverse evidence need inspection.
                rows = self.store._connection.execute(
                    "SELECT action_id FROM actions WHERE agent_id=? AND ("
                    "status IN ('queued','dispatched','outcome_unknown') OR "
                    "(status='failed' AND action_type IN ('rollback_service','rollback_service_repair','rollback_integrity'))) "
                    "ORDER BY created_at DESC LIMIT 1025", (agent,)).fetchall()
                if len(rows) > 1024:
                    raise PermissionError('outstanding/inverse history exceeds the bounded reconciliation budget')
                for row in rows:
                    item = self.store.get_action(row['action_id'])
                    if _belongs(self, agent, service, item) and item.get('status') in {'queued','dispatched','outcome_unknown'}:
                        raise PermissionError('pending or unknown service work must be reconciled before resume')
                    result = item.get('result') or {}
                    if (_belongs(self, agent, service, item) and item.get('status') == 'failed'
                            and isinstance(result, dict) and result.get('review_required') is True
                            and self.store.undo_review(item['action_id']) is None):
                        raise PermissionError('failed inverse requires evidence-based reconciliation before resume'
                                              ' (review it on the Alerts & verification tab: action ' + str(item['action_id']) + ')')
            from .service_automation import update_with_details, agent_report
            state, details = update_with_details(self.store, self.event_profile, agent, service, payload['paused'],
                                                 payload['reason'], expected_revision=payload['expected_revision'],
                                                 report=agent_report(self, agent))
            if payload['paused']:
                from .service_automation import cancel_queued
                cancel_queued(self.store, self.event_profile, agent, service)
            self.store.audit(principal, 'pause_service_automation' if payload['paused'] else 'resume_service_automation',
                agent + '/' + service, {'revision':state['revision'], 'reason':payload['reason'], **details})
            message = ('Saved on controller. Agent applies this through its next authenticated poll; '
                       'disconnected agents keep their prior hold. No permissions or retry history are changed.')
            if details['resynchronized_from_agent_floor'] is not None:
                message += (f" Re-synchronized past the agent's durable floor (revision "
                            f"{details['resynchronized_from_agent_floor']}); holds carried forward: "
                            + (', '.join(details['carried_forward']) or 'none') + '.')
            return {'service_automation': state, 'status': 'controller-applied', 'message': message,
                    'resynchronization': details}
