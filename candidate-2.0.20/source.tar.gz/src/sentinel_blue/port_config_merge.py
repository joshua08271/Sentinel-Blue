"""Conservative, hash-reviewed native configuration edits for port selection.

These functions transform caller-supplied snapshots; they never read or modify
live service state. Ambiguous layouts are refused, not heuristically rewritten.
"""
from __future__ import annotations
import re


def _bind_tokens(text):
    token = re.compile(r'/\*.*?\*/|//[^\n]*|\#[^\n]*|"(?:\\.|[^"\\])*"|[{};]|[^\s{};"/]+|/', re.S)
    rows = []
    for match in token.finditer(text):
        value = match.group()
        if value.startswith(('/*', '//', '#')):
            continue
        rows.append((value, match.start(), match.end()))
    return rows


def bind_port(current: str, port: int) -> str:
    if type(port) is not int or not 1 <= port <= 65535:
        raise ValueError("Port must be an integer from 1 to 65535")
    if not isinstance(current, str) or len(current.encode()) > 1024 * 1024:
        raise ValueError("BIND listener snapshot must be bounded text")
    tokens = _bind_tokens(current)
    depth, blocks = 0, []
    for i, (token, start, end) in enumerate(tokens):
        if token == "options" and depth == 0:
            if i + 1 >= len(tokens) or tokens[i + 1][0] != "{":
                raise ValueError("Invalid BIND options clause")
            blocks.append(i)
        if token == "{": depth += 1
        if token == "}": depth -= 1
        if depth < 0: raise ValueError("Unbalanced BIND snapshot")
    if depth or len(blocks) != 1:
        raise ValueError("BIND listener_config needs exactly one top-level options block")
    begin = blocks[0] + 2
    depth, end_index = 1, None
    replacements = []
    seen_port = False
    for i in range(begin, len(tokens)):
        token, start, end = tokens[i]
        if token == "}":
            depth -= 1
            if depth == 0:
                end_index = i
                break
        if depth == 1 and token == "include":
            raise ValueError("Included BIND options require a separate reviewed layout; ports cannot be inferred")
        if depth == 1 and token == "port":
            # A listen-on port token is processed with its parent directive.
            if i > begin and tokens[i-1][0] in {"listen-on", "listen-on-v6"}:
                continue
            if seen_port or i + 2 >= len(tokens) or not tokens[i+1][0].isdigit() or tokens[i+2][0] != ";":
                raise ValueError("BIND default port is ambiguous")
            seen_port = True
            replacements.append((tokens[i+1][1], tokens[i+1][2], str(port)))
        if depth == 1 and token in {"listen-on", "listen-on-v6"}:
            j = i + 1
            if j >= len(tokens):
                raise ValueError("BIND listener is truncated")
            if tokens[j][0] == "port":
                if j + 1 >= len(tokens) or not tokens[j+1][0].isdigit():
                    raise ValueError("BIND listener port is malformed")
                if int(tokens[j+1][0]) != port:
                    raise ValueError("An explicit BIND listen-on port differs; review that listener separately")
                j += 2
            if j >= len(tokens) or tokens[j][0] != "{":
                raise ValueError("TLS/HTTP BIND listeners need a separately reviewed port adapter")
        if token == "{": depth += 1
    if end_index is None:
        raise ValueError("Unclosed BIND options block")
    if not seen_port:
        point = tokens[end_index][1]
        replacements.append((point, point, f"    port {port}; // Sentinel reviewed DNS port\n"))
    for a, b, value in sorted(replacements, reverse=True):
        current = current[:a] + value + current[b:]
    return current


def postfix_smtp_port(current: str, port: int, selector: str = "smtp") -> str:
    if type(port) is not int or not 1 <= port <= 65535:
        raise ValueError("Port must be an integer from 1 to 65535")
    if not isinstance(current, str) or len(current.encode()) > 1024 * 1024:
        raise ValueError("Postfix master snapshot must be bounded text")
    if not isinstance(selector, str) or not re.fullmatch(r"smtp|[0-9]{1,5}", selector):
        raise ValueError("smtp_listener must name exactly smtp or the existing numeric listener")
    lines = current.splitlines(keepends=True)
    candidates = []
    for index, line in enumerate(lines):
        if not line or line[0].isspace() or line.lstrip().startswith('#'):
            continue
        fields = line.split()
        if len(fields) < 2 or fields[1] != "inet":
            continue
        if fields[0] == selector or (selector == "smtp" and fields[0] == "25"):
            if len(fields) < 8 or fields[7] != "smtpd":
                raise ValueError("Selected Postfix listener is not an ordinary smtpd inet service")
            candidates.append(index)
        else:
            suffix = fields[0].rsplit(":", 1)[-1]
            known = {"smtp": 25, "submission": 587, "submissions": 465, "smtps": 465}
            resolved = int(suffix) if suffix.isascii() and suffix.isdigit() else known.get(suffix)
            if resolved is None:
                raise ValueError("An existing symbolic Postfix inet listener needs an explicit reviewed port mapping")
            if resolved == port:
                raise ValueError("Another Postfix inet listener already uses the requested port")
    if len(candidates) != 1:
        raise ValueError("master_config must contain exactly one selected SMTP inet listener")
    index = candidates[0]
    lines[index] = re.sub(r'^\S+', str(port), lines[index], count=1)
    return ''.join(lines)
