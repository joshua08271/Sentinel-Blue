"""Bounded causal reasoning over declared service goals and observed failures.

This is an inspectable diagnostic planner, not a command-generating language
model. Text from logs and probes is evidence only. Execution stays in the
controller/agent's independently validated, journaled repair path.
"""

from __future__ import annotations

import time
from typing import Any

from .service_repair import diagnose_service, repair_parameters
from .service_recovery import recovery_parameters

MAX_SERVICES = 128

# Diagnostic requests identify missing evidence; none is executable code.
CHECKS = {
    "trusted_baseline": "Verify the intended service state and trusted configuration or backup.",
    "fresh_inventory": "Obtain complete, fresh native service, process and file observations.",
    "service_definition": "Compare the native service definition and startup policy with the approved configuration.",
    "application_logs": "Inspect bounded application/native-service diagnostics around the failure time.",
    "resource_health": "Check free space, memory pressure, filesystem writability and native service exit status.",
    "account_access": "Verify the declared service/scoring identity and its required access using approved credentials.",
    "path_health": "Compare local and external application checks, routing, DNS, TLS and permitted firewall state.",
    "transaction_health": "Collect every exact declared application transaction; a listening port is insufficient.",
    "restore_source": "Verify the exact approved restore point and required file metadata before restoring.",
    "dependency_health": "Recover and verify the failing dependency before changing its dependent service.",
    "event_contract": "Supply an unambiguous service/dependency contract for the required application.",
    "repair_authority": "Review the service repair policy, current permissions and recovery hold before mutation.",
    "native_failure_state": "Read the service manager's recorded failure verdict, exit status and restart counters, and clear the failure state only under review.",
    "port_ownership": "Identify the process holding the declared listening port and whether it is an authorized part of this service.",
    "host_capacity": "Check free space, inodes, memory and process/file-descriptor limits on this host before restarting anything.",
}

DOMAINS = {
    "configuration_missing": ("configuration", "observed", ("restore_source",)),
    "configuration_changed": ("configuration", "observed", ("restore_source",)),
    "configuration_unverified": ("configuration", "unresolved", ("fresh_inventory", "restore_source")),
    "startup_configuration_changed": ("startup", "observed", ("service_definition",)),
    "service_stopped": ("service_state", "observed", ("application_logs", "resource_health")),
    "native_state_unknown": ("service_state", "unresolved", ("fresh_inventory", "service_definition")),
    "required_account_unavailable": ("identity", "observed", ("account_access",)),
    "dependency_unavailable": ("dependency", "observed", ("dependency_health",)),
    "dependency_unhealthy": ("dependency", "observed", ("dependency_health",)),
    "local_application_unhealthy": ("application", "observed", ("application_logs", "resource_health")),
    "external_path_or_access_failure": ("external_path_or_identity", "inferred", ("path_health", "account_access")),
    "application_failure_location_unknown": ("unknown", "unresolved", ("transaction_health", "path_health", "application_logs")),
    "transaction_evidence_missing": ("unknown", "unresolved", ("transaction_health",)),
    "no_running_baseline": ("trust", "unresolved", ("trusted_baseline",)),
    # Why the service manager says the unit stopped (issue #13). These explain a
    # stopped or unknown state; they never authorize a mutation on their own.
    "service_start_refused_by_limit": ("service_control", "observed", ("native_failure_state", "application_logs")),
    "service_restart_looping": ("service_control", "observed", ("native_failure_state", "application_logs")),
    "service_startup_protocol_violation": ("service_control", "observed", ("service_definition", "application_logs")),
    "service_killed_for_memory": ("host_capacity", "observed", ("host_capacity", "application_logs")),
    "host_resources_exhausted": ("host_capacity", "observed", ("host_capacity",)),
    "service_exited_with_error": ("application", "observed", ("application_logs", "service_definition")),
    "service_killed_by_signal": ("application", "observed", ("application_logs", "host_capacity")),
    "service_start_timed_out": ("application", "observed", ("application_logs", "dependency_health")),
    "service_watchdog_timeout": ("application", "observed", ("application_logs",)),
    "native_failure_reason_unrecognized": ("unknown", "unresolved", ("native_failure_state", "application_logs")),
    "listening_port_occupied": ("port_conflict", "observed", ("port_ownership", "fresh_inventory")),
    "socket_activation_holds_port": ("service_control", "inferred", ("service_definition", "port_ownership")),
    # Still stopping: the unit's own process holds its port and blocks a start.
    "service_stop_stuck": ("service_control", "observed", ("native_failure_state", "application_logs")),
    # Observed host capacity, not inferred from a service's exit status.
    "service_filesystem_full": ("host_capacity", "observed", ("host_capacity",)),
    "service_filesystem_inodes_exhausted": ("host_capacity", "observed", ("host_capacity",)),
    "service_filesystem_read_only": ("host_capacity", "observed", ("host_capacity", "service_definition")),
}


def _graph(manifests: list[dict[str, Any]]) -> tuple[list[str], dict[str, list[str]], dict[str, set[str]]]:
    if len(manifests) > MAX_SERVICES:
        raise ValueError("service reasoning budget exceeded")
    nodes = {row["service_id"]: row for row in manifests}
    if len(nodes) != len(manifests):
        raise ValueError("ambiguous service definitions")
    dependencies = {name: list(row["dependencies"]) for name, row in nodes.items()}
    if any(dep not in nodes for deps in dependencies.values() for dep in deps):
        raise ValueError("missing dependency definition")
    if any(len(set(deps)) != len(deps) for deps in dependencies.values()):
        raise ValueError("duplicate dependency definition")
    order: list[str] = []
    remaining = set(nodes)
    while remaining:
        ready = sorted(name for name in remaining if not set(dependencies[name]) & remaining)
        if not ready:
            raise ValueError("service dependency cycle")
        order.extend(ready)
        remaining.difference_update(ready)
    downstream = {name: set() for name in nodes}
    for name in reversed(order):
        for dependency in dependencies[name]:
            downstream[dependency].add(name)
            downstream[dependency].update(downstream[name])
    return order, dependencies, downstream


def reason_recovery(profile: Any, agent_id: str, baseline: dict[str, Any] | None,
                    telemetry: dict[str, Any], *, approved: bool = False,
                    observations: dict[str, dict[str, Any]] | None = None) -> dict[str, Any]:
    """Explain repair order, unresolved causes and the next discriminating checks.

    ``observations`` is an internal cache from ServiceRecoveryPlanner. A report
    never authorizes execution, even when the planner has a confirmed candidate.
    Offline callers get candidate plans only, never a ready-to-execute verdict.
    """
    report: dict[str, Any] = {
        "schema": 1, "engine": "declared-state-causal-planner", "agent_id": agent_id,
        "generated_at": time.time(), "observed_at": telemetry.get("observed_at"),
        "sequence": telemetry.get("sequence"), "execution_authority": False,
        "complete": False, "services": [], "repair_order": [], "blockers": [],
    }
    manifests = [item for item in profile.services if item["host"] == agent_id]
    try:
        order, dependencies, downstream = _graph(manifests)
    except (KeyError, TypeError, ValueError) as exc:
        report["blockers"].append(str(exc))
        report["next_checks"] = [{"id": "event_contract", "purpose": CHECKS["event_contract"]}]
        return report
    if not manifests:
        report["blockers"].append("no declared services for this host")
        report["next_checks"] = [{"id": "event_contract", "purpose": CHECKS["event_contract"]}]
        return report
    if not approved or not baseline:
        report["blockers"].append("baseline is not approved")
    nodes = {item["service_id"]: item for item in manifests}
    rows: dict[str, dict[str, Any]] = {}
    for name in order:
        manifest = nodes[name]
        cached = (observations or {}).get(name)
        diagnosis = cached["diagnosis"] if cached else diagnose_service(profile, agent_id, name, baseline, telemetry)
        findings = diagnosis.get("findings", [])
        checks: set[str] = set()
        hypotheses = []
        for finding in findings:
            domain, strength, requested = DOMAINS.get(finding.get("code"), ("unknown", "unresolved", ("fresh_inventory",)))
            checks.update(requested)
            hypotheses.append({"domain": domain, "strength": strength,
                               "evidence": finding.get("code"), "subject": finding.get("subject")})
        if diagnosis.get("code") == "insufficient_evidence":
            checks.update(("fresh_inventory", "trusted_baseline"))
        failing_dependencies = [dep for dep in dependencies[name] if rows[dep]["state"] != "healthy"]
        roots = set()
        for dependency in failing_dependencies:
            roots.update(rows[dependency]["upstream_faults"] or [dependency])
        action = "repair_service" if "repair_service" in manifest["allowed_automatic_actions"] else "restart_service"
        state, reason, candidate = "held", "", None
        if not approved or not baseline:
            reason = "baseline is not approved"
            checks.add("trusted_baseline")
        elif diagnosis.get("code") == "healthy":
            state = "healthy"
        else:
            try:
                if not profile.action_allowed(action, automated=True, autonomy_mode=profile.autonomy_mode):
                    raise ValueError("event profile does not authorize this automatic repair")
                if cached:
                    reason = cached["status"]
                    if reason not in {"ready", "awaiting consecutive observations"}:
                        raise ValueError(reason)
                    state = "confirmed_candidate" if reason == "ready" else "awaiting_confirmation"
                    parameters = cached.get("parameters")
                else:
                    parameters = (repair_parameters if action == "repair_service" else recovery_parameters)(
                        profile, agent_id, name, baseline, telemetry)
                    state = "candidate"
                    reason = "requires consecutive live observations and controller/agent authorization"
                candidate = {"action": action, "service": name,
                             "restore_files": [item["path"] for item in (parameters or {}).get("repair", {}).get("restore_files", [])]}
                if (parameters or {}).get("repair", {}).get("startup"):
                    candidate["startup"] = dict(parameters["repair"]["startup"])
            except (KeyError, TypeError, ValueError) as exc:
                reason = str(exc)[:500]
                checks.add("repair_authority")
        if failing_dependencies:
            state, candidate = "deferred_dependency", None
            checks.add("dependency_health")
            reason = "verify upstream recovery before reconsidering this service"
        rows[name] = {
            "service": name, "state": state, "reason": reason, "diagnosis": diagnosis,
            "hypotheses": hypotheses, "upstream_faults": sorted(roots),
            "affected_dependents": sorted(downstream[name]), "candidate": candidate,
            "next_checks": [{"id": code, "purpose": CHECKS[code]} for code in sorted(checks)],
        }
    # High-impact independent faults first; dependencies remain prerequisites.
    rank = {name: index for index, name in enumerate(order)}
    actionable = [name for name in order if rows[name]["candidate"] is not None]
    actionable.sort(key=lambda name: (-len(downstream[name]), rank[name], name))
    report.update(complete=all(row["diagnosis"].get("code") != "insufficient_evidence" for row in rows.values()),
                  services=[rows[name] for name in order], repair_order=actionable)
    report["complete"] = report["complete"] and not report["blockers"]
    return report


def run(args: Any) -> None:
    """Read-only CLI; private evidence is never sent to an external model."""
    import json
    from pathlib import Path
    from .event_profile import EventProfile
    from .json_codec import strict_json_loads
    from .validation import validate_telemetry
    from .state import write_private_json

    def read(path: str) -> Any:
        with Path(path).open("rb") as handle:
            data = handle.read(8 * 1024 * 1024 + 1)
        if len(data) > 8 * 1024 * 1024:
            raise ValueError("diagnostic input exceeds its byte budget")
        return strict_json_loads(data, max_bytes=8 * 1024 * 1024)

    profile_data = read(args.event_profile)
    if not isinstance(profile_data, dict):
        raise ValueError("diagnostic event profile must be an object")
    profile = EventProfile.from_dict(profile_data.get("event_profile", profile_data))
    telemetry = validate_telemetry(read(args.telemetry))
    baseline = None
    if args.baseline:
        raw_baseline = read(args.baseline)
        recorded = raw_baseline.get("observed_at") if isinstance(raw_baseline, dict) else None
        if type(recorded) not in (int, float) or not 0 <= recorded <= time.time():
            raise ValueError("diagnostic baseline has an invalid observation time")
        # Approved restore material may be older than the telemetry replay
        # window. Validate its shape at capture time; never freshen its timestamp.
        baseline = validate_telemetry(raw_baseline, now=recorded)
    if baseline and baseline["agent_id"] != telemetry["agent_id"]:
        raise ValueError("diagnostic baseline belongs to a different host")
    report = reason_recovery(profile, telemetry["agent_id"], baseline, telemetry,
                             approved=args.baseline_approved)
    if args.output:
        write_private_json(Path(args.output), report)
    else:
        print(json.dumps(report, indent=2, allow_nan=False))
