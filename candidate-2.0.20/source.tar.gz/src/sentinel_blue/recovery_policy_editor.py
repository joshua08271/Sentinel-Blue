"""Explicit per-service recovery budgets. Produces an unapproved profile copy.

Changing a budget never clears attempts, changes running agents, widens service
or filesystem authority, or edits a signed live profile in place. A reviewed
redeployment binds the chosen limits on BOTH the controller and each agent.
"""
from __future__ import annotations
import copy
import json
import os
from pathlib import Path

from .event_profile import EventProfile
from .recovery_limits import normalize_attempt_limits

PRESETS = {
    'Conservative': {'cooldown_seconds': 300, 'maximum_attempts': 3},
    'Moderate': {'cooldown_seconds': 60, 'maximum_attempts': 12},
    'Repeated disruption': {'cooldown_seconds': 15, 'maximum_attempts': 60},
}


def policy_candidate(raw, targets, limits):
    """Return a candidate and exact change report; unknown/duplicate targets fail."""
    original = EventProfile.from_dict(raw)
    limits = normalize_attempt_limits(limits)
    if (not isinstance(targets, (list, tuple)) or not 1 <= len(targets) <= 128
            or any(not isinstance(row, (list, tuple)) or len(row) != 2
                   or any(not isinstance(x, str) or not x for x in row) for row in targets)):
        raise ValueError('select 1–128 exact host/service pairs')
    keys = [tuple(row) for row in targets]
    if len(set(keys)) != len(keys):
        raise ValueError('duplicate service selection')
    candidate = copy.deepcopy(original.raw)
    changes = []
    for host, service in keys:
        rows = [x for x in candidate['services'] if x['host'] == host and x['service_id'] == service]
        if len(rows) != 1 or not rows[0].get('repair_policy'):
            raise ValueError(f'{host}/{service} requires one existing explicit repair policy; no new repair authority is inferred')
        row = rows[0]
        previous = normalize_attempt_limits(row['repair_policy'].get('attempt_limits'))
        row['repair_policy']['attempt_limits'] = dict(limits)
        changes.append({'agent_id': host, 'service': service, 'before': previous, 'after': dict(limits)})
    candidate['approval'] = {'status': 'pending', 'approved_by': ''}
    release = candidate.setdefault('release', {})
    release['approved'] = False
    # Do not carry assertions that the changed profile/release has been reviewed
    # by officials. Preserve its exact runtime/CA identity, scope and permissions.
    for key in ('frozen', 'submitted_to_officials', 'submission_approved'):
        if key in release:
            release[key] = False
    checked = EventProfile.from_dict(candidate)
    return candidate, {'source_fingerprint': original.fingerprint, 'candidate_fingerprint': checked.fingerprint,
        'changes': changes, 'applied_to_running_agents': False,
        'unchanged_failure_circuit_breaker': {'maximum_failures_per_hour': 3, 'cooldown_seconds': 300},
        'unchanged_setup_redo': {'maximum_attempts_per_hour': 3, 'cooldown_seconds': 600},
        'next': 'Review and approve this changed profile, then update controller and agents together through '
                'their matching deployment workflow. Preserve all state and attempt history. '
                'Saving this copy does not activate it.'}


def save_candidate(destination, candidate):
    """Exclusive, private, fsynced file; cannot overwrite source or follow a link."""
    EventProfile.from_dict(candidate)
    destination = Path(destination).absolute()
    data = (json.dumps(candidate, indent=2) + '\n').encode('utf-8')
    if len(data) > 4 * 1024 * 1024:
        raise ValueError('candidate exceeds profile size budget')
    from .state import _fsync_directory
    fd = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    # On write failure leave the partial exclusive file as evidence; never delete
    # a path another actor could have replaced during error handling.
    with os.fdopen(fd, 'wb') as handle:
        handle.write(data); handle.flush(); os.fsync(handle.fileno())
    _fsync_directory(destination.parent)
    return str(destination)
