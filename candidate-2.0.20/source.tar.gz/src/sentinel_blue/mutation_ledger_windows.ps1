# Same authenticated event/state format as mutation_ledger.py. No Python is
# required during cold Windows setup. This module uses the setup ACL helpers.
function Get-SBLMac($key, [string]$value) {
    $mac=New-Object Security.Cryptography.HMACSHA256
    try {$mac.Key=[byte[]]$key;return ([BitConverter]::ToString($mac.ComputeHash([Text.Encoding]::UTF8.GetBytes($value)))).Replace('-','').ToLowerInvariant()}
    finally {$mac.Dispose()}
}
function Write-SBLHead($ledger) {
    $head=[ordered]@{hash=$ledger.Hash;sequence=[long]$ledger.Sequence}
    $signed=[ordered]@{hash=$ledger.Hash;sequence=[long]$ledger.Sequence;mac=(Get-SBLMac $ledger.Key (Get-SBJson $head))}
    Write-SBState (Join-Path $ledger.Root 'head.json') $signed
}
function Open-SBLedger {
    $root=Join-Path ([Environment]::GetFolderPath('CommonApplicationData')) 'SentinelBlueLedger'
    if($env:SENTINEL_LEDGER_DIR){$root=$env:SENTINEL_LEDGER_DIR}
    New-SBPrivateDirectory $root
    New-SBPrivateDirectory (Join-Path $root 'states')
    $lockPath=Join-Path $root 'writer.lock'
    if(!(Test-Path -LiteralPath $lockPath)){Write-SBText $lockPath '0'}
    Test-SBPrivate $lockPath
    $lock=[IO.File]::Open($lockPath,'Open','ReadWrite','ReadWrite')
    $deadline=[DateTime]::UtcNow.AddSeconds(60)
    try {
        while($true){try{$lock.Lock(0,1);break}catch [IO.IOException]{if([DateTime]::UtcNow -ge $deadline){throw 'Another Sentinel mutation has not drained'};Start-Sleep -Milliseconds 50}}
        $keyPath=Join-Path $root 'authentication.key'
        $eventsPath=Join-Path $root 'events.jsonl'
        $headPath=Join-Path $root 'head.json'
        if(!(Test-Path -LiteralPath $keyPath)){
            if((Test-Path -LiteralPath $eventsPath) -or (Test-Path -LiteralPath $headPath)){throw 'Ledger authentication key is missing'}
            $key=New-Object byte[] 32
            $rng=[Security.Cryptography.RandomNumberGenerator]::Create()
            try{$rng.GetBytes($key)}finally{$rng.Dispose()}
            $file=[IO.File]::Open($keyPath,'CreateNew','Write','None')
            try{$file.Write($key,0,32);$file.Flush($true)}finally{$file.Dispose()}
            Set-SBPrivateAcl $keyPath $false
        }
        Test-SBPrivate $keyPath
        $key=[IO.File]::ReadAllBytes($keyPath)
        if($key.Length -ne 32){throw 'Invalid ledger key'}
        $ledger=@{Root=$root;Key=$key;Lock=$lock;Sequence=[long]0;Hash=('0'*64);Events=@()}
        if(Test-Path -LiteralPath $eventsPath){
            Test-SBPrivate $eventsPath
            if(!(Test-Path -LiteralPath $headPath)){throw 'Ledger head is missing'}
            $file=[IO.File]::OpenRead($eventsPath)
            try{if($file.Length -gt 536870912){throw 'Ledger requires archival review'};if($file.Length){$null=$file.Seek(-1,'End');if($file.ReadByte() -ne 10){throw 'Torn ledger append requires human reconciliation'}}}finally{$file.Dispose()}
            foreach($line in [IO.File]::ReadLines($eventsPath)){
                if($line.Length -gt 1048576){throw 'Oversized ledger event'}
                $record=$line|ConvertFrom-Json
                $body=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($record.payload))
                $hash=Get-SBHash ($ledger.Hash+$body)
                if($record.sequence -ne ($ledger.Sequence+1) -or $record.previous -cne $ledger.Hash -or $record.hash -cne $hash -or $record.mac -cne (Get-SBLMac $key $hash)){throw 'Ledger authentication or chain verification failed'}
                $event=$body|ConvertFrom-Json
                if($event.version -ne 1){throw 'Unsupported ledger event'}
                $ledger.Events+=,$event;$ledger.Sequence++;$ledger.Hash=$hash
                # Retain prefix hashes to validate a crash-stale durable head.
                $ledger['Prefix'+$ledger.Sequence]=$hash
            }
        }
        if(Test-Path -LiteralPath $headPath){
            $head=Read-SBState $headPath
            $unsigned=[ordered]@{hash=$head.hash;sequence=[long]$head.sequence}
            if($head.mac -cne (Get-SBLMac $key (Get-SBJson $unsigned))){throw 'Ledger head authentication failed'}
            $expected=if($head.sequence -eq 0){'0'*64}else{$ledger['Prefix'+$head.sequence]}
            if($head.sequence -gt $ledger.Sequence -or $head.hash -cne $expected){throw 'Ledger rollback detected'}
        }
        Write-SBLHead $ledger
        return $ledger
    } catch {$lock.Dispose();throw}
}
function Close-SBLedger($ledger) {if($ledger){try{$ledger.Lock.Unlock(0,1)}finally{$ledger.Lock.Dispose()}}}
function Store-SBLState($ledger,$value) {
    $raw=Get-SBJson $value
    if([Text.Encoding]::UTF8.GetByteCount($raw) -gt 67108864){throw 'Exact state exceeds the ledger evidence limit'}
    $hash=Get-SBHash $raw
    $path=Join-Path (Join-Path $ledger.Root 'states') $hash
    if(Test-Path -LiteralPath $path){Test-SBPrivate $path;if((Get-SBHash ([IO.File]::ReadAllText($path))) -cne $hash){throw 'Ledger state blob was modified'}}
    else{Write-SBText $path $raw}
    return $hash
}
function Write-SBLEvent($ledger,[string]$kind,$fields) {
    $body=[ordered]@{version=1;kind=$kind;time_ns=([DateTime]::UtcNow.Ticks-621355968000000000)*100;host=$env:COMPUTERNAME}
    foreach($key in $fields.Keys){$body[$key]=$fields[$key]}
    $raw=Get-SBJson $body
    $hash=Get-SBHash ($ledger.Hash+$raw)
    $record=[ordered]@{sequence=$ledger.Sequence+1;previous=$ledger.Hash;payload=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($raw));hash=$hash;mac=(Get-SBLMac $ledger.Key $hash)}
    $bytes=[Text.Encoding]::UTF8.GetBytes((Get-SBJson $record)+"`n")
    if($bytes.Length -gt 1048576){throw 'Oversized ledger event'}
    $path=Join-Path $ledger.Root 'events.jsonl'
    $file=[IO.File]::Open($path,'Append','Write','Read')
    try{$file.Write($bytes,0,$bytes.Length);$file.Flush($true)}finally{$file.Dispose()}
    Set-SBPrivateAcl $path $false
    $ledger.Sequence++;$ledger.Hash=$hash;$ledger.Events+=,([PSCustomObject]$body)
    Write-SBLHead $ledger
}
function Test-SBLPaused($ledger) {
    $paused=$false
    foreach($event in $ledger.Events){if($event.kind -eq 'withdrawal_pause'){$paused=$true}elseif($event.kind -eq 'withdrawal_review_cancelled'){$paused=$false}}
    return $paused
}
function Prepare-SBLSetup($ledger,$spec,[string]$token,$before) {
    if(Test-SBLPaused $ledger){throw 'Emergency withdrawal paused setup mutations'}
    $id='setup-'+$token
    if(@($ledger.Events|Where-Object {$_.action_id -ceq $id}).Count){throw 'Ledger action cannot be replayed'}
    $objects=@()
    if($spec.service){$objects+='service:'+$spec.service.ToLowerInvariant()}
    if($spec.recipe -eq 'windows-firewall'){foreach($rule in $spec.rules){$objects+='firewall:'+$rule.ToLowerInvariant()}}
    if($spec.recipe -eq 'windows-iis'){$objects+='iis:'+$spec.name.ToLowerInvariant()}
    $dependencies=@()
    foreach($event in $ledger.Events|Where-Object {$_.kind -eq 'prepared'}){
        if(@($event.target.objects|Where-Object {$_ -in $objects}).Count){
            $last=@($ledger.Events|Where-Object {$_.action_id -ceq $event.action_id -and $_.kind -in @('prepared','applied','committed','uncertain','conflict','undo_prepared','undone','cancelled')})[-1]
            if($last.kind -notin @('committed','undone','cancelled')){throw 'Earlier object ownership requires reconciliation'}
            if($last.kind -eq 'committed'){$dependencies+=,$event.action_id}
        }
    }
    Write-SBLEvent $ledger 'prepared' @{action_id=$id;adapter='setup-windows-v1';target=@{spec=$spec;token=$token;objects=$objects};
        before_hash=(Store-SBLState $ledger $before);ownership='configuration';dependencies=$dependencies;
        inverse=@{adapter='setup-windows-v1';operation='restore_exact_pre_state'};context=$spec.ledger_context;another_actor_modified=$false}
}
