"""Finite, explicitly authorized service recovery during controller outages.

One agent process owns native execution. Durable epochs fence stale controllers;
all enrolled agents must reconcile before a newly started controller dispatches.
No policy grants a shell, configuration repair, new baseline or enrollment.
"""
from __future__ import annotations
import hashlib
import json
import logging
import math
import os
from pathlib import Path
import time
import uuid

from . import recovery as r
from .json_codec import canonical_json_bytes
from .probe_evidence import probe_name
from .mutation_ledger import MutationLedger, canonical, ZERO
from .service_recovery import ServiceRecoveryPlanner, recovery_contract

LOG = logging.getLogger(__name__)
MAX_EVENTS = 512
MAX_EVENT_BYTES = 60 * 1024
MAX_APPROVED_BASELINE_BYTES = 2_000_000
LEASE_SECONDS = 30
# Offline authority is judged by wall-clock bounds, so the agent's clock must
# agree with the controller's this closely for the agent to accept it.
OFFLINE_CLOCK_AGREEMENT = 5
# Controller-signed online work is accepted up to this clock difference; it
# stays below the agent authentication window and the default 300 s action
# lifetime, so a leased action is still valid on the agent's clock.
MAX_ONLINE_CLOCK_SKEW = 240
# A clock report wider than this (a very slow sync) says too little to use.
MAX_CLOCK_REPORT_WIDTH = 60


def clock_bounds(sent, received, server_time):
    """The agent-minus-controller clock difference, bounded by one round trip.

    The controller stamped server_time between this agent sending at `sent`
    and receiving at `received` (both on the agent's clock), so the true
    difference lies in [sent - server_time, received - server_time]. Network
    delay can only widen the interval; it can never exclude the true value.
    """
    return sent - server_time, received - server_time


def clock_agreement(low, high, limit=OFFLINE_CLOCK_AGREEMENT):
    """'agree', 'differ' or 'unknown' for |difference| <= limit, given bounds."""
    if max(abs(low), abs(high)) <= limit:
        return 'agree'
    if low > limit or high < -limit:
        return 'differ'
    return 'unknown'


POLICY_SCHEMA = 2
# The first release whose agent accepts each offline policy schema.
MINIMUM_POLICY_SCHEMA_VERSIONS = {1: '1.9.74', 2: '1.9.75'}


def _release_order(text):
    """Order dotted release identifiers; unknown or malformed text sorts lowest."""
    if not isinstance(text, str):
        return None
    parts = text.strip().split('.')
    if not 1 <= len(parts) <= 4 or any(not part.isdigit() or len(part) > 6 for part in parts):
        return None
    return tuple(int(part) for part in parts) + (0,) * (4 - len(parts))


def supports_policy_schema(agent_version, schema):
    """Report whether an enrolled agent release can parse this policy schema."""
    required = _release_order(MINIMUM_POLICY_SCHEMA_VERSIONS[schema])
    reported = _release_order(agent_version)
    return reported is not None and reported >= required


def token_key(token):
    return hashlib.sha256(b'sentinel-continuity-token\0' + token.encode()).digest()


def encode(value):
    return canonical_json_bytes(value, max_bytes=MAX_EVENT_BYTES)


def approved_baseline_hash(baseline):
    # Native inventory includes processes and firewall state; it is much larger
    # than a bounded restart policy. Retain its exact approval identity without
    # copying unrelated inventory into every journal intent.
    return hashlib.sha256(canonical_json_bytes(
        baseline, max_bytes=MAX_APPROVED_BASELINE_BYTES)).hexdigest()


def restart_baseline(baseline, contracts):
    services = set(contracts)
    files, accounts = set(), set()
    for contract in contracts.values():
        services.update(contract['dependencies'])
        files.update(contract['files'])
        accounts.update(contract['required_accounts'])
    from .service_recovery import _one

    def _required(rows, key, value, label):
        try:
            return _one(rows, key, value)
        except ValueError:
            raise ValueError(
                f'The approved baseline does not cover {label} {value!r} required by this service '
                'contract; approve a baseline collected with that item present') from None

    result = {name: baseline[name] for name in (
        'agent_id', 'hostname', 'platform', 'observed_at', 'boot_id', 'sequence',
        'collector_errors', 'collector_issue_sources') if name in baseline}
    result['services'] = [_required(baseline.get('services', []), 'name', name, 'service')
                          for name in sorted(services)]
    result['integrity'] = [_required(baseline.get('integrity', []), 'path', name, 'protected file')
                           for name in sorted(files)]
    result['accounts'] = [_required(baseline.get('accounts', []), 'name', name, 'account')
                          for name in sorted(accounts)]
    probes = [probe for contract in contracts.values()
              for probe in [*contract['probes'], *contract['dependency_probes']]]
    result['probes'] = [row for row in baseline.get('probes', []) if any(
        row.get('name') == probe_name(probe)
        and row.get('target') == probe.get('target') for probe in probes)]
    encode(result)  # Large approved dependency sets still fail closed.
    return result


def read_state(store, key, default=None):
    with store._lock:
        row = store._connection.execute('SELECT state_value FROM controller_state WHERE state_key=?', (key,)).fetchone()
    return json.loads(row[0]) if row else default


def put_state(store, key, value):
    store._connection.execute('INSERT OR REPLACE INTO controller_state VALUES (?,?,?)',
                              (key, encode(value).decode(), time.time()))


def authority_order(value):
    if (not isinstance(value, dict) or set(value) != {'instance', 'generation', 'epoch', 'holder'}
            or type(value['generation']) is not int or type(value['epoch']) is not int
            or not 1 <= value['generation'] < 2**63 or not 1 <= value['epoch'] < 2**63
            or any(not isinstance(value[x], str) or len(value[x]) > 64 for x in ('instance', 'holder'))):
        raise ValueError('Invalid continuity authority')
    uuid.UUID(value['instance'])
    uuid.UUID(value['holder'])
    return value['generation'], value['epoch']


def verify_policy(record, key, profile, agent_id, authority, now):
    policy = r.verify_signed_payload(record, key, purpose='offline-policy')
    required = {'schema', 'id', 'authority', 'agent_id', 'profile_fingerprint', 'services',
                'action_types', 'authorized_by', 'created_at', 'expires_at', 'max_attempts',
                'cooldown_seconds', 'baseline', 'baseline_sha256',
                'contracts', 'validation', 'rollback'}
    # Schema 1 carried the whole approved baseline and pinned it through
    # baseline_sha256 alone. Accept a policy signed by an earlier controller so
    # an upgraded agent keeps its bounded offline authority; every other bound
    # field, signature and expiry check below is unchanged.
    if policy.get('schema') == 2:
        required = required | {'approved_baseline_sha256'}
    elif policy.get('schema') != 1:
        raise ValueError('Unsupported offline policy')
    if set(policy) != required:
        raise ValueError('Unsupported offline policy')
    if policy['schema'] == 1:
        policy = {**policy, 'approved_baseline_sha256': policy['baseline_sha256']}
    uuid.UUID(policy['id'])
    if (policy['authority'] != authority or policy['agent_id'] != agent_id
            or policy['profile_fingerprint'] != profile.fingerprint
            or policy['action_types'] != ['restart_service']
            or not isinstance(policy['baseline'], dict) or policy['baseline'].get('agent_id') != agent_id
            or not isinstance(policy['authorized_by'], str) or not 1 <= len(policy['authorized_by']) <= 128
            or type(policy['max_attempts']) is not int or not 1 <= policy['max_attempts'] <= 3
            or type(policy['cooldown_seconds']) is not int or not 300 <= policy['cooldown_seconds'] <= 3600
            or any(type(policy[n]) not in (int, float) or not math.isfinite(policy[n]) for n in ('created_at', 'expires_at'))
            or not 0 < policy['expires_at'] - policy['created_at'] <= 3600
            or not policy['created_at'] <= now < policy['expires_at']
            or policy['validation'] != 'manifest-probes-and-stable-health'
            or policy['rollback'] != 'exact-owned-service-state-otherwise-hold'
            or not isinstance(policy['approved_baseline_sha256'], str)
            or len(policy['approved_baseline_sha256']) != 64
            or any(c not in '0123456789abcdef' for c in policy['approved_baseline_sha256'])
            or hashlib.sha256(encode(policy['baseline'])).hexdigest() != policy['baseline_sha256']):
        raise ValueError('Offline authority expired, unbound or unsupported')
    services = policy['services']
    if (not isinstance(services, list) or not 1 <= len(services) <= 16
            or len(set(services)) != len(services)
            or not profile.action_allowed('restart_service', automated=True,
                                          autonomy_mode=profile.autonomy_mode)):
        raise ValueError('Offline scope is not explicitly approved')
    if policy['contracts'] != {service: recovery_contract(profile, agent_id, service) for service in services}:
        raise ValueError('Offline dependencies or validation contract changed')
    from .recovery_limits import normalize_attempt_limits
    for service in services:
        manifest = next(x for x in profile.services if x['host'] == agent_id and x['service_id'] == service)
        limits = normalize_attempt_limits(manifest.get('repair_policy', {}).get('attempt_limits'))
        if policy['max_attempts'] > limits['maximum_attempts']:
            raise ValueError('Offline policy exceeds an approved service retry limit')
    return policy


class ControllerContinuity:
    def __init__(self, app):
        self.app, self.store = app, app.store
        identity = self.store.recovery_identity()
        with self.store._lock:
            previous = read_state(self.store, 'continuity_authority', {'epoch': 0})
            self.authority = {'instance': identity['controller_instance_id'],
                              'generation': identity['recovery_generation'],
                              'epoch': previous['epoch'] + 1, 'holder': str(uuid.uuid4())}
            authority_order(self.authority)
            put_state(self.store, 'continuity_authority', self.authority)
            self.store._connection.commit()

    def _row(self, agent):
        return read_state(self.store, 'continuity_agent:' + agent,
                          {'head': {'sequence': 0, 'hash': ZERO}, 'reconciled': False,
                           'authority': None, 'held': 'awaiting complete journal'})

    def ready(self, agent=None):
        with self.store._lock:
            agents = [x[0] for x in self.store._connection.execute("SELECT agent_id FROM agents WHERE enabled=1 AND agent_id != 'sentinel-relay-probes'")]
            if agent is not None and agent not in agents:
                return False
            # A recovered/new process has no changing authority until every
            # currently enrolled participant has durably accepted this epoch.
            return all(self._row(a).get('authority') == self.authority
                       and self._row(a).get('reconciled') is True for a in agents)

    def status(self):
        with self.store._lock:
            agents = [x[0] for x in self.store._connection.execute("SELECT agent_id FROM agents WHERE agent_id != 'sentinel-relay-probes'")]
        rows = []
        now = time.time()
        for agent in agents:
            row = self._row(agent)
            policy = read_state(self.store, 'offline_policy:' + agent)
            expiry = policy['signed']['expires_at'] if policy else None
            connected = now - row.get('last_seen', 0) <= LEASE_SECONDS + 5
            rows.append({'agent_id': agent, **row, 'connected': connected,
                         'offline_policy_expires_at': expiry,
                         'connection_status': 'connected' if connected else
                            'disconnected; pre-authorized offline policy may be active' if expiry and now < expiry else
                            'disconnected; no current offline authorization'})
        return {'authority': self.authority, 'network_reconciled': self.ready(), 'agents': rows}

    def authorize(self, payload):
        if set(payload) != {'agent_id', 'services', 'duration_seconds', 'max_attempts', 'cooldown_seconds'}:
            raise ValueError('Offline approval requires exact scope, duration and budgets')
        app, now = self.app, time.time()
        agent = payload['agent_id']
        if not isinstance(agent, str) or not app.store.agent_enabled(agent):
            raise ValueError('Offline agent is not enrolled')
        # The agent refuses offline authority unless its clock agrees with this
        # controller's (2.0.17); say so while an operator is present.
        differs = getattr(app, 'agent_clock_differs', lambda _agent: None)(agent)
        if differs is not None:
            raise ValueError(f'Agent {agent} clock differs from this controller by about {differs:+.0f} s;'
                             f' offline authorization requires agreement within {OFFLINE_CLOCK_AGREEMENT} s'
                             ' (run NTP on both hosts)')
        if (app.emergency_stopped or MutationLedger().automation_paused() or not self.ready(agent)
                or not app.event_profile.action_allowed('restart_service', automated=True,
                                                        autonomy_mode=app.autonomy_mode)):
            raise ValueError('Offline authorization requires reconciled active governance')
        if type(payload['duration_seconds']) is not int or not 60 <= payload['duration_seconds'] <= 3600:
            raise ValueError('Offline authorization duration must be 60..3600 seconds')
        binding = app.store.agent_binding(agent)
        if binding is None:
            raise ValueError('Offline authorization requires an unambiguous enrolled identity')
        # An older agent cannot parse the current policy schema and would refuse
        # the authorization only after losing the controller. Say so here, while
        # an operator is present, instead of issuing unusable offline authority.
        if not supports_policy_schema(binding.get('agent_version'), POLICY_SCHEMA):
            raise ValueError(
                f"Agent {agent} runs Sentinel Blue {binding.get('agent_version') or 'unknown'};"
                f' offline restart authorization requires {MINIMUM_POLICY_SCHEMA_VERSIONS[POLICY_SCHEMA]}'
                ' or newer on that host')
        baseline = app.store.get_baseline(agent, binding)
        if baseline is None or app.store.baseline_status(agent, binding) != 'approved':
            raise ValueError('Offline recovery requires an approved exact baseline')
        services = payload['services']
        if not isinstance(services, list) or not 1 <= len(services) <= 16 or any(not isinstance(x, str) for x in services):
            raise ValueError('Offline approval needs a bounded list of services')
        for service in services:
            manifest = next((x for x in app.event_profile.services if x['host'] == agent and x['service_id'] == service), {})
            # Collectors report "Linux <kernel release>" (R214-02): match the
            # prefix exactly as every other Linux recovery gate does.
            if str(baseline.get('platform', '')).casefold().startswith('linux'):
                from .service_automation import controller_refusal, inverse_readiness
                reason = (controller_refusal(app, agent, 'restart_service', {'service': service})
                          or inverse_readiness(app.event_profile, agent, 'restart_service', {'service': service}))
                if reason:
                    raise ValueError(reason)
            if not app.store.service_recovery_budget_status(agent, service, manifest.get('repair_policy', {}).get('attempt_limits'))['allowed']:
                raise ValueError('Existing recovery budget or unknown action holds this service')
        contracts = {s: recovery_contract(app.event_profile, agent, s) for s in services}
        projected = restart_baseline(baseline, contracts)
        policy = {'schema': 2, 'id': str(uuid.uuid4()), 'authority': self.authority,
                  'agent_id': agent, 'profile_fingerprint': app.event_profile.fingerprint,
                  'services': services, 'action_types': ['restart_service'],
                  'authorized_by': app.operator_principal_id,
                  'created_at': now, 'expires_at': now + payload['duration_seconds'],
                  'max_attempts': payload['max_attempts'], 'cooldown_seconds': payload['cooldown_seconds'],
                  'baseline': projected, 'baseline_sha256': hashlib.sha256(encode(projected)).hexdigest(),
                  'approved_baseline_sha256': approved_baseline_hash(baseline),
                  'contracts': contracts,
                  'validation': 'manifest-probes-and-stable-health',
                  'rollback': 'exact-owned-service-state-otherwise-hold'}
        key = token_key(app.agent_token(agent))
        record = r.sign_payload(policy, key, purpose='offline-policy')
        verify_policy(record, key, app.event_profile, agent, self.authority, now)
        encode(record)
        with self.store._lock:
            put_state(self.store, 'offline_policy:' + agent, record)
            self.store._connection.commit()
        return {'authorized': True, 'policy_id': policy['id'], 'expires_at': policy['expires_at']}

    def revoke(self):
        with self.store._lock:
            self.store._connection.execute("DELETE FROM controller_state WHERE state_key LIKE 'offline_policy:%'")
            self.store._connection.commit()

    def _import_event(self, agent, event):
        from .validation import validate_action_request, validate_action_result
        from .store import _require_success_result_contract
        if event['kind'] == 'offline_intent':
            policy_record = event['policy']
            policy = r.verify_signed_payload(policy_record, token_key(self.app.agent_token(agent)), purpose='offline-policy')
            verify_policy(policy_record, token_key(self.app.agent_token(agent)), self.app.event_profile,
                          agent, policy['authority'], event['at'])
            action = validate_action_request(event['action'], expected_agent_id=agent,
                         expected_profile_id=self.app.event_profile.profile_id,
                         expected_profile_fingerprint=self.app.event_profile.fingerprint,
                         expected_autonomy_mode=self.app.event_profile.autonomy_mode,
                         require_binding=True, now=event['at'])
            if action['parameters']['service'] not in policy['services'] or action['action_type'] != 'restart_service':
                raise ValueError('Offline journal contains unapproved action scope')
            db = self.store._connection
            for queued in db.execute("SELECT action_id,parameters_json FROM actions WHERE agent_id=? AND status='queued'", (agent,)).fetchall():
                parameters = json.loads(queued['parameters_json'])
                if parameters.get('service') == action['parameters']['service']:
                    db.execute("UPDATE actions SET status='failed',completed_at=?,result_json=?,result_source='controller' WHERE action_id=?",
                               (time.time(), json.dumps({'success': False, 'message': 'Offline recovery superseded this queued service state; fresh review required'}), queued['action_id']))
            if db.execute('SELECT 1 FROM actions WHERE action_id=?', (action['action_id'],)).fetchone():
                raise ValueError('Offline action identity collides with controller state')
            from .validation import canonical_action_envelope_sha256
            binding = self.store.agent_binding(agent) or {}
            db.execute('''INSERT INTO actions(action_id,agent_id,action_type,parameters_json,status,
                         created_at,automated,risk,expires_at,profile_id,profile_fingerprint,
                         autonomy_mode,credential_epoch,agent_version,envelope_sha256,result_source)
                         VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                       (action['action_id'], agent, action['action_type'], json.dumps(action['parameters']),
                        'outcome_unknown', action['created_at'], 1, action['risk'], action['expires_at'],
                        action['profile_id'], action['profile_fingerprint'], action['autonomy_mode'],
                        binding.get('credential_epoch', -1), binding.get('agent_version', ''),
                        canonical_action_envelope_sha256(action), 'agent-offline'))
        elif event['kind'] == 'offline_result':
            result = validate_action_result(event['result'], require_envelope_sha256=True)
            row = self.store._connection.execute('SELECT * FROM actions WHERE action_id=? AND agent_id=?',
                                                 (result['action_id'], agent)).fetchone()
            if row is None or row['result_source'] != 'agent-offline' or row['status'] != 'outcome_unknown':
                raise ValueError('Offline result has no matching durable intent')
            if row['envelope_sha256'] != result['action_envelope_sha256']:
                raise ValueError('Offline result envelope differs')
            if result.get('success'):
                _require_success_result_contract(row['action_type'], json.loads(row['parameters_json']), result)
            unknown = result.get('interrupted') or result.get('outcome_unknown')
            state = 'outcome_unknown' if unknown else 'completed' if result['success'] else 'failed'
            self.store._connection.execute('UPDATE actions SET status=?,result_json=?,completed_at=? WHERE action_id=?',
                                            (state, json.dumps(result), result['completed_at'], row['action_id']))
        else:
            raise ValueError('Unsupported offline journal event')

    def sync(self, agent, payload):
        fields = {'nonce', 'authority', 'head', 'events', 'online_unresolved', 'ledger_head', 'status'}
        # 2.0.17 agents add 'clock': the bounds on their clock difference that
        # they measured on their previous sync (review bug 9).
        if set(payload) not in (fields, fields | {'clock'}):
            raise ValueError('Continuity handshake fields differ')
        report = payload.get('clock')
        if report is not None and (
                not isinstance(report, list) or len(report) != 2
                or any(type(v) not in (int, float) or not math.isfinite(v) for v in report)
                or not report[0] <= report[1]):
            # The report only informs freshness; without it the controller
            # is as strict as before 2.0.17. Never refuse the sync over it.
            LOG.warning('agent %s sent an unusable continuity clock report; ignored', agent)
            report = None
        if not isinstance(payload['nonce'], str) or len(payload['nonce']) != 32:
            raise ValueError('Invalid continuity nonce')
        if type(payload['online_unresolved']) is not bool or not isinstance(payload['status'], str) or len(payload['status']) > 256:
            raise ValueError('Malformed continuity status')
        for head in (payload['head'], payload['ledger_head']):
            if (not isinstance(head, dict) or set(head) != {'sequence', 'hash'}
                    or type(head['sequence']) is not int or head['sequence'] < 0
                    or not isinstance(head['hash'], str) or len(head['hash']) != 64
                    or any(c not in '0123456789abcdef' for c in head['hash'])):
                raise ValueError('Malformed journal checkpoint')
        incoming = payload['authority']
        if incoming is not None:
            old = authority_order(incoming)
            new = authority_order(self.authority)
            if incoming['instance'] != self.authority['instance'] or old > new or (old == new and incoming != self.authority):
                raise ValueError('Stale or competing controller authority')
        events = payload['events']
        if not isinstance(events, list) or len(events) > 16:
            raise ValueError('Offline journal batch exceeds capacity')
        with self.store._lock:
            self.store._connection.execute('BEGIN IMMEDIATE')
            try:
                row = self._row(agent)
                head = row['head']
                if events and type(events[0].get('sequence')) is int and events[0]['sequence'] > head['sequence'] + 1:
                    events = []  # Restored receipt floor: request the retained missing prefix.
                for event in events:
                    encode(event)
                    sequence = event['sequence']
                    if type(sequence) is not int or not 1 <= sequence <= MAX_EVENTS:
                        raise ValueError('Invalid offline journal sequence')
                    event_key = f'continuity_event:{agent}:{sequence}'
                    if sequence <= head['sequence']:
                        if read_state(self.store, event_key) != event:
                            raise ValueError('Offline journal replay changed')
                        continue
                    body = {k: v for k, v in event.items() if k not in {'sequence', 'hash'}}
                    hashed = hashlib.sha256(head['hash'].encode() + canonical(body)).hexdigest()
                    if sequence != head['sequence'] + 1 or event['hash'] != hashed:
                        raise ValueError('Offline journal chain is incomplete or tampered')
                    self._import_event(agent, event)
                    put_state(self.store, event_key, event)
                    head = {'sequence': sequence, 'hash': hashed}
                complete = head == payload['head']
                unresolved = self.store._connection.execute(
                    "SELECT COUNT(*) FROM actions WHERE agent_id=? AND status IN ('dispatched','outcome_unknown')", (agent,)).fetchone()[0]
                held = ('incomplete offline journal' if not complete else 'unknown action outcome'
                        if unresolved or payload['online_unresolved'] else '')
                row = {'head': head, 'reconciled': not held, 'held': held,
                       'authority': self.authority if incoming == self.authority else None,
                       'last_seen': time.time(), 'agent_status': str(payload['status'])[:256],
                       'ledger_head': payload['ledger_head']}
                put_state(self.store, 'continuity_agent:' + agent, row)
                restored = read_state(self.store, 'recovery_receipt')
                if restored and not held and incoming == self.authority:
                    restored['agents_pending_reconciliation'] = [a for a in restored['agents_pending_reconciliation'] if a != agent]
                    if not restored['agents_pending_reconciliation']:
                        restored['status'] = 'journals-reconciled; operator Resume required'
                    put_state(self.store, 'recovery_receipt', restored)
                self.store._connection.commit()
            except BaseException:
                self.store._connection.rollback()
                raise
        if report is not None and hasattr(self.app, 'note_agent_clock_bounds'):
            self.app.note_agent_clock_bounds(agent, float(report[0]), float(report[1]))
        policy = read_state(self.store, 'offline_policy:' + agent)
        paused = self.app.emergency_stopped or MutationLedger().automation_paused() or bool(held)
        if policy:
            try:
                decoded = verify_policy(policy, token_key(self.app.agent_token(agent)), self.app.event_profile,
                                        agent, self.authority, time.time())
                binding = self.store.agent_binding(agent)
                baseline = self.store.get_baseline(agent, binding)
                if (self.store.baseline_status(agent, binding) != 'approved'
                        or approved_baseline_hash(baseline) != decoded['approved_baseline_sha256']):
                    raise ValueError('Approved offline baseline changed')
            except (ValueError, KeyError, TypeError):
                policy = None
        now = time.time()
        return {'nonce': payload['nonce'], 'authority': self.authority, 'server_time': now,
                'lease_until': now + LEASE_SECONDS, 'ack': head, 'paused': paused,
                'reconciled': not held and incoming == self.authority,
                'policy': policy if not paused else None}


class AgentContinuity:
    def __init__(self, state_dir, profile, agent_id, token, *, ledger=None):
        self.directory = Path(state_dir) / 'continuity'
        from .state import ActionJournal
        execution = self.directory / "execution"
        for directory in (self.directory, execution):
            if os.name == 'nt':
                # These are descendants of the live agent's pinned state tree.
                # Python 3.13 mkdir(0700) adds an OWNER RIGHTS ACE and would make
                # the next whole-tree health check hold all native execution.
                # Existing unexpected ACLs still require review; do not reset them.
                from .win_state import acquire_windows_state_tree
                guard = acquire_windows_state_tree(directory, initialize=True)
                if guard is not None:
                    guard.close()
            else:
                directory.mkdir(mode=0o700, exist_ok=True)
        self.actions = ActionJournal(execution, profile_fingerprint=profile.fingerprint)
        self.journal = MutationLedger(self.directory / 'journal', host=agent_id)
        self.ledger = ledger or MutationLedger()
        self.path = self.directory / 'authority.json'
        self.key, self.profile, self.agent_id = token_key(token), profile, agent_id
        self.planner = ServiceRecoveryPlanner(profile, restart_only=True)
        self.state = (r._read_signed_document(self.path, self.key, purpose='continuity-state', maximum=MAX_EVENT_BYTES)
                      if self.path.exists() else {'authority': None, 'lease_until': 0, 'paused': True,
                                                 'policy': None, 'ack': {'sequence': 0, 'hash': ZERO}, 'last_clock': 0})
        # The ledger is host-wide and outlives any one deployment, so a floor
        # belongs to the deployment that recorded it: this agent identity under
        # this approved profile. A restored or competing controller of the SAME
        # deployment is still fenced by it. A new reviewed deployment on the same
        # host (a new local session, a re-approved profile) starts its own
        # lineage instead of being refused forever by the previous one's
        # controller. Floors written before 2.0.4 name no profile; they belong
        # to a deployment whose profile, by construction, is not this one.
        floors = [e['authority'] for e in self.ledger.read()
                  if e['kind'] == 'continuity_authority' and e.get('agent_id') == agent_id
                  and e.get('profile_fingerprint') == profile.fingerprint]
        if floors:
            floor = floors[-1]
            saved = self.state['authority']
            if saved is None or authority_order(saved) < authority_order(floor):
                self.state.update(authority=floor, policy=None, paused=True, lease_until=0)
                self._save()
            elif saved['instance'] != floor['instance'] or (authority_order(saved) == authority_order(floor) and saved != floor):
                raise ValueError('Agent authority differs from its durable ledger floor')
        self.status = 'awaiting authenticated authority' 
        self._monotonic = time.monotonic()
        self._wall = time.time()
        # [low, high] bounds on this clock minus the controller's, from the
        # last sync; sent with the next sync so the controller can judge
        # telemetry freshness on this clock (2.0.17, review bug 9).
        self.clock_bound = None
        self.online = False

    def _save(self):
        r._write_signed_document(self.path, self.state, self.key, purpose='continuity-state',
                                 maximum=MAX_EVENT_BYTES)

    def _clock(self, *, online=False):
        """Return wall time, answering a clock step by revoking offline authority.

        The offline policy's expiry, the online lease and the offline cooldown
        are all wall-clock bounds, so a step (an NTP/chrony correction, ``date
        -s``) voids them. The step revokes the policy and the lease and
        re-baselines the clock. Offline callers are refused
        for that sample and then stay without authority until a fresh signed
        sync, which requires the controller's clock to agree within 5 s.
        Online callers continue: controller-signed work does not depend on
        the offline clock, so a step no longer stops it until the agent
        restarts; at most the one fetch that straddles the step is refused.
        """
        now, monotonic = time.time(), time.monotonic()
        drift = (now - self._wall) - (monotonic - self._monotonic)
        if now < self.state['last_clock'] - 2 or abs(drift) > 5:
            LOG.warning('wall clock stepped by about %.0f s; offline authority revoked until the next controller sync',
                        drift if abs(drift) > 5 else now - self.state['last_clock'])
            self._wall, self._monotonic = now, monotonic
            # Without a policy and a lease nothing runs offline, and online
            # commands need a new sync (which sets online) first.
            self.state.update(policy=None, lease_until=0, last_clock=now)
            self.clock_bound = None
            self.online = False
            self.status = 'held: clock step revoked offline authority; waiting for a controller sync'
            self._save()
            if not online:
                raise ValueError('Clock discontinuity holds offline authority')
        self.state['last_clock'] = max(now, self.state['last_clock'])
        return now

    def sync(self, client, action_journal):
        self.online = False
        if self.ledger.paused():
            self.status = 'held: emergency Withdraw'
            raise ValueError('Withdraw prevents continuity authority updates')
        now = self._clock(online=True)
        events = self.journal.read()
        ack = self.state['ack']
        self.journal.read(pinned=ack)
        nonce = uuid.uuid4().hex
        unresolved = any(v.get('status') == 'in_progress' or
                         (v.get('result', {}).get('interrupted') is True)
                         for v in action_journal._records.values())
        unresolved = unresolved or any(a['status'] in {'prepared','applied','uncertain','undo_prepared','boot_prepared','quiesce_prepared'} for a in self.ledger.actions())
        payload = {'nonce': nonce, 'authority': self.state['authority'],
                   'head': self.journal.head(), 'events': events[ack['sequence']:ack['sequence'] + 16],
                   'online_unresolved': unresolved, 'ledger_head': self.ledger.head(), 'status': self.status,
                   'clock': self.clock_bound}
        sent, sent_monotonic = time.time(), time.monotonic()
        response = client._request('POST', '/api/v1/agent/continuity', payload)
        received, received_monotonic = time.time(), time.monotonic()
        if (not isinstance(response, dict) or response.get('nonce') != nonce
                or type(response.get('paused')) is not bool or type(response.get('reconciled')) is not bool
                or any(type(response.get(n)) not in (int, float) or not math.isfinite(response[n]) for n in ('server_time', 'lease_until'))):
            raise ValueError('Malformed or stale continuity response')
        # 2.0.17 (review bug 9): the controller's clock may differ from this
        # one. The round trip bounds the difference; network delay only
        # widens the bounds. A clock step during the request voids them.
        if received < sent or abs((received - sent) - (received_monotonic - sent_monotonic)) > 1:
            self.clock_bound = None
            raise ValueError('Clock changed during the continuity sync')
        low, high = clock_bounds(sent, received, response['server_time'])
        if max(abs(low), abs(high)) > MAX_ONLINE_CLOCK_SKEW:
            raise ValueError('Malformed or stale continuity response')
        self.clock_bound = [round(low, 3), round(high, 3)] if high - low <= MAX_CLOCK_REPORT_WIDTH else None
        # The lease is kept on this clock, using the bound that ends it
        # soonest: it expires LEASE_SECONDS after this request was sent.
        lease_until = response['lease_until'] + low
        if not received < lease_until <= received + LEASE_SECONDS + 5:
            raise ValueError('Malformed or stale continuity response')
        incoming, prior = response['authority'], self.state['authority']
        new = authority_order(incoming)
        if prior:
            old = authority_order(prior)
            if incoming['instance'] != prior['instance'] or new < old or (new == old and incoming != prior):
                raise ValueError('Stale controller cannot regain authority')
        self.journal.read(pinned=response['ack'])
        # Offline authority is judged by wall-clock bounds. A revocation
        # (no policy) always applies. A policy is taken only while the clocks
        # provably agree within OFFLINE_CLOCK_AGREEMENT seconds; if a slow
        # sync leaves that unknown, only the identical policy already held is
        # kept. Clocks that provably differ hold offline authority.
        agreement = clock_agreement(low, high)
        policy = response.get('policy')
        if policy and agreement == 'differ':
            policy = None
        elif policy and agreement == 'unknown' and policy != self.state.get('policy'):
            policy = None
        if policy:
            verify_policy(policy, self.key, self.profile, self.agent_id, incoming, received)
        # Do not hold admission while waiting on the network. Recheck it after
        # the response, then flush the authority and its state under one lock.
        # Withdrawal must drain this writer before pinning the review's head.
        with self.ledger.lock():
            if self.ledger.paused():
                self.status = 'held: emergency Withdraw'
                raise ValueError('Withdraw prevents continuity authority updates')
            if prior != incoming:
                self.ledger.append('continuity_authority', agent_id=self.agent_id,
                                   profile_fingerprint=self.profile.fingerprint, authority=incoming)
            # A restored DB may acknowledge fewer retained events. Upload the
            # full journal again, but never replay its mutations.
            self.state.update(authority=incoming, lease_until=lease_until,
                              paused=response['paused'], ack=response['ack'], policy=policy)
            self._save()
            self.online = response['reconciled']
            self.status = 'online reconciled' if self.online else 'held: controller reconciliation or Pause'
            if agreement == 'differ':
                self.status += (f'; offline authority held: this clock is about {(low + high) / 2:+.0f} s from the'
                                f' controller (must be within {OFFLINE_CLOCK_AGREEMENT} s)')[:200]
        return response

    def accept_online(self, authority, actions=()):
        if (not self.online or authority != self.state['authority']
                or self._clock(online=True) >= self.state['lease_until'] or self.ledger.paused()):
            raise ValueError('Online command lacks the current reconciled authority lease')
        from .event_profile import EMERGENCY_ALLOWED_ACTIONS
        if (self.state['paused'] or self.ledger.automation_paused()) and any(
                action.get('action_type') not in EMERGENCY_ALLOWED_ACTIONS for action in actions):
            raise ValueError('Pause admits only the existing explicit emergency rollback actions')

    def run_offline(self, journal, executor, telemetry, health):
        from .agent import execute_queued_action
        from .policy import action_risk
        from .mutation_tracking import active, action_context
        now = self._clock()
        self._save()
        if self.online and now < self.state['lease_until']:
            return 0
        self.online = False
        if now < self.state['lease_until']:
            self.status = 'disconnected; waiting for online lease expiry'
            return 0
        if self.state['paused'] or self.ledger.automation_paused():
            self.status = 'held: Pause or Withdraw'
            return 0
        if not self.state['policy']:
            self.status = 'disconnected; no pre-authorized offline policy'
            return 0
        try:
            policy = verify_policy(self.state['policy'], self.key, self.profile, self.agent_id, self.state['authority'], now)
            if not active() or not health.get('action_safe') or not journal.healthy or executor.allow_service_recovery is not True:
                raise ValueError('Healthy durable mutation tracking is required')
            if any(v.get('status') == 'in_progress' or v.get('result', {}).get('interrupted')
                   for v in journal._records.values()):
                raise ValueError('Unknown prior online action holds offline work')
            if any(a['status'] in {'prepared', 'applied', 'uncertain', 'undo_prepared', 'boot_prepared', 'quiesce_prepared'}
                   for a in self.ledger.actions()):
                raise ValueError('Unknown mutation ledger outcome holds offline work')
            events = self.journal.read()
            if len(events) > MAX_EVENTS - 2:
                raise ValueError('Offline evidence journal capacity exhausted')
            intents = {e['action']['action_id']: e for e in events if e['kind'] == 'offline_intent'}
            results = {e['result']['action_id']: e['result'] for e in events if e['kind'] == 'offline_result'}
            if set(intents) != set(results) or any(x.get('interrupted') or x.get('outcome_unknown') for x in results.values()):
                raise ValueError('Unknown offline outcome requires review; replay forbidden')
            attempts = [e for e in intents.values() if e['policy']['signed']['id'] == policy['id']]
            if len(attempts) >= policy['max_attempts']:
                raise ValueError('Offline retry budget exhausted')
            if attempts and now - max(e['at'] for e in attempts) < policy['cooldown_seconds']:
                raise ValueError('Offline cooldown has not elapsed')
            candidates = self.planner.observe(self.agent_id, policy['baseline'], True, telemetry)
            if str(telemetry.get('platform', '')).casefold().startswith('linux'):  # R214-02
                from .service_automation import LocalAutomation
                control = LocalAutomation(executor.state_dir, self.profile, self.agent_id)
                held = {s: control.refusal('restart_service', p) for s, p in candidates.items()}
                candidates = {s: p for s, p in candidates.items() if not held[s]}
                if not candidates and any(held.values()):
                    self.status = next(reason for reason in held.values() if reason)[:256]
                    return 0  # No intent or allowance consumed for a known operator hold.
            service = next((x for x in policy['services'] if x in candidates), None)
            if service is None:
                stopped = any(x.get('name') in policy['services'] and x.get('state') != 'running' for x in telemetry.get('services', []))
                details = '; '.join(x['status'] for x in self.planner.status() if x['service'] in policy['services'])
                self.status = (('held: ' + details) if stopped else 'offline monitoring; approved services running')[:256]
                return 0
            from .recovery_limits import normalize_attempt_limits
            manifest = next(x for x in self.profile.services if x['host'] == self.agent_id and x['service_id'] == service)
            candidates[service]['recovery_guard']['attempt_limits'] = normalize_attempt_limits(manifest.get('repair_policy', {}).get('attempt_limits'))
            action = {'action_id': str(uuid.uuid4()), 'agent_id': self.agent_id,
                      'action_type': 'restart_service', 'parameters': candidates[service],
                      'status': 'dispatched', 'created_at': now, 'automated': True,
                      'risk': action_risk('restart_service'), 'expires_at': min(policy['expires_at'], now + 90),
                      'profile_id': self.profile.profile_id, 'profile_fingerprint': self.profile.fingerprint,
                      'autonomy_mode': self.profile.autonomy_mode}
            evidence = {'policy': self.state['policy'], 'action': action, 'telemetry': telemetry,
                        'at': now, 'ledger_before': self.ledger.head()}
            encode(evidence)
            with self.ledger.lock(), self.journal.lock():
                if self.ledger.automation_paused():
                    raise ValueError('Pause won admission before offline action')
                self.journal.append('offline_intent', **evidence)
                with action_context(offline_policy_id=policy['id'], authorization=policy['authorized_by']):
                    result = execute_queued_action(self.actions, executor, action, telemetry, health, self.profile)
                result = {**result, "action_id": action["action_id"]}
                # Offline results go to this complete journal, not the online
                # result endpoint (which has not yet seen the action identity).
                self.journal.append('offline_result', result=result, at=time.time(), ledger_after=self.ledger.head())
            self.status = 'offline repair completed' if result['success'] else 'offline repair failed; retained for review'
            return 1
        except (ValueError, RuntimeError, KeyError, TypeError) as exc:
            self.status = 'held: ' + str(exc)
            return 0


class HeldContinuity:
    def __init__(self, error):
        self.status = 'held: ' + str(error)[:256]
        self.online = False

    def sync(self, client, journal):
        raise ValueError(self.status)

    def accept_online(self, authority, actions=()):
        raise ValueError(self.status)

    def run_offline(self, *args):
        return 0
