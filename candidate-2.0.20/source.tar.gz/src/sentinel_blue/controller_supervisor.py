"""Own one fixed controller child without changing its recovery authority.

The OS service manager should start this process at boot. Only a stop that this
supervisor was asked for is final. Every other child exit (a crash, a stalled
controller loop, or a signal sent to the child alone, which the controller
answers with a clean exit) is restarted, with a delay that backs off to
MAX_RESTART_DELAY and never gives up (2.0.16: before, five failures in five
minutes, or one SIGTERM to the child, stopped supervision for good). Every
start rechecks the same profile and frozen package; a changed one is a hold.
No saved PID is ever used to signal a process.
"""
from __future__ import annotations

import logging
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time

from .state import read_private_json, write_private_json

LOG = logging.getLogger(__name__)
# Failures within FAILURE_WINDOW set the restart delay: restart_delay doubled per
# recent failure, and MAX_RESTART_DELAY once MAX_FAILURES are recent.
MAX_FAILURES = 5
FAILURE_WINDOW = 300.0
MAX_RESTART_DELAY = 60.0
HEARTBEAT_LIMIT = 120.0


def heartbeat_writer(path, app):
    """Liveness for the supervisor. A failed write (a full or read-only disk)
    is logged, never raised into the server loop: the supervisor then sees a
    stale heartbeat and restarts the controller, instead of the controller
    crashing on every request."""
    last = 0.0
    failure = None

    def beat():
        nonlocal last, failure
        now = time.monotonic()
        if now - last >= 5.0:
            last = now
            try:
                write_private_json(path, {
                    "pid": os.getpid(), "server": now,
                    "maintenance": getattr(app, "maintenance_heartbeat", 0.0),
                })
            except (OSError, ValueError) as exc:
                reason = type(exc).__name__ + ": " + str(exc)[:200]
                if reason != failure:
                    LOG.error("controller heartbeat write failed: %s", reason)
                failure = reason
            else:
                if failure is not None:
                    LOG.warning("controller heartbeat write recovered")
                failure = None
    return beat


def heartbeat_fresh(path, pid, started, now, *, limit=HEARTBEAT_LIMIT):
    try:
        row = read_private_json(path, 4096)
        if not isinstance(row, dict) or set(row) != {"pid", "server", "maintenance"}:
            return False
        if type(row["pid"]) is not int or row["pid"] != pid:
            return False
        return all(type(row[key]) in (int, float) and math.isfinite(row[key])
                   and started <= row[key] <= now and now-row[key] < limit
                   for key in ("server", "maintenance"))
    except (OSError, ValueError, TypeError):
        return False


SUPERVISOR_PID_ENVIRONMENT = "SENTINEL_SUPERVISOR_PID"
PARENT_CHECK_SECONDS = 1.0


def expected_supervisor_pid():
    """The supervisor PID a supervised controller child was started by, or None.

    The variable is removed so nothing the controller starts inherits it.
    """
    value = os.environ.pop(SUPERVISOR_PID_ENVIRONMENT, None)
    if os.name == "nt" or value is None or not value.isdigit():
        return None
    return int(value)


def supervisor_gone(expected):
    return expected is not None and os.getppid() != expected


def watch_supervisor(expected, stop, *, interval=PARENT_CHECK_SECONDS, on_orphaned=None):
    """Ask this controller to stop cleanly once its supervisor has exited.

    The shutdown goes through the controller's own SIGTERM handler, so the
    session marker is cleared exactly as for any requested stop.
    """
    def run():
        while not stop.wait(interval):
            if supervisor_gone(expected):
                LOG.error("controller supervisor %s exited; stopping this controller so a new supervisor"
                          " can start one", expected)
                (on_orphaned or (lambda: os.kill(os.getpid(), signal.SIGTERM)))()
                return
    thread = threading.Thread(target=run, daemon=True, name="sentinel-supervisor-watch")
    thread.start()
    return thread


class OwnedController:
    def __init__(self, command):
        self.job = None
        self.process = None
        try:
            if os.name == "nt":
                from .windows_inventory_host import _OwnedJob
                self.job = _OwnedJob()
            # The child stops itself if this supervisor dies (2.0.17, review
            # bug 6); otherwise it would keep the database lock and block
            # every later supervisor. On Windows the job object does this.
            environment = dict(os.environ)
            if os.name != "nt":
                environment[SUPERVISOR_PID_ENVIRONMENT] = str(os.getpid())
            self.process = subprocess.Popen(
                command, stdin=subprocess.DEVNULL, close_fds=True,
                start_new_session=os.name != "nt", env=environment,
                creationflags=getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0),
            )
            if self.job:
                self.job.assign(self.process)
        except BaseException:
            self.close()
            raise

    def close(self):
        child = self.process
        try:
            if child is not None and child.poll() is None:
                try:
                    if os.name == "nt":
                        child.send_signal(signal.CTRL_BREAK_EVENT)
                    else:
                        os.killpg(child.pid, signal.SIGTERM)
                except (OSError, ValueError):
                    child.terminate()
                try:
                    child.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    if os.name != "nt":
                        os.killpg(child.pid, signal.SIGKILL)
                    else:
                        child.kill()
                    child.wait(timeout=5)
        finally:
            if self.job:
                self.job.close()
                self.job = None


def _recent_failures(status_path):
    """Failure times saved by an earlier supervisor run.

    They only pace restarts. An unreadable, malformed or future history is
    moved aside and restarting continues, instead of stopping supervision.
    """
    if not status_path.exists():
        return []
    try:
        saved = read_private_json(status_path, 16384)
        failures = saved.get("failures") if isinstance(saved, dict) else None
        if not isinstance(failures, list) or any(
            type(value) not in (float, int) or not math.isfinite(value)
            or value > time.time()+5 for value in failures
        ):
            raise ValueError("supervisor failure history is malformed or in the future")
        return [float(value) for value in failures][-MAX_FAILURES:]
    except (OSError, ValueError, TypeError) as exc:
        LOG.error("supervisor state set aside and reset: %s", str(exc)[:200])
        try:
            os.replace(status_path, status_path.with_name(status_path.name + ".invalid"))
        except OSError as moved:
            LOG.error("supervisor state could not be set aside: %s", type(moved).__name__)
        return []


def supervise(command_factory, status_path, heartbeat_path, stop, *,
              child_factory=OwnedController, heartbeat_limit=HEARTBEAT_LIMIT,
              poll_interval=0.5, restart_delay=2.0, max_restart_delay=MAX_RESTART_DELAY):
    """Restart the owned child until a stop is requested; pace restarts only.

    Returns 0 after a requested stop. A changed profile or package (from
    ``command_factory``) and a child that cannot be owned are holds: they are
    raised, never launched.
    """
    failures = _recent_failures(status_path)
    restarts = 0
    status_error = None

    def status(state, **fields):
        # A status write failure (full or read-only disk) must not end
        # supervision; the status file is only a report.
        nonlocal status_error
        try:
            write_private_json(status_path, {"state": state, "failures": failures,
                                             "restarts": restarts, **fields})
        except (OSError, ValueError) as exc:
            reason = type(exc).__name__
            if reason != status_error:
                LOG.error("supervisor status write failed: %s", reason)
            status_error = reason
        else:
            status_error = None

    while not stop.is_set():
        now = time.time()
        failures[:] = [value for value in failures if 0 <= now-value < FAILURE_WINDOW][-MAX_FAILURES:]
        child = None
        started = time.monotonic()
        reason = "controller_exited"
        result = None
        try:
            # A changed package/profile is a hold, never a reason to launch it.
            command = command_factory()
            child = child_factory(command)
        except OSError as exc:
            # Reading the profile or package, or creating the process, can
            # fail transiently (I/O errors, memory or process limits). That
            # is a failed start to retry, not a changed launch authority.
            reason = "controller_start_failed"
            LOG.error("controller start failed: %s", type(exc).__name__)
        except (RuntimeError, ValueError) as exc:
            status("held", reason="controller_preflight_or_ownership_failed",
                   error_type=type(exc).__name__)
            raise
        if child is not None:
            try:
                status("running", child_pid=child.process.pid)
                while child.process.poll() is None and not stop.wait(poll_interval):
                    now_monotonic = time.monotonic()
                    if now_monotonic-started >= heartbeat_limit and not heartbeat_fresh(
                        heartbeat_path, child.process.pid, started, now_monotonic, limit=heartbeat_limit,
                    ):
                        reason = "controller_heartbeat_stale"
                        break
                result = child.process.poll()
            finally:
                child.close()
        if stop.is_set():
            status("stopped", reason="supervisor_stop_requested")
            return 0
        if result == 0 and reason == "controller_exited":
            # The controller exits cleanly on SIGTERM/SIGINT. Only a stop this
            # supervisor was asked for is final; a signal to the child alone
            # (pkill, kill) must not leave the controller down.
            reason = "controller_exited_without_stop_request"
        failures.append(time.time())
        failures[:] = failures[-MAX_FAILURES:]
        restarts += 1
        delay = (max_restart_delay if len(failures) >= MAX_FAILURES
                 else min(max_restart_delay, restart_delay * 2**(len(failures)-1)))
        status("waiting", reason=reason, exit_code=result, retry_in_seconds=round(delay, 3),
               backing_off=len(failures) >= MAX_FAILURES)
        LOG.warning("Controller restart in %.1f s: %s (%s recent failure(s))",
                    delay, reason, len(failures))
        stop.wait(delay)
    status("stopped", reason="supervisor_stop_requested")
    return 0


def run(args):
    from .controller import ControllerDatabaseLock, prepare_controller_directories
    from .event_profile import load_event_profile

    logging.basicConfig(level=getattr(logging, args.log_level.upper()))
    if args.supervisor_child:
        raise ValueError("controller cannot supervise another supervisor")
    runtime = Path(sys.argv[0]).absolute()
    profile = load_event_profile(args.event_profile)
    profile.verify_release_file(runtime)
    prepare_controller_directories(args)
    directory = Path(args.supervisor_directory)
    arguments = [value for value in sys.argv[1:] if value != "--supervise"]
    if not arguments or arguments[0] != "controller":
        raise ValueError("supervision requires the packaged controller entry point")

    def command():
        current = load_event_profile(args.event_profile)
        if current.fingerprint != profile.fingerprint:
            raise ValueError("supervised profile changed; restart requires review")
        current.verify_release_file(runtime)
        from .runtime_environment import python_command
        return [*python_command(), str(runtime), *arguments, "--supervisor-child"]

    stop = threading.Event()
    numbers = [signal.SIGINT, signal.SIGTERM]
    if hasattr(signal, "SIGBREAK"):
        numbers.append(signal.SIGBREAK)
    previous = {number: signal.getsignal(number) for number in numbers}
    with ControllerDatabaseLock(directory / "supervisor"):
        try:
            for number in numbers:
                signal.signal(number, lambda *_: stop.set())
            return supervise(command, directory/"status.json", directory/"heartbeat.json", stop)
        finally:
            for number, handler in previous.items():
                signal.signal(number, handler)
