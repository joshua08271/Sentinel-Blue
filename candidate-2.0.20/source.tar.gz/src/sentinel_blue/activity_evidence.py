"""Record available native audit evidence independently of alert classification.

No audit policy is changed. Coverage gaps and unclassified records are evidence,
not proof that an action was malicious or that all access was observed.
"""
from __future__ import annotations
from collections import OrderedDict
import hashlib
import json
import re
import socket
import threading
import time

_lock = threading.Lock()
_seen = OrderedDict()
MAX_SEEN = 8192


def capture_audit(rows, *, source, available=True, queried=0, limit=512, error_type=None):
    from .recording import emit
    emit('audit_coverage', {'source': source, 'hostname': socket.gethostname(),
        'available': available, 'queried_records': queried, 'record_limit': limit,
        'lookback_seconds': 300, 'possibly_truncated': queried >= limit,
        'audit_policy_verified': False, 'error_type': error_type})
    queue_activity({'kind':'coverage','source':source,'available':available,'queried_records':queried,
        'record_limit':limit,'lookback_seconds':300,'possibly_truncated':queried>=limit,'audit_policy_verified':False,'at':time.time()})
    batch = []
    with _lock:
        for row in rows:
            identity = (source, row.get('event_id'))
            if identity in _seen:
                continue
            _seen[identity] = time.time()
            batch.append(row)
            while len(_seen) > MAX_SEEN:
                _seen.popitem(last=False)
    for row in batch:queue_activity(dict(row,kind='native_audit',source=source))
    for offset in range(0, len(batch), 32):
        emit('native_audit_evidence', {'source': source, 'hostname': socket.gethostname(),
             'events': batch[offset:offset+32]})


def linux_audit_row(row):
    """Select structured audit identity fields; never retain command/message text."""
    message = str(row.get('MESSAGE', ''))[:16384]
    if row.get('_TRANSPORT') != 'audit' and not re.search(r'\b(?:type=(?:SYSCALL|PATH|USER_[A-Z_]+|CRED_[A-Z_]+|[0-9]{4})|audit\([0-9.]+:[0-9]+\))', message):
        return None
    fields = {}
    for key, quoted, bare in re.findall(r'\b(type|pid|ppid|uid|auid|acct|exe|comm|name|addr|success|syscall|perm)=(?:"([^"\n]{0,1024})"|([^\s]{1,1024}))', message):
        fields[key] = quoted or bare
    stamp = str(row.get('__REALTIME_TIMESTAMP', '0'))
    at = int(stamp)/1000000 if stamp.isdigit() else time.time()
    serial = re.search(r'audit\(([0-9.]+:[0-9]+)\)', message)
    stable = str(row.get('_BOOT_ID', ''))+'|'+(serial.group(1) if serial else stamp)+'|'+str(fields.get('type',''))+'|'+str(fields.get('name',''))
    return {'event_id': 'linux-audit-'+hashlib.sha256(stable.encode()).hexdigest()[:32],
        'occurred_at': at, 'category': 'native_audit', 'audit_type': fields.get('type', 'unknown'),
        'actor': fields.get('auid', fields.get('uid', str(row.get('_UID','unknown')))),
        'account': fields.get('acct', 'unknown'), 'path': fields.get('name',''),
        'executable': fields.get('exe',''), 'process_name': fields.get('comm',''),
        'process_id': int(fields['pid']) if fields.get('pid','').isdigit() else None,
        'remote_address': fields.get('addr','unknown'), 'syscall': fields.get('syscall',''),
        'access_mask': fields.get('perm',''), 'outcome': {'yes':'success','no':'failure'}.get(fields.get('success'), 'observed')}


def capture_windows(rows):
    selected = []
    mapping = {'EventId':'event_id','Category':'category','Outcome':'outcome','Account':'account',
        'Actor':'actor','AccountId':'account_id','AccountDomain':'account_domain','RemoteAddress':'remote_address',
        'OccurredAt':'occurred_at','ObjectPath':'path','ProcessName':'executable','ProcessId':'process_id',
        'AccessMask':'access_mask','NativeCode':'native_event_code'}
    for row in rows:
        selected.append({target:row[source] for source,target in mapping.items() if source in row})
    capture_audit(selected,source='windows-security',queried=len(rows),limit=257)

# Evidence is relayed inside the authenticated telemetry envelope as well as
# recorded locally. Bounded buffering exposes loss rather than growing forever.
from collections import deque
_pending = deque()
_pending_bytes = 0
_lost = 0
TEXT_FIELDS = frozenset(('kind source hostname event_id category audit_type actor account account_id account_domain path executable process_name remote_address syscall access_mask outcome reason_code').split())
NUMBER_FIELDS = frozenset(('at occurred_at process_id native_event_code queried_records record_limit lookback_seconds lost_values notification_count').split())
BOOL_FIELDS = frozenset(('available possibly_truncated audit_policy_verified object_rules_verified').split())


def validate_row(row, index=0):
    if not isinstance(row,dict) or len(row)>32 or set(row)-TEXT_FIELDS-NUMBER_FIELDS-BOOL_FIELDS:
        raise ValueError('Invalid activity evidence fields')
    if row.get('kind') not in {'native_audit','protected_file_change','protected_file_access','coverage','coverage_gap'}:
        raise ValueError('Invalid activity evidence kind')
    import math
    for key,value in row.items():
        if key in TEXT_FIELDS and (not isinstance(value,str) or len(value)>512 or any(ord(c)<32 for c in value)):
            raise ValueError('Invalid activity evidence text')
        if key in NUMBER_FIELDS and value is not None and (type(value) not in (int,float) or not math.isfinite(value) or not 0<=value<=2**63-1):
            raise ValueError('Invalid activity evidence number')
        if key in BOOL_FIELDS and type(value) is not bool:raise ValueError('Invalid activity evidence flag')
    if len(json.dumps(row).encode())>8192:raise ValueError('Activity evidence exceeds its event bound')
    return dict(row)


def queue_activity(row):
    global _pending_bytes,_lost
    clean={}
    for key,value in row.items():
        if key in TEXT_FIELDS:clean[key]=''.join(c if ord(c)>=32 else ' ' for c in str(value))[:512]
        elif key in NUMBER_FIELDS:
            if isinstance(value,str):
                try:value=int(value,16) if value.startswith('0x') else float(value)
                except ValueError:value=None
            clean[key]=value
        elif key in BOOL_FIELDS:clean[key]=value
    clean=validate_row(clean);size=len(json.dumps(clean).encode())
    with _lock:
        _pending.append((clean,size));_pending_bytes+=size
        while len(_pending)>255 or _pending_bytes>120*1024:
            _,old_size=_pending.popleft();_pending_bytes-=old_size;_lost+=1


def drain():
    global _pending_bytes,_lost
    with _lock:
        rows=[row for row,_ in _pending];_pending.clear();_pending_bytes=0
        if _lost:
            rows.append({'kind':'coverage_gap','source':'activity-buffer','reason_code':'buffer_limit','lost_values':_lost,'at':time.time()})
            _lost=0
    return rows


def protected_file_changes(paths,source):
    from .recording import emit
    emit('protected_file_activity',{'paths':[{'path':p} for p in sorted(paths)],'source':source,'actor':'unknown'})
    for path in sorted(paths):queue_activity({'kind':'protected_file_change','path':path,'source':source,'actor':'unknown','at':time.time()})


def protected_file_access(paths,source):
    from .recording import emit
    rows=[{'kind':'protected_file_access','path':p,'source':source,'actor':'unknown',
           'notification_count':count,'at':time.time()} for p,count in sorted(paths.items())]
    emit('protected_file_access',{'events':rows,'coalescing_seconds':2})
    for row in rows:queue_activity(row)


def windows_policy_coverage():
    from .windows_audit import audit_policy,PROCESS_CREATION_SUBCATEGORY,FILE_SYSTEM_SUBCATEGORY
    from .recording import emit
    for source,guid in (('windows-process-audit',PROCESS_CREATION_SUBCATEGORY),('windows-object-audit',FILE_SYSTEM_SUBCATEGORY)):
        row={'kind':'coverage','source':source,'at':time.time(),'audit_policy_verified':False,'available':False}
        try:
            flags=audit_policy(guid)
            row.update(audit_policy_verified=True,available=flags['success'])
        except (OSError,ValueError):pass
        if source=='windows-object-audit':row['object_rules_verified']=False
        emit('audit_coverage',row);queue_activity(row)
