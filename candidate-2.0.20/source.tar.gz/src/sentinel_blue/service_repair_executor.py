"""Journaled config restoration + native service recovery as one operation."""

from __future__ import annotations

import hashlib
import json
import os
import math
import itertools
import stat
from pathlib import Path
import subprocess
import time
import uuid
from dataclasses import asdict
from typing import Any

from .policy import validate_action_parameters
from .probes import run_probes
from .probe_evidence import all_probes_healthy, matching_probe_health
from .restoration import MAX_FILE_BYTES, validate_restored_configuration
from .service_recovery import check_recovery_observation, check_recovery_deadline
from .service_repair import local_probe, plan_digest
from .state import read_private_json, write_private_json


# systemd reads unit files only on daemon-reload. A restored unit or drop-in
# left unreloaded is correct on disk while systemd keeps running the tampered
# definition from memory, and the start that follows proves nothing.
UNIT_DIRECTORIES = ("/etc/systemd/system/", "/run/systemd/system/", "/lib/systemd/system/",
                    "/usr/lib/systemd/system/", "/usr/local/lib/systemd/system/")
MASKED_START_MODES = frozenset({"masked", "masked-runtime"})
# This is a work/inspection bound, not a lifetime limit on completed repairs.
MAX_REPAIR_SCAN = 4096
MAX_UNFINISHED_REPAIRS = 256
TERMINAL_REPAIRS = frozenset({"committed", "rolled_back", "recovered"})


def touches_units(paths) -> bool:
    return any(str(path).startswith(UNIT_DIRECTORIES) for path in paths)


class ServiceRepairExecutor:
    def __init__(self, executor: Any):
        self.executor = executor
        self.store = executor.restore_points

    def _path(self, identifier: str) -> Path:
        # IDs are generated UUIDs. Do not accept a path, glob or alternate spelling.
        if not isinstance(identifier, str) or str(uuid.UUID(identifier)) != identifier:
            raise ValueError("invalid service repair transaction identifier")
        return self.executor.state_dir / f"service-repair-{identifier}.json"

    def _archive_path(self, identifier: str, *, create: bool = False) -> Path:
        live = self._path(identifier)  # validates the literal UUID
        base = self.executor.state_dir / "service-repair-history"
        shard = base / identifier[:2]
        for directory in (base, shard):
            if create:
                directory.mkdir(mode=0o700, exist_ok=True)
            if directory.exists() or directory.is_symlink():
                info = directory.lstat()
                if (not stat.S_ISDIR(info.st_mode) or directory.is_symlink()
                        or os.name == "posix" and (info.st_uid != os.geteuid() or info.st_mode & 0o077)):
                    raise ValueError("service repair history directory is not private and owned")
        return shard / live.name

    def _archive_terminal(self, path: Path, record: dict[str, Any], now: float) -> bool:
        from .service_recovery import RECOVERY_WINDOW_SECONDS
        from .state import remove_private_file, _fsync_directory
        completed = record.get("completed_at", record["created_at"])
        if (record.get("status") not in TERMINAL_REPAIRS or type(completed) not in {int, float}
                or not math.isfinite(completed)):
            return False
        # Recent attempts must remain visible to the independent cooldown and
        # hourly-limit gate. Never archive an unfinished or uncertain record.
        if max(completed, record["created_at"]) > now - RECOVERY_WINDOW_SECONDS:
            return False
        target = self._archive_path(record["transaction_id"], create=True)
        if target.exists() or target.is_symlink():
            previous = self._read(target)
            identity = ("transaction_id", "parameters", "plan_sha256", "children", "service",
                        "profile_fingerprint", "before", "desired", "created_at", "operation")
            if (previous.get("status") not in TERMINAL_REPAIRS
                    or any(previous.get(key) != record.get(key) for key in identity)
                    or previous.get("origin_action", "repair_service") != record.get("origin_action", "repair_service")
                    or previous.get("forward_success", previous.get("status") == "committed")
                       != record.get("forward_success", record.get("status") == "committed")):
                raise ValueError("archived service repair identity conflicts with live journal")
            previous_completed = previous.get("completed_at", previous["created_at"])
            if (type(previous_completed) not in {int, float} or not math.isfinite(previous_completed)
                    or previous_completed > completed
                    or previous.get("status") in {"rolled_back", "recovered"} and record.get("status") == "committed"):
                raise ValueError("archived service repair is newer than or conflicts with live journal")
        if self._read(path) != record:
            raise ValueError("service repair changed before archival")
        # Durable copy before unlink; a crash can leave two equivalent records,
        # never zero. Child journals, restore blobs and ledger references remain.
        write_private_json(target, record)
        _fsync_directory(target.parent.parent)
        _fsync_directory(self.executor.state_dir)
        if self._read(path) != record:
            raise ValueError("service repair changed during archival")
        remove_private_file(path)
        return True

    def bind_profile(self, fingerprint: str) -> None:
        if self.executor.repair_profile_fingerprint not in {"", fingerprint}:
            raise ValueError("local service repair executor belongs to a different profile")
        self.executor.repair_profile_fingerprint = fingerprint

    def _write(self, transaction: dict[str, Any]) -> None:
        write_private_json(self._path(transaction["transaction_id"]), transaction)

    def _transition(self, service: str, desired: str) -> None:
        if desired == "running" and os.name != "nt":
            # A unit that hit its start limit refuses "start" until its failure
            # state is cleared; the repair has just removed the cause.
            try:
                subprocess.run(["systemctl", "reset-failed", "--", service], capture_output=True, text=True,
                               timeout=12, check=False)
            except (OSError, subprocess.SubprocessError):
                pass            # the start below reports any real failure
        self.executor._set_service_state(service, desired)
        deadline = time.monotonic() + 15
        while self.executor._service_state(service) != desired:
            if time.monotonic() >= deadline:
                raise ValueError(f"native service did not reach {desired}")
            time.sleep(0.2)

    def _probe(self, specs: list[dict[str, Any]]) -> list[Any]:
        return run_probes(specs, self.executor.authorized_networks,
                          authorized_hosts=self.executor.authorized_hosts,
                          excluded_hosts=self.executor.excluded_hosts)

    def _startup_mode(self, service: str) -> str:
        from .service_startup import read_start_mode
        return read_start_mode(service)

    def _change_startup(self, service: str, expected: str, desired: str) -> None:
        from .service_startup import change_start_mode
        change_start_mode(service, expected, desired)

    def _reload_units(self) -> None:
        import platform
        if platform.system().casefold() != "linux":
            return
        result = subprocess.run(["systemctl", "daemon-reload"], capture_output=True, text=True,
                                timeout=30, check=False)
        if result.returncode:
            raise ValueError("systemd did not reload the restored unit definition")

    def _observed_state(self, service: str, startup: dict[str, Any] | None, restore_files=()) -> str:
        """Native state, reading a masked or deleted unit as the stopped unit it is.

        systemctl reports a masked unit, and a unit whose file was deleted, as
        not loaded, which the generic state reader rightly calls unknown. When
        the repair was planned against that exact mask, or against the missing
        unit file it is about to restore, the unit cannot be running.
        """
        state = self.executor._service_state(service)
        if state != "unknown":
            return state
        if os.name != "nt":
            properties = self._unit_properties(service)
            # Waiting in systemd's auto-restart: not running, and a start
            # replaces the queued restart.
            if (properties.get("LoadState") == "loaded" and properties.get("ActiveState") == "activating"
                    and properties.get("SubState") in {"auto-restart", "auto-restart-queued"}):
                return "stopped"
        if (startup and startup["observed"] in MASKED_START_MODES
                and self._startup_mode(service) == startup["observed"]):
            return "stopped"
        if self._unit_file_missing(service, restore_files):
            properties = self._unit_properties(service)
            if properties.get("LoadState") == "not-found" and properties.get("ActiveState") in {"inactive", "failed"}:
                return "stopped"
        return state

    @staticmethod
    def _unit_file_missing(service: str, restore_files) -> bool:
        """This repair restores the service's own unit file, and it is still absent."""
        if os.name == "nt":
            return False
        for item in restore_files or ():
            path = str(item.get("path", ""))
            if (item.get("observed_missing") is True and path.startswith(UNIT_DIRECTORIES)
                    and Path(path).name == service and not os.path.lexists(path)):
                return True
        return False

    @staticmethod
    def _unit_properties(service: str) -> dict[str, str]:
        try:
            result = subprocess.run(["systemctl", "show", "--property=LoadState", "--property=ActiveState",
                                     "--property=SubState", "--", service],
                                    text=True, capture_output=True, timeout=12, check=False)
        except (OSError, subprocess.SubprocessError):
            return {}
        if result.returncode != 0:
            return {}
        return dict(line.split("=", 1) for line in result.stdout.splitlines() if "=" in line)

    def _verify_files(self, parameters: dict[str, Any]) -> None:
        for item in parameters["recovery_guard"]["files"]:
            data, metadata = self.store._read_target(Path(item["path"]))
            if (hashlib.sha256(data).hexdigest() != item["sha256"] or
                self.store._metadata_security_descriptor_sha256(metadata) != item["security_descriptor_sha256"]):
                raise ValueError(f"configuration is not the approved state: {item['path']}")

    def _verify_sources(self, parameters: dict[str, Any]) -> None:
        manifest = self.store._read_manifest()
        total = 0
        for item in parameters["repair"]["restore_files"]:
            path, expected = self.store._validate_item(item)
            record = manifest.get(str(path))
            if not isinstance(record, dict) or record.get("sha256") != expected:
                raise ValueError("no exact approved restore point for repair")
            if self.store._metadata_security_descriptor_sha256(record) != item["baseline_security_descriptor_sha256"]:
                raise ValueError("repair source security metadata differs from baseline")
            data = self.store.approved_bytes(expected, path)
            total += len(data)
            if total > 64 * 1024 * 1024 or hashlib.sha256(data).hexdigest() != expected:
                raise ValueError("repair source integrity or total byte budget failed")
            current = self.store._read_target_if_present(path)
            if item["observed_missing"]:
                if current is not None:
                    raise ValueError("repair target reappeared after observation")
            elif current is None or hashlib.sha256(current[0]).hexdigest() != item["observed_sha256"]:
                raise ValueError("repair target changed after observation")
            elif self.store._metadata_security_descriptor_sha256(current[1]) != item["observed_security_descriptor_sha256"]:
                raise ValueError("repair target security changed after observation")

    def _validate_application(self, transaction: dict[str, Any]) -> tuple[list[Any], int]:
        parameters = transaction["parameters"]
        startup = parameters["repair"].get("startup")
        if startup and self._startup_mode(transaction["service"]) != startup["desired"]:
            raise ValueError("service startup policy failed verification")
        self._verify_files(parameters)
        for item in parameters["repair"]["restore_files"]:
            validation = validate_restored_configuration(Path(item["path"]))
            if validation["applicable"] and validation["available"] and validation["healthy"] is False:
                raise ValueError("restored configuration failed native validation")
        guard = parameters["recovery_guard"]
        for name in guard["dependencies"]:
            if self.executor._service_state(name) != "running":
                raise ValueError("dependency became unavailable during repair")
        if guard["dependency_probes"]:
            results = self._probe(guard["dependency_probes"])
            if not all_probes_healthy(guard["dependency_probes"], results):
                raise ValueError("dependency became unhealthy during repair")
        if self.executor._service_state(transaction["service"]) != "running":
            raise ValueError("repaired service is not running")
        probes, attempts, healthy = self.executor._wait_for_service_probes(
            parameters["probes"], grace_seconds=parameters["repair"]["validation_timeout_seconds"])
        if not healthy or not parameters["probes"] or not all_probes_healthy(parameters["probes"], probes):
            raise ValueError("repaired service did not pass stable application validation")
        # A process or file can change during the validation window.
        self._verify_files(parameters)
        if self.executor._service_state(transaction["service"]) != "running":
            raise ValueError("service stopped during final validation")
        if startup and self._startup_mode(transaction["service"]) != startup["desired"]:
            raise ValueError("service startup policy changed during final validation")
        return probes, attempts

    def _undo(self, transaction: dict[str, Any]) -> None:
        """Undo only this journal's exact file effects; never overwrite a third state."""
        service = transaction["service"]
        startup = transaction["parameters"]["repair"].get("startup")
        restore_files = transaction["parameters"]["repair"]["restore_files"]
        current = self._observed_state(service, startup, restore_files)
        if current not in {"running", "stopped"}:
            raise ValueError("unknown service state holds repair rollback")
        # Unmasking passes through an unmasked, not-yet-enabled step, so a
        # failure between the two leaves that intermediate mode, not a third party's.
        expected_modes = {startup["observed"], startup["desired"]} if startup else set()
        if startup and startup["observed"] in MASKED_START_MODES:
            expected_modes |= {"disabled", "enabled"}
        if startup and self._startup_mode(service) not in expected_modes:
            raise ValueError("startup rollback held because a third state replaced the repair")
        children = []
        for child, planned in zip(transaction["children"], transaction["parameters"]["repair"]["restore_files"]):
            path = self.store.transactions / f"{child['transaction_id']}.json"
            raw = self.store._read_private_file_if_present(path, 128 * 1024)
            if raw is None:
                current_file = self.store._read_target_if_present(Path(child["path"]))
                if (planned["observed_missing"] and current_file is not None or
                    not planned["observed_missing"] and (current_file is None or
                    hashlib.sha256(current_file[0]).hexdigest() != planned["observed_sha256"] or
                    self.store._metadata_security_descriptor_sha256(current_file[1]) != planned["observed_security_descriptor_sha256"])):
                    raise ValueError("unmodified repair target differs from its original observation")
                continue  # Reserved before a write; this child never began.
            record = json.loads(raw)
            if (not isinstance(record, dict) or record.get("transaction_id") != child["transaction_id"]
                or record.get("path") != child["path"]):
                raise ValueError("child restoration journal does not match its parent")
            if record.get("status") in {"rolled_back", "recovered"}:
                current_file = self.store._read_target_if_present(Path(child["path"]))
                if (record["existed"] and (current_file is None or
                    hashlib.sha256(current_file[0]).hexdigest() != record["before_sha256"] or
                    not self.store._metadata_matches(record["before_metadata"], current_file[1])) or
                    not record["existed"] and current_file is not None):
                    raise ValueError("previously rolled-back file no longer matches its prior state")
                continue
            if record.get("status") != "committed":
                raise ValueError("child restoration requires recovery before parent rollback")
            # Check every child before stopping anything or undoing any sibling.
            data, metadata = self.store._read_target(Path(child["path"]))
            if (hashlib.sha256(data).hexdigest() != record["restored_sha256"]
                or not self.store._metadata_matches(record["restored_metadata"], metadata)):
                raise ValueError("repair rollback held because a target changed after repair")
            children.append(child)
        transaction["status"] = "undo_prepared"
        self._write(transaction)
        if current == "running" and (children or transaction["before"] == "stopped"):
            self._transition(service, "stopped")
        for child in reversed(children):
            result = self.store.rollback(child["transaction_id"], allowed=True, probes=[])
            if result.get("success") is not True or result.get("dry_run"):
                raise ValueError("child restoration rollback did not complete")
        if touches_units(child["path"] for child in children):
            self._reload_units()
        if self._observed_state(service, startup, restore_files) != transaction["before"]:
            self._transition(service, transaction["before"])
        if self._observed_state(service, startup, restore_files) != transaction["before"]:
            raise ValueError("repair rollback did not restore the prior native state")
        if startup:
            mode = self._startup_mode(service)
            if mode != startup["observed"]:
                self._change_startup(service, mode, startup["observed"])
        transaction["status"] = "rolled_back"
        transaction["completed_at"] = time.time()
        self._write(transaction)

    def execute(self, action_type: str, parameters: dict[str, Any], telemetry: dict[str, Any], started: float,
                *, origin_action: str = "repair_service") -> dict[str, Any]:
        ex = self.executor
        transaction = None
        try:
            validate_action_parameters(action_type, parameters)
            if origin_action not in {"repair_service", "restart_service"}:
                raise ValueError("unsupported journal origin")
            if origin_action == "restart_service" and action_type == "repair_service":
                from .journaled_recovery import start_plan
                source = {key: parameters[key] for key in ("service", "probes", "recovery_guard")}
                if start_plan(source) != parameters:
                    raise ValueError("restart authority cannot restore files or startup policy")
            if not ex.allow_service_recovery or (origin_action != "restart_service" and not ex.allow_restoration):
                return ex._result(action_type, True, "dry run: coordinated repair requires service and restoration permission",
                                  started, dry_run=True)
            if action_type == "rollback_service_repair":
                transaction = self._read(self._path(parameters["transaction_id"]))
                if (transaction["service"] != parameters["service"] or transaction["status"] != "committed"
                    or transaction.get("profile_fingerprint") != ex.repair_profile_fingerprint
                    or transaction.get("origin_action", "repair_service") != origin_action):
                    raise ValueError("service repair is not available for exact rollback")
                before = ex._service_state(transaction["service"])
                # A manual inverse must not stop a service using changed protected
                # inputs, even when this transaction changed no files itself.
                self._verify_files(transaction["parameters"])
                if before != transaction["desired"]:
                    raise ValueError("service state changed after the recorded action; the undo changed nothing")
                transaction["forward_success"] = True
                self._undo(transaction)
                return ex._result(action_type, True, "service repair restored its exact prior files and service state", started,
                                  pre_state={"service": transaction["service"], "desired_state": before})
            check_recovery_observation(parameters, telemetry)
            service = parameters["service"]
            before = self._observed_state(service, parameters["repair"].get("startup"),
                                          parameters["repair"]["restore_files"])
            if before != parameters["repair"]["observed_state"]:
                raise ValueError("service state changed after repair diagnosis")
            changed = tuple(item["path"] for item in parameters["repair"]["restore_files"])
            ex._service_recovery_preflight(parameters, skip_paths=changed)
            self._verify_sources(parameters)
            startup = parameters["repair"].get("startup")
            if startup and self._startup_mode(service) != startup["observed"]:
                raise ValueError("startup mode changed after repair diagnosis")
            if before == "running":
                if not parameters["repair"]["restart_unhealthy"]:
                    raise ValueError("restarting a running service is not authorized")
                from .service_repair import host_addresses
                own = host_addresses(telemetry)
                specs = [spec for spec in parameters["probes"] if local_probe(spec, own)]
                results = self._probe(specs)
                health = matching_probe_health(specs, results, exact=True)
                if not specs or any(value is None for value in health):
                    raise ValueError("local application check unavailable or incomplete; no restart performed")
                if not any(value is False for value in health):
                    raise ValueError("local application recovered or cannot confirm the fault; no restart performed")
            # Source reads and fresh local probes can outlive the original guard.
            # Check again before preparing any forward repair; rollback is not gated.
            check_recovery_deadline(parameters)
            transaction = {"transaction_id": str(uuid.uuid4()), "operation": "repair_service", "service": service,
                           "profile_fingerprint": ex.repair_profile_fingerprint, "origin_action": origin_action,
                           "before": before, "desired": "running", "created_at": started, "status": "prepared",
                           "parameters": parameters, "plan_sha256": plan_digest(parameters),
                           "children": [{"path": item["path"], "transaction_id": str(uuid.uuid4())} for item in parameters["repair"]["restore_files"]]}
            self._write(transaction)
            if before == "running":
                self._transition(service, "stopped")
            for item, child in zip(parameters["repair"]["restore_files"], transaction["children"]):
                result = self.store.restore(item, allowed=True, probes=[], transaction_id=child["transaction_id"], defer_validation=True)
                if result.get("success") is not True or result.get("dry_run"):
                    raise ValueError("configuration restoration failed during coordinated repair")
            ex._service_recovery_preflight(parameters, ignore_transaction_id=transaction["transaction_id"])
            for item in parameters["repair"]["restore_files"]:
                validation = validate_restored_configuration(Path(item["path"]))
                if validation["applicable"] and validation["available"] and validation["healthy"] is False:
                    raise ValueError("restored configuration failed native validation before service start")
            if startup:
                self._change_startup(service, startup["observed"], startup["desired"])
            if touches_units(item["path"] for item in parameters["repair"]["restore_files"]):
                self._reload_units()
            self._transition(service, "running")
            probes, attempts = self._validate_application(transaction)
            transaction["status"] = "committed"
            transaction["forward_success"] = True
            transaction["completed_at"] = time.time()
            self._write(transaction)
            return ex._result(action_type, True, "approved configuration and service recovered; stable application checks passed",
                              started, stable_health=True, probe_attempts=attempts, probes=[asdict(item) for item in probes],
                              pre_state={"service": service, "desired_state": before, "transaction_id": transaction["transaction_id"]},
                              record={"plan_sha256": transaction["plan_sha256"], "files": parameters["recovery_guard"]["files"],
                                      **({"startup": dict(startup)} if startup else {}),
                                      "transaction_id": transaction["transaction_id"],
                                      **({"origin_action": origin_action} if origin_action == "restart_service" else {})})
        except (OSError, KeyError, TypeError, ValueError, RuntimeError, subprocess.TimeoutExpired) as exc:
            rolled_back = False
            errors = [str(exc)[:500]]
            if transaction is not None and action_type == "repair_service":
                transaction["forward_success"] = False
                try:
                    self._undo(transaction)
                    rolled_back = True
                except (OSError, KeyError, TypeError, ValueError, RuntimeError, subprocess.TimeoutExpired) as undo_error:
                    errors.append(str(undo_error)[:500])
                    transaction["status"] = "rollback_failed"
                    try:
                        self._write(transaction)
                    except (OSError, TypeError, ValueError):
                        pass
            # A repair held before its transaction began changed nothing; only a
            # started one whose undo failed leaves the host needing review. The
            # result schema is fixed, so that case uses its existing flag. An
            # inverse is "started" only once _undo marked its journal
            # undo_prepared, just before its first change: one refused by its
            # checks (for example, the service state changed after the recorded
            # action) changed nothing and needs no review (2.0.18, review bug 12).
            if action_type == "rollback_service_repair":
                mutation_started = transaction is not None and transaction.get("status") != "committed"
            else:
                mutation_started = transaction is not None
            extra = {"review_required": True} if mutation_started and not rolled_back else {}
            return ex._result(action_type, False, f"coordinated service repair held or failed: {exc}"[:1000], started,
                              rolled_back=rolled_back, errors=errors, **extra)

    def _read(self, path: Path) -> dict[str, Any]:
        original_path = path
        if not path.exists() and not path.is_symlink() and path.parent == self.executor.state_dir:
            identifier = path.name.removeprefix("service-repair-").removesuffix(".json")
            path = self._archive_path(identifier)
        record = read_private_json(path, 1024 * 1024)
        if not isinstance(record, dict):
            raise ValueError("invalid service repair journal")
        live = self._path(record["transaction_id"])
        if path != live and path != self._archive_path(record["transaction_id"]):
            raise ValueError("invalid service repair journal")
        if original_path.parent == self.executor.state_dir and original_path != live:
            raise ValueError("invalid service repair journal identity")
        validate_action_parameters("repair_service", record["parameters"])
        if record["parameters"]["service"] != record["service"] or record["plan_sha256"] != plan_digest(record["parameters"]):
            raise ValueError("service repair journal plan does not match its binding")
        if (record["before"] != record["parameters"]["repair"]["observed_state"] or record["desired"] != "running"
            or record.get("operation") != "repair_service"):
            raise ValueError("invalid service repair journal states")
        origin = record.get("origin_action", "repair_service")
        if origin not in {"repair_service", "restart_service"}:
            raise ValueError("invalid repair journal authority")
        if origin == "restart_service":
            from .journaled_recovery import start_plan
            source = {key: record["parameters"][key] for key in ("service", "probes", "recovery_guard")}
            if start_plan(source) != record["parameters"]:
                raise ValueError("start journal contains effects outside restart authority")
        if "forward_success" in record and type(record["forward_success"]) is not bool:
            raise ValueError("invalid original repair outcome")
        if type(record["created_at"]) not in {int, float} or not math.isfinite(record["created_at"]):
            raise ValueError("invalid service repair journal timestamp")
        children = record["children"]
        if not isinstance(children, list) or [item["path"] for item in children] != [item["path"] for item in record["parameters"]["repair"]["restore_files"]]:
            raise ValueError("service repair journal children differ from its plan")
        if any(not isinstance(item.get("transaction_id"), str) for item in children):
            raise ValueError("invalid child restoration identities")
        ids = [str(uuid.UUID(item["transaction_id"])) for item in children]
        if ids != [item["transaction_id"] for item in children] or len(set(ids)) != len(ids):
            raise ValueError("invalid child restoration identities")
        return record

    def reconcile(self) -> dict[str, Any]:
        """Validate completed effects; roll back exact unfinished work with permission."""
        recovered, unresolved = [], []
        records = list(itertools.islice(self.executor.state_dir.glob("service-repair-*.json"), MAX_REPAIR_SCAN + 1))
        overflow = len(records) > MAX_REPAIR_SCAN
        pending = 0
        now = time.time()
        for path in records[:MAX_REPAIR_SCAN]:
            try:
                record = self._read(path)
                if record["status"] in TERMINAL_REPAIRS:
                    self._archive_terminal(path, record, now)
                    continue
                pending += 1
                if pending > MAX_UNFINISHED_REPAIRS:
                    raise ValueError("unfinished service repair budget exceeded")
                if record.get("profile_fingerprint") != self.executor.repair_profile_fingerprint:
                    raise ValueError("interrupted repair belongs to a different approved profile")
                if record["status"] not in {"prepared", "undo_prepared", "rollback_failed"}:
                    raise ValueError("invalid service repair journal status")
                # The same permissions that allowed the change finish it: a
                # journaled start (restart authority) restores no files, so it
                # needs no restoration permission (2.0.18; as execute() checks).
                origin = record.get("origin_action", "repair_service")
                if (not self.executor.allow_service_recovery
                        or (origin != "restart_service" and not self.executor.allow_restoration)):
                    raise ValueError("unfinished repair requires current local repair permissions")
                if record["status"] == "prepared" and self.executor._service_state(record["service"]) == "running":
                    try:
                        self._validate_application(record)
                    except (OSError, ValueError, subprocess.TimeoutExpired):
                        pass
                    else:
                        record["status"] = "committed"
                        record["completed_at"] = time.time()
                        self._write(record)
                        recovered.append(record["transaction_id"])
                        continue
                self._undo(record)
                recovered.append(record["transaction_id"])
            except (OSError, KeyError, TypeError, ValueError, RuntimeError, subprocess.TimeoutExpired) as exc:
                unresolved.append({"transaction": path.name, "reason": str(exc)[:500]})
        if overflow:
            unresolved.append({"transaction": "*", "reason": "service repair migration/inspection budget exceeded; another bounded reconciliation is required"})
        return {"healthy": not unresolved, "recovered": recovered, "unresolved": unresolved}
