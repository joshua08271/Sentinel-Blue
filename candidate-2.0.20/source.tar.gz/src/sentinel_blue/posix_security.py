"""Canonical POSIX file-security evidence shared by monitoring and restoration.

Includes all readable extended attributes (ACLs, labels and capabilities included),
not timestamps/inodes/content. This is a security-metadata fingerprint, not an
assessment of the effective access policy or protection against a privileged writer.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os

MAX_SECURITY_XATTRS = 128
MAX_SECURITY_XATTR_BYTES = 64 * 1024


def security_digest(metadata: dict) -> str:
    mode, uid, gid = (metadata.get(key) for key in ('mode', 'uid', 'gid'))
    if (type(mode) is not int or not 0 <= mode <= 0o7777
            or any(type(value) is not int or not 0 <= value <= 0xffffffff for value in (uid, gid))):
        raise ValueError('POSIX security identity/mode is unavailable or invalid')
    attrs = metadata.get('xattrs')
    if not isinstance(attrs, dict) or len(attrs) > MAX_SECURITY_XATTRS:
        raise ValueError('POSIX security attributes are unavailable or exceed the limit')
    canonical = {}
    total = 0
    for name, encoded in attrs.items():
        if not isinstance(name, str) or not name or len(name) > 255 or not isinstance(encoded, str):
            raise ValueError('Invalid POSIX security attribute')
        if len(encoded) > 4 * ((MAX_SECURITY_XATTR_BYTES + 2) // 3):
            raise ValueError('POSIX security attributes exceed the byte limit')
        try:
            value = base64.b64decode(encoded, validate=True)
        except (ValueError, TypeError) as exc:
            raise ValueError('Invalid POSIX security attribute encoding') from exc
        total += len(name.encode('utf-8', 'surrogateescape')) + len(value)
        if total > MAX_SECURITY_XATTR_BYTES:
            raise ValueError('POSIX security attributes exceed the byte limit')
        canonical[name] = base64.b64encode(value).decode('ascii')
    record = {'schema': 'posix-file-security-v1', 'mode': mode, 'uid': uid, 'gid': gid, 'xattrs': canonical}
    return hashlib.sha256(json.dumps(record, sort_keys=True, separators=(',', ':'),
                                     ensure_ascii=True, allow_nan=False).encode('ascii')).hexdigest()


def capture_xattrs(descriptor: int, budget=None) -> dict[str, str]:
    if not hasattr(os, 'listxattr') or not hasattr(os, 'getxattr'):
        raise ValueError('POSIX security attribute inspection is unavailable')
    names = os.listxattr(descriptor)
    if len(names) > MAX_SECURITY_XATTRS:
        raise ValueError('POSIX security attribute count exceeds the limit')
    result = {}
    total = 0
    for name in sorted(names):
        if budget is not None:
            budget.check()
        value = os.getxattr(descriptor, name)
        total += len(name.encode('utf-8', 'surrogateescape')) + len(value)
        if total > MAX_SECURITY_XATTR_BYTES:
            raise ValueError('POSIX security attributes exceed the byte limit')
        if budget is not None:
            budget.consume(len(value))
        result[name] = base64.b64encode(value).decode('ascii')
    return result
