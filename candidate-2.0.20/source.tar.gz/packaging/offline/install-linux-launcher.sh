#!/bin/sh
# Per-user shortcuts only, using the bundled interpreter. No downloads/services.
set -eu
case "$0" in */*) parent=${0%/*} ;; *) parent=. ;; esac
here=$(CDPATH='' cd -- "$parent" && pwd -P)
exec "$here/runtime/bin/python3" -I -B "$here/install-linux-launcher.py" "$@"
