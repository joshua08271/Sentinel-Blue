#!/bin/sh
# Only the adjacent interpreter is used; never install or locate system Python.
set -eu
case "$0" in
  */*) sentinel_parent=${0%/*} ;;
  *) sentinel_parent=. ;;
esac
sentinel_root=$(CDPATH='' cd -- "$sentinel_parent" && pwd -P)
[ -x "$sentinel_root/runtime/bin/python3" ] || {
    printf '%s\n' 'The bundled interpreter is missing or not executable. Extract the complete offline ZIP; restore execute permissions if your extractor removed them.' >&2
    exit 2
}
exec "$sentinel_root/runtime/bin/python3" -I -B "$sentinel_root/launch.py" "$@"
