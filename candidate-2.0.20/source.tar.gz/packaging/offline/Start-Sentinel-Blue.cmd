@echo off
setlocal DisableDelayedExpansion
"%~dp0runtime\python.exe" -I -B "%~dp0launch.py" %*
set "sentinel_exit=%errorlevel%"
if not "%sentinel_exit%"=="0" (
  echo Sentinel Blue could not start. Keep the entire extracted folder together.
  if "%~1"=="" pause
)
exit /b %sentinel_exit%
