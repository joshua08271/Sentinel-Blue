"""Offline bundle entry point. No downloads, installation, or remote activation."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import runpy
import sys


def verify_bundle(root):
    """Check every distributed file, not mutable operator data in the folder.

    SHA256SUMS detects corruption; it is not a signature or a root trust anchor.
    Verify the archive checksum against the independently delivered release first.
    """
    checked = 0
    seen = set()
    for line in (root / 'SHA256SUMS').read_text(encoding='utf-8').splitlines():
        checksum, name = line.split('  ', 1)
        relative = PurePosixPath(name)
        if (relative.is_absolute() or '..' in relative.parts or name in seen or
                len(checksum) != 64 or any(c not in '0123456789abcdef' for c in checksum)):
            raise ValueError('Unsafe or duplicate bundle checksum entry')
        seen.add(name)
        path = root.joinpath(*relative.parts)
        for part in (path, *path.parents):
            if part == root.parent:
                break
            if part.is_symlink():
                raise ValueError('Bundle file is a symbolic link: ' + name)
        if not path.is_file():
            raise ValueError('Bundle file is missing: ' + name)
        with path.open('rb') as handle:
            if hashlib.file_digest(handle, 'sha256').hexdigest() != checksum:
                raise ValueError('Bundle file checksum mismatch: ' + name)
        checked += 1
    required = {'launch.py', 'sentinel-blue.pyz', 'offline-manifest.json', 'Start-Sentinel-Blue.sh'}
    if not required.issubset(seen) or not any(n.startswith('runtime/') for n in seen):
        raise ValueError('Offline checksum inventory is incomplete')
    return {'passed': True, 'files_checked': checked, 'network_access_required': False}


def main():
    root = Path(__file__).resolve().parent
    runtime = root / 'runtime'
    if not sys.flags.isolated or not Path(sys.executable).resolve().is_relative_to(runtime):
        raise RuntimeError('Use Start-Sentinel-Blue from the fully extracted offline bundle.')
    manifest = json.loads((root / 'offline-manifest.json').read_text(encoding='utf-8'))
    package = root / 'sentinel-blue.pyz'
    with package.open('rb') as handle:
        actual = hashlib.file_digest(handle, 'sha256').hexdigest()
    if actual != manifest['runtime_sha256']:
        raise RuntimeError('The script differs from this offline bundle. Extract a complete verified release.')
    for variable, pattern, marker in (('TCL_LIBRARY', 'tcl*', 'init.tcl'), ('TK_LIBRARY', 'tk*', 'tk.tcl')):
        candidates = [p for base in (runtime/'lib', runtime/'tcl') for p in base.glob(pattern) if (p/marker).is_file()]
        if len(candidates) != 1:
            raise RuntimeError('The bundled desktop libraries are incomplete. Extract the full archive again.')
        os.environ[variable] = str(candidates[0])
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    os.environ['PIP_NO_INDEX'] = '1'
    os.environ['PIP_DISABLE_PIP_VERSION_CHECK'] = '1'
    if sys.argv[1:] == ['--verify-bundle']:
        print(json.dumps(verify_bundle(root), indent=2))
        return
    if not sys.argv[1:] or sys.argv[1] == 'desktop':
        verify_bundle(root)
    sys.argv = [str(package), *sys.argv[1:]]
    runpy.run_path(str(package), run_name='__main__')


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print('Sentinel Blue could not start: ' + str(exc), file=sys.stderr)
        desktop_requested = (len(sys.argv) == 1 or
                             (sys.platform.startswith('linux') and sys.argv[1:2] == ['desktop']))
        if desktop_requested and os.environ.get('DISPLAY'):
            try:
                import tkinter as tk
                from tkinter import messagebox
                window = tk.Tk(); window.withdraw()
                messagebox.showerror('Sentinel Blue', str(exc) + '\nKeep the complete offline folder together.')
                window.destroy()
            except Exception:
                pass
        raise SystemExit(2) from None
