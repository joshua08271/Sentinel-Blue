#!/bin/sh
# Per-user installer; the stdlib helper records exact ownership before writing.
# Python 3.11+ is also required by the Sentinel runtime. No pip or network used.
set -eu
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
[ -f "$here/install-linux-launcher.py" ] || { printf '%s\n' 'Keep install-linux-launcher.py beside this installer.' >&2; exit 1; }
for candidate in python3 python3.14 python3.13 python3.12 python3.11; do
    command -v "$candidate" >/dev/null 2>&1 || continue
    if "$candidate" -c 'import sys; raise SystemExit(0 if sys.version_info[:2] >= (3, 11) else 1)' 2>/dev/null; then
        exec "$candidate" -I "$here/install-linux-launcher.py" "$@"
    fi
done
printf '%s\n' 'Install Python 3.11 or newer before registering the Sentinel launcher. On Debian/Ubuntu/Kali: sudo apt install python3' >&2
exit 1
