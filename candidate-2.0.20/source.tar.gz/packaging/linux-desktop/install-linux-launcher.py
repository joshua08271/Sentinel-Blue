#!/usr/bin/env python3
"""Per-user desktop integration with exact-state ownership and crash receipts.

This only manages the application entry, icon and optional desktop entry. It
never touches controller/agent configuration, credentials, services or the
Sentinel mutation ledger. Unowned or changed objects are refused, not adopted.
"""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tempfile
import fcntl

FORMAT = 'sentinel-blue-desktop-install-v1'
LIMIT = 65536

def path_safe(path):
    path = Path(path)
    if not path.is_absolute() or '..' in path.parts or any(not c.isprintable() for c in str(path)):
        raise ValueError('Desktop paths must be absolute and contain no control characters')
    for part in (path, *path.parents):
        if part.is_symlink():
            raise ValueError('Desktop integration refuses symlink paths: ' + str(part))
    return path

def state(path):
    path_safe(path)
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except FileNotFoundError:
        return None
    with os.fdopen(fd, 'rb') as f:
        info = os.fstat(f.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid() or info.st_nlink != 1:
            raise ValueError('Desktop integration needs an owned regular file: ' + str(path))
        data = f.read(LIMIT + 1)
        if len(data) > LIMIT:
            raise ValueError('Desktop integration file exceeds its limit')
    return {'sha256': hashlib.sha256(data).hexdigest(), 'mode': stat.S_IMODE(info.st_mode)}

def sync_dir(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try: os.fsync(fd)
    finally: os.close(fd)

def write(path, data, mode, expected):
    path_safe(path)
    if state(path) != expected:
        raise ValueError('File changed during desktop integration: ' + str(path))
    fd, tmp = tempfile.mkstemp(prefix='.sentinel-write-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as f:
            os.fchmod(f.fileno(), mode); f.write(data); f.flush(); os.fsync(f.fileno())
        if state(path) != expected:
            raise ValueError('File changed during desktop integration: ' + str(path))
        os.replace(tmp, path); sync_dir(path.parent)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)

def exec_value(path):
    value = str(path_safe(path))
    # Desktop string escaping is undone BEFORE Exec argument escaping. Percent
    # signs are literal, not %U/%F substitutions. Never use shell interpolation.
    value = ''.join('\\' + c if c in '\\"$`' else c for c in value)
    value = value.replace('%', '%%').replace('\\', '\\\\')
    return '"' + value + '"'

def main():
    if sys.argv[1:] not in ([], ['--uninstall']):
        raise ValueError('Usage: sh install-linux-launcher.sh [--uninstall]')
    uninstall = bool(sys.argv[1:])
    here = path_safe(Path(__file__).absolute().parent)
    home = path_safe(Path.home())
    data = path_safe(Path(os.environ.get('XDG_DATA_HOME', str(home/'.local/share'))))
    apps = path_safe(data/'applications'); icons = path_safe(data/'icons/hicolor/scalable/apps')
    desktop = home/'Desktop'
    command = shutil.which('xdg-user-dir')
    if command:
        r = subprocess.run([command, 'DESKTOP'], capture_output=True, text=True, timeout=5)
        if r.returncode == 0 and r.stdout.strip(): desktop = Path(r.stdout.strip())
    desktop = path_safe(desktop)
    entry = apps/'sentinel-blue.desktop'; icon = icons/'sentinel-blue.svg'
    allowed = {str(entry), str(icon), str(desktop/'sentinel-blue.desktop')}
    if len(allowed) != 3: raise ValueError('Desktop integration destinations overlap')
    data.mkdir(parents=True, exist_ok=True)
    lock = path_safe(data/'.sentinel-blue-launcher.lock')
    fd = os.open(lock, os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW, 0o600)
    try:
        st = os.fstat(fd)
        if st.st_uid != os.geteuid() or st.st_nlink != 1 or not stat.S_ISREG(st.st_mode) or st.st_mode & 0o077:
            raise ValueError('Unsafe desktop integration lock')
        fcntl.flock(fd, fcntl.LOCK_EX|fcntl.LOCK_NB)
        receipt = path_safe(data/'.sentinel-blue-launcher.json')
        receipt_state = state(receipt)
        prior = None
        if receipt_state is not None:
            if receipt_state['mode'] != 0o600: raise ValueError('Desktop receipt must be private (0600)')
            prior = json.loads(receipt.read_text())
            if (not isinstance(prior, dict) or prior.get('format') != FORMAT or
                prior.get('source_directory') != str(here) or
                prior.get('phase') not in {'prepared','committed','uninstalling'} or
                not isinstance(prior.get('objects'), dict) or not prior['objects'] or
                not set(prior['objects']).issubset(allowed)):
                raise ValueError('Receipt does not belong to this installation; review the original folder')
            for name, expected in prior['objects'].items():
                if (not isinstance(expected, dict) or set(expected) != {'sha256','mode'} or
                    not isinstance(expected['sha256'], str) or len(expected['sha256']) != 64 or
                    any(c not in '0123456789abcdef' for c in expected['sha256']) or
                    type(expected['mode']) is not int or expected['mode'] not in {0o644,0o755}):
                    raise ValueError('Malformed desktop ownership receipt')
                current = state(Path(name))
                if current != expected and not (current is None and prior['phase'] in {'prepared','uninstalling'}):
                    raise ValueError('Installed desktop object was changed; retained for review: ' + name)
        if uninstall:
            if prior is None:
                if any(Path(name).exists() or Path(name).is_symlink() for name in allowed):
                    raise ValueError('No ownership receipt for existing desktop objects; nothing removed')
                print('Nothing was installed for this user'); return 0
            prior['phase'] = 'uninstalling'
            write(receipt, json.dumps(prior, sort_keys=True).encode(),0o600,receipt_state)
            for name, expected in prior['objects'].items():
                p=Path(name); current=state(p)
                if current is not None:
                    if current!=expected: raise ValueError('Desktop object changed; removal held')
                    p.unlink();sync_dir(p.parent)
            receipt.unlink();sync_dir(data)
            print('Sentinel Blue launcher removed. Download, services and ledgers were untouched.');return 0
        if prior and prior['phase']=='uninstalling':
            raise ValueError('Finish the interrupted --uninstall before installing again')
        for name in ('sentinel-blue','sentinel-blue.pyz','sentinel-blue.desktop','sentinel-blue.svg'):
            p=path_safe(here/name)
            if not p.is_file() or p.stat().st_uid != os.geteuid() or p.stat().st_nlink != 1:
                raise ValueError('Installer must sit beside owned regular file: '+name)
        template=(here/'sentinel-blue.desktop').read_text()
        if template.count('Exec=@EXEC@')!=1 or template.count('Icon=@ICON@')!=1:
            raise ValueError('Invalid desktop template')
        text=template.replace('Exec=@EXEC@','Exec=/bin/sh '+exec_value(here/'sentinel-blue')).replace('Icon=@ICON@','Icon=sentinel-blue').encode()
        outputs={entry:(text,0o755),icon:((here/'sentinel-blue.svg').read_bytes(),0o644)}
        if desktop.is_dir(): outputs[desktop/'sentinel-blue.desktop']=(text,0o755)
        desired={str(p):{'sha256':hashlib.sha256(content).hexdigest(),'mode':mode} for p,(content,mode) in outputs.items()}
        if prior and prior['objects'] != desired:
            raise ValueError('Desktop integration inputs changed; uninstall the recorded version before replacing it')
        if prior is None:
            for p in outputs:
                if state(p) is not None: raise ValueError('Refusing unowned existing desktop object: '+str(p))
        for p in outputs:p.parent.mkdir(parents=True,exist_ok=True)
        record={'format':FORMAT,'source_directory':str(here),'phase':'prepared','objects':desired}
        write(receipt,json.dumps(record,sort_keys=True).encode(),0o600,receipt_state)
        for p,(content,mode) in outputs.items():
            expected=state(p)
            if expected is not None and expected != desired[str(p)]:raise ValueError('Desktop object changed; installation held')
            if expected != desired[str(p)]:write(p,content,mode,expected)
        for name in ('sentinel-blue','sentinel-blue.pyz'):
            p=here/name;p.chmod(stat.S_IMODE(p.stat().st_mode)|0o500)
        record['phase']='committed'
        write(receipt,json.dumps(record,sort_keys=True).encode(),0o600,state(receipt))
        command=shutil.which('update-desktop-database')
        if command: subprocess.run([command,str(apps)],timeout=5,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        print('Sentinel Blue registered for this user. Open the application menu or desktop icon.')
        print('Your desktop may require Allow Launching / Trust once. No service or defense was started.')
        return 0
    finally:
        os.close(fd)

if __name__ == '__main__':
    try: raise SystemExit(main())
    except (OSError,ValueError,TypeError,KeyError,subprocess.SubprocessError) as exc:
        print('Sentinel Blue launcher installation held: '+str(exc),file=sys.stderr)
        raise SystemExit(1)
