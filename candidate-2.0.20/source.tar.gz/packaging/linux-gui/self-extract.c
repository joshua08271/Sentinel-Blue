/* Linux x86_64 offline launcher. No shell interpolation or network access.
 * Build with SB_PAYLOAD_SIZE and SB_PAYLOAD_SHA256, then append the archive.
 * It extracts into an owned private directory and verifies the appended bytes.
 */
#define _GNU_SOURCE
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#ifndef SB_PAYLOAD_SIZE
#error "A payload length and digest are required"
#endif

static void fail(const char *message) {
    fprintf(stderr, "Sentinel Blue: %s\n", message);
    if (getenv("DISPLAY")) {
        pid_t p = fork();
        if (p == 0) {
            execl("/usr/bin/zenity", "zenity", "--error", "--title=Sentinel Blue", "--text", message, (char *)NULL);
            execl("/usr/bin/xmessage", "xmessage", "-center", message, (char *)NULL);
            _exit(127);
        }
        if (p > 0) waitpid(p, NULL, 0);
    }
    exit(2);
}

static void join(char *out, size_t n, const char *base, const char *name) {
    if (snprintf(out, n, "%s/%s", base, name) >= (int)n) fail("The download or data path is too long.");
}

static void parents(const char *path) {
    char copy[PATH_MAX];
    if (strlen(path) >= sizeof(copy) || path[0] != '/') fail("The application data directory must be an absolute path.");
    strcpy(copy, path);
    for (char *c = copy + 1; ; c++) {
        if (*c != '/' && *c != '\0') continue;
        char saved = *c; *c = '\0';
        struct stat st;
        if (lstat(copy, &st)) {
            if (errno != ENOENT || mkdir(copy, 0700)) fail("Cannot create the private application directory. Check storage permissions.");
        } else if (!S_ISDIR(st.st_mode)) fail("The application data path contains a link or non-directory. Choose a normal local home directory.");
        *c = saved;
        if (!saved) break;
    }
}

static int child_ok(pid_t p) {
    int status;
    if (p <= 0) return 0;
    while (waitpid(p, &status, 0) < 0) if (errno != EINTR) return 0;
    return WIFEXITED(status) && WEXITSTATUS(status) == 0;
}

static void verify_archive(const char *path) {
    int fds[2]; if (pipe(fds)) fail("Cannot verify the offline download.");
    pid_t p = fork();
    if (p == 0) {
        close(fds[0]); dup2(fds[1], 1); close(fds[1]);
        execl("/usr/bin/sha256sum", "sha256sum", "--", path, (char *)NULL); _exit(127);
    }
    close(fds[1]); char result[65] = {0}; size_t count = 0;
    while (count < 64) {
        ssize_t n = read(fds[0], result + count, 64 - count);
        if (n < 0 && errno == EINTR) continue;
        if (n <= 0) break;
        count += (size_t)n;
    }
    /* Drain the bounded filename output before waiting for the checker. */
    char tail[4096]; while (read(fds[0], tail, sizeof(tail)) > 0) {}
    close(fds[0]);
    if (!child_ok(p) || count != 64 || strcmp(result, SB_PAYLOAD_SHA256))
        fail("The offline download is incomplete or corrupted. Download it again.");
}

int main(int argc, char **argv) {
    umask(077);
    char self[PATH_MAX], base[PATH_MAX], directory[PATH_MAX], staging[PATH_MAX], archive[PATH_MAX];
    ssize_t length = readlink("/proc/self/exe", self, sizeof(self)-1);
    if (length <= 0 || length >= (ssize_t)sizeof(self)-1) fail("Cannot find the downloaded application.");
    self[length] = '\0';
    const char *home = getenv("HOME"), *xdg = getenv("XDG_DATA_HOME");
    if (xdg && xdg[0] == '/') join(base, sizeof(base), xdg, "sentinel-blue");
    else if (home && home[0] == '/') join(base, sizeof(base), home, ".local/share/sentinel-blue");
    else fail("A local home directory is needed. Open Sentinel from your Linux desktop.");
    parents(base);
    struct stat st;
    if (lstat(base, &st) || st.st_uid != getuid() || (st.st_mode & 0077))
        fail("The Sentinel application directory must be owned by you and private (permissions 700). Use the file manager to correct it.");
    char build[128]; snprintf(build, sizeof(build), "linux-gui1-%.16s", SB_PAYLOAD_SHA256);
    join(directory, sizeof(directory), base, build);
    if (lstat(directory, &st)) {
        if (errno != ENOENT) fail("Cannot inspect the saved application directory.");
        join(staging, sizeof(staging), base, ".extract-XXXXXX");
        if (!mkdtemp(staging)) fail("Cannot unpack Sentinel. Check available disk space.");
        join(archive, sizeof(archive), staging, "payload.tar.gz");
        int in = open(self, O_RDONLY | O_CLOEXEC);
        int out = open(archive, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC, 0600);
        if (in < 0 || out < 0 || fstat(in, &st) || st.st_size <= (off_t)SB_PAYLOAD_SIZE ||
            lseek(in, st.st_size - (off_t)SB_PAYLOAD_SIZE, SEEK_SET) < 0) fail("The download is incomplete.");
        uint64_t remaining = SB_PAYLOAD_SIZE; char buffer[65536];
        while (remaining) {
            ssize_t n = read(in, buffer, remaining > sizeof(buffer) ? sizeof(buffer) : (size_t)remaining);
            if (n < 0 && errno == EINTR) continue;
            if (n <= 0) fail("The download ended early.");
            ssize_t done = 0;
            while (done < n) {
                ssize_t written = write(out, buffer + done, (size_t)(n-done));
                if (written < 0 && errno == EINTR) continue;
                if (written <= 0) fail("Not enough free space to unpack Sentinel.");
                done += written;
            }
            remaining -= (uint64_t)n;
        }
        if (fsync(out)) fail("Cannot save the offline application.");
        close(in); close(out);
        verify_archive(archive);
        pid_t p = fork();
        if (p == 0) {
            execl("/usr/bin/tar", "tar", "--extract", "--gzip", "--no-same-owner", "--no-same-permissions",
                "--file", archive, "--directory", staging, (char *)NULL); _exit(127);
        }
        if (!child_ok(p)) fail("The offline folder could not be unpacked. Check disk space and that tar is installed.");
        if (unlink(archive)) fail("Cannot finish unpacking the application.");
        if (rename(staging, directory))
            fail("Another launch may already be unpacking this version. Close this message and open it again.");
    }
    if (lstat(directory, &st) || !S_ISDIR(st.st_mode) || st.st_uid != getuid() || (st.st_mode & 0077))
        fail("The saved application directory is unsafe or unavailable.");
    char launcher[PATH_MAX]; join(launcher, sizeof(launcher), directory, "Start-Sentinel-Blue.sh");
    if (argc == 2 && strcmp(argv[1], "--verify-bundle") == 0)
        execl("/bin/sh", "sh", launcher, "--verify-bundle", (char *)NULL);
    else if (argc != 1) fail("Open this application by double-clicking it. It does not accept other commands.");
    else execl("/bin/sh", "sh", launcher, "desktop", "--foreground", (char *)NULL);
    fail("Could not open Sentinel. Keep the complete offline folder together.");
    return 2;
}
