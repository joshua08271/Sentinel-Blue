"""Retain selected private test evidence until the operator retrieves it.

No payload or command files are accepted. Unlike temporary delivery staging,
this explicitly requested result container survives an ephemeral Cloud Shell.
Delete the newly created container after checksum-verified local retrieval.
"""
from __future__ import annotations

import hashlib
import io
import json
from pathlib import Path
import secrets
from urllib.parse import urlparse
import zipfile

from azure_private_transfer import cli


def validate(data: bytes, *, nested=False):
    if len(data) > 32*1024*1024:
        raise ValueError('Evidence archive exceeds its bound')
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or len(names) > 32:
            raise ValueError('Evidence archive has duplicate or excess entries')
        total = 0
        for info in archive.infolist():
            name = info.filename
            if '/' in name or '\\' in name or ':' in name:
                raise ValueError('Evidence must contain only fixed flat filenames')
            total += info.file_size
            if info.file_size > 16*1024*1024 or total > 32*1024*1024:
                raise ValueError('Expanded evidence exceeds its bound')
            item = archive.read(info)
            if not nested and name in ('sb-linux-target-evidence.zip', 'sb-windows-target-evidence.zip'):
                validate(item, nested=True)
            elif name in ('result.json', 'setup-defensive-result.json', 'defensive-progress.json') or (
                    nested and name.startswith('defensive-') and name.endswith('.json')):
                json.loads(item)
            else:
                raise ValueError('Unexpected evidence filename')


def retain(path: Path, *, account: str, group: str, runtime_sha256: str) -> dict:
    if len(runtime_sha256) != 64 or any(c not in '0123456789abcdef' for c in runtime_sha256):
        raise ValueError('A complete runtime checksum is required')
    data = path.read_bytes()
    validate(data)
    state = cli('storage','account','show','--name',account,'--resource-group',group)
    endpoint = urlparse(state['primaryEndpoints']['blob'])
    if state.get('allowBlobPublicAccess') is not False or endpoint.scheme != 'https' or endpoint.hostname != account+'.blob.core.windows.net':
        raise ValueError('Result retention requires the existing private storage account')
    container = 'sentinel-results-'+secrets.token_hex(12)
    common = ['--account-name',account,'--auth-mode','key']
    created = False
    try:
        reply = cli('storage','container','create','--name',container,'--public-access','off',*common)
        if reply.get('created') is not True:
            raise RuntimeError('Result container was not newly created')
        created = True
        checksum = hashlib.sha256(data).hexdigest()
        cli('storage','blob','upload','--container-name',container,'--name','evidence.zip',
            '--file',str(path),'--overwrite','false','--metadata',
            'sha256='+checksum,'runtime_sha256='+runtime_sha256,*common)
        row = cli('storage','blob','show','--container-name',container,'--name','evidence.zip',*common)
        if row.get('properties',{}).get('contentLength') != len(data) or row.get('metadata',{}).get('sha256') != checksum:
            raise RuntimeError('Private result upload was not verified')
        return {'account':account,'container':container,'blob':'evidence.zip',
                'sha256':checksum,'bytes':len(data),'runtime_sha256':runtime_sha256,
                'cleanup_required_after_retrieval':True}
    except BaseException:
        if created:
            cli('storage','container','delete','--name',container,*common)
        raise
