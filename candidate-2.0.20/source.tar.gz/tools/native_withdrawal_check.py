"""Disposable local Linux account inverse; no production account is changed."""
import hashlib
import json
import os
from pathlib import Path
import secrets
import subprocess
import tempfile
import uuid


def run():
    if os.name != 'posix' or os.geteuid() != 0:
        raise RuntimeError('Disposable Linux root fixture required')
    name = 'sbwd_' + uuid.uuid4().hex[:12]
    created = False
    with tempfile.TemporaryDirectory(prefix='sentinel-native-withdraw-') as directory:
        try:
            admission = subprocess.run(['useradd', '--no-create-home', '--shell', '/usr/sbin/nologin', name], capture_output=True)
            import pwd
            try:
                pwd.getpwnam(name)
                created = True
            except KeyError:
                pass
            if admission.returncode:
                raise RuntimeError('Native fixture unavailable: ' + admission.stderr.decode(errors='replace')[:500])
            created = True
            subprocess.run(['chpasswd'], input=(name + ':' + secrets.token_urlsafe(32) + '\n').encode(), check=True, capture_output=True)
            from sentinel_blue.security_native import NativeSecurityBackend
            from sentinel_blue.mutation_ledger import MutationLedger
            from sentinel_blue.mutation_tracking import enable
            from sentinel_blue.withdrawal import guest
            os.environ['SENTINEL_LEDGER_DIR'] = directory + '/ledger'
            enable()
            native = NativeSecurityBackend()
            account = native.account(name)
            rows = Path('/etc/shadow').read_bytes().splitlines(keepends=True)
            prefix = name.encode() + b':'
            before = next(x for x in rows if x.startswith(prefix))
            others = b''.join(x for x in rows if not x.startswith(prefix))
            native.set_password(name, account['account_id'], secrets.token_urlsafe(32))
            ledger = MutationLedger()
            action = ledger.actions()[0]
            changed = next(x for x in Path('/etc/shadow').read_bytes().splitlines(keepends=True) if x.startswith(prefix))
            if changed == before:
                raise RuntimeError('Native password fixture did not mutate')
            ledger.pause('native-test')
            result = guest({'operation': 'undo', 'action_id': action['action_id']}, ledger)
            rows = Path('/etc/shadow').read_bytes().splitlines(keepends=True)
            restored = next(x for x in rows if x.startswith(prefix))
            untouched = b''.join(x for x in rows if not x.startswith(prefix))
            if restored != before or untouched != others:
                raise RuntimeError('Native account inverse or unrelated-account preservation failed')
            return {'platform': 'linux', 'fixture': 'disposable local account', 'native': True,
                    'password_changed': True, 'exact_shadow_row_restored': True, 'all_other_shadow_rows_preserved': True,
                    'withdrawal_status': result['status'], 'ledger_head': ledger.head(),
                    'external_multi_host_test': False, 'windows_native_test': False}
        finally:
            if created:
                subprocess.run(['userdel', name], check=True, capture_output=True)


if __name__ == '__main__':
    print(json.dumps(run(), indent=2))
