"""Build the complete Linux offline release using ONLY an existing local payload.

Example (from source/ in a complete extracted bundle):
  ../runtime/bin/python3 -I -B tools/build_offline_release.py \
      --python-root ../runtime --dependency-manifest ../offline-manifest.json \
      --output /a/new/local/output-directory
No pip, network fetch, activation, or external build package is used.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
# Deliberate fixed local source root for standalone invocation under -I.
sys.path.insert(0, str(ROOT))
from tools.build_defensive_release import build as build_runtime
from tools.build_release import VERSION


def digest(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def source_files(root):
    for p in sorted(Path(root).rglob('*')):
        if '__pycache__' in p.parts or p.suffix in {'.pyc', '.pyo'} or '.git' in p.parts:
            continue
        if p.is_symlink():
            raise ValueError('Source/payload symbolic links are not accepted: ' + str(p))
        if p.is_file():
            yield p


def build(python_root, dependency_manifest, output):
    python_root = Path(python_root).resolve()
    output = Path(output).resolve()
    if output.exists() or output.is_relative_to(ROOT) or output.is_relative_to(python_root):
        raise ValueError('Use a new output directory outside the source and Python payload')
    prior = json.loads(Path(dependency_manifest).read_text())
    if prior.get('target') != 'linux-x86_64':
        raise ValueError('This builder restores Linux x86_64, not Windows or another architecture')
    if not (python_root/'bin/python3').is_file():
        raise ValueError('Local standalone Python payload is missing')
    # New manifests authenticate payload content against its prior inventory.
    # Initial conversion is verified against the separate historical ZIP SHA256SUMS.
    inventory = {p.relative_to(python_root).as_posix():
                 {'sha256': digest(p), 'mode': stat.S_IMODE(p.stat().st_mode)} for p in source_files(python_root)}
    if prior.get('dependency_files') is not None and inventory != prior['dependency_files']:
        raise ValueError('Local dependency files differ from the supplied manifest')
    if any(Path(n).suffix.lower() in {'.ttf','.otf','.woff','.woff2','.pcf','.bdf'} or n.endswith('.pcf.gz') for n in inventory):
        raise ValueError('Unexpected font payload: do not redistribute host font files')
    if not any('license' in n.lower() or 'copying' in n.lower() for n in inventory):
        raise ValueError('Dependency licenses are missing')
    output.mkdir(parents=True)
    runtime = build_runtime(output)
    folder = 'Sentinel-Blue-' + VERSION + '-linux-x86_64'
    root = output / folder
    root.mkdir()
    shutil.copytree(python_root, root/'runtime', ignore=shutil.ignore_patterns('__pycache__','*.pyc','*.pyo'))
    shutil.copyfile(runtime, root/'sentinel-blue.pyz')
    for name in ('launch.py','Start-Sentinel-Blue.sh','sentinel-blue','install-linux-launcher.sh'):
        shutil.copyfile(ROOT/'packaging/offline'/name,root/name)
        (root/name).chmod(0o755 if name != 'launch.py' else 0o644)
    for name in ('install-linux-launcher.py','sentinel-blue.svg','sentinel-blue.desktop'):
        shutil.copyfile(ROOT/'packaging/linux-desktop'/name,root/name)
    shutil.copyfile(ROOT/'LICENSE',root/'LICENSE-Sentinel-Blue.txt')
    guide = ROOT/f'docs/OFFLINE_RELEASE_{VERSION}.md'
    shutil.copyfile(guide,root/'START-HERE.md')
    (root/'START-HERE.txt').write_text(
        f'Sentinel Blue {VERSION} - complete offline Linux x86_64 distribution\n\n'
        'Extract every file. Open Start-Sentinel-Blue.sh, or run ./Start-Sentinel-Blue.sh\n'
        'No preinstalled Python, pip, internet, activation, cloud, or AI API is required.\n'
        'A Linux x86_64 glibc 2.34+ system and an X11/XWayland desktop are required.\n'
        'Optional menu/desktop integration: sh install-linux-launcher.sh\n'
        'Do not open the sentinel-blue.desktop template directly; use the installer.\n'
        'Check all distributed files: ./Start-Sentinel-Blue.sh --verify-bundle\n'
        'Check libraries/window: ./Start-Sentinel-Blue.sh offline-check --desktop\n\n'
        'The GUI does not start services or deploy agents merely by opening it.\n'
        'Approved local-range networking and operator credentials are still required\n'
        'for controllers, agents, and observers on separate machines.\n'
        'Read START-HERE.md before setup. LINUX-31 through LINUX-36 are corrected; earlier fixes are retained; native acceptance remains separate.\n',encoding='utf-8')
    for p in source_files(ROOT):
        q=root/'source'/p.relative_to(ROOT);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
    manifest = {'schema':1,'version':VERSION,'target':'linux-x86_64',
        'runtime_sha256':digest(runtime),'python':prior['python'],
        'provenance':prior['provenance'], 'dependency_files':inventory,
        'offline_contract':{'runtime_downloads':False,'startup_requires_system_python':False,
            'automatic_online_prerequisites':False,'local_range_networking':True,
            'arbitrary_runbooks_are_not_sandboxed':True},
        'dependency_payload_source':prior.get('dependency_payload_source',{
            'archive':'sentinel-blue-1.9.75-offline-linux-x86_64-recovered.zip',
            'sha256':'c9b7542b79a51cb84e9ec96221062f65f8366734b344b376e32d1980484ef80a'}),
        'dependency_bytes_preserved':True,'downloaded_dependencies':False,
        'corrected_findings':['LINUX-'+str(i) for i in range(1, 37)],
        'native_acceptance_complete':False}
    manifest_path=root/'offline-manifest.json'
    manifest_path.write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
    checked = subprocess.run([str(root/'runtime/bin/python3'),'-I','-B',str(root/'launch.py'),'offline-check'],
        capture_output=True,text=True,timeout=45,
        env=dict(os.environ,PYTHONHOME='/invalid-system-python',PYTHONPATH='/invalid-site-packages'))
    if checked.returncode:
        raise RuntimeError('Bundled dependency check failed: '+checked.stdout[-2000:]+checked.stderr[-2000:])
    manifest['dependency_check']=json.loads(checked.stdout)
    manifest_path.write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
    # This is a fixed content inventory; later user state outside it is not overwritten.
    paths=list(source_files(root))
    (root/'SHA256SUMS').write_text(''.join(digest(p)+'  '+p.relative_to(root).as_posix()+'\n' for p in paths))
    archive=output/f'sentinel-blue-{VERSION}-offline-linux-x86_64.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for path in source_files(root):
            info=zipfile.ZipInfo(folder+'/'+path.relative_to(root).as_posix(),(2026,1,1,0,0,0))
            info.create_system=3;info.external_attr=(stat.S_IFREG|stat.S_IMODE(path.stat().st_mode))<<16
            z.writestr(info,path.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=6)
    with zipfile.ZipFile(archive) as z:
        if z.testzip():raise ValueError('ZIP integrity failed')
    return {'version':VERSION,'archive':str(archive),'archive_bytes':archive.stat().st_size,
            'sha256':digest(archive),'bundle_root':str(root),'runtime_sha256':digest(runtime),
            'dependency_files':len(inventory),'dependency_check':manifest['dependency_check']}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--python-root',type=Path,required=True)
    p.add_argument('--dependency-manifest',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();print(json.dumps(build(a.python_root,a.dependency_manifest,a.output),indent=2))
