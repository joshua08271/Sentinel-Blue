"""Prove one Linux service pack against the real product, on a host you can lose.

Every shipped catalog row reports ``native_tested: False``. Native tests produce
scoped local receipts; they do not change the source flags or grant authority.
Run only against an installed product on an explicitly disposable host.

    python3 tools/service_pack_acceptance.py --service redis --plan
    python3 tools/service_pack_acceptance.py --service redis \\
        --options redis.json --operator jj \\
        --profile redis-transactions.json \\
        --host-is-disposable --run

``--plan`` prints a command template and structural blockers without running any
service command. Exact execution plans still require ordinary digest approval. Read that output before you use
``--run``: these steps deliberately edit real configuration, restart real
services, make a failure happen mid-apply, and roll it back.

``--run`` refuses unless you say the host is disposable, and unless it is root on
a Debian-family machine with systemd. It writes a report every time. It writes a
**receipt** only when every required step passed, and a receipt claims nothing
beyond what it recorded: one pack, one exact set of reviewed options, one product
version, on this host, with this runtime.

What it will not do: invent a transaction. The scored transaction a service must
answer, and the weakening that service must refuse, are product knowledge this
tool does not assume. Supply them in a profile. Without one those steps are
skipped, and because they are required, no receipt is written. That is the
intended outcome — a pack is not accepted because the configuration parsed.
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from acceptance_profile import MATCH_FIELDS, probe_problems, profile_problems, argv_safety_problems

from sentinel_blue import pack_acceptance                      # noqa: E402
from sentinel_blue.linux_service_catalog import CATALOG, CONFIGURE, entry   # noqa: E402

DISPOSABLE = "--host-is-disposable"
COMMAND_TIMEOUT = 300

# What a profile may hold, and what --run will not proceed without. These are
# module constants because the shipped example and its test read them from here:
# when the gate gained update_options and invalid_options in 1.9.88 the example
# was not updated with it, and for five releases no service could be accepted.
PROFILE_KEYS = ("positive", "denied", "config_test", "effective", "update_options",
                "invalid_options", "rejected_options", "host", "withdrawal", "data_invariants")
REQUIRED_PROFILE_KEYS = ("positive", "denied", "effective", "update_options",
                         "invalid_options", "withdrawal")
WHAT_EACH_KEY_IS = {
    "positive": "the scored transaction this service must answer",
    "denied": "the weakening this service must refuse",
    "effective": "a query that asks the running product what it is using",
    "update_options": "a second reviewed option set, to prove an approved change",
    "invalid_options": "a compiling option set the native product rejects after writes, with exact preceding-state hashes",
    "withdrawal": "how to reach the separate observer that confirms the restore",
    "config_test": "the product's own offline configuration test",
}


# --------------------------------------------------------------- execution

class Executor:
    """Runs commands on this host. Replaced by a fake in tests."""

    def __init__(self, *, dry_run: bool = False):
        self.dry_run = dry_run
        self.log: list[dict] = []

    def run(self, argv, *, input_text=None, timeout=COMMAND_TIMEOUT):
        record = {"argv": list(argv)}
        if self.dry_run:
            record.update(returncode=-1, stdout="", stderr="dry run is not execution evidence", skipped=True)
            self.log.append(record)
            return record
        try:
            # Preserve complete bounded JSON for decisions. Logs may be shortened,
            # but truncation is never silently parsed as successful evidence.
            with tempfile.TemporaryFile() as out, tempfile.TemporaryFile() as err:
                done = subprocess.run([str(a) for a in argv], stdout=out, stderr=err,
                                      input=input_text, text=True, timeout=timeout)
                out.seek(0); err.seek(0)
                stdout, stderr = out.read(8 * 1024 * 1024 + 1), err.read(8 * 1024 * 1024 + 1)
            too_large = max(len(stdout),len(stderr)) > 8 * 1024 * 1024
            record.update(returncode=-1 if too_large else done.returncode,
                          stdout=stdout[:8 * 1024 * 1024].decode(errors="replace"),
                          stderr="output limit exceeded; no evidence claim" if too_large else stderr.decode(errors="replace"),
                          truncated=too_large)
        except (OSError, subprocess.SubprocessError) as exc:
            record.update(returncode=-1, stdout="", stderr=f"{type(exc).__name__}: {exc}", infrastructure_error=True)
        self.log.append(record.copy())
        return record

    def snapshot(self, paths):
        from acceptance_snapshot import snapshot_paths
        return snapshot_paths(paths)

    def watch_writes(self, paths):
        from acceptance_host import WriteWatch
        return WriteWatch(paths)

    def stage_edit(self, path, marker, backup_dir):
        from acceptance_host import stage_edit
        return stage_edit(path, marker, backup_dir)

    def restore_edit(self, token):
        from acceptance_host import restore_edit
        return restore_edit(token)

    def service_state(self, unit):
        from acceptance_snapshot import SnapshotError
        fields = ('LoadState','ActiveState','UnitFileState','InvocationID','MainPID',
                  'ExecMainStartTimestampMonotonic','ActiveEnterTimestampMonotonic','NRestarts')
        result = self.run(['systemctl','show','--property='+','.join(fields),'--',unit])
        if result['returncode'] != 0:
            raise SnapshotError('cannot observe service lifecycle')
        values = {}
        for line in result['stdout'].splitlines():
            key,sep,value = line.partition('=')
            if not sep or key not in fields or key in values or len(value) > 128:
                raise SnapshotError('malformed service lifecycle output')
            values[key] = value
        if set(values) != set(fields):
            raise SnapshotError('service lifecycle fields are missing')
        for key in ('MainPID','ExecMainStartTimestampMonotonic','ActiveEnterTimestampMonotonic','NRestarts'):
            if not values[key].isascii() or not values[key].isdigit() or len(values[key]) > 20:
                raise SnapshotError('invalid numeric service lifecycle field')
        if values['InvocationID'] and not re.fullmatch(r'[0-9a-f]{32}', values['InvocationID']):
            raise SnapshotError('invalid service invocation identity')
        if values['ActiveState']=='active' and (not values['InvocationID'] or
                not int(values['ActiveEnterTimestampMonotonic'])):
            raise SnapshotError('active service lacks stable invocation evidence')
        return values

    def port_open(self, port, host="127.0.0.1", timeout=5):
        if self.dry_run:
            return True
        try:
            with socket.create_connection((host, int(port)), timeout=timeout):
                return True
        except OSError:
            return False


class Report:
    def __init__(self, service_id):
        self.service_id = service_id
        self.results: dict[str, dict] = {}

    def record(self, step, verdict, detail=""):
        self.results[step] = {"verdict": verdict, "detail": str(detail)[:500]}
        marker = {"passed": "  ok  ", "failed": " FAIL ", "skipped": " skip "}[verdict]
        print(f"[{marker}] {step:22} {str(detail)[:90]}")
        return verdict == "passed"

    @property
    def required_all_passed(self):
        return all(self.results.get(name, {}).get("verdict") == "passed"
                   for name in pack_acceptance.REQUIRED)


# ------------------------------------------------------------------ guards

def refuse(message):
    print(f"acceptance refused: {message}", file=sys.stderr)
    raise SystemExit(2)


def check_host(arguments):
    """The conditions under which this may touch a machine at all."""
    if not arguments.host_is_disposable:
        refuse(f"this rewrites real configuration and restarts real services. "
               f"Pass {DISPOSABLE} only on a host you can destroy.")
    if os.name != "posix":
        refuse("the Linux service packs are Linux only")
    if hasattr(os, "geteuid") and os.geteuid() != 0:
        refuse("root is required to configure a service")
    identity = pack_acceptance.platform_identity()
    if identity["id"] not in {"debian", "ubuntu", "kali"}:
        family = identity["id"]
        refuse(f"these packs emit a Debian-family layout and this host reports ID={family}")
    if shutil.which("systemctl") is None:
        refuse("systemd is required; these packs manage units")
    try:
        pid1 = Path("/proc/1/comm").read_text(encoding="utf-8").strip()
    except OSError:
        pid1 = ""
    if pid1 != "systemd":
        refuse(f"PID 1 is {pid1!r}, not systemd; a container stand-in cannot accept a unit")


def load_json_argument(path, label):
    try:
        from sentinel_blue.json_codec import strict_json_loads
        with Path(path).open('rb') as handle:
            raw = handle.read(2 * 1024 * 1024 + 1)
        payload = strict_json_loads(raw, max_bytes=2 * 1024 * 1024)
    except (OSError, ValueError) as exc:
        refuse(f"could not read the {label}: {exc}")
    if not isinstance(payload, dict):
        refuse(f"the {label} must be a JSON object")
    return payload


def absolute_sources(value, base):
    """Preserve hash-pinned references relative to the file that supplied them.

    Does not expand arbitrary command arguments or target-host paths. Both plan
    and run use this same read-only transform before staging inventory copies.
    """
    if isinstance(value, dict):
        if set(value) == {'path', 'sha256'} and isinstance(value.get('path'), str):
            path = Path(value['path']).expanduser()
            return {**value, 'path': str(path if path.is_absolute() else (base/path).absolute())}
        return {k: absolute_sources(v, base) for k, v in value.items()}
    if isinstance(value, list):
        return [absolute_sources(v, base) for v in value]
    return value


# ------------------------------------------------------------------- steps

def probe_verdict(result, expectation, *, require_denial=False):
    """Judge one probe. Exit status alone is not enough for several products.

    `dig` exits 0 for a refused transfer and for an empty answer, and a client
    that prints an error while returning success is common enough that a probe
    which only reads the exit status can call a failure a pass. So a profile may
    also require text to be present or absent in the output.
    """
    reasons = []
    if not isinstance(result, dict) or not isinstance(expectation, dict):
        return False, 'malformed probe result or expectation'
    if require_denial or expectation.get('expect_failure') is True:
        if not any(isinstance(expectation.get(k), list) and expectation[k]
                   for k in ('expect_stdout_contains', 'expect_stderr_contains', 'expect_output_contains')):
            return False, 'no explicit product refusal signature; an arbitrary client failure is not denied access'
    if any(not isinstance(result.get(k), str) for k in ('stdout', 'stderr')):
        return False, 'missing or malformed captured output'
    if (type(result.get('returncode')) is not int or result['returncode'] < 0 or
            result.get('infrastructure_error') or result.get('truncated') or result.get('skipped')):
        return False, 'probe was not validly executed; an infrastructure error is not denied access'
    declared = {'argv': ['/internal/probe'], **expectation}
    problems = probe_problems(declared, 'probe', denial=require_denial)
    if problems:
        return False, '; '.join(problems)
    expected = expectation.get("expect_returncode")
    if expected is None and not expectation.get('expect_failure'):
        expected = 0
    if expected is not None and result["returncode"] != expected:
        reasons.append(f"exit {result['returncode']}, wanted {expected}")
    if expected is None and expectation.get("expect_failure") and result["returncode"] == 0:
        reasons.append("succeeded, and it had to be refused")
    streams = {'stdout': result['stdout'], 'stderr': result['stderr'],
               'output': result['stdout'] + '\n' + result['stderr']}
    for stream, output in streams.items():
        for suffix, present in (('contains', True), ('absent', False)):
            matchers = expectation.get('expect_' + stream + '_' + suffix, [])
            if not isinstance(matchers, list) or len(matchers) > 32 or any(
                    not isinstance(v, str) or not v or len(v) > 1024 for v in matchers):
                return False, 'malformed output expectations'
            for needle in matchers:
                if (needle in output) != present:
                    reasons.append(stream + (' did not contain ' if present else ' contained forbidden ') + repr(needle))
    return (not reasons), "; ".join(reasons) or "as expected"


def plan_commands(service_id, row, profile):
    """A review template; exact paths/digests are supplied by native planning."""
    unit = row["unit"]
    lines = []
    lines.append(("preflight", ["systemctl", "list-unit-files", f"{unit}.service"]))
    apt = row["packages"].get("apt") or []
    lines.append(("preflight", ["/bin/sh", "-c", f"dpkg -s {' '.join(apt)}"] if apt else
                  ["<no distribution package: the unit wraps an application you supply>"]))
    lines.append(("initial-state", ["systemctl", "is-active", unit]))
    for path in row["config_paths"]:
        lines.append(("pre-state", ["<bounded typed tree snapshot>", path]))
    lines.append(("compile", [sys.executable, "-m", "sentinel_blue", "setup",
                              "--inventory", "<generated>", "--plan-out", "<plan.json>"]))
    lines.append(("apply", [sys.executable, "-m", "sentinel_blue", "setup",
                            "--inventory", "<generated>", "--execute",
                            "--approve-plan", "<digest printed by the planning step>"]))
    config_test = (profile.get("config_test") or {}).get("argv") or row["validate_argv"]
    lines.append(("config-test", list(config_test) if config_test
                  else ["<no offline test for this product: supply config_test in the profile>"]))
    lines.append(("service-active", ["systemctl", "is-active", "--quiet", "--", unit]))
    positive = profile.get("positive")
    lines.append(("positive-transaction", positive["argv"] if positive
                  else ["<missing required product transaction; no receipt>"]))
    denied = profile.get("denied")
    lines.append(("denied-transaction", denied["argv"] if denied
                  else ["<no profile: this step will be skipped and no receipt written>"]))
    lines.append(("effective-settings", (profile.get('effective') or {}).get('argv') or
                  ["<required product-specific effective-settings query>"]))
    lines.append(("identical-reapply", [sys.executable, "-m", "sentinel_blue", "setup",
                                        "--inventory", "<generated>", "--execute",
                                        "--approve-plan", "<same digest>"]))
    lines.append(("approved-update", [sys.executable, "-m", "sentinel_blue", "setup",
                                      "--inventory", "<updated>", "--execute",
                                      "--approve-plan", "<new digest>"]))
    lines.append(("outside-edit-refused", ["<stage exact owned-file edit with private backup, verify refusal, compare-and-restore cleanup>"]))
    lines.append(("interrupted-setup", ["<watch owned-path writes, apply product-rejected configuration, verify failed apply and exact rollback>"]))
    lines.append(("restart-survives", ["systemctl", "restart", "--", unit]))
    lines.append(("rollback", ["<reviewed observer runtime>", "withdraw", "--mode", "restore-withdraw",
                               "--inventory", "<explicit observer inventory>", "--event-profile", "<approved profile>",
                               "--directory", "<new private review directory>"]))
    lines.append(("rollback", ["<same observer command>", "--approved-digest", "<exact review digest>"]))
    lines.append(("withdrawal", ["<verify complete result, independent checks and captured filesystem/data states>"]))
    lines.append(("reboot-survives", ["<not implemented in this walk: separate real reboot/resume campaign>"]))
    lines.append(("independent-client", ["<optional; needs a second authorized host>"]))
    return lines


def show_plan(service_id, options, profile, *, root=None):
    row = entry(service_id)
    print(f"Acceptance plan for {row['label']} ({service_id})")
    print(f"  unit             {row['unit']}")
    print(f"  apt packages     {', '.join(row['packages'].get('apt') or []) or 'none declared; the unit wraps an application you supply'}")
    print(f"  configuration    {', '.join(row['config_paths'])}")
    print(f"  data preserved   {', '.join(row['data_paths']) or 'none declared'}")
    print(f"  declared ports   {', '.join(str(p) for p in row['ports']) or 'none'}")
    print(f"  scoring clients  {', '.join(row['clients']) or 'none'}")
    print()
    print(f"  {len(pack_acceptance.REQUIRED)} required steps, "
          f"{len(pack_acceptance.OPTIONAL)} optional. A receipt needs every required step.")
    print()
    for step in pack_acceptance.MATRIX:
        mark = "required" if step["required"] else "optional"
        print(f"  [{mark}] {step['id']}")
        print(f"             {step['asks']}")
    print()
    print("Commands, in order: (template; runtime paths, digests and file lists are bound at execution)")
    for step, argv in plan_commands(service_id, row, profile):
        unsafe = argv_safety_problems(argv, step)
        printable = ('<unsafe client arguments withheld; review profile blockers>' if unsafe
                     else " ".join(str(a) for a in argv))
        print(f"  {step:22} {printable[:130]}")
    print()
    print("\nRead-only profile checks (not native acceptance):")
    if options is None:
        print("  BLOCKED: reviewed --options are missing; no receipt would be written.")
    else:
        problems = profile_problems(service_id, options, profile, root or Path.cwd())
        if problems:
            print("  BLOCKED: no receipt would be written with these inputs.")
        for problem in problems:
            print("  BLOCKED: " + problem)
        if not problems:
            print("  Structural and generated-state contracts pass; native execution remains unproven.")
    print("  Builder-refusal examples do not replace failed-apply-after-writes tests.")


def execute(service_id, options, profile, arguments, executor, runtime=None):
    """Walk the matrix. Returns (report, pack fingerprint or None)."""
    from acceptance_steps import Acceptance, Runtime

    row = entry(service_id)
    report = Report(service_id)
    try:
        fingerprint = pack_acceptance.pack_fingerprint(service_id, options, Path(arguments.workdir))
    except Exception as exc:                                  # noqa: BLE001
        report.record("compile", "failed", f"{type(exc).__name__}: {exc}")
        return report, None

    if runtime is None:
        runtime = Runtime(executor, [sys.executable, str(arguments.runtime)],
                          event_profile=arguments.event_profile,
                          range_deployment=arguments.range_deployment,
                          withdrawal=profile.get('withdrawal'))

    walk = Acceptance(service_id=service_id, row=row, options=options, profile=profile,
                      executor=executor, runtime=runtime, workdir=arguments.workdir,
                      inventory=arguments.inventory, report=report, fingerprint=fingerprint)
    walk.walk()
    return report, fingerprint


# -------------------------------------------------------------------- main

def main(argv=None):
    parser = argparse.ArgumentParser(
        prog="service_pack_acceptance",
        description="Prove one Linux service pack against the real product.")
    parser.add_argument("--service", required=True, help="a catalog service id")
    parser.add_argument("--runtime", help="exact reviewed .pyz under acceptance; mandatory for --run")
    parser.add_argument("--range-deployment", action="store_true", help="use the existing explicitly permitted range profile path")
    parser.add_argument("--options", help="JSON file: the reviewed options for the pack")
    parser.add_argument("--profile", help="JSON file: the positive and denied transactions")
    parser.add_argument("--inventory", help="the reviewed inventory for this host")
    parser.add_argument("--event-profile", help="the explicit approved event profile; required for --run")
    parser.add_argument("--operator", help="who is running this")
    parser.add_argument("--product-version", help="the product version being accepted")
    parser.add_argument("--state-dir", default=str(Path.home() / ".sentinel-blue"),
                        help="where the receipt is written")
    parser.add_argument("--workdir", default=None, help="scratch directory for compilation")
    parser.add_argument("--report", help="write the full report here")
    parser.add_argument("--plan", action="store_true", help="print the plan and change nothing")
    parser.add_argument("--run", action="store_true", help="execute against this host")
    parser.add_argument(DISPOSABLE, action="store_true",
                        help="confirm this host may be destroyed")
    arguments = parser.parse_args(argv)

    if arguments.service not in CATALOG:
        refuse(f"{arguments.service!r} is not a catalog service")
    row = entry(arguments.service)
    if row["capability"] != CONFIGURE:
        refuse(f"{row['label']} is adoption-only: it generates no configuration, "
               "so there is nothing to accept")

    options = load_json_argument(arguments.options, "options file") if arguments.options else None
    profile = load_json_argument(arguments.profile, "profile") if arguments.profile else {}
    # Either file may hold one service's section, or several keyed by service id
    # (which is how the shipped examples are written). Take the matching section.
    if arguments.service in profile and isinstance(profile[arguments.service], dict):
        profile = profile[arguments.service]
    if options is not None and isinstance(options.get(arguments.service), dict):
        options = options[arguments.service]
    # A commented example stays readable, and a comment is not a service option.
    if options is not None:
        options = {k: v for k, v in options.items() if not k.startswith("_")}
    known = set(PROFILE_KEYS)
    unknown = {k for k in profile if not k.startswith("_")} - known
    if unknown:
        refuse(f"the profile for {arguments.service} holds {sorted(unknown)}, which this "
               f"harness does not use. It reads: {', '.join(sorted(known))}.")
    # A commented example stays readable, and a comment is not a service option.
    for key in ("update_options", "invalid_options", "rejected_options"):
        if isinstance(profile.get(key), dict):
            profile[key] = {k: v for k, v in profile[key].items() if not k.startswith("_")}

    for key in ('positive','denied','config_test','effective'):
        spec = profile.get(key)
        if spec is None:
            continue
        if not isinstance(spec, dict) or not isinstance(spec.get('argv'), list) or not 1 <= len(spec['argv']) <= 64 or any(
                not isinstance(x,str) or not x or '\x00' in x or len(x)>4096 for x in spec['argv']):
            refuse(key + ' requires a bounded literal argv array')
        for field in MATCH_FIELDS:
            if field in spec and (not isinstance(spec[field],list) or any(not isinstance(x,str) or not x or len(x)>1024 for x in spec[field])):
                refuse(key + ' requires literal output match strings')
        if 'expect_failure' in spec and type(spec['expect_failure']) is not bool:
            refuse('expect_failure must be a boolean')
        if 'expect_returncode' in spec and type(spec['expect_returncode']) is not int:
            refuse('expect_returncode must be an integer')
    for key in ('update_options','invalid_options','rejected_options','data_invariants','withdrawal'):
        if key in profile and not isinstance(profile[key],dict):
            refuse(key + ' must be an object')

    options = absolute_sources(options, Path(arguments.options).absolute().parent if arguments.options else Path.cwd())
    profile = absolute_sources(profile, Path(arguments.profile).absolute().parent if arguments.profile else Path.cwd())
    if arguments.plan or not arguments.run:
        show_plan(arguments.service, options, profile, root=Path.cwd())
        return 0

    check_host(arguments)
    if options is None:
        refuse("--run needs --options: the reviewed options the pack is built from")
    if not arguments.inventory:
        refuse("--run needs --inventory: the reviewed inventory this host is set up from. "
               "Without it the apply, rollback and withdrawal steps cannot run, and no "
               "receipt is possible.")
    if not arguments.operator:
        refuse("--run needs --operator: a receipt records who produced it")
    if not arguments.product_version:
        refuse("--run needs --product-version: a receipt records what was accepted")

    missing = [key for key in REQUIRED_PROFILE_KEYS if not profile.get(key)]
    if not (profile.get('config_test') or row.get('validate_argv')):
        missing.append('config_test')
    if missing:
        detail = '\n'.join(f'  {key}: {WHAT_EACH_KEY_IS[key]}' for key in missing)
        refuse('no mutations admitted: the acceptance profile for '
               f'{arguments.service} is missing\n{detail}\n'
               'examples/acceptance-profile.example.json carries a reviewed draft of '
               'the product transaction drafts. Native failed-apply inputs, exact update pre-states, '
               'and observer wiring must be reviewed separately; a planning refusal is not rollback evidence.')

    if not arguments.runtime or not arguments.event_profile:
        refuse('--run requires the exact --runtime .pyz and explicit --event-profile')
    # The tool's planners and the tested artifact must be from the same build.
    import zipfile
    try:
        artifact = Path(arguments.runtime).resolve(strict=True)
        with zipfile.ZipFile(artifact) as archive:
            if archive.testzip() is not None:
                raise ValueError('damaged runtime')
            for name in archive.namelist():
                if name.startswith('sentinel_blue/') and not name.endswith('/'):
                    original = ROOT / 'src' / name
                    if not original.is_file() or archive.read(name) != original.read_bytes():
                        raise ValueError('runtime does not match the harness source tree')
        arguments.runtime = str(artifact)
    except (OSError, ValueError, zipfile.BadZipFile) as exc:
        refuse('runtime validation failed: ' + str(exc))
    problems = profile_problems(arguments.service, options, profile, Path.cwd())
    if problems:
        refuse('no mutations admitted:\n  ' + '\n  '.join(problems))
    # Do not discover a missing native checking client only after configuring a service.
    probes = [profile[k] for k in ('positive', 'denied', 'effective', 'config_test') if profile.get(k)]
    probes.extend(profile.get('data_invariants', {}).values())
    for spec in probes:
        if shutil.which(spec['argv'][0]) is None:
            refuse('no mutations admitted: checking executable is unavailable: ' + spec['argv'][0])
    if shutil.which(profile['withdrawal']['runtime_argv'][0]) is None:
        refuse('no mutations admitted: independent observer forwarding executable is unavailable')
    if arguments.workdir is None:
        arguments.workdir = tempfile.mkdtemp(prefix="sentinel-acceptance-")
    work = Path(arguments.workdir).absolute()
    if work.is_symlink() or work.exists() and any(work.iterdir()):
        refuse('workdir must be new or empty; prior experiment evidence is not overwritten')
    work.mkdir(mode=0o700,parents=True,exist_ok=True)
    os.chmod(work,0o700)
    arguments.workdir = str(work)
    if not arguments.report:
        arguments.report = str(work/'report.json')
    executor = Executor()
    started = time.time()
    print(f"Accepting {row['label']} on {platform.node()} — every step is recorded.\n")
    report, fingerprint = execute(arguments.service, options, profile, arguments, executor)

    payload = {
        "service_id": arguments.service,
        "started_at": pack_acceptance._stamp(),
        "seconds": round(time.time() - started, 2),
        "platform": pack_acceptance.platform_identity(),
        "host_key": pack_acceptance.host_key(),
        "results": report.results,
        "commands": executor.log,
    }
    if arguments.report:
        from sentinel_blue.state import write_private_json
        write_private_json(arguments.report, payload)
        print(f"\nreport written to {arguments.report}")

    print()
    if not report.required_all_passed:
        outstanding = [name for name in pack_acceptance.REQUIRED
                       if report.results.get(name, {}).get("verdict") != "passed"]
        print(f"NO RECEIPT. {len(outstanding)} required step(s) did not pass:")
        for name in outstanding:
            print(f"  {name}: {report.results.get(name, {}).get('detail', 'not run')}")
        print(f"\n{row['label']} remains native_tested: False on this host, which is correct.")
        return 1

    receipt = pack_acceptance.build_receipt(
        arguments.service, options=options, results=report.results,
        product_version=arguments.product_version, fingerprint=fingerprint,
        runtime=pack_acceptance.runtime_fingerprint(arguments.runtime), operator=arguments.operator)
    target = pack_acceptance.write(arguments.state_dir, receipt)
    print(f"RECEIPT written to {target}")
    print("It covers this pack, these options, this product version, this host and this")
    print("runtime. Change any of them and it goes stale, which is the point.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
