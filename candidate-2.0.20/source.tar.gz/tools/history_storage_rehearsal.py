"""Sustained packaged-controller storage test on an owned loopback fixture.

The load identities and process lists are explicitly synthetic. TLS, HTTP,
SQLite, archive/backup writes, elapsed time, and child restarts are real.
No system settings or existing services are modified.
"""
from __future__ import annotations

import argparse
import copy
import datetime
import hashlib
import ipaddress
import json
import os
import platform
import secrets
import signal
import socket
import sqlite3
import ssl
import subprocess
import sys
import threading
import tempfile
import time
import traceback
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen


def free_port():
    with socket.socket() as listener:
        listener.bind(('127.0.0.1', 0))
        return listener.getsockname()[1]


def stop(process):
    if process is None or process.poll() is not None:
        return
    if os.name == 'nt':
        process.terminate()  # Deliberately exercise crash recovery on Windows.
    else:
        process.send_signal(signal.SIGTERM)
    try:
        process.wait(timeout=20)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=10)


def certificate(root):
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import NameOID
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    subject = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, '127.0.0.1')])
    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (x509.CertificateBuilder().subject_name(subject).issuer_name(subject)
            .public_key(key.public_key()).serial_number(x509.random_serial_number())
            .not_valid_before(now-datetime.timedelta(minutes=1))
            .not_valid_after(now+datetime.timedelta(days=1))
            .add_extension(x509.SubjectAlternativeName([x509.IPAddress(ipaddress.ip_address('127.0.0.1'))]), False)
            .sign(key, hashes.SHA256()))
    from sentinel_blue.state import _atomic_bytes as write_private_bytes
    # Use the runtime writer on both platforms, including Windows DACLs.
    write_private_bytes(root/'tls.key', key.private_bytes(serialization.Encoding.PEM,
                        serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
    write_private_bytes(root/'tls.crt', cert.public_bytes(serialization.Encoding.PEM))


def verify_retained_capsules(root, anchor, key, *, release_sha256, profile_fingerprint):
    """Verify complete retained capsules; admit only the latest for restore."""
    from sentinel_blue.controller_restore import inspect_capsule, verify_capsule
    paths = sorted(Path(root).iterdir())
    sequences, latest, nested = [], 0, 0
    for path in paths:
        if path.is_symlink() or not path.is_dir() or not path.name.endswith('.sbrecovery'):
            raise ValueError('Unexpected material in the owned capsule fixture')
        capsule, backup = inspect_capsule(path, anchor, key,
            release_sha256=release_sha256, profile_fingerprint=profile_fingerprint)
        sequences.append(int(backup.manifest['backup_sequence']))
        nested += sum(len(Path(name).parts) > 2 for name in capsule['ledger_files'])
        if backup.anchor_binding == 'latest':
            verify_capsule(path, anchor, key, release_sha256=release_sha256,
                           profile_fingerprint=profile_fingerprint)
            latest += 1
    if latest != 1:
        raise ValueError('Owned fixture must retain exactly one latest protected capsule')
    return {'backups_verified': len(paths), 'retained_backup_sequences': sorted(sequences),
            'latest_capsule_verified': True, 'nested_ledger_files_verified': nested}


def prepare_owned_ledger(root):
    from sentinel_blue.mutation_ledger import MutationLedger
    ledger = MutationLedger(root / 'ledger')
    ledger.append('owned_storage_fixture')
    if os.name == 'posix':
        from sentinel_blue.restoration import RestorePointStore
        target = root / 'owned-restore.conf'
        target.write_bytes(b'owned storage rehearsal restore point')
        target.chmod(0o600)
        restore = RestorePointStore(root / 'restore', mirror=ledger.directory / 'restore-mirror')
        data, metadata = restore._read_target(target)
        result = restore.capture([{'path': str(target), 'sha256': hashlib.sha256(data).hexdigest(),
            'security_descriptor_sha256': restore._metadata_security_descriptor_sha256(metadata)}])
        if not result['success']:
            raise RuntimeError('Owned nested restore metadata could not be captured')
    return ledger.directory


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runtime', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--seconds', type=int, default=600)
    parser.add_argument('--agents', type=int, default=8)
    parser.add_argument('--interval', type=float, default=1.0)
    parser.add_argument('--process-rows', type=int, default=64)
    parser.add_argument('--work-directory', type=Path,
                        help='local unsynchronized filesystem for the live SQLite fixture; defaults to OS temporary storage')
    args = parser.parse_args()
    if (not 10 <= args.seconds <= 3600 or not 1 <= args.agents <= 32 or not .1 <= args.interval <= 30
            or not 1 <= args.process_rows <= 256):
        parser.error('bounded fixture: seconds 10..3600, agents 1..32, interval .1..30')
    runtime = args.runtime.resolve(strict=True)
    sys.path.insert(0, str(runtime))
    sys.path.insert(1, str(Path(__file__).resolve().parents[1]))
    import sentinel_blue
    from sentinel_blue.agent import AgentClient, ControllerBackoff
    from sentinel_blue.auth import derive_enrollment_ticket
    from sentinel_blue.event_profile import EventProfile
    from sentinel_blue.history_storage import HistoryPolicy, HistoryStorage, read_archive
    from sentinel_blue.recovery_ops import initialize_controller_recovery
    from sentinel_blue.state import _atomic_bytes as write_private_bytes, write_private_json
    from sentinel_blue.store import Store
    from tools.smoke_release import _operator_headers
    from tools.setup_native_inputs import manifest
    if str(runtime) not in sentinel_blue.__file__:
        raise RuntimeError('test is not importing the supplied packaged runtime')
    args.output = args.output.absolute()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    work_directory = args.work_directory or Path(tempfile.gettempdir())
    root = work_directory.absolute() / ('history-fixture-' + secrets.token_hex(6))
    root.mkdir(mode=0o700)
    if os.name == "nt":
        subprocess.run(["icacls", str(root), "/inheritance:r", "/grant:r", "*S-1-5-18:(OI)(CI)F",
                        "*S-1-5-32-544:(OI)(CI)F"], check=True, capture_output=True)
    certificate(root)
    ledger_directory = prepare_owned_ledger(root)
    child_environment = dict(os.environ, SENTINEL_LEDGER_DIR=str(ledger_directory))
    digest = hashlib.sha256(runtime.read_bytes()).hexdigest()
    master, operator, recovery_key = secrets.token_urlsafe(48), secrets.token_urlsafe(48), secrets.token_bytes(48)
    write_private_json(root/'enrollment.json', {'token': master})
    write_private_bytes(root/'operator.txt', operator.encode())
    write_private_bytes(root/'recovery.key', recovery_key)
    port, service_port = free_port(), free_port()
    origin = f'https://127.0.0.1:{port}'
    service_origin = f'http://127.0.0.1:{service_port}'
    raw = copy.deepcopy(EventProfile.testing().raw)
    raw['profile_id'] = 'owned-history-storage-rehearsal'
    raw['scope'].update(authorized_networks=['127.0.0.0/8'], authorized_hosts=['127.0.0.1'],
                        controller_ingress_hosts=['127.0.0.1'], approved_deployment_paths=[str(root)])
    raw['allowed_automatic_actions'] = []
    raw['services'] = [manifest('owned-storage-http', 'http', service_port,
                               [{'kind': 'http', 'target': service_origin, 'expected_status': 200}])]
    raw['services'] = [{**raw['services'][0], 'host': f'load-{n}', 'service_id': f'owned-http-{n}'}
                       for n in range(args.agents)]
    raw['services_confirmed'] = True
    raw['release'].update(sha256=digest, controller_ca_sha256=hashlib.sha256((root/'tls.crt').read_bytes()).hexdigest(),
                          cloud_processing=False, external_telemetry_export=False)
    profile = EventProfile.from_dict(raw)
    profile.require_range_ready()
    write_private_json(root/'profile.json', raw)
    database, anchor = root/'controller.db', root/'recovery.anchor'
    initialize_controller_recovery(database, anchor, recovery_key)
    context = ssl.create_default_context(cafile=str(root/'tls.crt'))
    policy = HistoryPolicy(minimum_online_seconds=60, database_max_bytes=32*1024**2,
                           archive_max_bytes=16*1024**2, archive_max_files=4,
                           minimum_free_bytes=8*1024**2, backup_max_bytes=128*1024**2)
    argv = [sys.executable, str(runtime), 'controller', '--bind', '127.0.0.1', '--port', str(port),
            '--event-profile', str(root/'profile.json'), '--range-deployment',
            '--token-file', str(root/'enrollment.json'), '--operator-token-file', str(root/'operator.txt'),
            '--operator-principal-id', 'storage-rehearsal', '--operator-credential-epoch', '2',
            '--database', str(database), '--recovery-anchor', str(anchor),
            '--recovery-key-file', str(root/'recovery.key'), '--tls-cert', str(root/'tls.crt'),
            '--tls-key', str(root/'tls.key'), '--tls-ca-file', str(root/'tls.crt'),
            '--maintenance-interval', '2', '--backup-interval', '60', '--backup-keep', '4',
            '--database-max-mib', '32', '--history-archive-max-mib', '16',
            '--history-archive-max-files', '4', '--history-minimum-online-seconds', '60',
            '--storage-minimum-free-mib', '8', '--backup-max-mib', '128']
    report = {'status': 'failed', 'version': sentinel_blue.__version__, 'runtime_sha256': digest,
              'platform': platform.platform(), 'python': platform.python_version(),
              'scope': 'owned loopback TLS controller; synthetic load identities; actual filesystem and child processes',
              'isolated_ledger': True, 'nested_restore_metadata_fixture': os.name == 'posix',
              'duration_requested_seconds': args.seconds, 'agents': args.agents,
              'offered_interval_seconds_per_agent': args.interval, 'test_policy': policy.__dict__,
              'process_rows_per_sample': args.process_rows,
              'accepted': 0, 'verified_503': 0, 'verified_429': 0, 'other_errors': [], 'service_checks': 0,
              'service_failures': 0, 'samples': [], 'restart': {}, 'cleanup': {}}
    controller = service = None
    streams, threads, clients, sequences, timings = [], [], [], [], []
    pending_flags, in_flight = [False]*args.agents, [False]*args.agents
    ending, paused = threading.Event(), threading.Event()
    lock = threading.Lock()
    def launch(command, name):
        stream = (root/name).open('w', encoding='utf-8')
        streams.append(stream)
        return subprocess.Popen(command, stdout=stream, stderr=subprocess.STDOUT, env=child_environment)
    def dashboard():
        with urlopen(origin+'/api/v1/operator/auth-info', context=context, timeout=10) as response:
            metadata = json.load(response)
        target = '/api/v1/dashboard'
        headers = _operator_headers(operator, principal_id='storage-rehearsal', credential_epoch=2,
                   method='GET', target=target, request_timestamp=max(int(time.time()), int(metadata['request_not_before'])))
        with urlopen(Request(origin+target, headers=headers), context=context, timeout=30) as response:
            return json.load(response)
    def ready():
        deadline = time.monotonic()+90
        while time.monotonic() < deadline:
            if controller.poll() is not None:
                raise RuntimeError('packaged controller exited; inspect private controller log')
            try:
                return dashboard()
            except OSError:
                time.sleep(.2)
        raise TimeoutError('controller readiness deadline')
    process_rows = [{'name': 'owned-load-fixture', 'path': '/synthetic/'+str(n)+'/'+('p'*450),
                     'username': 'load-fixture', 'process_id': n+1000, 'parent_id': 1, 'privileged': False}
                    for n in range(args.process_rows)]
    def sender(index):
        client, pending = clients[index], None
        while not ending.is_set():
            if paused.is_set():
                ending.wait(.05)
                continue
            began = time.monotonic()
            if pending is None:
                pending = {'agent_id': client.agent_id, 'hostname': 'synthetic-storage-load', 'platform': platform.system(),
                           'observed_at': time.time(), 'queued_at': time.time(), 'sequence': sequences[index]+1,
                           'boot_id': 'owned-storage-load-boot', 'agent_version': sentinel_blue.__version__,
                           'profile_id': profile.profile_id, 'profile_fingerprint': profile.fingerprint,
                           'processes': process_rows, 'firewall': {'enabled': True, 'provider': 'synthetic-fixture'}}
            try:
                pending_flags[index] = True
                in_flight[index] = True
                client.telemetry(pending)
                with lock:
                    report['accepted'] += 1
                    timings.append(time.monotonic()-began)
                    sequences[index] = pending['sequence']
                pending = None
                pending_flags[index] = False
            except ControllerBackoff:
                pass
            except HTTPError as exc:
                if exc.code == 503 and getattr(exc, 'sentinel_blue_verified', False):
                    with lock:
                        report['verified_503'] += 1
                elif exc.code == 429 and getattr(exc, 'sentinel_blue_verified', False):
                    with lock:
                        report['verified_429'] += 1
                else:
                    with lock:
                        report['other_errors'].append({'type': type(exc).__name__, 'code': exc.code, 'detail': str(exc)[:240]})
                    ending.set()
            except OSError as exc:
                if not paused.is_set():
                    with lock:
                        report['other_errors'].append({'type': type(exc).__name__, 'detail': str(exc)[:240]})
                    ending.set()
            except Exception as exc:
                with lock:
                    report['other_errors'].append({'type': type(exc).__name__, 'detail': str(exc)[:240]})
                ending.set()
            finally:
                in_flight[index] = False
            ending.wait(max(.01, args.interval-(time.monotonic()-began)))
    def observer():
        while not ending.is_set():
            try:
                with urlopen(service_origin, timeout=2) as response:
                    healthy = response.status == 200
            except OSError:
                healthy = False
            with lock:
                report['service_checks'] += 1
                report['service_failures'] += int(not healthy)
            ending.wait(.5)
    try:
        public = root/'owned-http'
        public.mkdir()
        (public/'index.html').write_text('Owned storage rehearsal service is available.', encoding='utf-8')
        service = launch([sys.executable, '-m', 'http.server', str(service_port), '--bind', '127.0.0.1',
                          '--directory', str(public)], 'owned-http.log')
        controller = launch(argv, 'controller-first.log')
        initial = ready()
        report['initial_storage'] = initial['controller']['storage']
        for index in range(args.agents):
            agent_id = f'load-{index}'
            client = AgentClient(origin, derive_enrollment_ticket(master, profile.fingerprint, agent_id), agent_id,
                                 timeout=30, ca_file=str(root/'tls.crt'), profile_id=profile.profile_id,
                                 profile_fingerprint=profile.fingerprint)
            client.enroll('synthetic-storage-load', platform.system())
            clients.append(client)
            sequences.append(0)
        threads = [threading.Thread(target=sender, args=(n,), daemon=True) for n in range(args.agents)]
        threads.append(threading.Thread(target=observer, daemon=True))
        started = time.monotonic()
        for thread in threads:
            thread.start()
        restarted = False
        while time.monotonic()-started < args.seconds and not ending.is_set():
            elapsed = time.monotonic()-started
            snapshot = dashboard()
            report['samples'].append({'seconds': round(elapsed, 3), 'accepted': report['accepted'],
                                      'storage': snapshot['controller']['storage']})
            write_private_json(args.output.with_suffix('.progress.json'), report)
            if elapsed >= args.seconds*.55 and not restarted:
                paused.set()
                drain_deadline = time.monotonic()+35
                while any(in_flight) and time.monotonic() < drain_deadline:
                    time.sleep(.05)
                if any(in_flight):
                    raise TimeoutError('fixture requests did not drain before restart')
                accepted_before = report['accepted']
                before = snapshot['controller']['storage']['archived_records']
                began = time.monotonic()
                stop(controller)
                controller = launch(argv, 'controller-restart.log')
                snapshot = ready()
                report['restart'] = {'seconds': round(time.monotonic()-began, 3),
                    'method': 'process termination' if os.name == 'nt' else 'SIGTERM',
                    'archived_counters_preserved': all(snapshot['controller']['storage']['archived_records'].get(k, 0) >= v
                                                      for k, v in before.items()),
                    'accepted_before': accepted_before}
                restarted = True
                paused.clear()
            ending.wait(5)
        ending.set()
        for thread in threads:
            thread.join(timeout=40)
        report['duration_seconds'] = round(time.monotonic()-started, 3)
        final = dashboard()
        report['final_storage'] = final['controller']['storage']
        stop(controller)
        store = Store(database)
        try:
            manager = HistoryStorage(store, Path(str(anchor)+'.history'), recovery_key, policy)
            report['integrity_check'] = store._connection.execute('PRAGMA integrity_check').fetchone()[0]
            report['foreign_key_violations'] = len(store._connection.execute('PRAGMA foreign_key_check').fetchall())
            report['sequences_preserved'] = all(store.latest_telemetry_for_agent(c.agent_id)['sequence'] == sequences[n]
                                                for n, c in enumerate(clients))
            report['archives_verified'] = sum(bool(read_archive(p, recovery_key)['verified'])
                for p in Path(str(anchor)+'.history').glob('*.sbhistory'))
            report['archive_catalog_verified'] = not manager.status()['reasons']
        finally:
            store.close()
        began = time.monotonic()
        report.update(verify_retained_capsules(Path(str(anchor)+'.backups'), anchor, recovery_key,
            release_sha256=digest, profile_fingerprint=profile.fingerprint))
        report['backup_verification_seconds'] = round(time.monotonic()-began, 3)
        timings.sort()
        report['request_latency_seconds'] = {'median': timings[len(timings)//2],
            'p95': timings[min(len(timings)-1, int(len(timings)*.95))], 'max': max(timings)} if timings else {}
        report['restart']['accepted_after'] = report['accepted']-report['restart'].get('accepted_before', report['accepted'])
        report['undelivered_at_stop'] = sum(pending_flags)
        required = [report['integrity_check'] == 'ok', not report['foreign_key_violations'], report['sequences_preserved'],
                    not report['other_errors'], not report['service_failures'], report['accepted'] > 0,
                    report['archive_catalog_verified'], report['latest_capsule_verified'],
                    not any('backup' in reason for reason in report['final_storage']['reasons']),
                    report['restart'].get('archived_counters_preserved'), report['restart']['accepted_after'] > 0,
                    all(s['storage']['database_allocated_bytes'] <= policy.database_max_bytes and
                        s['storage']['archive_bytes'] <= policy.archive_max_bytes and
                        s['storage']['backup_bytes'] <= policy.backup_max_bytes for s in report['samples'])]
        if args.seconds >= 180:
            required += [report['final_storage']['archived_records'].get('telemetry_observations', 0) > 0,
                         report['archives_verified'] > 0, 2 <= report['backups_verified'] <= 5,
                         max(report['retained_backup_sequences']) >= max(2, args.seconds//60-2)]
        if os.name == 'posix':
            required.append(report['nested_ledger_files_verified'] > 0)
        report['status'] = 'passed' if all(required) else 'failed'
    except Exception as exc:
        report['exception'] = {'type': type(exc).__name__, 'detail': str(exc)[:500]}
        (root/'failure.txt').write_text(traceback.format_exc(), encoding='utf-8')
    finally:
        ending.set()
        for thread in threads:
            thread.join(timeout=35)
        stop(controller)
        stop(service)
        for stream in streams:
            stream.close()
        report['cleanup'] = {'controller_stopped': controller is None or controller.poll() is not None,
                             'owned_service_stopped': service is None or service.poll() is not None,
                             'worker_threads_stopped': all(not t.is_alive() for t in threads),
                             'private_fixture_retained': str(root)}
        write_private_json(args.output, report)
    print(json.dumps({k: report.get(k) for k in ('status', 'version', 'duration_seconds', 'accepted', 'verified_503',
          'other_errors', 'exception', 'archives_verified', 'backups_verified', 'request_latency_seconds', 'cleanup')}, indent=2))
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
