"""Measure planning cost in a local synthetic dependency chain; no host mutation."""

import argparse
import copy
import json
from pathlib import Path
import statistics
import sys
import time


def measure(source: Path):
    sys.path[:0] = [str(source / "src"), str(source / "tests")]
    from sentinel_blue import __version__
    from sentinel_blue.service_recovery import ServiceRecoveryPlanner
    from test_service_repair import repair_fixture
    from test_service_manifest_policy import profile_for

    results = []
    for count in (8, 32, 64, 128):
        _, baseline = repair_fixture()
        native, manifests, files, probes = [], [], [], []
        for index in range(count):
            profile, fixture = repair_fixture(f"/etc/owned-reasoning-{index}.conf")
            manifest = copy.deepcopy(profile.services[0])
            name = f"owned-{index}.service"
            manifest.update(service_id=name, dependencies=[f"owned-{index-1}.service"] if index else [])
            probe = {"name": f"owned-{index}", "kind": "http", "target": f"http://127.0.0.1:{18000+index}/health"}
            manifest["expected_transactions"] = [probe]
            manifests.append(manifest)
            native.append({"name": name, "state": "running", "start_mode": "enabled"})
            files.extend(fixture["integrity"])
            probes.append({"name": probe["name"], "target": probe["target"], "healthy": True})
        baseline.update(services=native, integrity=files, probes=probes)
        planner = ServiceRecoveryPlanner(profile_for(manifests))
        durations = []
        for sequence in range(2, 7):
            observation = copy.deepcopy(baseline)
            observation.update(sequence=sequence, observed_at=time.time())
            start = time.perf_counter()
            candidates = planner.observe("agent-one", baseline, True, observation)
            durations.append((time.perf_counter() - start) * 1000)
            if candidates:
                raise ValueError("healthy benchmark fixture unexpectedly produced a repair")
        results.append({"services": count, "iterations": len(durations),
                        "median_ms": round(statistics.median(durations), 3),
                        "maximum_ms": round(max(durations), 3)})
    return {"version": __version__, "platform": sys.platform, "scope": "local healthy dependency-chain planning only",
            "measurements": results}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = measure(args.source.resolve())
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))
