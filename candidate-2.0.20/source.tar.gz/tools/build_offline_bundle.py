"""Assemble a portable release from a prepared, local standalone Python tree.

This builder and the generated launchers never download dependencies. Prepare
the official standalone distribution and install locked wheels at build time.
Run on the destination OS so native dependencies can be checked before shipping.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    with Path(path).open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def build(python_root, script, destination, provenance):
    python_root, script, destination = (Path(p).resolve() for p in (python_root, script, destination))
    if destination.exists() or destination.is_relative_to(python_root):
        raise ValueError('Use a new output directory outside the prepared Python tree')
    windows = os.name == 'nt'
    target = 'windows-x64' if windows else 'linux-x86_64'
    exe = python_root / ('python.exe' if windows else 'bin/python3')
    probe = subprocess.run([str(exe), '-I', '-B', '-c',
        "import json,platform,struct,sys; print(json.dumps({'version':platform.python_version(),'bits':struct.calcsize('P')*8,'machine':platform.machine(),'platform':sys.platform}))"],
        text=True, capture_output=True, check=True, timeout=30)
    identity = json.loads(probe.stdout)
    if identity['bits'] != 64 or identity['machine'].lower() not in {'amd64','x86_64'}:
        raise ValueError('This bundle definition supports x64 Windows and x86_64 Linux')
    if not zipfile.is_zipfile(script):
        raise ValueError('A built runtime zipapp is required')
    with zipfile.ZipFile(script) as archive:
        source = archive.read('sentinel_blue/__init__.py').decode()
        import ast
        versions = [n.value.value for n in ast.parse(source).body if isinstance(n, ast.Assign)
                    and any(isinstance(t, ast.Name) and t.id == '__version__' for t in n.targets)]
        if len(versions) != 1:
            raise ValueError('Invalid runtime version')
    version = versions[0]
    destination.mkdir(parents=True)
    shutil.copytree(python_root, destination/'runtime', symlinks=False,
                    ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    shutil.copyfile(script, destination/'sentinel-blue.pyz')
    shutil.copyfile(ROOT/'packaging/offline/launch.py', destination/'launch.py')
    launcher = 'Start-Sentinel-Blue.cmd' if windows else 'Start-Sentinel-Blue.sh'
    shutil.copyfile(ROOT/'packaging/offline'/launcher, destination/launcher)
    if not windows:
        (destination/launcher).chmod(0o755)
    shutil.copyfile(ROOT/'LICENSE', destination/'LICENSE-Sentinel-Blue.txt')
    # Preserve all CPython and third-party licenses in the copied runtime.
    licenses = list((destination/'runtime').rglob('*LICENSE*')) + list((destination/'runtime').rglob('*COPYING*'))
    if not licenses:
        raise ValueError('The standalone Python distribution is missing its licenses')
    manifest = {'schema':1,'version':version,'target':target,'python':identity,
                'runtime_sha256':digest(script),'provenance':provenance}
    (destination/'offline-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    bundled_python = destination/'runtime'/('python.exe' if windows else 'bin/python3')
    checked = subprocess.run([str(bundled_python),'-I','-B',str(destination/'launch.py'),'offline-check'],
                             capture_output=True,text=True,timeout=90)
    if checked.returncode:
        raise RuntimeError('Offline dependency check failed: '+checked.stdout[-3000:]+checked.stderr[-1500:])
    manifest['dependency_check'] = json.loads(checked.stdout)
    (destination/'offline-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    (destination/'START-HERE.txt').write_text(
        f'Sentinel Blue {version} — {target}\n\n'
        f'Extract this entire archive to a local writable folder. Open {launcher}.\n'
        'Keep the runtime folder and script together. No Python installation, pip, internet,\n'
        'cloud account, or AI connection is required to start or use local features.\n'
        'On Linux, a graphical X11/XWayland session is needed for the window.\n'
        'If an archive extractor removes execute permissions, use:\n'
        '  chmod -R u+X runtime; chmod u+x runtime/bin/python* Start-Sentinel-Blue.sh\n'
        '  ./Start-Sentinel-Blue.sh\n\n'
        'Use the same launcher with controller, agent, observer, or other command arguments.\n'
        'Run offline-check --desktop to test the bundled libraries and window locally.\n'
        'The controller, host agents and outside service observer communicate only as\n'
        'configured in the approved range. These connections still require the range network.\n'
        'Prepare event profiles, credentials, OS management tools and application installation\n'
        'media before the event. This bundle includes Sentinel dependencies, not installers\n'
        'for every service you may choose to provision.\n\n'
        'Recording stays local. Stop & save writes the portable session ZIP beside the script.\n'
        'The reviewed script checksum is in offline-manifest.json. Do not replace files\n'
        'inside a reviewed deployment without reviewing the new release.\n', encoding='utf-8')
    files = sorted(p for p in destination.rglob('*') if p.is_file())
    checksums = ''.join(digest(p)+'  '+p.relative_to(destination).as_posix()+'\n' for p in files)
    (destination/'SHA256SUMS').write_text(checksums,encoding='utf-8')
    output = destination.parent/f'sentinel-blue-{version}-offline-{target}.zip'
    if output.exists():
        raise ValueError('The release archive already exists')
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for path in sorted(p for p in destination.rglob('*') if p.is_file()):
            info = zipfile.ZipInfo(destination.name+'/'+path.relative_to(destination).as_posix(),(2026,1,1,0,0,0))
            info.create_system=3
            info.external_attr=(stat.S_IFREG|stat.S_IMODE(path.stat().st_mode))<<16
            archive.writestr(info,path.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=6)
    return {'archive':str(output),'sha256':digest(output),'bytes':output.stat().st_size,'manifest':manifest}


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--python-root',required=True,type=Path)
    parser.add_argument('--runtime',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--provenance',required=True,type=Path)
    args=parser.parse_args()
    print(json.dumps(build(args.python_root,args.runtime,args.output,json.loads(args.provenance.read_text())),indent=2))
