"""Compare the owned Windows lab on B2s/B2ms, then restore its original B1ms size.

This optional capacity experiment uses the existing isolated defensive harness.
It never changes VM identity, disks or the original network. It requires all
four lab VMs off and the exact reviewed network before resizing the one target.
Run only in authenticated Cloud Shell with no other lab coordinator active.
"""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import zipfile

import azure_lab_isolated_boot as isolation
import azure_lab_preflight as lab

TARGET = 'sb-windows-target'
ORIGINAL_SIZE = 'Standard_B1ms'
TEST_SIZE = 'Standard_B2s'


def require_size(azure, identity, expected):
    row = azure.call('vm', 'show', '--ids', identity)
    if (row.get('id', '').casefold() != identity.casefold() or
            row.get('provisioningState') != 'Succeeded' or
            row.get('hardwareProfile', {}).get('vmSize') != expected):
        raise lab.PreflightError('Windows lab size or provisioning state differs from the expected state')


def resize(azure, identity, old, new):
    require_size(azure, identity, old)
    if lab.power(azure.call('vm', 'get-instance-view', '--ids', identity)) != 'PowerState/deallocated':
        raise lab.PreflightError('Capacity changes require the Windows target deallocated')
    try:
        azure.call('vm', 'resize', '--resource-group', lab.GROUP, '--name', TARGET,
                   '--size', new, timeout=180)
    except lab.PreflightError:
        # Reconcile an uncertain control-plane response; never blindly replay.
        require_size(azure, identity, new)
    require_size(azure, identity, new)


def run(args):
    test_size = getattr(args, 'test_size', TEST_SIZE)
    if test_size not in ('Standard_B2s', 'Standard_B2ms'):
        raise ValueError('Capacity comparison is limited to the reviewed two-core B sizes')
    runtime = args.runtime.absolute()
    if hashlib.sha256(runtime.read_bytes()).hexdigest() != args.runtime_sha256:
        raise ValueError('Capacity experiment runtime checksum mismatch')
    os.umask(0o077)
    work = Path(tempfile.mkdtemp(prefix='sentinel-capacity-'))
    print('SB_CAPACITY_WORK='+str(work), flush=True)
    azure = lab.Azure(work)
    state = isolation.snapshot(azure)
    if isolation.network_digest(state) != args.expected_network_sha256:
        raise ValueError('Reviewed network changed; no capacity changes attempted')
    identity = state['vms'][TARGET]['id']
    require_size(azure, identity, ORIGINAL_SIZE)
    (work/'original-network.json').write_text(json.dumps(state, indent=2))
    report = {'kind':'owned Windows lab capacity comparison', 'original_size':ORIGINAL_SIZE,
              'test_size':test_size, 'runtime_sha256':args.runtime_sha256,
              'status':'reviewed', 'guest_runs':[], 'full_competition_readiness_proven':False}
    if not args.execute:
        return report
    changed = False
    try:
        changed = True  # Cleanup also covers an uncertain resize response.
        resize(azure, identity, ORIGINAL_SIZE, test_size)
        report['size_change_verified'] = True
        for mode in (['full', 'uptime'] if args.with_uptime else ['full']):
            destination = work/mode
            destination.mkdir(mode=0o700)
            environment = dict(os.environ, PYTHONPATH=str(Path(__file__).resolve().parent.parent)
                               + os.pathsep + str(Path(__file__).resolve().parent))
            command = [sys.executable, str(Path(__file__).with_name('azure_defensive_rehearsal.py')),
                       '--runtime',str(runtime),'--runtime-sha256',args.runtime_sha256,
                       '--private-storage-account',args.private_storage_account,
                       '--expected-network-sha256',args.expected_network_sha256,
                       '--mode',mode,'--target',TARGET,'--execute']
            if getattr(args,'retain_private_results',False):
                command.append('--retain-private-results')
            with (destination/'runner-private.log').open('w') as log:
                child = subprocess.Popen(command, cwd=destination, env=environment,
                                         stdout=log, stderr=subprocess.STDOUT)
                try:
                    code = child.wait(timeout=2700)
                finally:
                    if child.poll() is None:
                        child.terminate()
                        try:
                            child.wait(timeout=60)
                        except subprocess.TimeoutExpired:
                            child.kill()
                            child.wait(timeout=5)
            report['guest_runs'].append({'mode':mode,'exit_code':code,
                                        'evidence':str(destination/'sentinel-defensive-evidence.zip')})
            if (destination/'retained-result.json').is_file():
                report['guest_runs'][-1]['retained_private_result'] = json.loads(
                    (destination/'retained-result.json').read_text())
            if code:
                report['status'] = 'acceptance_failed'
                break
        else:
            report['status'] = 'measurements_complete'
    except BaseException as exc:
        report.update(status='failed', error_type=type(exc).__name__)
        raise
    finally:
        errors = []
        try:
            lab.cleanup(azure, state['vms'], list(state['vms']))
            isolation.require_off(azure, state['vms'])
            report['all_vms_deallocated'] = True
        except Exception as exc:
            report['all_vms_deallocated'] = False
            errors.append('deallocation:'+type(exc).__name__)
        if report['all_vms_deallocated']:
            for name in sorted(isolation.PUBLIC_HOSTS):
                try:
                    isolation.change_association(azure, name, state['network'][name], restore=True)
                except Exception as exc:
                    errors.append('network:'+name+':'+type(exc).__name__)
            try:
                current = azure.call('vm','show','--ids',identity)['hardwareProfile']['vmSize']
                if changed and current == test_size:
                    resize(azure, identity, test_size, ORIGINAL_SIZE)
                require_size(azure, identity, ORIGINAL_SIZE)
                report['original_size_restored'] = True
            except Exception as exc:
                report['original_size_restored'] = False
                errors.append('size:'+type(exc).__name__)
            try:
                final = isolation.snapshot(azure)
                report['original_network_restored'] = isolation.network_digest(final) == args.expected_network_sha256
            except Exception as exc:
                report['original_network_restored'] = False
                errors.append('verification:'+type(exc).__name__)
        report['cleanup_errors'] = errors
        if errors or not report.get('original_network_restored') or not report.get('original_size_restored'):
            report['status'] = 'cleanup_incomplete'
        (work/'result.json').write_text(json.dumps(report, indent=2))
        print('SB_CAPACITY_RESULT='+json.dumps(report), flush=True)
    if getattr(args,'retain_private_results',False):
        from azure_result_archive import retain
        archive = work/'capacity-evidence.zip'
        with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as output:
            output.write(work/'result.json','result.json')
        retained = retain(archive,account=args.private_storage_account,group=lab.GROUP,
                          runtime_sha256=args.runtime_sha256)
        (Path.cwd()/'capacity-retained-result.json').write_text(json.dumps(retained,indent=2))
        print('SB_CAPACITY_PRIVATE_RESULT='+json.dumps(retained),flush=True)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runtime',type=Path,required=True)
    parser.add_argument('--runtime-sha256',required=True)
    parser.add_argument('--expected-network-sha256',required=True)
    parser.add_argument('--private-storage-account',required=True)
    parser.add_argument('--execute',action='store_true')
    parser.add_argument('--with-uptime',action='store_true')
    parser.add_argument('--test-size', choices=['Standard_B2s', 'Standard_B2ms'], default=TEST_SIZE)
    parser.add_argument('--retain-private-results',action='store_true')
    args = parser.parse_args()
    def interrupted(*_):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, interrupted)
    # The nested isolation harness keeps its existing lock. This second lock
    # prevents two capacity coordinators from racing their resize/restore steps.
    with (Path.home()/'.sentinel-azure-capacity.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX|fcntl.LOCK_NB)
        report = run(args)
    return 0 if report['status'] in ('reviewed','measurements_complete') else 1


if __name__ == '__main__':
    raise SystemExit(main())
