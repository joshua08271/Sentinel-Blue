"""Owned native validation of the packaged opening command and real startup jobs."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import ssl
import subprocess
import sys
import time
import traceback
import uuid
from urllib.request import Request, urlopen


def request(context, target, payload=None):
    from tools.smoke_release import _operator_headers
    remaining=context['deadline']-time.time()
    if remaining<=0:
        raise TimeoutError('Original opening deadline exhausted')
    tls=ssl.create_default_context(cafile=context['ca'])
    with urlopen(context['origin']+'/api/v1/operator/auth-info',context=tls,timeout=min(5,remaining)) as response:
        metadata=json.load(response)
    body=b'' if payload is None else json.dumps(payload).encode()
    method='GET' if payload is None else 'POST'
    token=Path(context['operator_file']).read_text().strip()
    headers=_operator_headers(token,principal_id=context['principal'],credential_epoch=context['epoch'],
        method=method,target=target,body=body,
        request_timestamp=max(int(time.time()),int(metadata['request_not_before'])))
    headers['Content-Type']='application/json'
    with urlopen(Request(context['origin']+target,data=body if payload is not None else None,
                         headers=headers,method=method),context=tls,timeout=min(10,max(.1,context['deadline']-time.time()))) as response:
        return json.load(response)


def command(context, role):
    root=Path(context['defender_root'])
    def launch(runtime, arguments):
        code="import json,runpy,sys; sys.path[:0]=json.loads(sys.argv[1]); sys.argv=sys.argv[2:]; runpy.run_path(sys.argv[0],run_name='__main__')"
        return [context['python'],'-c',code,json.dumps(context['python_paths']),str(runtime),*arguments]
    if role=='controller':
        return launch(context['controller_runtime'],['controller','--bind','127.0.0.1',
            '--port',context['origin'].rsplit(':',1)[1],'--event-profile',context['profile'],
            '--range-deployment','--token-file',str(root/'enrollment.json'),
            '--operator-token-file',context['operator_file'],'--operator-principal-id',context['principal'],
            '--operator-credential-epoch',str(context['epoch']),'--tls-cert',context['ca'],
            '--tls-key',str(root/'controller.key'),'--tls-ca-file',context['ca'],
            '--auto-recover-services','--maintenance-interval','2','--database',str(root/'controller.db'),
            '--recovery-key-file',str(root/'recovery.key'),'--recovery-anchor',str(root/'recovery.anchor')])
    install=root/'agent-install'
    return launch(install/'sentinel-blue.pyz',['agent','--controller',context['origin'],
        '--event-profile',str(install/'event-profile.json'),'--range-deployment',
        '--token-file',str(install/'enrollment.json'),'--agent-id','target','--ca-file',str(install/'controller-ca.crt'),
        '--probe-config',str(install/'probes.json'),'--state-dir',str(root/'agent-state'),
        '--expected-package-sha256',context['runtime_sha256'],'--allow-restoration','--allow-service-recovery','--interval','5'])


def unit_text(context, role):
    def quote(value):
        return '"'+str(value).replace('\\','\\\\').replace('"','\\"').replace('%','%%')+'"'
    return ('[Unit]\nDescription=Owned Sentinel complete opening\nAfter=network-online.target\n'
            '[Service]\nType=exec\nExecStart='+' '.join(quote(v) for v in command(context,role))+
            '\nRestart=on-failure\nRestartSec=2\nTimeoutStopSec=30\n[Install]\nWantedBy=multi-user.target\n')


def powershell(code):
    from sentinel_blue.setup_transport import powershell_environment
    return subprocess.run(['powershell.exe','-NoLogo','-NoProfile','-NonInteractive','-Command',code],
                          capture_output=True,text=True,timeout=90,env=powershell_environment('powershell.exe'))


def ps(value):
    return "'"+str(value).replace("'","''")+"'"


def boot_identity():
    if os.name != 'nt':
        return Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    result=powershell("$ErrorActionPreference='Stop'; (Get-CimInstance Win32_OperatingSystem).LastBootUpTime.ToUniversalTime().ToString('o')")
    if result.returncode or not result.stdout.strip():
        raise RuntimeError('Native boot identity unavailable')
    return result.stdout.strip()


def verify_reboot(context_path, output):
    """Read-only readiness after a real provider-initiated restart."""
    context=json.loads(context_path.read_text())
    sys.path[:0]=context['python_paths']
    from tools.azure_setup_guest import validate_guest
    from sentinel_blue.event_profile import load_event_profile
    from sentinel_blue.opening import assess_defender,compile_opening,scoring_checks
    from sentinel_blue.state import write_private_json
    validate_guest(context['expected_resource_id'])
    started=time.time()
    deadline=time.monotonic()+180
    context['deadline']=started+180
    report={'status':'failed','version':context['readiness_plan']['release_version'],
            'runtime_sha256':context['runtime_sha256'],'automatic_activation_replayed':False,
            'full_network_cold_start_verified':False}
    try:
        report['boot_identity_changed']=boot_identity()!=context['boot_identity']
        if not report['boot_identity_changed']:
            raise RuntimeError('Actual OS restart has not been verified')
        runtime=Path(context['controller_runtime'])
        if hashlib.sha256(runtime.read_bytes()).hexdigest()!=context['runtime_sha256']:
            raise RuntimeError('Installed release differs')
        root=Path(context['root'])
        profile=load_event_profile(Path(context['profile']))
        plan=compile_opening(json.loads((root/'inventory.json').read_text()),profile,root,runtime,range_deployment=True)
        report['startup_jobs_running']=False
        while time.monotonic()<deadline:
            try:
                snapshot=request(context,'/api/v1/dashboard')
                # Require telemetry newer than this post-boot observer, so
                # a previously persisted online status cannot satisfy the gate.
                defense=assess_defender(snapshot,plan,time.time(),started)
                report['defender']=defense
                if defense['ready']:
                    final=scoring_checks(plan,profile,deadline)
                    report['final_scoring']=final
                    if final and all(r['checked'] and r['healthy'] for r in final):
                        states=[]
                        for name in context['jobs'].values():
                            if os.name=='nt':
                                state=powershell('(Get-ScheduledTask -TaskName '+ps(name)+').State.ToString()')
                                states.append(state.returncode==0 and state.stdout.strip()=='Running')
                            else:
                                states.append(subprocess.run(['systemctl','is-active','--quiet',name],timeout=10).returncode==0)
                        report['startup_jobs_running']=all(states)
                        again=assess_defender(request(context,'/api/v1/dashboard'),plan,time.time(),started)
                        if all(states) and again['ready']:
                            report['status']='passed'
                            break
            except OSError:
                pass
            time.sleep(min(1,max(0,deadline-time.monotonic())))
    except Exception as exc:
        report['error_type']=type(exc).__name__
    report['verification_seconds']=round(time.time()-started,3)
    write_private_json(output,report)
    print(json.dumps({k:report.get(k) for k in ('status','version','boot_identity_changed','startup_jobs_running','automatic_activation_replayed','verification_seconds','error_type')}))
    return 0 if report['status']=='passed' else 2


def install_job(context, role):
    name=context['jobs'][role]
    if os.name=='nt':
        argv=command(context,role)
        script=("$ErrorActionPreference='Stop'; "
            f"if (Get-ScheduledTask -TaskName {ps(name)} -ErrorAction SilentlyContinue) {{throw 'Owned job already exists'}}; "
            f"$a=New-ScheduledTaskAction -Execute {ps(argv[0])} -Argument {ps(subprocess.list2cmdline(argv[1:]))}; "
            "$t=New-ScheduledTaskTrigger -AtStartup; "
            "$p=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest; "
            "$s=New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew; "
            f"Register-ScheduledTask -TaskName {ps(name)} -Action $a -Trigger $t -Principal $p -Settings $s | Out-Null; "
            f"Start-ScheduledTask -TaskName {ps(name)}")
        result=powershell(script)
    else:
        from sentinel_blue.setup_recipes import compile_recipe
        source=Path(context['root'])/(role+'.service')
        source.write_text(unit_text(context,role))
        _,apply,_=compile_recipe('linux-service',{'service':name,'enable':True,'files':[{
            'path':'/etc/systemd/system/'+name,'previous_sha256':'absent',
            'source':{'path':str(source),'sha256':hashlib.sha256(source.read_bytes()).hexdigest()}}]},source.parent,'linux')
        result=subprocess.run(['bash','-se'],input=apply,capture_output=True,text=True,timeout=90)
    if result.returncode:
        Path(context['root'],role+'-install.log').write_text(result.stdout+result.stderr)
        raise RuntimeError('Owned startup job installation failed')


def phase(context_path, operation):
    from sentinel_blue.opening import assess_defender
    context=json.loads(context_path.read_text())
    plan=context['readiness_plan']
    def ready():
        return assess_defender(request(context,'/api/v1/dashboard'),plan,time.time(),context['started_at'])['ready']
    if operation in {'bootstrap-check','activate-check','health-check'}:
        try:
            observed=request(context,'/api/v1/dashboard')
            healthy=True if operation!='activate-check' else assess_defender(observed,plan,time.time(),context['started_at'])['ready']
            return 0 if healthy else 10
        except OSError:
            return 10
    if operation=='health-apply':
        return 42
    if operation=='bootstrap-apply':
        root=Path(context['defender_root'])
        result=subprocess.run([context['python'],context['controller_runtime'],'recovery-init',
            '--database',str(root/'controller.db'),'--recovery-key-file',str(root/'recovery.key'),
            '--recovery-anchor',str(root/'recovery.anchor')],capture_output=True,timeout=30)
        if result.returncode:
            raise RuntimeError('Fresh controller recovery initialization failed')
        install_job(context,'controller')
        while time.time()<context['deadline']:
            try:
                request(context,'/api/v1/dashboard')
                return 0
            except OSError:
                time.sleep(.5)
    elif operation=='activate-apply':
        install_job(context,'agent')
        approved=False
        while time.time()<context['deadline']:
            snapshot=request(context,'/api/v1/dashboard')
            rows=[r for r in snapshot.get('agents',[]) if r.get('agent_id')=='target']
            if not approved and rows and rows[0].get('baseline_readiness',{}).get('ready') is True:
                # This private fixture approves only its declared, owned starting
                # state through the authenticated API. No database writes or
                # synthetic telemetry are used to establish readiness.
                request(context,'/api/v1/governance/mode',{'mode':'range-autonomous'})
                request(context,'/api/v1/governance/resume',{})
                request(context,'/api/v1/agents/target/baseline/approve',{})
                approved=True
            if assess_defender(snapshot,plan,time.time(),context['started_at'])['ready']:
                return 0
            time.sleep(.5)
    raise TimeoutError('Native opening phase did not finish in its original budget')


def cleanup_jobs(context):
    clean=True
    for role in ('agent','controller'):
        name=context['jobs'][role]
        if os.name=='nt':
            argv=command(context,role)
            code=("$ErrorActionPreference='Stop'; "
                f"$t=Get-ScheduledTask -TaskName {ps(name)} -ErrorAction SilentlyContinue; "
                "if ($t) { "
                f"if ($t.Actions.Execute -ne {ps(argv[0])} -or $t.Actions.Arguments -ne {ps(subprocess.list2cmdline(argv[1:]))}) {{throw 'Startup job ownership differs'}}; "
                f"Stop-ScheduledTask -TaskName {ps(name)}; Unregister-ScheduledTask -TaskName {ps(name)} -Confirm:$false; "
                f"if (Get-ScheduledTask -TaskName {ps(name)} -ErrorAction SilentlyContinue) {{throw 'Owned job remains'}} }}")
            clean=powershell(code).returncode==0 and clean
        else:
            path=Path('/etc/systemd/system')/name
            if path.exists():
                if path.read_text()!=unit_text(context,role):
                    clean=False
                    continue
                subprocess.run(['systemctl','stop',name],capture_output=True,timeout=45)
                subprocess.run(['systemctl','disable',name],capture_output=True,timeout=20)
                clean=subprocess.run(['systemctl','is-active','--quiet',name]).returncode!=0 and clean
                path.unlink()
                clean=subprocess.run(['systemctl','daemon-reload'],capture_output=True,timeout=20).returncode==0 and clean
    return {'verified':clean,'owned_startup_jobs_removed':clean}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--runtime',type=Path,required=True)
    parser.add_argument('--expected-resource-id',required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--budget-seconds',type=int,default=1800)
    parser.add_argument('--retain-for-reboot',action='store_true')
    args=parser.parse_args()
    from tools.azure_setup_guest import validate_guest
    validate_guest(args.expected_resource_id)
    from tools.competition_native_inputs import linux_competition_inputs,windows_competition_inputs,prepare_opening_observer
    from tools.setup_native_inputs import profile_inventory,source
    from tools.native_defender_startup import NativeDefender
    from tools.measure_setup_acceptance import runtime_command
    from sentinel_blue.event_profile import load_event_profile
    from sentinel_blue.opening import compile_opening
    from sentinel_blue.setup import plan_digest
    from sentinel_blue.state import write_private_json
    started=float(os.environ.get('SENTINEL_OPENING_STARTED_AT',time.time()))
    suffix=uuid.uuid4().hex[:10]
    root=args.output.parent/('complete-opening-'+suffix)
    root.mkdir(mode=0o700)
    services_cleanup=None
    context=None
    auditing=None
    report={'status':'failed','scope':'actual packaged opening command, one native host, real service/startup jobs',
            'full_network_cold_start_verified':False,'vm_reboot_continuity_verified':False}
    try:
        builder=windows_competition_inputs if os.name=='nt' else linux_competition_inputs
        tasks,services,initial,_,services_cleanup,_=builder(root,suffix)
        prepare_opening_observer(root,time.monotonic()+args.budget_seconds-(time.time()-started))
        inventory=profile_inventory(args.runtime,tasks,services)
        defender=NativeDefender(root/'defender',args.runtime,inventory,started_at=started,budget=args.budget_seconds)
        jobs={role:('SentinelOpening'+suffix+role if os.name=='nt' else 'sentinel-opening-'+suffix+'-'+role+'.service') for role in ('controller','agent')}
        if os.name!='nt':
            additions=['/etc/systemd/system/'+name for name in jobs.values()]
            defender.profile.raw['services'][-1]['required_files'].extend(additions)
            probes=json.loads(defender.probe_path.read_text())
            probes['protected_paths'].extend(additions)
            write_private_json(defender.probe_path,probes)
        write_private_json(defender.profile_path,defender.profile.raw)
        profile=load_event_profile(defender.profile_path)
        context={'root':str(root),'defender_root':str(defender.root),'python':sys.executable,
            'boot_identity':boot_identity(),'expected_resource_id':args.expected_resource_id,
            'python_paths':[str(Path(p).absolute()) for p in sys.path if p],
            'controller_runtime':str(defender.runtime),'runtime_sha256':defender.digest,
            'origin':defender.origin,'profile':str(defender.profile_path),'ca':str(defender.cert),
            'operator_file':str(defender.root/'operator.txt'),'principal':defender.principal,'epoch':defender.epoch,
            'started_at':started,'deadline':started+args.budget_seconds,'jobs':jobs,
            'readiness_plan':{'release_version':profile.release['version'],'profile_fingerprint':profile.fingerprint,
                              'expected_agents':['target'],'controller':{'expected_mode':'range-autonomous'}}}
        context_path=root/'context.json'
        write_private_json(context_path,context)
        report['context_file']=str(context_path)
        context_hash=hashlib.sha256(context_path.read_bytes()).hexdigest()
        helper=Path(__file__).resolve()
        helper_hash=hashlib.sha256(helper.read_bytes()).hexdigest()
        def runbook(operation):
            entries={}
            for step in ('check','apply'):
                argv=[sys.executable,str(helper),'phase',str(context_path),operation+'-'+step]
                guard="import hashlib,pathlib; assert hashlib.sha256(pathlib.Path("+repr(str(helper))+").read_bytes()).hexdigest()=="+repr(helper_hash)
                guard+='; assert hashlib.sha256(pathlib.Path('+repr(str(context_path))+').read_bytes()).hexdigest()=='+repr(context_hash)
                if os.name=='nt':
                    body="$ErrorActionPreference='Stop'\n& "+ps(sys.executable)+" -c "+ps(guard)+"\nif ($LASTEXITCODE -ne 0) {exit 42}\n& "+' '.join(ps(x) for x in argv)+"\nexit $LASTEXITCODE\n"
                else:
                    body='set -eu\n'+shlex.join([sys.executable,'-c',guard])+'\n'+shlex.join(argv)+'\n'
                entries[step]=source(root,operation+'-'+step+('.ps1' if os.name=='nt' else '.sh'),body)
            if operation == 'health':
                # health-apply is a read-only refusal (exit 42); it changes nothing.
                entries['rollback']=source(root,'health-rollback'+('.ps1' if os.name=='nt' else '.sh'),'exit 0\n')
            return entries
        tasks.append({'id':'controller-ready','host':'target','recipe':'runbook','service_id':'native-host-baseline',
                      'requires':[t['id'] for t in tasks],'options':runbook('health'),'timeout_seconds':30})
        inventory['event_profile']=profile.raw
        inventory['hosts']=defender.inventory['hosts']
        inventory['opening']={'catalog':'declared-services','budget_seconds':args.budget_seconds,'deployment_hosts':['target'],
            'controller':{'host':'target','origin':context['origin'],'ca_file':context['ca'],
                'operator_token_file':context['operator_file'],'operator_principal':context['principal'],'operator_epoch':context['epoch'],
                'enrollment_token_file':str(defender.root/'enrollment.json'),'expected_mode':'range-autonomous',
                'bootstrap':runbook('bootstrap'),'activate':runbook('activate')}}
        inventory_path=root/'inventory.json'
        write_private_json(inventory_path,inventory)
        plan=compile_opening(inventory,profile,root,args.runtime,range_deployment=True)
        if os.name=='nt':
            from sentinel_blue.windows_audit import temporary_logon_auditing
            auditing=temporary_logon_auditing()
            auditing.__enter__()
        output=root/'opening-result.json'
        cli=runtime_command(args.runtime,['opening','--inventory',str(inventory_path),'--event-profile',str(defender.profile_path),
            '--runtime',str(args.runtime),'--execute','--range-deployment','--approve-plan',plan_digest(plan),
            '--state-dir',str(root/'opening-state'),'--started-at',str(started),'--output',str(output)])
        with (root/'opening.log').open('w') as log:
            completed=subprocess.run(cli,stdout=log,stderr=subprocess.STDOUT,timeout=max(1,context['deadline']-time.time()+15))
        result=json.loads(output.read_text()) if output.exists() else {}
        report.update(status='passed' if completed.returncode==0 and result.get('status')=='passed' else 'failed',
            version=profile.release['version'],runtime_sha256=defender.digest,initial_packages_or_features=initial,
            opening=result,process_returncode=completed.returncode,
            startup_jobs_installed=all(result.get('stages',{}).get(stage,{}).get('result',{}).get('status')=='verified'
                                       for stage in ('controller_bootstrap','defense_activation')))
    except Exception as exc:
        report.update(error_type=type(exc).__name__,
            error_sites=[{'function':frame.name,'line':frame.lineno} for frame in traceback.extract_tb(exc.__traceback__)[-5:]])
    finally:
        retained=args.retain_for_reboot and report['status']=='passed'
        if retained:
            report['status']='awaiting-reboot'
            for key in ('startup_cleanup','service_cleanup'):
                report[key]={'verified':False,'deferred_to':'owned Azure VM disposal after reboot verification'}
        else:
            try:
                report['startup_cleanup']=cleanup_jobs(context) if context is not None else {'verified':True,'jobs_created':False}
            except Exception as exc:
                report['startup_cleanup']={'verified':False,'error_type':type(exc).__name__}
            try:
                report['service_cleanup']=services_cleanup() if services_cleanup is not None else {'verified':False}
            except Exception as exc:
                report['service_cleanup']={'verified':False,'error_type':type(exc).__name__}
        if auditing is not None:
            auditing.__exit__(None,None,None)
        if not retained and not all(report[key].get('verified') for key in ('startup_cleanup','service_cleanup')):
            report['status']='failed'
        write_private_json(args.output,report)
    print(json.dumps({'status':report['status'],'version':report.get('version'),'error_type':report.get('error_type'),
        'error_sites':report.get('error_sites'),
        'opening_status':report.get('opening',{}).get('status'),'seconds':report.get('opening',{}).get('elapsed_seconds'),
        'cold_start_verified':report.get('opening',{}).get('declared_services_cold_start_verified'),
        'startup_cleanup':report['startup_cleanup'],'service_cleanup':report['service_cleanup']}))
    return 0 if report['status'] in {'passed','awaiting-reboot'} else 2


if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='phase':
        raise SystemExit(phase(Path(sys.argv[2]),sys.argv[3]))
    if len(sys.argv)>1 and sys.argv[1]=='verify-reboot':
        raise SystemExit(verify_reboot(Path(sys.argv[2]),Path(sys.argv[3])))
    raise SystemExit(main())
