"""Private availability measurement of the exact declared packaged defender.

Only four predeclared losses of one owned configuration file and one finite CPU
worker are used. An independent process scores the real owned HTTP service.
No exploitation, account manipulation, persistence campaign, or external target.
"""
from __future__ import annotations
from contextlib import closing, contextmanager
import copy
import hashlib
import json
import os
from pathlib import Path
import secrets
import sqlite3
import subprocess
import sys
import tempfile
import time

from sentinel_blue.actions import ActionExecutor
from sentinel_blue.security_native import powershell_json
from sentinel_blue.event_profile import EventProfile
from sentinel_blue.state import write_private_json
from tools import service_repair_native as repair
from tools.native_defender_startup import NativeDefender
from tools.setup_native_inputs import free_port, manifest, profile_inventory
from tools.uptime_observer import summarize

DURATION = 1200
FAULT_SECONDS = (240, 360, 660, 1080)
LOAD_START, LOAD_SECONDS = 60, 120


class DefaultIntervalDefender(NativeDefender):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # The general opening helper assigns every setup file to its host
        # capture manifest. Here the owned service declares those same files
        # for repair. Each path must have exactly one manifest owner.
        raw = copy.deepcopy(self.profile.raw)
        assigned = {path for entry in raw['services']
                    if entry['service_id'] != 'native-host-baseline'
                    for path in entry.get('required_files', [])}
        host = next(entry for entry in raw['services']
                    if entry['service_id'] == 'native-host-baseline')
        host['required_files'] = [path for path in host['required_files'] if path not in assigned]
        self.profile = EventProfile.from_dict(raw)
        write_private_json(self.profile_path, raw)
        self.plan['profile_fingerprint'] = self.profile.fingerprint

    def request(self, target, payload=None):
        from urllib.error import HTTPError
        try:
            return super().request(target, payload)
        except HTTPError as exc:
            try:
                detail = json.loads(exc.read(2048)).get('error', 'request rejected')
            except (ValueError, AttributeError):
                detail = 'request rejected'
            finally:
                exc.close()
            raise RuntimeError(f'{target}: HTTP {exc.code}: {str(detail)[:250]}') from exc

    def command(self, runtime, args, name, *, background=False):
        # Use the distributed CLI defaults rather than the opening fixture's
        # accelerated polling configuration. Runtime bytes and gates are intact.
        args = list(args)
        for flag, value in (('--interval', '15'), ('--maintenance-interval', '30')):
            if flag in args:
                args[args.index(flag)+1] = value
        return super().command(runtime, args, name, background=background)


@contextmanager
def owned_service(root, cleanup):
    root.mkdir(mode=0o700)
    name = 'sbuptime' + secrets.token_hex(5)
    service = name if os.name == 'nt' else name+'.service'
    port = free_port()
    files = [root/'web.conf', root/'second.conf']
    for path in files:
        path.write_bytes(b'trusted')
    executable = root/('owned-service.exe' if os.name == 'nt' else 'owned-service.py')
    executor = ActionExecutor(root/'fixture-state', authorized_networks=['127.0.0.0/8'])
    owned, unit, unit_text = False, None, None
    try:
        if os.name == 'nt':
            powershell_json("Add-Type -TypeDefinition $p.source -OutputAssembly $p.output -OutputType WindowsApplication -ReferencedAssemblies System.ServiceProcess,System; 'true'",
                            {'source': repair.CSHARP_WORKER, 'output': str(executable)})
            repair.command(['sc.exe', 'query', service], expected=1060)
            repair.command(['sc.exe', 'create', service, 'binPath=',
                            subprocess.list2cmdline([str(executable), service, str(root), str(port)]),
                            'start=', 'demand'])
            owned = True
        else:
            executable.write_text(repair.PYTHON_WORKER)
            executable.chmod(0o700)
            unit = Path('/etc/systemd/system')/service
            unit_text = f'[Unit]\nDescription=Sentinel owned uptime fixture\n[Service]\nExecStart={sys.executable} {executable} {root} {port}\nRestart=no\n'
            with unit.open('x') as stream:
                stream.write(unit_text)
            owned = True
            unit.chmod(0o600)
            repair.command(['systemctl', 'daemon-reload'])
        executor._set_service_state(service, 'running')
        repair.wait_state(executor, service, 'running')
        yield service, port, files
    finally:
        if owned:
            if executor._service_state(service) != 'stopped':
                executor._set_service_state(service, 'stopped')
                repair.wait_state(executor, service, 'stopped')
            if os.name == 'nt':
                repair.command(['sc.exe', 'delete', service])
                repair.command(['sc.exe', 'query', service], expected=1060)
            else:
                if unit.read_text() != unit_text:
                    raise RuntimeError('Owned fixture unit changed before cleanup')
                unit.unlink()
                repair.command(['systemctl', 'daemon-reload'])
            cleanup['owned_service_removed'] = True


def database_sample(defender, service, start, start_unix):
    result = {'elapsed_seconds': round(time.monotonic()-start, 3)}
    try:
        path = defender.root/'controller.db'
        with closing(sqlite3.connect(path.as_uri()+'?mode=ro', uri=True, timeout=.1)) as db:
            row = db.execute("SELECT a.latest_telemetry, b.status FROM agents a LEFT JOIN baselines b ON b.agent_id=a.agent_id WHERE a.agent_id='target'").fetchone()
            if row:
                data = json.loads(row[0] or '{}')
                result.update(sequence=data.get('sequence'), baseline_status=row[1],
                              observation_age_seconds=round(time.time()-data['observed_at'], 3),
                              collector_error_count=len(data.get('collector_errors', [])),
                              collector_errors=data.get('collector_errors', [])[:16],
                              collector_issue_sources=data.get('collector_issue_sources', [])[:16],
                              all_probes_healthy=bool(data.get('probes')) and all(p.get('healthy') for p in data['probes']))
            actions = []
            for action_type, status, created, completed, parameters in db.execute(
                    "SELECT action_type,status,created_at,completed_at,parameters_json FROM actions WHERE agent_id='target'"):
                if action_type in ('repair_service', 'restart_service') and json.loads(parameters).get('service') == service:
                    actions.append({'type': action_type, 'status': status,
                                    'created_seconds': round(created-start_unix, 3),
                                    'completed_seconds': None if completed is None else round(completed-start_unix, 3)})
            result['service_actions'] = actions
    except (OSError, sqlite3.Error, ValueError, KeyError, TypeError) as exc:
        result['diagnostic_error_type'] = type(exc).__name__
    result['defender_processes_alive'] = all(child.poll() is None for child in defender.children)
    return result


def rehearse():
    from sentinel_blue import __version__
    root = Path(__file__).resolve().parent
    runtime = root/'runtime.pyz'
    RUNTIME_SHA = json.loads((root/'run-options.json').read_text())['runtime_sha256']
    assert hashlib.sha256(runtime.read_bytes()).hexdigest() == RUNTIME_SHA
    cleanup = {'owned_service_removed': False, 'defender_removed': False,
               'observer_removed': True, 'load_worker_removed': True}
    report = {'version': __version__, 'runtime_sha256': RUNTIME_SHA,
              'platform': 'Windows' if os.name == 'nt' else 'Linux', 'mode': 'uptime',
              'scope': 'owned loopback service; real packaged controller and agent; independent local scoring process',
              'live_red_team_executed': False, 'full_network_test_executed': False,
              'full_competition_readiness_proven': False,
              'agent_interval_seconds': 15, 'controller_maintenance_interval_seconds': 30,
              'planned_duration_seconds': DURATION, 'fault_schedule_seconds': list(FAULT_SECONDS),
              'cpu_load_schedule': {'start_seconds': LOAD_START, 'duration_seconds': LOAD_SECONDS, 'workers': 1},
              'events': [], 'cleanup': cleanup, 'phases': {}}
    began = time.monotonic()
    defender = observer = load = None
    samples, scores = [], []
    with tempfile.TemporaryDirectory(prefix='owned-uptime-', dir=root) as directory:
        work = Path(directory)
        try:
            with owned_service(work/'service', cleanup) as (service, port, files):
                specs = [{'name': 'owned-health', 'kind': 'http', 'target': f'http://127.0.0.1:{port}/health',
                          'expected_status': [200], 'expected_body': 'fixture-ok', 'timeout': 1}]
                declared = manifest(service, 'http', port, specs)
                declared.update(required_files=[str(p) for p in files],
                    allowed_automatic_actions=['repair_service', 'capture_restore_point'],
                    approval_actions=['rollback_service_repair'],
                    repair_policy={'restore_files': [str(p) for p in files], 'restart_unhealthy': True,
                                   'validation_timeout_seconds': 30,
                                   'allow_unrelated_payload_errors': True,
                                   'attempt_limits': {'cooldown_seconds': 30, 'maximum_attempts': 12}})
                # Only capture-path declarations are consumed here. This test
                # pre-creates its service and executes no setup task/runbook.
                tasks = [{'options': {'files': [{'path': str(p)} for p in files]}}]
                inventory = profile_inventory(runtime, tasks, [declared])
                defender = DefaultIntervalDefender(work/'defender', runtime, inventory,
                                                   started_at=time.time(), budget=180)
                try:
                    report['activation'] = defender.start()
                    report['phases']['activation'] = {'passed': True}
                    ready, stop, output = work/'observer-ready.json', work/'observer-stop', work/'observer.jsonl'
                    observer = subprocess.Popen([sys.executable, str(root/'tools/uptime_observer.py'),
                        '--target', specs[0]['target'], '--duration', str(DURATION), '--output', str(output),
                        '--ready', str(ready), '--stop', str(stop)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    limit = time.monotonic()+15
                    while not ready.exists():
                        if observer.poll() is not None or time.monotonic() >= limit:
                            raise RuntimeError('Independent observer could not start')
                        time.sleep(.1)
                    identity = json.loads(ready.read_text())
                    start, start_unix = identity['start_monotonic'], identity['start_unix']
                    report['measurement_start_unix'] = start_unix
                    next_sample, next_fault, load_started, load_finished = 0, 0, False, False
                    while time.monotonic()-start < DURATION:
                        elapsed = time.monotonic()-start
                        if next_fault < len(FAULT_SECONDS) and elapsed >= FAULT_SECONDS[next_fault]:
                            present = files[0].is_file()
                            if present:
                                assert files[0].parent == work/'service' and files[0].name == 'web.conf'
                                files[0].unlink()
                            report['events'].append({'kind': 'owned_configuration_file_loss',
                                'scheduled_seconds': FAULT_SECONDS[next_fault], 'actual_seconds': round(elapsed, 3),
                                'injected': present, 'already_missing': not present})
                            next_fault += 1
                        if not load_started and elapsed >= LOAD_START:
                            code = 'import time\nend=time.monotonic()+120\nx=1\nwhile time.monotonic()<end:\n x=(x*1664525+1013904223)&0xffffffff\n'
                            load = subprocess.Popen([sys.executable, '-c', code],
                                                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                            load_started = True
                            report['events'].append({'kind': 'finite_cpu_load_started', 'actual_seconds': round(elapsed, 3)})
                        if load is not None and load.poll() is not None and not load_finished:
                            load_finished = True
                            report['events'].append({'kind': 'finite_cpu_load_finished',
                                'actual_seconds': round(elapsed, 3), 'exit_code': load.returncode})
                        if elapsed >= next_sample:
                            samples.append(database_sample(defender, service, start, start_unix))
                            next_sample = elapsed+5
                            report['measurement_elapsed_seconds'] = round(elapsed, 3)
                            (root/'defensive-uptime-samples.json').write_text(json.dumps(samples))
                            (root/'defensive-progress.json').write_text(json.dumps(report))
                        if observer.poll() is not None and elapsed < DURATION-3:
                            raise RuntimeError('Independent observer exited early')
                        time.sleep(.25)
                    report['measured_duration_seconds'] = round(time.monotonic()-start, 3)
                    stop.touch()
                    observer.wait(timeout=10)
                    scores = [json.loads(line) for line in output.read_text().splitlines()]
                    report['scoring'] = summarize(scores, DURATION)
                    report['phases']['measurement'] = {'passed': len(scores) == DURATION,
                        'meaning': 'measurement completed, not an uptime acceptance threshold'}
                    samples.append(database_sample(defender, service, start, start_unix))
                finally:
                    for process in (observer, load):
                        if process is not None and process.poll() is None:
                            process.terminate()
                            try:
                                process.wait(timeout=10)
                            except subprocess.TimeoutExpired:
                                process.kill(); process.wait(timeout=10)
                    if defender is not None:
                        try:
                            report['activation_diagnostics'] = defender.diagnostics()
                            report['native_inventory_section_seconds'] = defender.inventory_section_seconds()
                        finally:
                            closed = defender.close()
                            cleanup['defender_removed'] = closed['verified']
                            cleanup['audit_policy_restored'] = not closed.get('errors')
        except Exception as exc:
            report['error_type'] = type(exc).__name__
            report['error'] = str(exc)[:350]
        finally:
            for process, key in ((observer, 'observer_removed'), (load, 'load_worker_removed')):
                if process is not None:
                    if process.poll() is None:
                        process.terminate()
                        try:
                            process.wait(timeout=10)
                        except subprocess.TimeoutExpired:
                            process.kill(); process.wait(timeout=10)
                    cleanup[key] = process.poll() is not None
            # Preserve primary diagnostics even if Windows denies subsequent
            # temporary-directory deletion because a handle is still open.
            (root/'defensive-progress.json').write_text(json.dumps(report))
            if not scores and (work/'observer.jsonl').exists():
                scores = [json.loads(line) for line in (work/'observer.jsonl').read_text().splitlines()]
                report['scoring'] = summarize(scores, DURATION)
    cleanup['verified'] = all(cleanup.values())
    report['seconds'] = round(time.monotonic()-began, 3)
    report['passed'] = cleanup['verified'] and 'error_type' not in report and len(scores) == DURATION
    report['passed_means'] = 'bounded measurement and cleanup completed; see measured availability'
    report['final_service_actions'] = next((row['service_actions'] for row in reversed(samples) if 'service_actions' in row), [])
    (root/'defensive-uptime-samples.json').write_text(json.dumps(samples))
    (root/'defensive-uptime-probes.json').write_text(json.dumps(scores))
    (root/'defensive-uptime.json').write_text(json.dumps(report, indent=2))
    return report


def summary(report):
    keys = ('status', 'version', 'runtime_sha256', 'platform', 'mode', 'scope', 'passed', 'passed_means',
            'live_red_team_executed', 'full_network_test_executed', 'full_competition_readiness_proven',
            'seconds', 'planned_duration_seconds', 'measured_duration_seconds', 'phases', 'scoring',
            'cleanup', 'final_service_actions', 'error_type')
    return {key: report[key] for key in keys if key in report}
