"""Owned native Azure acceptance. No simulated service/probe/transport results.

The observer offers only authenticated, bounded HTTP health checks to the two
declared lab targets. Router tests use real veth links/network namespaces on the
owned Linux VM, preserving Azure's subnet and NIC configuration.
"""
from __future__ import annotations
import copy, hashlib, hmac, http.client, http.server, json, os, shutil, socket, ssl
import subprocess, sys, threading, time, traceback, uuid
from dataclasses import asdict
from pathlib import Path
from urllib.parse import urlparse

ROOT=Path(__file__).resolve().parent.parent
RUNTIME=ROOT/'sentinel-blue.pyz'
CONFIG=json.loads((ROOT/'acceptance.json').read_text())
assert hashlib.sha256(RUNTIME.read_bytes()).hexdigest()==CONFIG['runtime_sha256']
sys.path.insert(0,str(RUNTIME))
from sentinel_blue.event_profile import EventProfile
from sentinel_blue.setup import SetupRunner, compile_plan, plan_digest
from sentinel_blue.setup_transport import SetupTransport, powershell_environment
from sentinel_blue.setup_transactions import bind
from sentinel_blue.protocol import ProbeResult
from sentinel_blue.probes import run_probe

RUN=CONFIG['run']; TAG='sb171'+RUN[:8]; TOKENS=set(); CHILDREN=[]
WINDOWS=os.name=='nt'; ADDRESS='10.79.2.5' if WINDOWS else '10.79.2.4'
REPORT={'runtime_sha256':CONFIG['runtime_sha256'],'run':RUN,'status':'running','cases':{},'observations':[]}
HOST={'name':'target','agent_id':'target','address':'127.0.0.1','transport':'local','platform':'windows' if WINDOWS else 'linux'}
TRANSPORT=SetupTransport(ROOT/'native-output')

def save(): (ROOT/'receipt.json').write_text(json.dumps(REPORT,indent=2))
def native(argv,code=None,timeout=120,allowed=(0,)):
    r=subprocess.run(argv,input=code,capture_output=True,text=True,timeout=timeout,
        env=powershell_environment(argv[0]) if WINDOWS else None)
    with (ROOT/'fixture-native.log').open('a') as f: f.write(r.stdout+r.stderr)
    if r.returncode not in allowed: raise RuntimeError(f'Native fixture command failed ({r.returncode}): '+r.stderr[-1800:]+r.stdout[-800:])
    return r.stdout.strip()
def ps(code,**kw): return native(['powershell.exe','-NoLogo','-NoProfile','-NonInteractive','-Command',"$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';"+code],**kw)
def src(name,value):
    p=ROOT/name;p.write_bytes(value.encode());return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def probe(port,body='desired',address=None):
    return {'name':'owned-external-http','kind':'http','target':f'http://{address or ADDRESS}:{port}/','expected_status':[200],'expected_body':body,'timeout':2}
def manifest(name,checks,host='target'):
    return {'host':host,'service_id':name,'protocol':'http','port':urlparse(checks[-1]['target']).port if checks[-1]['kind'] in {'http','https'} else checks[-1]['port'],
      'implementation':'owned native acceptance','dependencies':[],'required_accounts':[],'required_files':[],'required_data':[],
      'credential_source':'','expected_transactions':checks,'local_checks':[],'allowed_automatic_actions':[],'approval_actions':[],
      'backup_method':'owned snapshots','recovery_method':'owned rollback','rollback_method':'owned rollback'}
def plan(recipe,options,checks,*,host=None,service=None,health=30):
    service=service or options.get('service') or {'linux-nginx':'nginx','windows-iis':'W3SVC'}.get(recipe) or 'owned-fixture'
    host=host or HOST;raw=copy.deepcopy(EventProfile.testing().raw)
    raw['deployment']['approved_routes']=[host['transport']]
    raw['scope'].update(authorized_networks=['127.0.0.0/8','10.79.0.0/16','10.201.0.0/16'],
       authorized_hosts=['127.0.0.1','10.79.1.4','10.79.2.4','10.79.2.5','10.201.1.1','10.201.1.254','10.201.2.1'],
       controller_ingress_hosts=['127.0.0.1'])
    raw['services']=[manifest(service or 'owned-fixture',checks,host['name'])];raw['services_confirmed']=True
    profile=EventProfile.from_dict(raw)
    inv={'authorized_networks':list(profile.authorized_networks),'hosts':[host],
      'setup':{'budget_seconds':900,'max_parallel_hosts':1,'tasks':[{'id':'owned-task','host':host['name'],'recipe':recipe,
       'service_id':service or 'owned-fixture','timeout_seconds':720,'health_wait_seconds':health,'options':options}]}}
    return compile_plan(inv,profile,ROOT),profile
def remote_probe(spec,*args,**kw):
    request={'nonce':uuid.uuid4().hex,'probe':spec};data=json.dumps(request,sort_keys=True).encode()
    context=ssl.create_default_context(cafile=str(ROOT/'observer.crt'))
    conn=http.client.HTTPSConnection('10.79.1.4',48171,timeout=6,context=context)
    try:
        conn.request('POST','/probe',data,{'X-Sentinel-Test':hmac.new(bytes.fromhex(CONFIG['probe_key']),data,hashlib.sha256).hexdigest()})
        response=conn.getresponse();body=response.read(65536)
        assert response.status==200
        assert hmac.compare_digest(response.getheader('X-Sentinel-Test',''),hmac.new(bytes.fromhex(CONFIG['probe_key']),body,hashlib.sha256).hexdigest())
        result=json.loads(body);assert result['nonce']==request['nonce'];assert result['observer']=='10.79.1.4'
        REPORT['observations'].append(result);save();return ProbeResult(**result['result'])
    finally:conn.close()
def execute(name,pair,callback=remote_probe):
    p,profile=pair
    row=SetupRunner(p,profile,probe=callback).execute(ROOT/('state-'+name),plan_digest(p))
    (ROOT/(name+'-setup.json')).write_text(json.dumps(row,indent=2))
    result=row['tasks']['owned-task']
    if result.get('transaction_id'):TOKENS.add(result['transaction_id'])
    return result
def phase(pair,phase_name,token):
    TOKENS.add(token);task=pair[0]['tasks'][0]
    r=TRANSPORT.execute(HOST,bind(task[phase_name],token),300)
    if r.returncode!=0 or r.uncertain:raise RuntimeError(f'Native transaction {phase_name} failed: {asdict(r)}')
def case(name,fn):
    start=time.monotonic()
    try: result=fn();REPORT['cases'][name]={'passed':True,'seconds':round(time.monotonic()-start,3),'result':result}
    except Exception as e:
        REPORT['cases'][name]={'passed':False,'seconds':round(time.monotonic()-start,3),'error':str(e)[-2200:]}
        (ROOT/(name+'-failure.txt')).write_text(traceback.format_exc())
    save()
def child(argv):
    log=(ROOT/('child-'+str(len(CHILDREN))+'.log')).open('w')
    p=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT);log.close();CHILDREN.append(p);return p
def wait_http(spec,external=True):
    for _ in range(20):
        r=remote_probe(spec) if external else run_probe(spec,['10.201.0.0/16'])
        if r.healthy:return r
        time.sleep(.3)
    raise AssertionError('Real service did not become externally healthy')

def observer():
    key=bytes.fromhex(CONFIG['probe_key']);seen=set()
    class Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self,*a):pass
        def do_POST(self):
            self.connection.settimeout(5)
            try:
                count=int(self.headers.get('Content-Length','0'));assert self.path=='/probe' and 0<count<=8192
                data=self.rfile.read(count);assert hmac.compare_digest(self.headers.get('X-Sentinel-Test',''),hmac.new(key,data,hashlib.sha256).hexdigest())
                request=json.loads(data);nonce=request['nonce'];assert len(nonce)==32 and nonce not in seen;seen.add(nonce)
                spec=request['probe'];u=urlparse(spec['target'])
                assert set(spec)<= {'name','kind','target','expected_status','expected_body','timeout'}
                assert spec['kind']=='http' and u.scheme=='http' and u.hostname in {'10.79.2.4','10.79.2.5'} and 48000<=u.port<=49000
                assert 0<float(spec.get('timeout',2))<=3 and len(spec.get('expected_body',''))<=1024
                result={'nonce':nonce,'observer':'10.79.1.4','at':time.time(),'result':asdict(run_probe(spec,['10.79.2.0/24']))}
                body=json.dumps(result,sort_keys=True).encode();self.send_response(200);self.send_header('Content-Length',str(len(body)))
                self.send_header('X-Sentinel-Test',hmac.new(key,body,hashlib.sha256).hexdigest());self.end_headers();self.wfile.write(body)
                with (ROOT/'observer-observations.jsonl').open('a') as f:f.write(body.decode()+'\n')
            except Exception:self.send_error(403)
    server=http.server.ThreadingHTTPServer(('10.79.1.4',48171),Handler)
    context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);context.load_cert_chain(ROOT/'observer.crt',ROOT/'observer.key')
    server.socket=context.wrap_socket(server.socket,server_side=True)
    (ROOT/'observer-ready.json').write_text(json.dumps({'pid':os.getpid(),'runtime_sha256':CONFIG['runtime_sha256']}))
    server.serve_forever()

def linux_services():
    base=Path('/var/lib')/TAG;base.mkdir(mode=0o755)
    content=base/'index.html';content.write_text('original');content.chmod(0o640)
    os.setxattr(content,'user.sentinel-test',b'original-metadata')
    unit=Path('/etc/systemd/system')/(TAG+'.service');assert not unit.exists()
    unit.write_text('[Unit]\nDescription=Owned Sentinel 171 acceptance\n[Service]\nType=simple\nExecStart=/usr/bin/python3 -m http.server 48274 --bind 10.79.2.4 --directory '+str(base)+'\n[Install]\nWantedBy=multi-user.target\n')
    native(['systemctl','daemon-reload']);native(['systemctl','start',TAG]);wait_http(probe(48274,'original'))
    options={'service':TAG,'enable':True,'files':[{'path':str(content),'source':src('desired.txt','desired'),'previous_sha256':hashlib.sha256(b'original').hexdigest(),'mode':'0644'}]}
    def failed():
        row=execute('linux-failure',plan('linux-service',options,[probe(48274,'unavailable')],health=5))
        assert row['apply']['returncode']==0 and row['rollback_status']=='completed',row
        assert content.read_text()=='original' and content.stat().st_mode&0o777==0o640
        assert os.getxattr(content,'user.sentinel-test')==b'original-metadata'
        assert native(['systemctl','is-enabled',TAG],allowed=(0,1))=='disabled'
        wait_http(probe(48274,'original'));return row
    def drift():
        pair=plan('linux-service',options,[probe(48274,'unavailable')],health=5);altered=False
        def observe(spec,*a,**kw):
            nonlocal altered
            if content.read_text()=='desired' and not altered:content.write_text('operator-edit');altered=True
            return remote_probe(spec)
        row=execute('linux-drift',pair,observe)
        assert row['status']=='uncertain' and row['rollback_status']=='unconfirmed' and content.read_text()=='operator-edit',row
        again=execute('linux-held',pair);assert again['status']=='uncertain' and not again['changed'],again
        # Explicitly reconcile our injected edit using the recorded after-state.
        content.write_text('desired');phase(pair,'rollback',row['transaction_id']);return {'conflict':row,'next_admission':again}
    def interruption():
        pair=plan('linux-service',options,[probe(48274)],health=10);token=uuid.uuid4().hex
        phase(pair,'apply',token);wait_http(probe(48274))
        # The apply process has exited; a new controller cannot adopt its state.
        row=execute('linux-unconfirmed-controller',pair)
        assert row['status']=='uncertain' and not row['changed'],row
        phase(pair,'rollback',token);wait_http(probe(48274,'original'));return row
    def success():
        row=execute('linux-success',plan('linux-service',options,[probe(48274)],health=10))
        assert row['status']=='ready' and row['commit']['returncode']==0,row
        state=json.loads((Path('/var/lib/sentinel-blue-setup-transactions')/row['transaction_id']/'state.json').read_text())
        assert state['status']=='committed';wait_http(probe(48274));return row
    try:
        for name,fn in [('linux-restore',failed),('linux-operator-edit',drift),('linux-controller-loss',interruption),('linux-commit',success)]:case(name,fn)
    finally:
        native(['systemctl','stop',TAG]);native(['systemctl','disable',TAG]);unit.unlink();native(['systemctl','daemon-reload']);shutil.rmtree(base)
    def nginx():
        name=TAG+'nginx';opts={'name':name,'listen_address':ADDRESS,'port':48278,'content':src('nginx-body.txt','desired')}
        pair=plan('linux-nginx',opts,[probe(48278,'unavailable')],health=6)
        row=execute('nginx-failure',pair)
        assert row['apply']['returncode']==0 and row['rollback_status']=='completed',row
        assert not Path('/etc/nginx/conf.d/sentinel-'+name+'.conf').exists()
        assert not Path('/var/lib/sentinel-blue-apps') .joinpath(name,'www/index.html').exists()
        assert not remote_probe(probe(48278)).healthy
        # A second successful transaction uses the real installed nginx binary.
        success=execute('nginx-success',plan('linux-nginx',opts,[probe(48278)],health=10))
        assert success['status']=='ready',success;wait_http(probe(48278))
        return {'rolled_back':row,'committed':success}
    case('nginx-native-install-rollback-commit',nginx)
    def new_unit():
        name=TAG+'new';directory=Path('/var/lib')/name;directory.mkdir(mode=0o755)
        unit=Path('/etc/systemd/system')/(name+'.service');assert not unit.exists()
        text='[Unit]\nDescription=Owned new-unit rollback\n[Service]\nExecStart=/usr/bin/python3 -m http.server 48280 --bind 10.79.2.4 --directory '+str(directory)+'\n[Install]\nWantedBy=multi-user.target\n'
        opts={'service':name,'enable':True,'files':[
            {'path':str(unit),'source':src('new-unit.txt',text),'mode':'0644','previous_sha256':'absent'},
            {'path':str(directory/'index.html'),'source':src('new-body.txt','desired'),'mode':'0644','previous_sha256':'absent'}]}
        try:
            row=execute('linux-new-unit',plan('linux-service',opts,[probe(48280,'unavailable')],health=6))
            assert row['apply']['returncode']==0 and row['rollback_status']=='completed',row
            assert not unit.exists() and not (directory/'index.html').exists()
            assert not Path('/etc/systemd/system/multi-user.target.wants',name+'.service').is_symlink()
            assert not remote_probe(probe(48280)).healthy;return row
        finally:
            native(['systemctl','stop',name],allowed=(0,5));native(['systemctl','disable',name],allowed=(0,1))
            unit.unlink(missing_ok=True);native(['systemctl','daemon-reload']);shutil.rmtree(directory)
    case('linux-new-unit-process-removed',new_unit)

def windows_services():
    exe=ROOT/(TAG+'.exe');name=TAG
    code='''using System;using System.Net;using System.Text;using System.Threading;using System.ServiceProcess;
public class OwnedService:ServiceBase {HttpListener listener;public OwnedService(){ServiceName="NAME";}
protected override void OnStart(string[] args){listener=new HttpListener();listener.Prefixes.Add("http://10.79.2.5:48275/");listener.Start();ThreadPool.QueueUserWorkItem(delegate(object s){while(listener.IsListening){try{var c=listener.GetContext();var b=Encoding.UTF8.GetBytes("desired");c.Response.ContentLength64=b.Length;c.Response.OutputStream.Write(b,0,b.Length);c.Response.Close();}catch{break;}}});}
protected override void OnStop(){listener.Stop();listener.Close();}public static void Main(){ServiceBase.Run(new OwnedService());}}'''.replace('NAME',name)
    ps("Add-Type -TypeDefinition @'\n"+code+"\n'@ -ReferencedAssemblies System.ServiceProcess.dll -OutputAssembly '"+str(exe)+"' -OutputType WindowsApplication;New-Service -Name '"+name+"' -BinaryPathName '\""+str(exe)+"\"' -StartupType Manual | Out-Null;New-NetFirewallRule -Name '"+TAG+"-service' -DisplayName '"+TAG+"-service' -Direction Inbound -Action Allow -Protocol TCP -LocalPort 48275,48277 -RemoteAddress 10.79.1.4 | Out-Null")
    def failed():
        row=execute('windows-service-failure',plan('windows-service',{'service':name,'enable':True},[probe(48275,'unavailable')],health=30))
        assert row['apply']['returncode']==0 and row['rollback_status']=='completed',row
        assert ps("$s=Get-Service '"+name+"';[string]$s.Status+','+[string]$s.StartType")=='Stopped,Manual'
        assert not remote_probe(probe(48275)).healthy;return row
    def success():
        row=execute('windows-service-success',plan('windows-service',{'service':name,'enable':True},[probe(48275)],health=40))
        assert row['status']=='ready',row;wait_http(probe(48275));return row
    case('windows-service-restore',failed);case('windows-service-commit',success)
    public=ROOT/'public';public.mkdir();(public/'index.html').write_text('desired')
    child([sys.executable,'-m','http.server','48276','--bind',ADDRESS,'--directory',str(public)])
    def firewall():
        policy=TAG+'fw';opts={'name':policy,'allow':[{'source':'10.79.1.4/32','protocol':'tcp','port':48276}]}
        assert not remote_probe(probe(48276)).healthy,'Port must be externally blocked before test'
        row=execute('firewall-failure',plan('windows-firewall',opts,[probe(48276,'unavailable')],health=30))
        assert row['apply']['returncode']==0 and row['rollback_status']=='completed',row
        assert ps("@(Get-NetFirewallRule -Name 'Sentinel-"+policy+"-000' -ErrorAction SilentlyContinue).Count")=='0'
        assert not remote_probe(probe(48276)).healthy
        ok=execute('firewall-success',plan('windows-firewall',opts,[probe(48276)],health=40))
        assert ok['status']=='ready',ok;wait_http(probe(48276))
        opts['allow'].append({'source':'10.79.1.4/32','protocol':'tcp','port':48279})
        row2=execute('firewall-preexisting',plan('windows-firewall',opts,[probe(48276,'unavailable')],health=30))
        assert row2['rollback_status']=='completed',row2
        assert ps("@(Get-NetFirewallRule -Name 'Sentinel-"+policy+"-000' -ErrorAction SilentlyContinue).Count")=='1'
        assert ps("@(Get-NetFirewallRule -Name 'Sentinel-"+policy+"-001' -ErrorAction SilentlyContinue).Count")=='0'
        wait_http(probe(48276));return {'rollback':row,'commit':ok,'preserved_existing':row2}
    case('windows-firewall-native',firewall)
    def iis():
        opts={'name':TAG+'iis','listen_address':ADDRESS,'port':48277,'content':src('iis-body.txt','desired')}
        row=execute('iis-failure',plan('windows-iis',opts,[probe(48277,'unavailable')],health=40))
        assert row['apply']['returncode']==0 and row['rollback_status']=='completed',row
        assert ps("Import-Module WebAdministration;@(Get-Website -Name 'Sentinel-"+TAG+"iis').Count")=='0'
        assert not Path('C:/inetpub/Sentinel-'+TAG+'iis').exists()
        ok=execute('iis-success',plan('windows-iis',opts,[probe(48277)],health=45))
        assert ok['status']=='ready',ok;wait_http(probe(48277));return {'rollback':row,'commit':ok}
    case('windows-iis-native-install-rollback-commit',iis)

def cleanup_services():
    # This guard is checked again by the cloud driver before entering cleanup.
    if WINDOWS:
        ps("if(Get-Service '"+TAG+"' -ErrorAction SilentlyContinue){Stop-Service '"+TAG+"';sc.exe delete '"+TAG+"'|Out-Null};Get-NetFirewallRule -Name '"+TAG+"-service','Sentinel-"+TAG+"fw-*' -ErrorAction SilentlyContinue|Remove-NetFirewallRule;Import-Module WebAdministration -ErrorAction SilentlyContinue;if(Get-Website -Name 'Sentinel-"+TAG+"iis' -ErrorAction SilentlyContinue){Remove-Website -Name 'Sentinel-"+TAG+"iis'};if(Test-Path 'IIS:\\AppPools\\Sentinel-"+TAG+"iis'){Remove-WebAppPool -Name 'Sentinel-"+TAG+"iis'}")
        p=Path('C:/inetpub/Sentinel-'+TAG+'iis')
        if p.exists():assert (p/'index.html').read_text()=='desired';(p/'index.html').unlink();p.rmdir()
    else:
        p=Path('/etc/nginx/conf.d/sentinel-'+TAG+'nginx.conf')
        if p.exists():p.unlink();native(['systemctl','stop','nginx']);native(['systemctl','disable','nginx'])
        p=Path('/var/lib/sentinel-blue-apps')/(TAG+'nginx')
        if p.exists():shutil.rmtree(p)
    return {'owned_services_removed':True,'installed_prerequisites_retained':True}

def main():
    os.umask(0o077)
    if sys.argv[1]=='observer':observer();return
    try:
        if sys.argv[1]=='linux':linux_services()
        elif sys.argv[1]=='windows':windows_services()
        elif sys.argv[1]=='cleanup':REPORT['cleanup']=cleanup_services()
        else:raise ValueError('Unknown acceptance role')
    except Exception as e:
        REPORT['fatal']={'error_type':type(e).__name__,'error':str(e)[-2000:]};(ROOT/'fatal.txt').write_text(traceback.format_exc())
    finally:
        for p in CHILDREN:
            if p.poll() is None:p.terminate()
        for p in CHILDREN:
            try:p.wait(timeout=10)
            except subprocess.TimeoutExpired:p.kill();p.wait(timeout=5)
        REPORT['tokens']=sorted(TOKENS)
        REPORT['status']='passed' if REPORT['cases'] and all(x['passed'] for x in REPORT['cases'].values()) and 'fatal' not in REPORT else 'failed'
        save();print('SB171='+json.dumps(REPORT),flush=True)
if __name__=='__main__':main()
