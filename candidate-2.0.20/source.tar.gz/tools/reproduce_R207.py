"""Read-only application review: private files/SQLite; no native service mutation.

Imports either exact source or a .pyz. Service/probe observations and approved
setup artifacts are modeled. Controller policy, grants, backup audits, telemetry
validation, scheduling, session loop, JobControl admission and job files are real.
Only daemon/job process creation is replaced by inert owned handles.
"""
from __future__ import annotations
import argparse,copy,hashlib,json,os,signal,sys,tempfile,time,unittest
from contextlib import ExitStack
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch


def sha(data):return hashlib.sha256(data).hexdigest()

class IdleProcess:
    def __init__(self):self.code=None
    def poll(self):return self.code
    def terminate(self):self.code=0
    def kill(self):self.code=-9
    def wait(self,timeout=None):return self.code


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--source',required=True);parser.add_argument('--runtime')
    parser.add_argument('--output',required=True);parser.add_argument('--assert-correctness',action='store_true')
    args=parser.parse_args();source=Path(args.source).resolve()
    application=Path(args.runtime).resolve() if args.runtime else source/'src'
    sys.path[:0]=[str(application),str(source/'tests'),str(source)]
    import sentinel_blue
    assert str(application) in sentinel_blue.__file__,sentinel_blue.__file__
    from sentinel_blue.controller import ControllerApp
    from sentinel_blue.store import Store
    from sentinel_blue.event_profile import EventProfile
    from sentinel_blue.restoration import RestorePointStore
    from sentinel_blue.telemetry_diagnostics import restore_point_issues,merge_health_diagnostics
    from sentinel_blue import setup_redo,desktop_jobs,linux_workspace
    from sentinel_blue.state import write_private_json,read_private_json
    from sentinel_blue.detection import lost_restore_points
    from test_service_repair import repair_fixture,damage
    from test_store_controller import _promote_integrity_baseline

    measured={'version':sentinel_blue.__version__,'application':sentinel_blue.__file__,'python':sys.version,
              'scope':'Private real files, SQLite and production control flow. No daemon deployment. Synthetic service/probe samples and setup artifacts; inert process factory.'}
    start=time.monotonic();clock=time.time()

    def fixture(root,*,auto=True,mode='guarded-autonomous',long=False):
        folder=root/'target'
        if long:folder=folder/('a'*100)/('b'*100)/('c'*50)
        folder.mkdir(parents=True)
        path=folder/'web.conf';path.write_bytes(b'trusted');path.chmod(0o600)
        profile,baseline=repair_fixture(str(path));raw=copy.deepcopy(profile.raw)
        raw['services'][0]['host']='local-linux';profile=EventProfile.from_dict(raw)
        baseline['agent_id']='local-linux';baseline['observed_at']=clock-10
        db=Store(':memory:')
        app=ControllerApp(db,'t'*32,operator_token='o'*32,event_profile=profile,auto_recover_services=auto)
        app.set_autonomy_mode(mode);app.ingest(baseline);_promote_integrity_baseline(app,db,'local-linux')
        write_private_json(root/'profile.json', profile.raw)
        return path,profile,baseline,db,app

    def setup_record(root,runtime_file):
        workspace=root/'session';workspace.mkdir(mode=0o700)
        original=root/'jobs/original/job.json';original.parent.mkdir(mode=0o700,parents=True)
        write_private_json(original,{'kind':'setup'})
        write_private_json(original.parent/'result.json',{'status':'passed'})
        inventory=root/'inventory.json'
        write_private_json(inventory,{'hosts':[{'name':'local-linux','address':'127.0.0.1'}],
          'setup':{'tasks':[{'id':'t-web','host':'local-linux','service_id':'web.service'}]}})
        record=setup_redo.record_approved_setup(workspace,{'kind':'setup','inventory':str(inventory),
          'event_profile':str(root/'profile.json'),'runtime':str(runtime_file),'range_deployment':True,
          'approved_digest':'a'*64},job_root=root/'jobs',job_path=original)
        return workspace,record

    class ReviewClient:
        # Connection fields are inert fixture credentials. The original test
        # already replaces daemon launch; policy still calls the real controller.
        origin='http://127.0.0.1:45555';principal='operator';epoch=1;token='o'*48;ca_file=None
        def __init__(self, app):self.app=app
        def dashboard(self):return self.app.dashboard()
        def request(self, target, payload):
            if target == '/api/v1/setup/redo/check':return self.app.check_setup_redo(payload)
            return {'closed':0,'reason':'not a recovery test'}

    def pending_mutations(db):
        return [a.action_type for a in db.pending_actions('local-linux')
                if a.action_type in {'repair_service','restart_service','restore_integrity'}]

    # Inert handles replace only process launch, after the real job file and
    # JobControl admission have been handled by desktop_jobs.launch_job.
    def process_recorder(calls,*,on_job=None):
        def detach(arguments,**kwargs):
            if arguments and arguments[0]=='desktop-worker':
                job_path=Path(arguments[arguments.index('--job')+1])
                calls.append({'job':read_private_json(job_path,65536),'path':str(job_path),
                              'control_admitted':bool(read_private_json(job_path,65536).get('control_epoch'))})
                if on_job:on_job()
            return IdleProcess()
        return detach

    with tempfile.TemporaryDirectory(prefix='sb207-review-') as home,ExitStack() as context:
        h=Path(home);home_env={'HOME':str(h),'XDG_CONFIG_HOME':str(h/'config'),'XDG_DATA_HOME':str(h/'data'),
                            'SENTINEL_LEDGER_DIR':str(h/'default-ledger')}
        context.enter_context(patch.dict(os.environ,home_env))
        runtime_file=Path(args.runtime).resolve() if args.runtime else Path(__file__).resolve()

        def grant_case(automatic=True,emergency=False):
            with tempfile.TemporaryDirectory(dir=h) as tmp:
                r=Path(tmp);path,profile,base,db,app=fixture(r);calls=[]
                try:
                    workspace,record=setup_record(r,runtime_file)
                    grant=app.authorize_change({'agent_id':'local-linux','path':str(path),'ttl_seconds':600})
                    if emergency:app.emergency_stop()
                    path.write_bytes(b'damaged')
                    frames=[]
                    with patch.object(desktop_jobs,'detach',side_effect=process_recorder(calls)):
                        for seq,offset in enumerate((0,1,30,60,90,120,150,181),2):
                            now=clock+offset
                            with patch('time.time',return_value=now):
                                current=damage(base,seq);current['observed_at']=now
                                app.ingest(current);snap=app.dashboard()
                                answer=setup_redo.tick(workspace,snap,now=now,automatic=automatic,client=ReviewClient(app))
                                grants=db.change_grants()
                                frames.append({'seconds':offset,'planner':[x['status'] for x in app.service_recovery_planner.status()],
                                  'controller_mutations':pending_mutations(db),'service_health':snap['service_health'],
                                  'grant_active':any(g['grant_id']==grant['grant_id'] and g['expires_at']>=now and g['revoked_at'] is None for g in grants),
                                  'verdict':answer})
                    return {'frames':frames,'job_count':len(calls),'jobs':calls,
                            'file_unchanged_by_tested_product':path.read_bytes()==b'damaged'}
                finally:db.close()
        measured['change_grant']=grant_case()
        measured['change_grant_approval_control']=grant_case(automatic=False)
        measured['change_grant_emergency_control']=grant_case(emergency=True)

        # Exercise the actual run_session loop: startup has guarded mode,
        # controller policy changes after readiness, the cached boolean remains.
        def session_case(new_mode=None,emergency=False):
            with tempfile.TemporaryDirectory(dir=h) as tmp:
                r=Path(tmp);path,profile,base,db,app=fixture(r);calls=[];dashboard_calls=[]
                old_signals={sig:signal.getsignal(sig) for sig in (signal.SIGTERM,signal.SIGINT)}
                try:
                    workspace,record=setup_record(r,runtime_file)
                    cur=damage(base,2);cur['observed_at']=clock;path.write_bytes(b'damaged');app.ingest(cur)
                    state=setup_redo.load_state(workspace);state['unhealthy_since']={'web.service':clock-181}
                    setup_redo.save_state(workspace,state)
                    config={'directory':str(workspace),'runtime_sha256':sha(runtime_file.read_bytes()),
                       'runtime':str(runtime_file),'event_profile':str(r/'profile.json'),'port':45555,
                       'principal':'review','ca_file':str(r/'ca.pem'),'origin':'https://127.0.0.1:45555',
                       'autonomy':'guarded-autonomous','session_id':'review-session'}
                    session_path=workspace/'session.json';write_private_json(session_path,config)
                    def stop():write_private_json(workspace/'stop-session.json',{'session_id':'review-session'})
                    class Client(ReviewClient):
                        def dashboard(self):
                            if dashboard_calls and new_mode:app.set_autonomy_mode(new_mode)
                            if dashboard_calls and emergency:app.emergency_stop()
                            value=app.dashboard();dashboard_calls.append(copy.deepcopy(value['controller']['governance']))
                            return value

                    monotonic=[0.0];sleeps=[0]
                    def advance():monotonic[0]+=20;return monotonic[0]
                    def sleep(_seconds):
                        sleeps[0]+=1
                        if sleeps[0]>=1:stop()
                    with patch.object(desktop_jobs,'detach',side_effect=process_recorder(calls,on_job=stop)), \
                         patch.object(linux_workspace,'client_for',return_value=Client(app)), \
                         patch('time.time',return_value=clock), \
                         patch.object(linux_workspace,'time',SimpleNamespace(time=lambda:clock,monotonic=advance,sleep=sleep)), \
                         patch.object(sys,'argv',[str(runtime_file)]):
                        result=linux_workspace.run_session(SimpleNamespace(session=str(session_path)))
                    return {'return_code':result,'startup_mode':config['autonomy'],'governance_observed':dashboard_calls,
                            'job_count':len(calls),'jobs':calls,'status':read_private_json(workspace/'session-status.json',4096)}
                finally:
                    for sig,handler in old_signals.items():signal.signal(sig,handler)
                    db.close()
        measured['local_mode_approval']=session_case('approval-based')
        measured['local_mode_observe']=session_case('observe')
        measured['local_mode_guarded_control']=session_case()
        measured['local_mode_emergency_control']=session_case('approval-based',emergency=True)

        def rollback_case(status='failed',dirty=True):
            with tempfile.TemporaryDirectory(dir=h) as tmp:
                r=Path(tmp);workspace,record=setup_record(r,runtime_file);calls=[]
                state=setup_redo.load_state(workspace);state['seen_healthy']=['web.service'];setup_redo.save_state(workspace,state)
                action={'agent_id':'local-linux','action_type':'repair_service','parameters':{'service':'web.service'},
                  'status':status,'created_at':clock-30,'completed_at':clock-10,
                  'result':{'success':False,'rolled_back':not dirty,'review_required':dirty,
                            'message':'modeled failed native repair','errors':['start failed','rollback incomplete'] if dirty else ['start failed']}}
                frames=[]
                with patch.object(desktop_jobs,'detach',side_effect=process_recorder(calls)):
                    for offset in (0,901):
                        snap={'service_health':[{'agent_id':'local-linux','service':'web.service','health':'unhealthy',
                            'native_state':'failed','reason':'','observed_at':clock+offset}],
                            'actions':[copy.deepcopy(action)],'controller':{'governance':{'emergency_stopped':False,'autonomy_mode':'guarded-autonomous'}}}
                        with patch('time.time',return_value=clock+offset):
                            value=setup_redo.tick(workspace,snap,now=clock+offset,
                                launcher=lambda job, directory: desktop_jobs.launch_job(job,directory))
                        frames.append({'seconds':offset,'verdict':value})
                return {'action_unchanged':action,'frames':frames,'job_count':len(calls),'jobs':calls}
        measured['rollback_hold_expires']=rollback_case()
        measured['outcome_unknown_control']=rollback_case(status='outcome_unknown')
        measured['clean_rollback_control']=rollback_case(dirty=False)

        def backup_case(kind='key_missing',long=False):
            with tempfile.TemporaryDirectory(dir=h) as tmp:
                r=Path(tmp);path,profile,base,db,app=fixture(r,auto=False,mode='approval-based');rp=None
                try:
                    rp=RestorePointStore(r/'agent-state',mirror=r/'ledger/restore-mirror')
                    assert rp.capture(base['integrity'])['success']
                    digest=base['integrity'][0]['sha256'];path.write_bytes(b'damaged')
                    if kind=='key_missing':rp._manifest_authority.key_path.unlink()
                    elif kind=='both_metadata_copies_missing':
                        rp._manifest_authority.local.unlink();rp._manifest_authority.remote.unlink()
                    elif kind=='blobs_missing':
                        (rp.blobs/digest).unlink();(rp.mirror/digest).unlink()
                    elif kind=='recoverable':
                        rp.manifest_path.unlink();(rp.blobs/digest).unlink()
                    audit=rp.audit_backups();current=damage(base,2);current['observed_at']=clock
                    merge_health_diagnostics(current,restore_point_issues(audit))
                    app.ingest(current);dash=app.dashboard()
                    offered=[{'kind':a['kind'],'title':a['title'],'action':a['recommended_action']} for a in dash['alerts']
                              if a['kind']=='service_repair_required' and a['status']=='open']
                    security=base['integrity'][0]['security_descriptor_sha256']
                    try:
                        result=rp.restore({'path':str(path),'sha256':digest,'observed_sha256':sha(b'damaged'),
                             'baseline_security_descriptor_sha256':security,'observed_security_descriptor_sha256':security},allowed=True)
                        restore={'success':result['success']}
                    except Exception as exc:restore={'success':False,'exception':type(exc).__name__,'reason':str(exc)}
                    return {'fault':kind,'path':str(path),'path_chars':len(str(path)),'audit':audit,
                            'wire_errors':current['collector_errors'],'wire_sources':current['collector_issue_sources'],
                            'controller_lost_paths':sorted(lost_restore_points(current)),'repair_offers':offered,
                            'restoration':restore,'file_bytes':path.read_text()}
                finally:db.close()
        measured['metadata_key_loss']=backup_case()
        measured['metadata_replica_loss']=backup_case('both_metadata_copies_missing')
        measured['individual_blob_loss_control']=backup_case('blobs_missing')
        measured['metadata_recovery_control']=backup_case('recoverable')
        # Separate long-path case; the complete path is allowed, but only the
        # human-readable diagnostic is sent as machine-readable loss identity.
        def long_backup_case():
            with tempfile.TemporaryDirectory(dir=h) as tmp:
                r=Path(tmp);path,profile,base,db,app=fixture(r,auto=False,long=True,mode='approval-based')
                try:
                    rp=RestorePointStore(r/'state',mirror=r/'ledger/restore-mirror');assert rp.capture(base['integrity'])['success']
                    digest=base['integrity'][0]['sha256'];path.write_bytes(b'damaged')
                    (rp.blobs/digest).unlink();(rp.mirror/digest).unlink()
                    audit=rp.audit_backups();current=damage(base,2);current['observed_at']=clock
                    merge_health_diagnostics(current,restore_point_issues(audit));app.ingest(current)
                    offers=[{'title':a['title'],'action':a['recommended_action']} for a in app.dashboard()['alerts']
                              if a['kind']=='service_repair_required' and a['status']=='open']
                    return {'path':str(path),'path_chars':len(str(path)),'audit':audit,'wire_errors':current['collector_errors'],
                            'controller_lost_paths':sorted(lost_restore_points(current)),'repair_offers':offers}
                finally:db.close()
        measured['long_path_loss']=long_backup_case()

    checks=[
      ('authorized_change_must_hold_redo',measured['change_grant']['job_count']==0,False),
      ('approval_mode_must_stop_automatic_local_redo',measured['local_mode_approval']['job_count']==0,False),
      ('observe_mode_must_stop_automatic_local_redo',measured['local_mode_observe']['job_count']==0,False),
      ('dirty_rollback_hold_must_not_expire',measured['rollback_hold_expires']['job_count']==0,False),
      ('lost_manifest_key_must_not_offer_verified_repair',not measured['metadata_key_loss']['repair_offers'],False),
      ('lost_metadata_copies_must_not_offer_verified_repair',not measured['metadata_replica_loss']['repair_offers'],False),
      ('long_path_loss_must_not_offer_verified_repair',not measured['long_path_loss']['repair_offers'],False),
      ('grant_control_operator_approval_does_not_launch',measured['change_grant_approval_control']['job_count']==0,True),
      ('grant_control_emergency_stop_does_not_launch',measured['change_grant_emergency_control']['job_count']==0,True),
      ('mode_control_guarded_does_launch',measured['local_mode_guarded_control']['job_count']==1,True),
      ('mode_control_emergency_stop_does_not_launch',measured['local_mode_emergency_control']['job_count']==0,True),
      ('unknown_outcome_control_stays_held',measured['outcome_unknown_control']['job_count']==0,True),
      ('clean_rollback_control_is_retryable',measured['clean_rollback_control']['job_count']>=1,True),
      ('short_blob_loss_control_no_verified_repair_offer',not measured['individual_blob_loss_control']['repair_offers'],True),
      ('recoverable_metadata_control_restores_trusted_bytes',measured['metadata_recovery_control']['restoration']['success'] and measured['metadata_recovery_control']['file_bytes']=='trusted',True),
      ('metadata_key_loss_control_fails_closed',not measured['metadata_key_loss']['restoration']['success'] and measured['metadata_key_loss']['file_bytes']=='damaged',True),
    ]
    measured['assertions']=[{'name':n,'passed':bool(v),'control':c} for n,v,c in checks]
    measured['elapsed_seconds']=round(time.monotonic()-start,3)
    dest=Path(args.output);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(json.dumps(measured,indent=2)+'\n')
    print(json.dumps({'application':measured['application'],'assertions':measured['assertions']},indent=2))
    if args.assert_correctness:
        class DesiredBehavior(unittest.TestCase):pass
        for name,value,_control in checks:
            def test(self,ok=value,label=name):self.assertTrue(ok,label)
            setattr(DesiredBehavior,'test_'+name,test)
        result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(DesiredBehavior))
        return 0 if result.wasSuccessful() else 1
    return 0

if __name__=='__main__':raise SystemExit(main())
