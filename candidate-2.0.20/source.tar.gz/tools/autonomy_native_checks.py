"""Run shipped defensive regression tests on the actual guest interpreter."""
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

TEST_FILES = (
    'test_windows_integrity_budget.py', 'test_payload_fingerprint_streaming.py',
    'test_windows_inventory_host.py', 'test_windows_query_batch.py',
    'test_controller_supervisor.py', 'test_recovery_ops.py',
    'test_windows_private.py',
    'test_windows_topology_query.py',
)


def rehearse():
    root = Path(__file__).resolve().parent.parent
    runtime = root/'runtime.pyz'
    runner = r'''
import io,json,sys,unittest
from pathlib import Path
sys.path.insert(0,sys.argv[1])
# Embedded Windows Python deliberately omits the working directory and ignores
# PYTHONPATH. The extracted, allowlisted tests need an explicit import root.
sys.path.insert(0,str(Path.cwd()))
names=json.loads(sys.argv[2])
suite=unittest.defaultTestLoader.loadTestsFromNames(names)
output=io.StringIO()
result=unittest.TextTestRunner(stream=output,verbosity=2).run(suite)
report={'passed':result.wasSuccessful(),'tests_run':result.testsRun,
 'skipped':[{'test':case.id(),'reason':reason} for case,reason in result.skipped],
 'failures':[{'test':case.id(),'detail':detail[-3500:]} for case,detail in result.failures+result.errors]}
Path('result.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report))
raise SystemExit(0 if result.wasSuccessful() else 1)
'''
    with tempfile.TemporaryDirectory(prefix='sentinel-native-checks-', dir=root) as directory:
        stage = Path(directory)
        with zipfile.ZipFile(root/'native-tests.zip') as archive:
            allowed = {'tests/__init__.py', *('tests/'+name for name in TEST_FILES)}
            if set(archive.namelist()) != allowed or len(archive.namelist()) != len(allowed):
                raise ValueError('native test archive differs from its exact defensive allowlist')
            archive.extractall(stage)
        import os
        environment = dict(os.environ, PYTHONPATH=str(runtime))
        result = subprocess.run([sys.executable, '-c', runner, str(runtime),
            json.dumps(['tests.'+Path(name).stem for name in TEST_FILES])],
            cwd=stage, env=environment, capture_output=True, text=True, timeout=180)
        output = stage/'result.json'
        if not output.is_file():
            raise RuntimeError('native regression process did not return a result: '+result.stderr[-500:])
        report = json.loads(output.read_text())
        report['passed'] = report['passed'] and result.returncode == 0
        return report
