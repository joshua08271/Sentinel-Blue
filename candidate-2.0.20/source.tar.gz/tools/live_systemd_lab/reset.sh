#!/bin/sh
# Return the lab to stock Ubuntu service configuration and a fresh ledger.
set -e
cp ${SB_ORIGINALS:?directory holding the stock files}/redis.conf.orig /etc/redis/redis.conf && chown redis:redis /etc/redis/redis.conf && chmod 640 /etc/redis/redis.conf
rm -f /etc/redis/sentinel.conf
cp ${SB_ORIGINALS:?directory holding the stock files}/pg_hba.conf.orig /etc/postgresql/16/main/pg_hba.conf; chown postgres:postgres /etc/postgresql/16/main/pg_hba.conf; chmod 640 /etc/postgresql/16/main/pg_hba.conf
cp ${SB_ORIGINALS:?directory holding the stock files}/postgresql.conf.orig /etc/postgresql/16/main/postgresql.conf; chown postgres:postgres /etc/postgresql/16/main/postgresql.conf; chmod 644 /etc/postgresql/16/main/postgresql.conf
rm -f /etc/postgresql/16/main/sentinel-pg-hba.conf /etc/postgresql/16/main/conf.d/60-sentinel.conf
printf '{"port": 18081, "body": "sentinel-ok"}' > /etc/sbweb/sbweb.json
printf '{"host": "0.0.0.0", "port": 18082, "body": "sentinel-two"}' > /etc/sbweb2/sbweb2.json
if [ -e /etc/systemd/system/sentinel-gunicorn.service ]; then systemctl disable --now sentinel-gunicorn.service || true; rm -f /etc/systemd/system/sentinel-gunicorn.service; systemctl daemon-reload; systemctl reset-failed sentinel-gunicorn.service 2>/dev/null || true; fi
systemctl restart redis-server postgresql sbweb sbweb2
[ -d /var/lib/sentinel-blue-ledger ] && mv /var/lib/sentinel-blue-ledger /var/lib/sentinel-blue-ledger.lab-$(date +%s)
sleep 2
systemctl is-active redis-server postgresql postgresql@16-main sbweb sbweb2 | tr '\n' ' '; echo
