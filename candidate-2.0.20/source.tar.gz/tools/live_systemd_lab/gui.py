"""Drive the real desktop window, attached to the running lab session."""
import json, os, subprocess, sys, time
PYZ = os.environ['SB_PYZ']
sys.argv[0] = PYZ; sys.path.insert(0, PYZ)
import tkinter as tk
from pathlib import Path
from unittest.mock import patch
from sentinel_blue.desktop import DesktopWindow
from sentinel_blue.state import write_private_json
SHOTS = Path(os.environ.get('SB_SHOTS', '/var/tmp/sentinel-live-lab/shots'))

desktop = Path(os.environ.get('SB_ROOT', '/var/tmp/sentinel-live-lab')) / 'desktop'
session = sorted((desktop / 'sessions').glob('local-*/session.json'))[-1]
write_private_json(desktop / 'last-local-session.json', {'path': str(session)})
root = tk.Tk(); root.geometry('1560x960+0+0')
w = DesktopWindow(root, directory=desktop)

def pump(seconds):
    end = time.time() + seconds
    while time.time() < end:
        root.update(); time.sleep(0.05)

def shot(name):
    pump(0.5)
    print(subprocess.run([os.environ.get('SB_SHOT_PYTHON', '/usr/bin/python3'), str(Path(__file__).with_name('xshot.py')), os.environ.get('DISPLAY', ':0'), str(SHOTS / f'{name}.png')], capture_output=True, text=True).stdout.strip())

SHOTS.mkdir(parents=True, exist_ok=True)
pump(2)
w.reconnect_local(); pump(8)
print('connected:', w.client is not None, '|', w.local_status.get())
shot('1-services')
rows = [w.services.item(i, 'values') for i in w.services.get_children()]
for row in rows: print('services row:', row)
w.notebook.select(w.tabs['Alerts & verification']); pump(2); shot('2-alerts')
w.notebook.select(w.tabs['Recovery']); pump(3)
w.reconcile_setup(); pump(6)
print('after reconcile:', w.footer.get())
print('recovery text:', w.recovery_text.get('1.0', 'end').strip()[:400])
shot('3-recovery-reconcile')
with patch.object(w.messagebox, 'askyesno', return_value=True):
    w.redo_local_setup(); pump(4)
print('after redo request:', w.footer.get())
shot('4-recovery-redo')
pump(3)
w.worker_stop.set()
root.destroy()
