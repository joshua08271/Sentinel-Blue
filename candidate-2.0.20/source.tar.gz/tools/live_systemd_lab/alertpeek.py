import sys, json, os
sys.argv[0] = os.environ['SB_PYZ']; sys.path.insert(0, sys.argv[0])
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import e2e
config, c = e2e.client()
snap = c.dashboard()
kinds = sys.argv[1].split(',') if len(sys.argv) > 1 else None
for a in snap.get('alerts', []):
    if kinds is None or a['kind'] in kinds:
        ev = {k: v for k, v in (a.get('evidence') or {}).items() if not k.startswith('_')}
        print(a['status'], a.get('decision'), a['kind'], a.get('severity'), a.get('title'), json.dumps(ev)[:300])
