"""Live end-to-end run of the guided local flow against a real systemd (2.0.6).

Runs inside the namespaced systemd (nsenter). Uses the product's own functions
in the order the desktop calls them; only the button presses are scripted.
"""
import copy, hashlib, json, os, secrets, subprocess, sys, time
from pathlib import Path

PYZ = os.environ['SB_PYZ']
sys.argv[0] = PYZ
sys.path.insert(0, PYZ)
ROOT = Path(os.environ.get('SB_ROOT', '/var/tmp/sentinel-live-lab'))
STATE = ROOT / 'e2e-state.json'
CONF = Path('/etc/sbweb/sbweb.json')
UNIT = Path('/etc/systemd/system/sbweb.service')
GOOD = {'port': 18081, 'body': 'sentinel-ok'}

def log(*a):
    print(time.strftime('%H:%M:%S'), *a, flush=True)

def sh(*argv, check=False):
    r = subprocess.run(argv, capture_output=True, text=True)
    if check and r.returncode:
        raise RuntimeError(f'{argv}: {r.stderr}')
    return r

OWN = os.environ.get('SB_OWN', '192.0.2.2')
CONF2 = Path('/etc/sbweb2/sbweb2.json')
UNIT2 = Path('/etc/systemd/system/sbweb2.service')
GOOD2 = {'host': '0.0.0.0', 'port': 18082, 'body': 'sentinel-two'}

def install_test_service():
    Path('/usr/local/bin/sbweb.py').write_text('''import json, sys, http.server
cfg = json.load(open(sys.argv[1] if len(sys.argv) > 1 else "/etc/sbweb/sbweb.json"))
body = cfg["body"].encode()
class H(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
    def log_message(self, *a): pass
http.server.HTTPServer((cfg.get("host", "127.0.0.1"), int(cfg["port"])), H).serve_forever()
''')
    for conf, unit, good, label in ((CONF, UNIT, GOOD, 'scoreboard'), (CONF2, UNIT2, GOOD2, 'public page')):
        conf.parent.mkdir(parents=True, exist_ok=True)
        conf.write_text(json.dumps(good))
        unit.write_text(f'[Unit]\nDescription=Sentinel live-test {label}\n\n[Service]\n'
                        f'ExecStart=/usr/bin/python3 /usr/local/bin/sbweb.py {conf}\n\n[Install]\nWantedBy=multi-user.target\n')
    sh('systemctl', 'daemon-reload', check=True)
    sh('systemctl', 'enable', '--now', 'sbweb.service', 'sbweb2.service', check=True)
    sh('systemctl', 'restart', 'sbweb.service', 'sbweb2.service', check=True)

def save(**values):
    data = json.loads(STATE.read_text()) if STATE.exists() else {}
    data.update(values)
    STATE.write_text(json.dumps(data, indent=2))
    return data

def load():
    return json.loads(STATE.read_text())

def client():
    from sentinel_blue.linux_workspace import client_for
    from sentinel_blue.state import read_private_json
    config = read_private_json(load()['session'], 2 * 1024 * 1024)
    return config, client_for(config)

def summary(snapshot, services=('sbweb.service', 'sbweb2.service', 'redis-server.service', 'postgresql.service', 'sentinel-gunicorn.service')):
    rows = {r['service']: r for r in snapshot.get('service_health', [])}
    out = []
    for name in services:
        r = rows.get(name, {})
        out.append(f"{name}={r.get('health')}/{r.get('native_state')}")
    status = {x['service']: x['status'] for x in snapshot.get('controller', {}).get('service_recovery_status', [])}
    out.append('recovery=' + json.dumps({k: status.get(k) for k in services}))
    return ' '.join(out)

def actions(snapshot, since=0):
    rows = []
    for a in snapshot.get('actions', []):
        if a.get('created_at', 0) >= since:
            res = a.get('result') or {}
            rows.append((a['created_at'], a['action_type'], (a.get('parameters') or {}).get('service'), a['status'],
                         str(res.get('message', ''))[:160], res.get('rolled_back')))
    return sorted(rows)

def setup(autonomy, pack=False):
    from sentinel_blue.linux_workspace import prepare_workspace, local_observation, require_available_local_ports, activate_reviewed_session, client_for
    from sentinel_blue.desktop_jobs import detach, launch_job
    from sentinel_blue.setup import plan_digest
    from sentinel_blue.state import read_private_json
    from sentinel_blue.linux_service_forms import snapshot_file
    from sentinel_blue import setup_redo
    install_test_service()
    observed = local_observation()
    log('presence redis:', observed['presence'].get('redis'), 'own addresses:', observed['addresses'],
        'listener inventory complete:', observed['observation']['complete'])
    custom = [{'unit': 'sbweb.service', 'label': 'Live-test scoreboard', 'files': [str(CONF)],
               'check': {'kind': 'http', 'target': 'http://127.0.0.1:18081/', 'timeout': 5,
                         'expected_status': [200], 'expected_body': 'sentinel-ok'}},
              {'unit': 'sbweb2.service', 'label': 'Live-test public page', 'files': [str(CONF2)],
               'check': {'kind': 'http', 'target': f'http://{OWN}:18082/', 'timeout': 5,
                         'expected_status': [200], 'expected_body': 'sentinel-two'}}]
    desktop = ROOT / 'desktop'
    desktop.mkdir(mode=0o700, parents=True, exist_ok=True); desktop.chmod(0o700)
    options = {}
    if pack:
        forms = desktop / 'forms'
        forms.mkdir(parents=True, exist_ok=True)
        options = {'redis': {'bind_address': '127.0.0.1', 'protected_mode': True,
                             'previous_files': {'/etc/redis/sentinel.conf': 'absent'},
                             'activation': {'/etc/redis/redis.conf': snapshot_file('/etc/redis/redis.conf', forms)}}}
    selection = [x for x in os.environ.get('SB_SELECT', 'redis').split(',') if x]
    if os.environ.get('SB_PACK_POSTGRES'):
        forms = desktop / 'forms'
        forms.mkdir(parents=True, exist_ok=True)
        base = '/etc/postgresql/16/main'
        options['postgresql'] = {'config_directory': base, 'listen_addresses': ['127.0.0.1'],
                                 'allowed_networks': ['127.0.0.0/8'],
                                 'previous_files': {base + '/conf.d/60-sentinel.conf': 'absent',
                                                    base + '/sentinel-pg-hba.conf': 'absent'},
                                 'activation': {base + '/postgresql.conf': snapshot_file(base + '/postgresql.conf', forms),
                                                base + '/pg_hba.conf': snapshot_file(base + '/pg_hba.conf', forms)}}
    if os.environ.get('SB_PACK_GUNICORN'):
        options['gunicorn'] = {'application': 'app:application', 'working_directory': '/srv/sbapp', 'user': 'www-data',
                               'bind_address': '127.0.0.1', 'port': 18090, 'workers': 1,
                               'previous_files': {'/etc/systemd/system/sentinel-gunicorn.service': 'absent'}}
    config, plan = prepare_workspace(desktop / 'sessions', Path(PYZ), selection, options, observed['presence'], {},
                                     autonomy, observed['observation'], custom,
                                     local_addresses=observed['addresses'])
    log('plan recipes', [(t['id'], t['recipe']) for t in plan['tasks']])
    directory = Path(config['directory'])
    save(session=str(directory / 'session.json'), autonomy=autonomy, desktop=str(desktop))
    log('workspace', directory)
    log('repair coverage', json.dumps(config['repair_coverage']))
    require_available_local_ports(config)
    detach(['linux-desktop-session', '--session', str(directory / 'session.json')])
    deadline = time.monotonic() + 60
    while True:
        try:
            status = read_private_json(directory / 'session-status.json', 4096)
        except (OSError, ValueError):
            status = {}
        if status.get('state') == 'running':
            break
        if status.get('state') == 'failed' or time.monotonic() > deadline:
            raise RuntimeError('session did not start: ' + json.dumps(status))
        time.sleep(.3)
    c = client_for(config)
    c.dashboard()
    activate_reviewed_session(config, c, lambda: None)
    log('session running and activated')
    job = {'inventory': config['inventory'], 'event_profile': config['event_profile'], 'runtime': PYZ,
           'kind': 'setup', 'range_deployment': True, 'approved_digest': plan_digest(plan)}
    _p, job_path = launch_job(job, desktop / ('job-' + secrets.token_hex(8)))
    setup_redo.record_approved_setup(directory, job, job_root=desktop, job_path=job_path)
    save(job=str(job_path))
    result = job_path.parent / 'result.json'
    deadline = time.monotonic() + 300
    while not result.exists():
        if time.monotonic() > deadline:
            raise RuntimeError('setup job did not finish')
        time.sleep(1)
    report = json.loads(result.read_text())
    log('setup', report.get('status'), json.dumps({k: v.get('status') for k, v in report.get('tasks', {}).items()}),
        report.get('reason', ''))

def approve_baseline():
    from sentinel_blue.desktop_control import verification_rows
    config, c = client()
    deadline = time.monotonic() + 180
    while time.monotonic() < deadline:
        snap = c.dashboard()
        rows = [r for r in verification_rows(snap) if r['kind'] == 'baseline' and r['id'] == 'local-linux']
        host = next((h for h in snap.get('agents', []) if h.get('agent_id') == 'local-linux'), {})
        if rows and host.get('baseline_readiness', {}).get('ready', True) is not False:
            try:
                log('approve baseline ->', c.decide(rows[0], 'approve'))
                break
            except Exception as exc:
                log('baseline held:', str(exc)[:200])
        time.sleep(3)
    else:
        raise RuntimeError('baseline was never ready: ' + json.dumps(host.get('baseline_readiness'))[:400])
    deadline = time.monotonic() + 120
    while time.monotonic() < deadline:
        snap = c.dashboard()
        captures = [a for a in actions(snap) if a[1] == 'capture_restore_point']
        host = next((h for h in snap.get('agents', []) if h.get('agent_id') == 'local-linux'), {})
        if host.get('baseline_status') == 'approved' and captures and all(x[3] == 'completed' for x in captures):
            log('baseline approved; restore points', [x[3] for x in captures])
            return
        time.sleep(2)
    raise RuntimeError('restore points not captured: ' + json.dumps(actions(snap)))

def watch(seconds, until=None):
    config, c = client()
    start = time.time()
    seen = set()
    while time.time() - start < seconds:
        try:
            snap = c.dashboard()
        except Exception as exc:
            log('dashboard error', exc); time.sleep(2); continue
        for row in actions(snap, start - 5):
            key = (row[0], row[3])
            if key not in seen:
                seen.add(key); log('action', row[1], row[2], row[3], row[4], 'rolled_back=' + str(row[5]))
        for a in snap.get('alerts', []):
            key = ('alert', a['alert_id'], a['status'])
            if a.get('created_at', 0) >= start - 5 and key not in seen:
                seen.add(key); log('alert', a['kind'], a.get('status'), a.get('recommended_action'), a.get('title', '')[:100])
        if until is not None and until(snap):
            log('condition met after', round(time.time() - start, 1), 's;', summary(snap))
            return snap
        time.sleep(2)
    log('timed out;', summary(snap))
    return snap

def healthy(name):
    """Seen unhealthy first, then healthy again: the recovery, not a stale sample."""
    seen = {'bad': False}
    def check(s):
        rows = [r for r in s.get('service_health', []) if r['service'] == name]
        if rows and rows[0]['health'] == 'unhealthy':
            seen['bad'] = True
        return seen['bad'] and bool(rows) and rows[0]['health'] == 'healthy'
    return check

if __name__ == '__main__':
    step = sys.argv[1]
    if step == 'setup':
        setup(sys.argv[2], pack='pack' in sys.argv[3:]); approve_baseline()
    elif step == 'status':
        config, c = client(); snap = c.dashboard(); log(summary(snap))
        for row in actions(snap)[-12:]: log(row)
    elif step == 'watch':
        watch(float(sys.argv[2]), healthy(sys.argv[3]) if len(sys.argv) > 3 else None)

def approve_repair(unit, seconds=180):
    from sentinel_blue.desktop_control import verification_rows
    config, c = client()
    start = time.time()
    while time.time() - start < seconds:
        snap = c.dashboard()
        auto = [a for a in actions(snap, start - 5) if a[1] in ('repair_service', 'restart_service')]
        if auto:
            log('UNEXPECTED action before approval:', auto)
        rows = [r for r in verification_rows(snap) if r['kind'] == 'alert'
                and r['detail'].get('kind') == 'service_repair_required' and unit in json.dumps(r['detail'])]
        if rows:
            log('offered:', rows[0]['title'], 'choices', rows[0]['choices'])
            log('approve ->', c.decide(rows[0], 'approve'))
            return
        time.sleep(2)
    raise RuntimeError('no repair was offered')

if __name__ == '__main__' and sys.argv[1] == 'approve-repair':
    approve_repair(sys.argv[2])


def open_alerts(snapshot):
    return [a for a in snapshot.get('alerts', []) if a.get('status') == 'open']

if __name__ == '__main__' and sys.argv[1] == 'alerts':
    config, c = client(); snap = c.dashboard()
    for a in open_alerts(snap):
        log('open', a['kind'], a.get('title', '')[:80], json.dumps(a.get('evidence', {}))[:120])
    decided = [a for a in snap.get('alerts', []) if a.get('decision') == 'resolved_by_repair']
    log('resolved_by_repair:', len(decided), sorted({a['kind'] for a in decided}))
