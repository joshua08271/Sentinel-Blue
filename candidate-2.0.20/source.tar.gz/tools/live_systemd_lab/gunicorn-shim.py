#!/usr/bin/python3
# Lab stand-in for gunicorn (PyPI is unreachable here): same command line,
# serves the named WSGI application with wsgiref.
import argparse, importlib, os, sys
from wsgiref.simple_server import make_server, WSGIRequestHandler
class Quiet(WSGIRequestHandler):
    def log_message(self, *a): pass
p = argparse.ArgumentParser(); p.add_argument('--workers'); p.add_argument('--bind', required=True); p.add_argument('app')
a = p.parse_args()
host, port = a.bind.rsplit(':', 1)
sys.path.insert(0, os.getcwd())
module, _, name = a.app.partition(':')
make_server(host, int(port), getattr(importlib.import_module(module), name or 'application'), handler_class=Quiet).serve_forever()
