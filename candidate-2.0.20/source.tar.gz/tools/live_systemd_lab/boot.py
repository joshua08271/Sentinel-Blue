"""Controller boot registration against the lab session's own controller files.

Stop the lab session first (its controller uses the same port and database):
  boot.py install | status | uninstall
then `systemctl start|stop sentinel-blue-controller` between the steps.
"""
import json, os, sys
sys.argv[0] = os.environ['SB_PYZ']; sys.path.insert(0, sys.argv[0])
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pathlib import Path
import e2e
from sentinel_blue.state import read_private_json
from sentinel_blue import controller_boot

session = Path(e2e.load()['session']).parent
config = read_private_json(session / 'session.json', 2 * 1024 * 1024)
S = session
args = (f"--bind 127.0.0.1 --port {config['port']} --token-file {S}/master.json --operator-token-file {S}/operator.txt "
        f"--operator-principal-id desktop-operator --database {S}/controller.db --recovery-anchor {S}/recovery.anchor "
        f"--recovery-key-file {S}/recovery.key --tls-cert {S}/controller.crt --tls-ca-file {S}/controller.crt "
        f"--tls-key {S}/controller.key --maintenance-interval 5 --event-profile {S}/profile.json --range-deployment").split()
if config.get('autonomy') == 'guarded-autonomous':
    args.append('--auto-recover-services')
boot = S / 'boot'
boot.mkdir(mode=0o700, exist_ok=True); boot.chmod(0o700)
path = boot / 'controller.json'
if not path.exists():
    path.write_text(json.dumps({'controller_arguments': args})); path.chmod(0o600)
step = sys.argv[1]
if step == 'install':
    print(json.dumps(controller_boot.install(str(path), Path(os.environ['SB_PYZ'])), indent=1))
elif step == 'status':
    print(json.dumps(controller_boot.status(), indent=1))
elif step == 'uninstall':
    print(json.dumps(controller_boot.uninstall(), indent=1))
