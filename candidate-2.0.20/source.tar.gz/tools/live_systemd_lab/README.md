# Live systemd lab

Runs the guided local flow against a **real systemd** and lets you break
services the way an attacker would. This is how the 2.0.4, 2.0.5 and 2.0.6 fixes were
found; see `docs/LINUX_HOTFIX_2.0.4.md`, `docs/LINUX_HOTFIX_2.0.5.md` and
`docs/LINUX_HOTFIX_2.0.6.md`.

It creates two test units — `sbweb.service` (checked on 127.0.0.1) and
`sbweb2.service` (listening on every address, checked on this VM's own address,
`SB_OWN`) — sets up `redis-server.service` if installed (adopted, or configured
by its pack with `setup … pack`), and drives the
product's own functions: prepare the workspace, start the session, run the
approved setup, approve the baseline, then watch what Sentinel does.

**Use a disposable lab VM.** It writes `/etc/sbweb`, `/etc/sbweb2`,
`/usr/local/bin/sbweb.py` and their units, and changes services as root. The
Redis pack needs `/etc/redis` root-owned (Ubuntu ships it `redis:redis`, which
setup refuses to write under; see the 2.0.5 notes).

## On a lab VM (systemd is PID 1)

```sh
APP=~/.local/share/sentinel-blue/linux-gui1-*        # where the .run unpacked itself
export SB_PYZ=$(echo $APP)/sentinel-blue.pyz SB_OWN=192.0.2.2   # SB_OWN: this VM's address
PY=$(echo $APP)/runtime/bin/python3                  # the bundled Python, with Tk and cryptography
sudo -E $PY tools/live_systemd_lab/e2e.py setup guarded-autonomous        # add "pack" to configure Redis
sudo sh -c 'echo "{broken" > /etc/sbweb/sbweb.json; systemctl restart sbweb'
sudo -E $PY tools/live_systemd_lab/e2e.py watch 240 sbweb.service
```

Steps: `setup <approval-based|guarded-autonomous> [pack]`, `status`,
`watch <seconds> [unit]` (waits for the unit to go unhealthy and come back),
`approve-repair <unit>` (approval-based mode: approve the offered repair),
`alerts` (open alerts, and how many a repair or redo closed).

2.0.6 additions:

* `SB_SELECT=redis,postgresql` chooses the catalogued services; `SB_PACK_POSTGRES=1`
  configures PostgreSQL 16 by its pack (both parent files activated; its
  folders must be root-owned, like `/etc/redis`); `SB_PACK_GUNICORN=1` adds the
  gunicorn pack, which creates a new unit. Without gunicorn installed,
  `gunicorn-shim.py` (copied to `/usr/bin/gunicorn`) serves the same command line
  with `wsgiref`, for the pack's unit and repair only.
* `redo.py` prints the setup-redo status; `redo.py press` does what the Recovery
  tab's **Redo approved setup** button does and waits for it.
* `allhealthy.py <seconds> <unit,unit,…>` waits until every named unit went
  unhealthy and came back (a red-team batch across several services).
* `alertpeek.py [kind,kind]` prints alerts with their decisions.
* `boot.py install|status|uninstall` registers the lab session's controller to
  start at boot (stop the session first), for `systemctl start/stop` tests.
* `reset.sh` (with `SB_ORIGINALS` holding stock copies named `redis.conf.orig`, `pg_hba.conf.orig`
  and `postgresql.conf.orig`) returns the lab to stock configuration and moves the
  ledger aside, between runs.

`batchwatch.py [seconds]` watches every service through a red-team batch (break
several at once, then run it). `gui.py` opens the real desktop window attached to
the running lab session (needs `DISPLAY`; the lab's `desktop` folder must be
0700), presses Reconcile and Redo on the Recovery tab, and saves screenshots with
`xshot.py` (Pillow, via `SB_SHOT_PYTHON`, default `/usr/bin/python3`).

## On a machine without systemd as PID 1 (a build sandbox)

`boot-systemd.sh` boots the installed systemd as PID 1 of a private PID and
mount namespace with its own `/run`, `/tmp` and `/var/tmp`. **Never run it on a
real VM.** The private `/tmp` matters: systemd's boot-time cleanup empties
`/tmp`. Run everything inside it with `nsenter -t <pid> -m -p --`.

`shims/ip` and `shims/ss` stand in for iproute2 on a machine that lacks it,
reading the same kernel state from `/proc` and `ioctl`. Put them first on `PATH`
only there; a real VM has the real tools.
