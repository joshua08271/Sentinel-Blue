import sys, os, time
sys.argv[0] = os.environ['SB_PYZ']; sys.path.insert(0, sys.argv[0])
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import e2e
names = sys.argv[2].split(',')
seen_bad = set()
def done(s):
    rows = {r['service']: r['health'] for r in s.get('service_health', [])}
    seen_bad.update(n for n in names if rows.get(n) != 'healthy')
    return seen_bad >= set(names) and all(rows.get(n) == 'healthy' for n in names)
e2e.watch(float(sys.argv[1]), done)
