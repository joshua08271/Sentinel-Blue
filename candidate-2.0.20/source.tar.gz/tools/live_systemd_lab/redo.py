import sys, json, os, time
sys.argv[0] = os.environ['SB_PYZ']; sys.path.insert(0, sys.argv[0])
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import e2e
from pathlib import Path
from sentinel_blue import setup_redo
config, c = e2e.client()
workspace = Path(config['directory'])
snap = c.dashboard()
print(setup_redo.status_text(workspace, snap))
if len(sys.argv) > 1 and sys.argv[1] == 'press':
    # What the Recovery tab's "Redo approved setup" button does after its confirmation.
    print(json.dumps(setup_redo.manual_redo(workspace, snap))[:600])
    deadline = time.time() + 300
    while time.time() < deadline:
        time.sleep(5)
        snap = c.dashboard()
        out = setup_redo.tick(workspace, snap, automatic=False,
                              close_incident=lambda agent, service: c.request(f'/api/v1/agents/{agent}/services/recovered', {'service': service, 'source': 'setup_redo'}))
        state = setup_redo.load_state(workspace)
        if not state.get('running'):
            print('finished', json.dumps(out)[:600]); break
    print(setup_redo.status_text(workspace, snap))
