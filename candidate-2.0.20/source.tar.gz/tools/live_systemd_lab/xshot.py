"""Save a PNG of an X display's root window (read-only), via libX11 + Pillow."""
import ctypes
import ctypes.util
import sys

from PIL import Image

x11 = ctypes.CDLL(ctypes.util.find_library("X11") or "libX11.so.6")
x11.XOpenDisplay.restype = ctypes.c_void_p
x11.XOpenDisplay.argtypes = [ctypes.c_char_p]
x11.XDefaultRootWindow.restype = ctypes.c_ulong
x11.XDefaultRootWindow.argtypes = [ctypes.c_void_p]
x11.XDefaultScreen.argtypes = [ctypes.c_void_p]
x11.XDisplayWidth.argtypes = [ctypes.c_void_p, ctypes.c_int]
x11.XDisplayHeight.argtypes = [ctypes.c_void_p, ctypes.c_int]
x11.XGetImage.restype = ctypes.c_void_p
x11.XGetImage.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.c_int, ctypes.c_int,
                          ctypes.c_uint, ctypes.c_uint, ctypes.c_ulong, ctypes.c_int]


class XImage(ctypes.Structure):
    _fields_ = [("width", ctypes.c_int), ("height", ctypes.c_int), ("xoffset", ctypes.c_int),
                ("format", ctypes.c_int), ("data", ctypes.POINTER(ctypes.c_char)),
                ("byte_order", ctypes.c_int), ("bitmap_unit", ctypes.c_int),
                ("bitmap_bit_order", ctypes.c_int), ("bitmap_pad", ctypes.c_int),
                ("depth", ctypes.c_int), ("bytes_per_line", ctypes.c_int),
                ("bits_per_pixel", ctypes.c_int)]


display = x11.XOpenDisplay(sys.argv[1].encode())
screen = x11.XDefaultScreen(display)
width, height = x11.XDisplayWidth(display, screen), x11.XDisplayHeight(display, screen)
crop = tuple(int(v) for v in sys.argv[3].split(",")) if len(sys.argv) > 3 else (0, 0, width, height)
ZPIXMAP, ALL_PLANES = 2, 0xFFFFFFFF
pointer = x11.XGetImage(display, x11.XDefaultRootWindow(display), 0, 0, width, height, ALL_PLANES, ZPIXMAP)
image = ctypes.cast(pointer, ctypes.POINTER(XImage)).contents
raw = ctypes.string_at(image.data, image.bytes_per_line * image.height)
picture = Image.frombuffer("RGBA", (image.bytes_per_line // 4, image.height), raw, "raw", "BGRA", 0, 1)
picture = picture.convert("RGB").crop(crop)
picture.save(sys.argv[2])
colours = picture.getcolors(maxcolors=1 << 20) or []
print(f"saved {sys.argv[2]} {picture.size[0]}x{picture.size[1]}, {len(colours)} distinct colours")
