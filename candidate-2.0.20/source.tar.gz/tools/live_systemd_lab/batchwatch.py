"""Watch several services recover at once (red-team batch); see README."""
import sys, time, json
import os
sys.argv[0] = os.environ['SB_PYZ']; sys.path.insert(0, sys.argv[0]); sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import e2e
config, c = e2e.client()
start = time.time(); seen = set(); first_bad = {}; healed = {}
limit = float(sys.argv[1]) if len(sys.argv) > 1 else 420
while time.time() - start < limit:
    try:
        snap = c.dashboard()
    except Exception as exc:
        e2e.log('dashboard error', exc); time.sleep(3); continue
    for row in e2e.actions(snap, start - 5):
        key = (row[0], row[3])
        if key not in seen:
            seen.add(key); e2e.log('action', row[1], row[2], row[3], row[4][:160])
    health = {r['service']: r['health'] for r in snap.get('service_health', [])}
    for unit, h in health.items():
        if h != 'healthy':
            first_bad.setdefault(unit, round(time.time() - start))
        elif unit in first_bad and unit not in healed:
            healed[unit] = round(time.time() - start); e2e.log('healthy again', unit, healed[unit], 's')
    if first_bad and set(healed) == set(first_bad) and all(v == 'healthy' for v in health.values()) and time.time() - start > 30:
        e2e.log('all healthy', healed); break
    time.sleep(3)
else:
    st = {x['service']: x['status'] for x in snap.get('controller', {}).get('service_recovery_status', [])}
    e2e.log('timed out', health, healed, json.dumps(st)[:600])
