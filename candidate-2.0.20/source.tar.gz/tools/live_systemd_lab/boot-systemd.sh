#!/bin/sh
# Boot a real systemd as PID 1 of a private PID + mount namespace, with its
# own /run, /tmp and /var/tmp so boot-time tmpfiles cleanup cannot touch the
# host's /tmp. Network namespace is shared (loopback checks work from both).
exec unshare --pid --fork --mount --propagation private --mount-proc sh -c '
  mount -t tmpfs tmpfs /run && mkdir -p /run/lock &&
  mount -t tmpfs tmpfs /tmp && chmod 1777 /tmp &&
  mount -t tmpfs tmpfs /var/tmp && chmod 1777 /var/tmp &&
  exec env container=other /lib/systemd/systemd --system --unit=basic.target --log-target=console --log-level=notice'
