"""Which listeners can a client reach through the router adapter's firewall?

    sudo unshare -n python3 tools/firewall_reachability.py .
    sudo unshare -n python3 tools/firewall_reachability.py . with-ipv6-allow

Run it only inside `unshare -n`: that gives it a private network namespace with
nothing but a loopback interface, so no firewall, route or listener on the host
is read or changed, and everything it creates disappears when it exits. It
refuses to run outside one.

Two ordinary dual-stack TCP services listen on `::` — the way sshd, nginx and
most daemons listen by default — and a plain client connects to each over IPv4
and IPv6. Port 8080 is not allowed; port 8081 is allowed from 127.0.0.0/8, and
with `with-ipv6-allow` also from ::1/128.

One change is made to the generated ruleset for this test and only this one: the
`iifname "lo" accept` line is removed, so loopback traffic is filtered the way
traffic from another machine would be. Every other line is the adapter's output.

Expected with 2.0.2: 8080 blocked on both families; 8081 reachable over IPv4,
and over IPv6 only when the IPv6 allow rule is present. 2.0.1 left 8080 and 8081
reachable over IPv6 in every case.
"""
import fcntl
import json
import socket
import struct
import subprocess
import sys

SRC = sys.argv[1]
sys.path.insert(0, SRC + "/src")
from sentinel_blue.network_setup import normalize, ruleset  # noqa: E402

BLOCKED_PORT, ALLOWED_PORT = 8080, 8081
OPTIONS = {
    "name": "probe", "input_policy": "drop", "forwarding": False,
    "management": [{"source": "127.0.0.0/8", "port": 22}],
    "allow": [{"source": "127.0.0.0/8", "protocol": "tcp", "port": ALLOWED_PORT}],
}
# An IPv6 allow rule exists only from 2.0.2; the older adapter refuses it.
if len(sys.argv) > 2 and sys.argv[2] == "with-ipv6-allow":
    OPTIONS["allow"].append({"source": "::1/128", "protocol": "tcp", "port": ALLOWED_PORT})


def private_namespace():
    """True when this process cannot see the host's interfaces."""
    with open('/proc/net/dev') as handle:
        devices = [line.split(':')[0].strip() for line in handle.readlines()[2:]]
    return devices == ['lo']


if not private_namespace():
    raise SystemExit('Run this inside `unshare -n`: it loads a firewall table and must not touch the host.')


def loopback_up():
    SIOCGIFFLAGS, SIOCSIFFLAGS, IFF_UP = 0x8913, 0x8914, 0x1
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        request = struct.pack("16sH14s", b"lo", 0, b"\0" * 14)
        flags = struct.unpack("16sH14s", fcntl.ioctl(s, SIOCGIFFLAGS, request))[1]
        fcntl.ioctl(s, SIOCSIFFLAGS, struct.pack("16sH14s", b"lo", flags | IFF_UP, b"\0" * 14))


def ipv6_available():
    try:
        socket.socket(socket.AF_INET6, socket.SOCK_STREAM).close()
        return True
    except OSError:
        return False


IPV6 = ipv6_available()


def listen(port):
    """Dual-stack where the kernel has IPv6; IPv4 only where it was disabled at boot."""
    family = socket.AF_INET6 if IPV6 else socket.AF_INET
    server = socket.socket(family, socket.SOCK_STREAM)
    if IPV6:
        server.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("::" if IPV6 else "0.0.0.0", port))
    server.listen(8)
    return server


def reach(address, port):
    try:
        with socket.create_connection((address, port), timeout=1.5):
            return "reachable"
    except socket.timeout:
        return "blocked"
    except ConnectionRefusedError:
        return "refused"
    except OSError as exc:
        return f"error: {exc.strerror}"


loopback_up()
servers = [listen(BLOCKED_PORT), listen(ALLOWED_PORT)]
text = ruleset(normalize(OPTIONS)).replace('  iifname "lo" accept\n', "")
subprocess.run(["nft", "-f", "-"], input=text, text=True, check=True)
families = (("IPv4", "127.0.0.1"), ("IPv6", "::1")) if IPV6 else (("IPv4", "127.0.0.1"),)
result = {f"{label} port {port}": reach(address, port)
          for port in (BLOCKED_PORT, ALLOWED_PORT) for label, address in families}
if not IPV6:
    result["IPv6"] = "not testable: this kernel was booted with ipv6.disable=1"
print(json.dumps(result))
