from pathlib import Path
w=Path('/mnt/data/sentinel_208_work')
s=(w/'review/harness/reproduce_207_review.py').read_text()
s=s.replace("        return path,profile,baseline,db,app", "        write_private_json(root/'profile.json', profile.raw)\n        return path,profile,baseline,db,app")
s=s.replace("    def pending_mutations(db):",'''    class ReviewClient:
        # Connection fields are inert fixture credentials. The original test
        # already replaces daemon launch; policy still calls the real controller.
        origin='http://127.0.0.1:45555';principal='operator';epoch=1;token='o'*48;ca_file=None
        def __init__(self, app):self.app=app
        def dashboard(self):return self.app.dashboard()
        def request(self, target, payload):
            if target == '/api/v1/setup/redo/check':return self.app.check_setup_redo(payload)
            return {'closed':0,'reason':'not a recovery test'}

    def pending_mutations(db):''')
s=s.replace('setup_redo.tick(workspace,snap,now=now,automatic=automatic)', 'setup_redo.tick(workspace,snap,now=now,automatic=automatic,client=ReviewClient(app))')
s=s.replace('                    class Client:\n', '                    class Client(ReviewClient):\n')
s=s.replace("                        def request(self,*a,**kw):return {'closed':0,'reason':'not a recovery test'}",'')
s=s.replace("return_value=Client()", "return_value=Client(app)")
s=s.replace('setup_redo.tick(workspace,snap,now=clock+offset)', '''setup_redo.tick(workspace,snap,now=clock+offset,
                                launcher=lambda job, directory: desktop_jobs.launch_job(job,directory))''')
p=w/'reproduce_207_fixed.py';p.write_text(s)
