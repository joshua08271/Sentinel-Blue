"""Run private bounded local acceptance against the exact portable runtime.

Creates only disposable local files, SQLite databases, TLS listeners on
127.0.0.1, and owned child processes. Never installs boot services or touches
Azure. Native service-manager and multi-host acceptance are separate gates.
"""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import sys
import time
import unittest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runtime', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    runtime = Path(args.runtime).resolve()
    tests = Path(__file__).resolve().parents[1] / 'tests'
    sys.path[:0] = [str(runtime), str(tests)]
    import sentinel_blue
    if str(runtime) not in sentinel_blue.__file__:
        raise RuntimeError('Acceptance imported a different runtime')
    classes = ['test_controller_restore_workflow', 'test_offline_authority',
               'test_recovery_acceptance_edges', 'test_continuity_live', 'test_boot_and_continuity_controls']
    suite = unittest.defaultTestLoader.loadTestsFromNames(classes)
    records = []
    class Result(unittest.TextTestResult):
        def startTest(self, test):
            self.started = time.monotonic()
            super().startTest(test)
        def stopTest(self, test):
            name = test.id()
            kind = ('controlled_local_live_TLS_process' if 'test_continuity_live.' in name else
                    'controlled_local_live_SQLite_process_exit' if 'actual_process_exit' in name else
                    'local_regression_with_simulated_faults')
            bad = any(t is test for t, _ in self.errors + self.failures)
            skipped = any(t is test for t, _ in self.skipped)
            records.append({'test': name, 'evidence_class': kind,
                            'result': 'failed' if bad else 'skipped' if skipped else 'passed',
                            'seconds': round(time.monotonic()-self.started, 4),
                            'service_availability': 'not measured against a native/scored service'})
            super().stopTest(test)
    stream = io.StringIO()
    result = unittest.TextTestRunner(stream=stream, verbosity=2, resultclass=Result).run(suite)
    out = Path(args.output).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    raw = runtime.read_bytes()
    report = {'runtime': runtime.name, 'version': sentinel_blue.__version__,
              'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw),
              'git_blob_sha1': hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),
              'scope': 'User-authorized owned disposable local directories, SQLite databases, loopback TLS and child processes only',
              'native_Azure': 'not run; authenticated lab access unavailable',
              'native_Windows_service_manager': 'not run', 'native_Linux_systemd_reboot': 'not run',
              'live_multi_host': 'not run', 'independent_red_team': 'not run',
              'total': result.testsRun, 'passed': result.testsRun-len(result.failures)-len(result.errors)-len(result.skipped),
              'failed': len(result.failures), 'errors': len(result.errors), 'skipped': len(result.skipped),
              'tests': records}
    out.write_text(json.dumps(report, indent=2)+'\n')
    out.with_suffix('.log').write_text(stream.getvalue())
    print(json.dumps({k: report[k] for k in ('runtime','sha256','total','passed','failed','errors','skipped')}, indent=2))
    return 0 if result.wasSuccessful() else 1


if __name__ == '__main__':
    raise SystemExit(main())
