"""Real native offline acceptance, run by a bundled interpreter in isolation.

The parent establishes a Linux network namespace or a Windows rule for this
exact bundled python.exe. The fixture only uses owned local files and loopback.
"""
from __future__ import annotations
import argparse
import datetime
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import platform
import secrets
import socket
import subprocess
import sys
import threading
import time
import traceback


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--bundle',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    root=args.output.resolve();root.mkdir(mode=0o700)
    bundle=args.bundle.resolve();runtime=bundle/'sentinel-blue.pyz'
    sys.path.insert(0,str(runtime));sys.argv=[str(runtime)]
    import sentinel_blue
    from sentinel_blue.credential_vault import private_directory,CredentialVault
    from sentinel_blue import recording
    from sentinel_blue.state import _atomic_bytes,write_private_json
    from sentinel_blue.desktop_jobs import runtime_command,detach
    from sentinel_blue.offline import check_dependencies
    from sentinel_blue.event_profile import EventProfile
    from sentinel_blue.recovery_ops import initialize_controller_recovery
    from sentinel_blue.desktop_control import DesktopClient
    from sentinel_blue.probes import run_probes
    guard=private_directory(root)
    report={'status':'failed','version':sentinel_blue.__version__,'runtime_sha256':hashlib.sha256(runtime.read_bytes()).hexdigest(),
            'platform':platform.platform(),'interpreter':sys.executable,'isolated':bool(sys.flags.isolated),'cases':{}}
    processes=[];streams=[];window=None;local=None;server=None
    def case(name,value):
        report['cases'][name]=value
        (root/'progress.json').write_text(json.dumps(report,indent=2))
    def spawn(arguments,name):
        stream=(root/(name+'.log')).open('w');streams.append(stream)
        p=subprocess.Popen([*runtime_command(),*arguments],stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT)
        processes.append(p);return p
    def wait_for(fn,seconds=45):
        end=time.monotonic()+seconds
        while time.monotonic()<end:
            if window:window.root.update()
            try:
                value=fn()
                if value:return value
            except (OSError,RuntimeError):pass
            time.sleep(.05)
        raise TimeoutError('Native acceptance condition did not finish')
    try:
        assert Path(sys.executable).resolve().is_relative_to(bundle/'runtime') and sys.flags.isolated
        # Load Tcl/Tk from this relocated distribution, never the OS install.
        for key,pattern,marker in [('TCL_LIBRARY','tcl*','init.tcl'),('TK_LIBRARY','tk*','tk.tcl')]:
            choices=[p for base in (bundle/'runtime/lib',bundle/'runtime/tcl') for p in base.glob(pattern) if (p/marker).is_file()]
            assert len(choices)==1
            os.environ[key]=str(choices[0])
        unavailable=[]
        for family,address in [(socket.AF_INET,('1.1.1.1',443)),(socket.AF_INET6,('2606:4700:4700::1111',443))]:
            with socket.socket(family) as s:
                s.settimeout(2)
                try:s.connect(address)
                except OSError as exc:unavailable.append({'family':family.name,'blocked':True,'error_type':type(exc).__name__})
                else:raise AssertionError('Outside network is reachable; offline evidence would be invalid')
        case('outside_ipv4_and_ipv6_blocked',unavailable)
        dependency=check_dependencies(desktop=True);assert dependency['passed'];case('bundled_libraries_and_native_tk',dependency)
        with CredentialVault(root/'vault','offline-fixture-passphrase',create=True) as vault:
            vault.data['entries']['fixture']={'value':'generated-local-secret'};vault.save()
        with CredentialVault(root/'vault','offline-fixture-passphrase') as vault:
            assert vault.data['entries']['fixture']['value']=='generated-local-secret'
        case('vault_create_close_reopen',{'passed':True})
        child=detach(['offline-check']);processes.append(child);assert child.wait(timeout=45)==0
        case('detached_child_uses_bundled_python',{'passed':True,'command':runtime_command(),'pid':child.pid})
        # A real HTTP service, supervised TLS controller, and signed observer.
        from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                body=b'sentinel-offline-ready';self.send_response(200);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
            def log_message(self,*_):pass
        server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        threading.Thread(target=server.serve_forever,daemon=True).start()
        port=server.server_address[1]
        check={'kind':'http','target':f'http://127.0.0.1:{port}/','expected_status':[200],'expected_body':'sentinel-offline-ready','timeout':2}
        assert run_probes([check],['127.0.0.0/8'],authorized_hosts=['127.0.0.1'])[0].healthy
        from cryptography import x509
        from cryptography.hazmat.primitives import hashes,serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.x509.oid import NameOID
        key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
        subject=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'127.0.0.1')]);now=datetime.datetime.now(datetime.timezone.utc)
        cert=(x509.CertificateBuilder().subject_name(subject).issuer_name(subject).public_key(key.public_key())
            .serial_number(x509.random_serial_number()).not_valid_before(now-datetime.timedelta(minutes=1))
            .not_valid_after(now+datetime.timedelta(days=1)).add_extension(x509.SubjectAlternativeName([x509.IPAddress(ipaddress.ip_address('127.0.0.1'))]),False).sign(key,hashes.SHA256()))
        _atomic_bytes(root/'tls.key',key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
        _atomic_bytes(root/'tls.crt',cert.public_bytes(serialization.Encoding.PEM))
        raw=EventProfile.testing().raw
        raw['profile_id']='owned-offline-startup';raw['scope']['authorized_networks']=['127.0.0.0/8']
        raw['scope']['authorized_hosts']=['127.0.0.1'];raw['scope']['controller_ingress_hosts']=['127.0.0.1']
        raw['scope']['approved_deployment_paths']=[str(root)]
        raw['release']={'version':sentinel_blue.__version__,'sha256':report['runtime_sha256'],
            'controller_ca_sha256':hashlib.sha256((root/'tls.crt').read_bytes()).hexdigest(),'cloud_processing':False,'external_telemetry_export':False}
        raw['services']=[{'host':'target','service_id':'offline-http','protocol':'http','port':port,'implementation':'owned offline acceptance',
            'dependencies':[],'required_accounts':[],'required_files':[],'required_data':[],'credential_source':'generated fixture only',
            'expected_transactions':[check],'local_checks':[],'allowed_automatic_actions':[],'approval_actions':[],
            'backup_method':'owned local fixture','recovery_method':'operator review','rollback_method':'stop owned fixture'}]
        raw['services_confirmed']=True;EventProfile.from_dict(raw).require_range_ready();write_private_json(root/'profile.json',raw)
        master,operator,observer_key= [secrets.token_urlsafe(48) for _ in range(3)]
        recovery=secrets.token_bytes(48)
        for name,data in [('master.txt',master.encode()),('operator.txt',operator.encode()),('observer.key',observer_key.encode()),('recovery.key',recovery)]:_atomic_bytes(root/name,data)
        initialize_controller_recovery(root/'controller.db',root/'recovery.anchor',recovery)
        with socket.socket() as s:s.bind(('127.0.0.1',0));controller_port=s.getsockname()[1]
        origin=f'https://127.0.0.1:{controller_port}'
        observer={'observer_id':'outside-fixture','runtime_sha256':report['runtime_sha256'],'authorized_networks':['127.0.0.0/8'],
            'authorized_hosts':['127.0.0.1'],'excluded_hosts':[],'checks':[{'check_id':'http-check','agent_id':'target','service_id':'offline-http','probe':check}],
            'key_file':str(root/'observer.key'),'controller':origin,'ca_file':str(root/'tls.crt'),'state_directory':str(root/'observer-state')}
        write_private_json(root/'observer.json',observer);write_private_json(root/'observers.json',{'observers':[observer]})
        controller=spawn(['controller','--bind','127.0.0.1','--port',str(controller_port),'--supervise',
            '--event-profile',str(root/'profile.json'),'--range-deployment','--token-file',str(root/'master.txt'),
            '--operator-token-file',str(root/'operator.txt'),'--operator-principal-id','offline-fixture',
            '--database',str(root/'controller.db'),'--recovery-anchor',str(root/'recovery.anchor'),'--recovery-key-file',str(root/'recovery.key'),
            '--tls-cert',str(root/'tls.crt'),'--tls-key',str(root/'tls.key'),'--tls-ca-file',str(root/'tls.crt'),
            '--observer-config',str(root/'observers.json'),'--maintenance-interval','5'],'controller')
        client=DesktopClient(origin,'offline-fixture',2,operator,str(root/'tls.crt'));snapshot=wait_for(client.dashboard)
        case('supervised_tls_controller_starts_offline',{'passed':True,'pid':controller.pid})
        observer_process=spawn(['observer','--config',str(root/'observer.json'),'--once'],'observer')
        assert observer_process.wait(timeout=30)==0
        observer_log=(root/'observer.log').read_text();assert '"delivered": true' in observer_log,observer_log
        case('signed_observer_reports_offline',{'passed':True})
        # Tk event loop and genuine Start / Stop & save controls, no stub callbacks.
        import tkinter as tk
        from sentinel_blue.desktop import DesktopWindow
        local=recording.Recorder(root/'recordings',role='desktop-test');recording._current=local
        os.environ[recording.ENV]=str(local.directory)
        window=DesktopWindow(tk.Tk(),directory=root/'desktop');window.client=client
        window.runtime_path.set(str(runtime));window.notify.set(False)
        window.notebook.select(window.tabs['Session']);window.start_session_button.invoke()
        wait_for(lambda:not window.session_busy and 'Recording' in window.session_status.get())
        window.stop_session_button.invoke()
        wait_for(lambda:not window.session_busy and 'file verified' in window.session_status.get(),90)
        case('native_window_start_stop_and_verified_export',{'passed':True,'status':window.session_status.get(),
            'recording_events':local.status()['events']})
        report['status']='passed'
    except Exception:
        report['error']=traceback.format_exc()
    finally:
        if window:
            try:window.close()
            except Exception:pass
        if local:
            try:local.close()
            except Exception:pass
        for process in reversed(processes):
            if process.poll() is None:
                process.terminate()
                try:process.wait(timeout=20)
                except subprocess.TimeoutExpired:process.kill();process.wait(timeout=10)
        for stream in streams:stream.close()
        if server:server.shutdown();server.server_close()
        if guard:guard.close()
        (root/'receipt.json').write_text(json.dumps(report,indent=2))
        print(json.dumps(report,indent=2),flush=True)
    return 0 if report['status']=='passed' else 2


if __name__=='__main__':raise SystemExit(main())
