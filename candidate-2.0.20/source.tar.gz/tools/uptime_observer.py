"""Independent, bounded one-Hz HTTP scoring for an owned loopback fixture."""
from __future__ import annotations
import argparse
import json
import math
from pathlib import Path
import time
from urllib.error import HTTPError
from urllib.parse import urlsplit
from urllib.request import ProxyHandler, build_opener


def validate(target, duration):
    url = urlsplit(target)
    if (url.scheme != 'http' or url.hostname != '127.0.0.1' or
            url.username or url.password or url.query or url.fragment or
            not url.port or not 1024 <= url.port <= 65535 or url.path != '/health'):
        raise ValueError('Only the owned loopback health endpoint is supported')
    if type(duration) is not int or not 5 <= duration <= 1200:
        raise ValueError('Measurement duration must be 5..1200 seconds')


def summarize(rows, duration):
    if type(duration) is not int or not 5 <= duration <= 1200:
        raise ValueError('Unsupported measurement duration')
    by_slot = {}
    for row in rows:
        slot = row.get('slot')
        if type(slot) is not int or not 0 <= slot < duration or slot in by_slot:
            raise ValueError('Invalid or duplicated scoring slot')
        by_slot[slot] = row
    for slot in range(duration):
        by_slot.setdefault(slot, {'slot': slot, 'healthy_1s': False, 'healthy_2s': False,
                                 'reason': 'missing_record'})
    longest = current = 0
    for slot in range(duration):
        current = 0 if by_slot[slot]['healthy_2s'] else current + 1
        longest = max(longest, current)
    reasons = {}
    for row in by_slot.values():
        if not row['healthy_2s']:
            reasons[row['reason']] = reasons.get(row['reason'], 0) + 1
    actual = [row['request_seconds'] for row in rows if 'request_seconds' in row]
    actual.sort()
    quantile = lambda p: actual[min(len(actual)-1, math.ceil(p*len(actual))-1)] if actual else None
    return {'expected_checks': duration, 'recorded_checks': len(rows),
            'healthy_checks_1s': sum(row['healthy_1s'] for row in by_slot.values()),
            'healthy_checks_2s': sum(row['healthy_2s'] for row in by_slot.values()),
            'availability_percent_1s': round(100*sum(row['healthy_1s'] for row in by_slot.values())/duration, 3),
            'availability_percent_2s': round(100*sum(row['healthy_2s'] for row in by_slot.values())/duration, 3),
            'longest_failed_check_run_seconds': longest, 'failed_check_reasons': reasons,
            'request_seconds_p50': quantile(.50), 'request_seconds_p95': quantile(.95),
            'request_seconds_max': max(actual, default=None),
            'observer_is_separate_process': True, 'observer_shares_guest_resources': True,
            'not_a_competition_forecast': True}


def observe(target, duration, output, ready, stop):
    validate(target, duration)
    opener = build_opener(ProxyHandler({}))
    start = time.monotonic()
    ready.write_text(json.dumps({'start_monotonic': start, 'start_unix': time.time()}))
    with output.open('x') as stream:
        for slot in range(duration):
            if stop.exists():
                break
            due = start + slot
            time.sleep(max(0, due-time.monotonic()))
            began = time.monotonic()
            row = {'slot': slot, 'observer_lag_seconds': round(began-due, 6),
                   'healthy_1s': False, 'healthy_2s': False}
            if began-due >= 1:
                row['reason'] = 'observer_missed_slot'
            else:
                status, matched, reason = 0, False, 'request_failed'
                try:
                    with opener.open(target, timeout=max(.05, due+2-began)) as response:
                        status = response.status
                        matched = response.read(128) == b'fixture-ok'
                    reason = 'healthy' if status == 200 and matched else 'unexpected_response'
                except HTTPError as exc:
                    status, reason = exc.code, 'http_status'
                    exc.close()
                except Exception as exc:
                    reason = type(exc).__name__
                done = time.monotonic()
                row.update(status=status, body_matched=matched,
                           request_seconds=round(done-began, 6),
                           scheduled_response_seconds=round(done-due, 6),
                           healthy_1s=status == 200 and matched and done-due <= 1,
                           healthy_2s=status == 200 and matched and done-due <= 2,
                           reason='scheduled_deadline' if status == 200 and matched and done-due > 2 else reason)
            stream.write(json.dumps(row, separators=(',', ':'))+'\n')
            stream.flush()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target', required=True)
    parser.add_argument('--duration', type=int, required=True)
    for name in ('output', 'ready', 'stop'):
        parser.add_argument('--'+name, type=Path, required=True)
    args = parser.parse_args()
    observe(args.target, args.duration, args.output, args.ready, args.stop)
