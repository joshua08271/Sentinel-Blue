"""Repack a verified offline bundle without changing or fetching dependencies."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import tempfile
import zipfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def repack(previous, runtime, output, guide=None):
    previous, runtime, output = map(Path, (previous, runtime, output))
    script = runtime.read_bytes()
    with zipfile.ZipFile(runtime) as runtime_zip:
        import ast
        tree = ast.parse(runtime_zip.read('sentinel_blue/__init__.py').decode())
        version = next(node.value.value for node in tree.body if isinstance(node, ast.Assign)
                       and any(isinstance(t, ast.Name) and t.id == '__version__' for t in node.targets))
    output.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(previous) as old:
        names = old.namelist()
        if len(names) != len(set(names)) or old.testzip():
            raise ValueError('Original bundle is duplicated or corrupt')
        prefixes = {PurePosixPath(n).parts[0] for n in names}
        if len(prefixes) != 1 or any('..' in PurePosixPath(n).parts or n.startswith('/') for n in names):
            raise ValueError('Unsafe original bundle paths')
        prefix = prefixes.pop() + '/'
        entries = {n[len(prefix):]: (old.read(n), old.getinfo(n)) for n in names if not n.endswith('/')}
    manifest = json.loads(entries['offline-manifest.json'][0])
    for line in entries['SHA256SUMS'][0].decode().splitlines():
        checksum, name = line.split('  ', 1)
        if sha(entries[name][0]) != checksum:
            raise ValueError('Original offline file checksum differs: ' + name)
    if sha(entries['sentinel-blue.pyz'][0]) != manifest['runtime_sha256']:
        raise ValueError('Original script checksum differs')
    target = manifest['target']
    folder = f'Sentinel Blue {version} {target}'
    with tempfile.TemporaryDirectory(prefix='sentinel-offline-repack-', dir=output) as temporary:
        root = Path(temporary) / folder
        for name, (data, info) in entries.items():
            mode = info.external_attr >> 16
            if stat.S_ISLNK(mode):
                raise ValueError('Offline repack does not follow symlinks')
            path = root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
            path.chmod(stat.S_IMODE(mode) or 0o644)
        (root/'sentinel-blue.pyz').write_bytes(script)
        original_version = manifest['version']
        manifest['previous_dependency_check'] = {'release_version': original_version,
                                                 'receipt': manifest.pop('dependency_check', None)}
        manifest.update(version=version, runtime_sha256=sha(script),
                        repack={'source_archive_sha256': sha(previous.read_bytes()),
                                'dependencies_byte_identical': True, 'downloaded_dependencies': False})
        (root/'offline-manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
        if target == 'linux-x86_64' and os.name == 'posix':
            env = dict(os.environ, PYTHONHOME='/not-a-system-python', PYTHONPATH='/not-system-packages')
            result = subprocess.run([str(root/'runtime/bin/python3'), '-I', '-B', str(root/'launch.py'), 'offline-check'],
                                    env=env, capture_output=True, text=True, timeout=60)
            if result.returncode:
                raise RuntimeError('New bundled runtime dependency check failed: '+result.stdout[-1500:]+result.stderr[-1500:])
            manifest['dependency_check'] = json.loads(result.stdout)
            manifest['dependency_check']['release_version'] = version
        else:
            manifest['dependency_check'] = {'status': 'not_run', 'passed': None, 'release_version': version,
                                            'reason': 'No native Windows runtime available in this build environment'}
        (root/'offline-manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
        first = (root/'START-HERE.txt').read_text().splitlines(keepends=True)
        first[0] = f'Sentinel Blue {version} — {target}\n'
        start_here = ''.join(first)
        if 'Read EMERGENCY-WITHDRAWAL.md' not in start_here:
            start_here += '\nEmergency Remove and Restore & Withdraw are in the Withdraw tab.\nRead EMERGENCY-WITHDRAWAL.md for ownership limits and native validation status.\n'
        if guide:
            guide_path = Path(guide)
            (root/guide_path.name).write_bytes(guide_path.read_bytes())
            start_here += f'\nAdditional release guide: {guide_path.name}\n'
        (root/'START-HERE.txt').write_text(start_here)
        for name, (data, _) in entries.items():
            if name.startswith('runtime/') or name in {'launch.py', 'Start-Sentinel-Blue.cmd', 'Start-Sentinel-Blue.sh'}:
                if (root/name).read_bytes() != data:
                    raise ValueError('Dependency or launcher was changed')
        files = sorted(p for p in root.rglob('*') if p.is_file() and p.name != 'SHA256SUMS')
        (root/'SHA256SUMS').write_text(''.join(sha(p.read_bytes())+'  '+p.relative_to(root).as_posix()+'\n' for p in files))
        archive = output / f'sentinel-blue-{version}-offline-{target}.zip'
        temporary_archive = output / (archive.name+'.building')
        with zipfile.ZipFile(temporary_archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as new:
            for path in sorted(p for p in root.rglob('*') if p.is_file()):
                info = zipfile.ZipInfo(folder+'/'+path.relative_to(root).as_posix(), (2026,1,1,0,0,0))
                info.create_system = 3
                info.external_attr = (stat.S_IFREG | stat.S_IMODE(path.stat().st_mode)) << 16
                new.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=6)
        with zipfile.ZipFile(temporary_archive) as check:
            if check.testzip() or sha(check.read(folder+'/sentinel-blue.pyz')) != sha(script):
                raise ValueError('New bundle verification failed')
        os.replace(temporary_archive, archive)
    return {'archive': str(archive), 'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes()), 'manifest': manifest}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--previous', required=True)
    parser.add_argument('--runtime', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--guide')
    args = parser.parse_args()
    print(json.dumps(repack(args.previous, args.runtime, args.output, args.guide), indent=2))
