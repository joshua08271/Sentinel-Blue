"""Live recorder acceptance on owned loopback services and actual packaged agents.
No offensive traffic. Controlled service outages and process restarts only.
"""
from __future__ import annotations
import argparse, copy, hashlib, json, os, platform, secrets, shutil, socket
import subprocess, sys, tempfile, time, traceback, zipfile
from pathlib import Path
from urllib.request import urlopen
from urllib.error import URLError


def scan_evidence(bundle, secret_values, since=0):
    kinds=set();healthy=False;unhealthy=False;secret_found=False
    secrets_bytes=[value.encode() for value in secret_values]
    with zipfile.ZipFile(bundle) as outer:
        for name in outer.namelist():
            if not name.endswith('.zip'):continue
            with tempfile.TemporaryFile() as copied, outer.open(name) as source:
                shutil.copyfileobj(source,copied,1024*1024);copied.seek(0)
                with zipfile.ZipFile(copied) as inner, inner.open('events.jsonl') as stream:
                    for line in stream:
                        secret_found |= any(value in line for value in secrets_bytes)
                        event=json.loads(line)
                        if event['at'] < since:continue
                        kinds.add(event['kind'])
                        if event['kind']=='controller_observation':
                            probes=event['data'].get('telemetry',{}).get('probes',[])
                            healthy |= any(p.get('healthy') is True for p in probes)
                            unhealthy |= any(p.get('healthy') is False for p in probes)
    return kinds,healthy,unhealthy,secret_found


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runtime',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--seconds',type=int,default=7200)
    parser.add_argument('--gui',action='store_true')
    parser.add_argument('--separate-recordings',action='store_true',
                        help='Keep desktop/setup and controller/agent journals separate to verify aggregation')
    parser.add_argument('--recording-directory',type=Path,
                        help='Reuse a stopped owned test journal to verify a later weekly session')
    parser.add_argument('--prefilled-recording',action='store_true',
                        help='Owned performance fixture: append live events to a verified historical-data copy')
    args=parser.parse_args()
    if not 60<=args.seconds<=7500:parser.error('Duration must be 60..7500 seconds')
    runtime=args.runtime.resolve(strict=True)
    sys.path[:0]=[str(runtime),str(Path(__file__).resolve().parents[1])]
    import sentinel_blue
    from sentinel_blue import recording
    from sentinel_blue.agent import AgentClient
    from sentinel_blue.auth import derive_enrollment_ticket
    from sentinel_blue.desktop_control import DesktopClient
    from sentinel_blue.event_profile import EventProfile
    from sentinel_blue.recovery_ops import initialize_controller_recovery
    from sentinel_blue.state import _atomic_bytes,write_private_json
    from tools.history_storage_rehearsal import certificate,free_port,stop
    from tools.setup_native_inputs import manifest,runbook,profile_inventory
    from sentinel_blue.desktop_jobs import prepare,launch_job
    from sentinel_blue.setup import plan_digest
    if str(runtime) not in sentinel_blue.__file__:raise RuntimeError('Packaged runtime not loaded')
    os.umask(0o077)
    root=Path(tempfile.gettempdir())/('sentinel-recorder-'+secrets.token_hex(6))
    root.mkdir(mode=0o700)
    if os.name=='nt':
        subprocess.run(['icacls',str(root),'/inheritance:r','/grant:r','*S-1-5-18:(OI)(CI)F','*S-1-5-32-544:(OI)(CI)F'],check=True,capture_output=True)
    args.output=args.output.absolute();args.output.mkdir(parents=True,exist_ok=True)
    report={'status':'failed','version':sentinel_blue.__version__,'runtime_sha256':hashlib.sha256(runtime.read_bytes()).hexdigest(),
            'platform':platform.platform(),'python':platform.python_version(),'requested_seconds':args.seconds,
            'scope':'owned loopback HTTP service; packaged TLS controller and real native host collector; benign service interruptions',
            'checks':{},'timeline':[],'gui_requested':args.gui,'separate_recordings':args.separate_recordings,
            'collection_interval_seconds':5 if args.seconds<600 else 15,'samples':[]}
    report['live_evidence_after']=time.time()
    processes=[];streams=[];window=None;tkroot=None;local=None;agent=None;controller=None;service=None
    def launch(argv,name):
        stream=(root/name).open('w',encoding='utf-8');streams.append(stream)
        process=subprocess.Popen(argv,stdout=stream,stderr=subprocess.STDOUT)
        processes.append(process);return process
    def wait_until(predicate,seconds=90):
        end=time.monotonic()+seconds
        while time.monotonic()<end:
            if tkroot is not None:tkroot.update()
            try:
                value=predicate()
                if value:return value
            except (OSError,RuntimeError,ValueError):pass
            time.sleep(.1)
        raise TimeoutError('Live acceptance condition did not complete')
    def mark(kind):report['timeline'].append({'kind':kind,'at':time.time()})
    def http_ok():
        try:
            with urlopen(service_origin,timeout=2) as response:return response.status==200 and b'range-ready' in response.read(1024)
        except (OSError,URLError):return False
    try:
        certificate(root)
        port,service_port=free_port(),free_port()
        origin=f'https://127.0.0.1:{port}';service_origin=f'http://127.0.0.1:{service_port}/'
        public=root/'public';public.mkdir(mode=0o700)
        service=launch([sys.executable,'-m','http.server',str(service_port),'--bind','127.0.0.1','--directory',str(public)],'service.log')
        check={'name':'range-http','kind':'http','target':service_origin,'expected_status':[200],'expected_body':'range-ready','timeout':1}
        service_manifest=manifest('owned-recording-http','http',service_port,[check])
        # This rehearsal measures Start/record/Stop with an already-ready
        # service. Generic provisioning requires a separate approved contract.
        target=public/'index.html'; target.write_text('range-ready')
        if os.name=='nt':
            q="'"+str(target).replace("'","''")+"'"
            check_script=f"if ((Test-Path -LiteralPath {q}) -and [IO.File]::ReadAllText({q}) -eq 'range-ready') {{exit 0}};exit 1"
            apply_script=f"[IO.File]::WriteAllText({q},'range-ready');exit 0"
            rollback_script=f"$ErrorActionPreference='Stop';if ([IO.File]::ReadAllText({q}) -cne 'range-ready') {{throw 'Fixture content changed'}};Remove-Item -LiteralPath {q};exit 0"
        else:
            import shlex
            q=shlex.quote(str(target))
            check_script=f"test -f {q} && test \"$(cat {q})\" = range-ready\n"
            apply_script=f"printf '%s' range-ready > {q}\n"
            rollback_script=f"set -eu\ntest \"$(cat {q})\" = range-ready\nrm -- {q}\n"
        task=runbook(root,'configure-owned-http',check_script,apply_script,service=service_manifest['service_id'],rollback=rollback_script)
        inventory=profile_inventory(runtime,[task],[service_manifest]);raw=inventory['event_profile']
        raw['profile_id']='owned-recorder-acceptance'
        raw['scope']['approved_deployment_paths']=[str(root)]
        raw['release']['controller_ca_sha256']=hashlib.sha256((root/'tls.crt').read_bytes()).hexdigest()
        profile=EventProfile.from_dict(raw);profile.require_range_ready()
        write_private_json(root/'profile.json',raw);write_private_json(root/'inventory.json',inventory)
        write_private_json(root/'probes.json',{'probes':[check]})
        master,operator,key=secrets.token_urlsafe(48),secrets.token_urlsafe(48),secrets.token_bytes(48)
        _atomic_bytes(root/'master.txt',master.encode());_atomic_bytes(root/'operator.txt',operator.encode());_atomic_bytes(root/'recovery.key',key)
        database,anchor=root/'controller.db',root/'recovery.anchor'
        initialize_controller_recovery(database,anchor,key)
        # UI, local agent and controller share one local session by explicit
        # environment inheritance. Remote export is separately tested in units.
        if args.recording_directory and args.separate_recordings:
            raise ValueError('Weekly reuse and separate-journal tests are distinct scenarios')
        local=recording.Recorder(args.recording_directory or root/'recordings',role='desktop-test')
        if args.recording_directory and args.prefilled_recording:
            state=local.status()
            if state['state']!='recording':raise ValueError('Prefilled fixture must be active')
            report['prefilled_journal']={'events_before_live_test':state['events'],'bytes_before_live_test':state['recorded_bytes']}
        elif args.recording_directory:
            previous_status=local.status()
            if previous_status['state']!='stopped':raise ValueError('Weekly reuse requires a stopped test session')
            previous_export=local.export()
            previous_hash=hashlib.sha256(previous_export.read_bytes()).hexdigest()
            report['previous_session']={'session_id':previous_status['session_id'],'events':previous_status['events'],
                'recorded_bytes':previous_status['recorded_bytes'],'sha256':previous_hash}
        recording._current=local;os.environ[recording.ENV]=str(local.directory)
        controller_argv=[sys.executable,str(runtime),'controller','--bind','127.0.0.1','--port',str(port),
             '--event-profile',str(root/'profile.json'),'--range-deployment','--token-file',str(root/'master.txt'),
             '--operator-token-file',str(root/'operator.txt'),'--operator-principal-id','recorder-test',
             '--database',str(database),'--recovery-anchor',str(anchor),'--recovery-key-file',str(root/'recovery.key'),
             '--tls-cert',str(root/'tls.crt'),'--tls-key',str(root/'tls.key'),'--tls-ca-file',str(root/'tls.crt'),
             '--maintenance-interval','5','--backup-interval','900']
        if args.separate_recordings:
            controller_argv+=['--recording-directory',str(root/'controller-recordings')]
        controller=launch(controller_argv,'controller.log')
        client=DesktopClient(origin,'recorder-test',2,operator,str(root/'tls.crt'))
        wait_until(client.dashboard)
        values={'inventory':str(root/'inventory.json'),'event_profile':str(root/'profile.json'),
                'runtime':str(runtime),'kind':'setup','range_deployment':True}
        plan,_=prepare(values['inventory'],values['event_profile'],values['runtime'],'setup',True)
        job=dict(values,approved_digest=plan_digest(plan))
        if args.gui:
            import tkinter as tk
            from sentinel_blue.desktop import DesktopWindow
            from unittest.mock import patch
            tkroot=tk.Tk();window=DesktopWindow(tkroot,directory=root/'desktop')
            window.notify.set(False);window.client=client
            window.inventory_path.set(values['inventory']);window.profile_path.set(values['event_profile'])
            window.runtime_path.set(str(runtime));window.range_mode.set(True);window.plan=(values,plan)
            window.notebook.select(window.tabs['Session'])
            # Invoke actual Tk controls. Only approval input and launch context
            # are supplied by the test; worker and runtime are real subprocesses.
            with patch('sentinel_blue.desktop_jobs.runtime_command',return_value=[sys.executable,str(runtime)]),patch.object(window.messagebox,'askyesno',return_value=True):
                window.start_session_button.invoke()
                wait_until(lambda:window.job_path is not None)
                wait_until(lambda:window.job_path is None and http_ok())
            report['checks']['native_gui_start_already_ready']=True
            report['gui_geometry']=tkroot.winfo_geometry()
            window.root.iconify();tkroot.update()
        else:
            client.request('/api/v1/recording/start',{})
            from unittest.mock import patch
            with patch('sentinel_blue.desktop_jobs.runtime_command',return_value=[sys.executable,str(runtime)]):
                process,path=launch_job(job,root/'setup-job')
            processes.append(process)
            if process.wait(timeout=150)!=0:raise RuntimeError('Native setup job failed')
            report['checks']['packaged_setup_worker']=True
        wait_until(http_ok);mark('setup_healthy')
        bootstrap=derive_enrollment_ticket(master,profile.fingerprint,'target')
        _atomic_bytes(root/'agent-ticket.txt',bootstrap.encode())
        agent_argv=[sys.executable,str(runtime),'agent','--controller',origin,'--agent-id','target',
            '--event-profile',str(root/'profile.json'),'--range-deployment','--ca-file',str(root/'tls.crt'),
            '--token-file',str(root/'agent-ticket.txt'),'--state-dir',str(root/'agent-state'),
            '--probe-config',str(root/'probes.json'),'--interval',('5' if args.seconds<600 else '15'),'--spool-limit','256']
        if args.separate_recordings:
            agent_argv+=['--recording-directory',str(root/'controller-recordings')]
        agent=launch(agent_argv,'agent.log')
        def observed():
            snap=client.dashboard()
            return snap if any(x.get('agent_id')=='target' and x.get('health')=='healthy' for x in snap.get('service_health',[])) else None
        wait_until(observed,150);mark('agent_healthy')
        report['checks']['real_collector_and_tls_delivery']=True
        # Known secret canary in excluded text fields; final ZIP is scanned.
        canary='recorder-private-canary-'+secrets.token_hex(16)
        local.emit('privacy_canary',{'password':canary,'stdout':canary,'message':canary})
        start=time.monotonic();phase=0;checks=0;failures=0;unexpected_failures=0;last_sample=0;planned_outage=False
        outage_start=max(15,args.seconds*.15);outage_end=outage_start+min(35,args.seconds*.1)
        controller_stop_at=max(outage_end+10,args.seconds*.45)
        controller_start_at=controller_stop_at+min(75,args.seconds*.15)
        agent_restart_at=max(controller_start_at+15,args.seconds*.75)
        while time.monotonic()-start<args.seconds:
            elapsed=time.monotonic()-start
            if tkroot is not None:tkroot.update()
            if phase==0 and elapsed>=outage_start:
                stop(service);phase=1;planned_outage=True;mark('service_stopped')
            elif phase==1 and elapsed>=outage_end:
                service=launch([sys.executable,'-m','http.server',str(service_port),'--bind','127.0.0.1','--directory',str(public)],'service-restart.log')
                phase=2;mark('service_restarted')
            elif phase==2 and elapsed>=controller_stop_at:
                controller.kill();controller.wait(timeout=10);phase=3;mark('controller_crashed')
            elif phase==3 and elapsed>=controller_start_at:
                controller=launch(controller_argv,'controller-restart.log');wait_until(client.dashboard)
                phase=4;mark('controller_restarted')
            elif phase==4 and elapsed>=agent_restart_at:
                agent.kill();agent.wait(timeout=10)
                agent=launch(agent_argv,'agent-restart.log');phase=5;mark('agent_restarted')
            okay=http_ok();checks+=1
            if planned_outage and phase>=2 and okay:
                planned_outage=False;mark('service_recovery_observed')
            if not okay:
                if planned_outage:failures+=1
                else:unexpected_failures+=1
            if elapsed-last_sample>=10:
                report['samples'].append({'seconds':round(elapsed,2),'service_healthy':okay,
                                         'journal_bytes':local.path.stat().st_size,'recorder':local.status()})
                last_sample=elapsed
                (args.output/'progress.json').write_text(json.dumps({'elapsed_seconds':round(elapsed,2),'phase':phase,
                    'events':local.status()['events'],'storage_errors':local.errors,'recorded_bytes':local.status()['recorded_bytes'],'journal_bytes':local.path.stat().st_size}))
            time.sleep(.5)
        report['duration_seconds']=round(time.monotonic()-start,3)
        report['checks']['all_scheduled_phases']=phase==5
        wait_until(observed,150);mark('final_service_healthy')
        client.request('/api/v1/governance/emergency-stop',{});client.request('/api/v1/governance/resume',{})
        if window:
            export_began=time.monotonic()
            window.stop_session_button.invoke()
            wait_until(lambda:not window.session_busy,1200)
            report['gui_export_seconds']=round(time.monotonic()-export_began,3)
            text=window.recording_location.get()
            if not text.startswith('Copy this file to your laptop: '):raise RuntimeError('GUI export failed')
            bundle=Path(text.split(': ',1)[1]);report['checks']['native_gui_stop_and_export']=True
        else:
            remote=client.save_recording(root/'download')
            local.stop();bundle=recording.make_session_bundle(root/'portable'/'session.zip',[remote,local.export()])
        summary=recording.inspect_bundle(bundle)
        report['checks']['portable_bundle_verified']=summary['verified']
        if args.recording_directory and not args.prefilled_recording:
            report['checks']['previous_week_preserved']=hashlib.sha256(previous_export.read_bytes()).hexdigest()==previous_hash
            report['checks']['previous_week_verified']=recording.inspect_bundle(previous_export)['events']==previous_status['events']
            report['checks']['new_week_has_new_identity']=local.status()['session_id']!=previous_status['session_id']
            report['checks']['previous_week_archived']=local.status()['archived_sessions']>previous_status['archived_sessions']
        if args.separate_recordings:
            report['checks']['both_distinct_recordings_in_one_bundle']=len(summary['verified_recordings'])==2
        kinds,healthy,unhealthy,secret_found=scan_evidence(bundle,(canary,master,operator),report['live_evidence_after'])
        report['checks']['secret_excluded']=not secret_found
        for kind in ('setup_progress','setup_worker_result','agent_observation','controller_observation','agent_cycle_failed','telemetry_queued','telemetry_delivered','request_outcome'):
            report['checks']['captured_'+kind]=kind in kinds
        report['checks']['captured_unhealthy_probe']=unhealthy
        report['checks']['captured_healthy_probe']=healthy
        report['checks']['zero_recording_drops']=all(x['dropped_events']==0 for x in summary['verified_recordings'])
        report['checks']['zero_recorder_storage_errors']=all(x['storage_errors_this_process']==0 and x.get('storage_errors_all_sources',0)==0 for x in summary['verified_recordings'])
        report['event_counts']=summary['verified_recordings'][0]['event_counts']
        report['coverage']=summary['verified_recordings'][0]['coverage']
        report['service_checks']=checks;report['service_failures_during_scheduled_outage']=failures
        report['unexpected_service_probe_failures']=unexpected_failures
        report['checks']['no_unexpected_service_probe_failures']=unexpected_failures==0
        report['bundle_bytes']=bundle.stat().st_size
        shutil.copyfile(bundle,args.output/'recorded-session.zip')
        report['status']='passed' if all(report['checks'].values()) else 'failed'
    except Exception as exc:
        report['error_type']=type(exc).__name__;report['error']=str(exc)
        (args.output/'failure.txt').write_text(traceback.format_exc())
    finally:
        if window:
            window.close();tkroot=None
        for process in processes:stop(process)
        if local:local.close()
        recording._current=None
        for stream in streams:stream.close()
        # Explicit diagnostics only. Credentials, profiles and mutable databases
        # stay out of the uploaded validation evidence.
        for name in ('controller.log','controller-restart.log','agent.log','agent-restart.log'):
            path=root/name
            if path.is_file():shutil.copyfile(path,args.output/name)
        report['cleanup']={'children_stopped':all(p.poll() is not None for p in processes),'fixture_root':str(root)}
        (args.output/'live.json').write_text(json.dumps(report,indent=2))
        print(json.dumps({'status':report['status'],'checks':report['checks'],'error':report.get('error'),
                          'duration_seconds':report.get('duration_seconds')}),flush=True)
    return 0 if report['status']=='passed' else 2

if __name__=='__main__':raise SystemExit(main())
