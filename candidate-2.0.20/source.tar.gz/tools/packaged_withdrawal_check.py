"""Exercise the shipped CLI against disposable local files and real transports.

This is a local integration check, not Windows or multi-machine acceptance.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


def run(runtime):
    runtime = Path(runtime).resolve()
    sys.path.insert(0, str(runtime))
    from sentinel_blue.event_profile import EventProfile
    from sentinel_blue.mutation_ledger import MutationLedger
    from sentinel_blue.withdrawal_native import NativeObjects, object_target
    from sentinel_blue.state import write_private_json
    digest = hashlib.sha256(runtime.read_bytes()).hexdigest()
    results = []
    for mode in ('remove', 'restore-withdraw'):
        with tempfile.TemporaryDirectory(prefix='sentinel-withdraw-cli-') as directory:
            root = Path(directory)
            installed = root / 'installation' / 'sentinel-blue.pyz'
            credential = installed.parent / 'identity.json'
            config = root / 'legitimate.conf'
            teammate = root / 'teammate.conf'
            installed.parent.mkdir()
            teammate.write_text('teammate owned')
            config.write_text('before')
            ledger_dir = root / 'ledger'
            env = dict(os.environ, SENTINEL_LEDGER_DIR=str(ledger_dir))
            def invoke(argv, payload=None, expected=0):
                result = subprocess.run([sys.executable, str(runtime), *argv],
                    input=None if payload is None else json.dumps(payload), text=True,
                    capture_output=True, env=env, timeout=60)
                if result.returncode != expected:
                    raise RuntimeError('Packaged command failed: ' + result.stdout[-2000:] + result.stderr[-2000:])
                return result.stdout
            def guest(request):
                response = json.loads(invoke(['withdraw-guest'], request).split('SENTINEL_WITHDRAW_RESULT=', 1)[1])
                if not response['success']:
                    raise RuntimeError(response['error'])
                return response['result']
            credential_data = b'{"fixture":"not-a-real-credential"}\n'
            guest({'operation': 'install-begin', 'action_id': 'fixture-install',
                   'target': object_target(files=[str(installed), str(credential)]),
                   'expected_files': {str(installed): digest, str(credential): hashlib.sha256(credential_data).hexdigest()}})
            shutil.copyfile(runtime, installed)
            credential.write_bytes(credential_data)
            guest({'operation': 'install-finish', 'action_id': 'fixture-install'})
            ledger = MutationLedger(ledger_dir)
            native = NativeObjects(ledger)
            ledger.mutate(native.name, object_target(files=[str(config)]),
                          lambda: config.write_text('sentinel configuration'), snapshot=native.snapshot,
                          action_id='fixture-configuration')
            profile = EventProfile.testing().raw
            profile['scope'].update(authorized_networks=['127.0.0.0/8'], authorized_hosts=['127.0.0.1'],
                                    controller_ingress_hosts=['127.0.0.1'])
            profile['release'].update(sha256=digest, controller_ca_sha256='a'*64,
                                      external_telemetry_export=False, cloud_processing=False)
            profile['services_confirmed'] = True
            profile['services'] = [{'host': 'local-fixture', 'service_id': 'fixture-web', 'protocol': 'http',
                'port': 8080, 'implementation': 'disposable fixture', 'dependencies': [], 'required_accounts': [],
                'required_files': [], 'required_data': [], 'credential_source': '',
                'expected_transactions': [{'kind': 'http', 'target': 'http://127.0.0.1:8080/', 'expected_body': 'healthy'}],
                'local_checks': [], 'allowed_automatic_actions': [], 'approval_actions': [],
                'backup_method': 'fixture', 'recovery_method': 'fixture', 'rollback_method': 'fixture'}]
            EventProfile.from_dict(profile)
            write_private_json(root/'profile.json', profile)
            # Withdrawal must work without old setup recipes or their source files.
            write_private_json(root/'inventory.json', {'authorized_networks': ['127.0.0.0/8'], 'hosts': [{
                'name': 'fixture', 'address': '127.0.0.1', 'agent_id': 'local-fixture', 'platform': 'linux',
                'transport': 'local', 'runtime': str(installed), 'python': sys.executable}]})
            args = ['withdraw', '--inventory', str(root/'inventory.json'), '--event-profile', str(root/'profile.json'),
                    '--directory', str(root/'report'), '--mode', mode, '--range-deployment']
            review = json.loads(invoke(args))
            result = json.loads(invoke(args + ['--approved-digest', review['review_digest']], expected=0 if mode == 'remove' else 2))
            if teammate.read_text() != 'teammate owned':
                raise RuntimeError('Unrelated teammate file was changed')
            if mode == 'remove':
                if result['status'] != 'complete' or installed.exists() or credential.exists() or config.read_text() != 'sentinel configuration':
                    raise RuntimeError('Remove did not preserve configuration and remove the recorded installation')
                if not (ledger_dir/'withdrawal-helper.pyz').is_file() or not all(x['verified'] for x in result['recovery_copies']):
                    raise RuntimeError('Independent helper or recovery evidence missing')
            else:
                if result['status'] != 'held' or not installed.exists() or config.read_text() != 'before':
                    raise RuntimeError('Restore did not hold installation removal for missing independent verification')
            results.append({'mode': mode, 'status': result['status'], 'native_files': True,
                            'packaged_cli': True, 'teammate_preserved': True,
                            'separate_machine_verification': False, 'actions': len(result['actions'])})
    return {'runtime_sha256': digest, 'platform': sys.platform, 'checks': results,
            'live_multi_host': False, 'windows_native': False}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('runtime')
    args = parser.parse_args()
    print(json.dumps(run(args.runtime), indent=2))
