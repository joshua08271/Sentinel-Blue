"""Local evidence/fixture primitives, used only by the disposable-host harness."""
from __future__ import annotations

import base64
import ctypes
import hashlib
import json
import os
from pathlib import Path
import stat
import struct
import uuid

from acceptance_snapshot import SnapshotError, snapshot_paths


class WriteWatch:
    """Observe writes to exact paths during one apply; queue loss is failure.

    A write event plus an apply/rollback report proves the failure path was
    exercised. It does not establish power-loss safety or actor attribution.
    """
    def __init__(self, paths):
        self.paths = {str(Path(p)) for p in paths}
        self.fd = -1
        self.parents = {}

    def __enter__(self):
        libc = ctypes.CDLL(None, use_errno=True)
        init = libc.inotify_init1
        init.argtypes, init.restype = [ctypes.c_int], ctypes.c_int
        add = libc.inotify_add_watch
        add.argtypes, add.restype = [ctypes.c_int, ctypes.c_char_p, ctypes.c_uint32], ctypes.c_int
        self.fd = init(os.O_NONBLOCK | os.O_CLOEXEC)
        if self.fd < 0:
            raise SnapshotError('native write observation unavailable')
        try:
            for parent in sorted({str(Path(p).parent) for p in self.paths}):
                if Path(parent).is_symlink():
                    raise SnapshotError('write observation refuses a symlink parent')
                wd = add(self.fd, os.fsencode(parent), 0x00000008 | 0x00000080 | 0x00000100 |
                         0x00000200 | 0x00000400 | 0x00000800 | 0x01000000 | 0x02000000)
                if wd < 0:
                    raise SnapshotError('cannot watch an exact mutation parent')
                self.parents[wd] = parent
            return self
        except BaseException:
            self.__exit__(None, None, None)
            raise

    def changed_paths(self):
        changed, count = set(), 0
        while True:
            try:
                data = os.read(self.fd, 65536)
            except BlockingIOError:
                break
            if not data:
                break
            pos = 0
            while pos < len(data):
                if len(data) - pos < 16:
                    raise SnapshotError('truncated write-observation event')
                wd, mask, _cookie, size = struct.unpack_from('iIII', data, pos)
                pos += 16
                if size > len(data) - pos:
                    raise SnapshotError('truncated write-observation name')
                name = os.fsdecode(data[pos:pos + size].split(b'\0', 1)[0])
                pos += size
                count += 1
                if count > 16384 or mask & (0x4000 | 0x2000 | 0x8000 | 0x0400 | 0x0800):
                    raise SnapshotError('write observation lost events or its watched parent')
                path = str(Path(self.parents.get(wd, '/')) / name)
                if path in self.paths and mask & (0x08 | 0x80 | 0x100 | 0x200):
                    changed.add(path)
        return sorted(changed)

    def __exit__(self, *_):
        if self.fd >= 0:
            os.close(self.fd)
            self.fd = -1


def stage_edit(path, marker, backup_dir):
    """Keep private recovery bytes before an exact test-owned outside edit."""
    path = str(path)
    before = snapshot_paths([path])[path]
    if before['type'] != 'file' or before['bytes'] > 8 * 1024 * 1024:
        raise SnapshotError('outside-edit fixture requires a bounded existing regular file')
    backup_dir = Path(backup_dir)
    try:
        backup_dir.mkdir(mode=0o700)
        created = True
    except FileExistsError:
        created = False
    if created:
        created_info = backup_dir.lstat()
        fd = os.open(backup_dir, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            info = os.fstat(fd)
            if (info.st_dev, info.st_ino) != (created_info.st_dev, created_info.st_ino):
                raise SnapshotError('new fixture directory was replaced')
            os.fchmod(fd, 0o700)
        finally:
            os.close(fd)
    if backup_dir.is_symlink() or stat.S_IMODE(backup_dir.stat().st_mode) != 0o700:
        raise SnapshotError('fixture backup directory is not private')
    fd = os.open(path, os.O_RDWR | os.O_NOFOLLOW)
    try:
        before_info = os.fstat(fd)
        if not stat.S_ISREG(before_info.st_mode) or before_info.st_nlink != 1:
            raise SnapshotError('outside edit refuses special files and hardlinks')
        original = os.read(fd, before['bytes'] + 1)
        if hashlib.sha256(original).hexdigest() != before['sha256'] or snapshot_paths([path])[path] != before:
            raise SnapshotError('outside-edit pre-state changed')
        target = backup_dir / (uuid.uuid4().hex + '.json')
        token = {'path': path, 'original_b64': base64.b64encode(original).decode(),
                 'before': before, 'mtime_ns': before_info.st_mtime_ns,
                 'atime_ns': before_info.st_atime_ns, 'status': 'prepared'}
        with target.open('x', encoding='utf-8') as handle:
            os.chmod(target, 0o600)
            json.dump(token, handle); handle.flush(); os.fsync(handle.fileno())
        if os.stat(path, follow_symlinks=False).st_ino != before_info.st_ino:
            raise SnapshotError('outside-edit target was replaced')
        os.lseek(fd, 0, os.SEEK_END)
        payload = marker.encode()
        written = 0
        while written < len(payload):
            written += os.write(fd, payload[written:])
        os.fsync(fd)
        token['edited'] = snapshot_paths([path])[path]
        token['status'] = 'edited'
        token['backup'] = str(target)
        with target.open('w', encoding='utf-8') as handle:
            json.dump(token, handle); handle.flush(); os.fsync(handle.fileno())
        return token
    finally:
        os.close(fd)


def restore_edit(token):
    """Undo only this fixture's bytes, and never a conflicting later change."""
    path = token['path']
    if snapshot_paths([path])[path] != token['edited']:
        raise SnapshotError('fixture target changed after test edit; private backup retained')
    fd = os.open(path, os.O_RDWR | os.O_NOFOLLOW)
    try:
        info = os.fstat(fd)
        current = os.stat(path, follow_symlinks=False)
        if info.st_ino != current.st_ino or info.st_dev != current.st_dev:
            raise SnapshotError('fixture target was replaced before restore')
        data = base64.b64decode(token['original_b64'], validate=True)
        # Recheck immediately before the write. This is a test-owned fixture on
        # a disposable host, not an adversary-safe replacement for the ledger.
        if snapshot_paths([path])[path] != token['edited']:
            raise SnapshotError('fixture conflict before restore')
        os.ftruncate(fd, 0)
        offset = 0
        while offset < len(data):
            offset += os.write(fd, data[offset:])
        os.fsync(fd)
        os.utime(fd, ns=(token['atime_ns'], token['mtime_ns']))
    finally:
        os.close(fd)
    if snapshot_paths([path])[path] != token['before']:
        raise SnapshotError('fixture cleanup did not reproduce its pre-state')
    backup = token.get('backup')
    if backup:
        token['status'] = 'restored'
        with open(backup, 'w', encoding='utf-8') as handle:
            json.dump(token, handle); handle.flush(); os.fsync(handle.fileno())
    return True
