#!/usr/bin/env python3
"""Read-only-release regression probes for Sentinel Blue 2.0.10 Linux.

All writes occur in disposable fixtures. Native systemctl enable/disable tests
ALWAYS use --root=<temporary-directory>. Daemon operations are inert. Never
point these tests at a live Sentinel state directory. The GUI test needs DISPLAY
(e.g. xvfb-run -a). No service is installed, started, stopped, or contacted.

Default exit 0 means collection completed, NOT that the release is correct.
--assert-correctness returns 1 when a reproduced defect remains.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import tempfile
from types import SimpleNamespace
from unittest.mock import patch
import uuid


def withdrawal_probe():
    from sentinel_blue.withdrawal_native import NativeObjects, object_target
    from sentinel_blue.mutation_ledger import LedgerError
    if os.name != 'posix' or not shutil.which('systemctl'):
        return {'id': 'SB210-R2-01', 'skipped': 'native systemctl unavailable'}
    cases = []
    for initial in ('enabled-runtime', 'disabled'):
        with tempfile.TemporaryDirectory(prefix='sb210-offline-systemctl-') as td:
            root = Path(td)
            units = root / 'usr/lib/systemd/system'
            units.mkdir(parents=True)
            name = 'sentinel-review-fixture.service'
            unit = ('[Unit]\nDescription=Isolated review fixture\n[Service]\n'
                    'Type=oneshot\nExecStart=/bin/true\n[Install]\nWantedBy=multi-user.target\n')
            (units / name).write_text(unit)
            (units / 'multi-user.target').write_text('[Unit]\nDescription=Isolated target\n')
            calls = []
            def command(*args, **kwargs):
                if args[0] != 'systemctl':
                    raise AssertionError('Only isolated systemctl is allowed')
                if args[1] in {'start', 'stop', 'restart', 'daemon-reload'}:
                    calls.append({'argv': list(args), 'inert': True})
                    return subprocess.CompletedProcess(args, 0, '', '')
                actual = [shutil.which('systemctl'), '--root=' + str(root), *args[1:]]
                result = subprocess.run(actual, capture_output=True, text=True, timeout=10)
                calls.append({'argv': actual, 'rc': result.returncode,
                              'stdout': result.stdout, 'stderr': result.stderr})
                if result.returncode not in kwargs.get('allowed', (0,)):
                    raise RuntimeError('isolated systemctl failed: ' + result.stderr)
                return result
            def state(_=name):
                enabled = command('systemctl', 'is-enabled', name, allowed=(0, 1)).stdout.strip()
                return {'exists': True, 'enabled': enabled, 'active': False,
                        'configuration': unit}
            if initial == 'enabled-runtime':
                command('systemctl', 'enable', '--runtime', name)
            target = object_target(services=[name])
            adapter = object.__new__(NativeObjects)
            adapter.service = state
            before = adapter.snapshot(target)
            assert before['services'][name]['enabled'] == initial
            command('systemctl', 'enable', name)
            expected = adapter.snapshot(target)
            assert expected['services'][name]['enabled'] == 'enabled'
            error = None
            with patch('sentinel_blue.setup_linux_transaction.command', side_effect=command):
                try:
                    adapter.restore(target, before, expected)
                except LedgerError as exc:
                    error = str(exc)
            after = adapter.snapshot(target)
            cases.append({'initial': initial, 'post_apply': 'enabled',
                          'after_withdraw': after['services'][name]['enabled'],
                          'error': error, 'matches_before': after == before,
                          'links': [str(p.relative_to(root)) for p in root.rglob('*') if p.is_symlink()],
                          'calls': calls})
    return {'id': 'SB210-R2-01', 'cases': cases,
            'bug_reproduced': not cases[0]['matches_before'] and bool(cases[0]['error']),
            'control_passed': cases[1]['matches_before'] and cases[1]['error'] is None}


def repair_history_probe():
    from test_service_repair import RepairExecutionTests
    from sentinel_blue.agent import refresh_recovery_health
    fixture = RepairExecutionTests('test_file_restore_and_start_commit_together_and_support_exact_undo')
    fixture.setUp()
    try:
        # Fixture writes/restores a temporary config; actual service control is inert.
        with patch.object(fixture.executor.repairs, '_transition',
                          side_effect=lambda s, d: fixture.change_state(s, d)):
            result = fixture.run_repair()
        assert result['success'], result
        initial_path = next(fixture.executor.state_dir.glob('service-repair-*.json'))
        template = fixture.executor.repairs._read(initial_path)
        assert template['status'] == 'committed'
        for _ in range(255):
            record = copy.deepcopy(template)
            record['transaction_id'] = str(uuid.uuid4())
            fixture.executor.repairs._write(record)
        at256 = fixture.executor.repairs.reconcile()
        record = copy.deepcopy(template)
        record['transaction_id'] = str(uuid.uuid4())
        fixture.executor.repairs._write(record)
        validated = sum(bool(fixture.executor.repairs._read(p))
                        for p in fixture.executor.state_dir.glob('service-repair-*.json'))
        at257 = fixture.executor.repairs.reconcile()
        health = {'healthy': True, 'action_safe': True, 'errors': [], 'critical_errors': []}
        refresh_recovery_health(fixture.executor, health)
        warnings = fixture.executor._prune_service_transactions()
        after_prune = fixture.executor.repairs.reconcile()
        return {'id': 'SB210-R2-02', 'initial_temporary_file_repair_passed': result['success'],
                'history_construction': '256 copies of one real terminal journal with fresh parent UUIDs; not 257 live repairs',
                'validated_terminal_journals': validated, 'at256': at256, 'at257': at257,
                'agent_health': health, 'after_existing_prune': after_prune, 'prune_warnings': warnings,
                'bug_reproduced': at256['healthy'] and not at257['healthy'] and not health['action_safe'],
                'control_passed': at256['healthy'] and validated == 257}
    finally:
        fixture.doCleanups()


def activation_probe():
    from sentinel_blue.linux_service_packs import build, BUILDERS
    from sentinel_blue.linux_service_catalog import entry
    from sentinel_blue import service_pack_checks as checks
    cases = []
    with tempfile.TemporaryDirectory(prefix='sb210-activation-') as td:
        for sid, options in (
            ('haproxy', {'frontend_port': 8080, 'backends': [{'address': '127.0.0.1', 'port': 9000}]}),
            ('samba', {'share': 'reviewshare', 'path': '/srv/reviewshare', 'valid_users': ['reviewuser']}),
            ('samba', {'share': 'reviewshare', 'path': '/srv/reviewshare', 'valid_users': ['reviewuser'],
                       'smb_port': 445, 'netbios_port': 139}),
        ):
            generated, extra = BUILDERS[sid](options)
            metadata = {}
            compiled = build(sid, options, Path(td), metadata=metadata)
            spec = {**extra, 'service_id': sid, 'generated': list(generated)}
            # Instrument the real product-specific validator. No native daemon is
            # executed. For Samba's port query, model an existing default listener.
            with patch.object(checks, '_command', return_value='445 139\n') as commands, \
                    patch.object(checks, '_read', return_value=b'[global]\n    smb ports = 445 139\n') as reads:
                guard_error = None
                try:
                    checks.run_checks(spec, 'configuration')
                except ValueError as exc:
                    guard_error = str(exc)
                calls = [list(c.args[0]) for c in commands.call_args_list]
                read_count = reads.call_count
            case = {'service': sid, 'options': options, 'generated_paths': list(generated),
                    'activation_supplied': False, 'permitted_activation': extra.get('activation_lines', {}),
                    'compiled_file_paths': [x['path'] for x in metadata['files']],
                    'native_syntax_command': entry(sid)['validate_argv'],
                    'configuration_guard_returned': 'refused' if guard_error else 'success',
                    'configuration_guard_error': guard_error, 'guard_commands': calls,
                    'parent_reads': read_count}
            if sid == 'haproxy':
                assert '/usr/sbin/haproxy -c -f /etc/haproxy/haproxy.cfg' in compiled[0]
                try:
                    build(sid, dict(options, activation={'/etc/haproxy/haproxy.cfg': {}}), Path(td))
                except ValueError as exc:
                    case['activation_request_error'] = str(exc)
            if extra.get('smb_ports'):
                try:
                    with patch.object(checks, '_command', return_value='1445 1139\n'):
                        checks.run_checks(spec, 'configuration')
                except ValueError as exc:
                    case['wrong_port_control_error'] = str(exc)
            cases.append(case)
    return {'id': 'SB210-R2-03', 'cases': cases,
            'scope': 'Compiler and validator omissions reproduced; no live HAProxy/Samba daemon or end-to-end setup success claimed',
            'bug_reproduced': all(len(c['compiled_file_paths']) == 1 and c['parent_reads'] == 0 for c in cases)
                              and cases[0]['guard_commands'] == [] and all(c['configuration_guard_error'] is None for c in cases),
            'control_passed': 'activation_request_error' in cases[0] and 'wrong_port_control_error' in cases[2]}


def form_probe():
    if not os.environ.get('DISPLAY'):
        return {'id': 'SB210-R2-04', 'skipped': 'DISPLAY unavailable; run under xvfb-run'}
    import tkinter as tk
    from tkinter import ttk
    from sentinel_blue.linux_service_forms import ServiceForm
    root = tk.Tk()
    root.withdraw()
    cases = []
    try:
        with tempfile.TemporaryDirectory(prefix='sb210-review-form-') as td:
            for name, original, protocol, clear_tls in (
                ('switch_imap_to_pop3', {'protocols': ['imap'], 'imap_port': 143}, 'pop3', False),
                ('fresh_pop3_control', {}, 'pop3', False),
                ('remove_tls', {'protocols': ['imap'], 'imap_port': 143, 'imaps_port': 993,
                                'ssl_certificate_path': '/etc/ssl/cert.pem', 'ssl_key_path': '/etc/ssl/key.pem'}, 'imap', True),
                ('plain_imap_control', {'protocols': ['imap'], 'imap_port': 143}, 'imap', False),
            ):
                panel = SimpleNamespace(tk=tk, ttk=ttk, tree=root, options={'dovecot': copy.deepcopy(original)},
                                        options_root=Path(td), port_requirements={}, selection=[], refresh=lambda: None)
                form = ServiceForm(panel, 'dovecot')
                form.inputs['protocols'].delete('1.0', 'end')
                form.inputs['protocols'].insert('1.0', protocol)
                if clear_tls:
                    form.inputs['ssl_certificate_path'].set('')
                    form.inputs['ssl_key_path'].set('')
                form.save()
                root.update_idletasks()
                cases.append({'name': name, 'saved': bool(panel.selection), 'message': form.error.get(),
                              'result': panel.options['dovecot'], 'visible_fields': list(form.inputs)})
                if form.window.winfo_exists():
                    form.window.destroy()
    finally:
        root.destroy()
    return {'id': 'SB210-R2-04', 'cases': cases,
            'bug_reproduced': not cases[0]['saved'] and not cases[2]['saved'],
            'control_passed': cases[1]['saved'] and cases[3]['saved']}


def gunicorn_probe():
    from sentinel_blue.linux_service_packs import _gunicorn
    # The one relevant expression below is from Gunicorn 23.0.0 util.py,
    # parse_address()'s unbracketed colon branch (MIT-licensed upstream).
    # https://raw.githubusercontent.com/benoitc/gunicorn/23.0.0/gunicorn/util.py
    # This is a narrow source-based parsing probe, NOT a native Gunicorn run.
    def parser_reference(netloc, default_port='8000'):
        if netloc.startswith('['):
            closing = netloc.index(']')
            return netloc[1:closing].lower(), int(netloc[closing + 2:])
        host, port = (netloc.split(':') + [default_port])[:2]
        return host.lower(), int(port)
    cases = []
    for address in ('::1', '2001:db8::1', '127.0.0.1'):
        generated, _ = _gunicorn({'application': 'app:application', 'working_directory': '/srv/reviewapp',
                                  'user': 'reviewuser', 'bind_address': address, 'port': 8000})
        content = next(iter(generated.values()))
        executable = next(x.split('=', 1)[1] for x in content.splitlines() if x.startswith('ExecStart='))
        argv = shlex.split(executable)
        value = argv[argv.index('--bind') + 1]
        result, error = None, None
        try:
            result = parser_reference(value)
        except ValueError as exc:
            error = str(exc)
        cases.append({'requested_address': address, 'generated_bind': value,
                      'parser_reference_result': result, 'parser_error': error})
    return {'id': 'SB210-R2-05', 'cases': cases,
            'scope': 'Actual generator output and published 23.0.0 non-bracket parsing branch; no installed Gunicorn or server run',
            'bug_reproduced': bool(cases[0]['parser_error']) and bool(cases[1]['parser_error']),
            'bracketed_control': parser_reference('[::1]:8000'),
            'control_passed': cases[2]['parser_reference_result'] == ('127.0.0.1', 8000)
                              and parser_reference('[::1]:8000') == ('::1', 8000)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--app', type=Path, help='Exact shipped .pyz; otherwise import source/src')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--assert-correctness', action='store_true')
    args = parser.parse_args()
    source = args.source.resolve()
    if not (source / 'tests/test_service_repair.py').is_file():
        parser.error('--source must be the extracted project root containing src/ and tests/')
    app = args.app.resolve() if args.app else source / 'src'
    if not app.exists():
        parser.error('application import path does not exist')
    sys.path[:0] = [str(app), str(source / 'tests')]
    import sentinel_blue
    findings = [probe() for probe in (withdrawal_probe, repair_history_probe, activation_probe, form_probe, gunicorn_probe)]
    data = {'version': sentinel_blue.__version__, 'application': sentinel_blue.__file__,
            'python': sys.version, 'findings': findings,
            'summary': {'findings_reproduced': sum(bool(f.get('bug_reproduced')) for f in findings),
                        'control_groups_passed': sum(bool(f.get('control_passed')) for f in findings),
                        'skipped': sum('skipped' in f for f in findings)}}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(data, indent=2) + '\n')
    print(json.dumps(data['summary'], indent=2))
    return 1 if args.assert_correctness and data['summary']['findings_reproduced'] else 0


if __name__ == '__main__':
    raise SystemExit(main())
