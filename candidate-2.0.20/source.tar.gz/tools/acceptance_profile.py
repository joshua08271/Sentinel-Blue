"""Read-only acceptance input contracts, checked before admitting a mutation.

Compilation/refusal tests are not native failed-apply/rollback tests. All probes
are trusted operator code, but their declared success/denial evidence must be
explicit; a command failing to connect is not a successful access-denial test.
"""
from __future__ import annotations

import copy
from pathlib import Path
from typing import Any

MATCH_FIELDS = tuple('expect_' + stream + '_' + operation
                     for stream in ('stdout', 'stderr', 'output')
                     for operation in ('contains', 'absent'))
PROBE_KEYS = {'argv', 'expect_returncode', 'expect_failure', *MATCH_FIELDS}
REQUIRED = ('positive', 'denied', 'effective', 'update_options', 'invalid_options', 'withdrawal')
MAX_PROBES = 64


def option_data(value: dict) -> dict:
    if not isinstance(value, dict) or any(not isinstance(k, str) for k in value):
        raise ValueError('service options must be an object with string keys')
    return {k: copy.deepcopy(v) for k, v in value.items() if not k.startswith('_')}


def probe_problems(spec: Any, label: str, *, denial: bool = False,
                   success: bool = False) -> list[str]:
    """Validate data, without resolving hosts, launching clients, or assuming health."""
    if not isinstance(spec, dict) or not spec:
        return [label + ' requires a product-specific probe object']
    problems = []
    if any(not isinstance(k, str) for k in spec):
        return [label + ' contains a non-string key']
    unknown = {k for k in spec if not k.startswith('_')} - PROBE_KEYS
    if unknown:
        problems.append(label + ' contains unsupported fields: ' + ', '.join(sorted(unknown)))
    argv = spec.get('argv')
    if (not isinstance(argv, list) or not 1 <= len(argv) <= 64 or
            any(not isinstance(x, str) or not x or '\x00' in x or len(x) > 4096 for x in argv)):
        problems.append(label + ' requires a bounded literal argv array')
    problems.extend(argv_safety_problems(argv, label))
    for key in MATCH_FIELDS:
        if key in spec and (not isinstance(spec[key], list) or len(spec[key]) > 32 or
                any(not isinstance(x, str) or not x or '\x00' in x or len(x) > 1024 for x in spec[key])):
            problems.append(label + ': ' + key + ' requires bounded nonempty literal match strings')
    code = spec.get('expect_returncode')
    if 'expect_returncode' in spec and (type(code) is not int or not 0 <= code <= 255):
        problems.append(label + ': expect_returncode must be an integer from 0 to 255')
    if 'expect_failure' in spec and type(spec['expect_failure']) is not bool:
        problems.append(label + ': expect_failure must be a boolean')
    if success and (spec.get('expect_failure') is True or code not in (None, 0)):
        problems.append(label + ' must prove command success, not request a failing exit status')
    if denial:
        if not any(isinstance(spec.get(k), list) and spec[k]
                   for k in ('expect_stdout_contains', 'expect_stderr_contains', 'expect_output_contains')):
            problems.append(label + ' requires an explicit product refusal signature; a connection/client failure alone is not denial')
        if spec.get('expect_failure') is False and 'expect_returncode' not in spec:
            problems.append(label + ' must specify the refusal exit status or expect_failure=true')
    elif success and code == 0 and spec.get('expect_failure') is True:
        problems.append(label + ' has contradictory success/failure expectations')
    return problems


def transition_problems(before: dict, after: dict, label: str) -> list[str]:
    """Check *reviewed* preconditions; never silently rewrite an approved option set."""
    old = {row['path']: row for row in before['files']}
    new = {row['path']: row for row in after['files']}
    errors = []
    if not old or not new:
        return [label + ' needs a nonempty generated-file contract']
    if {p: (r['sha256'], r.get('mode')) for p, r in old.items()} == {
            p: (r['sha256'], r.get('mode')) for p, r in new.items()}:
        errors.append(label + ' must change generated configuration, not only review metadata')
    for path in sorted(old.keys() & new.keys()):
        if (new[path]['sha256'], new[path].get('mode')) != (old[path]['sha256'], old[path].get('mode')):
            if new[path].get('previous_sha256') != old[path]['sha256']:
                errors.append(label + ': reviewed previous_sha256 must match the preceding generated state for ' + path)
    return errors


def profile_problems(service_id: str, options: Any, profile: Any, root: Path) -> list[str]:
    """Return every discoverable blocker before the first runtime apply.

    Native failed-apply options must compile; whether the actual product rejects
    them *after writes* is proved only by the later isolated native test. The
    optional rejected_options field is separately checked as a planning refusal.
    """
    from sentinel_blue.pack_acceptance import pack_contract
    from sentinel_blue.linux_service_catalog import entry

    if not isinstance(options, dict) or not isinstance(profile, dict):
        return ['reviewed options and profile must be objects']
    errors = []
    for key in REQUIRED:
        if not isinstance(profile.get(key), dict) or not profile[key]:
            errors.append(key + ' is missing or empty')
    for key in ('positive', 'denied', 'effective', 'config_test'):
        if key in profile:
            errors.extend(probe_problems(profile[key], key, denial=key == 'denied', success=key != 'denied'))
    if not profile.get('config_test') and not entry(service_id).get('validate_argv'):
        errors.append('config_test is required for this product')
    spec = profile.get('withdrawal')
    if isinstance(spec, dict) and spec:
        if set(spec) != {'runtime_argv', 'inventory', 'event_profile', 'directory'}:
            errors.append('withdrawal requires runtime_argv, inventory, event_profile and directory only')
        argv = spec.get('runtime_argv')
        if (not isinstance(argv, list) or not 1 <= len(argv) <= 64 or
                any(not isinstance(x, str) or not x or '\x00' in x or len(x) > 4096 for x in argv)):
            errors.append('withdrawal requires a bounded literal argv prefix')
        elif not Path(argv[0]).is_absolute():
            errors.append('withdrawal forwarding executable must be an absolute reviewed path')
        for key in ('inventory', 'event_profile', 'directory'):
            value = spec.get(key)
            if (not isinstance(value, str) or not value.startswith('/') or '\x00' in value or
                    len(value) > 4096 or '..' in value.split('/') or 'REPLACE' in value.split('/')):
                errors.append('withdrawal ' + key + ' requires a real absolute observer path, not a placeholder')
    if isinstance(spec, dict) and isinstance(spec.get('runtime_argv'), list):
        errors.extend(argv_safety_problems(spec['runtime_argv'], 'withdrawal'))
    invariants = profile.get('data_invariants', {})
    if not isinstance(invariants, dict) or set(invariants) - set(entry(service_id)['data_paths']):
        errors.append('data_invariants must map catalog data paths to deterministic product queries')
    else:
        for path, probe in invariants.items():
            errors.extend(probe_problems(probe, 'data_invariants ' + path, success=True))
    contracts = {}
    for key, value in (('options', options), ('update_options', profile.get('update_options')),
                       ('invalid_options', profile.get('invalid_options'))):
        if not isinstance(value, dict) or (key != 'options' and not value):
            continue
        try:
            contracts[key] = pack_contract(service_id, option_data(value), root)
        except (ValueError, TypeError, KeyError, OSError) as exc:
            text = (' must compile before apply; a planning refusal cannot prove failed-apply rollback: '
                    if key == 'invalid_options' else ' does not compile: ')
            errors.append(key + text + str(exc)[:300])
    if 'options' in contracts and 'update_options' in contracts:
        errors.extend(transition_problems(contracts['options'], contracts['update_options'], 'update_options'))
    if 'update_options' in contracts and 'invalid_options' in contracts:
        errors.extend(transition_problems(contracts['update_options'], contracts['invalid_options'], 'invalid_options'))
    if 'rejected_options' in profile:
        rejected = profile['rejected_options']
        if not isinstance(rejected, dict) or not rejected:
            errors.append('rejected_options must be a nonempty builder-refusal example')
        else:
            try:
                pack_contract(service_id, option_data(rejected), root)
            except ValueError:
                pass
            except (TypeError, KeyError, OSError) as exc:
                errors.append('rejected_options failed without the expected controlled refusal: ' + type(exc).__name__)
            else:
                errors.append('rejected_options was accepted; it does not prove a planning refusal')
    return list(dict.fromkeys(errors))


def argv_safety_problems(argv: Any, label: str) -> list[str]:
    """Reject known unsafe draft client forms, not claim to audit arbitrary wrappers.

    Native probes are trusted, reviewed operator code. This catches the cleartext
    password and disabled-peer-verification patterns previously shipped as drafts.
    It never echoes the argument value or a potential secret into a report.
    """
    if not isinstance(argv, list) or not argv or any(not isinstance(x, str) for x in argv):
        return []  # Shape checks produce the actual error.
    from urllib.parse import urlsplit
    program = Path(argv[0]).name
    errors = []
    secret = False
    flags = {'redis-cli': {'-a', '--pass', '--password'},
             'mosquitto_sub': {'-P', '--pw'}, 'mosquitto_pub': {'-P', '--pw'},
             'curl': {'-u', '--user', '--proxy-user'},
             'swaks': {'--auth-password'},
             'mysql': {'--password'}, 'mariadb': {'--password'}}.get(program, set())
    for i, arg in enumerate(argv[1:], 1):
        if any(arg == flag or arg.startswith(flag + '=') or
               (flag.startswith('-') and not flag.startswith('--') and arg.startswith(flag) and len(arg) > len(flag))
               for flag in flags):
            secret = True
        if program == 'smbclient' and ((arg == '-U' and i + 1 < len(argv) and '%' in argv[i + 1]) or
                                     (arg.startswith('-U') and '%' in arg[2:])):
            secret = True
        if program in {'mysql', 'mariadb'} and arg.startswith('-p') and len(arg) > 2 and not arg.startswith('--'):
            secret = True
        if '://' in arg:
            try:
                if urlsplit(arg).password is not None:
                    secret = True
            except ValueError:
                errors.append(label + ': malformed URL argument')
        if program == 'curl' and (arg in {'--insecure', '-k'} or arg.lower().startswith('authorization:')):
            errors.append(label + ': certificate verification bypass or inline authorization is not permitted')
        if program in {'ssh', 'sftp', 'scp'}:
            setting = arg[2:] if arg.startswith('-o') else arg
            import re
            fields = re.split(r'[=\s]+', setting.strip().lower(), maxsplit=1)
            setting = '='.join(fields)
            if setting in {'stricthostkeychecking=no', 'stricthostkeychecking=off',
                           'stricthostkeychecking=false', 'userknownhostsfile=/dev/null'}:
                errors.append(label + ': SSH peer verification must use reviewed host keys')
    if secret:
        errors.append(label + ': password-bearing argv is refused; use a protected client configuration or reviewed credential wrapper')
    return list(dict.fromkeys(errors))
