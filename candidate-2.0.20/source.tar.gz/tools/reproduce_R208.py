"""Independent 2.0.8 review (R208) reproductions and controls.

Real private files, SQLite, history archival and signed loopback controller
HTTP; the setup worker's native transport is the repository's modeled fixture
and no worker process is launched. Nothing outside temporary directories is
changed. Run with the bundled interpreter as root (the suite's private-fixture
convention), e.g.:

    python3 -I -B tools/reproduce_R208.py --source . --output r208.json --assert-correctness

On unchanged 2.0.8 the correctness assertions fail and the controls pass.
"""
import argparse
import copy
import json
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import patch

DIRTY = {'success': False, 'rolled_back': False, 'review_required': True, 'errors': ['start', 'rollback']}
CLEAN = {'success': False, 'rolled_back': True, 'errors': ['start failed']}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--assert-correctness', action='store_true')
    args = parser.parse_args()
    source = Path(args.source).resolve()
    sys.path[:0] = [str(source / 'src'), str(source / 'tests'), str(source)]
    import sentinel_blue
    from sentinel_blue import desktop_jobs, setup_redo
    from sentinel_blue.controller import ControllerApp, ControllerServer, make_handler, OPERATOR_REPLAY_MARKERS
    from sentinel_blue.desktop_control import DesktopClient
    from sentinel_blue.event_profile import EventProfile
    from sentinel_blue.job_control import JobControl
    from sentinel_blue.redo_governance import CHECK_PATH, WorkerGuard, prepare_guard
    from sentinel_blue.setup import SetupRunner, compile_plan, plan_digest
    from sentinel_blue.state import write_private_json
    from sentinel_blue.store import Store
    from sentinel_blue.history_storage import HistoryPolicy, HistoryStorage, MIB
    from redo_gate_fixture import live_client
    from test_service_repair import damage, repair_fixture
    from test_setup import FixtureTransport, fixture as setup_fixture, healthy_probe
    import test_session_alert_continuity as continuity

    holders = []

    class Holder(unittest.TestCase):
        def runTest(self):
            pass

        def __init__(self):
            super().__init__()
            holders.append(self)

    def insert(store, name, service, result, *, status='failed', age=1000, agent='local-linux'):
        at = time.time() - age
        store._connection.execute(
            "INSERT INTO actions(action_id,agent_id,action_type,parameters_json,status,created_at,completed_at,result_json) "
            "VALUES(?,?,?,?,?,?,?,?)", (name, agent, 'repair_service', json.dumps({'service': service}), status,
                                        at - 5, at, None if result is None else json.dumps(result)))
        store._connection.commit()

    def environment(root, *, two=False):
        holder = Holder()
        path = root / 'target' / 'web.conf'
        path.parent.mkdir(parents=True)
        path.write_bytes(b'trusted')
        path.chmod(0o600)
        profile, base = repair_fixture(str(path))
        raw = copy.deepcopy(profile.raw)
        raw['services'][0]['host'] = 'local-linux'
        if two:
            db = copy.deepcopy(raw['services'][0])
            db['service_id'] = 'db.service'
            db['expected_transactions'] = [{'name': 'local-db', 'kind': 'http', 'target': 'http://127.0.0.1:8766/health'}]
            db['repair_policy'] = dict(db['repair_policy'], restore_files=[])
            raw['services'].append(db)
            base['services'].append({'name': 'db.service', 'state': 'running'})
            base['probes'].append({'name': 'local-db', 'target': 'http://127.0.0.1:8766/health', 'healthy': True})
        profile = EventProfile.from_dict(raw)
        base['agent_id'] = 'local-linux'
        base['observed_at'] = time.time()
        app, store, client = live_client(holder, profile, base)
        write_private_json(root / 'profile.json', profile.raw)
        workspace = root / 'session'
        workspace.mkdir(mode=0o700)
        original = root / 'jobs/original/job.json'
        original.parent.mkdir(mode=0o700, parents=True)
        write_private_json(original, {'kind': 'setup'})
        write_private_json(original.parent / 'result.json', {'status': 'passed'})
        write_private_json(root / 'inventory.json', {'hosts': [{'name': 'local-linux', 'address': '127.0.0.1'}],
            'setup': {'tasks': [{'id': 't-web', 'host': 'local-linux', 'service_id': 'web.service'}]}})
        record = setup_redo.record_approved_setup(workspace, {
            'kind': 'setup', 'inventory': str(root / 'inventory.json'), 'event_profile': str(root / 'profile.json'),
            'runtime': str(root / 'sb.pyz'), 'range_deployment': True, 'approved_digest': 'a' * 64},
            job_root=root / 'jobs', job_path=original)
        state = setup_redo.load_state(workspace)
        state['seen_healthy'] = ['web.service']
        setup_redo.save_state(workspace, state)
        path.write_bytes(b'damaged')
        current = damage(base, 2)
        current['observed_at'] = time.time()
        app.ingest(current)
        return dict(holder=holder, app=app, store=store, client=client, profile=profile, workspace=workspace,
                    record=record, root=root)

    def launcher(job, directory):
        directory.mkdir(parents=True, exist_ok=True)
        write_private_json(directory / 'job.json', job)
        return None, directory / 'job.json'

    measured = {'version': sentinel_blue.__version__, 'application': sentinel_blue.__file__, 'python': sys.version,
                'scope': 'Private files, SQLite, history archival and signed loopback controller HTTP; modeled '
                         'setup transport; no worker process, VM, service or network change.'}
    assertions = []

    def check(name, passed, *, control=False, finding=''):
        assertions.append({'name': name, 'finding': finding, 'passed': bool(passed), 'control': control})

    started = time.monotonic()
    with tempfile.TemporaryDirectory(prefix='sb-r208-') as home:
        home = Path(home)

        # R208-01: operator-started redo through the GUI path.
        with tempfile.TemporaryDirectory(dir=home) as temp:
            env = environment(Path(temp))
            env['app'].set_autonomy_mode('approval-based')
            answer = env['client'].request(CHECK_PATH, {'profile_fingerprint': env['profile'].fingerprint,
                                                        'services': [['local-linux', 'web.service']], 'automated': False})
            try:
                entry = setup_redo.manual_redo(env['workspace'], None, client=env['client'], launcher=launcher)
                outcome = {'launched': entry['units']}
            except Exception as exc:
                outcome = {'refused': f'{type(exc).__name__}: {exc}'[:300]}
            measured['manual_redo'] = {'controller_check': answer.get('allowed'), 'gui_path': outcome}
            check('controller_permits_manual_redo', answer.get('allowed') is True, control=True, finding='R208-01')
            check('gui_manual_redo_launches', 'launched' in outcome, finding='R208-01')
            # A controller whose clock differs from this machine's (network GUI).
            skewed = []
            for offset in (-120, 120):
                snapshot = env['client'].dashboard()
                snapshot['controller']['setup_redo_policy']['observed_at'] += offset
                verdict = setup_redo.assess(snapshot, env['record'], setup_redo.load_state(env['workspace']), time.time())
                skewed.append({'controller_clock_offset': offset, 'web.service': verdict['units']['web.service']})
            measured['clock_skew'] = skewed
            check('controller_clock_skew_does_not_hold_redo',
                  all('fresh complete' not in row['web.service']['reason'] for row in skewed), finding='R208-01')

        # R208-02: hold scope.
        with tempfile.TemporaryDirectory(dir=home) as temp:
            env = environment(Path(temp), two=True)
            insert(env['store'], 'dirty-db', 'db.service', DIRTY)
            def allowed(service):
                return env['client'].request(CHECK_PATH, {'profile_fingerprint': env['profile'].fingerprint,
                    'services': [['local-linux', service]], 'automated': False})['allowed']
            policy = {row['service']: row['holds'] for row in
                      env['client'].dashboard()['controller']['setup_redo_policy']['services']}
            measured['hold_scope'] = {'policy': policy, 'web_allowed': allowed('web.service'),
                                      'db_allowed': allowed('db.service')}
            check('other_service_failure_does_not_hold_redo', measured['hold_scope']['web_allowed'], finding='R208-02')
            check('failed_service_itself_stays_held', not measured['hold_scope']['db_allowed'], control=True,
                  finding='R208-02')

        # R208-03: worker polling and Emergency Stop availability.
        with tempfile.TemporaryDirectory(dir=home) as temp:
            env = environment(Path(temp))
            pairs = [['local-linux', 'web.service']]
            guard = WorkerGuard({'redo_guard_file': prepare_guard(env['client'], Path(temp) / 'job', pairs, False,
                                                                  env['profile']), 'only_services': pairs}, env['profile'])
            before = env['store']._connection.execute('SELECT COUNT(*) FROM operator_request_replay').fetchone()[0]
            with tempfile.TemporaryDirectory(dir=home) as plan_root:
                plan_root = Path(plan_root)
                inventory, setup_profile = setup_fixture(plan_root, hosts=1, budget=70)
                inventory['setup']['tasks'][0]['timeout_seconds'] = 40
                plan = compile_plan(inventory, setup_profile, plan_root)
                transport = FixtureTransport()
                transport.delay = 10.0
                clock = time.monotonic()
                report = SetupRunner(plan, setup_profile, transport=transport, probe=healthy_probe,
                                     checkpoint=guard.checkpoint).execute(plan_root / 'state', plan_digest(plan))
                wall = time.monotonic() - clock
            checks = env['store']._connection.execute('SELECT COUNT(*) FROM operator_request_replay').fetchone()[0] - before
            rate = checks / wall
            measured['worker_polling'] = {'apply_seconds': 10.0, 'wall_seconds': round(wall, 2), 'signed_checks': checks,
                                          'checks_per_second': round(rate, 2),
                                          'replay_markers_per_300s': int(rate * 300), 'replay_capacity': OPERATOR_REPLAY_MARKERS,
                                          'status': report['status']}
            check('redo_worker_polls_at_most_once_per_second', rate <= 1.0, finding='R208-03')
        with tempfile.TemporaryDirectory(dir=home) as temp:
            holder = Holder()
            path = Path(temp) / 'web.conf'
            path.write_bytes(b'x')
            path.chmod(0o600)
            profile, base = repair_fixture(str(path))
            base['observed_at'] = time.time()
            app, store, client = live_client(holder, profile, base)
            request = {'profile_fingerprint': profile.fingerprint, 'services': [['agent-one', 'web.service']],
                       'automated': True}
            for _ in range(OPERATOR_REPLAY_MARKERS):
                client.request(CHECK_PATH, request)
            outcome = {}
            for name, call in (('dashboard', client.dashboard),
                               ('emergency_stop', lambda: client.request('/api/v1/governance/emergency-stop', {}))):
                try:
                    call()
                    outcome[name] = 'accepted'
                except Exception as exc:
                    outcome[name] = str(exc)[:120]
            outcome['controller_emergency_stopped'] = app.emergency_stopped
            measured['replay_exhaustion'] = outcome
            check('ordinary_traffic_is_still_bounded', outcome['dashboard'] != 'accepted', control=True, finding='R208-03')
            check('emergency_stop_survives_replay_exhaustion', app.emergency_stopped is True, finding='R208-03')

        # R208-04: connection material for a refused redo.
        with tempfile.TemporaryDirectory(dir=home) as temp:
            env = environment(Path(temp))
            control = JobControl(Path(temp) / 'jobs')
            control.initialize()
            control.set_paused(True)
            spawned = []
            with patch.object(desktop_jobs, 'detach', side_effect=lambda *a, **k: spawned.append(a)):
                for _ in range(5):
                    state = setup_redo.load_state(env['workspace'])
                    state['unhealthy_since'] = {'web.service': time.time() - 400}
                    setup_redo.save_state(env['workspace'], state)
                    verdict = setup_redo.tick(env['workspace'], env['client'].dashboard(), client=env['client'])
            orphans = list((Path(temp) / 'jobs').glob('job-redo-*/redo-control.json'))
            measured['paused_setup'] = {'ticks': 5, 'workers': len(spawned), 'orphan_connection_files': len(orphans),
                                        'last': verdict.get('last')}
            check('paused_setup_starts_no_worker', not spawned, control=True, finding='R208-04')
            check('paused_setup_leaves_no_connection_file', not orphans, finding='R208-04')

        # R208-05: bound counts unresolved repairs only.
        with tempfile.TemporaryDirectory(dir=home) as temp:
            env = environment(Path(temp))
            at = time.time() - 1000
            for prefix, result in (('clean', CLEAN),):
                env['store']._connection.executemany(
                    "INSERT INTO actions(action_id,agent_id,action_type,parameters_json,status,created_at,completed_at,result_json) "
                    "VALUES(?,?,?,?,?,?,?,?)", [(f'{prefix}{i}', 'local-linux', 'repair_service',
                    json.dumps({'service': 'web.service'}), 'failed', at + i, at + i + 1, json.dumps(result)) for i in range(4097)])
            env['store']._connection.commit()
            clock = time.perf_counter()
            holds = {row['service']: row['holds'] for row in
                     env['client'].dashboard()['controller']['setup_redo_policy']['services']}
            measured['clean_failures'] = {'rows': 4097, 'holds': holds, 'dashboard_ms': round((time.perf_counter() - clock) * 1000, 1)}
            check('clean_rollbacks_never_create_a_permanent_hold', holds.get('web.service') == [], finding='R208-05')

        # R208-07: production history archival and unresolved evidence.
        fixture = continuity.SessionAlertContinuityTests()
        fixture.setUp()
        try:
            store = fixture.store
            root = fixture.root / 'history'
            root.mkdir(mode=0o700)
            manager = HistoryStorage(store, root, fixture.key, HistoryPolicy(
                database_max_bytes=32 * MIB, archive_max_bytes=16 * MIB, archive_max_files=2,
                minimum_free_bytes=8 * MIB, backup_max_bytes=32 * MIB, minimum_online_seconds=60))
            insert(store, 'dirty-old', 'web.service', DIRTY, age=40 * 86400, agent='agent-one')
            insert(store, 'clean-old', 'web.service', CLEAN, age=40 * 86400, agent='agent-one')
            for _ in range(20):
                manager.maintain()
            remaining = sorted(row[0] for row in store._connection.execute(
                "SELECT action_id FROM actions WHERE action_type='repair_service'"))
            measured['history_archival'] = {'remaining_after_maintenance': remaining}
            check('clean_failure_is_archived', 'clean-old' not in remaining, control=True, finding='R208-07')
            check('unresolved_failure_survives_archival', 'dirty-old' in remaining, finding='R208-07')
        finally:
            fixture.tearDown()

        # R208-06: audit label for operator verification.
        with tempfile.TemporaryDirectory(dir=home) as temp:
            holder = Holder()
            path = Path(temp) / 'web.conf'
            path.write_bytes(b'trusted')
            path.chmod(0o600)
            profile, base = repair_fixture(str(path))
            base['observed_at'] = time.time()
            app, store, client = live_client(holder, profile, base)
            from test_store_controller import _promote_integrity_baseline
            _promote_integrity_baseline(app, store, 'agent-one')
            current = copy.deepcopy(base)
            current.update(sequence=2, observed_at=time.time())
            app.ingest(current)
            decisions = []
            original = store.resolve_repaired_incident
            def record(*a, **k):
                decisions.append(k.get('decision'))
                return original(*a, **k)
            with patch.object(store, 'resolve_repaired_incident', side_effect=record):
                app.close_recovered_incident('agent-one', 'web.service', 'operator_verified_recovery')
            measured['operator_verified_label'] = decisions
            check('operator_verification_is_labelled_as_such',
                  decisions == ['resolved_by_operator_verified_recovery'], finding='R208-06')

    for holder in holders:
        holder.doCleanups()
    measured['assertions'] = assertions
    measured['elapsed_seconds'] = round(time.monotonic() - started, 3)
    Path(args.output).write_text(json.dumps(measured, indent=2, default=str) + '\n')
    failed = [row['name'] for row in assertions if not row['passed']]
    print(json.dumps({'version': measured['version'], 'assertions': len(assertions), 'failed': failed}, indent=2))
    return 1 if args.assert_correctness and failed else 0


if __name__ == '__main__':
    raise SystemExit(main())
