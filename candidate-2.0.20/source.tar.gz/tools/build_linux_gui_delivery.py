"""Repack an extracted Linux offline bundle into a double-click executable.

Uses only its existing runtime and local compiler/tar; no dependency download.
Run with --bundle EXTRACTED_DIR --output OUTPUT_DIR. Final documentation and
evidence must already be present in the bundle before invoking this builder.
"""
from __future__ import annotations
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
import tempfile
import zipfile

import tomllib
# The build label follows the source it packages, so a new release cannot ship
# under the previous release's name.
VERSION = tomllib.loads((Path(__file__).resolve().parents[1] / 'pyproject.toml').read_text())['project']['version']
BUILD = f'{VERSION}-linux-gui1'
# Source files that must stay executable in every archive (R214-03: 2.0.14
# shipped them 0644 after a mode-dropping copy). The build refuses otherwise.
EXECUTABLE_SOURCES = ('tools/live_systemd_lab/boot-systemd.sh', 'tools/live_systemd_lab/gunicorn-shim.py',
                      'tools/live_systemd_lab/reset.sh', 'tools/live_systemd_lab/shims/ip',
                      'tools/live_systemd_lab/shims/ss')


def check_executable_sources(source_root):
    missing = [name for name in EXECUTABLE_SOURCES
               if not (Path(source_root)/name).is_file() or (Path(source_root)/name).stat().st_mode & 0o111 != 0o111]
    if missing:
        raise ValueError('release sources lost their executable mode: ' + ', '.join(missing))


def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def files(root):
    for p in sorted(root.rglob('*')):
        if p.is_symlink(): raise ValueError('Release inputs must not be symlinks: '+str(p))
        if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.pyc', '.pyo'}:
            yield p


def build_runtime(bundle):
    source = bundle/'source/src'
    with zipfile.ZipFile(bundle/'sentinel-blue.pyz', 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        rows = [(p.relative_to(source).as_posix(), p.read_bytes()) for p in files(source)]
        rows.append(('__main__.py', b'from sentinel_blue.__main__ import main\n\nif __name__ == "__main__":\n    main()\n'))
        for name, content in sorted(rows):
            info = zipfile.ZipInfo(name, (2026, 1, 1, 0, 0, 0))
            info.create_system = 3; info.external_attr = 0o100644 << 16
            z.writestr(info, content, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    manifest = json.loads((bundle/'offline-manifest.json').read_text())
    if manifest.get('build') != BUILD:
        manifest = {'build': BUILD, 'base_version': VERSION, 'platform': 'linux-x86_64',
                    'previous_build_metadata': manifest,
                    'validation_note': 'Historical validation files describe only the build explicitly named in each file. See START-HERE.md and the matching corrective-release report for this build; no current native-VM acceptance is implied.'}
    manifest['runtime_sha256'] = sha(bundle/'sentinel-blue.pyz')
    (bundle/'offline-manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')


def archive_tree(root, output):
    with output.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0, compresslevel=6) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as tar:
            for p in files(root):
                info = tarfile.TarInfo(p.relative_to(root).as_posix())
                info.size = p.stat().st_size; info.mode = p.stat().st_mode & 0o777
                info.uid = info.gid = 0; info.mtime = 1767225600
                with p.open('rb') as f: tar.addfile(info, f)


def build(bundle, output):
    bundle, output = Path(bundle).resolve(), Path(output).resolve()
    if output.is_relative_to(bundle): raise ValueError('Output must be outside the bundle.')
    output.mkdir(parents=True, exist_ok=True)
    check_executable_sources(bundle/'source')
    build_runtime(bundle)
    # Remove Python caches produced by any local tests, never distribute them.
    for p in bundle.rglob('__pycache__'):
        shutil.rmtree(p)
    sums = ''.join(sha(p)+'  '+p.relative_to(bundle).as_posix()+'\n' for p in files(bundle) if p.name != 'SHA256SUMS')
    (bundle/'SHA256SUMS').write_text(sums)
    source_archive = output/f'sentinel-blue-{BUILD}-source.tar.gz'
    archive_tree(bundle/'source', source_archive)
    with tempfile.TemporaryDirectory(prefix='sentinel-build-') as temp:
        temp = Path(temp)
        payload = temp/'payload.tar.gz'; archive_tree(bundle, payload)
        stub = temp/'launcher'
        digest = sha(payload)
        subprocess.run(['gcc', '-O2', '-static', '-s', '-Wall', '-Wextra', '-Werror',
            f'-DSB_PAYLOAD_SIZE={payload.stat().st_size}ULL', f'-DSB_PAYLOAD_SHA256="{digest}"',
            str(bundle/'source/packaging/linux-gui/self-extract.c'), '-o', str(stub)], check=True)
        result = output/f'sentinel-blue-{BUILD}-x86_64.run'
        with result.open('wb') as dest:
            for p in (stub, payload):
                with p.open('rb') as src: shutil.copyfileobj(src, dest)
        result.chmod(0o755)
    runtime = output/f'sentinel-blue-{BUILD}.pyz'
    shutil.copyfile(bundle/'sentinel-blue.pyz', runtime)
    report = {'build': BUILD, 'runtime_sha256': sha(runtime), 'source_sha256': sha(source_archive),
              'launcher_sha256': sha(result), 'launcher_bytes': result.stat().st_size,
              'payload_sha256': digest, 'bundled_files': len(list(files(bundle))),
              'network_downloads_during_build': False}
    (output/'linux-gui-build.json').write_text(json.dumps(report, indent=2)+'\n')
    return report


if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('--bundle', type=Path, required=True); p.add_argument('--output', type=Path, required=True)
    a = p.parse_args(); print(json.dumps(build(a.bundle, a.output), indent=2))
