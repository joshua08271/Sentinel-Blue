"""Strict orchestration of one disposable-host service acceptance.

The production setup/withdrawal guards are not bypassed. A fake host can test
these decisions, but cannot certify a real product. Missing evidence fails down.
"""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
import re

from acceptance_snapshot import SnapshotError

MARKER = "\n# sentinel acceptance: an edit made outside Sentinel\n"
HEX = re.compile(r'[0-9a-f]{64}\Z')


def payload(result):
    value = result.get('report')
    if value is None:
        try:
            value = json.loads(result.get('stdout', ''))
        except (ValueError, TypeError):
            return {}
    return value if isinstance(value, dict) else {}


class Runtime:
    """Invoke the actual zipapp, respecting plan/review approval contracts."""
    def __init__(self, executor, argv, *, event_profile=None, range_deployment=False,
                 withdrawal=None):
        self.executor, self.argv = executor, list(argv)
        self.event_profile = event_profile
        self.range_deployment = range_deployment
        self.withdrawal = withdrawal

    def _profile(self):
        return ['--event-profile', str(self.event_profile)] if self.event_profile else []

    def _range(self):
        return ['--range-deployment'] if self.range_deployment else []

    def plan(self, inventory, plan_out):
        result = self.executor.run(self.argv + ['setup', '--inventory', str(inventory),
            *self._profile(), '--plan-out', str(plan_out)])
        digest = payload(result).get('plan_sha256')
        if result['returncode'] != 0 or not isinstance(digest, str) or not HEX.fullmatch(digest):
            digest = None
        return result, digest

    def apply(self, inventory, digest, state_dir):
        if not isinstance(digest, str) or not HEX.fullmatch(digest):
            raise ValueError('setup requires the exact reviewed plan digest')
        return self.executor.run(self.argv + ['setup', '--inventory', str(inventory),
            *self._profile(), *self._range(), '--execute', '--approve-plan', digest,
            '--state-dir', str(state_dir)])

    def withdraw(self, inventory, directory, mode='restore-withdraw', *,
                 allowed_actions=(), expected_hosts=()):
        """Review, validate scope/owned actions, then approve that exact review.

        A separate observer can be reached by an operator-supplied trusted argv
        forwarding wrapper. Its inventory/profile/report directory live there.
        A local-only call retains the production separate-observer hold.
        """
        if mode != 'restore-withdraw':
            raise ValueError('acceptance rollback must Restore & Withdraw, not Remove')
        spec = self.withdrawal
        if spec is not None:
            if not isinstance(spec, dict) or set(spec) != {'runtime_argv', 'inventory', 'event_profile', 'directory'}:
                raise ValueError('withdrawal observer needs an argv prefix and explicit inventory/profile/directory')
            argv = spec['runtime_argv']
            if not isinstance(argv, list) or not argv or any(not isinstance(x, str) or not x or '\x00' in x for x in argv):
                raise ValueError('withdrawal observer requires a reviewed argv forwarding wrapper')
            if any(not isinstance(spec[k], str) or not spec[k] or '\x00' in spec[k]
                   for k in ('inventory', 'event_profile', 'directory')):
                raise ValueError('invalid observer path')
            base = list(argv) + ['withdraw', '--inventory', spec['inventory'],
                '--event-profile', spec['event_profile'], '--directory', spec['directory'],
                '--mode', mode, *self._range()]
        else:
            if self.event_profile is None:
                raise ValueError('withdrawal requires an explicit approved event profile')
            base = self.argv + ['withdraw', '--inventory', str(inventory), *self._profile(),
                                '--directory', str(directory), '--mode', mode, *self._range()]
        reviewed = self.executor.run(base)
        review = payload(reviewed)
        from sentinel_blue.mutation_ledger import digest as review_digest
        digest = review.get('review_digest')
        valid_digest = (isinstance(digest, str) and HEX.fullmatch(digest) and
            digest == review_digest({k: v for k, v in review.items() if k != 'review_digest'}))
        hosts = review.get('hosts')
        reasons = []
        if reviewed['returncode'] != 0 or not valid_digest or review.get('mode') != mode:
            return {'returncode': 2, 'stdout': '', 'stderr': 'no usable restore-withdraw review',
                    'review_result': reviewed}
        if not isinstance(hosts, dict) or not expected_hosts or set(hosts) != set(expected_hosts):
            reasons.append('withdrawal review scope does not exactly match the acceptance host')
        if review.get('conflicts'):
            reasons.append('withdrawal review contains unresolved conflicts')
        if isinstance(hosts, dict):
            for host in hosts.values():
                actions = host.get('inventory', {}).get('actions') if isinstance(host, dict) else None
                if not isinstance(actions, list):
                    reasons.append('no complete action inventory')
                    continue
                for action in actions:
                    if not isinstance(action, dict) or action.get('action_id') not in allowed_actions:
                        reasons.append('review contains actions not created by this acceptance run')
        if reasons:
            # No execution began. Cancel just this review rather than leave an
            # unexpected host paused. Cancellation itself keeps its own guards.
            cancelled = self.executor.run(base + ['--cancel-review'])
            return {'returncode': 2, 'stdout': '', 'stderr': '; '.join(reasons),
                    'review_result': reviewed, 'cancel_result': cancelled}
        done = self.executor.run(base + ['--approved-digest', digest])
        result = payload(done)
        checks = result.get('external_verification')
        complete = (done['returncode'] == 0 and result.get('status') == 'complete' and
            result.get('mode') == mode and result.get('review_digest') == digest and
            not result.get('conflicts') and isinstance(checks, list) and bool(checks) and
            all(isinstance(c, dict) and c.get('healthy') is True and c.get('external') is True for c in checks))
        if not complete:
            return {**done, 'returncode': 2, 'stderr': 'restoration held, incomplete, or missing independent service verification',
                    'review_result': reviewed}
        return {**done, 'report': result, 'review_result': reviewed}


class Acceptance:
    def __init__(self, *, service_id, row, options, profile, executor, runtime,
                 workdir, inventory, report, fingerprint):
        self.service_id, self.row, self.options = service_id, row, copy.deepcopy(options)
        self.profile, self.executor, self.runtime = profile, executor, runtime
        self.workdir, self.inventory, self.report = Path(workdir), inventory, report
        self.fingerprint = fingerprint
        self.pre_state, self.pre_data = {}, {}
        self.owned, self.all_owned = [], []
        self.digest, self.merged = None, None
        self.current_options = copy.deepcopy(options)
        self.applied_ok = False
        self.rollback_ok = False
        self.fixture_conflict = False
        self.actions = set()
        self.host = None
        self.prepared_digests = {}

    def state_of(self, path):
        return self.snapshot([path])[path]

    def digest_of(self, path):
        # Compatibility name: absence and directories are now explicitly typed,
        # and IO errors are exceptions instead of the old ambiguous None.
        return self.state_of(path)

    def snapshot(self, paths):
        result = self.executor.snapshot(list(paths))
        if not isinstance(result, dict) or set(result) != set(paths):
            raise SnapshotError('incomplete snapshot coverage')
        for state in result.values():
            if not isinstance(state, dict) or state.get('type') not in {'file','directory','symlink','absent'}:
                raise SnapshotError('unknown snapshot state')
            if state['type'] in {'file','directory'} and not HEX.fullmatch(str(state.get('sha256', ''))):
                raise SnapshotError('snapshot has no verified content digest')
        return result

    def data_snapshot(self):
        """Strict tree equality by default; live products can use reviewed logical invariants."""
        specs = self.profile.get('data_invariants', {})
        if not isinstance(specs, dict) or set(specs) - set(self.row['data_paths']):
            raise ValueError('data_invariants must name declared preserved data paths')
        plain = [p for p in self.row['data_paths'] if p not in specs]
        values = self.snapshot(plain)
        if any(v["type"] == "symlink" or v.get("symlink_count", 0) for v in values.values()):
            raise SnapshotError("preserved data contains symlinks; supply reviewed product invariants instead of claiming target bytes were checked")
        from service_pack_acceptance import probe_verdict
        for path, spec in specs.items():
            result = self.executor.run(spec['argv'])
            ok, why = probe_verdict(result, {'expect_returncode': 0, **spec})
            if not ok:
                raise SnapshotError('data-invariant query failed: ' + why)
            values[path] = {'type': 'logical-invariant', 'sha256': hashlib.sha256(result['stdout'].encode()).hexdigest()}
        return values

    def contract(self, options=None):
        from sentinel_blue.pack_acceptance import pack_contract
        return pack_contract(self.service_id, self.options if options is None else options, self.workdir)

    def owned_paths(self, options=None):
        return [r['path'] for r in self.contract(options)['files']]

    def build_inventory(self, options, name):
        from sentinel_blue.desktop_services import merge_service_fragment, service_plan
        source = json.loads(Path(self.inventory).read_text())
        hosts = source.get('hosts', [])
        if (not isinstance(hosts, list) or len(hosts) != 1 or hosts[0].get('platform') != 'linux' or
                hosts[0].get('transport') != 'local' or hosts[0].get('address') not in {'127.0.0.1', '::1'}):
            raise ValueError('acceptance inventory must contain exactly this one local disposable Linux host')
        host = hosts[0].get('name')
        if self.profile.get('host', host) != host:
            raise ValueError('profile host differs from the acceptance inventory')
        tasks = source.get('setup', {}).get('tasks', [])
        if any(not isinstance(t, dict) or t.get('id') != 'sentinel-' + self.service_id for t in tasks):
            raise ValueError('acceptance refuses unrelated setup tasks')
        self.host = host
        fragment = service_plan([self.service_id], host, manager='apt', options={self.service_id: options})
        merged = merge_service_fragment(source, fragment)
        target = self.workdir / name
        from sentinel_blue.state import write_private_json
        write_private_json(target, merged)
        return target

    def _remember(self, result):
        report = payload(result)
        tasks = report.get('tasks', {})
        if not isinstance(tasks, dict):
            return {}
        for task in tasks.values():
            if isinstance(task, dict) and re.fullmatch(r'[0-9a-f]{32}', str(task.get('transaction_id', ''))):
                self.actions.add('setup-' + task['transaction_id'])
        return tasks.get('sentinel-' + self.service_id, {})

    def preflight(self):
        from acceptance_profile import profile_problems
        problems = profile_problems(self.service_id, self.options, self.profile, self.workdir)
        if problems:
            return self.report.record('preflight', 'failed', 'no mutations admitted: ' + '; '.join(problems))
        # A pack may wrap an application the operator supplies rather than one a
        # distribution ships; gunicorn declares no packages for that reason. A
        # bare dpkg-query with no names lists every installed package and exits
        # 0, so asking anyway would have compared the whole host against zero
        # expected rows and reported a missing package that was never required.
        names = self.row['packages'].get('apt') or []
        unit = self.executor.service_state(self.row['unit'])
        if not names:
            ok = unit['LoadState'] == 'loaded'
            return self.report.record('preflight', 'passed' if ok else 'failed',
                                      'loaded unit verified; this service declares no distribution package'
                                      if ok else 'unit is not loaded')
        packages = self.executor.run(['dpkg-query', '-W', '-f=${Status}\\n', *names])
        rows = packages['stdout'].splitlines()
        ok = (packages['returncode'] == 0 and len(rows) == len(names) and
              all(r == 'install ok installed' for r in rows) and unit['LoadState'] == 'loaded')
        return self.report.record('preflight', 'passed' if ok else 'failed',
                                  'installed prerequisites and loaded unit verified' if ok else 'missing package or unit')

    def initial_state(self):
        state = self.executor.service_state(self.row['unit'])
        config = self.snapshot(self.row['config_paths'])
        exists = any(v['type'] != 'absent' for v in config.values())
        return self.report.record('initial-state', 'passed',
            ('adoption of existing configuration' if exists else 'fresh configuration, prerequisites already installed') +
            '; unit ' + state['ActiveState'])

    def compile(self):
        self.contract()
        # Resolve all three ordinary plans before changing the first service.
        # A future event/profile or source-file mismatch must not be discovered
        # only after initial setup. Execution still re-plans and checks equality.
        if not self.inventory:
            return self.report.record('compile', 'failed', 'requires the reviewed local inventory')
        for label, options in (('initial', self.options),
                               ('update', self.profile['update_options']),
                               ('invalid', self.profile['invalid_options'])):
            inventory = self.build_inventory(options, 'preflight-inventory-' + label + '.json')
            planned, digest = self.runtime.plan(inventory, self.workdir/('preflight-plan-' + label + '.json'))
            if planned['returncode'] != 0 or not isinstance(digest, str) or not HEX.fullmatch(digest):
                return self.report.record('compile', 'failed', label + ' planning failed before any service mutation')
            self.prepared_digests[label] = digest
        if len(set(self.prepared_digests.values())) != 3:
            return self.report.record('compile', 'failed', 'initial/update/failed-apply plans must be distinct')
        return self.report.record('compile','passed','all three ordinary setup plans checked; pack ' + self.fingerprint[:16])

    def matches_prepared_plan(self, label, digest):
        # Direct step tests can intentionally isolate a later step. A complete
        # walk always fills this map during compile before admitting apply.
        return not self.prepared_digests or self.prepared_digests.get(label) == digest

    def capture_pre_state(self):
        self.owned = self.owned_paths()
        all_owned = set(self.owned)
        for key in ('update_options', 'invalid_options'):
            if isinstance(self.profile.get(key), dict):
                try:
                    all_owned.update(self.owned_paths(self.profile[key]))
                except (ValueError, TypeError, KeyError, OSError):
                    # The corresponding step will fail explicitly. Do not invent
                    # paths or silently substitute the initial option set.
                    pass
        self.all_owned = sorted(all_owned)
        watched = list(dict.fromkeys(self.row['config_paths'] + self.all_owned))
        self.pre_state = self.snapshot(watched)
        self.pre_data = self.data_snapshot()
        self.pre_unit = self.executor.service_state(self.row['unit'])
        return self.report.record('pre-state','passed',
            f'{len(watched)} explicit configuration states and {len(self.pre_data)} data invariants captured')

    def apply(self):
        if not self.inventory:
            return self.report.record('apply','skipped','requires the reviewed local inventory')
        self.merged = self.build_inventory(self.options, 'acceptance-inventory.json')
        planned, digest = self.runtime.plan(self.merged, self.workdir/'plan.json')
        if planned['returncode'] != 0 or not digest or not self.matches_prepared_plan('initial', digest):
            return self.report.record('apply','failed','setup planning failed; no mutation started')
        self.digest = digest
        done = self.runtime.apply(self.merged,digest,self.workdir/'setup-state')
        task = self._remember(done)
        self.applied_ok = done['returncode'] == 0 and payload(done).get('status') == 'ready' and task.get('status') == 'ready'
        return self.report.record('apply','passed' if self.applied_ok else 'failed',
                                  'ordinary approved setup completed' if self.applied_ok else 'setup did not report this task ready')

    def validation_argv(self):
        spec = self.profile.get('config_test') or {}
        return (spec.get('argv') or self.row.get('validate_argv') or None), spec

    def config_test(self):
        from service_pack_acceptance import probe_verdict
        argv, spec = self.validation_argv()
        if not argv:
            return self.report.record('config-test','skipped','profile must supply a real product configuration check')
        ok, why = probe_verdict(self.executor.run(argv), {'expect_returncode':0,**spec})
        return self.report.record('config-test','passed' if ok else 'failed',why)

    def service_active(self):
        value = self.executor.service_state(self.row['unit'])
        return self.report.record('service-active','passed' if value['ActiveState']=='active' else 'failed',value['ActiveState'])

    def probe(self, step, key, default_expectation):
        from service_pack_acceptance import probe_verdict
        spec = self.profile.get(key)
        if not spec:
            return self.report.record(step,'skipped','missing product-specific ' + key + ' probe')
        ok, why = probe_verdict(self.executor.run(spec['argv']),{**default_expectation,**spec},
                                require_denial=step == 'denied-transaction')
        return self.report.record(step,'passed' if ok else 'failed',why)

    def effective_settings(self):
        contract = self.contract(self.current_options)
        current = self.snapshot([r['path'] for r in contract['files']])
        for row in contract['files']:
            state = current[row['path']]
            if state.get('type') != 'file' or state.get('sha256') != row['sha256']:
                return self.report.record('effective-settings','failed','generated configuration does not match installed bytes')
        if not self.profile.get('effective'):
            return self.report.record('effective-settings','skipped','requires a product effective-settings query, not merely syntax validation')
        return self.probe('effective-settings','effective',{'expect_returncode':0})

    def identical_reapply(self):
        if not self.applied_ok:
            return self.report.record('identical-reapply','skipped','follows a successful apply')
        before = self.snapshot(self.all_owned)
        service_before = self.executor.service_state(self.row['unit'])
        planned, digest = self.runtime.plan(self.merged,self.workdir/'plan-again.json')
        if planned['returncode'] != 0 or digest != self.digest:
            return self.report.record('identical-reapply','failed','same input no longer produces the reviewed digest')
        done = self.runtime.apply(self.merged,digest,self.workdir/'setup-state')
        task = self._remember(done)
        after = self.snapshot(self.all_owned)
        service_after = self.executor.service_state(self.row['unit'])
        ok = (done['returncode']==0 and task.get('status')=='ready' and task.get('changed') is False and
              before==after and service_before==service_after and service_after['ActiveState']=='active')
        return self.report.record('identical-reapply','passed' if ok else 'failed',
            'exact files and service instance stayed unchanged' if ok else 'reapply changed state, restarted, or lacks lifecycle evidence')

    def approved_update(self):
        update = self.profile.get('update_options')
        if not update:
            return self.report.record('approved-update','skipped','missing reviewed update_options')
        if not self.applied_ok:
            return self.report.record('approved-update','skipped','follows a successful apply')
        before = self.snapshot(self.all_owned)
        data = self.data_snapshot()
        updated = self.build_inventory(update,'acceptance-inventory-update.json')
        planned,digest = self.runtime.plan(updated,self.workdir/'plan-update.json')
        if planned['returncode'] != 0 or not digest or digest==self.digest or not self.matches_prepared_plan('update', digest):
            return self.report.record('approved-update','failed','update must produce a distinct valid reviewed plan')
        done = self.runtime.apply(updated,digest,self.workdir/'setup-state-update')
        task = self._remember(done)
        contract = self.contract(update)
        expected = {r['path']:r for r in contract['files']}
        after = self.snapshot(self.all_owned)
        valid = all(after[p].get('sha256')==r['sha256'] and after[p].get('type')=='file' for p,r in expected.items())
        untouched = all(before[p]==after[p] for p in self.all_owned if p not in expected)
        ok = done['returncode']==0 and task.get('status')=='ready' and valid and untouched and data==self.data_snapshot()
        if ok:
            self.current_options, self.merged, self.digest = copy.deepcopy(update), updated,digest
        return self.report.record('approved-update','passed' if ok else 'failed',
            'requested bytes installed and declared data invariants preserved' if ok else 'update or preservation verification failed')

    def outside_edit_refused(self):
        if not self.applied_ok or not self.owned:
            return self.report.record('outside-edit-refused','skipped','follows a successful apply')
        target = self.owned[0]
        token = self.executor.stage_edit(target, MARKER, self.workdir/'fixture-backups')
        edited = self.state_of(target)
        try:
            planned,digest = self.runtime.plan(self.merged,self.workdir/'plan-edited.json')
            if planned['returncode'] != 0 or not digest:
                return self.report.record('outside-edit-refused','failed','plan failed; runtime ownership refusal was not exercised')
            done = self.runtime.apply(self.merged,digest,self.workdir/'setup-state-edited')
            task = self._remember(done)
            diagnostic = json.dumps(task,sort_keys=True) + done.get('stderr','')
            specific = any(s in diagnostic for s in (
                'OwnershipConflict','differs from the reviewed before/after hashes',
                'Object changed after','unreviewed change present'))
            preserved = self.state_of(target)==edited==token['edited']
            ok = done['returncode'] != 0 and specific and preserved
            if task.get('status')=='uncertain' or task.get('rollback_status')=='unconfirmed':
                ok = False
            return self.report.record('outside-edit-refused','passed' if ok else 'failed',
                'ownership refusal retained the exact outside-edited state' if ok else
                'no proven ownership refusal, edited state lost, or unresolved transaction')
        finally:
            try:
                self.executor.restore_edit(token)
            except (OSError, ValueError, RuntimeError):
                self.fixture_conflict = True
                self.report.record('outside-edit-refused','failed','fixture changed after edit; cleanup refused and private backup retained')

    def interrupted_setup(self):
        invalid = self.profile.get('invalid_options')
        if not invalid or not self.applied_ok:
            return self.report.record('interrupted-setup','skipped','requires a successful apply and product-rejected option set')
        before = self.snapshot(self.all_owned)
        before_data = self.data_snapshot()
        try:
            broken = self.build_inventory(invalid,'acceptance-inventory-invalid.json')
        except (ValueError, TypeError, KeyError, OSError) as exc:
            return self.report.record('interrupted-setup','failed','rejected before apply; no failed-mutation recovery exercised: '+type(exc).__name__)
        planned,digest = self.runtime.plan(broken,self.workdir/'plan-invalid.json')
        if planned['returncode'] != 0 or not digest or not self.matches_prepared_plan('invalid', digest):
            return self.report.record('interrupted-setup','failed','planning rejection is not a mid-apply failure')
        with self.executor.watch_writes(self.all_owned) as watcher:
            done = self.runtime.apply(broken,digest,self.workdir/'setup-state-invalid')
            changes = watcher.changed_paths()
        task = self._remember(done)
        applied = task.get('apply',{})
        ok = (done['returncode'] != 0 and task.get('changed') is True and
              isinstance(applied,dict) and applied.get('uncertain') is False and
              type(applied.get('returncode')) is int and applied['returncode'] != 0 and
              task.get('rollback_status')=='completed' and task.get('status')=='failed' and
              bool(changes) and set(changes)<=set(self.all_owned) and
              before==self.snapshot(self.all_owned) and before_data==self.data_snapshot())
        return self.report.record('interrupted-setup','passed' if ok else 'failed',
            'observed exact-target writes, failed apply and confirmed restoration; not a power-loss test' if ok else
            'missing observed writes/failed-apply/rollback evidence or pre-state was not restored')

    def restart_survives(self):
        before = self.snapshot(self.all_owned)
        first = self.executor.service_state(self.row['unit'])
        result = self.executor.run(['systemctl','restart','--',self.row['unit']])
        last = self.executor.service_state(self.row['unit'])
        ok = (result['returncode']==0 and last['ActiveState']=='active' and
              first['InvocationID'] != last['InvocationID'] and before==self.snapshot(self.all_owned))
        return self.report.record('restart-survives','passed' if ok else 'failed',
                                  'new active service instance, identical configuration' if ok else 'restart not proven')

    def rollback(self):
        if not self.digest or self.fixture_conflict:
            return self.report.record('rollback','skipped','no apply to restore or unresolved outside fixture conflict')
        result = self.runtime.withdraw(self.merged,self.workdir/'withdraw-report','restore-withdraw',
                                      allowed_actions=self.actions,expected_hosts=[self.host])
        status = payload(result)
        checks = status.get('external_verification',[])
        ok = (result['returncode']==0 and status.get('status')=='complete' and
              status.get('mode')=='restore-withdraw' and not status.get('conflicts') and
              bool(checks) and all(isinstance(c,dict) and c.get('healthy') is True and c.get('external') is True for c in checks) and
              self.pre_state==self.snapshot(list(self.pre_state)) and self.pre_data==self.data_snapshot())
        # A restart can legitimately change process identity; restoration must
        # restore active/enabled state, not resurrect a dead PID.
        final = self.executor.service_state(self.row['unit'])
        ok = ok and all(self.pre_unit[k]==final[k] for k in ('LoadState','ActiveState','UnitFileState'))
        self.rollback_ok = bool(ok)
        return self.report.record('rollback','passed' if ok else 'failed',
            'approved restoration, independent checks and exact preserved state verified' if ok else 'restore-withdraw held or final state differs')

    def withdrawal(self):
        if not self.rollback_ok:
            return self.report.record('withdrawal','skipped','requires completed approved restoration and outside verification')
        ok = self.pre_state==self.snapshot(list(self.pre_state)) and self.pre_data==self.data_snapshot()
        return self.report.record('withdrawal','passed' if ok else 'failed','final declared state verified' if ok else 'state changed after restore')

    def optional(self):
        self.report.record('reboot-survives','skipped','not exercised; a real reboot/resume campaign is separate')
        self.report.record('independent-client','skipped','initial provisioned-service second-client test not exercised; restoration has its own required outside checks')

    def walk(self):
        sequence = [('preflight',self.preflight),('initial-state',self.initial_state),
                    ('compile',self.compile),('pre-state',self.capture_pre_state),('apply',self.apply),
                    ('config-test',self.config_test),('service-active',self.service_active),
                    ('positive-transaction',lambda:self.probe('positive-transaction','positive',{'expect_returncode':0})),
                    ('denied-transaction',lambda:self.probe('denied-transaction','denied',{'expect_failure':True})),
                    ('effective-settings',self.effective_settings),('identical-reapply',self.identical_reapply),
                    ('approved-update',self.approved_update),('outside-edit-refused',self.outside_edit_refused),
                    ('interrupted-setup',self.interrupted_setup),('restart-survives',self.restart_survives)]
        blocked = None
        for name, fn in sequence:
            if blocked:
                self.report.record(name,'skipped','blocked by '+blocked)
                continue
            try:
                ok = fn()
            except (OSError, ValueError, RuntimeError, TypeError, KeyError) as exc:
                ok = self.report.record(name,'failed',type(exc).__name__+': '+str(exc)[:350])
            if not ok or self.report.results.get(name, {}).get("verdict") != "passed":
                blocked = name
        for name,fn in [('rollback',self.rollback),('withdrawal',self.withdrawal)]:
            try:
                fn()
            except (OSError, ValueError, RuntimeError, TypeError, KeyError) as exc:
                self.report.record(name,'failed',type(exc).__name__+': '+str(exc)[:350])
        self.optional()
        return self.report
