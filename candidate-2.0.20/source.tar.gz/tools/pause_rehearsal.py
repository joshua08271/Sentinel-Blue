"""Native Tk/TLS/detached-worker pause acceptance on owned loopback fixtures."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import secrets
import shlex
import shutil
import subprocess
import sys
import threading
import time
import traceback
import zipfile
from pathlib import Path
from unittest.mock import patch


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runtime', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    runtime = args.runtime.resolve(strict=True)
    sys.path[:0] = [str(runtime), str(Path(__file__).resolve().parents[1])]
    import sentinel_blue
    from sentinel_blue import recording
    from sentinel_blue.desktop import DesktopWindow
    from sentinel_blue.desktop_control import DesktopClient
    from sentinel_blue.desktop_jobs import prepare
    from sentinel_blue.job_control import JobControl, SetupPaused
    from sentinel_blue.recovery_ops import initialize_controller_recovery
    from sentinel_blue.state import _atomic_bytes, write_private_json, read_private_json
    from tools.history_storage_rehearsal import certificate, free_port, stop
    from tools.setup_native_inputs import manifest, runbook, profile_inventory
    import tkinter as tk
    assert str(runtime) in sentinel_blue.__file__, 'Acceptance must use packaged runtime'
    os.umask(0o077)
    output = args.output.absolute()
    output.mkdir(mode=0o700, parents=True, exist_ok=True)
    root = output/'owned-fixture'
    root.mkdir(mode=0o700)
    if os.name == 'nt':
        subprocess.run(['icacls', str(root), '/inheritance:r', '/grant:r',
                        '*S-1-5-18:(OI)(CI)F', '*S-1-5-32-544:(OI)(CI)F'], capture_output=True, check=True)
    began = time.monotonic()
    report = {'status': 'failed', 'version': sentinel_blue.__version__,
              'runtime_sha256': hashlib.sha256(runtime.read_bytes()).hexdigest(),
              'checks': {}, 'seconds': {}, 'scope': 'owned loopback native Tk, TLS controller and detached setup workers'}
    processes, streams = [], []
    window = None
    local = None
    blocker = threading.Event()
    release = root/'release-first'
    def launch(argv, name):
        stream = (root/name).open('w'); streams.append(stream)
        process = subprocess.Popen(argv, stdout=stream, stderr=subprocess.STDOUT)
        processes.append(process)
        return process
    def wait_for(predicate, seconds=45):
        deadline = time.monotonic()+seconds
        while time.monotonic() < deadline:
            if window is not None:
                window.root.update()
            try:
                value = predicate()
                if value: return value
            except (OSError, RuntimeError, ValueError):
                pass
            time.sleep(.02)
        raise TimeoutError('Native pause acceptance condition did not finish')
    def click(text):
        def walk(widget):
            for child in widget.winfo_children():
                if child.winfo_class() == 'TButton' and child.cget('text') == text:
                    return child
                found = walk(child)
                if found is not None: return found
        button = walk(window.root)
        assert button is not None, text
        with patch.object(window.messagebox, 'askyesno', return_value=True):
            button.invoke()
    def close_window():
        nonlocal window
        if window is not None:
            current, window = window, None
            current.close()
            current.control_thread.join(12)
            current.worker_thread.join(12)
            assert not current.control_thread.is_alive() and not current.worker_thread.is_alive()
    try:
        certificate(root)
        controller_port, service_port = free_port(), free_port()
        assert controller_port != service_port
        public = root/'public'; public.mkdir(mode=0o700)
        (public/'index.html').write_text('range-ready')
        launch([sys.executable, '-m', 'http.server', str(service_port), '--bind', '127.0.0.1',
                '--directory', str(public)], 'service.log')
        first, started, second = root/'first-done', root/'first-started', root/'second-done'
        counter = root/'first-count'
        if os.name == 'nt':
            quote = lambda p: "'"+str(p).replace("'", "''")+"'"
            first_check = f'if (Test-Path -LiteralPath {quote(first)}) {{exit 0}}; exit 10'
            second_check = f'if (Test-Path -LiteralPath {quote(second)}) {{exit 0}}; exit 10'
            first_apply = f"""$ErrorActionPreference='Stop'
[IO.File]::AppendAllText({quote(counter)},'1')
[IO.File]::WriteAllText({quote(started)},'started')
$limit=[DateTime]::UtcNow.AddSeconds(45)
while (-not (Test-Path -LiteralPath {quote(release)})) {{
 if ([DateTime]::UtcNow -gt $limit) {{exit 20}}
 Start-Sleep -Milliseconds 100
}}
[IO.File]::WriteAllText({quote(first)},'done'); exit 0
"""
            second_apply = f"[IO.File]::WriteAllText({quote(second)},'done'); exit 0"
            first_rollback = "$ErrorActionPreference='Stop'\n"
            for p, value in [(counter,'1'),(started,'started'),(first,'done')]:
                first_rollback += f"if ((Test-Path -LiteralPath {quote(p)}) -and [IO.File]::ReadAllText({quote(p)}) -cne '{value}') {{throw 'Fixture changed'}}\n"
            first_rollback += '\n'.join(f"Remove-Item -LiteralPath {quote(p)} -ErrorAction SilentlyContinue" for p in (first,started,counter))+'\nexit 0'
        else:
            quote = lambda p: shlex.quote(str(p))
            first_check = 'test -f '+quote(first)+'\n'
            second_check = 'test -f '+quote(second)+'\n'
            first_apply = f"""set -eu
printf 1 >> {quote(counter)}
printf started > {quote(started)}
i=0
while test ! -f {quote(release)}; do
 i=$((i+1))
 if test "$i" -gt 450; then exit 20; fi
 sleep 0.1
done
printf done > {quote(first)}
"""
            second_apply = 'printf done > '+quote(second)+'\n'
            first_rollback = 'set -eu\n'
            for p, value in [(counter,'1'),(started,'started'),(first,'done')]:
                first_rollback += f'if test -e {quote(p)}; then test "$(cat {quote(p)})" = {value}; fi\n'
            first_rollback += 'rm -f -- '+' '.join(quote(p) for p in (first,started,counter))+'\n'
        check = {'name': 'owned-http', 'kind': 'http', 'target': f'http://127.0.0.1:{service_port}/',
                 'expected_status': [200], 'expected_body': 'range-ready', 'timeout': 1}
        service = manifest('pause-fixture', 'http', service_port, [check])
        tasks = [runbook(root, 'first', first_check, first_apply, service='pause-fixture', rollback=first_rollback),
                 runbook(root, 'second', second_check, second_apply, requires=['first'])]
        for task in tasks:
            task.update(timeout_seconds=90, health_wait_seconds=15)
        inventory = profile_inventory(runtime, tasks, [service])
        inventory['setup'].update(budget_seconds=180, max_parallel_hosts=1)
        profile = inventory['event_profile']
        profile['scope']['approved_deployment_paths'] = [str(root)]
        profile['release']['controller_ca_sha256'] = hashlib.sha256((root/'tls.crt').read_bytes()).hexdigest()
        write_private_json(root/'profile.json', profile)
        write_private_json(root/'inventory.json', inventory)
        master, operator, key = secrets.token_urlsafe(48), secrets.token_urlsafe(48), secrets.token_bytes(48)
        for name, value in [('master.txt', master.encode()), ('operator.txt', operator.encode()), ('recovery.key', key)]:
            _atomic_bytes(root/name, value)
        initialize_controller_recovery(root/'controller.db', root/'recovery.anchor', key)
        local = recording.Recorder(root/'recordings', role='native-pause-test')
        recording._current = local
        os.environ[recording.ENV] = str(local.directory)
        controller_args = [sys.executable, str(runtime), 'controller', '--bind', '127.0.0.1', '--port', str(controller_port),
            '--event-profile', str(root/'profile.json'), '--range-deployment', '--token-file', str(root/'master.txt'),
            '--operator-token-file', str(root/'operator.txt'), '--operator-principal-id', 'pause-test',
            '--database', str(root/'controller.db'), '--recovery-anchor', str(root/'recovery.anchor'),
            '--recovery-key-file', str(root/'recovery.key'), '--tls-cert', str(root/'tls.crt'),
            '--tls-key', str(root/'tls.key'), '--tls-ca-file', str(root/'tls.crt'), '--backup-interval', '900']
        controller = launch(controller_args, 'controller.log')
        client = DesktopClient(f'https://127.0.0.1:{controller_port}', 'pause-test', 2, operator, str(root/'tls.crt'))
        wait_for(client.dashboard, 90)
        values = {'inventory': str(root/'inventory.json'), 'event_profile': str(root/'profile.json'),
                  'runtime': str(runtime), 'kind': 'setup', 'range_deployment': True}
        plan, _ = prepare(values['inventory'], values['event_profile'], runtime, 'setup', True)
        def open_window():
            current = DesktopWindow(tk.Tk(), directory=root/'desktop')
            current.notify.set(False)
            current.client = client
            current.inventory_path.set(values['inventory']); current.profile_path.set(values['event_profile'])
            current.runtime_path.set(str(runtime)); current.setup_kind.set('setup'); current.range_mode.set(True)
            current.plan = (values, plan)
            return current
        window = open_window()
        with patch('sentinel_blue.desktop_jobs.runtime_command', return_value=[sys.executable, str(runtime)]), \
                patch.object(window.messagebox, 'askyesno', return_value=True):
            window.execute_setup()
            wait_for(lambda: window.job_path is not None and started.exists(), 90)
        job_path, worker = window.job_path, window.job_process
        processes.append(worker)
        epoch = read_private_json(job_path)['control_epoch']
        busy = threading.Event()
        def long_operation():
            busy.set(); blocker.wait(60)
        assert window.submit(long_operation, lambda _: None)
        wait_for(busy.is_set)
        for _ in range(4): assert window.submit(lambda: None, lambda _: None)
        pause_at = time.monotonic()
        click('Pause automatic changes')
        wait_for(lambda: not window.control_pending, 15)
        report['seconds']['busy_gui_pause_confirmation'] = round(time.monotonic()-pause_at, 3)
        assert 'Controller pause confirmed.' in window.footer.get(), window.footer.get()
        assert window.jobs.qsize() == 4 and worker.poll() is None
        report['checks']['pause_bypassed_full_queue_and_busy_worker'] = True
        assert client.dashboard()['controller']['governance']['emergency_stopped'] is True
        report['checks']['signed_tls_controller_pause'] = True
        assert JobControl(root/'desktop').read()['paused']
        blocker.set()
        close_window()
        release.write_text('finish admitted operation')
        wait_for(lambda: worker.poll() is not None, 90)
        result = read_private_json(job_path.parent/'result.json')
        (output/'paused-job.json').write_text(json.dumps(result, indent=2))
        assert result['status'] == 'paused', result
        assert first.exists() and not second.exists()
        assert result['tasks']['first']['status'] == 'ready'
        assert result['tasks']['second']['changed'] is False
        report['checks']['detached_task_finished_without_starting_next_task'] = True
        stop(controller)
        controller = launch(controller_args, 'controller-restart.log')
        wait_for(client.dashboard, 90)
        assert client.dashboard()['controller']['governance']['emergency_stopped'] is True
        report['checks']['controller_pause_survived_restart'] = True
        window = open_window()
        assert window.job_control.read()['paused']
        click('Resume approved changes')
        wait_for(lambda: not window.control_pending, 15)
        assert 'Controller resume confirmed.' in window.footer.get(), window.footer.get()
        assert not window.job_control.read()['paused']
        try:
            window.job_control.permit(epoch).checkpoint()
        except SetupPaused:
            pass
        else:
            raise AssertionError('Old job became runnable on resume')
        assert not second.exists()
        report['checks']['reopened_gui_requires_review_and_never_replays_old_job'] = True
        with patch('sentinel_blue.desktop_jobs.runtime_command', return_value=[sys.executable, str(runtime)]), \
                patch.object(window.messagebox, 'askyesno', return_value=True):
            window.execute_setup()
            wait_for(lambda: window.job_path is not None, 30)
            new_job, new_worker = window.job_path, window.job_process
            processes.append(new_worker)
            wait_for(lambda: new_worker.poll() is not None, 90)
        result = read_private_json(new_job.parent/'result.json')
        (output/'reviewed-job.json').write_text(json.dumps(result, indent=2))
        assert result['status'] == 'ready' and second.exists(), result
        assert counter.read_text() == '1', 'Completed first mutation was repeated'
        report['checks']['new_review_finishes_remaining_work_without_repeating_first_change'] = True
        close_window()
        stop(controller)
        local.stop(); bundle = local.export()
        info = recording.inspect_bundle(bundle)
        with zipfile.ZipFile(bundle) as archive:
            events = [json.loads(line) for line in archive.read('events.jsonl').splitlines()]
        kinds = {event['kind'] for event in events}
        assert {'setup_pause_changed', 'desktop_control_result', 'setup_worker_result', 'setup_progress'} <= kinds
        assert any(e['kind'] == 'setup_worker_result' and e['data'].get('status') == 'paused' for e in events)
        assert any(e['kind'] == 'desktop_control_result' and e['data'].get('local', {}).get('status') == 'paused'
                   and e['data'].get('controller', {}).get('status') == 'paused' for e in events)
        assert all(operator not in json.dumps(event) and master not in json.dumps(event) for event in events)
        assert info['verified']
        shutil.copyfile(bundle, output/'pause-recording.zip')
        report['checks']['pause_and_partial_results_in_verified_recording'] = True
        report['status'] = 'passed'
    except Exception as exc:
        report.update(error_type=type(exc).__name__, error=str(exc)[:500])
        (output/'failure.txt').write_text(traceback.format_exc())
    finally:
        blocker.set()
        release.write_text('allow fixture to finish')
        close_window()
        for process in processes: stop(process)
        if local: local.close()
        recording._current = None
        os.environ.pop(recording.ENV, None)
        for stream in streams: stream.close()
        report['children_stopped'] = all(process.poll() is not None for process in processes)
        report['elapsed_seconds'] = round(time.monotonic()-began, 3)
        (output/'native-pause.json').write_text(json.dumps(report, indent=2))
        print(json.dumps(report), flush=True)
    return 0 if report['status'] == 'passed' else 2


if __name__ == '__main__': raise SystemExit(main())
