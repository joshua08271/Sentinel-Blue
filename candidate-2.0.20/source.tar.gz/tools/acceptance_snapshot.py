"""Bounded, read-only native filesystem evidence for private acceptance tests.

No missing/unreadable distinction is lost: absence is a typed state, and any
permission, race, unsupported object or budget violation raises SnapshotError.
Directory digests include every visited regular file's bytes and metadata. Live
DB/queue invariants may need a reviewed product-level snapshot instead.
"""
from __future__ import annotations

import hashlib
import json
import os
import stat
import time
from pathlib import PurePosixPath


class SnapshotError(RuntimeError):
    pass


def _metadata(info):
    return {"mode": stat.S_IMODE(info.st_mode), "uid": info.st_uid, "gid": info.st_gid}


def _revision(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_gid,
            info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def snapshot_paths(paths, *, max_entries=10000, max_bytes=128 * 1024 * 1024,
                   max_seconds=30, max_depth=32):
    if (not isinstance(paths, (list, tuple)) or len(paths) > 256 or
            any(not isinstance(p, str) or not p.startswith('/') or '\x00' in p or
                len(p) > 4096 or '..' in p.split('/') or '.' in p.split('/') for p in paths)):
        raise SnapshotError('snapshot paths must be bounded canonical absolute paths')
    deadline = time.monotonic() + max_seconds
    used = {"entries": 0, "bytes": 0}

    def check(depth=0):
        if (used['entries'] > max_entries or used['bytes'] > max_bytes or
                depth > max_depth or time.monotonic() > deadline):
            raise SnapshotError('snapshot exceeds entry/byte/depth/time budget; no equality claim')

    def visit(parent, name, depth=0):
        check(depth)
        try:
            before = os.stat(name, dir_fd=parent, follow_symlinks=False)
        except FileNotFoundError:
            return {"type": "absent"}
        used['entries'] += 1
        check(depth)
        if stat.S_ISLNK(before.st_mode):
            # Never follow a link out of the reviewed evidence tree. Record the
            # link itself, not whatever a changing target might point at.
            link = os.readlink(name, dir_fd=parent)
            after = os.stat(name, dir_fd=parent, follow_symlinks=False)
            if _revision(before) != _revision(after):
                raise SnapshotError('symlink changed while capturing evidence')
            return {"type": "symlink", "target_sha256": hashlib.sha256(os.fsencode(link)).hexdigest(),
                    **_metadata(before)}
        if not (stat.S_ISREG(before.st_mode) or stat.S_ISDIR(before.st_mode)):
            raise SnapshotError('unsupported special file in watched tree')
        flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK
        if stat.S_ISDIR(before.st_mode):
            flags |= os.O_DIRECTORY
        fd = os.open(name, flags, dir_fd=parent)
        try:
            opened = os.fstat(fd)
            if _revision(before) != _revision(opened):
                raise SnapshotError('object changed before it was opened')
            attrs = {}
            for attr in sorted(os.listxattr(fd)):
                value = os.getxattr(fd, attr)
                used['bytes'] += len(value)
                check(depth)
                attrs[attr] = hashlib.sha256(value).hexdigest()
            base = {**_metadata(opened), "xattrs": attrs}
            if stat.S_ISREG(opened.st_mode):
                digest = hashlib.sha256()
                size = 0
                while True:
                    chunk = os.read(fd, 1024 * 1024)
                    if not chunk:
                        break
                    size += len(chunk)
                    used['bytes'] += len(chunk)
                    check(depth)
                    digest.update(chunk)
                state = {"type": "file", "sha256": digest.hexdigest(), "bytes": size, **base}
            else:
                tree = []
                # scandir iteration is bounded before constructing a sorted list.
                names = []
                with os.scandir(fd) as items:
                    for item in items:
                        names.append(item.name)
                        if len(names) + used['entries'] > max_entries:
                            raise SnapshotError('directory exceeds the entry budget')
                        check(depth)
                for child in sorted(names):
                    value = visit(fd, child, depth + 1)
                    if value['type'] == 'absent':
                        raise SnapshotError('child disappeared during tree snapshot')
                    tree.append([child, value])
                state = {"type": "directory", "sha256": hashlib.sha256(
                    json.dumps(tree, sort_keys=True, ensure_ascii=True).encode()).hexdigest(),
                    "children": len(tree),
                    "symlink_count": sum((1 if value["type"] == "symlink" else value.get("symlink_count", 0))
                                         for _, value in tree), **base}
            if _revision(opened) != _revision(os.fstat(fd)):
                raise SnapshotError('object changed during evidence capture')
            if _revision(before) != _revision(os.stat(name, dir_fd=parent, follow_symlinks=False)):
                raise SnapshotError('object was replaced during evidence capture')
            return state
        finally:
            os.close(fd)

    results = {}
    for path in dict.fromkeys(paths):
        fd = os.open('/', os.O_RDONLY | os.O_DIRECTORY)
        try:
            parts = PurePosixPath(path).parts[1:]
            missing = False
            for part in parts[:-1]:
                try:
                    child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
                except FileNotFoundError:
                    missing = True
                    break
                os.close(fd)
                fd = child
            results[path] = {"type": "absent"} if missing else visit(fd, parts[-1] if parts else '.')
        except OSError as exc:
            raise SnapshotError(f'cannot capture {path}: {type(exc).__name__}; no equality claim') from exc
        finally:
            os.close(fd)
    return results
