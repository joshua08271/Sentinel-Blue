"""Create the reproducible Linux launcher ZIP (requires system Python/Tk)."""
from pathlib import Path
import argparse,hashlib,tomllib,zipfile,stat
ROOT=Path(__file__).resolve().parents[1]
VERSION=tomllib.loads((ROOT/'pyproject.toml').read_text())['project']['version']
def build(runtime,output):
    data=Path(runtime).read_bytes()
    with zipfile.ZipFile(runtime) as z:
        if ('__version__ = "'+VERSION+'"') not in z.read('sentinel_blue/__init__.py').decode():
            raise ValueError('Runtime version differs from source')
        if z.testzip() is not None:raise ValueError('Damaged runtime')
    digest=hashlib.sha256(data).hexdigest()
    files={'sentinel-blue.pyz':(data,0o755),'SHA256SUMS':((digest+'  sentinel-blue.pyz\n').encode(),0o644),
           'README.md':((ROOT/'README.md').read_bytes(),0o644),'LICENSE':((ROOT/'LICENSE').read_bytes(),0o644)}
    for name in ('sentinel-blue','install-linux-launcher.sh','install-linux-launcher.py','sentinel-blue.desktop','sentinel-blue.svg'):
        files[name]=((ROOT/'packaging/linux-desktop'/name).read_bytes(),0o755 if name in ('sentinel-blue','install-linux-launcher.sh') else 0o644)
    files['HOW-TO-RUN.txt']=(('Sentinel Blue '+VERSION+' Linux launcher\n\n'
        'Requires Python 3.11+, cryptography and Tk. This ZIP does not bundle Python.\n'
        'Extract all files; verify SHA256SUMS; run: sh install-linux-launcher.sh\n'
        'The installer uses its adjacent stdlib-only install-linux-launcher.py helper.\n'
        'Open the installed application. Your desktop may request Trust/Allow Launching.\n'
        'No services or automatic defense are started merely by opening the GUI.\n'
        'Supply the reviewed event profile, connections and credentials in the GUI.\n\n'
        'Remove per-user integration: sh install-linux-launcher.sh --uninstall\n'
        'The installer refuses existing entries without its ownership receipt and\n'
        'preserves externally changed entries. Legacy 1.9.84 entries require manual\n'
        'review; do not delete controller ledgers or relax directory permissions.\n'
        'Integration receipts live in XDG_DATA_HOME or ~/.local/share. The private\n'
        'zero-data lock file remains after uninstall for safe concurrent access.\n'
        'No Windows launcher or native VM/service acceptance is claimed.\n').encode(),0o644)
    # The round's own document, whatever this round was about.
    for stem in ('PORTS_AND_FIXES_', 'PACK_ACCEPTANCE_', 'LINUX_HOTFIX_'):
        guide = ROOT/'docs'/(stem+VERSION+'.md')
        if guide.exists():
            files['docs/'+guide.name] = (guide.read_bytes(), 0o644)
    for name in ('VM_TESTING_REQUIRED_'+VERSION+'.md', 'vm-testing-required-'+VERSION+'.json'):
        files['docs/'+name]=((ROOT/'docs'/name).read_bytes(),0o644)
    output=Path(output);output.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,(content,mode) in sorted(files.items()):
            i=zipfile.ZipInfo('sentinel-blue-'+VERSION+'/'+name,(2026,1,1,0,0,0));i.create_system=3;i.external_attr=(stat.S_IFREG|mode)<<16;i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,content)
    return output
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--runtime',required=True);p.add_argument('--output',required=True);a=p.parse_args();print(build(a.runtime,a.output))
