"""Real kernel forwarding/SSH/HTTP(S) acceptance on an isolated owned VM fixture."""
import copy,hashlib,http.server,json,os,shutil,socket,ssl,subprocess,sys,time,uuid
from pathlib import Path
from dataclasses import asdict
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'tools'))
import rollback_route_rehearsal as h
from sentinel_blue.setup import SetupRunner,plan_digest
from sentinel_blue.setup_transport import SetupTransport
from sentinel_blue.route_verification import script as witness_script
from sentinel_blue import network_native

TAG=h.TAG;A=TAG+'s';B=TAG+'d';IA='p'+h.RUN[:8]+'a';IB='p'+h.RUN[:8]+'b'
HOST={'name':'router','agent_id':'router','address':'10.201.1.254','transport':'ssh','platform':'linux',
      'username':'root','key_file':str(ROOT/'route-key'),'known_hosts_file':str(ROOT/'route-known-hosts'),'port':48271,'sudo':False}
OPTIONS={'name':TAG,'forwarding':True,'input_policy':'accept','rollback_seconds':120,
 'management':[{'source':'10.201.1.0/24','port':48271}],
 'forward':[{'source':'10.201.1.1/32','destination':'10.201.2.1/32','protocol':'tcp','port':p,'in_interface':IA,'out_interface':IB} for p in (48272,48273)],
 'masquerade':[{'source':'10.201.1.1/32','out_interface':IB}],
 'path_checks':[{'probe_index':i,'source_address':'10.201.1.1','in_interface':IA,'out_interface':IB} for i in (1,2)]}
def ip(*args):return h.native(['ip',*args])
def controller_pair(options=None,body='desired'):
    checks=[{'kind':'tcp','target':'10.201.1.254','port':48271,'timeout':2},h.probe(48272,body,'10.201.2.1'),
       {'kind':'https','target':'https://10.201.2.1:48273/','expected_body':body,'expected_status':[200],
        'ca_file':str(ROOT/'route.crt'),'ca_sha256':hashlib.sha256((ROOT/'route.crt').read_bytes()).hexdigest(),'timeout':2}]
    return h.plan('linux-router',options or OPTIONS,checks,host=HOST,service='sentinel-router-'+(options or OPTIONS)['name'],health=25)
def controller(label):
    pair=controller_pair();p,profile=pair
    if label=='wrong-interface':
        opts=copy.deepcopy(OPTIONS)
        opts['forward'] += [dict(x,in_interface=IB,out_interface=IA) for x in opts['forward']]
        opts['path_checks']=[dict(x,in_interface=IB,out_interface=IA) for x in opts['path_checks']]
        p,profile=controller_pair(opts)
    elif label=='bad-content':
        opts=copy.deepcopy(OPTIONS);opts['name']=TAG+'bad'
        p,profile=controller_pair(opts,body='unavailable')
    observations=[]
    class ObservedRunner(SetupRunner):
        def _command(self,host,script,seconds):
            if "ns['run']('finish'," in script:
                super()._command(host,'nft -j list ruleset\n',min(5,seconds))
            return super()._command(host,script,seconds)
        def _healthy(self,*args,**kwargs):
            result=super()._healthy(*args,**kwargs)
            observations.extend(copy.deepcopy(result[1]));return result
    row=ObservedRunner(p,profile).execute(ROOT/('route-'+label),plan_digest(p))
    row['observed_checks']=observations
    (ROOT/('route-'+label+'.json')).write_text(json.dumps(row,indent=2))
    task=row['tasks']['owned-task']
    if label=='healthy':
        assert row['status']=='ready',task
        assert len([x for x in task['checks'] if x['kind']=='router-path' and x['path_witnessed'] and x['application_healthy']])==2,task
    elif label in {'bypass','wrong-interface'}:
        assert task['status']!='ready',task
        assert any(x.get('application_healthy') and not x.get('path_witnessed') for x in observations),task
        if label=='wrong-interface':assert task['rollback_status']=='completed',task
    elif label=='bad-content':
        assert task['apply']['returncode']==0 and task['rollback_status']=='completed',task
        assert any(x.get('path_witnessed') and not x.get('application_healthy') for x in observations),task
    print(json.dumps({'status':'passed','label':label,'task':task}))
def run_controller(label):
    output=h.native(['ip','netns','exec',A,sys.executable,str(Path(__file__)),'controller',label],timeout=250)
    return json.loads(output.splitlines()[-1])
def remove_router(name):
    base=Path('/var/lib/sentinel-blue-network')/name
    if not base.exists():return
    state=json.loads((base/'state.json').read_text());assert state['spec']['name']==name and name in {TAG,TAG+'bad'}
    service='sentinel-router-'+name
    if state['status']=='pending':network_native.rollback(state['spec'],state);state=json.loads((base/'state.json').read_text())
    if state['status']=='committed':
        assert network_native.table_fingerprint('sentinel_blue_'+name)==state['table_fingerprint']
        h.native(['systemctl','disable','--now',service+'.service'])
        h.native(['nft','delete','table','inet','sentinel_blue_'+name])
        for raw,digest in state['files'].items():
            p=Path(raw);assert network_native.digest(network_native.read(p))==digest;p.unlink()
        # A committed runtime record deliberately discards its before-state.
        # This fixture uses a fresh nonce name and refuses any pre-existing
        # forwarding chain before its first apply; the recorded file hashes
        # above identify only resources created by this fixture.
    h.native(['systemctl','disable','--now',service+'-rollback.timer'],allowed=(0,1,5))
    shutil.rmtree(base);h.native(['systemctl','daemon-reload'])
def setup():
    assert os.geteuid()==0
    if shutil.which('nft') is None:h.native(['apt-get','install','-y','nftables'],timeout=180)
    before_policy=json.loads(h.native(['nft','-j','list','ruleset']) or json.dumps(dict(nftables=[])))
    (ROOT/'before-policy.json').write_text(json.dumps(before_policy))
    assert not any(x.get('chain',{}).get('hook')=='forward' for x in before_policy['nftables']),'This fixture requires a lab host without a pre-existing forwarding policy'
    # Explicitly refuse overlap with pre-existing routes, interfaces or namespaces.
    assert not any(x.get('dst','').startswith('10.201.') for x in json.loads(ip('-j','route','show','table','all')))
    assert not any(x.get('name') in {A,B} for x in json.loads(ip('-j','netns','list') or '[]'))
    for n in (A,B):ip('netns','add',n);ip('-n',n,'link','set','lo','up')
    for ns,iface,subnet in ((A,IA,1),(B,IB,2)):
        ip('link','add',iface,'type','veth','peer','name','peer'+iface[-8:])
        peer='peer'+iface[-8:];ip('link','set',peer,'netns',ns)
        ip('addr','add',f'10.201.{subnet}.254/24','dev',iface);ip('link','set',iface,'up')
        ip('-n',ns,'addr','add',f'10.201.{subnet}.1/24','dev',peer);ip('-n',ns,'link','set',peer,'up')
        ip('-n',ns,'route','add','default','via',f'10.201.{subnet}.254')
    ip('link','add','bypass1','type','veth','peer','name','bypass2')
    ip('link','set','bypass1','netns',A);ip('link','set','bypass2','netns',B)
    for ns,n,addr in ((A,'bypass1','10.201.3.1/24'),(B,'bypass2','10.201.3.2/24')):
        ip('-n',ns,'addr','add',addr,'dev',n);ip('-n',ns,'link','set',n,'up')
    for name in ('route-key','route-host-key'):h.native(['ssh-keygen','-t','ed25519','-N','','-f',str(ROOT/name)])
    (ROOT/'route-authorized-keys').write_text('from="10.201.1.1",no-agent-forwarding,no-port-forwarding,no-X11-forwarding,no-pty '+(ROOT/'route-key.pub').read_text())
    (ROOT/'route-known-hosts').write_text('[10.201.1.254]:48271 '+(ROOT/'route-host-key.pub').read_text())
    config=f'Port 48271\nListenAddress 10.201.1.254\nHostKey {ROOT}/route-host-key\nAuthorizedKeysFile {ROOT}/route-authorized-keys\nPasswordAuthentication no\nKbdInteractiveAuthentication no\nPermitRootLogin prohibit-password\nUsePAM yes\nPidFile {ROOT}/sshd.pid\nAllowUsers root\n'
    (ROOT/'sshd.conf').write_text(config)
    privsep=Path('/run/sshd');privsep.mkdir(mode=0o755,exist_ok=True)
    assert privsep.is_dir() and not privsep.is_symlink() and privsep.stat().st_uid==0 and not privsep.stat().st_mode&0o022
    sshd=h.child(['/usr/sbin/sshd','-D','-e','-f',str(ROOT/'sshd.conf')])
    for attempt in range(30):
        if sshd.poll() is not None:raise RuntimeError((ROOT/'child-0.log').read_text()[-800:])
        try:
            with socket.create_connection(('10.201.1.254',48271),timeout=1) as connection:
                assert connection.recv(128).startswith(b'SSH-2.0');break
        except OSError:time.sleep(.1)
    else:raise RuntimeError('Owned SSH listener did not start')
    h.native(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-keyout',str(ROOT/'route.key'),'-out',str(ROOT/'route.crt'),'-days','2','-subj','/CN=owned-route','-addext','subjectAltName=IP:10.201.2.1'])
    for port in (48272,48273):h.child(['ip','netns','exec',B,sys.executable,str(Path(__file__)),'server',str(port)])
def server(port):
    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):self.send_response(200);self.send_header('Content-Length','7');self.end_headers();self.wfile.write(b'desired')
        def log_message(self,*args):pass
    service=http.server.ThreadingHTTPServer(('10.201.2.1',port),Handler)
    if port==48273:
        context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);context.load_cert_chain(ROOT/'route.crt',ROOT/'route.key');service.socket=context.wrap_socket(service.socket,server_side=True)
    service.serve_forever()
def run():
    before=Path('/proc/sys/net/ipv4/ip_forward').read_text().strip();before_witness=set(Path('/var/lib/sentinel-blue-route-checks').glob('*/state.json'))
    if os.environ.get('SENTINEL_ROUTE_DIAGNOSTIC')=='1':
        selected=h.case
        h.case=lambda name,fn:selected(name,fn) if name=='real-ssh-router-http-and-https' else None
    try:
        setup()
        h.case('real-ssh-router-http-and-https',lambda:run_controller('healthy'))
        def bypass():
            ip('-n',A,'route','add','10.201.2.1/32','via','10.201.3.2');ip('-n',B,'route','add','10.201.1.1/32','via','10.201.3.1')
            try:return run_controller('bypass')
            finally:ip('-n',A,'route','del','10.201.2.1/32');ip('-n',B,'route','del','10.201.1.1/32')
        h.case('reachable-bypass-rejected',bypass)
        h.case('wrong-router-interfaces-rejected',lambda:run_controller('wrong-interface'))
        h.case('routed-bad-content-rollback',lambda:run_controller('bad-content'))
        def expiry():
            flow={'router_name':TAG,'source':'10.201.1.1','destination':'10.201.2.1','source_port':49271,'destination_port':48272,'in_interface':IA,'out_interface':IB}
            token=uuid.uuid4().hex
            r=h.TRANSPORT.execute(h.HOST,witness_script('arm',flow,token),15);assert r.returncode==0,asdict(r)
            state=Path('/var/lib/sentinel-blue-route-checks')/token/'state.json'
            deadline=time.monotonic()+70
            while time.monotonic()<deadline:
                if json.loads(state.read_text()).get('status')=='closed':break
                time.sleep(.5)
            assert json.loads(state.read_text())['status']=='closed'
            assert 'sentinel_path_'+token not in h.native(['nft','list','tables'])
            return {'timer_expired_without_controller':True,'token':token}
        h.case('native-witness-expiry',expiry)
    finally:
        for p in h.CHILDREN:
            if p.poll() is None:p.terminate()
        for p in h.CHILDREN:
            try:p.wait(timeout=5)
            except subprocess.TimeoutExpired:p.kill();p.wait(timeout=5)
        for name in (TAG+'bad',TAG):remove_router(name)
        h.native(['sysctl','-w','net.ipv4.ip_forward='+before])
        for n in (A,B):h.native(['ip','netns','delete',n],allowed=(0,1))
        witness_states=[]
        for state in set(Path('/var/lib/sentinel-blue-route-checks').glob('*/state.json'))-before_witness:
            data=json.loads(state.read_text());assert data['flow']['router_name'] in {TAG,TAG+'bad'}
            witness_states.append(data)
            assert data['status']=='closed'
            h.native(['systemctl','stop','sentinel-path-'+data['token']+'.timer'],allowed=(0,5))
            shutil.rmtree(state.parent)
        (ROOT/'witness-states.json').write_text(json.dumps(witness_states,indent=2))
        h.REPORT['cleanup']={'namespaces_removed':True,'forwarding_restored':Path('/proc/sys/net/ipv4/ip_forward').read_text().strip()==before}
        h.REPORT['status']='passed' if h.REPORT['cases'] and all(x['passed'] for x in h.REPORT['cases'].values()) else 'failed'
        h.save()
        (ROOT/'router-receipt.json').write_text(json.dumps(h.REPORT,indent=2))
if __name__=='__main__':
    if sys.argv[1]=='server':server(int(sys.argv[2]))
    elif sys.argv[1]=='controller':controller(sys.argv[2])
    elif sys.argv[1]=='run':run()
