"""Verify recorder coverage of real repairs on explicitly owned native fixtures.
Creates and removes uniquely named loopback services; changes no existing service.
"""
import argparse, hashlib, json, os, subprocess, sys, tempfile, time, zipfile
from pathlib import Path


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runtime',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--owned-native-test',action='store_true',required=True)
    args=parser.parse_args()
    runtime=args.runtime.resolve(strict=True)
    sys.path[:0]=[str(runtime),str(Path(__file__).resolve().parents[1])]
    import sentinel_blue
    from sentinel_blue import recording
    from sentinel_blue.security_native import powershell_json
    from tools.service_repair_native import scenario,PYTHON_WORKER,CSHARP_WORKER
    if str(runtime) not in sentinel_blue.__file__:raise ValueError('Packaged runtime not loaded')
    os.umask(0o077)
    root=Path(tempfile.gettempdir())/('sentinel-recording-actions-'+os.urandom(6).hex())
    root.mkdir(mode=0o700)
    if os.name=='nt':
        subprocess.run(['icacls',str(root),'/inheritance:r','/grant:r','*S-1-5-18:(OI)(CI)F','*S-1-5-32-544:(OI)(CI)F'],check=True,capture_output=True)
    args.output=args.output.absolute();args.output.mkdir(parents=True,exist_ok=True)
    r=recording.Recorder(root/'recordings',role='owned-native-repairs')
    recording._current=r
    checks={};timings={};errors={};began=time.monotonic()
    try:
        executable=root/('owned-service.exe' if os.name=='nt' else 'owned-service.py')
        if os.name=='nt':
            source=CSHARP_WORKER.replace('if(Encoding.ASCII.GetString(request,0,length).StartsWith("GET /owned-crash HTTP/")) { Environment.Exit(71); }','')
            powershell_json("Add-Type -TypeDefinition $p.source -OutputAssembly $p.output -OutputType WindowsApplication -ReferencedAssemblies System.ServiceProcess,System; 'true'",{'source':source,'output':str(executable)})
        else:
            executable.write_text(PYTHON_WORKER);executable.chmod(0o700)
        for kind in ('damaged_files','running_unhealthy','failed_validation'):
            try:
                timings[kind]=scenario(root/kind,executable,kind,checks)
            except Exception as exc:
                checks[kind+'_completed']=False
                errors[kind]=type(exc).__name__+': '+str(exc)[:400]
        r.stop();path=r.export();manifest=recording.inspect_bundle(path)
        with zipfile.ZipFile(path) as z:events=[json.loads(x) for x in z.read('events.jsonl').splitlines()]
        results=[x['data']['result'] for x in events if x['kind']=='controller_action_result']
        checks['successful_repair_captured']=any(x.get('success') is True and x.get('stable_health') is True for x in results)
        checks['failed_validation_and_rollback_captured']=any(x.get('success') is False and x.get('rolled_back') is True for x in results)
        checks['audit_captured']=any(x['kind'] in {'audit_committed','audit_pending_transaction'} for x in events)
        checks['no_recorder_storage_errors']=manifest['storage_errors_this_process']==0 and manifest['storage_errors_all_sources']==0
        checks['no_recorder_drops']=manifest['dropped_events']==0
        import shutil
        shutil.copyfile(path,args.output/'action-recording.zip')
        report={'passed':bool(checks) and all(checks.values()),'checks':checks,'errors':errors,
                'repair_seconds':timings,'seconds':time.monotonic()-began,'event_counts':manifest['event_counts'],
                'runtime_sha256':hashlib.sha256(runtime.read_bytes()).hexdigest(),'version':sentinel_blue.__version__,
                'scope':'Real native service manager, owned files, HTTP checks, planner, executor and journal; in-process controller action submission, not a signed action-transport test',
                'fixture_root':str(root)}
        (args.output/'actions.json').write_text(json.dumps(report,indent=2))
        print(json.dumps({'passed':report['passed'],'checks':checks,'seconds':report['seconds']}),flush=True)
        return 0 if report['passed'] else 2
    finally:
        recording._current=None;r.close()

if __name__=='__main__':raise SystemExit(main())
