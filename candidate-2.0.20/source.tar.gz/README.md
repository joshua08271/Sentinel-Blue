# Sentinel Blue 2.0.20

## Linux test candidate: verified process identity and cleanup

This candidate fixes private permissions when copying nested recovery-capsule metadata and updates the native test harnesses. See `docs/LINUX_TEST_CANDIDATE_2.0.20.md` and the companion testing checkpoint for exact measured results and remaining acceptance gates. Historical results below apply only to their named releases.

---

# Sentinel Blue 2.0.18

## Corrective release: stale stop requests, failed undos and undelivered restarts

2.0.18 keeps everything in 2.0.17 and fixes three problems that could stop or hold automatic recovery:

- **A leftover stop request no longer stops the next start of a local session.** Each stop request names the runner it is for: the running one, or the one a GUI start launched. The runner removes the request once honoured, and removes stale ones at start. Before, after a Stop or a failed GUI start, the next start of the same session stopped within a second of becoming ready. A status left by an earlier run no longer fails the next GUI start either.
- **12. An undo that changed nothing no longer holds Resume forever.** Only an undo that failed after it began changing the host is marked for review. That case now appears in the GUI's review queue. The controller accepts the operator's review only when the agent's latest observation, collected after the failure, is fresh, complete and reports no interrupted change, and the service is in a known state. The agent's result is kept as reported, and the review is recorded beside it. The agent now finishes an interrupted undo of an automatic start with restart permission alone.
- **13. A restart no agent received no longer uses the failure budget.** An automatic restart that expired before any agent received it is not counted, exactly like one cancelled by Pause. It also no longer blocks an undo or setup redo. Restarts that were received, or that ran and failed, still count.

Read `docs/AUTONOMY_FIXES_2.0.18.md` for the exact behavior and upgrade notes. No approval, authentication, backup, ownership, baseline or offline requirement is relaxed. Review bugs 15–20 are not part of this release. This release is not a live VM deployment or a competition-uptime certification.

---

## Historical implementation notes (not current-build acceptance)

# Sentinel Blue 2.0.17

## Corrective release: the next five autonomy fixes

2.0.17 keeps everything in 2.0.16 and fixes bugs 6, 7, 8, 9 and 11 of the 2.0.15 autonomy review (bug 10 was fixed in 2.0.16). Each one could stop automatic recovery during an event with nobody watching:

- **6. The local session restarts a process that exits.** The GUI's local session no longer ends when the agent or the controller supervisor exits. It restarts that process after 2 s, doubling up to 60 s, and never gives up. A supervised controller whose supervisor has died stops cleanly instead of holding the database. Starting a session again first stops, by verified process identity, the processes an earlier run left behind, and a start that fails keeps that record for the next one. A withdrawal pause, or a changed profile or runtime, still ends the session instead of restarting it.
- **7. A refused result no longer stops all later work on the host.** After four signed 400, 403 or 409 refusals, a result stays recorded and is still offered, but it no longer holds new work. The controller still holds that action as unresolved until an operator reconciles it. Results not yet delivered, or answered 404 (the controller has no record), still hold new work.
- **8. An automatic start is validated for as long as the service needs.** The journaled Linux start uses the service's `repair_policy.validation_timeout_seconds` (5–120 s), or 30 s without one, instead of a fixed 5 s. The window is signed in the recovery guard. A service that never becomes healthy is still rolled back.
- **9. Recovery works when the agent's clock differs from the controller's.** The agent bounds the clock difference over each continuity round trip and reports it. The controller judges telemetry freshness on the agent's clock, erring towards "older", so network delay cannot make an old sample look fresh. Online continuity accepts up to 240 s of difference. Offline authority still requires the clocks to agree within 5 s, and the controller now refuses to authorize it otherwise.
- **11. Reconciling an unknown outcome as executed no longer ends automatic restarts.** It now closes the service's outage alert, so the next outage is restarted. An alert left open by an earlier release is closed the next time the service is seen stopped.

Read `docs/AUTONOMY_FIXES_2.0.17.md` for the exact behavior, what is still held on purpose, and upgrade notes. No approval, authentication, backup, ownership, baseline or offline requirement is relaxed. Bugs 12, 13 and 15–20 from the review are not part of this release. This release is not a live VM deployment or a competition-uptime certification.

---

## Historical implementation notes (not current-build acceptance)

# Sentinel Blue 2.0.16

## Corrective release: automatic recovery keeps running with nobody watching

2.0.16 keeps everything in 2.0.15 and fixes the first five bugs in the 2.0.15 autonomy review. Each one could switch automatic recovery off during an event without anyone noticing:

- **1. The alert quota no longer switches recovery off.** An outage of a service that the recovery planner has confirmed for its host opens its alert in a reserved, bounded lane. That lane is outside the per-severity quota and the per-sample candidate caps. A red team that opens 40 high or 64 critical alerts, or stops eight unscored services first (bug 10), can no longer block the restart. Other alerts keep their quotas.
- **2. A controller crash no longer leaves automation off.** A guarded-autonomous GUI workspace now sets `recovery.resume_after_controller_crash`, so an unclean restart resumes the saved governance (a saved Pause stays paused). The authenticated recovery key and anchor are still required. **Resume approved changes** also restores the approved profile mode, and the mode line now says whether automatic changes can run. A start that fails before serving (port taken, TLS file unreadable) is recorded as a failed start, not a crash, unless the run before it was itself unclean.
- **3. A wall-clock step no longer stops the agent's actions.** An NTP or `date -s` step revokes the offline policy and lease and re-baselines the clock. Online, controller-signed work continues from the next sync. Offline work stays held until a fresh signed sync, and a backward step can never extend offline authority.
- **4. A process running from a deleted executable holds only its own service.** Each payload-coverage gap now names the service it belongs to (from the process's cgroup, or the unit file that references the payload). A gap in another service, or in no service, is still reported but no longer holds this service's restart or repair. Gaps that cannot be attributed still hold recovery. The restart-only path now honours `allow_unrelated_payload_errors` (bug 14), which no longer ignores a gap attributed to the service itself.
- **5. The controller supervisor never gives up.** A controller exit that the supervisor did not ask for (including SIGTERM sent to the child alone) is restarted. Repeated failures back off to one attempt a minute instead of stopping. A malformed status file is set aside, and a failed heartbeat or status write is logged instead of crashing. The boot unit uses `Restart=always` with no start limit.

Read `docs/AUTONOMY_FIXES_2.0.16.md` for the exact behavior, what is still held on purpose, and upgrade notes. No approval, authentication, backup, ownership, baseline or offline requirement is relaxed. Bugs 6–9, 11–13 and 15–20 from the review are not part of this release. This release is not a live VM deployment or a competition-uptime certification.

---

## Historical implementation notes (not current-build acceptance)

# Sentinel Blue 2.0.15

## Corrective release: service-automation holds survive profile re-approval and controller restore

2.0.15 keeps the 2.0.14 automatic Linux recovery, recorded GUI undo and durable per-service holds, and corrects four defects found in an independent review of 2.0.14:

- **R214-01**: re-approving the event profile no longer strands agents or takes down the dashboard. Each agent's hold record is carried into the new profile's lineage on the controller and on the agent. Pauses and undo latches of still-approved services are kept and audited, and each agent's hold state fails on its own instead of breaking the dashboard.
- **R214-01b**: a controller restored from an older backup no longer cuts agents off. The agent keeps its durable floor and holds only automatic recovery, while manual work, checks and undo still run. It reports its floor on the signed poll, the GUI shows it, and one explicit Pause, Resume or undo approval re-synchronizes the controller while carrying every agent hold forward.
- **R214-02**: the offline hold gates match the collector's real `Linux <kernel release>` platform value. A paused or undone service no longer gets new offline authority or spends an offline attempt.
- **R214-03**: the `tools/live_systemd_lab` scripts are executable again, and the build refuses sources that lose that mode.

Read `docs/AUTOMATIC_UNDO_2.0.15.md` (also shipped as `Sentinel_Blue_2.0.15_Recovery_and_Undo_Guide.md`) for scope, permissions, upgrade, restore and offline behavior. No permission, budget, baseline or Emergency Stop rule is relaxed. This release is not a live VM deployment or a competition-uptime certification.

---

## Historical implementation notes (not current-build acceptance)

# Sentinel Blue 2.0.14

## Automatic Linux recovery with recorded GUI undo and durable service holds

Already approved automatic Linux starts now use a no-file coordinated journal under the existing restart authority. Automatic configuration repairs and declared file restorations share the GUI history/undo workflow; signed reconciled offline starts are included. A service that recovered itself is validated without a mutation or fake undo. Missing forward/inverse permissions remain a refusal, not a silently expanded profile.

**Services → select VM/service → Choose action / Undo… → History / undo** labels Automatic versus Operator actions. Approving a recorded inverse durably pauses the affected service before queuing undo. A local sticky hold survives lost replies/restarts and blocks offline reapplication. **Pause automatic recovery / Resume approved automatic recovery** explicitly control that hold without granting permissions, resetting budgets or overriding global governance. Never-delivered queued automatic work is cancelled with retained evidence; dispatched work is not declared cancelled.

Read `docs/AUTOMATIC_UNDO_2.0.14.md` for exact scope, permissions, migration, offline behavior, no-op and undo limitations. Full setup jobs use their existing reviewed rollback workflow. Retry policy candidates still require approved coordinated deployment; no live profile migration is claimed. Windows-specific files and the offline runtime remain preserved. This release is not a live VM deployment or a competition-uptime certification.

# Sentinel Blue 2.0.13

## Operator-selected Linux recovery, exact recorded undo, and repeat-recovery policy

On **Services**, select the exact VM/service and choose **Choose action / Undo…**. The dialog offers declared checks, an undoable start of a clean stopped service, or a full approved repair. Review is read-only; explicit approval queues a signed, evidence-bound action. History distinguishes queued work from agent-confirmed results and offers review of an exact journal inverse, never a whole-VM restore or overwrite of conflicting later changes.

The **Repeated-disruption policy** tab can save a private unapproved per-service profile candidate with a 15–300 second cooldown and 1–120 attempts/hour. Only explicitly approved policy changes can take effect after matching controller/agent redeployment. Failures retain three/hour and a 300-second cooldown; unknown outcomes, unsafe rollback, missing authority and Emergency Stop remain held. Full setup-redo keeps its separate limits. No attempt history is cleared.

Read `docs/OPERATOR_RECOVERY_2.0.13.md` for exact fields, undo limitations and profile activation requirements. Dedicated management from 2.0.12 and Windows-specific files are preserved. This release does not deploy to a VM, hot-edit active profiles, remove an adversary, or establish event uptime.

---

## Historical implementation notes (not current-build acceptance)

# Sentinel Blue 2.0.12

## 2.0.12 dedicated-management option

Linux **Start here → Dedicated management… / Join as agent…** prepares an approved controller-only workspace on a separate authorized management host and host-specific agent-only joins. It does not move existing sessions automatically or create a VM. Same-host root isolation, full off-host restore-blob replication, automatic failover and native multi-VM acceptance are not claimed. See `docs/DEDICATED_MANAGEMENT_2.0.12.md` before deployment. Existing single-VM and Windows-specific implementations are retained.


Corrective release for the five findings in the second Linux review of 2.0.10 (SB210-R2). Exact withdrawal restores runtime/persistent enablement and mask lifetimes. Completed repair history is archived without deleting undo evidence or consuming the unfinished-work gate. HAProxy and Samba checks prove generated configuration is loaded; Dovecot edits remove obsolete listener options; Gunicorn emits valid bracketed IPv6 binds.

The complete Linux `.run` retains the supplied offline Python/Tk dependencies. Windows-specific modules and PowerShell helpers remain included. Native service packages are separate prerequisites. Read `docs/LINUX_HOTFIX_2.0.11.md` and the matching measured validation report before upgrading; preserve the whole private state tree, including archived repair history. Older runtimes cannot look up migrated archives, so do not downgrade active migrated state. Reconcile old pending work first, update controller/agents together, and regenerate/reapprove affected setup plans.

No live VM, native daemon catalog, Windows lifecycle, reboot, polkit or competition acceptance is implied. Opening a new GUI is not a deployment or an upgrade of running services.

---

## Historical release notes (not current-build acceptance)

# Sentinel Blue 2.0.10

Corrective release for all five findings in the independent 2.0.9 review (SB209-01 through SB209-05).
The complete Linux `.run` retains the supplied Python, Tcl/Tk, dependencies and licenses. Native service packages are still separate prerequisites.

Retention and redo governance now share the same classification of failed repair records, including unreadable parameters. Manual redo selects only unheld covered services and reports exclusions, without weakening signed live or shared-dependency checks. The automatic hourly redo budget is per service, including batch/wildcard and host-qualified history. New BIND zones use the correct zone-file comment marker. Standard wheels include the Windows PowerShell helpers.

Read `docs/LINUX_HOTFIX_2.0.10.md` and the current measured validation report. No native VM/polkit, Windows lifecycle, reboot, or competition acceptance is implied. Keep ledgers and recovery receipts; opening the new GUI does not upgrade existing agents or authorize a deployment. Re-review setup plans because corrected generated content changes their approved digest.

---

## Historical release notes (not current-build acceptance)

# Sentinel Blue 2.0.9

Corrective offline Linux release for the independent 2.0.8 review (R208). Full installer and source are embedded in the accompanying all-in-one HTML. Python and GUI dependencies remain bundled; no download/activation is needed. Native server packages remain prerequisites.

Operator-started **Recovery → Redo approved setup** works again: the live governance view is fetched before its freshness is judged, and freshness uses this machine's receipt time instead of comparing two machines' clocks. Unresolved-repair holds are per approved service (maintenance grants still hold the whole host). A running redo worker polls the controller at most every 2 s between tasks while still checking fresh before every mutation, and Emergency Stop keeps a reserved replay allowance. Unclean or unreadable failed repairs are pinned against both pruning and history archival, so an unresolved rollback hold no longer disappears after 7–30 days; clean rollbacks follow ordinary retention and only unresolved repairs count toward the governance bound. Redo worker connection files are never written for a paused Setup and are removed when a redo ends. See `docs/LINUX_HOTFIX_2.0.9.md` and the measured validation report.

Old generated helpers, running sessions and boot registrations do not auto-upgrade when a new GUI opens. Preserve all private recovery state; upgrade/reapprove the controller and agents together. No native VM/polkit, reboot or competition acceptance is claimed by this corrective build.

---

## Historical release notes (not current-build acceptance)

# Sentinel Blue 2.0.8

Corrective offline Linux release for all five R207 review findings. Full installer and source are embedded in the accompanying all-in-one HTML. Python and GUI dependencies remain bundled; no download/activation is needed. Native server packages remain prerequisites.

Setup redo now rechecks live authenticated governance at dispatch and before new task mutations. Active maintenance grants, observe/approval downgrades and unresolved rollback failures cannot be bypassed by this fallback. Unavailable backup metadata and full missing-backup identifiers are delivered as structured evidence, separate from shortened alert text. See `docs/LINUX_HOTFIX_2.0.8.md` and the measured validation report.

Old generated helpers, running sessions and boot registrations do not auto-upgrade when a new GUI opens. Preserve all private recovery state; upgrade/reapprove the controller and agents together. No native VM/polkit, reboot or competition acceptance is claimed by this corrective build.

# Sentinel Blue 2.0.7

Linux corrective release for the five independent 2.0.6 findings. Use the complete `sentinel-blue-2.0.7-linux-gui1-x86_64.run` for offline, bundled-Python startup. The standalone `.pyz` alone is not that bundle. See `docs/LINUX_HOTFIX_2.0.7.md` for exact fixes, metadata migration and current validation limits. Source and tests are included. No automatic network downloads or activation are required.

**New:** authenticated redundant restore metadata, truthful redo closure, full DNS response validation with an explicit local DNS contract, batched-redo cooldown enforcement and bounded shallow-first configuration discovery with coverage warnings.

**Current validation:** use the accompanying 2.0.7 measured report. Older live results below identify their own earlier builds; they are not native acceptance of this release. Native service packages remain prerequisites. Reapprove the new version/hash and preserve old recovery evidence when upgrading.

---

## Historical release notes and general reference

# Sentinel Blue 2.0.6

**Untested build.** 2.0.6 has been run end to end against a real systemd, but not yet on a lab VM with a desktop. Read `docs/LINUX_HOTFIX_2.0.6.md`.

**Linux double-click installer:** `sentinel-blue-2.0.6-linux-gui1-x86_64.run` is the complete offline download, with Python, Tk and every dependency included. Mark it executable, then double-click it. `sentinel-blue.pyz` is the same program for a machine that already has Python 3.11+, Tk and cryptography.

## Release notes: 2.0.6 — the issues left after 2.0.5, and twelve more found live (untested)

The issues listed as open after 2.0.5 are fixed: one inventory-review alert
per host; the Withdraw tab explains a single-VM result and offers **Allow
Sentinel on this VM again…**; restore points have a private second copy; a setup
redo runs only the services it is for, and a failed service on a network host
can be redone too; the PostgreSQL pack fits PostgreSQL 16 (Ubuntu 24.04); a
catalog folder stands for its files; two packs fit in one plan.

Running 2.0.6 against a real systemd with the Redis, PostgreSQL and gunicorn
packs then found twelve more, all fixed. The ones that stopped something working:

* **PostgreSQL could not be set up or baselined at all**, for five separate
  reasons: the review and the setup job built its two parent files in different
  orders ("Configuration changed after review"); the pack would have widened
  `pg_hba.conf` from 0640; its check ran `pg_conftool … show`, which only prints
  usage; `postgresql.service` stays "active (exited)" and was never read as
  running; and with Redis also checked on 127.0.0.1, both checks had the same
  name, so both services stayed "unverified". Now it is set up, verified,
  repaired (6 s) and redone.
* **A setup redo could not fix a damaged file**, only a deleted one: it refused
  anything but the reviewed before-state. A redo may now replace a file its
  approved step owns. Corrupted configuration plus deleted backups: back in 22 s.
* **A new unit that failed to start could not be rolled back**, which held every
  other setup task on the host. The gunicorn pack's unit also never loaded
  (systemd does not unquote `WorkingDirectory=`).
* **A stopped boot controller could no longer be removed** (nor withdrawn), and
  its registration disappeared from the status.

Also: fewer stale alerts (a wrapper's cluster, a superseded failed repair, and
the items Sentinel's own setup created close when they are resolved), and no
repair is offered whose restore point is gone. A red-team batch across four
services recovered all of them in 19 s. Read `docs/LINUX_HOTFIX_2.0.6.md`.

## Release notes: 2.0.5 — the issues left after 2.0.4, and ten more found live (untested)

The issues listed as open after 2.0.4 are fixed: a unit stuck stopping is named
correctly and setup's `systemctl` calls are bounded; firewall, route and
interface gaps (or a host without `ip`/`ss`) no longer hold recovery; an
interrupted setup can be reconciled on evidence; Withdraw after a setup redo
returns the pre-Sentinel state; custom checks may target this VM's own address;
a verified repair closes its incident's alerts.

Running 2.0.5 against a real systemd then found ten more, all fixed. The ones
that stopped something working:

* **Configuring Redis could never start** on stock Ubuntu: its 106 KB
  `redis.conf` overflowed the setup step. Setup payloads are now compressed.
* **A pack refused before changing anything was reported "uncertain"**, which
  holds all later setup. It is now an ordinary failure. Ubuntu's `/etc/redis` is
  owned by `redis`, which setup will not write under as root; the pack is now
  refused at review with that reason, and adopting Redis still repairs it.
* **Repair never ran for a daemon that restarts on failure** (`Restart=always`)
  when its configuration was corrupted: the restart loop held it. A repair that
  restores the changed file now proceeds.
* **One `useradd` held a service's repair**: host-wide files the baseline watches
  (`/etc/passwd`, `/etc/hosts`, `sudoers`…) counted as that service's
  configuration. They are now marked `host_files`: still watched and alerted on,
  but they no longer hold recovery.
* **Deleted restore points went unnoticed** until a repair failed. They are now
  rebuilt from files that still match, or reported lost.
* **After Withdraw there was no way back**: `sentinel-blue withdraw-release`
  records the decision to use Sentinel on the host again.

Also: fewer stale alerts (baseline approval and a successful setup redo close
what they resolved), and plainer Services-tab wording. A red-team batch (unit
file deleted, page defaced, Redis masked and misconfigured, new account,
poisoned `/etc/hosts`) recovered every service in 12 s. Read
`docs/LINUX_HOTFIX_2.0.5.md`.

## Release notes: 2.0.4 — found by running it against a real systemd (untested)

Running the guided local flow against a real systemd found seven faults. Three
of them stopped all recovery on the host:

* **A second local session could never act.** The agent's trusted-controller
  floor was keyed only by agent id, so after *Change local choices* or an
  upgrade the new session's controller was refused forever: no restore points,
  no baseline, no restart or repair. The floor now belongs to its deployment.
* **One ordinary firewall rule held all recovery.** nftables prints a notice
  for every table iptables-nft owns (ufw, Docker, `iptables -m state`). The
  collector took it as a failed query, so the baseline could not be approved and
  every restart and repair was held. The notice is now recognised.
* **A service that died right after starting left setup "uncertain"**, which
  held every later setup and all recovery — and the 2.0.3 setup redo caused it.
  Setup now watches a started service stay up for 3 seconds.

Also: a deleted unit file is repaired (restored, reloaded, started); the redo
tells a repair that never started from one whose undo failed, and counts the
approved baseline as proof of health; the baseline waits for custom services;
and controller recovery backups, which failed on every host an agent had run
on, are written again. `tools/live_systemd_lab/` is the test harness.

## Release notes: 2.0.3 — repair reaches every service (untested)

**Every service chosen in Service setup can now be repaired**, not only
restarted: its own configuration files are restored from the approved baseline,
its unit is put back to enabled (including from a mask) and restarted, and its
check decides whether that worked — otherwise everything is rolled back.
Approval-based mode offers the repair for you to approve; guarded mode does it
on its own. Account, sudo, PAM and SSH-key files stay alert-only.

* **Services outside the catalog.** Service setup → *Add custom service…* takes
  a unit, its files and its check, and sets it up and repairs it like the rest.
* **Services on the rest of the network.** `sentinel-blue repair-grant` (or
  Setup → *Grant repair to every service…*) writes a new event profile granting
  each service a repair of the files that are its own. The original is untouched.
* **When repair fails, the approved setup runs again**, as a new job that must
  hash to the plan you approved and that leaves healthy services alone. Guarded
  mode does it automatically, rate-limited; Recovery → *Redo approved setup of
  this VM* does it on request.
* The repair engine gained masked units, `daemon-reload` after a restored unit
  file, and separate authority for approved and automatic repairs.

## Release notes: 2.0.2 — the firewall drops IPv6 too

**A host set to drop incoming traffic was still wide open over IPv6.** The router
adapter's nftables table is `inet`, so it sees both families, but both of its
drops were written `meta nfproto ipv4 drop`. On a host with IPv6 enabled — the
Linux default — `input_policy: drop` left every IPv6 listener reachable, and most
daemons (sshd, nginx, apache, PostgreSQL with `*`) listen on IPv4 and IPv6 at
once. So the whole host was reachable over IPv6 while the plan said default-deny.

* The input drop and the forwarding drop now cover both families.
* ICMPv6 is accepted ahead of the invalid-state drop. Neighbor discovery and
  packet-too-big are ICMPv6; blocking them takes a host off an IPv6 network
  instead of filtering it. This mirrors the IPv4 rule, which always accepted ICMP.
* Management and allow rules may name IPv6 sources (`2001:db8:100::/64`, `::/0`),
  written as `ip6 saddr`, so a service that must answer over IPv6 is allowed on
  purpose rather than left open by accident.
* Routing, NAT, forward rules and interface addresses stay IPv4 and still refuse
  an IPv6 network, so IPv6 transit through a forwarding router is dropped rather
  than half-supported.
* A network written as a number is refused. `ipaddress.ip_network(5)` is
  `0.0.0.5/32`, so `"source": 5` used to be admitted as a real, wrong, address.

**Upgrading:** reapplying an approved router plan replaces the table, which is
the change. If you reach a host's management port over IPv6, add an IPv6
management source before approving: the change closes IPv6 access it did not
list, and the rollback timer reverts it unless the change is confirmed.

`tools/firewall_reachability.py` shows which listeners a client can reach through
the generated rules, in a throwaway network namespace. Run it on a VM with IPv6
(`sudo unshare -n python3 tools/firewall_reachability.py .`). The machine this
was built on boots with IPv6 disabled, so there the IPv6 half was checked by
reading the generated rules and loading them into a real kernel, not by a live
IPv6 connection; IPv4 filtering was checked with real connections and is unchanged.

## Release notes: 2.0.1

**Linux offline distribution:** use the complete `sentinel-blue-2.0.1-offline-linux-x86_64.zip`, not the standalone `.pyz`. Python and GUI/security dependencies remain bundled. Read `docs/OFFLINE_RELEASE_2.0.1.md` and `docs/LINUX_HOTFIX_2.0.1.md`. This is the renamed successor to 1.9.101, correcting issues 31–36 and retaining earlier fixes. Native acceptance remains separate.

This release restores offline packaging and removes built-in online prerequisite downloads. Findings LINUX-26 through LINUX-30 were corrected in 1.9.101 (`docs/OFFLINE_RELEASE_1.9.101.md`); `docs/KNOWN_ISSUES_26-30.md` is the historical review that found them.

## Release notes: 1.9.99 — Linux review fixes 21–25

Authenticated resumable router confirmation, single-pass guarded withdrawal,
case-sensitive Linux path identity, unknown firewall evidence through telemetry
validation, and bounded batches of service metadata with nullable unknown restart
counts. The earlier 1–20 fixes and regressions are retained.
See `docs/LINUX_HOTFIX_1.9.99.md` and `tests/test_linux_hotfix_1999.py`.

Native systemd, VM boot, live router, distribution and multi-host acceptance remain
unestablished. Reapprove release hashes and regenerate plans. Upgrade the controller
with the agents to retain nullable telemetry values. Installed helpers and pending
timers do not update by replacing a desktop/runtime; preserve authenticated evidence.
Historical stranded confirmations lacking a bound intent remain held for review.

## Historical release notes (not validation of 1.9.99)


## Release notes: 1.9.98 — Linux review fixes 15–20

Authenticated router rollback completion/reconciliation, committed metadata
admission, idempotent router confirmation, effective/retained UID and capability
evidence, explicit persistence overflow diagnostics, and quota-enforced internal
native-client capture. Earlier fixes 1–14 and their regressions are retained.
See `docs/LINUX_HOTFIX_1.9.98.md` and `tests/test_linux_hotfix_1998.py`.

No native VM or competition acceptance is claimed. Regenerate and reapprove
setup plans. Installed helpers, pending timers and historical unresolved actions
do not update or repair themselves merely by replacing the desktop/runtime.
Keep ledgers, exact before-states and ownership/conflict evidence.

## Historical release notes (not validation of 1.9.98)


## Release notes: 1.9.97 — Linux review fixes 9–14

Per-object router rollback receipts, complete retained router startup/withdrawal
state, service-validation deadlines, safe routed-witness reads, truthful group
coverage, and a 16 MiB command-output capture limit. Earlier issues 1–8 fixes
remain. Boot audit snapshots no longer overwrite the original withdrawal pre-state.
See `docs/LINUX_HOTFIX_1.9.97.md` and `tests/test_linux_hotfix_1997.py`.

No native VM or competition acceptance is claimed. Regenerate and reapprove plans;
keep ledgers and backups. Installed helpers and pending timers do not update by
replacing the desktop runtime. Ambiguous old pending transactions require review.

## Historical release notes (not validation of 1.9.97)

## Release notes: 1.9.96 — Linux review fixes 5–8

This release corrects TCP/UDP listener evidence, creation ownership/readability
for restricted configuration, nonblocking/stable setup and router file reads,
and the mutation ledger's shared thread/process lock deadline. It retains the
1.9.95 fixes for issues 1–4. See `docs/LINUX_HOTFIX_1.9.96.md` and the regressions
in `tests/test_linux_hotfix_1996.py`.

No native service acceptance or competition uptime is claimed. Reapprove the
release version/hash and regenerate setup plans. Keep old mutation ledgers,
snapshots and pending-transaction evidence. Replacing the runtime does not
rewrite installed router helpers or previously generated scripts.

## Historical release notes (not validation of 1.9.96)


## Release notes: 1.9.95 — Linux review fixes 1–4

This release patches failed-apply file rollback ownership, collector subprocess
timeout handling, local POSIX process-group timeout cleanup, and pending-router
IP-forwarding ownership. The source contains targeted regression tests in
`tests/test_linux_hotfix_1995.py`. See `docs/LINUX_HOTFIX_1.9.95.md`.

The original review's issues 5–8 are not fixed by this patch. No native VM,
remote SSH, boot, Windows, or competition-uptime acceptance is implied. All
native catalog flags remain false. Existing review/approval gates stay in place.
Use a newly reviewed release version/hash and regenerate setup plans for the new
bytes; do not delete ledgers, repurpose old receipts, or overwrite a held pending
transaction. Already generated scripts and installed router helpers do not
change simply because the desktop runtime is replaced.

### Older release notes (not validation of 1.9.96)

## Release notes: 1.9.94

Corrective review of 1.9.93. The original input remains separate. No native pack
acceptance or competition availability is asserted by this release.

* Acceptance profiles now distinguish a builder-refused `rejected_options` case
  from `invalid_options` that must compile, enter writes and fail the native
  product check. All twenty earlier examples failed at planning; their native
  failed-apply cases remain explicitly pending instead of being misrepresented.
* Before the first mutation, the runner validates required probes, refusal
  signatures, generated-file changes and exact reviewed update pre-states, and
  resolves all three ordinary setup plans. Later execution must match those plans.
* A client error alone cannot prove denied access. Missing/truncated/timeout
  evidence remains invalid; explicit positive refusal signatures are required.
  stdout and stderr matchers now examine their named stream. `expect_output_*`
  is the explicit combined-stream alternative.
* Known password-in-argv and disabled SSH/TLS peer-verification forms are refused.
  Drafts no longer recommend those forms. Protected credential wrappers are
  operator-supplied prerequisites, not executables included in the product.
* Automatic alternate port suggestions require both current complete listener
  data and an absent-service observation. Existing/unknown services are not
  silently assigned an alternate merely because no port option was saved.
  Manual choices remain reviewed; an unspecified current port is not discovered.
* Duplicate-key/nonfinite/oversized input documents are refused. Hash-pinned
  sources are resolved relative to their own options/profile file for plan/run.

Read `docs/PACK_ACCEPTANCE_1.9.94.md` and the new VM-testing checklist. Keep the
matching source/tools and runtime together for acceptance testing. Runtime
response policy, controller/agent, service builders, launcher and recording are
unchanged. All 39 catalog flags remain false. The Linux package needs Python
3.11+, Tk and cryptography; it is not a Python-free executable.

## Historical release claims

The sections below record earlier releases. In particular, 1.9.93's assertion
that its drafts were ready to run is superseded by this correction: builder
rejection is not failed-apply rollback, and native product inputs and tests remain
pending. Historical test counts and partial native checks are not new results.

## Release notes: 1.9.93

Fills in the acceptance harness's example so it can actually be run, and closes
the input contract on the pack options the previous sweeps never touched. No pack
has still been run against a real product: **all 39 catalog entries report
`native_tested: False`**, and this host can still earn no receipt.

**Every configuring service now ships a reviewed acceptance draft.** A receipt
requires six things per service — the scored transaction, the weakening that must
be refused, a query that asks the running product what it is actually using, a
second reviewed option set, an option set the pack must refuse, and the observer
wiring that confirms the withdrawal. The 1.9.88 example was a deliberate *shape*
example: it carried `/REPLACE/` placeholders for five services and said on its
first line that it was intentionally not runnable. The shape was right; the
content was the work nobody had done. So an operator had to invent five things
per service before `--plan` told them anything useful, and fifteen of the twenty
services had no starting point at all.

There are now two files, both keyed by service id, covering all twenty:
`examples/acceptance-options.example.json` (the reviewed options each pack is
built from) and `examples/acceptance-profile.example.json` (the probes, the
update, the refusal). `--options` accepts a service-keyed file the way
`--profile` already did.

* **Mechanically verified, for all twenty:** both option sets compile through the
  real pack builder, the update produces a different pack fingerprint, the
  invalid set is genuinely refused and the refusal text is recorded beside it, a
  configuration test exists, every probe is a bounded argv list naming an
  absolute path, and `--plan` runs clean for every service.
* **Not verified, and marked DRAFT on every entry:** whether `dig` prints
  "Transfer failed" on a refused BIND, whether your Samba rejects `smbclient -N`,
  whether `swaks` exists at the path given. That is product behaviour, and no
  sandbox can observe it.
* The two packs that edit a file they did not generate refuse without the exact
  digest of what they are replacing. Pinning the string `SUPPLY-THE-DIGEST` can
  never be run, so the example now ships the files it pins with their real
  digests — and says plainly that your host's own file replaces them.
* `withdrawal` is deliberately left out rather than placeheld. It is four paths
  on your own observer; a placeholder passes the gate and then fails at the
  rollback step, after the host has been changed. Missing, `--run` refuses before
  touching anything and now names what each missing key is.
* Services whose data changes merely by running — a database, a mail queue, a
  lease file, `/var/log` — say so in the profile, because strict tree equality
  will not hold for them and a reviewed `data_invariants` query is the answer.
* The gate's list of required keys is a module constant instead of a local, and
  the new tests import it, so a key added to the gate without an answer in the
  example fails in the suite rather than on a host.

**Seven more option shapes crashed instead of explaining themselves.** The
malformed-input sweep that has run since 1.9.83 mutated the keys present in a
reviewed baseline, so an option a baseline happened not to set was never tried.
`dnsmasq addresses` written as a list called `.items()` on it; five list options
iterated `None`; `dovecot protocols` built a `set()` containing an unhashable
member. Each raised an `AttributeError` or `TypeError`, and the dialog that
collects these options only shows a correction for `ValueError` — so the operator
got no message at all. The sweep now walks every option each pack *declares*:
2,400 inputs across every declared option of 19 packs, every one refused with a
stated reason or accepted deliberately.

**An option written as null no longer throws its own default away.** `.get(name,
default)` cannot tell an absent key from a key present as null, so `"protocols":
null` quietly became an empty list — a Dovecot serving no protocol at all — and
`"mynetworks": null` a Postfix trusting nothing, in both cases instead of the
default the operator had just read in the documentation, and without a word on
screen. Absence keeps the default; null is refused with both alternatives named,
which is what `_boolean` has always done with a null where it wanted true or
false. Sixteen call sites across eleven packs.

**A service with no distribution package failed its first step.** `gunicorn`
wraps an application the operator supplies and declares no apt packages. The
preflight ran `dpkg-query -W` with no names, which lists every installed package
on the host and exits 0, compared that against zero expected rows, and reported a
missing package that was never required — and `--plan --service gunicorn` did not
print a plan at all, it raised `KeyError: 'apt'`. Both are fixed, and a test
plans every configuring service to keep them fixed.

Read `docs/PACK_ACCEPTANCE_1.9.93.md` for the full round, including what is
verified mechanically and what is still a draft nobody has run. VM-dependent
items remain explicitly pending in `docs/VM_TESTING_REQUIRED_1.9.93.md`.
`doctor` still reports **0 of 20 configuring services accepted**.

## Release notes: 1.9.92

Corrects the four findings in the independent 1.9.91 review and adds a beginner-facing
**Ports: Automatic / Manual…** editor. This is not native service acceptance.

* Local missing, unreadable, changed or unparseable TLS checking trust becomes
  unexecuted/unverified evidence, including preflight. Actual endpoint TLS/HTTP
  failures remain executed failures. Pinning and verification are not weakened.
* Probe identity now has the same name-or-target default in the checker, evidence
  matcher and controller success validator. Count/duplicate/target/execution checks remain.
* Nested restart-manifest and top-level deadline inputs fail with controlled errors.
  Historical sweep descriptions are not universal rejection claims.
* Select a catalog service, open **Ports: Automatic / Manual…**, and use labeled
  numeric fields. Automatic prefers a declared event/SSH-management requirement,
  then a saved configuration value, then the standard default. A separately enabled
  alternate candidate for eligible new listeners requires recent complete host
  listener data. The candidate is not reserved, and setup never hops to another port
  after review. **Automatic for selected…** uses safe defaults and never silently
  enables alternate selection.
* Port fields are available for 18 configuration adapters, including outbound
  rsyslog forwarding (not a local listener). The other 21 rows explain fixed,
  export-only or adopt-only boundaries. No missing installer is invented.
* Loaded event ports and remote SSH management endpoints are protected. Firewall,
  observer, scoring and client settings are not silently rewritten. The normal
  reviewed setup compiler rejects mismatched declared ports. A port edit alone does
  not supply missing certificates, credentials, data or complete configuration.

Read `docs/PORTS_AND_FIXES_1.9.92.md` for per-service coverage, required snapshots,
constraints and the test boundary. VM-dependent items remain explicitly pending in
`docs/VM_TESTING_REQUIRED_1.9.92.md`. All 39 native_tested flags remain false. Current
measured test counts and artifact identity are in the delivered validation report;
older release sections describe historical work rather than a new native campaign.


## Release notes: 1.9.91

A correctness round on the 1.9.89/1.9.90 repair-decision code. No new capability,
no change to any trust boundary, and **all 39 catalog entries still report
`native_tested: False`**.

**Four identified malformed-input crashes were corrected in 1.9.91.** This did not establish exhaustive input rejection; 1.9.92 also corrects the reported nested-manifest and deadline-helper cases.
Four places raised a `TypeError` or `AttributeError` rather than a stated reason:
`check_restart_target` tested `state not in stopped` before confirming the state
was a string, so an unhashable value crashed the membership test; the same
function called `.get()` on a manifest it had not confirmed was a mapping; and
`matching_probe_health` and `all_probes_healthy` validated their `rows` carefully
while not validating `specs` at all. Every caller of these paths reports a held
restart by catching `ValueError`, so anything else escapes as a traceback.

None of it was reachable from the network — `validate_telemetry` rejects a
non-string service state with its own clean error — but this is the layer behind
that one, and it decides whether a future caller gets a refusal or a crash.

**An empty probe contract no longer reads as health.** `all_probes_healthy([], [])`
returned `True`: with nothing declared there is nothing to fail, so a naive `all()`
reported success on no evidence. The default answer is now `False`, and a caller
for which "nothing declared" genuinely means "nothing to check" — restoring a file
that declares no probes, after configuration validation has already passed — says
so with `allow_empty=True` rather than relying on the subtlety.

**Health is claimed only where a transaction was declared.** The same trap sat one
level up: `_wait_for_service_probes` returns healthy for an empty contract, and an
approved `restart_service` may legitimately carry no probes. A restart of a service
with no declared transaction therefore reported `stable_health: True` having
measured nothing. The restart decision is unchanged — it was always gated on the
service-manager state — but `stable_health` is now omitted entirely in that case,
which downstream already reads as unconfirmed, and the message says health is
unverified. This follows the rule 1.9.80 established elsewhere: a check that was
never attempted is missing evidence, not health.

**A regression sweep now locks the class down.** This "use before type-check"
pattern has appeared three times: `_network`'s set membership on a nested list,
`_haproxy` calling `.get()` on a list element, and now the service state. Each was
reachable from a different direction and each was found by sweeping rather than by
reading, so the new tests sweep — selected shapes across the repair decision surface. This is a no-unexpected-exception robustness sweep, not a claim that every input is invalid or rejected. Explicit negative cases are tested separately.

## Release notes: 1.9.90

**Queued automatic restart revalidation.** The agent now checks the latest
available observation of the target, not only the original dependency guard.
A target newly reported disabled, masked, missing/ambiguous, transitional,
start-limited, memory/resource-failed, looping, or blocked by a declared port or
required-data filesystem causes the old restart to be held for a fresh diagnosis.
The agent uses the approved manifest, including required business-data paths.
The executor independently checks target facts available in its file/probe guard.
No startup policy is changed and no restart-futility safeguard is removed.

An unchanged legitimate outage retains the existing approved restart path. An
already running target is validation-only; a historical native failure result
is not treated as a reason to restart it. A target that stopped after the latest
running observation requires a new diagnosis instead of silently rebinding the
old action to a new outage. Refused envelopes keep the existing replay tombstone.

Freshness is also rechecked after dependency/file preflight and after fresh local
repair probes. A guard that expires while those operations run cannot admit a
new forward repair. Already admitted transactions retain existing validation and
rollback behavior; this is not cancellation of all work at an arbitrary deadline.

**Testing boundary:** local regression fixtures exercise profiles, real SQLite,
action journals and temporary files; service-manager and final service-validation
calls are mocked in the queued-action replay. No real VM/native service was
accepted. Latest telemetry is not a fresh native service-manager snapshot and
cannot reveal changes that have not yet been collected. No new guard/wire schema,
baseline restart-counter binding, or universal atomic race-proof operation was
added. The original controller still validates baseline-relative restart counts.

**REQUIRES VM TESTING — NOT RUN:** see `docs/VM_TESTING_REQUIRED_1.9.90.md`
and its JSON companion, especially VM-L17. All 39 catalog flags remain false.
Use the matching source and runtime, deliberately review the release version/hash
in event profiles, and never erase ledgers or change acceptance flags to bypass
holds. Linux desktop packaging still requires installed Python 3.11+, Tk and
cryptography; startup/recording and the launcher are unchanged.

## Release notes: 1.9.89

**Execution-time probe evidence correction.** A missing check is neither a
service outage nor a successful repair. This release closes an agent-side gap
where a running service could be stopped/restarted after a fresh local check
reported `executed: false`. A saturated bounded probe pool now reports that the
check was unattempted instead of manufacturing a service-failure observation.

Service repair rechecks require complete matching local evidence before stopping
anything. Missing native checking clients hold a restart/repair before mutation;
unknown dependency evidence cannot authorize it. Stable validation, configuration
restoration checks and controller success attestations reject unattempted,
malformed, duplicate or mismatched results. A genuine failed local transaction
still permits an otherwise approved repair. Existing legacy probe rows without
`executed` keep the established compatibility default, but explicit False is
never evidence of success or failure.

This does not enable new automatic actions, clear systemd start limits, install
missing clients, change event authority or remove rate limits. It does not
establish universal classification of every client/network error. Missing
credentials and other native-client edge cases need their own reviewed tests.

**REQUIRES VM TESTING / NOT RUN HERE:** real systemd restart/boot, live service
products and native credentials, remote SSH deployment, independent-observer
withdrawal, multi-host/controller-loss, load/endurance and adversarial campaigns.
All 39 catalog flags remain `native_tested: False`. See
`docs/VM_TESTING_REQUIRED_1.9.89.md` and `docs/vm-testing-required-1.9.89.json` for
individual product and environment checks. The new local regressions exercise
real temporary files, a real bounded worker pool and loopback HTTP; native service
control in repair fixtures is mocked. No native acceptance receipt is issued.

Use matching 1.9.89 source and runtime, review the new runtime checksum in event
profiles, and retain the original event approval process. This remains a Python
zipapp and a Linux desktop-launcher package, not a Python-free executable. Earlier
reports below are historical and must not be read as new test results.


## Release notes: 1.9.88

Corrects the eight issues in the independent 1.9.87 acceptance-tool review. This
is an evidence/acceptance correction, not new attack detection, autonomous repair,
Windows support, or a claim that service packs passed native acceptance.

- Restore & Withdraw now follows the real review -> exact digest approval ->
  execution workflow. It requires the recorded acceptance-owned action set,
  matching host scope, completed restoration and independent service checks.
  No production withdrawal, authority, ledger or observer guard is weakened.
- Typed, bounded filesystem evidence distinguishes absent paths from errors,
  includes regular-file bytes and directory descendants, and fails on lost
  coverage. Live data requires a quiet tree or reviewed logical invariants;
  symlinked data is not silently treated as verified target content.
- Outside edits must survive byte/metadata-exactly. The fixture keeps a private
  backup and refuses cleanup if somebody changed the edited object afterward.
- A failed-apply test requires observed writes, a real failed apply report and
  confirmed restoration. Builder rejection is not a passing interruption test.
  This is not a hard-crash, reboot or power-loss acceptance.
- Identical reapply compares native service invocation/restart evidence as well
  as file state. Effective configuration requires a product-specific query.
- nginx fingerprinting and owned-file discovery use its real production adapter.
- Receipt schema 2 rejects malformed nested evidence and invalidates schema 1.
  Summary/doctor compare the actual runtime. A current configuration/product
  context is required before historical results can count as accepted.

The acceptance tool requires the exact `--runtime`, explicit approved event
profile, complete probes, and an explicitly authorized disposable systemd host.
A reviewed external-observer forwarding wrapper is necessary for the production
Restore & Withdraw independent-verification contract. `--plan` displays a
review template, not a promise that all runtime-dependent commands are known.

See `docs/ACCEPTANCE_FIXES_1.9.88.md` for parameters, evidence scope and migration.
All 39 shipped catalog entries remain `native_tested: False`. Native Windows,
real service-manager/boot, other products and the shared Proxmox range are not
certified by the local regression suite. The Linux icon still needs installed
Python/Tk/cryptography; opening it does not automatically deploy an event.

### Historical release notes

The following is retained history. Claims made by 1.9.86/1.9.87 are qualified by
the defects and corrections above; they are not current native acceptance results.

## Release notes: 1.9.87

**The acceptance harness shipped in 1.9.86 could never succeed.** Eleven of its
seventeen required steps were recorded as skipped unconditionally — even with an
inventory supplied — so `--run` ended in "NO RECEIPT" on every host, forever. The
`--plan` checklist was real; the thing it promised was not reachable. That is
fixed here, and the fix is the release.

The harness now drives the ordinary setup path: it merges the service fragment
into a copy of your reviewed inventory, plans, takes the approval digest the
planner prints, executes against it, and then actually checks the result. It runs
the product's own configuration test, confirms the unit is active, fires the
scored transaction and the refused weakening, reapplies the identical plan and
requires nothing to change, applies a second reviewed option set and requires only
that to change, stages an edit outside Sentinel and requires the next apply to
refuse it without overwriting, forces a failure with a configuration the product
rejects and requires the exact pre-state to survive it, restarts the unit, then
withdraws and requires every watched path back at its captured digest.

**A profile now carries five things, and all five are required for a receipt:** the
scored transaction, the refused weakening, the product's offline configuration test,
a second reviewed option set for the approved-update step, and an option set the
product rejects so a failure can be forced. Anything missing is skipped, and
skipped is not a pass.

That last point exposed a real gap: **Redis declares no offline configuration test**,
so under 1.9.86's rules it could never have been accepted even in principle. The
catalog's own check is used when it exists and the profile supplies one when it does
not — and a service with neither is skipped rather than waved through.

**Verified by walking the whole matrix against a simulated host**, which is what
1.9.86 lacked: a healthy host now reaches a receipt and leaves the machine exactly as
it was found, and each of ten ways a host can fail is shown to block the receipt and
name the step. The fake is a model of a host, not a host — it proves the
orchestration asks the right questions and judges the answers, not that any real
product passes.

**Nothing has been accepted.** `doctor` still reports 0 of 20.

## Release notes: 1.9.86

Built on 1.9.85 and keeping every launcher correction in it. This round is the
other half of the honesty problem: a pack could be proven, but nothing could
record that it had been.

**A pack can now be proven, and the proof is recorded.** Every catalog row reports
`native_tested: False`, and that was the only thing it could ever say — proving a
pack against a real BIND or Postfix on a lab host left no trace, so the next
person had to take it on trust.

`tools/service_pack_acceptance.py` runs the acceptance matrix: 17 required steps
covering fresh setup versus adoption, the product's own configuration test, a real
client transaction, the weakening the pack must refuse, identical reapply, an
approved update, an edit made outside Sentinel, a failure forced mid-apply,
restart, rollback and withdrawal. `--plan` prints every command it would run and
changes nothing, so the whole acceptance is reviewed before any of it happens.
`--run` refuses unless you declare the host disposable, and unless it is root on a
Debian-family machine whose PID 1 is really systemd — a container stand-in cannot
accept a unit.

A passing run writes a **receipt**, and a receipt is evidence rather than
permission. It unlocks nothing: a pack with one compiles, refuses and rolls back
exactly as one without. It covers a single pack built from one exact set of
reviewed options, against a named product version, on one host, with one runtime,
and it carries a fingerprint of what that pack actually generates. Change an
option, change the builder, upgrade the runtime, move to another host, or let it
age past 180 days, and it goes stale and stops counting. An unreadable receipt, or
one missing a step, reads as untested. Every uncertainty resolves downward.

`doctor` reports how many packs this host has proven, and the service-setup summary
names them instead of only ever saying nothing is native-tested. **The shipped
catalog still reports `native_tested: False` for all 39 entries**, because that is
a fact about the source, and shipping a pack proves nothing.

The harness does not invent transactions. The scored transaction a service must
answer, and the weakening it must refuse, are product knowledge supplied in a
profile — `examples/acceptance-profile.example.json` shows four, including the trap
that `dig` exits 0 on a refused zone transfer, so a probe reading only the exit
status would call the failure a pass. Without a profile those two steps are
skipped, and since both are required, no receipt is written.

**Nothing has been accepted yet.** This ships the means, not the result: no pack in
this build has been run against a real product, and `doctor` says so — 0 of 20.

Also corrected: the example inventory's `public_url` still named the 1.9.84
runtime.

## Release notes: 1.9.85

Local acceptance: 1,009 tests with 15 headless / 14 graphical platform skips and no failures; 175 targeted packaged regressions, 44 continuity checks and 11 limited real web checks passed. These counts overlap and do not establish universal native support. The inherited 1.9.83 corpus produced 8,321 refusals and 39 accepted values out of 8,360 calls, with zero unexpected exceptions; the original all-refused wording below is historical, not a reproduced result.

Corrective launch validation release. Fresh default desktop storage is created privately before recording starts; unsafe existing storage is still refused. Detached desktop failures now reach the same visible error reporting as direct launch. Display connection failures are explained, control characters are sanitized, and failed notification helpers fall through instead of falsely reporting success.

Linux desktop integration uses an adjacent Python-stdlib helper (Python 3.11+ is already required by the runtime), specification-correct Exec escaping, and a private per-user exact-state receipt. Unowned/changed files and symlinks are held for review. Prepared receipts permit bounded interrupted-install/uninstall recovery. Legacy 1.9.84 entries without a receipt are not silently adopted or overwritten. The receipt is separate from, and never replaces, the Sentinel host mutation ledger.

The Linux ZIP still needs installed Python/Tk/cryptography; it is not a self-contained offline bundle. Opening the GUI does not automatically deploy an event or enable defense. All 39 service catalog entries remain native_tested: False. Native Windows, real systemd/reboot, additional service daemons, multi-host/Proxmox acceptance remain separate requirements. See docs/VALIDATION_1.9.85.md for measured evidence and limitations.


## Release notes: 1.9.84

**Starting it from a Linux desktop.** The runtime already opens the operator
window when it is started with no arguments, which is what a double-click passes.
What was missing was everything around that: a downloaded file arrives without its
executable bit, a file manager will not run a `.pyz`, and a launch from an icon has
no terminal — so when the window failed to appear there was nowhere for the reason
to go.

`packaging/linux-desktop/` now carries a launcher, an application entry, an icon and
a one-command installer. `sh install-linux-launcher.sh` restores the executable bit,
registers the application for your user, and puts an icon on the desktop. Nothing is
installed system-wide, nothing needs root, and `--uninstall` reverses it.

**A failed launch now says why, where you can see it.** Starting with no arguments
and hitting a missing Tk or no graphical session used to raise a traceback into a
stderr that a double-click discards. That reason is now shown in a dialog through
whichever helper the desktop provides, and the traceback is still printed for a
terminal launch, so nothing is hidden. The two messages name the exact package and
the exact command. The launcher reports a missing or too-old Python and a missing
`cryptography` the same way, because those stop the runtime before it can report
anything itself.

The dialog text is always passed as a single argument to an argument list — never
built into a shell command — so nothing in an error message can be executed.

This is the Linux half. The runtime is unchanged as the one portable file that runs
on either platform; **the Windows launcher is not written yet** and nothing here has
been run on Windows.

## Release notes: 1.9.83

A correctness round on 1.9.82's provisioning packs. No new service support, no
change to any trust boundary, and **all 39 catalog entries still report
`native_tested: False`.**

**A malformed service parameter is now always refused with a reason.** The packs
promised that unsupported input is rejected rather than silently applied, but
some malformed input never reached a refusal at all: a list option given a bare
string or a number, an haproxy backend written as `"host:port"` instead of an
object, or an unhashable value in a fixed-choice option raised a Python
`AttributeError` or `TypeError` from inside the builder. `AttributeError` is not
one of the errors the Configure dialog reports, so the most natural way to write
an haproxy backend produced no error message at all — the button appeared to do
nothing. Every option of every pack now refuses garbage as a stated reason, and
a test asserts that property across every pack, every option and eleven shapes of
malformed input.

**The generated scripts are now checked for syntax before they can ship.** A pack
compiles to shell that runs on a competition host, and nothing verified that shell
was parseable. Every pack's `check` and `apply` output is now parsed by `sh` and
`bash`, and the embedded Python preflight validator is compiled, on every test
run. All 19 packs pass today; the point is that a future edit cannot quietly break
one. This does not run the scripts, and it is not evidence that a pack configures
its product correctly.

**Closing the desktop no longer needs Tk to be installed.** 1.9.82's Tcl cleanup
imported `tkinter` unconditionally while shutting down, so on a host without
`python3-tk` two tests failed and a window built without Tk could not close. The
cleanup now looks the module up instead: if Tk was never imported, no Tk-owned
object can exist to release. The full suite is green on a host with no Tk at all.

## Release notes: 1.9.82

This is a corrective build of the uploaded 1.9.81, not universal native service acceptance.
The original artifact is preserved separately. No repository or remote host was changed.
The portable `.pyz` still requires Python 3.11+ and its dependencies. This release does
not contain a newly built self-contained Python/offline bundle or a native executable.

Fixed security option validation, active Apache site generation and path quoting,
nginx catalog dispatch, Gunicorn unit identity, BIND static-zone generation and
hash-bound parent includes, PostgreSQL SSL-only certificate rules and explicit
cluster prerequisites, Redis ACL binding and preflight, Postfix main.cf merging,
DHCP host-pool validation, exact per-file update preconditions, existing-service
conflicts/dependencies, GUI parameter export and reviewed inventory merging.
GUI shutdown now releases Tcl/Tk-owned objects on the GUI thread. The inventory
helper's completion-timeout regression synchronizes fixture startup without
changing production time budgets.

The source ships 52 new regression tests. Full-run results and native boundaries
are in the accompanying validation report. All 39 catalog entries retain
`native_tested: False`. Shell/unit passes are not real-product acceptance.

### Configuration changes you must review

* **Redis:** `password_file` is rejected, because it never configured authentication.
  Use an existing root-owned restrictive `acl_file` with its exact `acl_sha256`.
  ACL users must begin with `reset`, define each user once, explicitly configure
  `default`, and require password hashes for enabled users. Unauthenticated/plaintext
  rules are refused. Activate `/etc/redis/sentinel.conf` through the reviewed parent
  snapshot mechanism or an already active include; no database data is initialized.
* **BIND:** `create-owned` needs `zone`, `soa_mname` and explicit `records`; it writes
  a static zone under `/etc/bind`. `adopt-existing` instead requires `zone_file` and
  `zone_sha256` and refuses `records` rather than ignoring them. Dynamic journals
  and populated data directories are not overwritten. An already active include
  or a hash-pinned `activation` snapshot is required.
* **PostgreSQL:** supply an explicit `/etc/postgresql/<17-or-newer>/<cluster>`
  `config_directory`. `cert` requires approved certificate, key, CA paths and
  `allowed_networks`; the generated HBA rules use `hostssl`. Included HBA rules
  precede old rules. Real database/authentication acceptance remains necessary.
* **Postfix:** supply `main_config` as a hash-pinned snapshot of `/etc/postfix/main.cf`.
  Only the generated keys are replaced, with unrelated settings preserved. An
  unsupported `relay_restrictions` override is refused, not ignored.
* **Update/activation:** `previous_sha256` applies to one generated file;
  multi-file packs use `previous_files`. `activation` maps allowed parent paths to
  local `{ "path": "snapshot-file", "sha256": "<digest>" }` references. Snapshots are
  merged without removing unrelated configuration. Use `file_modes` when required
  to preserve restrictive permissions; mode widening is refused.
* **Apache:** the owned regular vhost file is in `sites-enabled`. The requested
  listener must already exist unless the plan explicitly sets `manage_listener`.
  No unrecorded `a2ensite` mutation or symlink is hidden outside the transaction.
* **Gunicorn:** new catalog plans manage `sentinel-gunicorn.service`, matching the
  generated unit. No old unrelated `gunicorn.service` is automatically removed.
* **Platform:** non-apt setup selections are held. Multi-manager package metadata
  does not authorize using Debian unit/config paths on another distribution.
* **GUI:** selection without parameters now explicitly means adopt/start only.
  Use **Configure selected service…** to enter reviewed JSON options, then export
  a fragment or **Merge into inventory copy…**. The original inventory is retained;
  the copied inventory still requires the ordinary profile/runtime plan review and
  approval on Setup. This is not a complete novice setup wizard or an installer.

No trust-boundary, mutation-ownership, rollback, event-profile, unknown-outcome or
runtime-pinning safeguard is intentionally disabled. Never delete the ledger or
turn off guards to make a setup plan pass. Update the approved event profile's
`release.version` and `release.sha256` deliberately for these new bytes; the app
never silently rewrites an approved event profile during an inventory merge.

See `docs/PROVISIONING_FIXES_1.9.82.md` and the accompanying validation evidence.

---

## Earlier operating guidance (retained context)

The following describes the existing runtime/offline-bundle workflow; it does not
mean a new offline bundle is included in this 1.9.82 correction.


Sentinel Blue is a controller, host agent and desktop for authorized Windows and Linux blue-team environments. It collects native observations and can restore approved files and recover declared services under a reviewed event profile.

## Run and record a range session

Use the offline bundle for your operating system. Extract the entire ZIP to a local writable folder, then open **Start-Sentinel-Blue.cmd** on Windows or **Start-Sentinel-Blue.sh** in a graphical Linux session. These bundles include Python, Tcl/Tk, cryptography, Paramiko and SMB libraries. Startup needs no internet connection, cloud account, AI service, pip, or system Python installation.

The standalone `.pyz` remains available for machines where Python 3.11+ and the needed libraries are already installed. The bundles use that exact reviewed script with a local interpreter; profile and runtime checksum checks remain in force.

To check a bundle locally, run its launcher with `offline-check --desktop`. Supply other controller, agent or observer arguments to the same launcher. On Linux, preserve archive execute permissions; if necessary, run `chmod u+x Start-Sentinel-Blue.sh runtime/bin/python*` after extracting.

```console
python sentinel-blue.pyz --version
python sentinel-blue.pyz desktop
```

Prepare the event inventory, approved profile, runtime, credentials and controller connection in the desktop. On **Session**, press **Start**. Recording is already enabled at runtime startup; Start reuses an active recording or starts the next session. A reviewed setup plan uses the existing approval flow. An unconfigured window does not deploy missing systems or grant new repair authority.

Minimize the window during the session. At the end, press **Stop & save**. Copy the single `Sentinel-Blue-session-<id>.zip` shown in the window, under `Sentinel-Blue-recordings` beside the script, to your laptop and upload it for later analysis. Defense continues after recording is stopped. The script itself stays unchanged, preserving its approved checksum.

Background ZIP snapshots use a shared schedule, normally at least one minute apart and up to 15 minutes apart as export work grows. Stop & save forces finalization.

Starting a later session verifies and retains the previous ZIP before reclaiming its journal space. Keep the exported session files you need; accumulated ZIPs still consume disk space.

Recording stays local and uses no outside AI service. It preserves structured observations, setup and action outcomes, failures, service probes and process continuity. Passwords, vault contents, raw command output and unstructured log text are excluded. Data remains sampled and bounded; omissions, known losses and source gaps are reported. See [range recording](docs/RANGE_RECORDING_1.9.69.md) for coverage, privacy, capacity and recovery.

```console
python sentinel-blue.pyz recording-inspect --bundle Sentinel-Blue-session-EXAMPLE.zip
python sentinel-blue.pyz recording-export --directory LOCAL_RECORDING_DIRECTORY --stop
```

These commands inspect or recover evidence without executing it or importing it as action or training authority. Active journals belong on a local, unsynchronized filesystem.

## Activity evidence and outside service checks

The recorder retains native audit and protected-file activity even when no alert was raised. This can reveal review leads such as a file read or process execution. It cannot identify every red-team action, recover unlogged events, or establish attribution without independent evidence. Windows file access requires the relevant existing audit policy and per-object auditing; Linux read notifications identify paths but not actors.

An outside VM can run only the observer role of the same approved script:

```console
python sentinel-blue.pyz observer --config observer.json
```

A reviewed configuration assigns exact service checks and a separate reporting key. The controller receives signed results over verified TLS and shows local and external health separately. Wrong content, failed checks and stale observations are visible; reports cannot authorize repairs. See [activity and observer setup](docs/ACTIVITY_AND_OBSERVERS_1.9.69.md) and the two observer configuration examples.

## Setup and recovery boundaries

Use the inventory and profile approved for the actual event. The example inventory contains placeholders and an intentionally unusable public URL; it is not a deployable event configuration. Approved runtime and controller trust checks remain required.

Automatic service recovery requires the reviewed service manifests, an approved baseline and verified restore points. Enable only the controller and agent permissions required by that profile. Unknown outcomes, operator holds and exhausted retry budgets still require review. General recovery for every application, identity or network appliance is not implemented.

Setup now keeps durable rollback records for built-in Linux services/nginx and Windows services/firewall/IIS. Failed external verification restores the owned changes when the recorded state still matches; later operator edits or unknown mutation outcomes hold the task for review. Router downstream checks require an explicit source address and interfaces and verify that the actual connection traverses them. See [setup rollback and router verification](docs/SETUP_RECOVERY_1.9.71.md).

The controller's operational history and backups are separate from portable range recordings. See [history storage](docs/HISTORY_STORAGE_1.9.67.md). Recording inspection does not restore a controller database.

## Emergency withdrawal

Open **Withdraw** for the separate **Remove Sentinel** and **Restore & Withdraw** workflows. Both pause and inventory the declared network before acting. Remove preserves service configuration; Restore reverses committed owned changes in dependency order and requires independent service verification before removal. Conflicts and interrupted outcomes remain for human review. No whole-machine snapshot is restored.

A private, immediately flushed, hash-chained action ledger records exact supported mutation pre/post states, validation and inverse information. Unknown historical ownership is never inferred from a Sentinel-looking name. Unsupported reversible-state adapters hold the corresponding mutation, including Windows password/containment and arbitrary installer/runbook changes. Read [emergency withdrawal](docs/EMERGENCY_WITHDRAWAL_1.9.73.md) for instructions, limitations and available native validation.

## Validation and release

This distribution excludes the native adversarial campaign commands. Development acceptance uses owned loopback services, ordinary configuration faults, controlled process interruptions and native Azure VMs. The recording runtime contains no Azure test harness.

The accompanying release status identifies the exact runtime checksum, completed tests and remaining issues. The private continuation includes source and test evidence; only the runtime script is intended for public publication. Earlier private operating documents are incomplete, so historical bundle-building inputs remain a tracked deficiency.

Emergency pause also holds detached 1.9.70 setup jobs in the same desktop workspace, even when the normal work queue is full. Already admitted tasks finish bounded verification or rollback. Resume permits newly reviewed runs; it never restarts stopped jobs. The Services tab reports local setup pause separately from controller acknowledgement. See [pause behavior](docs/EMERGENCY_PAUSE_1.9.70.md).

## Offline deployment boundaries

Offline startup includes the window, local credential vault, recording, packaged background workers, controller, agent and observer entry points. Controller/agent and service-observer connections still need the approved range network. Operating-system management tools and installers for services you choose to provision are separate from Sentinel's runtime. Prepare local packages or approved local repositories before the range when those services are not already installed. No launcher downloads or installs missing software.

Windows x64 and Linux x86_64 bundles are built separately. Linux needs a compatible glibc system and an X11/XWayland session for the GUI. The native release status identifies the specific systems tested. Existing observer profiles still require reviewed service assignments and reporting credentials; an observer configuration creation wizard is a separate UI gap.

## Controller recovery and bounded offline continuity

1.9.74 adds authenticated private recovery capsules, restartable offline restore with durable receipts, bounded explicitly approved offline service restarts, durable controller epochs and reconciliation, independent management Pause, and controller boot registration. See [the recovery and continuity guide](docs/RECOVERY_CONTINUITY_1.9.74.md). This is a release candidate: final native Windows/Linux service-manager, reboot and multi-host acceptance remain open. Issues #34 and #17 are not marked complete.
