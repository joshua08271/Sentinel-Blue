# Sentinel Blue 1.9.82 — corrective provisioning changes


## Release notes: 1.9.82

This is a corrective build of the uploaded 1.9.81, not universal native service acceptance.
The original artifact is preserved separately. No repository or remote host was changed.
The portable `.pyz` still requires Python 3.11+ and its dependencies. This release does
not contain a newly built self-contained Python/offline bundle or a native executable.

Fixed security option validation, active Apache site generation and path quoting,
nginx catalog dispatch, Gunicorn unit identity, BIND static-zone generation and
hash-bound parent includes, PostgreSQL SSL-only certificate rules and explicit
cluster prerequisites, Redis ACL binding and preflight, Postfix main.cf merging,
DHCP host-pool validation, exact per-file update preconditions, existing-service
conflicts/dependencies, GUI parameter export and reviewed inventory merging.
GUI shutdown now releases Tcl/Tk-owned objects on the GUI thread. The inventory
helper's completion-timeout regression synchronizes fixture startup without
changing production time budgets.

The source ships 52 new regression tests. Full-run results and native boundaries
are in the accompanying validation report. All 39 catalog entries retain
`native_tested: False`. Shell/unit passes are not real-product acceptance.

### Configuration changes you must review

* **Redis:** `password_file` is rejected, because it never configured authentication.
  Use an existing root-owned restrictive `acl_file` with its exact `acl_sha256`.
  ACL users must begin with `reset`, define each user once, explicitly configure
  `default`, and require password hashes for enabled users. Unauthenticated/plaintext
  rules are refused. Activate `/etc/redis/sentinel.conf` through the reviewed parent
  snapshot mechanism or an already active include; no database data is initialized.
* **BIND:** `create-owned` needs `zone`, `soa_mname` and explicit `records`; it writes
  a static zone under `/etc/bind`. `adopt-existing` instead requires `zone_file` and
  `zone_sha256` and refuses `records` rather than ignoring them. Dynamic journals
  and populated data directories are not overwritten. An already active include
  or a hash-pinned `activation` snapshot is required.
* **PostgreSQL:** supply an explicit `/etc/postgresql/<17-or-newer>/<cluster>`
  `config_directory`. `cert` requires approved certificate, key, CA paths and
  `allowed_networks`; the generated HBA rules use `hostssl`. Included HBA rules
  precede old rules. Real database/authentication acceptance remains necessary.
* **Postfix:** supply `main_config` as a hash-pinned snapshot of `/etc/postfix/main.cf`.
  Only the generated keys are replaced, with unrelated settings preserved. An
  unsupported `relay_restrictions` override is refused, not ignored.
* **Update/activation:** `previous_sha256` applies to one generated file;
  multi-file packs use `previous_files`. `activation` maps allowed parent paths to
  local `{ "path": "snapshot-file", "sha256": "<digest>" }` references. Snapshots are
  merged without removing unrelated configuration. Use `file_modes` when required
  to preserve restrictive permissions; mode widening is refused.
* **Apache:** the owned regular vhost file is in `sites-enabled`. The requested
  listener must already exist unless the plan explicitly sets `manage_listener`.
  No unrecorded `a2ensite` mutation or symlink is hidden outside the transaction.
* **Gunicorn:** new catalog plans manage `sentinel-gunicorn.service`, matching the
  generated unit. No old unrelated `gunicorn.service` is automatically removed.
* **Platform:** non-apt setup selections are held. Multi-manager package metadata
  does not authorize using Debian unit/config paths on another distribution.
* **GUI:** selection without parameters now explicitly means adopt/start only.
  Use **Configure selected service…** to enter reviewed JSON options, then export
  a fragment or **Merge into inventory copy…**. The original inventory is retained;
  the copied inventory still requires the ordinary profile/runtime plan review and
  approval on Setup. This is not a complete novice setup wizard or an installer.

No trust-boundary, mutation-ownership, rollback, event-profile, unknown-outcome or
runtime-pinning safeguard is intentionally disabled. Never delete the ledger or
turn off guards to make a setup plan pass. Update the approved event profile's
`release.version` and `release.sha256` deliberately for these new bytes; the app
never silently rewrites an approved event profile during an inventory merge.

See `docs/PROVISIONING_FIXES_1.9.82.md` and the accompanying validation evidence.

---

## Earlier operating guidance (retained context)

The following describes the existing runtime/offline-bundle workflow; it does not
mean a new offline bundle is included in this 1.9.82 correction.

