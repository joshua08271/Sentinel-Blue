# Sentinel Blue 1.9.74 — recovery and bounded offline continuity

This release candidate implements the new workflows. **Issues #34 and #17 remain open for native acceptance.** Local regression and controlled local process/TLS evidence do not certify Windows tasks, systemd host reboot, live SSH/WinRM or multi-host controller loss. Keep the 1.9.73 Emergency Remove / Restore & Withdraw guide: those controls and their ownership safeguards remain in effect.

## Controller recovery

A complete private `.sbrecovery` capsule contains an authenticated database bundle, the controller host's exact mutation-ledger chain/key/state blobs, captured profile and configured credential/TLS/model/probe/observer inputs, and references to historical archives and recording locations. Running packaged controllers create these capsules through their existing backup schedule. Backup byte limits, free-space admission and retention still apply. Keep the latest two complete copies; the protected latest backup is never pruned.

Keep the **recovery key and latest protected recovery anchor separately** from the controller's disk and independently of its backup. Loss of both cannot be solved safely by inventing an anchor or key. Remote agent ledgers stay on their hosts; recovery reconciles their reported heads and journals before changing authority resumes.

For an offline backup, stop the controller and supply its private configuration containing a literal `controller_arguments` array. All paths must be absolute. Inline tokens and shell commands are refused. For example, using your own private paths:

```sh
python3 sentinel-blue-1.9.74.pyz recovery-backup \
  --database /private/controller.db --output-directory /private/backups \
  --recovery-key-file /private/recovery.key --recovery-anchor /private/recovery.anchor \
  --event-profile /private/event-profile.json --controller-config /private/controller-config.json
```

The old database-only `recovery-backup`/`recovery-verify` interface remains for compatibility. Such a legacy bundle alone is **not** a complete recovery capsule. A capsule made without controller configuration retains verified state and profile material but cannot reconstruct omitted launch/TLS/enrollment inputs.

Use the desktop **Recovery** tab to select the private controller configuration and capsule, review them, then restore. For database/ledger loss before the desktop has created a new local ledger, the offline CLI is the supported entry point:

```sh
python3 sentinel-blue-1.9.74.pyz recovery-restore \
  --bundle /private/backups/recovery-EXACT-ID.sbrecovery --database /private/controller.db \
  --recovery-key-file /private/recovery.key --recovery-anchor /private/recovery.anchor \
  --event-profile /private/event-profile.json --expected-package-sha256 EXACT_RELEASE_SHA256 \
  --receipt-directory /private/restore-receipt
```

Use `--ledger-directory` only when that is the actual controller-host ledger location. Repeat the **same arguments and receipt directory** after interruption. Preparation attempts are retained in separate candidate folders; after three abandoned preparations use a fresh receipt directory and retain the old evidence. Receipt and ledger staging must be on filesystems supporting the required atomic renames. No VM image is restored.

Restore accepts only the exact latest backup pinned by the independent anchor, with matching controller identity, release and profile. It preserves corrupt database evidence and orphan SQLite sidecars. A different valid database, a valid database with unreviewed WAL state, a mismatched ledger, missing authority material or an unsafe path is held. It never copies an old database over a different valid current database or guesses which team edits should be discarded.

A valid current ledger may extend the backed-up chain; it is retained intact. A wholly missing ledger may be recovered from the authenticated capsule. An existing independently initialized ledger is a different identity and is held for human review, including on replacement machines. Do not erase that newer ledger to bypass this guard. Whole-machine ownership migration and merging independently initialized controller-host ledgers are not automated.

Restore advances recovery generation and backup sequence through a pending/committed protected-anchor transition. It preserves the existing trust, approvals, baselines, limits, history receipts and action records. **Every queued/dispatched/unknown-at-backup action remains outcome-unknown**, because it might have executed after the backup. Host changes remain paused. Fresh complete agent reconciliation is required, and an operator must resolve unknown outcomes and explicitly Resume. A partial Withdraw latch cannot be cleared by recovery or ordinary Resume.

Captured launch inputs are placed in the receipt's private staging tree; existing input files are not overwritten. When the capsule includes launch arguments and the recovery-key path is supplied, `controller-config.json` is generated with recovered input paths. Start that reviewed configuration from the existing desktop Connection controls. The key and anchor remain external. History and recording locations are references, not fabricated evidence. Missing authenticated historical archives are reported while current operation can continue; altered archives still fail verification. Unknown online results absent from the backup may need operator reconciliation and do not get automatically declared successful.

Verify the signed transaction/rejection receipt chains:

```sh
python3 sentinel-blue-1.9.74.pyz recovery-receipt \
  --receipt-directory /private/restore-receipt --recovery-key-file /private/recovery.key
```

Receipts state what was copied, held, missing, rejected and preserved. Back up these private receipts and the independent anchor after recovery. A new successful backup is required before another restore of this generation; the prior capsule cannot be replayed.

## Bounded offline service recovery

Collection, local recording, the telemetry spool, health checks and action journals continue when the controller is unreachable. Mutation-authority errors hold repairs without suppressing telemetry upload.

In **Recovery**, explicitly authorize an enrolled agent and exact service names, duration, retry count and cooldown. Approval requires active governance, a fully reconciled network, an exact approved baseline and remaining service-recovery budget. Supported policy is deliberately narrow:

- Only `restart_service`, for 1–16 named services on the named agent. Configuration repair, installation, credential repair, new baselines and arbitrary shell commands are not authorized offline.
- Authorization identity, profile, controller instance/generation/epoch/process holder, creation time, expiry, exact baseline, manifest dependency/file/account/probe contract and rollback rule are signed and saved.
- Validity is 60–3,600 seconds; at most three attempts per authorization and at least 300 seconds between attempts. Stricter approved service limits still apply. Existing local and controller recovery budgets remain enforced.
- The agent waits for the 30-second online lease to expire, then requires fresh consecutive observations, native preflight, exact approved configuration, dependency health and stable post-repair service probes. Local service-recovery permission and mutation tracking must also be enabled.
- Unknown, ambiguous, unsupported, expired, clock-discontinuous, exhausted, interrupted or unresolved conditions are held. Service rollback uses the existing exact native service-state transaction and ownership guards; conflicts are retained for review.

Every attempted offline action first enters a durable hash-chained intent journal, uses the 1.9.73 mutation ledger for its native writes, and saves a result/evidence record. An interrupted intent is never automatically executed again. The complete bounded offline journal uploads on reconnect, including after recovery rewinds the controller's acknowledged journal position. Completed receipts enter ordinary controller action history and recovery-budget accounting. Superseded queued service actions are cancelled. New changing authority is held until all enabled enrolled agents have reconciled; relay-only observations are excluded.

An agent durably pins its highest controller identity/generation/epoch/holder in signed state and its mutation ledger. Lower epochs, another controller identity or competing holders at the same epoch are refused. Copying/restoring all local evidence, credentials and independent anchors remains outside the root/SYSTEM trust boundary. This is a local scope and fencing protocol, not a claim of Byzantine consensus or trust after root compromise.

The offline evidence journal stops admitting new offline mutations at its finite capacity (512 events). It does not silently discard unacknowledged or historical action evidence. Recovery after an unknown outcome or full journal requires review; there is no automatic journal erasure/reset workflow.

## Pause when the normal controller path is down

Ordinary controller Pause revokes stored offline policies and reaches connected agents on their authenticated path. **A partitioned agent cannot receive an unreachable controller's new Pause.** Use Recovery → **Pause across inventory through SSH / WinRM**, with the approved inventory/profile from Setup. This uses independent management connections and produces per-host pause/drain receipts. Unreachable hosts are explicitly incomplete; do not treat a partial result as a network-wide success.

For a directly managed host:

```sh
python3 sentinel-blue-1.9.74.pyz continuity-pause --reason 'Operator emergency Pause'
python3 sentinel-blue-1.9.74.pyz continuity-resume --reason 'Reviewed independent Pause'
```

This independent latch is distinct from Withdraw. It survives restart, permits only the existing explicitly authorized emergency rollback actions on a reconciled online connection, and cannot clear a Withdraw latch. Restore & Withdraw still uses the existing independent network inventory, exact ownership, dependency ordering, conflict preservation and external verification. No whole-machine rollback is introduced.

## Controller boot persistence

Recovery → **Enable controller at boot**, or:

```sh
python3 sentinel-blue-1.9.74.pyz controller-boot-install \
  --config /private/controller-config.json --runtime /private/sentinel-blue-1.9.74.pyz
```

Run administratively on a real systemd host or supported Windows host. Installation creates a new `sentinel-blue-controller.service` or `SentinelBlueController` startup task and a private exact boot binding; it does not overwrite an existing registration. The registration is recorded as a Sentinel-owned installation mutation. It is enabled for the next boot; the desktop's existing Start controller action can start the current session. Native supervision restarts failures within bounds, and the existing supervisor retains its crash/stall budget. Every boot verifies the same approved runtime/profile/configured input bytes and respects Withdraw. Changed inputs require reviewed rebinding; no automatic credential/profile migration is inferred.

Native service/task behavior, reboot behavior, and ownership transitions after OS-driven startup still require final Linux/Windows acceptance. Natural service-state changes can cause withdrawal ownership conflicts; review them instead of suppressing revision guards. No native boot registration was installed in the development container.

## Validation and continuation

See the accompanying status and machine-readable receipts for exact final counts and hashes. `tools/controlled_continuity_acceptance.py` reruns focused tests against the actual `.pyz`; `tools/packaged_withdrawal_check.py` covers the retained emergency fixture. Full native acceptance remains: Linux/systemd and Windows task reboot, actual service repair during network loss, SSH/WinRM emergency overrides, replacement-controller trust reconciliation, an independently observed multi-host loss/recovery sequence, and final cleanup receipts. Independent external red-team and competition service-availability evidence were not obtained.

Forecast, not measurement: bounded recovery should reduce the duration of an approved stopped-service outage while a controller is absent, and reduce manual reconstruction after controller loss. It adds no autonomous coverage for arbitrary application/network/credential faults. There is no defensible measured NCAE/CCDC uptime percentage or maturity score from these local tests.
