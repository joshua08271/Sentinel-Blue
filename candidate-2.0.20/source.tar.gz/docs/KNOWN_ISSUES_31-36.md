> Historical 1.9.101 review. Corrections are documented in LINUX_HOTFIX_2.0.1.md.

# Sentinel Blue 1.9.101 — Sixth Linux review

## Result and boundaries

**Six additional issues were reproduced: LINUX-31 through LINUX-36. Two have high engineering priority; four are medium-priority monitoring/repair issues. No product code was changed and no new release was created.** Priorities are engineering triage, not CVSS ratings or proof of exploitation.

Each finding reproduced with the unchanged source and the exact packaged application under the distribution's bundled Python 3.13.15. Eight desired-correctness assertions fail in each of those two runs. Passing pre-existing regressions do not cover or negate these additional cases.

The complete offline bundle is retained and passes its own 5,271-file verification. The worker isolation finding concerns a subprocess entry point, not missing Python/dependency files or an internet requirement.

## Identity and preservation

Runtime SHA-256: `f533a0178354c4267f2e2f4a7160858d3f7bbf2a0459f381ea15a196dabe1a55`. Full offline ZIP SHA-256: `bfdcbbc3b21dfbc5a1430d737911054c59be6b30483161fccf8c4230f31f2991`.

All **119 packaged source members** match the corresponding source bytes. The standalone application and the one inside the full offline ZIP are identical. All **115** source Python modules parse under the Python 3.11 grammar. All **340 original source-archive files** remain byte-identical and match the original archive. Parsing establishes syntax, not complete correctness. The source/runtime review did not edit dependency payloads, application files, native acceptance flags, user profiles or ledgers on real targets.

## Test results actually obtained

| Group | Run | Passed | Skipped | Failures / errors |
|---|---:|---:|---:|---:|
| Full headless source suite, system Python 3.13.5 | 1,816 | 1,788 | 28 | 0 / 0 |
| Retained exact-package regressions, bundled Python 3.13.15 | 427 | 427 | 0 | 0 / 0 |
| New desired-correctness assertions, source under bundled Python | 8 | 0 | 0 | **8 / 0** |
| Same new assertions, exact zipapp under bundled Python | 8 | 0 | 0 | **8 / 0** |
| Additional new-source run under system Python 3.13.5 | 8 | 1 | 0 | **7 / 0** |

The final three rows are **unfixed-code failure demonstrations**, not passes for corrected code. There are eight assertions for six findings because worker isolation and interface coverage each have two subcases. Test groups overlap. The 427-test packaged group contains all **307 retained issue-1–25**, **80 issue-26–30**, and **40 offline-release** regressions. Imported Sentinel module origins are recorded and remain inside the selected source/package; no neighboring source module leaked into the exact-runtime campaign.

The full suite's 28 skips require a graphical display, native Windows or native systemd. Its measured duration was 235.558 seconds; the retained group took 48.431 seconds. These are development-test timings, not target performance or availability estimates. Some inherited tests emit warnings and print modeled failure outcomes; the unittest summary has zero actual failures/errors.

**Interpreter distinction:** the ambient startup-hook subcase of LINUX-32 reproduces with the supplied bundled Python for both source and zipapp. The additional system-interpreter run did not execute that marker, although it still reproduced invalid-PYTHONHOME worker failure. Both logs are retained. The report does not assert that every Python build/environment behaves identically.

## Findings at a glance

| ID | Priority | Finding |
|---|---|---|
| LINUX-31 | High | Read-only setup refusal leaves unresolved ownership and blocks a corrected plan |
| LINUX-32 | High | Native scoring workers drop isolated-Python flags and honor ambient Python startup settings |
| LINUX-33 | Medium | Case-folded service identities hide changes to distinct Linux units |
| LINUX-34 | Medium | Linux integrity telemetry does not capture a permissions-only security change |
| LINUX-35 | Medium | Interface inventory hides provider failures and silently truncates large results |
| LINUX-36 | Medium | An unrelated loopback address is treated as a proven port collision and blocks repair |

## LINUX-31 — Read-only setup refusal leaves unresolved ownership and blocks a corrected plan

**Priority:** High.

**Locations:** `src/sentinel_blue/setup_linux_transaction.py:305–322`; `src/sentinel_blue/setup_linux_transaction.py:537–566`.

**Cause.** The outer `run(apply)` prepares a durable mutation-ledger action before the inner transaction checks the reviewed previous file hash. When that read-only check refuses, there is no transaction snapshot, no resource claim and no inverse-completion receipt. The common exception path nevertheless changes the action to `uncertain`. A later corrected plan for the same service/file is rejected by unresolved ownership.

**Reproduction and controls.** The actual generated Linux service recipe was exercised with a real private configuration file and real mutation ledger; native service controls were inert. The file already contained harmless `TEAM_PREEXISTING` text before apply. Its hash did not match the initial reviewed plan. Apply refused with `Setup file differs from the reviewed before/after hashes`, preserving the file, creating no native transaction directory or resource claims, and executing no service mutations. The ledger nevertheless retained `uncertain`. A newly generated plan using the correct current hash and a fresh transaction token was then blocked by `An earlier action has unresolved ownership`.

An independent fresh fixture accepted that same corrected plan and wrote `AFTER`. That separate fixture is a control demonstrating plan validity, not a recommendation to switch ledgers or erase ownership evidence.

**Impact and limits.** An ordinary precondition mismatch can prevent subsequent authorized configuration even though no service/configuration mutation began. The refusal writes audit/ledger records; “read-only” here describes the protected service/configuration operation, not absence of all filesystem activity. This did not cause a demonstrated daemon outage or loss of configuration.

**Suggested correction.** Validate read-only admission conditions before preparing the mutation, while still rechecking them under the appropriate locks before the first write, or record an authenticated, provable no-mutation refusal outcome. Keep prepare-before-mutate ordering. Do not classify an ambiguous partially executed action as a harmless refusal merely because current bytes look familiar.

**Execution scope.** Real generated shell/transaction/ledger and private files; inert service controls.

### Exact-runtime measured result

```json
{
  "first": "ValueError:Setup file differs from the reviewed before/after hashes",
  "original_configuration_preserved": true,
  "native_transaction_exists": false,
  "claims_count": 0,
  "service_mutation_calls": 0,
  "ledger_statuses": [
    "uncertain"
  ],
  "corrected_plan_retry": "ValueError:An earlier action has unresolved ownership",
  "corrected_plan_fresh_ledger": "success",
  "fresh_control_content": "AFTER\n"
}
```

### Relevant unmodified source excerpts

`src/sentinel_blue/setup_linux_transaction.py:305–322`

```text
  305:         if phase == 'apply':
  306:             if base.exists() or base.is_symlink():
  307:                 raise ValueError('A setup transaction cannot be replayed')
  308:             keys = resources(spec)
  309:             if any((ROOT / ('resource-' + key + '.json')).exists() or (ROOT / ('resource-' + key + '.json')).is_symlink() for key in keys):
  310:                 raise ValueError('An earlier setup transaction still owns this service or file')
  311:             admitted = ledger_capture(spec)
  312:             if expected is not None and admitted != expected:
  313:                 raise ValueError('Setup changed after authenticated admission')
  314:             before = admitted['native']
  315:             for row in spec['files']:
  316:                 original = before['files'][row['path']]
  317:                 if original is None:
  318:                     if row['previous_sha256'] != 'absent':
  319:                         raise ValueError('Reviewed existing setup file is absent')
  320:                 elif original['sha256'] not in {row['sha256'], row['previous_sha256']}:
  321:                     raise ValueError('Setup file differs from the reviewed before/after hashes')
  322:             secure_directory(base, create=True)
```

`src/sentinel_blue/setup_linux_transaction.py:537–566`

```text
  537:     with ledger.lock(), transaction_lock(create=phase != 'admit'):
  538:         if phase in {'admit', 'apply'}:
  539:             if ledger.paused():
  540:                 raise ValueError('Emergency withdrawal has paused setup mutations')
  541:             _unfinished_confirmation(ledger, objects)
  542:         if phase == 'apply':
  543:             before = ledger_capture(spec)
  544:             target = {'spec': spec, 'token': token, 'objects': objects}
  545:             try:
  546:                 ledger.prepare('setup-linux-v1', target, before, action_id=action_id, context=spec.get('ledger_context', {}))
  547:             except RuntimeError as exc:
  548:                 raise ValueError(str(exc)) from exc
  549:             try:
  550:                 _run(phase, spec, token, apply, lock_held=True, expected=before,
  551:                      on_restored=lambda state, current: _record_restoration(ledger, spec, token, state, current))
  552:                 state = read(ROOT / token / 'state.json')
  553:                 after = ledger_capture(spec)
  554:                 if state['after'] != after['native'] or state['after_revisions'] != revisions(after):
  555:                     raise ValueError('Setup changed before durable applied evidence')
  556:                 target['native_record_hash'] = ledger.store(state)
  557:                 ledger.append('applied', action_id=action_id, target=target,
  558:                               after_hash=ledger.store(after), validation={'success': True, 'external': False})
  559:             except BaseException as exc:
  560:                 # A durable applied/committed decision is never downgraded merely
  561:                 # because its acknowledgement failed. Missing proof still holds.
  562:                 if not _reconcile_restoration(ledger, spec, token):
  563:                     row = _action(ledger, spec, token)
  564:                     if row['status'] == 'prepared':
  565:                         ledger.append('uncertain', action_id=action_id, reason=type(exc).__name__)
  566:                 raise
```


## LINUX-32 — Native scoring workers drop isolated-Python flags and honor ambient Python startup settings

**Priority:** High.

**Locations:** `src/sentinel_blue/native_probes.py:376–403`; `src/sentinel_blue/runtime_environment.py:1–10`.

**Cause.** The offline launcher enters Python with `-I -B`, and the project already has a `python_command()` helper that preserves those flags. `run_native_probe()` instead launches its scoring worker as `[sys.executable, "-c", ...]`. It supplies intended import paths from inside the worker program, but Python environment handling and `sitecustomize` processing occur before that program begins. The inherited `PYTHONHOME`/`PYTHONPATH` environment is therefore no longer ignored by the worker.

**Reproduction and controls.** A real isolated parent under the bundled Python 3.13.15 invoked the actual native-probe supervisor, worker and command-capture paths. A private, inert shell executable named `ping` wrote only a local marker and returned success; it sent no traffic. The clean-environment control passed.

With an invalid `PYTHONHOME`, the isolated parent remained healthy but the worker failed before the native client ran. Sentinel reported `native scoring client failed; check credentials, protocol, and dependencies`. With `PYTHONPATH` pointing to a private directory containing a benign `sitecustomize.py`, that startup hook executed in the worker and wrote its private marker. The same code was not imported in the isolated parent.

Both manifestations reproduced with unmodified source and the exact zipapp using bundled Python. An additional source run under the environment's Python 3.13.5 reproduced invalid-PYTHONHOME failure but did not execute the ambient startup marker. This interpreter/environment distinction is retained in the evidence; the supplied bundled interpreter is the demonstrated affected distribution.

**Impact and limits.** The complete offline bundle is present, but its scoring subprocess can still depend on ambient Python configuration and execute ambient startup code contrary to the parent isolation boundary. This is local environment-influenced execution, not a demonstrated remote exploit or privilege escalation. The separate process-group cleanup fix is not the failure being reported.

**Suggested correction.** Use the existing isolated interpreter command helper for the scoring worker, with explicit intended module paths, and sanitize incompatible Python environment variables as defense in depth. Test native probe startup—not just the GUI/launcher—with invalid Python environment variables and a harmless ambient startup hook. Inserting `sys.path` after interpreter startup is too late to preserve isolation.

**Execution scope.** Actual isolated parent, worker and inert native subprocess; benign private startup-hook marker; no network traffic.

### Exact-runtime measured result

```json
{
  "cases": [
    {
      "parent_isolated": 1,
      "parent_executable": "/mnt/data/review_19101/offline/Sentinel-Blue-1.9.101-linux-x86_64/runtime/bin/python3",
      "intended_python_command": [
        "/mnt/data/review_19101/offline/Sentinel-Blue-1.9.101-linux-x86_64/runtime/bin/python3",
        "-I",
        "-B"
      ],
      "probe": "ICMP echo reply received",
      "success": true,
      "variant": "clean",
      "ambient_marker": false,
      "native_client_ran": true
    },
    {
      "parent_isolated": 1,
      "parent_executable": "/mnt/data/review_19101/offline/Sentinel-Blue-1.9.101-linux-x86_64/runtime/bin/python3",
      "intended_python_command": [
        "/mnt/data/review_19101/offline/Sentinel-Blue-1.9.101-linux-x86_64/runtime/bin/python3",
        "-I",
        "-B"
      ],
      "probe": "RuntimeError:native scoring client failed; check credentials, protocol, and dependencies",
      "success": false,
      "variant": "invalid_home",
      "ambient_marker": false,
      "native_client_ran": false
    },
    {
      "parent_isolated": 1,
      "parent_executable": "/mnt/data/review_19101/offline/Sentinel-Blue-1.9.101-linux-x86_64/runtime/bin/python3",
      "intended_python_command": [
        "/mnt/data/review_19101/offline/Sentinel-Blue-1.9.101-linux-x86_64/runtime/bin/python3",
        "-I",
        "-B"
      ],
      "probe": "ICMP echo reply received",
      "success": true,
      "variant": "ambient_site",
      "ambient_marker": true,
      "native_client_ran": true
    }
  ],
  "scope": "Actual isolated parent, scoring worker and inert native client; no network traffic."
}
```

### Relevant unmodified source excerpts

`src/sentinel_blue/native_probes.py:376–403`

```text
  376: def run_native_probe(kind, spec, address, timeout):
  377:     if type(timeout) not in {int, float} or not math.isfinite(timeout) or timeout <= 0:
  378:         raise TimeoutError('scoring transaction has no remaining deadline')
  379:     deadline = time.monotonic() + timeout
  380:     # A child provides one hard overall deadline even when a library has several
  381:     # internal request timers. It also prevents logging/cache state crossing probes.
  382:     package_root = str(Path(__file__).parent.parent)
  383:     # Preserve explicitly configured dependency paths in embedded Python too;
  384:     # its isolated mode intentionally ignores the PYTHONPATH environment.
  385:     module_paths = json.dumps([package_root, *[str(Path(p).absolute()) for p in sys.path if p]])
  386:     code = "import json,sys; sys.path[:0]=json.loads(sys.argv[1]); from sentinel_blue.native_probes import _worker; _worker()"
  387:     payload = json.dumps({"kind": kind, "spec": spec, "address": address, "timeout": timeout, "deadline": deadline}).encode()
  388:     if len(payload) > 65536:
  389:         raise ValueError("native scoring specification exceeds 64 KiB")
  390:     # Catch an absent client here as well: the child cannot start if the
  391:     # interpreter itself is unavailable, and the readiness answer is the same.
  392:     absent = missing_clients(kind)
  393:     if absent:
  394:         raise ProbeUnavailable("scoring client is not installed: " + ", ".join(absent))
  395:     result = _command([sys.executable, "-c", code, module_paths], timeout, incoming=payload,
  396:                       deadline=deadline, supervise_tree=True)
  397:     record = json.loads(result)
  398:     if record.get("healthy") is not True:
  399:         detail = record.get("detail", "scoring transaction failed")
  400:         if record.get("unavailable") is True:
  401:             raise ProbeUnavailable(detail)
  402:         raise RuntimeError(detail)
  403:     return record["detail"]
```

`src/sentinel_blue/runtime_environment.py:1–10`

```text
    1: """Keep portable runtimes independent of system Python and user packages."""
    2: from __future__ import annotations
    3: 
    4: import sys
    5: 
    6: 
    7: def python_command():
    8:     """Children retain the isolation selected by the offline launcher."""
    9:     return [sys.executable, *(['-I', '-B'] if sys.flags.isolated else [])]
   10: 
```


## LINUX-33 — Case-folded service identities hide changes to distinct Linux units

**Priority:** Medium.

**Locations:** `src/sentinel_blue/analyzers.py:17–18`; `src/sentinel_blue/analyzers.py:84–100`; `src/sentinel_blue/analyzers.py:118–137`.

**Cause.** The shared `_index()` case-folds each service name into a dictionary key. `analyze_services()` uses it for both baseline and current Linux service rows. Distinct `Worker.service` and `worker.service` rows collide, and the later row silently replaces the earlier one. The prior platform-aware pathname correction does not cover this service-name index.

**Reproduction and controls.** The actual full detector consumed a Linux baseline containing both names, each running with enabled startup and zero restarts. In the current observation only `Worker.service` changed to masked startup, seven restarts and an exit-code failure result; the lowercase service remained unchanged and appeared last. No alert was generated. Changing only the unaffected service's name to `other.service` produced both `service_startup_disabled` and `service_restart_loop`. Reversing the original two rows also produced those alerts.

**Impact and limits.** The specific startup-configuration and repeated-restart alerts can disappear based solely on row order when Linux units differ only by capitalization. The fixture keeps the service state running to isolate those branches. It does not claim the separate stopped-service detector or every other alert mechanism was bypassed. Native units were not installed.

**Suggested correction.** Use platform-appropriate service identity comparisons, preserving Linux unit-name case and retaining reviewed Windows semantics. Reject or explicitly handle genuinely duplicate records rather than silently merging separate Linux identities. Test both row orders and simultaneous case-distinct baseline entries.

**Execution scope.** Synthetic provider observations through the actual full detector, with controls; no native unit changes.

### Exact-runtime measured result

```json
{
  "baseline_services": [
    {
      "name": "Worker.service",
      "state": "running",
      "start_mode": "enabled",
      "restart_count": 0,
      "result": "success"
    },
    {
      "name": "worker.service",
      "state": "running",
      "start_mode": "enabled",
      "restart_count": 0,
      "result": "success"
    }
  ],
  "current_services": [
    {
      "name": "Worker.service",
      "state": "running",
      "start_mode": "masked",
      "restart_count": 7,
      "result": "exit-code"
    },
    {
      "name": "worker.service",
      "state": "running",
      "start_mode": "enabled",
      "restart_count": 0,
      "result": "success"
    }
  ],
  "alert_kinds": [],
  "different_name_control_kinds": [
    "service_startup_disabled",
    "service_restart_loop"
  ],
  "same_rows_reverse_order_kinds": [
    "service_startup_disabled",
    "service_restart_loop"
  ]
}
```

### Relevant unmodified source excerpts

`src/sentinel_blue/analyzers.py:17–18`

```text
   17: def _index(items: list[dict[str, Any]], key: str = "name") -> dict[str, dict[str, Any]]:
   18:     return {str(item.get(key, "")).casefold(): item for item in items if item.get(key)}
```

`src/sentinel_blue/analyzers.py:84–100`

```text
   84: def analyze_services(
   85:     telemetry: dict[str, Any], baseline: dict[str, Any] | None, model: RiskModel
   86: ) -> list[AlertCandidate]:
   87:     if not baseline:
   88:         return []
   89:     previous = _index(baseline.get("services", []))
   90:     current = _index(telemetry.get("services", []))
   91:     alerts: list[AlertCandidate] = []
   92:     automatic_modes = {"auto", "automatic", "enabled", "delayed-auto"}
   93:     disabled_modes = {"disabled", "masked"}
   94:     for name, old in previous.items():
   95:         new = current.get(name)
   96:         if not new:
   97:             continue
   98:         old_mode = str(old.get("start_mode", "unknown")).casefold()
   99:         new_mode = str(new.get("start_mode", "unknown")).casefold()
  100:         if old_mode in automatic_modes and new_mode in disabled_modes:
```

`src/sentinel_blue/analyzers.py:118–137`

```text
  118:         previous_restarts = old.get("restart_count")
  119:         current_restarts = new.get("restart_count")
  120:         known_current = type(current_restarts) is int and current_restarts >= 0
  121:         known_previous = type(previous_restarts) is int and previous_restarts >= 0
  122:         restart_delta = max(0, current_restarts - previous_restarts) if known_current and known_previous else None
  123:         failed_result = str(new.get("result", "")).casefold() not in {
  124:             "",
  125:             "success",
  126:             "done",
  127:             "unknown",
  128:         }
  129:         if (restart_delta is not None and restart_delta >= 3) or (failed_result and known_current and current_restarts >= 3):
  130:             features = {"critical_service_stopped": 1.0}
  131:             alerts.append(
  132:                 ModelBoundAlertCandidate(
  133:                     kind="service_restart_loop",
  134:                     title="Service is repeatedly failing or restarting",
  135:                     summary=(
  136:                         f"{new.get('name', name)} recorded {current_restarts} recent restarts "
  137:                         f"with result {new.get('result', 'unknown')}."
```


## LINUX-34 — Linux integrity telemetry does not capture a permissions-only security change

**Priority:** Medium.

**Locations:** `src/sentinel_blue/collectors.py:1538–1548`; `src/sentinel_blue/collectors.py:1573–1584`; `src/sentinel_blue/detection.py:250–261`.

**Cause.** The POSIX integrity reader checks metadata/revision stability during a single read, but returns only pathname, content digest, byte count and modification time. The optional `security_descriptor_sha256` remains an empty string. The detector compares content and security digests between observations, so a permissions-only change that preserves bytes and modification time produces identical Linux integrity telemetry.

**Reproduction and controls.** A benign private configuration file was collected through the real Linux integrity reader. It initially had mode 0600; an independent process under UID/GID 65534 could not read it. After changing only its mode to 0644, that same reduced-privilege reader succeeded. Both integrity snapshots remained exactly equal, including empty security digests, and collection returned no errors. The full detector generated no change alert. Altering the contents in a separate control generated `critical_file_changed` as expected.

**Impact and limits.** The integrity channel misses a demonstrated access-permission expansion even though the operating system's effective read access changed. No real credential or service configuration was exposed: the file contained explicitly nonsecret fixture text. This finding does not establish that an independent native audit feed or all Sentinel monitoring channels would also miss the event.

**Suggested correction.** Emit a canonical POSIX security-metadata fingerprint covering relevant mode, owner/group and ACL/extended-attribute state, with deliberate handling of unsupported/unreadable metadata and baseline migration. Keep volatile access times out of that semantic security digest. The existing rollback metadata guards are separate and do not supply this missing telemetry.

**Execution scope.** Actual private chmod, Linux integrity reads and UID-reduced read check; actual detector; no secrets or host service changes.

### Exact-runtime measured result

```json
{
  "mode_before": "0o600",
  "mode_after": "0o644",
  "equal_integrity_telemetry": true,
  "before": [
    {
      "path": "/var/lib/sb-permission-review-ushobx71/example.conf",
      "sha256": "7c20d5bf11eb46b48eb8b55d5f86ce364c6ba5f1eacc07b2dce3aa91aec6715a",
      "size": 29,
      "modified_at": 1790018736.2655907,
      "readable": true,
      "security_descriptor_sha256": ""
    }
  ],
  "after": [
    {
      "path": "/var/lib/sb-permission-review-ushobx71/example.conf",
      "sha256": "7c20d5bf11eb46b48eb8b55d5f86ce364c6ba5f1eacc07b2dce3aa91aec6715a",
      "size": 29,
      "modified_at": 1790018736.2655907,
      "readable": true,
      "security_descriptor_sha256": ""
    }
  ],
  "collector_errors": [],
  "unrelated_uid": 65534,
  "read_before_exit": 1,
  "read_after_exit": 0,
  "alert_kinds": [],
  "content_change_control_kinds": [
    "critical_file_changed"
  ]
}
```

### Relevant unmodified source excerpts

`src/sentinel_blue/collectors.py:1538–1548`

```text
 1538: def _posix_integrity_item(path: Path, budget: _IntegrityBudget) -> IntegrityItem | None:
 1539:     """Hash a bounded regular-file snapshot; reject concurrent changes.
 1540: 
 1541:     Deadlines are checked between operations. A blocked filesystem call still
 1542:     depends on the OS. Existing monitored symlink paths remain supported, with
 1543:     the final pathname required to identify the same snapshot as the open file.
 1544:     """
 1545:     budget.check()
 1546:     flags = os.O_RDONLY | getattr(os, "O_NONBLOCK", 0) | getattr(os, "O_CLOEXEC", 0)
 1547:     try:
 1548:         descriptor = os.open(path, flags)
```

`src/sentinel_blue/collectors.py:1573–1584`

```text
 1573:         if received != before.st_size:
 1574:             raise ValueError("integrity file changed while being read")
 1575:         after = os.fstat(descriptor)
 1576:         named = path.stat()
 1577:         budget.check()
 1578:         identity = _file_snapshot_identity(before)
 1579:         if identity != _file_snapshot_identity(after) or identity != _file_snapshot_identity(named):
 1580:             raise ValueError("integrity file changed while being read")
 1581:         return IntegrityItem(path=str(path), sha256=digest.hexdigest(),
 1582:                              size=received, modified_at=float(after.st_mtime))
 1583:     finally:
 1584:         os.close(descriptor)
```

`src/sentinel_blue/detection.py:250–261`

```text
  250:         for path, previous in baseline_integrity.items():
  251:             current = current_integrity.get(path)
  252:             content_changed = current is None or current.get("sha256") != previous.get("sha256")
  253:             baseline_security_digest = previous.get("security_descriptor_sha256", "")
  254:             observed_security_digest = (
  255:                 current.get("security_descriptor_sha256", "") if current else None
  256:             )
  257:             security_metadata_changed = current is None or (
  258:                 observed_security_digest != baseline_security_digest
  259:             )
  260:             if not content_changed and not security_metadata_changed:
  261:                 continue
```


## LINUX-35 — Interface inventory hides provider failures and silently truncates large results

**Priority:** Medium.

**Locations:** `src/sentinel_blue/collectors.py:514–545`; `src/sentinel_blue/collectors.py:567–579`.

**Cause.** The Linux interface collector passes a temporary empty diagnostic list to its `ip -j address show` query. On failure it discards that provider error and falls back to interface names plus hostname resolution. That fallback does not recover the interface-to-address mapping: resolved addresses are placed under a synthetic `host` entry. A separate slice retains only the first 512 successful interface rows without an overflow diagnostic.

**Reproduction and controls.** With a modeled nonzero provider exit, and separately a modeled TimeoutExpired, the real collector returned `eth0` with no addresses plus a synthetic `host` entry containing 127.0.1.1. It returned no collection errors in either case. A second provider fixture supplied 513 successful interface records; the collector returned 512, omitted the final interface and again returned no errors. The provider commands and name-resolution inputs were modeled; this was not a native 513-interface deployment.

**Impact and limits.** Partial or truncated address ownership/topology observations are not accompanied by the diagnostics that would tell downstream consumers coverage is missing. No GUI completeness flag, automated network mutation or containment decision was exercised. The nearby 64-address-per-interface slice is also unreported by inspection, but it was not an additional executable reproduction in this pass.

**Suggested correction.** Carry the primary query's diagnostics into the returned observation, identify fallback data as partial mapping, and report every per-interface/per-address overflow explicitly while retaining useful partial evidence. Hostname resolution should not be represented as complete native interface-address discovery.

**Execution scope.** Modeled command/name-resolution inputs through actual collectors and parsers; separate failure, timeout and 513-row cases.

### Exact-runtime measured result

```json
{
  "provider_error": {
    "interfaces": [
      {
        "name": "eth0",
        "addresses": []
      },
      {
        "name": "host",
        "addresses": [
          "127.0.1.1"
        ]
      }
    ],
    "collector_errors": []
  },
  "provider_timeout": {
    "interfaces": [
      {
        "name": "eth0",
        "addresses": []
      },
      {
        "name": "host",
        "addresses": [
          "127.0.1.1"
        ]
      }
    ],
    "collector_errors": []
  },
  "overflow": {
    "provider_rows": 513,
    "returned_rows": 512,
    "collector_errors": [],
    "last_provider_interface_returned": false
  }
}
```

### Relevant unmodified source excerpts

`src/sentinel_blue/collectors.py:514–545`

```text
  514: def _fallback_interfaces(errors: list[str]) -> list[Interface]:
  515:     interfaces: dict[str, set[str]] = {}
  516:     try:
  517:         for _, name in socket.if_nameindex():
  518:             interfaces.setdefault(name, set())
  519:     except OSError as exc:
  520:         errors.append(f"interface names unavailable: {exc}")
  521:     try:
  522:         for family, _, _, _, address in socket.getaddrinfo(socket.gethostname(), None):
  523:             if family in {socket.AF_INET, socket.AF_INET6}:
  524:                 interfaces.setdefault("host", set()).add(str(address[0]))
  525:     except OSError as exc:
  526:         errors.append(f"interface addresses unavailable: {exc}")
  527:     return [Interface(name=name, addresses=sorted(addresses)) for name, addresses in sorted(interfaces.items())]
  528: 
  529: 
  530: def _linux_interfaces(errors: list[str]) -> list[Interface]:
  531:     rows = _json_command(["ip", "-j", "address", "show"], [], "interface inventory")
  532:     if not rows:
  533:         return _fallback_interfaces(errors)
  534:     result: list[Interface] = []
  535:     for row in rows[:512]:
  536:         addresses = []
  537:         for item in row.get("addr_info", []):
  538:             if not isinstance(item, dict) or not item.get("local"):
  539:                 continue
  540:             address = str(item["local"])
  541:             if item.get("prefixlen") is not None:
  542:                 address += f"/{item['prefixlen']}"
  543:             addresses.append(address)
  544:         result.append(Interface(name=str(row.get("ifname", "unknown")), addresses=addresses[:64]))
  545:     return result
```

`src/sentinel_blue/collectors.py:567–579`

```text
  567: def _json_command(command: list[str], errors: list[str], label: str) -> list[dict[str, Any]]:
  568:     try:
  569:         result = _run(command, timeout=15)
  570:         if result.returncode != 0 or not result.stdout.strip():
  571:             errors.append(f"{label} unavailable")
  572:             return []
  573:         value = json.loads(result.stdout)
  574:         if isinstance(value, dict):
  575:             return [value]
  576:         return value if isinstance(value, list) else []
  577:     except (OSError, ValueError, subprocess.TimeoutExpired, json.JSONDecodeError) as exc:
  578:         errors.append(f"{label} failed: {exc}")
  579:         return []
```


## LINUX-36 — An unrelated loopback address is treated as a proven port collision and blocks repair

**Priority:** Medium.

**Locations:** `src/sentinel_blue/service_repair.py:205–250`; `src/sentinel_blue/service_repair.py:253–281`; `src/sentinel_blue/service_repair.py:390–412`; `src/sentinel_blue/service_repair.py:543–561`.

**Cause.** The repair code reduces expected local transactions to numeric TCP ports, discarding the destination address. `_bindable()` accepts every loopback listener, so a listener on any loopback address with the same port becomes `listening_port_occupied`. `repair_parameters()` treats that finding as a fatal reason that restarting cannot bind the service, rather than checking address overlap.

**Reproduction and controls.** A real TCP socket listened on 127.0.0.2 at an ephemeral port. The actual listener collector observed it without errors. A valid modeled web-service repair profile expected 127.0.0.1 at the same port. The actual blocker and repair-plan functions classified the other address as occupied and held repair with the assertion that a restart cannot bind it. While the first listener stayed active, an independent TCP socket successfully bound and listened on 127.0.0.1 at that exact same port. Removing only the unrelated listener from the modeled observation allowed the otherwise identical repair plan.

**Impact and limits.** An unrelated same-port listener can prevent an otherwise admissible repair even when the demonstrated address-specific sockets do not overlap. This is a false certainty about a bind collision, not a real service-restart failure. A probe destination alone does not prove whether the daemon is configured for a specific address or a wildcard; that uncertainty should not be converted into a proved impossibility.

**Suggested correction.** Retain address, family and protocol in the endpoint model and compare known bind overlap. Require actual bind-policy evidence for a hard collision hold. Where that policy is unknown, report uncertainty rather than a proven incompatible listener. Preserve appropriate same-address and wildcard collision protections.

**Execution scope.** Real simultaneous loopback TCP listeners and actual listener collector/repair decision; service state/profile modeled, no repair mutation.

### Exact-runtime measured result

```json
{
  "observed_listeners": [
    {
      "protocol": "tcp",
      "address": "127.0.0.2",
      "port": 38235,
      "process": ""
    }
  ],
  "collector_errors": [],
  "intended_endpoint": [
    "127.0.0.1",
    38235
  ],
  "findings": [
    {
      "code": "listening_port_occupied",
      "subject": "web.service",
      "evidence": {
        "port": 38235,
        "address": "127.0.0.2",
        "holder": "unattributed"
      }
    }
  ],
  "restart_futility": "another process holds the declared listening port, so a restart cannot bind it (port 38235)",
  "repair_plan": "ValueError:another process holds the declared listening port, so a restart cannot bind it (port 38235); repair is held for review",
  "same_plan_without_unrelated_listener": "success",
  "both_addresses_listened_simultaneously": true
}
```

### Relevant unmodified source excerpts

`src/sentinel_blue/service_repair.py:205–250`

```text
  205: def local_probe_port(spec: dict[str, Any]) -> int | None:
  206:     """The exact TCP port a loopback transaction checks, or None when unstated.
  207: 
  208:     Only an explicit port or an http(s) URL is used. A guessed port would turn
  209:     an unrelated listener into a false accusation, so anything else is unknown.
  210:     """
  211:     if not isinstance(spec, dict) or not local_probe(spec):
  212:         return None
  213:     port = spec.get("port")
  214:     if type(port) is int and 1 <= port <= 65535:
  215:         return port
  216:     target = str(spec.get("target", ""))
  217:     if "://" not in target:
  218:         return None
  219:     try:
  220:         parsed = urlparse(target)
  221:     except ValueError:
  222:         return None
  223:     if parsed.scheme not in {"http", "https"}:
  224:         return None
  225:     try:
  226:         explicit = parsed.port
  227:     except ValueError:
  228:         return None
  229:     return explicit or (443 if parsed.scheme == "https" else 80)
  230: 
  231: 
  232: def declared_local_ports(manifest: dict[str, Any]) -> list[int]:
  233:     if not isinstance(manifest, dict):
  234:         raise ValueError("service manifest must be an object")
  235:     specs = manifest.get("expected_transactions", [])
  236:     if not isinstance(specs, list) or len(specs) > 32 or any(not isinstance(spec, dict) for spec in specs):
  237:         raise ValueError("expected_transactions must be a bounded list of probe objects")
  238:     ports = [local_probe_port(spec) for spec in specs]
  239:     return sorted({port for port in ports if port is not None})
  240: 
  241: 
  242: def _bindable(address: str) -> bool:
  243:     """A listener only blocks this service's bind on loopback or the wildcard."""
  244:     text = str(address).strip().strip("[]")
  245:     if text in {"", "*", "0.0.0.0", "::", "::0"}:
  246:         return True
  247:     try:
  248:         return ipaddress.ip_address(text).is_loopback
  249:     except ValueError:
  250:         return False
```

`src/sentinel_blue/service_repair.py:253–281`

```text
  253: def port_conflict_findings(service: str, manifest: dict[str, Any],
  254:                            telemetry: dict[str, Any]) -> list[dict[str, Any]]:
  255:     """A stopped service whose declared port is already held cannot be restarted.
  256: 
  257:     The service is not running, so no listener on its port can be its own; the
  258:     holder is either an orphaned process, a socket-activation unit, or an
  259:     attacker's listener. Each is reported with the evidence, never acted on.
  260:     """
  261:     findings: list[dict[str, Any]] = []
  262:     listeners = telemetry.get("listeners", [])
  263:     if not isinstance(listeners, list):
  264:         return findings
  265:     for port in declared_local_ports(manifest):
  266:         for row in listeners[:4096]:
  267:             if not isinstance(row, dict) or row.get("port") != port:
  268:                 continue
  269:             if str(row.get("protocol", "tcp")).casefold() not in {"tcp", "tcp6"}:
  270:                 continue
  271:             if not _bindable(row.get("address", "")):
  272:                 continue
  273:             holder = str(row.get("process", ""))[:200]
  274:             socket_activated = "pid=1," in holder or holder.endswith("pid=1)") or "pid=1)" in holder
  275:             findings.append({
  276:                 "code": "socket_activation_holds_port" if socket_activated else "listening_port_occupied",
  277:                 "subject": service,
  278:                 "evidence": {"port": port, "address": str(row.get("address", ""))[:64],
  279:                              "holder": holder or "unattributed"},
  280:             })
  281:             break
```

`src/sentinel_blue/service_repair.py:390–412`

```text
  390: def restart_futility(findings: list[dict[str, Any]]) -> str:
  391:     """The first named reason a restart cannot succeed, or an empty string."""
  392:     for finding in findings:
  393:         reason = RESTART_FUTILE_CODES.get(finding.get("code", ""))
  394:         if reason:
  395:             evidence = finding.get("evidence") or {}
  396:             port = evidence.get("port")
  397:             return f"{reason} (port {port})" if port else reason
  398:     return ""
  399: 
  400: 
  401: def restart_blockers(service: str, manifest: dict[str, Any], current: dict[str, Any],
  402:                      prior: dict[str, Any], telemetry: dict[str, Any]) -> list[dict[str, Any]]:
  403:     """Fault findings a mutation path must consider before restarting."""
  404:     running = str(current.get("state", "")) == "running"
  405:     findings = native_fault_findings(service, current, prior, running=running)
  406:     # A filesystem fault under the service's own files blocks it whether or not
  407:     # the service is currently running: a running service cannot write, and a
  408:     # stopped one cannot start.
  409:     findings.extend(host_capacity_findings(service, manifest, telemetry))
  410:     if not running:
  411:         findings.extend(port_conflict_findings(service, manifest, telemetry))
  412:     return findings
```

`src/sentinel_blue/service_repair.py:543–561`

```text
  543: def repair_parameters(profile: Any, agent_id: str, service: str, baseline: dict[str, Any],
  544:                       telemetry: dict[str, Any]) -> dict[str, Any]:
  545:     from .service_recovery import _fresh, check_recovery_observation, recovery_contract
  546:     import time
  547:     manifest = _manifest(profile, agent_id, service)
  548:     policy = manifest.get("repair_policy")
  549:     if not policy:
  550:         raise ValueError("coordinated repair requires an explicit repair_policy")
  551:     _fresh(telemetry, time.time(), allow_payload_issues=policy.get("allow_unrelated_payload_errors", False))
  552:     contract = recovery_contract(profile, agent_id, service, action="repair_service")
  553:     prior = _one(baseline.get("services", []), "name", service)
  554:     current = _one(telemetry.get("services", []), "name", service)
  555:     if prior.get("state") != "running":
  556:         raise ValueError("repair requires an approved running-service baseline")
  557:     # A restart the service manager or the host will defeat is held and named
  558:     # before any less specific refusal (issue #13).
  559:     futile = restart_futility(restart_blockers(service, manifest, current, prior, telemetry))
  560:     if futile:
  561:         raise ValueError(f"{futile}; repair is held for review")
```

## What the offline checks establish in this pass

The exact extracted package's `Start-Sentinel-Blue.sh --version` and `--verify-bundle` both returned zero with PATH pointing to a nonexistent tools directory and deliberately invalid PYTHONHOME/PYTHONPATH. The version was `sentinel-blue 1.9.101`; bundle verification reported `passed: true` and `files_checked: 5271`.

The isolated launcher therefore works in that environment while the separate scoring-worker entry point in LINUX-32 does not preserve the same isolation. The verification command's `network_access_required: false` is its recorded result; this pass did **not** rerun the prior kernel socket-denial, full source rebuild or actual GUI-window campaign. The existing package was reviewed, not rebuilt or reduced to a thin launcher.

## Interpretation and next engineering priorities

Prioritize read-only setup admission/reconciliation and native-worker isolation. Then close the service-identity and integrity-telemetry gaps, preserve truthful interface coverage, and correct the bind-overlap reasoning before making a repair hold definitive.

All new reproductions are local: private temporary files, actual ledgers, an unprivileged file-read child, benign startup/native-client markers, two ephemeral loopback listeners, and modeled provider/service observations. No actual login session, privileged account, cron entry, service unit, router or host firewall policy was installed. No cloud/repository or remote-machine API was used. A synthetic full-detector result is not a native attacker campaign. No native reboot, multi-host acceptance, detection-rate measurement or competition uptime is established.

The original release remains unchanged. No finding in this report is represented as fixed. Existing exact ownership guards should not be bypassed by deleting ledger state or choosing another ledger directory; the independent fresh-ledger fixture is only an experimental control.

## Evidence and reproduction files

`Sentinel_Blue_1.9.101_Sixth_Review_Evidence.json` retains current identity checks, full-suite summary, bundled regression results, exact import origins, all six source/package measured cases, desired-correctness failures, the supplemental interpreter-dependent result and launcher checks.

`Sentinel_Blue_1.9.101_Sixth_Review_Reproductions.zip` contains the independent reproduction code, eight regression assertions, suite drivers, instructions and measured logs. Run only on authorized disposable Linux infrastructure with the matching source/tests and bundled Python. The fixtures require privileges for private metadata/UID checks and do not replace native platform acceptance. No dependency payload, font files, real credentials or user data are included in that review archive.
