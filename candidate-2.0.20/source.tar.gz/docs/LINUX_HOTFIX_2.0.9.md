# Sentinel Blue 2.0.9 — R208 setup-redo governance corrections

This release corrects the findings of the independent 2.0.8 review (R208, `docs/R208_REVIEW_BASIS.md`) and one further defect found while correcting them (R208-07). It retains the self-contained Linux x86_64 installer, bundled Python/Tk, licenses, and matching source. The full `Sentinel-Blue-2.0.9-everything.html` includes the complete `.run` as embedded bytes, not a URL or a split-file requirement.

## R208-01: operator-started redo and freshness on one clock

`manual_redo()` now fetches the live governance view before taking the time used to judge its freshness. In 2.0.8 the time was taken first, so every fresh view appeared to come from the future and **Recovery → Redo approved setup** was always refused with "fresh complete redo-governance evidence is unavailable" — the only redo path in approval-based mode.

`DesktopClient.dashboard()` records `client_received_at`, the local receipt time. The advisory scheduler gate judges the 30-second freshness window against that local time, so a network GUI whose clock differs from the controller's is neither held nor admitted by comparing two machines' wall clocks. Snapshots without a receipt time (the controller's own check, older fixtures) keep the same-host check with a 5-second ordering tolerance. The controller's signed live check at dispatch and before each worker mutation is unchanged and remains authoritative. With every approved service healthy, a governed manual redo now explains that there is nothing to redo instead of reporting a missing scope.

## R208-02: holds are per approved service

The controller policy and live check evaluate exact (host, service) pairs. A maintenance grant still holds every service on its host. An unresolved repair — unclean rollback, unknown outcome, repair pending/queued/dispatched, or unreadable record — holds its own service; a repair that names no service, or whose record cannot be read, holds every service on its host. The redo worker's scope is the services its selected tasks are bound to (`service_key`); a selected task without a service binding (packages, shared files) conservatively adds every governed service on its host. On a single VM, one service's unresolved rollback therefore no longer disables redo for every other service, while a redo that runs host-level work is still checked against the whole host.

## R208-03: bounded worker polling and a reserved Emergency Stop allowance

`SetupRunner.paused()` — called on every scheduling-loop iteration — now polls at most every 2 seconds and stops polling once paused. Task admission and every pre-apply checkpoint remain unthrottled, so each mutation boundary still performs a fresh signed live check; a refusal at a task boundary now pauses the run immediately. Measured with a real `SetupRunner` and `WorkerGuard` against a signed controller, a running redo fell from 4.2 to about 0.6 signed checks per second (≈1,260 → ≈190 replay markers per 5 minutes; capacity 2,048).

Emergency Stop keeps a reserved replay allowance of 64 above the ordinary 2,048 markers. Replay protection is unchanged: each Emergency Stop request is still signed, stored and refused as a duplicate if replayed; only ordinary traffic can no longer exhaust the last way to stop. The controller now evaluates redo holds only for a check request's exact scope, and caches the classification of each repair row by its exact identity, status and stored JSON (a changed row is always re-read). With 4,096 retained failures the hold query fell from ≈79 ms to ≈12 ms under the controller's locks.

## R208-04: no orphan worker connection files

A redo checks Setup admission before writing `redo-control.json`, removes it if the worker fails to start, and the worker removes its own file (only the one beside its `job.json`) when the job ends. In 2.0.8 a paused local Setup with a running controller left a new 0600 copy of the operator signing key every 15-second tick, and finished jobs kept theirs indefinitely.

## R208-05 and R208-07: retention keeps unresolved evidence; the bound counts only it

Production controllers always run history archival, and `Store.prune()` is used only when archival is absent. In 2.0.8 the retained-evidence exception was added to `prune()` only; history archival still archived and deleted failed repairs older than the retention age (30 days, or 7 days under storage pressure), silently releasing an unresolved rollback hold (R208-07). Conversely, `prune()` retained every failed repair forever, and all of them — including clean rollbacks and receipted recoveries — counted toward a 4,096-row bound whose overflow held redo permanently (R208-05).

Both retention paths now use `Store.redo_evidence_pins_locked()`: failed repairs whose result is unclean or unreadable are pinned online (a receipted recovery keeps its original failure as evidence); clean rollbacks follow ordinary retention and archival. Archival also refuses any failed repair newer than the pin snapshot, so no row can cross the age boundary unclassified. More than 8,192 pinned rows keeps every failed repair online (fail-safe). The governance bound now counts only unresolved (holding, unreceipted) repairs.

## R208-06: audit label and verification report

Operator-verified recovery closes incidents with `resolved_by_operator_verified_recovery` instead of `resolved_by_setup_redo`. **Recovery → Verify repaired redo holds…** reports every held service's answer; one refused request no longer discards the others.

## Upgrade and deployment

Update the controller and agents together, reapprove the release/hash and setup plans, and restart/reconnect through the reviewed workflow. No schema change: the 2.0.8 `redo_recovery_receipts` table and backup contract are unchanged. Previously generated helpers, installed agents, controller boot registrations, and pending tasks are not upgraded merely by opening the new GUI. Preserve private job directories, ledgers, snapshots, authentication keys, and conflict records. `redo-control.json` files left by 2.0.8 jobs are not removed automatically; delete them from finished `job-redo-*` directories once no 2.0.8 worker is running.

## Validation scope

See the accompanying measured 2.0.9 report/JSON/logs for final counts and exact hashes. `tests/test_linux_hotfix_209.py` adds 37 regressions using private real files, SQLite, history archival, signed loopback controller HTTP and actual `SetupRunner` checkpoints with a modeled transport; 28 of them fail on unchanged 2.0.8. `tools/reproduce_R208.py` records 9 correctness assertions and 5 controls (all 9 fail and all 5 controls pass on 2.0.8; all 14 pass on 2.0.9). Prior R207 assertions remain in `tools/reproduce_R207.py`. No full user VM, native service recovery, graphical administrator authentication, reboot, multi-host deployment, or competition acceptance is claimed. Historical validation documents in the bundle apply only to their explicitly named release.
