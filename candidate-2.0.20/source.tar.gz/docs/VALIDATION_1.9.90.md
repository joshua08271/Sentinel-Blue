# Sentinel Blue 1.9.90 — queued restart revalidation

**Date:** 19 September 2026  
**Baseline:** corrected 1.9.89, preserved unchanged.  
**Delivered:** 1.9.90 runtime, matching source, incremental patch, Linux launcher ZIP,
all-in-one HTML, validation report, VM checklist and private test evidence.  
**Verdict:** the reproduced queued-restart and expired-preflight admission defects
are corrected in the tested paths. Native acceptance is still pending.

## 1. Issue selected

The last release fixed unavailable probe evidence. This round addresses a separate
execution-admission gap: an automatic restart planned for a stopped service could
still reach the executor after newer telemetry explicitly reported a reason to
hold it. The agent checked the old dependency/identity guard, but did not recheck
the target's current startup state, native restart blockers or business-data
filesystem against the approved manifest.

A second gap allowed dependency checks or source/file reads to consume the entire
observation freshness window after the initial check, then admit a forward
mutation with the now-expired guard. The production window remains 90 seconds.

These are real runtime admission fixes, not a new service catalog or blanket
repair authority. This does not close all of #13, #17/#34, #22 or #30.

## 2. Reproductions against unchanged 1.9.89

### P90-01 — newer target conditions were ignored by a queued restart

The portable replay creates an approved fixture profile, real SQLite Store,
automatic action envelope, ActionJournal and ActionExecutor using the exact
runtime. Service-manager transitions and final target validation are explicit
mocks; their call history demonstrates admission, not successful native repair.

| Newer observation after planning | 1.9.89 requested a start | 1.9.90 requested a start |
|---|---:|---:|
| Disabled startup state | Yes | No |
| Masked startup state | Yes | No |
| Native start-rate limit | Yes | No |
| Native out-of-memory failure | Yes | No |
| Target disappeared from inventory | Yes | No |
| Declared local port occupied | Yes | No |
| Declared business-data filesystem full | Yes | No |
| Unchanged genuine stopped-service outage (positive control) | Yes | Yes |

Both runs preserve the real temporary configuration file. A reported success in
the baseline replay is produced by the intentionally healthy final-validation
mock; it must not be interpreted as a masked systemd service actually starting.
The relevant failure is that the start operation was admitted at all.

### P90-02 — long preflight outlived observation freshness

A separate replay uses a real loopback HTTP daemon, actual network request and
real elapsed time. For this fixture only, the freshness window is shortened to
1 second, while the dependency response takes approximately 1.15 seconds. The
runtime files and production 90-second window are unchanged.

The original runtime still requested a start. The corrected runtime reports
`service recovery guard expired during preflight` and issues no start request.
Native target controls/final target health remain mocked; the dependency HTTP
request and preflight file reads are real.

An additional actual-file test verifies expiry **after an admitted restore**:
the file first becomes the trusted version, the next preflight sees expiry, and
ordinary rollback restores the exact prior damaged fixture content. No native
state transition is required in that case. Clock progression is simulated for
this additional test; file operations and restoration journals are real.

## 3. Corrections

| Runtime file | Change |
|---|---|
| `service_recovery.py` | `check_restart_target` rechecks latest target identity/state and known restart blockers; the automatic agent validator supplies the approved manifest, including required_data. `check_recovery_deadline` rejects stale/future/nonfinite guard times. |
| `actions.py` | Guarded restarts call target validation independently. A native stopped state following a latest running observation requires a new diagnosis. Freshness is rechecked around dependency/file preflight. |
| `service_repair_executor.py` | Rechecks the guard after source checks and fresh local application probes, before preparing a new repair. Existing rollback remains available. |
| `__init__.py` | Version updated to 1.9.90. |

The package has **no new runtime modules**. Agent/controller orchestration,
service builders, authorization policy, mutation ledger, recording, Linux
launcher and offline schema constants are unchanged. The existing agent calls
the strengthened validator; no signature or scope bypass is introduced.

**45 new regression tests** cover malformed/missing/duplicate targets, disabled
and masked states, known native faults, declared data volumes, port conflicts,
positive controls, direct-executor checks, replay identity and freshness bounds.

## 4. Final measured results

| Test | Result | Evidence scope |
|---|---|---|
| Complete headless source suite | **1,211 run; 1,196 passed; 15 skipped; no failures/errors** | Logic, mocks and bounded local integration fixtures. |
| Complete graphical source suite | **1,211 run; 1,197 passed; 14 skipped; no failures/errors** | Xvfb available graphical test included; not all desktop/native combinations. |
| Targeted exact-runtime suite | **261/261 passed**, no skips | Ten modules import the delivered zipapp, including all 45 new tests. |
| Exact-runtime continuity | **44/44 passed**, no skips | Supplied local TLS, SQLite, processes and simulated failure scenarios. |
| Basic, lifecycle/crash-resume and supervisor smoke | **All passed** | Test-owned local controller/agent/process fixtures. |
| Packaged withdrawal fixture | **Remove complete; Restore & Withdraw held** | Real local owned files; separate-host verification absent. |
| Original/corrected queued-target replay | **Seven late hazards refused after correction; positive control preserved** | Real profile/envelope/Store/ActionJournal/executor with mocked native controls. |
| Slow-preflight replay | **Original requests start; correction holds** | Actual loopback HTTP and elapsed time; shortened test-only freshness window. |
| Already-admitted file repair expiry | **Rollback preserved** | Actual file and journal round trip; clock/native-state fixtures. |

Counts overlap. The 45 new tests are included in both full suites and the
261-test subset. Skips are twelve Windows-native cases and two systemd cases,
plus one graphical test in the headless run. Existing ResourceWarnings and
expected failure text from negative fixtures are retained, not disguised as a
warning-free run. No test pass ratio is an availability measurement.

## 5. Compatibility and limits

* Latest telemetry is checked; this does not add an atomic live systemd snapshot
  immediately before every native write. Uncollected changes and last-instant
  races still need native testing and further engineering.
* Existing guard/wire schemas are retained. They do not pin a historical target
  restart counter. Current native loop substates are checked, but the agent does
  not invent a zero baseline and misclassify accumulated historical restarts.
  Controller-side baseline-relative counter checks remain unchanged.
* A currently running service is validation-only. Historical Result fields or
  disabled boot startup do not justify stopping an already running service.
  If native state is now stopped while the latest sample says running, this old
  action is held for a new diagnosis instead of reused for a new outage.
* The automatic agent gate knows the complete approved manifest. The executor's
  independent target check covers only the files/probes present in its guard;
  it cannot infer business-data paths omitted from an unbound library call.
* Missing capacity from legacy telemetry is not silently invented. The earlier
  compatibility policy is unchanged; absence is not evidence of healthy space.
* Guard rechecks apply to admission and existing preflight stages. They are not
  a guarantee that no transaction can ever outlive 90 seconds, nor permission
  to abandon an in-progress transaction without rollback. The filesystem/ledger
  and native service transitions are not made atomic by this patch.
* A refused action keeps its existing at-most-once journal record. Fixing the
  environment does not replay that envelope automatically; the ordinary
  controller diagnosis and durable recovery budget apply to new work.
* Explicitly reviewed unguarded actions retain their existing behavior. This
  release does not create a backdoor to automatic unguarded restarts.

## 6. VM tests — explicitly pending

`docs/VM_TESTING_REQUIRED_1.9.90.md` and the JSON companion carry **17 native
infrastructure/lifecycle areas and all 39 catalog products**. Every one is marked
**REQUIRES VM TESTING — NOT RUN**. New **VM-L17** specifically requires queued-target
changes, genuine positive controls, slow preflight, late uncollected changes,
and rollback using actual systemd/services and the approved profile.

No catalog product was newly accepted. All 39 `native_tested` flags stay false.
This round did not repeat historical nginx/Apache daemon acceptance fixtures;
the HTTP server used above is a Python test server, not those adapters.

Not performed: native Windows, real systemd transitions or reboot, power-loss,
authenticated remote SSH/WinRM/observer operation, forty-VM scaling, whole-event
endurance or adversarial testing. The shared Kali pool was not accessed and its
restrictions are not overridden by this local work.

Missing implementation remains separate: bounded root-cause repairs for disk,
OOM, start-limit and port ownership; broader identity/network/application
recovery; prerequisite installers and adopt-only provisioners; non-apt native
contracts; novice event wizard and bundled-Python packaging. No such capability
is falsely marked complete by this correction.

## 7. Identity and reproduction

**Runtime bytes:** 672,640  
**Runtime SHA-256:** `eb38023691ee87f537fc603d5e5568b0f6e7054c9d50de0dbf4a9a3c57422657`  
**Source correspondence:** all 112 packaged source members match.

The delivery verification includes two independent builds, rebuilding from the
supplied source archive, applying the incremental patch to original 1.9.89,
and confirming the Linux ZIP contains the identical runtime and VM checklist.

Use matching 1.9.90 source and runtime. Review actual event-profile release
version and hash deliberately; only the unapproved example inventory is updated.
Historical `MINIMUM_POLICY_SCHEMA_VERSIONS` stays 1 -> 1.9.74, 2 -> 1.9.75.
Older runtime-bound service receipts cannot automatically count as current.
No acceptance receipt was issued or manually promoted here.

```sh
PYTHONPATH=src:tests python3 -m unittest discover -s tests -t tests -v
xvfb-run -a env PYTHONPATH=src:tests python3 -m unittest discover -s tests -t tests -v
PYTHONPATH=. python3 tools/build_defensive_release.py --output ../build
python3 tools/controlled_continuity_acceptance.py \
  --runtime ../build/sentinel-blue-1.9.90.pyz --output ../continuity.json
```

Run development fixtures only in isolated authorized workspaces. The portable
replays in `harness/` accept explicit runtime/source/output paths. The job scripts
used for this session have fixed workspace paths and are labeled as such.
The Linux ZIP still requires Python 3.11+, cryptography and Tk, with its existing
one-time desktop installer. Opening the GUI does not deploy or authorize an event.
Recording and the launcher were not modified. No repository or remote host was
changed and no cloud charges were incurred.

## 8. Evidence index and harness corrections

`results/baseline-queued-restart.json` and `corrected-queued-restart.json` record
all eight same-fixture scenarios. `baseline-slow-preflight.json` and its corrected
counterpart record the real HTTP calls and elapsed times. `admitted-rollback.json`
records the actual-file restoration test. `runtime-diff.json`, full logs,
`packaged-regressions.json`, `continuity-detail.json` and smoke/withdrawal outputs
identify the exact tested bytes and scope. `delivery-verification.json` identifies
the final source/archive/patch/ZIP verification.

The first new regression attempt exposed a **test fixture alias**, not a product
fix: mutating a plan's shared probe object also mutated the in-memory profile.
The regression now copies the plan as a real serialized envelope would.
The first slow-HTTP harness invocation used incorrect helper keyword names; they
were corrected before the two authoritative replay results. An attempted tool
streaming session was unavailable; bounded local subprocess jobs then completed
within this response. No failure or skipped native check was relabeled a pass.
