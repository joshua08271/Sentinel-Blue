# Sentinel Blue 2.0.17: the next five autonomy fixes

2.0.17 fixes bugs 6, 7, 8, 9 and 11 of the 2.0.15 autonomy review. Bug 10 was already fixed in 2.0.16. Every other 2.0.16 behavior is unchanged.

No approval, authentication, backup, ownership, baseline or offline requirement is relaxed. Each fix keeps the protection the original check provided and removes only the part that switched recovery off.

## 6. The local session restarts a process that exits

**Before.** The GUI's local session (`linux-desktop-session`) ended as soon as either of its two processes exited: the controller supervisor or the agent. It then stopped the other one, and nothing started them again. When the supervisor itself was killed, its controller kept running without a parent and held the database lock. Starting the session again then failed with "another controller already owns this database".

**Now.**
- **Restarts.** A process that exits is started again. The delay is 2 s at first and doubles with each exit within 300 s, up to 60 s. It never gives up. The session stays `running` and its status line names what was restarted and how many times.
- **Crash loops.** A process that exits within 30 s of starting ten times in a row is restarted every 5 minutes until it stays up. Each start is recorded in the host's append-only change ledger, so a tight loop would otherwise grow it by thousands of rows a day.
- **Busy ledger.** A restart that finds the host change ledger busy (for example during a long service validation) waits and tries again 10 s later. It does not end the session.
- **Controller without its supervisor.** The supervised controller checks its parent once a second. If its supervisor has died, it stops cleanly through its own shutdown path, so the next supervisor can take the database lock. A controller whose supervisor is already gone when it starts refuses to start.
- **Processes left by an earlier run.**
  - The session records each process it starts (PID, start time, boot, executable and session) in `session-processes.json`.
  - When the session starts again, it stops those processes first. It signals a process only if every recorded field still matches, so a reused PID is never signalled. The one allowed difference is an executable replaced on disk while the process ran (Linux reports it as "(deleted)"); the same file identity is still required.
  - It waits up to 30 s for them to exit and then starts new ones. The status line names what it stopped. The GUI waits up to 80 s for the session to start.
  - A record is removed only once its process is verified stopped. A start that fails (for example during a withdrawal review, or because a process did not stop) keeps the record for the next start.
  - A record that is not this session's, or is malformed, is refused on every start and left in place for review.

**Not restarted, on purpose:**
- **Emergency withdrawal.** If the host has been paused for withdrawal, the session ends with the withdrawal message instead of restarting anything. Each process still refuses to start on a paused host, as before.
- **Changed profile or runtime.** If the approved event profile or the runtime changed since the session started, the session ends and asks for a fresh review. A restart never accepts a changed profile or package, which matches the supervisor's own hold.
- **First start.** A controller that exits before it first becomes ready still fails the start, as before, so the problem is visible straight away.

**Still true.**
- If the session process itself is killed, the controller and agent keep running and the GUI's **Reconnect saved local session** still attaches to them. Nothing restarts them until the session is started again, and that start now stops the processes left behind.
- SIGTERM to the session process is its normal stop signal and ends monitoring, as before.
- A child started in the few milliseconds before the session process is killed may not be recorded yet, so a later start cannot stop it.
- While a restart waits for a busy change ledger (up to 60 s per check), a Stop request is handled after that check.
- The controller supervisor's own restarts of the controller are paced as in 2.0.16 (at most one a minute).
- Nothing starts the session after a reboot.

## 7. A refused result no longer stops all later work on the host

**Before.** The agent keeps every action result until the controller acknowledges it, and takes no new work while any result is unacknowledged. When the controller definitively refused a result (a signed 409 conflict, for example because an operator had already reconciled that action), the result was never acknowledged. After four attempts it was not even offered again. The agent then took no new action on that host for the rest of the event.

**Now.**
- **Refused results.** After four signed refusals with HTTP 400, 403 or 409, a result no longer holds new work. For those, the controller keeps its own record of the action. The result stays in the agent's durable record and is still offered again, with a backoff that grows to one hour. Only the controller's signed answers count towards the four; a transport failure or server error during a re-offer neither counts nor changes the outcome. The agent logs one error when it reaches that point.
- **Everything else still holds.** New work still waits, exactly as before, while any result:
  - has not been delivered (for example, the controller is unreachable);
  - has been refused fewer than four times;
  - was answered with a signed 404, which means the controller has no record of that action (for example after a database restore), so nothing there would hold it;
  - got a signed reply that is not an acknowledgement.
- **The controller still holds that action.** Its row stays `dispatched` and then becomes `outcome_unknown`. That holds recovery of that service. With continuity, it also holds all work on that agent ("unknown action outcome") until an operator reconciles it. Once reconciled, work resumes. Before 2.0.17 it never did.

## 8. An automatic start is validated for as long as the service needs

**Before.** An automatic Linux start (the journaled start under restart permission) had a fixed 5 s to pass three consecutive health checks. A service that needed longer, such as PostgreSQL recovery, a large DNS zone or a slow application, or a health check that takes about 2 s, was always judged failed. It was then rolled back, which stopped the service it had just started.

**Now.**
- **Window.** The start is validated for the service's `repair_policy.validation_timeout_seconds` (5 to 120 s). Without a repair policy it gets 30 s. GUI workspaces already set 30 s.
- **Signed with the action.** The window travels in the signed recovery guard as `validation_timeout_seconds`. The agent's action policy accepts only an integer from 5 to 120, and the agent also requires it to match its own approved manifest.
- **Older journals.** Guards signed by 2.0.16 or earlier have no window. Their journals are still checked with 5 s, so their recorded undo still verifies.
- **Checks unchanged.** Three consecutive healthy checks are still required. A service that never becomes healthy is still rolled back, after the full window.
- **Lock held longer.** The agent holds the host change ledger lock for the whole start, now up to the window instead of 5 s. A Pause or withdrawal requested during a long validation waits up to 60 s for that lock and may report "busy"; retry it. Repairs already worked this way.

## 9. Recovery works when the agent's clock differs from the controller's

This matters only with a separate management host. On a single VM both use one clock.

**Before.**
- **Recovery.** It compared the agent's telemetry time with the controller's clock. An agent clock that was even a few seconds ahead, or more than 90 s behind, made every sample "not fresh", so no restart or repair was ever queued.
- **Continuity.** It refused any sync where the two clocks differed by more than 5 s, so the agent could take no online work at all.

**Now.** Freshness errs towards "older": the controller uses the largest clock difference the evidence allows. With the agent's round-trip report, network delay can never make an old sample look fresh. Without one, the controller is at least as strict as 2.0.16.
- **Two measurements.**
  - **Round trip (agent).** On each continuity sync the agent notes when it sent the request and when the reply arrived. The controller's signed reply time lies between the two, so the difference is bounded above and below. Delay only widens those bounds. The agent sends them with its next sync.
  - **One way (controller).** Each authenticated request's signed timestamp, compared with when the request arrived, bounds the difference from below.
- **What the controller uses.** It uses the agent's upper bound from the last 120 s, or the one-way bound if that is larger. Without a report it uses the one-way bound, but never less than zero; for an agent that looks behind, that is exactly the 2.0.16 behavior.
- **Where it is used.** Freshness is judged on the agent's own clock in the recovery planner, operator repair and "Mark recovered", the post-crash observation gate, the recovery status table, and setup redo. A sample more than 90 s old is still refused.
- **Online continuity.** A difference of up to 240 s is accepted for online, controller-signed work. The lease is kept on the agent's clock and ends 30 s after the request was sent. A clock step during the request voids that sync. Authentication still refuses requests more than 300 s off, as before.
- **Reports are advisory.** A controller that gets an unusable report ignores it and logs a warning; it never refuses the sync over it.
- **Offline authority.** It is judged by wall-clock bounds, so it still requires the clocks to agree within 5 s:
  - the agent takes a new offline policy only while its bounds show agreement within 5 s;
  - when a slow sync leaves that unclear, it keeps only the identical policy it already holds, so a slow reply does not drop a valid policy;
  - when its bounds show the clocks provably differ by more, it holds offline authority and says so in its status;
  - a revocation always applies;
  - the controller refuses to authorize offline recovery for an agent whose clock provably differs, and logs one warning per agent.

**Still true.** Run NTP on every host. Beyond 240 s, continuity refuses to sync. Beyond 300 s, authentication refuses every request. After an agent's clock is stepped back, freshness can be judged too strictly for up to 2 minutes, which delays but never widens recovery.

## 11. Reconciling an unknown outcome as executed no longer ends automatic restarts

**Before.** When an agent died mid-action, the action became `outcome_unknown`. If an operator then reconciled it as **executed**, the service's outage alert stayed open. Every later outage of that service joined that alert, and the alert's action was the reconciled one, so no restart was ever queued for that service again.

**Now.**
- **Reconcile closes the alert.** Reconciling an automatic, guarded restart or repair as executed closes its linked alert, the same way an agent-confirmed success does. The alert's binding must still match the action's. The reply and the audit record include `alert_closed`. If the action's stored parameters are unreadable, the row is quarantined and isolated as before, and the alert stays open.
- **The next outage restarts.** It opens a new alert and is restarted as usual, within the usual budgets.
- **Reconciled before 2.0.17.** An alert left open by an earlier release is closed the next time its service is observed stopped. That is recorded as `close_alert_of_reconciled_recovery`, and the outage after it is restarted.
- **Unchanged.** Reconciling as **not executed** works as before.

## Upgrade notes

- **Controller and agents** must run the same release, as before. A 2.0.16 agent refuses a 2.0.17 restart because it does not know the guard's new `validation_timeout_seconds` field.
- **Local GUI sessions** get the restart behavior as soon as they are started with 2.0.17. A session started by 2.0.16 has no `session-processes.json`, so its first 2.0.17 start stops nothing.
- **Dedicated management hosts** should still run NTP. Offline authorization now refuses an agent whose clock provably differs by more than 5 s instead of issuing a policy the agent would ignore.
- **Continuity handshake.** 2.0.17 agents add a `clock` field to the continuity sync. A 2.0.17 controller still accepts a sync without it.
