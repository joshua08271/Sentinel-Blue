# Sentinel Blue 2.0.9 — offline startup and upgrade

## Download and open

1. Save `Sentinel-Blue-2.0.9-everything.html` to local storage and open it in a modern browser. Internet access is not required. The full installer is embedded in this file; it is not a link to an online download.
2. Select **Save complete Linux installer (.run)**. Wait while the page decodes and checks its bytes. The saved filename is `sentinel-blue-2.0.9-linux-gui1-x86_64.run`. No `.part` joining is necessary. A direct `.run` download is also supplied separately.
3. Transfer the complete `.run` inside the Linux guest, not onto the Proxmox hypervisor. In your file manager, right-click it, choose **Properties → Permissions**, and enable **Allow executing file as program / Is executable**.
4. Double-click it and choose Run/Execute when asked. It verifies and privately extracts its bundled interpreter and GUI dependencies, then opens **Sentinel Blue 2.0.9 · Linux GUI 1**.
5. Use **Open as administrator…** on **Start here** when privileged setup is required. Complete the normal desktop authentication prompt and configure in the administrator window. Ordinary-user and administrator settings are separate.

Opening the GUI does not authorize a deployment. The package includes Python, Tcl/Tk, required Python dependencies, licenses, and local source/build tools; no pip installation, activation, cloud account, or online source is required. It still needs compatible Linux x86_64/glibc and native OS libraries/tools, an X11/XWayland session, and functioning graphical administrator authentication. Native server packages remain separate prerequisites. The small `.pyz` alone is not the complete offline package.

## Set up the single VM

Select only intended services in **Service setup**; highlight each and save **Configure selected service…**, **Ports: Automatic / Manual…**, and **Service check…**. Use real existing paths/accounts, approved ports and meaningful checks. DNS requires a real query and expected answer; a TCP listener does not establish SQL login, FTP transfer, SSH authentication, SMB share access or DHCP lease allocation.

Choose the intended recovery mode, select **Review local setup**, read its scope and any warnings, then approve. Capture/approve a baseline only after independently verifying the actual files, permissions and service transactions. Automatic setup redo depends on current controller permission. Approval-based disables automatic redo but keeps **Recovery → Redo approved setup** for the services that are not healthy; observe and Emergency Stop hold new redo. These controls do not erase already-running transactions or prevent their bounded safe rollback.

## Maintenance and held recovery

An approved maintenance grant holds setup redo on its host, including shared configuration/dependencies. An unresolved repair (unclean rollback, unknown outcome, repair in progress or unreadable record) holds redo of **its own service**; a repair that names no service holds its whole host, and a redo whose tasks include host-level work (packages, shared files) is checked against every service on that host. Incomplete or unknown repair outcomes do not become safe just because time has passed, and routine retention or history archival no longer removes them. First inspect and reconcile the actual target operation using its preserved evidence. After verifying recovery, **Recovery → Verify repaired redo holds…** requests a fresh evidence-based acknowledgment for each held service and reports every service's answer. It does not modify files or promote a new baseline. Unknown outcomes still require the existing outcome-reconciliation workflow. Failed-action records remain retained; do not delete them to bypass a hold.

Missing backup authority or required backups prevents a file-restoring repair offer. Full path identity survives shortened display messages. Read metadata/coverage warnings and preserve independent backups of important data and private recovery authority.

## Upgrading an existing session

Update controller and agents together. Reapprove version/hash and regenerate/review setup plans. New setup-redo workers deliberately refuse an older controller without the authenticated live-check API. A different GUI does not silently replace installed agents/helpers, pending timers, running jobs, or optional controller boot registration. Reconcile pending work with its matching old runtime before replacing it. Do not overwrite the active extracted directory.

Preserve all ledgers, backups, snapshots, authentication keys and conflict records. Those files are sensitive, not public upload material. A redo worker's private `redo-control.json` connection file is now written only after Setup admission and is removed when that redo ends or fails to start; files left by 2.0.8 jobs are not removed automatically — review and delete them from finished `job-redo-*` directories once no 2.0.8 worker is running. The reconciliation-receipt table is included in authenticated database backups; old backups without receipts cannot imply permission to clear unresolved failures. The earlier 2.0.7 requirement to review and completely recapture legacy unsigned restore-point metadata remains.

Closing the window is not the same as stopping monitoring. **Window → Close window** leaves background monitoring running; reconnect the saved local session to manage it. **Stop local monitoring** and **Withdraw** are different operations. Optional controller boot registration is not installed/upgraded just by opening the application.

## Acceptance boundary

Use the measured 2.0.9 report, not historical bundled notes, for this release's validation. Local regression/GUI checks are not full VM/polkit, native daemon, reboot, multi-host or competition acceptance. Test the actual single-VM service stack and removal/recovery controls before relying on unattended operation. Checksums detect corruption; they are not publisher signatures.
