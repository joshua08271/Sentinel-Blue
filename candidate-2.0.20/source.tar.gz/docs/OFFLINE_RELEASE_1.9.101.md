# Sentinel Blue 1.9.101 — self-contained offline Linux release

## What this release supplies

Use `sentinel-blue-1.9.101-offline-linux-x86_64.zip`. This is the full application
**and** standalone Python runtime, not the former system-Python launcher ZIP.
It includes Python 3.13.15; Tcl/Tk; cryptography, Paramiko, SMBProtocol, SPNEGO,
and their dependencies; SQLite; licenses/provenance; full matching source/tests;
and local build tools. The payload is retained from the checksum-verified
1.9.75 recovered offline distribution. No dependency was downloaded to build this
release. Vendor URLs in the provenance are historical attribution, not runtime
fetch locations. The application is updated from 1.9.100, not reverted to the historical payload donor.

Startup, GUI, local credential vault, recording, and local analysis need no
internet, preinstalled Python, pip installation, AI API, cloud login, subscription,
or activation. Nothing is silently installed when the GUI opens. The bundle's
launcher uses its adjacent isolated interpreter, ignoring PYTHONHOME/PYTHONPATH.
Missing/corrupt prerequisites produce an error, not an online fallback.

## Start

Extract **every file** into a local directory. Keep `runtime/`, `source/`, the
launchers, manifest, checksums and `sentinel-blue.pyz` together. Run:

```sh
./Start-Sentinel-Blue.sh
```

A file manager may require permission to execute scripts. For an application-menu
entry and desktop shortcut, run `sh install-linux-launcher.sh` once. This installer
also uses the bundled Python and only creates per-user shortcuts/icon/receipts.
The desktop may ask Trust/Allow Launching. Do not open the included `.desktop`
**template** directly. There is no automatic privilege elevation or deployment.

If an extractor strips executable bits:

```sh
chmod u+x Start-Sentinel-Blue.sh runtime/bin/python3
./Start-Sentinel-Blue.sh
```

The launcher no longer needs even `dirname` or a Python executable on PATH; it uses
shell built-ins and an explicit local interpreter. Native system administration
operations still use ordinary host utilities and require their approved privileges.

```sh
./Start-Sentinel-Blue.sh --version
./Start-Sentinel-Blue.sh --verify-bundle
./Start-Sentinel-Blue.sh offline-check --desktop
```

Verify the archive against the separately supplied SHA-256 before extraction.
`--verify-bundle` checks the distributed files locally; a local checksum manifest
is not a digital signature or protection from an actor replacing the entire bundle.
Use `sh install-linux-launcher.sh --uninstall` to remove owned per-user integration;
externally edited/unowned shortcut files are preserved and refused.

## Offline deployment and prerequisites

The approved LAN/range is still needed for communication between separate hosts.
Offline means no outside software source, cloud processing or internet dependency;
it does not mean agents can communicate with disconnected machines. Keep actual
event profiles, authority, credentials, trust anchors, and target addresses local.
An event profile's public-disclosure URL remains review metadata: it is not fetched.
`--package-url` deployment is refused; supply the reviewed local `.pyz` instead.

Copy the **complete** offline folder to each Linux target needing its own Python
before deploying an agent or compiling setup. Use a stable administrator-owned
location for privileged services, for example `/opt/sentinel-blue-offline`, not
a user-writable Desktop directory or a temporary download folder. Do not move or
remove the interpreter while persistent services or rollback timers reference it.
The current agent installer transfers the `.pyz` and configuration; it does **not**
automatically copy the entire interpreter payload to another host.

In each Linux inventory host, set `python` to the actual pre-staged executable:

```json
{"python": "/opt/sentinel-blue-offline/runtime/bin/python3"}
```

Local setup launched by this bundle automatically selects its current interpreter.
Remote setup launched by the offline bundle requires an explicit target `python`
path so it cannot mistake the controller's local path for the remote interpreter.
Generated service, router, configuration-access and witness helpers use the selected
interpreter. Router startup/rollback units and witness expiry retain the interpreter
which executed their approved installation. Linux agent installation now accepts
absolute bundled-interpreter paths and uses isolated execution. Existing operating
system Python may still be used when an operator explicitly selects it.

Built-in `linux-packages` defaults to `cache_only=true`. Explicit false is refused;
APT uses `--no-download` without `apt-get update`; DNF uses `--cacheonly`.
Stage all needed package metadata, packages and transitive OS dependencies in the
target's cache first. Missing local packages fail instead of reaching a repository.
The Windows prerequisite recipes are check-only in this offline release: provision
features/runtime from approved local media separately; no vendor HTTP download or
Windows Update installation is launched. This artifact is Linux x86_64, not a new
Windows package or Windows-native acceptance claim.

This bundle is not an operating-system image. It needs Linux x86_64, glibc 2.34+
(as required by retained wheels), a compatible loader/kernel and an X11/XWayland
session for the GUI. Native admin/client tools such as systemd, bash, ip, nft,
OpenSSH, ping, and database clients are **not all bundled**, nor are Redis, mail,
DNS, directory-server or web-server installation packages. They must exist or be
supplied on local media. No fresh machine can universally provision every possible
service from a Python distribution alone. A headless host can use CLI commands
without opening the GUI.

Reviewed custom runbooks, OS package hooks, and configured service probes remain
operator-supplied code/endpoints, not a network sandbox. This release removes
built-in online prerequisite sources; it does not install an egress firewall,
rewrite your target network, or promise arbitrary external commands cannot contact
an address. Keep the range isolated separately when that is part of event policy.

## Source and offline rebuilding

Full matching source/tests and builder are in `source/`. Rebuild using the retained
local payload, without pip or online build sources:

```sh
cd source
../runtime/bin/python3 -I -B tools/build_offline_release.py \
  --python-root ../runtime --dependency-manifest ../offline-manifest.json \
  --output /an/unused/local/build-directory
```

Use a new output directory outside the source and runtime. New manifests inventory
all dependency bytes/modes; the builder refuses altered payloads. It rejects
symlinks and unexpected font payloads, and retains software license files.
Historical cloud/native lab tools retained in source are optional development
tools, not invoked by startup or by this offline builder.

## Upgrade and remaining acceptance

Issues LINUX-26 through LINUX-30 are corrected in 1.9.101. Read
`source/docs/LINUX_HOTFIX_1.9.101.md` for the confirmation decision/retry rules,
exact-revision ownership, paired diagnostics, native-client cancellation and
Linux protected-identity normalization. Earlier fixes 1–25 and the complete
1.9.100 offline distribution policy are retained. This is not a claim of universal
correctness or native competition acceptance.

Reapprove the new version/hash and regenerate plans. Update the controller before
or with agents. Replacing a desktop/runtime does not update old generated scripts,
installed helper programs, interpreter paths, or pending timers. Reconcile pending
work using the matching preserved helper and authenticated evidence. Keep mutation
ledgers, exact pre-states, backups and completion/conflict records. Do not edit
immutable history or delete ownership claims to bypass a hold.

For new generic service confirmations the durable ledger decision precedes native
committed-state publication and claim release. Retry the same confirmation after
an interrupted acknowledgement. Before that decision, ordinary pending rollback
remains possible. After that decision, finish its publication, then use Emergency
Restore & Withdraw for a deliberate inverse; a pending rollback cannot silently
undo committed configuration. Unfinished publication blocks fresh overlapping
setup admission. Historical stranded native-committed/ledger-applied records
without the new proof are not automatically repaired or promoted.

The original 1.9.99 review is retained for provenance at
`source/docs/KNOWN_ISSUES_26-30.md`; it is historical, not the status of this build.
Native systemd/VM boot, distribution-specific behavior, remote SSH/multi-host
recovery, Windows-native behavior and scored-service uptime remain unestablished
by local regression fixtures. No native catalog flag or acceptance receipt has
been promoted. The separately delivered report records actual tests and limits.
