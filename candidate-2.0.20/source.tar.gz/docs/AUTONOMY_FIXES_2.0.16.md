# Sentinel Blue 2.0.16: automatic recovery keeps running with nobody watching

2.0.16 fixes bugs 1–5 of the 2.0.15 autonomy review. It also fixes bug 10 and bug 14, because they share code with bugs 1 and 4. Every other 2.0.15 behavior is unchanged.

No approval, authentication, backup, ownership, baseline or offline requirement is relaxed. Each fix keeps the protection the original check provided and removes only the part that switched recovery off.

## 1. The alert quota no longer switches recovery off

**Before.** Each agent may have at most 128 open alerts: 64 critical, 40 high, 16 medium and 8 low. Once the high tier was full, a new outage could not open its `baseline_service_stopped` alert. No alert meant no restart. A red team could fill the tier by creating about 40 users, rewriting a watched file in a loop, or (bug 10) stopping eight unscored services whose names sort first.

**Now.** A recovery candidate is a `baseline_service_stopped` or `service_repair_required` candidate for a service that the recovery planner has already confirmed for that host. The planner confirms a service only from the approved event profile after two matching observations, so telemetry cannot add candidates.
- A recovery candidate is selected before other evidence and does not count toward the 64-per-sample or 8-per-kind caps.
- Its alert is admitted in a reserved lane when the severity or total quota is full. The lane is bounded at 64 open recovery alerts per agent.
- The lane skips only the quota. The binding, lineage and recent-operator-decision checks all still apply.
- All other alerts keep their quotas, and suppressed alerts are still audited (`ingest_alert_overflow`).

**Still true.** The first "stopped" observation, before the planner has confirmed the outage, uses the normal quota. The restart is queued on the confirming observation. Visibility of other alert kinds under a flood is unchanged: a full tier still drops new alerts of that tier.

## 2. A controller crash no longer leaves automation off

**Before.** An unclean restart forced observe mode plus Emergency Stop unless the profile set `recovery.resume_after_controller_crash`. The GUI never set that flag. The profile's mode was re-applied only on the first session start. The GUI's Resume cleared the stop but left observe mode, and its label still read "governed by event profile". Because the crash marker was written before the port was bound, a busy port at startup also counted as a crash.

**Now:**
- **Crash resume.** A **guarded-autonomous** GUI workspace sets `recovery.resume_after_controller_crash: true`, and the reviewed plan says so. After an unclean exit the controller resumes the durably saved governance, so a saved Pause stays paused. It still requires the authenticated recovery key and anchor and a ready recovery preflight. Approval-based workspaces do not set the flag.
- **Resume.** **Resume approved changes** now sends `{"restore_profile_mode": true}`. The controller then restores the event profile's approved mode together with clearing the stop. It is refused if that mode exceeds the signed profile's ceiling. A signed Resume with an empty body behaves exactly as before, and the route rejects any other field.
- **Mode line.** The line now says whether automatic changes can run:
  - paused, with "Resume restores the approved … mode" when a crash lowered it;
  - paused by the host-wide Pause or Withdraw, which Resume does not clear;
  - off;
  - on, but service recovery waits for approval;
  - on.
- **New status fields.** `governance_status()` adds `profile_autonomy_mode`, `automatic_allowed` and `automatic_recovery`. The dashboard adds `host_automation_paused`, which is read on a helper thread so the dashboard never waits for the ledger lock the agent holds during a restart. It reports the last value read, or `null` before the first read completes.
- **Failed starts.** A start that fails before serving (a taken port, an unreadable TLS file, a busy syslog port) stops its workers, closes its listener and clears its own session marker. It is then recorded as a failed start, not a crash. The marker stays in three cases: the previous run was itself unclean, governance persistence is uncertain, or a worker did not stop.

**Dedicated management profiles** are approved outside the GUI. To get the same crash behavior, set `recovery.resume_after_controller_crash: true` there. It is valid only with guarded or range autonomy.

## 3. A wall-clock step no longer stops agent actions

**Before.** Continuity compared elapsed wall time with elapsed monotonic time since the agent process started. After any step of more than 5 s (an NTP or chrony correction, `date -s`), every online action fetch failed with "Clock discontinuity" until the agent restarted.

**Now.** A step does four things:
- revokes the offline policy and the online lease;
- re-baselines the clock;
- logs one warning;
- persists the revocation, so a restart does not bring the policy back.

Online, controller-signed work continues from the next sync. That sync still requires the controller's clock to agree within 5 s and a signed lease. At most the one fetch that straddles the step is refused.

Offline work is refused for that sample and then has no authority until a fresh signed sync. A backward step can revoke authority but never extend it.

**Not in this release.** On a separate management host, an agent whose clock is more than 5 s off the controller's clock still cannot sync. That is review bug 9. Run NTP on every VM.

## 4. A process running from a deleted executable holds only its own service

**Before.** Any payload-coverage gap on the host held restart and repair of every service. That included a fileless implant, a program that was run and then deleted, a daemon upgraded while running, or a scan time bound.

**Now.** Each gap names the service it belongs to, in a new telemetry array `collector_issue_owners` that is aligned with `collector_errors`:

| Owner | Where it comes from | Holds recovery of |
|---|---|---|
| a unit name, e.g. `web.service` | the process's cgroup (the first `*.service` component); the unit file or drop-in that references the payload | that service; a template or prefix owner (`app@.service`, `app-.service`) holds its instances |
| `""` (no service) | a login session, cron, shell or login startup files | no service (still reported and alerted) |
| `*running` | a process that could not be attributed, or processes left unscanned by a scan bound | services that currently have processes; not a stopped service |
| `*` | anything else that cannot be attributed (another systemd file type, Windows, telemetry without owners) | every service, as before |

When a scan bound is reached, the collector reads only the remaining processes' cgroups (within 0.5 s) and names their services. The process whose arguments were cut off by the reference bound is named too. Many processes in a login session therefore no longer hold everything.

Identical gaps, such as the workers of one upgraded daemon, are reported once with a count. If the 256-row diagnostic array still overflows and every omitted row is a payload gap, the overflow row keeps the payload provenance and the omitted owners (up to 8, otherwise `*`). If any omitted row is not a payload gap, the overflow row is `unknown`, as before.

After a controller crash, a gap attributed to a service, or to no service, relaxes the "complete observation" gate only for **automatic restart and repair**. The agent rechecks those against that service's own evidence before running them. Every other action still needs a complete observation.

**Bug 14.** The restart-only path now honours `repair_policy.allow_unrelated_payload_errors`, and the agent's recheck receives it. The opt-out now means what its name says: it ignores gaps that are unrelated or cannot be attributed, but a gap attributed to the service being recovered still holds that service. In 2.0.15 it ignored every payload gap.

**Still held on purpose:**
- a gap attributed to the service being recovered, or one that cannot be attributed;
- collector failures other than payload coverage (source `unknown`), such as a failed `ss`.

## 5. The controller supervisor never gives up

**Before.** SIGTERM sent to the controller child alone made it exit cleanly, and the supervisor treated that as final. Five failures in 300 s stopped supervision for good (exit 70). The boot unit used `Restart=on-failure` with `StartLimitBurst=3`. A failed heartbeat write crashed the controller in a loop.

**Now.**
- **Restarts.** Only a stop the supervisor was asked for is final. Any other exit is restarted, including a clean exit with no stop request and a stale heartbeat. The delay starts at 2 s and doubles with each recent failure. Once five failures fall within 300 s, the supervisor waits 60 s before each further attempt and keeps trying.
- **Holds.** A changed profile or package is still a hold and is never launched. A transient I/O error while re-reading them, or while starting the process, is retried.
- **Status and heartbeat files.**
  - A malformed or future status file is moved to `status.json.invalid`, and supervision continues.
  - A failed status write is logged and does not end supervision.
  - A failed heartbeat write is logged, not raised. The supervisor then sees a stale heartbeat and restarts the controller.
- **Boot registration.**
  - The systemd unit uses `Restart=always`, `RestartSec=10` and `StartLimitIntervalSec=0`. `systemctl stop` still stops it.
  - The Windows scheduled task allows 999 restarts at one-minute intervals. Task Scheduler does not restart a task that exits 0, and the supervisor exits 0 only when stopped.
  - The controller does not rewrite an existing registration. Run `controller-boot-uninstall` and then `controller-boot-install` to get the new settings.

**Not in this release.** Review bug 6: the GUI's local session still ends when either child exits.

## Upgrade notes

- **Local GUI workspaces** created by 2.0.15 keep their approved profile. Prepare a new guarded workspace to get crash resume, or add `recovery.resume_after_controller_crash: true` through a reviewed profile change. The Resume and mode-line changes apply as soon as 2.0.16 is running.
- **Controller and agents** must run the same release (unchanged). `collector_issue_owners` is optional on the wire. A sample without it is treated as unattributed (`*`), which is the 2.0.15 behavior.
