# Sentinel Blue 1.9.89 — runtime probe-evidence correction

**Date:** 19 September 2026  
**Baseline:** corrected 1.9.88, preserved unchanged.  
**Delivered:** 1.9.89 runtime, matching full source, incremental patch, Linux launcher ZIP, all-in-one HTML, VM-testing checklist and private evidence.  
**Verdict:** the reproduced probe-evidence defects are corrected and the listed local tests pass. Full native/competition acceptance is still open.

## 1. What was selected and why

The previous Linux backlog has native service acceptance, systemd lifecycle and
multi-host validation near the top. Those cannot honestly be closed with this
container. While examining the production repair path, three related executable
reproductions showed a concrete high-priority runtime defect that can be fixed
and tested locally: **missing checking evidence could trigger a service repair
or be accepted as evidence that an action succeeded**.

This is not another catalog expansion or an acceptance-runner-only change. It
changes the actual probe/repair/validation path while preserving action authority,
rate limits, native state checks, rollback, ledger ownership and operator holds.
It does not close all of #12, #13, #17/#34, #22 or #30.

## 2. Reproduced failures in unchanged 1.9.88

### P89-01 — local checker saturation looked like a target outage

`BoundedRequestPool.run()` refused an operation before calling it, but raised a
generic RuntimeError. `run_probe()` returned `healthy: false, executed: true`.
The controller could therefore interpret its own checker-capacity failure as a
failed application transaction.

An independent replay used a **real loopback HTTP server**, an occupied real
one-slot worker pool and the production controller/SQLite path. Baseline approval
used the existing controlled test fixture. The healthy server remained running.
1.9.88 queued a `repair_service` after the unadmitted check. The new runtime queued
no repair. Once pool capacity was released, a real HTTP request succeeded again.
No native service-manager operation was executed during this replay. This is not
a 40-host load benchmark.

### P89-02 — a fresh unattempted check could restart a running service

In `ServiceRepairExecutor.execute()`, the live precheck accepted any non-all-healthy
batch as grounds to proceed. An actual `ProbeResult(healthy=False, executed=False)`
therefore passed that gate. A disposable-file/executor fixture reproduced native
transition requests `stopped -> running` even though no new check had run.
Service management was mocked; this demonstrated improper admission, not a live
systemd outage. The later validation failed and rolled back in the baseline case.

In 1.9.89 the same missing result holds **before** a service transition, repair
journal or file mutation. Genuine negative local evidence still permits an
otherwise approved repair; the correction does not disable service recovery.

### P89-03 — contradictory success evidence could pass the controller contract

A result claiming `healthy: true, executed: false` passed the old successful-action
probe check. It now fails. Stable service validation, dependency checks and file
restoration validation use the same executed/matching evidence rule.

## 3. Code changes

| File | Change |
|---|---|
| `probe_evidence.py` | New bounded shared three-state matcher: measured true/false versus unknown, exact identity/count, duplicate and malformed-result handling. |
| `request_deadline.py` | Typed `RequestCapacityUnavailable` exception for an operation the pool never admits; capacity/deadline limits are unchanged. |
| `probes.py` | Pool nonadmission becomes `executed: false`, not a fabricated outage. |
| `service_repair.py` | Telemetry health uses the shared evidence interpretation. |
| `service_recovery.py` | Unknown dependency results cannot authorize recovery. |
| `actions.py` | Client readiness before service mutations, exact executed validation batches, stable-success checks and quarantine-result health handling. |
| `service_repair_executor.py` | Complete local evidence before stopping a running service; unknown/missing/mismatched results hold; final/dependency evidence must be measured success. |
| `restoration.py` | Exact executed probe results are required where file restore/rollback has a probe contract; missing batches cannot silently pass. |
| `store.py` | A success attestation cannot claim an unexecuted check is healthy. |
| `tests/test_probe_evidence_1989.py` | 48 corrective tests, with real temporary files, worker pool and loopback HTTP as well as explicit service-manager mocks. |
| `tools/build_linux_desktop_bundle.py` | Includes the VM checklist and its JSON in the Linux package, not just the private source. |

Version metadata and the **unapproved example inventory only** now identify 1.9.89
and its runtime hash. No real event profile was rewritten or approved.

## 4. Compatibility and remaining limits of this fix

Wire rows omitting `executed` retain the established legacy default of True.
Explicit False and invalid types cannot establish success or failure. There is
no new wire-schema requirement, new mutation action or authorization override.

A genuine failed connection/transaction remains negative evidence. A recovered
healthy service is not restarted merely because an older observation failed.
An unavailable check after an already admitted mutation still causes validation
to fail and the existing guarded rollback to run; this is not immunity to every
client disappearing at every possible instant.

Client-readiness checking establishes availability of the configured checking
binary/module, not valid credentials or complete live service health. The change
does not reclassify every possible DNS/TLS/credential/library error. Those native
edge cases remain in the VM checklist. Local evidence is not proof that a
root-compromised agent is trustworthy.

The existing #13 holds remain: no new automatic disk deletion, memory-process
killing, port eviction, systemd reset-failed, account recreation or universal
application remediation was added. Generalized recovery and provisioning gaps
remain implementation work, not merely test flags.

## 5. Measured test results

| Test | Result | Evidence boundary |
|---|---|---|
| Full source suite, headless | **1,166 run; 1,151 passed; 15 skipped; zero failures/errors** | Regression/fixture coverage, not 1,166 native service tests. |
| Full source suite under Xvfb | **1,166 run; 1,152 passed; 14 skipped; zero failures/errors** | Actual available graphical test included; not all desktops. |
| Focused tests importing the delivered runtime | **211/211 passed**, no skips | New correction plus service repair, recovery, manifest and controller regressions. |
| Exact-runtime continuity fixture | **44/44 passed**, no skips | Local TLS/process/SQLite and simulated fault evidence. |
| Basic/lifecycle/crash-resume/supervisor smoke | **Passed** | Owned local controller/agent/process fixtures. |
| Packaged withdrawal fixture | **Remove complete; Restore & Withdraw held** | Real local files, no independent separate-host verification. |
| Controller capacity replay | **Old runtime queues repair; new runtime does not** | Real loopback server/pool; baseline fixture; no native service mutation. |
| Native service/catalog acceptance | **Not run / not accepted** | All 39 static flags remain false. |

The 48 new tests are included in both the full-suite and packaged-targeted counts.
Counts overlap; do not sum them or turn pass ratios into uptime. Headless skips
are twelve Windows-native cases, two systemd cases and one graphical case.
The graphical run keeps the twelve Windows and two systemd skips. Existing
ResourceWarnings in inherited tests are not represented as a warning-free run.

## 6. Required VM tests — explicitly pending

See **`docs/VM_TESTING_REQUIRED_1.9.89.md`** and
**`docs/vm-testing-required-1.9.89.json`**, embedded in the all-in-one HTML and
included in the Linux ZIP and private source. They identify **16 environment/
lifecycle checks and all 39 catalog products** as **REQUIRES VM TESTING — NOT RUN**.

They cover the new correction with real systemd and installed clients, complete
native product acceptance, boot/reboot, abrupt termination, remote SSH enrollment,
independent-observer withdrawal, controller loss/offline reconciliation, scaling,
endurance, filesystem/resource faults, identities/persistence, adversarial quality,
cross-host dependencies, distribution compatibility, desktops and Windows.
The document also separately lists features needing **implementation**, including
adopt-only provisioners and general root-cause recovery.

This campaign did not run nginx/Apache product adapters again, nor any of the
other catalog daemons. The real HTTP server in the new regression is a controlled
Python fixture; it must not be labeled native nginx/Apache acceptance. No VM,
Proxmox/Azure account, hypervisor setting or remote repository was accessed.
No competition service-availability estimate is supported by these checks.

## 7. Build and release identity

Runtime: **671,431 bytes**  
SHA-256: **`b9d605fdda72dae707f6caf45b7ce2ead406fb00b8e51d4becefa94213a7867d`**

The two independent builds match. All **112 packaged `sentinel_blue/` members**
match their source files; the whole-runtime comparison includes the generated
zipapp entry point. The delivered-source rebuild and patch application are
checked separately in `results/delivery-verification.json` before delivery.

The controller, agent, authorization policy, event-profile enforcement, mutation
ledger, recovery-budget implementation, offline-continuity schemas and Linux
launcher files are retained. Production execution and result validation are
intentionally tightened in the files listed above; it would be inaccurate to
say the entire runtime is unchanged.

Use matching source/tools and runtime. Review your actual event profile's
`release.version` and `release.sha256` before deployment. Do not change historical
`MINIMUM_POLICY_SCHEMA_VERSIONS` (1 -> 1.9.74, 2 -> 1.9.75). Existing schema-2
acceptance receipts from older runtime bytes cannot automatically count as
current acceptance. No acceptance receipt was issued in this campaign.

The Linux ZIP still requires Python 3.11+, Tk and cryptography. It contains the
existing one-time desktop installer; opening the GUI does not deploy/authorize
an entire network. This is not a Python-free executable or a new Windows app.

## 8. Reproduction and evidence

From the delivered source, with test dependencies installed, use an isolated
local workspace rather than an unrelated production/shared host:

```sh
PYTHONPATH=src:tests python3 -m unittest discover -s tests -t tests -v
xvfb-run -a env PYTHONPATH=src:tests python3 -m unittest discover -s tests -t tests -v
PYTHONPATH=. python3 tools/build_defensive_release.py --output ../build
python3 tools/controlled_continuity_acceptance.py \
  --runtime ../build/sentinel-blue-1.9.89.pyz --output ../continuity.json
```

| Evidence | Contents |
|---|---|
| `results/baseline_reproductions.json` | Three failures in unchanged 1.9.88, with explicit fixture scope. |
| `results/controller-capacity-before.json`, `controller-capacity-after.json` | Actual exact-runtime replay observations before and after. |
| `logs/candidate-full-headless.log` | Completed headless source suite; candidate label retained, same final runtime code. |
| `logs/final-full-graphical.log` | Completed graphical source suite. |
| `logs/final-packaged-regressions.log` | 211 tests importing the exact delivered runtime. |
| `results/final-continuity.json`, `.log` | Supplied 44-check exact-runtime acceptance fixture. |
| `logs/final-smoke-*.log`, `results/final-smokes.json` | Current smoke/withdrawal commands and results. |
| `results/delivery-verification.json` | Archive, patch, source/runtime and packaged-checklist correspondence. |
| `harness/controller_capacity_replay.py` | Portable replay accepting runtime/source/output paths. |
| `source/` archive and incremental patch | Complete change set and matching tests. |

Private evidence is for project continuation; it was not published. Harnesses
with fixed workspace paths are labeled as such in START-HERE. The source's
ordinary test commands are relative and require no session-specific path.
No skipped or simulated check is presented as native acceptance.
