# Sentinel Blue 1.9.84 review and 1.9.85 corrective validation

**Input:** the uploaded `Sentinel-Blue-1.9.84-everything.html`.  
**Original verdict:** regression suite green, but not accepted for dependable fresh Linux desktop startup.  
**Delivered correction:** **1.9.85**, passing the recorded local acceptance checks.  
**Boundary:** this is not a claim that every service, operating system, failure mode or competition scenario works.

## 1. Executive assessment

1.9.84 retains the 1.9.82 service-setup corrections and adds useful input-contract and Linux-launcher work. Both supplied 988-test runs passed here. Independent tests nevertheless found a first-launch blocker: the recording initializer created the GUI's parent storage directory too permissively, after which the GUI correctly refused it. A detached launch hid that error. Existing tests did not exercise this full fresh-HOME startup chain.

The installer also misencoded five legal path variants and could overwrite or remove desktop integration files without proving ownership. Error-report fallback could stop at a helper that failed, and control characters could break an invocation. These issues were reproduced and corrected in 1.9.85. A real mapped GUI now opens from its installed application entry under Xvfb, including as an unprivileged user. This is stronger than checking an entry's text or substituting a fake Python interpreter.

The final 1.9.85 suites have no failures or errors in this environment. Earlier supplied functionality also passed the listed smoke, continuity, GUI and limited real nginx/Apache checks. These results establish the tested behavior only. All 39 catalog entries still have `native_tested: False`; 37 products were not run, and neither native Windows nor real systemd/reboot acceptance was available.

**The original upload was not modified. No repository, cloud account or remote range VM was changed.** The new runtime, source, patch and Linux launcher bundle are separate artifacts.

## 2. Artifact identity and source correspondence

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| Original 1.9.84 runtime | 660,771 | `6b8c82b30160d20561c5a3a57113058a3059c2b3d29dffe3341c0cfeba084b7f` |
| Corrected 1.9.85 runtime | 661,192 | `da7eaad30d9322805b0b6aefc1dec1a29f2b673c4914be71937aa3864e36b4d4` |

Both original and corrected runtimes were independently rebuilt twice with identical results. Each has 110 packaged source members that match its corresponding source byte-for-byte. Whole-runtime equality also covers the generated zipapp entry point. Code, tests and packaging were frozen before the final complete runs; the recorded freeze had no changed files when checked after completion. The final source archive is separately rebuilt during delivery verification.

Reproducibility establishes which bytes were tested. It is not evidence that every behavior is correct. Update a reviewed event profile's version and runtime digest deliberately; the GUI does not silently repin event authority.

## 3. Environment and test boundaries

Testing ran in a Debian 13 Linux container with Python 3.13.5, Tk/Xvfb, GLib/GIO, nginx, Apache and OpenSSL. PID 1 is supervisord, not systemd. The main test account was root; the installed-app startup was also repeated successfully as UID 65534 in a separate temporary HOME with private state mode 0700.

The available web daemons were exercised using real configuration files, native parsers, real processes and HTTP/HTTPS transactions on loopback. An explicit service-control substitute starts/stops those processes. This is **not native systemd, boot or full guarded remote transaction acceptance**. No DHCP broadcast, routing change, destructive range fault or remote attack was performed.

The other service binaries and native Windows environment were not available here. Attempts to access additional packages did not succeed. Existing user access to Proxmox is not an authenticated connection from this session; no such connection was used.

## 4. Results ledger

| Test | Original 1.9.84 | Corrected 1.9.85 | Meaning |
|---|---|---|---|
| Complete headless suite | 988 run; 973 passed; 15 skipped | **1,009 run; 994 passed; 15 skipped** | Supplied logic/regression coverage, including fixtures and mocks |
| Complete suite under Xvfb | 988 run; 974 passed; 14 skipped | **1,009 run; 995 passed; 14 skipped** | Includes available actual graphical test |
| Targeted final-runtime regressions | Not a separate count | **175/175 passed** | Six test modules import the delivered zipapp rather than source |
| Exact-runtime controlled continuity | 44/44 | **44/44** | Supplied local continuity fixture |
| Basic/lifecycle/supervisor smoke | All passed | **All passed** | Real local controller/agent and bounded process fixtures |
| Packaged withdrawal | Remove completes; Restore & Withdraw held | **Same required behavior** | Local ownership/rollback evidence; independent verification absent |
| nginx/Apache application campaign | 11/11 | **11/11** | Real product-level requests; service manager substituted |
| GUI configuration/export/merge | Passed | **Passed** | Actual Tk controls, local inventory fixture |
| GUI lifecycle stress | 15/15 | **15/15** | Seven cycles include pending work; no thread errors |
| Actual GLib path launch | 3/8 pass | **8/8 pass** | Harmless payload proves exact launcher/path dispatch |
| Fresh HOME, installed app to actual GUI | **Fails** | **Passes** | Real runtime, mapped window, normal menu close |
| Existing private HOME, installed app | Passes as positive control | **Passes** | Does not recreate or weaken existing trust state |
| Unprivileged installed-app GUI | Not used to claim an original pass | **Fresh and existing-private cases pass** | UID 65534, actual mapped GUI, clean process exit |
| Additional negative launch/ownership checks | Defects reproduced | **5/5 pass** | Includes real detached-child failure and captured notifier invocation |

**Counts overlap. Do not add them into one total, treat skips as passes, or convert pass rates into service uptime.** Headless skips are 12 Windows-native cases, two systemd cases and one graphical case. Under Xvfb only the 12 Windows and two systemd cases remain skipped.

The new 21 first-launch/installer regressions are part of the 1,009 full-suite count and the 175 packaged-regression count. The fresh/existing HOME launch and close checks were repeated in strengthened visible-window and non-root campaigns; these are repetition, not additional independent features.

## 5. Confirmed findings and corrections

### V84-01 — Fresh default GUI startup is blocked by recording-created storage permissions

**Observed:** with a clean HOME and ordinary umask, the runtime creates `~/.sentinel-blue-desktop/recordings` before constructing the GUI. Its implicit parent is created with group/other access (0755; an inherited setgid bit also appeared in the root container fixture). The desktop's existing private-directory check refuses that parent. Foreground output: `private storage must be owned by the operator with mode 0700`. A previously created private parent is a positive control that permits launch.

**Fix:** `recording.initialize` explicitly establishes the shared default parent through the existing private-directory guard before constructing the recorder. Existing unsafe storage is still refused, not silently trusted or chmodded.

**Evidence:** default fresh/existing/unsafe directory regressions, exact runtime through installed GLib application entry, mapped-window checks, and an unprivileged UID 65534 repeat. The non-root state directory is mode 0700 and both tested windows close without a remaining matching child process.

**Remaining migration boundary:** an old failed run may already have left an unsafe state directory. This release reports it; it does not blindly repair unknown ownership or permissions. Do not delete the host mutation ledger or relax a security guard to get past that condition.

### V84-02 — Detached GUI failures lose their error message

**Observed:** no-argument desktop launch detaches a child with `desktop --foreground`. The original error-report condition only recognized the no-argument parent. A child configuration failure went to discarded stderr; an invalid display raised TclError without the promised explanation. The parent returning zero meant only that a child was spawned, not that a window opened.

**Fix:** explicit desktop child invocations use the same visible-error path. Configuration, import and runtime launch failures are routed to it. Tk display connection errors become a descriptive runtime error, and failed initialization destroys its temporary root on the GUI thread. Non-desktop commands retain their previous exception behavior.

**Evidence:** a real detached child with an invalid DISPLAY reaches a captured notification helper with the correct reason; separate configuration-error routing tests pass. This verifies delivery attempts, not a visible dialog on a nonexistent display. Successful mapped-GUI tests use a working Xvfb display.

### V84-03 — Legal installation paths break desktop-entry execution

**Observed:** actual GLib dispatch failed for paths containing ampersand, a double quote, a vertical bar, `%U`, or a backslash. For ampersand, sed replacement inserted `@EXEC@` into the path; the vertical bar caused a sed error. Ordinary spaces, dollar sign and backtick cases passed the original actual dispatch experiment.

**Fix:** replace shell text substitution with a Python-stdlib integration helper that applies the Desktop Entry string and Exec escaping layers. The installed command has a fixed `/bin/sh` executable plus one escaped literal launcher-path argument. It never uses `sh -c` or interpolates a user path as a shell program.

**Evidence:** all eight paths now reach the exact intended harmless runtime payload through GLib. These dispatch cases intentionally do not run the full Sentinel GUI; full-runtime GUI launch is a separate test. Desktop escaping was cross-checked against the freedesktop.org Desktop Entry specification.

### V84-04 — Installer lacks ownership checks for overwrite and removal

**Observed:** the 1.9.84 installer overwrites an existing entry and its uninstall path removes a subsequently changed entry based on filename alone.

**Fix:** a private per-user receipt records exact hashes and modes of the application entry, icon and optional desktop entry. Unowned or changed objects, symlink paths, forged out-of-scope receipt destinations and mismatched installation folders are held. Atomic writes and a lock coordinate the installer. Prepared/uninstalling receipts permit bounded restart after partial application/removal.

**Evidence:** new tests cover normal install/reapply/remove, unowned and changed entries, symlinks, malformed receipts, destination limits, and simulated interrupted-install/uninstall recovery. Actual negative acceptance checks confirm unowned/modified content remains intact.

**Boundary:** this is an installer-specific exact-state receipt, separate from the host action ledger. It does not claim security against a compromised account owner or full power-loss proof. Source download files remain after uninstall, and a private empty lock file remains to maintain concurrency safety. Old 1.9.84 entries without a receipt are not silently adopted. Changing installation directory requires reviewing/removing the previously recorded integration first.

### V84-05 — Error helpers can fail without fallback; control bytes break invocation

**Observed:** the original Python reporter treated a helper returning nonzero as successful. A NUL in the message survived cleaning and raised an embedded-null-byte error. Other control characters also remained.

**Fix:** sanitize nonprintable characters, retain the length bound, test helper exit status and try the next available notifier on failure. The shell launcher likewise tries its next notifier after a failed command. Arguments remain separate values, not shell code.

**Evidence:** a first helper returning 1 falls through to a second returning 0; control-byte and all-helper-failure tests pass. Shell-metacharacter handling from the existing suite remains covered.

### V84-06 — Input-fuzz documentation overstates what was rejected

**Observed:** replaying the supplied corpus against the exact 1.9.84 runtime produced **8,360 calls: 8,321 ValueError refusals, 39 accepted inputs, zero unexpected exceptions**. The suite's loop fails on unexpected exceptions but does not assert that every call raises ValueError.

Some accepted shapes are valid in context, such as real booleans, optional empty lists or legal single hostnames. The detailed list also retains coercion cases (for example numeric time-source/network inputs) for further explicit schema review. The 39 are not asserted to be 39 native-product bugs.

**Resolution:** report the measured counts rather than repeating “8,360 rejected.” No service-pack semantics or authentication guards were changed in this launch-focused correction. The inherited contract tests demonstrate controlled error handling for this corpus, not exhaustive correctness or native service acceptance.

## 6. Existing service fixes: what was actually rechecked

nginx passed catalog dispatch -> generated configuration -> real HTTP response, identical reapply without replacing the master, outside-edit refusal, invalid-TLS rollback to the preceding HTTP configuration and a matching-certificate HTTPS transaction with verification.

Apache passed requested-content serving from the active site, identical reapply, outside-edit refusal, approved update to a document root with spaces, invalid-TLS rollback and native parser acceptance of the spaced path. The previous false-success Apache problem did not recur in either the original 1.9.84 or corrected 1.9.85 campaign.

Both campaigns have **11 checks**, but no result promotes either catalog row to complete native acceptance. All real web listeners were test-owned and on loopback. No existing range service was changed.

The final 175-test packaged subset includes prior 1.9.82 corrections, service catalog tests, generated script contract tests, launcher/error tests and the 21 new regressions. It imports the exact 1.9.85 zipapp. The supplied generated-script tests parse 19 packs' check/apply text with sh and bash and compile their embedded validators. Parsing does not execute the missing service products.

## 7. GUI usability and operational boundaries

The actual Service setup GUI still accepts validated JSON parameters, exports configured tasks and merges them into a new full inventory after a preview. Eight integration assertions pass, including original inventory/scope/profile preservation, full plan compilation, retained ordinary approval and conflict refusal.

This is not a universal novice wizard. Opening the window alone does not deploy hosts, discover new scope, start an event or authorize repairs. It still needs the approved event profile, credentials, controller connection and relevant service prerequisites. The GUI X close action minimizes by design; the normal menu close was used for process-exit acceptance.

The Linux ZIP is desktop integration, not bundled CPython. **Python 3.11+, cryptography and Tk must already be installed**; SSH/SMB/WinRM features need their separate prerequisites. The adjacent `install-linux-launcher.py` must be kept with its shell wrapper. There is no new Windows launcher or rebuilt Python-free offline distribution.

## 8. What is not established

- **Native Windows:** no SCM, ACL, IIS, scheduled-task, domain, WinRM, Windows GUI or reboot acceptance was performed. Linux mocks do not establish it.
- **Real systemd:** enablement, native service restart, boot/reboot and restart-after-crash contracts remain unproven here.
- **37 other catalog products:** no real BIND, MariaDB, PostgreSQL, Redis, Postfix, Dovecot, SSH, DHCP, sharing, broker or other absent daemon was started and functionally checked.
- **Complete remote setup:** no authenticated Proxmox/Azure host or live remote SSH/WinRM setup was exercised. Real web checks did not cover the entire remote ledger transaction and external-observer chain.
- **Full-range reliability:** no 40-VM scaling, multi-host partition/reconciliation acceptance, full-event endurance, adversarial eviction or measured competition availability was established.
- **Every input or every desktop:** finite tests do not prove all legal desktop configurations, all failure interleavings or all application settings.

The new installer intentionally refuses unowned legacy entries and existing unsafe storage. These are visible holds, not automatic migration. Privileged cleanup or unknown state repair must not be guessed by an inexperienced operator.

**No uptime estimate is justified by these tests.** The supported conclusion is that the corrected launch path and listed local regression/application behaviors passed; general autonomous defense and universal provisioning are still broader engineering and validation goals.

## 9. Reproduction and release handling

Extract the delivered source into its own folder and keep the runtime outside or alongside it. In the source folder, with prerequisites available:

```sh
PYTHONPATH=src:tests python3 -m unittest discover -s tests -t tests -v
xvfb-run -a env PYTHONPATH=src:tests python3 -m unittest discover -s tests -t tests -v
PYTHONPATH=. python3 tools/build_defensive_release.py --output ../rebuilt
python3 tools/build_linux_desktop_bundle.py --runtime ../rebuilt/sentinel-blue-1.9.85.pyz --output ../sentinel-blue-1.9.85-linux.zip
```

The full suite launches local processes and uses temporary owned fixtures; it is not intended for an unrelated shared production machine. GUI runs require a working graphical display and test dependencies. The provided real-web harness requires its explicit disposable-fixture authorization argument. Do not run disruptive native tests on the user's restricted shared Kali pool without that environment owner's specific authorization.

Runtime-only use:

```sh
python3 sentinel-blue-1.9.85.pyz --version
python3 sentinel-blue-1.9.85.pyz desktop
```

For the Linux app ZIP, extract everything, run `sha256sum -c SHA256SUMS` in its folder and then `sh install-linux-launcher.sh`. Open the installed application entry. GNOME/KDE may still require their normal Trust/Allow Launching step; no session policy is disabled. Uninstall from the same folder with `sh install-linux-launcher.sh --uninstall` when the receipt still matches.

The source/evidence archive is private and includes implementation details. Do not publish it as though it were only the runtime. No GitHub upload was performed. Source/runtime version and digest changes must be reviewed in event profiles.

## 10. Harness corrections and excluded intermediate results

The authoritative final suite logs are `final-full-headless.log`, `final-full-xvfb.log` and `final-packaged-regression.log`. Experimental failures were retained rather than deleted, but are not silently combined with these counts.

An initial path harness inspected GLib's executable display string rather than invoking the desktop entry; it falsely treated a correctly quoted space path as broken. The final harness uses actual GIO launch and an exact-path payload marker. The asynchronous marker wait was extended from 1.2 to eight seconds after load delayed dispatch; this changed test waiting, not the production launch path.

Early GUI images were captured before mapping and were blank. Final screenshots wait for a viewable window and are approximately 49 KB; root and unprivileged fresh-HOME images show the actual application. Only these final views are included as visible-window evidence.

A first candidate suite exposed a fixture inheriting umask 077, which made its intended unsafe-directory fixture private. The fixture now explicitly establishes the intended unsafe mode. A concurrently changing launcher invocation also invalidated an old assertion; the final runs used a frozen tree and require the exact `/bin/sh` plus launcher argument.

An intermediate Xvfb suite opened a blocking Tk error dialog in a test intended to simulate no available notifier. That test had hidden only external helpers, not Tk. It was stopped; the fixture now explicitly mocks the Tk fallback and asserts it was attempted. No production fallback was removed. The final full graphical suite completed successfully.

The earlier 1.9.82 lifecycle fixes remained intact and the actual 15-cycle GUI stress found no Tcl thread errors. Simulated installer crash receipts are not represented as physical power-failure tests.

## 11. Evidence index

| Path in private evidence | Contents |
|---|---|
| `results/validation_summary.json` | Key original/corrected results and boundaries |
| `results/reproducibility.json` | Original/corrected independent rebuild and member-match evidence |
| `results/delivery_verification.json` | Delivered source/patch/runtime/ZIP verification |
| `results/final-source-freeze.json`, `final-freeze-verification.json` | Frozen final test inputs |
| `logs/full-headless.log`, `full-xvfb.log` | Original 1.9.84 supplied suite logs |
| `logs/final-full-headless.log`, `final-full-xvfb.log` | Final 1.9.85 complete suite logs |
| `logs/final-packaged-regression.log` | 175 targeted tests importing the final zipapp |
| `results/candidate-continuity-detail.json` | Exact-runtime 44-test continuity acceptance |
| `logs/candidate-smoke-*.log`, `candidate-withdrawal.log` | Current smoke/withdrawal results |
| `product/original-native_web.json`, `candidate-native_web.json` | Original/corrected 11-check web campaigns |
| `launcher/original-installed-launch.json`, `candidate-installed-launch.json` | Actual GLib path dispatch, with harmless-payload scope labeled |
| `launcher/candidate-visible-gui.json`, `candidate-nonroot-gui.json` | Exact-runtime mapped GUI and normal close |
| `launcher/negative-candidate.json` | Negative launch and ownership checks |
| `gui/` | Actual configuration handoff results and final visible screenshots |
| `results/input-contract-count.json` | Exact 8,360-call input corpus results and 39 accepted values |
| `harness/` | Independent test programs; workspace paths and environment requirements are documented |
| `historical/` | Excluded intermediate runs, not final acceptance |

Original source references: `recording.py::initialize`, `desktop.py::run`, `__main__.py::main`, `launch_report.py`, and `packaging/linux-desktop/`. Source excerpts and a complete incremental patch identify exact changes. The uploaded 1.9.84 HTML's launcher section (lines 1207-1247), prerequisites (148-197), catalog native-test status (1039-1057) and open acceptance list (2018-2038) define the reviewed claims.

Primary external reference for desktop-entry escaping only: freedesktop.org Desktop Entry Specification, *The Exec key* and *Recognized value types*. This reference is not a native GNOME/KDE acceptance test.
