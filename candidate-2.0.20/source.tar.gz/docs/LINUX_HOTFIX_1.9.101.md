# Sentinel Blue 1.9.101 — Linux corrections 26–30

This source is based on the complete offline 1.9.100 release. Retain the full
Python-inclusive ZIP; the application zipapp alone is not a self-contained system.
All earlier runtime corrections and cache-only/local-input policies remain.

## 26 — Recoverable generic service confirmation

The generic setup adapter now records authenticated applied/native-state evidence
and confirmation intent. The append-only ledger commit is the durable decision.
Only afterward does it publish native committed state and release resource claims.
Interrupted intent, decision, publication, claim release and acknowledgement have
explicit retry paths. A matching unchanged committed action is idempotent.
Current exact objects and bound lifecycle metadata are checked throughout. Missing
proof, conflicting files, changed private state and later owners are never guessed
safe. An unfinished publication blocks overlapping new setup admission.

Before the durable decision, ordinary rollback can reverse the pending action.
After the decision, complete confirmation and use Emergency Restore & Withdraw
for a deliberate inverse. Old stranded committed labels without authenticated
confirmation proof remain held. Intact older applied/committed states retain
compatibility with their existing exact ledger snapshots.

Rollback completion is recorded before publication/releasing claims. A retry can
finish a proved inverse/cancellation and retain legitimate predecessor evidence.
A partial inverse without a completion proof remains held; this is not whole-VM
rollback or automatic reconstruction of historical lost state. Independent
evidence backup includes all newly referenced state blobs.

## 27 — Exact live-object ownership in later setup phases

Copied backups still use content/security metadata comparisons, since copied
inodes differ. Live objects use authenticated file revisions as well. Confirmation
and ordinary rollback refuse externally replaced files even when their bytes,
permissions, owner and group are identical. Rollback rechecks every live object
before each inverse, after staging replacement content, and around service-control
callbacks. The long-lived withdrawal adapter passes the same authenticated exact
post-state into the native inverse. Observable outside changes hold rather than
being overwritten or adopted. No atomic compare-and-swap against arbitrary racing
privileged writers is claimed.

## 28 — Bounded, paired diagnostic handling

Collection and agent self-health use one normalization helper. Errors and source
labels are emitted together within the existing 256-entry and 256-character wire
limits. Legacy missing provenance becomes unknown. Saturation retains self-health
faults and an explicit loss witness rather than breaking telemetry validation or
mislabeling health faults as payload fingerprint evidence. Existing validators and
the existing provenance vocabulary remain strict and unchanged.

## 29 — One supervised Linux scoring process group

The scoring worker is the leader of the outer supervisor-owned session/group.
Its native clients now join that group rather than creating separate unsupervised
groups. The worker only signals its direct client; only the outer owner can signal
the whole group. One monotonic deadline passes through worker admission and native
commands. Late observations cannot become healthy results. After an outer timeout,
overflow, or unexpected live descendant at worker exit, the group is terminated
and checked for remaining executing members while the unreaped leader pins its
identity. Signal delivery alone is no longer treated as observed termination.
Zombies are stopped execution, not running clients. Incomplete drain remains an
explicit uncertain failure. Deliberate group escapes, uninterruptible kernel/FS
waits, native Windows trees, and proof of remote write rollback remain outside
these local Linux guarantees. This does not bypass client/endpoint authorization.

## 30 — Protected Linux UID normalization

A session's `uid:real:effective` evidence is compared with the independently
reviewed numeric account ID. Both IDs must match; mixed or malformed identities
remain unverified. Exact Linux username/account inventory and allowed-source
checks remain required. Authentication-event numeric IDs and Windows SID behavior
remain distinct. A matching address/name/UID is still not cryptographic proof of
a scorer/operator, and no automatic access or containment is granted here.

## Distribution and acceptance

Use Start-Sentinel-Blue.sh from the fully extracted offline Linux x86_64 ZIP.
Python/Tcl/Tk/security/transport dependencies, licenses and local build tools are
included; no system Python, pip or outside software source is required to start.
Linux/glibc/display/native administration prerequisites and approved range
networking remain as described in OFFLINE_RELEASE_1.9.101.md.

Regenerate/reapprove plans and update installed helpers deliberately; replacing the
GUI does not upgrade pending transactions. Preserve all original evidence.
Regressions use private files/ledgers/local processes plus modeled service controls;
actual native VM/service/remote acceptance is not implied. See the separately
delivered measured validation report for exact final results, including any skips
or failures. Source tests can be run from this directory with:

```sh
PYTHONPATH=.:src:tests python3 -m unittest test_linux_hotfix_19101 -v
PYTHONPATH=.:src:tests python3 -m unittest discover -s tests -t tests -v
```

For bundled tests use the included runtime/bin/python3, the built zipapp at the
front of sys.path, and the matching source test tree. Do not run development
mutation fixtures on an active production/competition system.
