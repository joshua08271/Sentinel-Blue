# Sentinel Blue 2.0.13 — selected recovery, recorded undo and repeat-recovery policy

## What this release addresses

Issue B gains an explicit Linux operator-action workflow, independent of whether an alert happens to recommend the desired action. The user selects a supported action for a named VM/service, reviews its actual effects, approves it, inspects the result and can review its recorded inverse. This is not an unrestricted shell, an invention of missing repair authority, an automatic resource-cleanup tool, or permission to ignore an unknown rollback.

Issue C gains explicit higher per-service allowances for repeated successful recovery: 15–300 seconds between attempts and 1–120 attempts/hour. The same approved limits bind controller and agent for both ordinary automatic restarts and coordinated repairs. Default limits are unchanged. The GUI saves a new, unapproved profile candidate, not a hot update to a running deployment. Failed attempts retain a 300-second cooldown and a maximum of three failures/hour; a later success does not erase previous failures. Full setup-redo retains its independent 600-second/three-per-hour policy.

Use the matching release report for measured test results. Controlled file/GUI/HTTP tests are not native daemon, real VM/reboot or competition acceptance.

## Opening and upgrading

Use the complete `sentinel-blue-2.0.13-linux-gui1-x86_64.run` inside the intended Linux host. Mark it executable in file-manager Permissions, then open it. Python/Tk dependencies are bundled; compatible native libraries, native service packages, graphical administration and network connectivity remain separate prerequisites.

An open new GUI does not upgrade controller/agents, migrate roles or install boot registrations. Reconcile pending work with the old matching runtime. Preserve the complete private state tree, including baseline/restore blobs, receipts, ledgers, agent identities, action delivery state and `service-repair-history`. Do not downgrade an archived state tree. Update controller/agents together, re-review their release hashes and use the existing approved deployment/re-enrollment workflow. Do not erase state to make new permissions or retries work.

Dedicated management remains **Start here → Dedicated management… / Join as agent…**. Its controller still belongs on a separate authorized trusted host. The new operator endpoints remain management-source-only in that mode; guests do not gain operator keys or management authority. The older single-VM workflow retains its shared-host limitation. The existing 2.0.12 dedicated-management guide remains applicable to the topology, with the current release runtime selected.

## Before selecting an action

Connect the management GUI to its matching controller. Verify fresh reports from the exact agent, not just a reachable controller. On **Services**, select the row showing the intended VM/agent and native service ID. For example, select the web VM's `web.service`, not another VM with an identically named service. Names in examples are placeholders, not services automatically present on your machine.

The service must have a confirmed manifest and approved probes. Mutating choices require a verified approved baseline, explicit `repair_service` and `rollback_service_repair` approval permissions, and a complete repair policy. Start-only deliberately uses the coordinated journaled repair engine with no file/startup changes; it does not use the old unjournaled restart receipt and pretend it can undo it exactly. A manifest permitting only a generic restart is not silently expanded.

File restoration is limited to explicitly approved configuration/startup objects, not arbitrary databases or user data. The agent needs actual repair privileges, local backups and restoration permission. The GUI does not grant these by selecting a row.

## Choose and approve an action

1. Select the VM/service on **Services**, then select **Choose action / Undo…**.
2. On **Choose action / approve**, select one choice:
   - **Run the declared service checks:** executes that manifest's probes. No configuration mutation or baseline promotion; authentication/transactions may still be exercised by probes.
   - **Start a stopped service, with a recorded undo:** available only when required approved files and startup are unchanged. If repairing files/startup is also necessary, this choice refuses rather than silently expanding its scope.
   - **Restore approved configuration/startup and recover the service:** builds the approved coordinated repair. It can stop/start the selected service, restore the explicitly listed configuration/startup objects, check declared dependencies and validate the result.
3. Select **Review selected action**. This does not queue a mutation. Read the human-readable summary and detailed bound review: VM/service, exact paths, state transition, startup effect, checks and remaining allowance.
4. Enter a meaningful **Reason**, 3–500 printable characters, such as `Restore reviewed web configuration after verified unauthorized edit`. Do not enter credentials; the reason is audit evidence.
5. Select **Approve and run reviewed action**, then confirm the target and effect. For a live high-risk action the client obtains a review-subject-bound, one-use authorization through the existing signed workflow. It does not bypass event approval.
6. A returned action ID means **queued**, not executed. Open **History / undo** and select **Refresh results** to inspect the agent's actual result. This view is explicitly bounded; truncation does not mean older history was deleted.

A review expires after 90 seconds. A changed operator identity/epoch, profile, boot, file effect, permission or state invalidates it. A newer observation of the identical plan is allowed; an old review cannot authorize different effects. Changing the selector while a review loads also invalidates that response. Reopen the dialog after switching controllers.

Duplicate approval of the same unexpired review returns the original queued ID. A full local GUI work queue is reported as not submitted and does not leave the dialog stuck. There are no automatic POST retries. After a lost reply, inspect History and reconcile uncertain outcomes instead of blindly requesting another effect.

## Undo a completed action

1. Open **History / undo** and **Refresh results**.
2. Select the specific successful coordinated repair. The **Undo** column's `Review` means it has a candidate journal, not a guarantee that applying an inverse is still safe. Double-click a row to inspect its receipt.
3. Select **Review undo of selected action**. The server checks the original agent/profile/credential, committed real receipt, transaction ID and subsequent service history, and checks current evidence. It refuses queued, failed, dry-run, interrupted or already-rolled-back work. Old generic restarts without an exact repair journal are not offered a fake undo.
4. Read the previous service state and exact paths to restore. Undo can intentionally return a service to an unhealthy before-state; it cannot recover process memory, lost sessions, database writes or arbitrary user data.
5. Enter a reason such as `Revert action <ID> after confirming its configuration change caused the observed fault`, select **Approve recorded undo**, and confirm.
6. Refresh History for the inverse action's result. The agent independently rechecks its local journal, current files/security metadata and ownership before any reversal. A teammate edit after review is preserved by refusing the undo.

This is a conservative one-action inverse, not an arbitrary rewind stack. Later completed/failed/pending service mutations can block an older undo even if the operator thinks they were harmless. Use the existing evidence-based reconciliation workflow in that case. If automatic validation already rolled back a failed action, there is no second successful effect to undo. Missing/corrupted evidence is never recreated by deleting records or recapturing an unverified baseline.

## Repeated-disruption policy (issue C)

Open **Repeated-disruption policy** in the same selected-service dialog. These controls describe a **candidate**, not the active policy.

| Field / preset | Meaning |
|---|---|
| Source event profile | Select the exact approved profile JSON for this controller/deployment. Do not select a different VM's unrelated local profile. |
| Conservative | 300-second cooldown, 3 attempts/hour. |
| Moderate | 60-second cooldown, 12 attempts/hour. |
| Repeated disruption | 15-second cooldown, 60 attempts/hour. |
| Custom values | Integer cooldown 15–300; maximum attempts/hour 1–120. No zero, unlimited, negative or Boolean values. |

Select **Review and save new policy candidate…**, inspect the before/after policy for the exact host/service, then choose a new filename. The existing profile is never overwritten. The copy is private, permission `0600`, and saved with approval marked **pending** and release approval cleared. No service/file permission, target scope, management topology or another service's budget is enlarged. A missing repair policy must first be explicitly authored and approved; the editor will not invent one.

**Saving the file does not activate it.** Review and obtain the appropriate approval, then use the existing coordinated profile/release deployment and explicit re-enrollment/migration procedures. A changed profile fingerprint must be consistently installed on controller and agents. This release does not implement a new in-place profile/identity migration or live Apply Policy API; do not replace a running profile file and assume old credentials will adopt it. Preserve the old state and action history, and verify each agent's effective policy after handoff. Where the approved workflow cannot preserve/reconcile the necessary state, keep the current budget and complete that migration explicitly rather than claiming the saved candidate is active.

The allowance counts recovery attempts in a rolling hour; it permits a larger number of verified successful attempts, not repeated unsafe failures. One failed attempt still holds for at least 300 seconds. Three failures in an hour hold until the retained failure window permits another. Unknown/in-progress outcomes hold independently. Explicit GUI repair also respects the relevant budget. Another service's history cannot consume this selected service's allowance, except genuine host-wide unreadable/oversized evidence conditions that safely hold the whole host.

A fast allowance does not remove the attacker's access. Sustained restart/repair loops can interrupt sessions and consume CPU, disk, probe and journal resources. Existing history inspection/storage ceilings are not removed, and guest-local recovery blobs are not automatically replicated to management. Choose a finite policy appropriate to the approved event and verify it in a disposable service test before relying on it.

## Holds that intentionally remain

Emergency Stop, stale or missing telemetry, revoked credentials, unapproved baselines, missing backups, maintenance grants, dependency faults, port conflicts, exhausted/read-only filesystems, memory failure, unknown outcomes and unclean rollback are not resolved by selecting an unsafe command. The existing details explain the hold. Correct/reconcile the underlying condition through a separately authorized workflow, then refresh evidence and review again. The action center improves operator choice inside supported contracts; it is not a universal repair engine.

Closing the action dialog does not cancel an already queued action. Closing the main GUI does not stop background monitoring. Use the existing Emergency Stop, Stop Monitoring, role-stop and Withdraw controls for their distinct purposes; preserve evidence throughout.
