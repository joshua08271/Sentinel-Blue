# Sentinel Blue 1.9.92 — Required VM Testing

**REQUIRES VM TESTING — NOT RUN** for every native item listed below.
Baseline: uploaded 1.9.91. This release corrects checker evidence and adds reviewed GUI port selection, not full native acceptance.

There are **19 infrastructure/lifecycle areas and 39 catalog products**. Local regression, loopback TLS, GUI and partial web tests do not replace these native requirements.

## Authorization and interpretation

Accessible shared Kali guests do not imply permission for disruptive tests. Use only explicitly authorized disposable VMs and independent observers. Do not change hypervisor settings or delete the mutation ledger.

Automatic port choices are proposed literal configuration, not proof of a free or reachable remote port. No firewall, scorer, observer or management connection is silently migrated.

## VM-L01 [P0] New probe-evidence correction on real service managers

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Disposable Linux VM, installed target service and its checking clients.

**Required evidence:** Keep a healthy service running while a test-owned client becomes unavailable or the probe worker pool is occupied. Verify unchanged systemd invocation/no stop or file write, unverified health, and an actionable missing-check result. Restore checking capacity and prove normal checks recover. Then cause an approved genuine service failure and prove normal bounded recovery still works.

## VM-L02 [P0] Complete native service setup and adoption

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Disposable supported apt-family Linux VMs plus installed product prerequisites.

**Required evidence:** For each configured product below: create/adopt, parse configuration, query effective settings, positive and denied transactions, identical reapply without restart, approved update, outside-edit preservation, failed apply after writes, native restart, rollback, and independently verified Restore & Withdraw. Adoption-only rows need adoption-specific acceptance; do not claim missing configuration adapters exist.

## VM-L03 [P0] systemd startup, enablement and reboot

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Disposable Linux VM with systemd as PID 1 and explicit reboot permission.

**Required evidence:** Verify declared unit identity and start mode, actual service transitions, controller/agent boot registration, reboots, crash restarts, late dependencies, interrupted registration and restart-after-crash. All checks use exact delivered bytes and retain controller/ledger bindings.

## VM-L04 [P0] Remote SSH deployment and enrollment

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Two or more authorized native Linux VMs.

**Required evidence:** Approved inventory -> runtime verification -> SSH deployment -> one-time enrollment -> fresh telemetry -> approved action -> application checks -> durable receipt. Exercise bad credentials, wrong host keys, duplicate enrollment, disconnection and retry without adopting untrusted identities.

## VM-L05 [P0] Independent observation and network-wide withdrawal

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** At least one target VM and a genuinely separate authorized observer.

**Required evidence:** Use actual signed/TLS observer reports and real event-profile authorization. Verify stale/missing evidence holds, review-only output is not execution, Remove preserves legitimate service changes, Restore & Withdraw restores only owned changes, and unrelated or teammate-modified objects block unsafe undo.

## VM-L06 [P0] Controller loss, offline operation and multi-host reconciliation (#17/#34)

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Multiple native agents and primary/replacement controllers.

**Required evidence:** Test lost controller, permitted bounded offline actions, lease expiry, reconnect, staggered partitions, epoch changes, stale-controller return, replay/idempotence and conflict handling. No duplicate action and no admission from stale authority. Local fixture passes are not this test.

## VM-L07 [P1] Abrupt termination, storage interruption and recovery

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Disposable native VM with approved process-kill/reboot/snapshot controls.

**Required evidence:** Exercise SIGKILL during mutation, agent/controller restart, disk-full during journal write, and separately approved reboot/power-loss cases. Preserve uncertain outcomes. The existing failed-apply-after-writes fixture does not prove hard-kill or power-loss recovery.

## VM-L08 [P1] Production load and 1/5/10/20/40-host scale (#22)

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Authorized native Linux VM pool with stated CPU/RAM/disk limits.

**Required evidence:** Measure actual systemd/journald collection, telemetry freshness, probe-pool saturation, controller queue/DB growth, recording volume, latency percentiles and repair delay. Distinguish checker overload from service failure; do not extrapolate from local unit-test speed.

## VM-L09 [P1] Full-event and extended endurance

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Explicitly authorized sustained native range.

**Required evidence:** Run declared event-length and longer campaigns with stable transaction observers. Measure successful/failed/unverified checks separately, per-service availability, memory/disk growth, cache aging, credential expiry, reconnection and accumulated action history. Do not convert unit-test pass rates to uptime.

## VM-L10 [P1] Filesystem/resource faults and existing diagnostic holds (#13)

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Disposable service-owned volume/cgroup, not the shared host root volume.

**Required evidence:** Validate actual disk/inode exhaustion, read-only mounts, memory limits, restart loops, start limits and port conflicts. Confirm holds and recovery after external cause removal. This release does not add disk cleanup, OOM killing, port eviction or reset-failed automation.

## VM-L11 [P1] Native identities, persistence and ownership protections

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Disposable Linux VM with approved test-owned accounts/jobs/units.

**Required evidence:** Verify actual cron/sudoers/systemd timer/socket/path collection and approved reversible response, protected/scoring/teammate exclusions, exact process identity, release/expiry and service effects. Validate native sudoers syntax where appropriate; generalized identity recovery is still incomplete.

## VM-L12 [P1] Measured detection and safe response (#30)

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Separately authorized isolated adversarial exercise plus independent ground truth.

**Required evidence:** Measure misses, false alarms, containment side effects, attribution limits and repeated attacker interference. Test benign teammate/inject changes alongside allowed adversarial activity. No adversarial campaign was run in this release.

## VM-L13 [P1] Cross-host application and routing dependencies

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Isolated multi-host Linux application/network layout.

**Required evidence:** Exercise DNS -> application -> database/mail/file-sharing dependencies and approved router/firewall paths. Verify true external transactions, partial failures, management connectivity, account/TLS dependencies and safe repair order. General appliance and cross-host recovery are not completed by this checklist.

## VM-L14 [P1] Distribution/version/native-permission compatibility

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Declared Debian/Ubuntu/Kali VM versions and relevant filesystems.

**Required evidence:** Verify actual package prerequisites, unit/config paths, service identities, UID/GID, ACL/xattrs, symlink handling and security policy. Non-apt provisioning is still held; RPM-family support needs implementation before native acceptance.

## VM-L15 [P2] Real desktop and privilege-boundary startup

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Unprivileged Linux desktops with installed Python/Tk/cryptography.

**Required evidence:** Verify installed launcher under the actual desktop/file manager and X11/XWayland policy, trust prompt, fresh/reused storage, missing prerequisites, recording failure visibility and clean shutdown. A graphical unit run here is not all-desktop acceptance; no new Python-free package is provided.

## VM-W01 [P1] Windows paths remain unaccepted

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Native Windows VM with explicit administrative test permission.

**Required evidence:** SCM, ACLs, IIS, WinRM, scheduled tasks, domain behavior, Windows GUI, inventory and reboot paths remain native-untested. Shared probe-evidence logic is portable Python, but Linux tests do not accept Windows. Missing Windows feature/catalog/launcher work remains separate implementation work.

## VM-L17 [P0] Queued restart and preflight freshness revalidation

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Disposable native Linux VM with systemd, test-owned service and data volume, approved action profiles and explicit fault permission.

**Required evidence:** Queue a permitted restart, then collect a newer sample reporting disabled/masked/missing/transitioning target, start-limit, OOM/resource verdict, native loop, port conflict or full/read-only business-data filesystem. Verify no start or service configuration change, a stated hold and no replay of that action. Test valid unchanged outage and independently recovered running service as positive controls. Delay checking/file preflight beyond the existing 90-second observation window: no first forward mutation may be admitted. Test changes occurring after the most recent observation separately; this release does not claim atomic native state revalidation. Retain normal rollback for already admitted work and confirm restart budgets/ledger and scope remain enforced.

## VM-L18 [P0] Local TLS checking prerequisites and unnamed probe completion

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Specifically authorized disposable native VMs, installed products and an independent observer.

**Required evidence:** On native Linux/Windows service hosts with separate observers, change only test-owned checker CA material; confirm unverified evidence and no service stop/restart/write. Restore trust and verify checks recover. Confirm actual endpoint TLS/HTTP failures still report negative evidence. Exercise unnamed and named probes through authenticated remote queue/dispatch/completion without stale action state. Preserve all trust and authorization guards.

## VM-L19 [P1] Manual/automatic port setup and client dependency validation

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Specifically authorized disposable native VMs, installed products and an independent observer.

**Required evidence:** For each editable adapter on supported disposable native products, drive the real GUI and actual remote setup: declared/default/manual ports, optional alternate suggestions, duplicate and wildcard/IPv4/IPv6 bind conflicts, socket-activation overrides, runtime listener races, effective configuration, positive/denied transactions, firewall and external clients/observers, idempotent reapply, approved updates, teammate conflicts, failed-apply rollback and Restore & Withdraw. Verify required scoring and SSH-management ports cannot be moved silently. Check BIND and Postfix parent snapshots, Dovecot 2.3 version contract, SMB multi-ports and FTP passive ranges. rsyslog is an outbound destination, not an inbound listener. This release does not migrate arbitrary client/scorer configurations or configure adopt-only products.

## All 39 catalog products

All native_tested flags remain false. Configure means configuration generation, not installation of every prerequisite. Adopt-only entries require implementation before new configuration can be claimed.

| Service | Current capability | Required evidence |
|---|---|---|
| openssh-server | configure; VM testing not run | Actual SSH login/SFTP with expected host key and protected credentials, rejected unauthorized login, and preserved scoring/management access. |
| mosquitto | configure; VM testing not run | Actual publish/consume with approved credentials and permissions, rejected unauthorized access and preserved durable messages where applicable. |
| rabbitmq-server | adopt; VM testing not run | Actual publish/consume with approved credentials and permissions, rejected unauthorized access and preserved durable messages where applicable. |
| memcached | adopt; VM testing not run | Authenticated permitted operations, explicit unauthenticated/unauthorized denial and preserved relevant data; no configuration-only auth assumption. |
| redis | configure; VM testing not run | Authenticated permitted operations, explicit unauthenticated/unauthorized denial and preserved relevant data; no configuration-only auth assumption. |
| docker | adopt; VM testing not run | Adoption of existing approved services without unauthorized relocation/redeployment; preserve volumes/images and service semantics. |
| podman | adopt; VM testing not run | Adoption of existing approved services without unauthorized relocation/redeployment; preserve volumes/images and service semantics. |
| mariadb | configure; VM testing not run | Actual scoped read/write transaction and permission denial; listener/auth/TLS effective settings; preserve existing logical data and cluster state. |
| mongodb | adopt; VM testing not run | Actual scoped read/write transaction and permission denial; listener/auth/TLS effective settings; preserve existing logical data and cluster state. |
| postgresql | configure; VM testing not run | Actual scoped read/write transaction and permission denial; listener/auth/TLS effective settings; preserve existing logical data and cluster state. |
| isc-dhcp-server | configure; VM testing not run | Lease acquisition/renewal on a specifically isolated segment, approved scopes/interfaces/reservations, and preserved leases; never broadcast onto the shared range. |
| kea-dhcp4 | adopt; VM testing not run | Lease acquisition/renewal on a specifically isolated segment, approved scopes/interfaces/reservations, and preserved leases; never broadcast onto the shared range. |
| freeradius | adopt; VM testing not run | Approved bind/ticket/authentication and denied identity, correct realm/domain dependencies and preserved accounts/privileges. |
| krb5-kdc | adopt; VM testing not run | Approved bind/ticket/authentication and denied identity, correct realm/domain dependencies and preserved accounts/privileges. |
| slapd | adopt; VM testing not run | Approved bind/ticket/authentication and denied identity, correct realm/domain dependencies and preserved accounts/privileges. |
| sssd | adopt; VM testing not run | Approved bind/ticket/authentication and denied identity, correct realm/domain dependencies and preserved accounts/privileges. |
| bind9 | configure; VM testing not run | Authoritative/recursive expected records, UDP/TCP and allowed dynamic updates; denied transfers/recursion; preserve zone files and journals. |
| dnsmasq | configure; VM testing not run | Authoritative/recursive expected records, UDP/TCP and allowed dynamic updates; denied transfers/recursion; preserve zone files and journals. |
| unbound | configure; VM testing not run | Authoritative/recursive expected records, UDP/TCP and allowed dynamic updates; denied transfers/recursion; preserve zone files and journals. |
| rsyslog | configure; VM testing not run | Actual test event delivery and correct source handling, preserved logs and bounded resource behavior. |
| dovecot | configure; VM testing not run | Authorized send/receipt and mailbox access, denied relay/login, effective TLS/identity settings and preserved existing queues/messages. |
| exim4 | adopt; VM testing not run | Authorized send/receipt and mailbox access, denied relay/login, effective TLS/identity settings and preserved existing queues/messages. |
| postfix | configure; VM testing not run | Authorized send/receipt and mailbox access, denied relay/login, effective TLS/identity settings and preserved existing queues/messages. |
| cups | adopt; VM testing not run | Authorized print/job queue operations and denied unauthorized access, preserving existing queue/configuration. |
| haproxy | configure; VM testing not run | Correct frontend/backend routing, health/failure behavior, access restrictions and TLS as required. |
| squid | adopt; VM testing not run | Correct frontend/backend routing, health/failure behavior, access restrictions and TLS as required. |
| gunicorn | configure; VM testing not run | Correct application/unit identity, served application transaction, process user/environment and dependency readiness. |
| php-fpm | adopt; VM testing not run | Correct application/unit identity, served application transaction, process user/environment and dependency readiness. |
| tomcat | adopt; VM testing not run | Correct application/unit identity, served application transaction, process user/environment and dependency readiness. |
| nfs-server | configure; VM testing not run | Actual share/export file operations and identity/client denial, preserved contents and access controls. |
| samba | configure; VM testing not run | Actual share/export file operations and identity/client denial, preserved contents and access controls. |
| chrony | configure; VM testing not run | Correct approved time-source operation and authentication/restrictions where configured; no unapproved system-wide clock changes. |
| ntpd | adopt; VM testing not run | Correct approved time-source operation and authentication/restrictions where configured; no unapproved system-wide clock changes. |
| systemd-timesyncd | adopt; VM testing not run | Correct approved time-source operation and authentication/restrictions where configured; no unapproved system-wide clock changes. |
| proftpd | adopt; VM testing not run | Authorized upload/download/login as required, checksum and permission checks, denied unauthorized operations, and preserved data. |
| tftpd-hpa | adopt; VM testing not run | Authorized upload/download/login as required, checksum and permission checks, denied unauthorized operations, and preserved data. |
| vsftpd | configure; VM testing not run | Authorized upload/download/login as required, checksum and permission checks, denied unauthorized operations, and preserved data. |
| apache2 | configure; VM testing not run | Correct hostname/port/content and HTTPS identity, effective virtual host, exact reapply/update and failed-config rollback. |
| nginx | configure; VM testing not run | Correct hostname/port/content and HTTPS identity, effective virtual host, exact reapply/update and failed-config rollback. |

## Implementation work remains separate

- Broad root-cause remediation (#13), including start-limit/resource/port-conflict cases.
- Generalized application/identity/network and cross-host recovery.
- Full provisioners for 19 adopt-only catalog entries and reversible prerequisite installation.
- Non-apt platform contracts; Python-free current offline bundle; complete novice setup/observer workflow.

## Current release-specific emphasis

VM-L18 covers local CA failures, preflight and unnamed results on real service managers and authenticated remote transports. VM-L19 covers every newly exposed port field, native effective settings, access/transaction checks, snapshot conflicts, listener races, clients/firewalls, idempotence, rollback, IPv4/IPv6 and real desktop operation.

Dovecot port syntax is targeted at the 2.3 configuration layout. NFS kernel/RPC port management, DHCP-port reassignment, 19 adopt-only provisioners and a Windows service catalog are not silently added. rsyslog is forwarding to a destination, not configuring an inbound listener.
