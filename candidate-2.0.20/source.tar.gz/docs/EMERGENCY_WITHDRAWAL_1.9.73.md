# Emergency Remove / Restore & Withdraw — 1.9.73

The **Withdraw** tab and `withdraw` command provide a separate emergency workflow from ordinary Pause. Use the approved inventory for the entire network and run with the privileges and management credentials needed by those hosts.

| Control | Result |
| --- | --- |
| Pause | Holds new work; retains Sentinel and configuration. Existing admitted work finishes bounded validation or becomes an unresolved outcome. |
| Remove Sentinel | Pauses every declared host, inventories and copies recovery evidence, stops proven Sentinel startup registrations and processes, and removes recorded installation files and materialized credentials. Configuration changes remain. |
| Restore & Withdraw | Performs the same admission and inventory steps, reverses committed configuration actions in reverse dependency order, checks approved services from the operator machine, reports conflicts, then removes owned installation objects. |

No command restores a whole VM, imports an old machine image, recursively deletes an installation directory, or authorizes a force overwrite of a conflicting object.

## Use from the desktop

1. Select the actual network inventory and matching approved event profile in **Setup**. Include the controller and all affected agents. Set each host's `runtime` and `python` fields when using non-default installation paths or the offline interpreter.
2. Open **Withdraw**, then **Review Remove Sentinel** or **Review Restore & Withdraw**. Review pauses the declared hosts and drains admitted mutations. It does not perform inverses.
3. Read the objects, retained configuration, conflicts and recovery report path. Execute the reviewed workflow when ready.
4. Treat `held` or `partial` as unfinished. Read `result.json` and preserve the recovery directory. The report does not label an unresolved outcome complete.

**Cancel this withdrawal review** releases the special admission latch only before any inverse or startup-stop has begun, with no interrupted actions. Ordinary desktop/controller Pause remains separate; use its existing Resume control deliberately. A completed or interrupted withdrawal cannot be replayed by pressing Resume.

## Use from a separate management machine

The normal SSH/WinRM management channel carries withdrawal requests independently of the controller. Review requires every declared host to confirm Pause and drain before any network inverse is admitted. The coordinator supports up to 64 explicitly inventoried hosts and derives cross-host order from recorded dependencies and setup task receipts. An unreachable host holds execution for the network.

```console
python sentinel-blue.pyz withdraw --inventory inventory.json --event-profile profile.json --directory private-recovery-001 --mode remove
python sentinel-blue.pyz withdraw --inventory inventory.json --event-profile profile.json --directory private-recovery-001 --mode remove --approved-digest DIGEST_FROM_REVIEW
```

Use `--mode restore-withdraw` for selective restoration. Add `--range-deployment` only for an explicitly approved disposable-range profile. Both invocations use the same private directory. Keep it outside the installation paths being removed. Use the OS offline launcher in place of `python sentinel-blue.pyz` when system Python is absent.

Host inventory fields include `name`, literal `address`, `platform`, `transport`, and the existing verified SSH/WinRM credential settings. Original setup tasks and their script files are not required for withdrawal. The event profile must approve this release and its exact SHA-256. SSH host keys and WinRM server identity remain verified.

The guest default runtime is `/opt/sentinel-blue/sentinel-blue.pyz` or `C:\ProgramData\SentinelBlue\sentinel-blue.pyz`; override `runtime` for other locations. Set `python` to the host's bundled interpreter when necessary. A private helper copy survives removal of the original zipapp, so the last inverse and receipt can finish.

Restore & Withdraw uses the service manifests' expected transactions for independent health checks. Run it from a machine separate from the service hosts. Local and loopback service checks cannot satisfy external verification. If external checks fail or are unavailable, the report is held and the installation files and evidence remain. There is no automatic fallback to calling local health "external."

## Durable action evidence

The ledger writes a durable `prepared` record before admitting a supported mutation, then records its exact observed post-state and validation. Each action includes its ID, host, object identities, exact pre/post snapshots, hashes, inverse adapter, dependencies, ownership category and detected intervening modification. Writes flush immediately with file synchronization; POSIX directory updates are synchronized as well.

Events are append-only JSON lines with sequence numbers, previous-event hashes, SHA-256 and HMAC authentication. Exact snapshots are separate content-addressed private blobs. An authenticated head detects truncation; the coordinator pins heads and verifies independent recovery copies before the first inverse. Snapshot bytes, password hashes and keys never enter the ordinary redacted recording stream or public release.

Default locations:

| Host context | Ledger |
| --- | --- |
| Linux root services | `/var/lib/sentinel-blue-ledger` |
| Linux current user | `~/.local/state/sentinel-blue-ledger` |
| Windows elevated runtime | `%PROGRAMDATA%\SentinelBlueLedger` |

Use the same privilege context that owns the recorded actions. `SENTINEL_LEDGER_DIR` exists for controlled fixtures and explicit installations; changing it hides the prior history from that runtime and is not a recovery procedure. Keep active state on a local filesystem. The ledger, helper, recovery snapshots and human-review reports are deliberately retained after removal.

The packaged CLI enables mutation tracking. A direct Python-library integration must call `sentinel_blue.mutation_tracking.enable()` before invoking native mutation entry points.

An interrupted prepare, apply, inverse or startup stop is held for reconciliation. Retrying never infers ownership solely because old bytes happen to be present. A new reviewed inventory is required after an interrupted coordinator execution. A conflict also holds its dependencies, preserving other actors' state.

## Supported changes and conservative holds

- File restoration and removal preserve exact bytes and supported security metadata. File revision guards detect changed-back content, inode replacement and metadata edits. Symlinks, reparse points, ambiguous hardlinks and invalid paths are refused.
- Native service state/startup and supported persistence objects use their exact recorded snapshots. Existing narrow service, firewall, IIS/nginx and Linux router transactions feed the same ledger. IIS never restores a whole `applicationHost.config`; routing never replaces an entire machine network configuration.
- Sentinel process shutdown uses immutable native identities and native handles. A reused PID is left alone. Linux temporary suspension/resume is recorded and a completed resume closes its suspension chain.
- Recorded installer objects and materialized identity/credential files are removable when current state still matches. The saved vault, user-provided management credentials and legitimate configured services remain. Declared router boot configuration remains during Remove.
- An incomplete deployment retains private pre-state and staging evidence for review. Its failure handler no longer copies old backups over current targets without a committed ownership receipt.
- Windows password rotation and Windows process suspension/resume are held because this release has no exact reversible native pre-state adapter for those operations. Arbitrary setup runbooks, OS package/feature installation and Python installation are also held when they would mutate without an exact adapter. Already-ready checks can still succeed. Missing nginx/IIS/router prerequisites must be provisioned through a separately reviewed process.
- Pre-existing Sentinel-looking services/tasks are not adopted by name. A registration without provable creation ownership is held, including older installations and some upgrades. Old 1.9.71 rollback records are not automatically converted into complete network ownership proof.
- This is not retrospective whole-machine undo for 1.9.72. Unknown historical mutations, unsupported application/registry objects and credentials issued outside the tracked runtime remain for human review. Removal does not promise deletion of every historical log, backup, offline interpreter or unrelated file.

Native state comparisons identify detectable drift; they do not establish actor identity. File revision guards have stronger changed-back detection than service/task APIs that lack a durable modification generation. A privileged actor able to replace the local key, every event/blob and all trusted external anchors is outside the local tamper-evidence boundary. Preserve independent recovery copies and use human review when provenance is uncertain.

## Validation for this release

The private release status contains the exact regression counts and runtime checksum. Focused checks exercise actual Linux files, processes, suspension/resume, crash boundaries and concurrent appenders. Coordinator dependency and unreachable-host scenarios are deterministic two-host fixtures, not a live multi-machine acceptance test.

The built zipapp was exercised through the real local management transport: Remove completed against disposable installation/credential files while preserving configuration and a teammate file; Restore restored its exact configuration pre-state and held installation removal when independent verification was unavailable.

No native Windows, WinRM, new Tk window, real systemd/nftables or live multi-host withdrawal acceptance was available here. A disposable Linux account test could not start because `useradd` could not open the OS audit interface; no account or password was changed by that test. These are unavailable checks, not passes. Previous 1.9.71/1.9.72 Azure results remain historical evidence only.

The offline bundles preserve their prior Python, libraries and launcher bytes. The new Linux bundle runs a fresh native dependency check. The repackaged Windows bundle records its new native check as not run. Neither bundle downloads missing dependencies at startup.
