# Sentinel Blue 2.0.19 — Linux test candidate

This candidate corrects three related PID namespace defects found while testing the supplied 2.0.18 release:

- Process identity lookup could use a colliding parent-namespace PID, or confuse sibling namespaces.
- Process inventory reported procfs PIDs and parent PIDs instead of the caller-visible IDs used by process controls.
- A scoring worker could report success while a surviving client descendant remained, because process-group inspection compared IDs from different namespaces.

The shared resolver now obtains the procfs PID from a kernel pidfd for the caller's exact process. Native procfs mounts retain direct lookup. Invalid, denied, inconsistent or exited identities fail closed. The process inventory translates and verifies IDs, and owned-group cleanup uses the same resolver. No approval, credential, baseline, ownership, recovery or offline guard was relaxed.

Windows behavior and service configuration adapters are unchanged. Controller, agents and GUI must use the matching candidate. Preserve private state and follow the existing reviewed upgrade workflow; installing this file does not upgrade a running session.

The new collision controls reproduce failures on 2.0.18. The targeted corrected run completed 80 tests: 79 passed and one Windows-only test skipped, including actual child processes, process-group cleanup, session restart and isolated systemctl --root enablement/withdrawal checks. These are not live systemd daemon tests.

Native VM acceptance is still pending. Workshop-Kali-4 (currently VM 1004 on hv02) was started from its stopped state and is at the Kali guest login. The build environment lacks a graphical display and live systemd, maps only UID/GID 0, and denies netlink inventory. Its full-suite environment failures are retained in the companion test evidence; they are not counted as passes. Reboot, polkit, actual service deployment/recovery/undo, end-to-end withdrawal and endurance have not been accepted for this candidate.

The companion testing report/evidence records final local results. All older embedded validation reports apply only to their named releases. This is a test candidate, not a claim that every service works on a VM.
