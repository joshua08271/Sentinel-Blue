# Sentinel Blue 1.9.94 — acceptance and port corrections

## Status and scope

This patch follows the uploaded 1.9.93. It retains the Manual/Automatic port GUI
and earlier TLS-checker / probe-identity fixes. It corrects acceptance input and
result judging and stops automatic alternate suggestions for an existing or
unverified service. It does not provide new response actions or service adapters.
No native receipt was issued and all 39 catalog flags remain `native_tested: False`.

## Two different negative tests

`rejected_options` is optional, read-only builder-refusal coverage. A rejected port
0 or malformed option is useful evidence of validation, but setup never began.
`invalid_options` is required for native acceptance: a complete, reviewed option
set that passes both the builder and ordinary event-profile planning, changes a
watched configuration, and then fails the actual product validation after writes.
The existing write observation, failed-apply, rollback and exact preservation
requirements remain in place. A killed process/power loss is a separate VM test.

The former invalid inputs in all twenty example profiles are now named
`rejected_options`. Their `invalid_options` objects remain explicitly empty and
blocked until an operator supplies a real native case. No unsafe option is enabled
just to manufacture a failure. The examples are DRAFT, not runnable acceptances.

## Exact update contracts

Initial, approved-update, and failed-apply configurations are compiled before
service mutations. Every changed existing generated object in the update must
carry the exact preceding generated SHA-256 in its reviewed precondition. The
failed-apply inputs must similarly refer to the preceding approved-update state.
A change only to metadata is not a configuration-change test. Missing/wrong
preconditions are reported before initial apply, not silently filled or approved.

A `previous_sha256` is appropriate for a single-file pack; multi-file packs use
`previous_files`. Preserve all activation/source snapshots and expected modes.
The runner also asks the ordinary planner to validate all three staged inventories
before initial apply, then compares each execution-time digest to its prepared
plan. Changing an input or profile after planning stops the corresponding step.
This does not bypass runtime state, freshness, approval, ownership or rollback gates.

## Service transactions and denial evidence

A successful positive/effective/configuration/data-invariant query requires exit
0, no infrastructure/truncation error, and all configured output assertions.
A denied transaction additionally requires a specific positive product refusal
signature. `expect_failure: true` alone, or only the absence of a success message,
is not proof of denied access: a client that cannot connect is not evidence that
the application's authorization rules worked.

Matchers examine the named stream:

* `expect_stdout_contains` / `expect_stdout_absent`: stdout only.
* `expect_stderr_contains` / `expect_stderr_absent`: stderr only.
* `expect_output_contains` / `expect_output_absent`: explicitly combined streams.

Do not copy a generic error string as a refusal signature. Match the actual
product's denied-operation result on the intended endpoint. A version-specific
client may return zero while reporting refusal; that needs both an explicit
expected return code and specific refusal output. All native signatures require
verification on the installed product. Probe outputs can be sensitive; trusted
operator wrappers must emit bounded non-secret assertions rather than credentials.

## Secrets and trust

Known direct client-password argument patterns (including Redis, MQTT, Samba,
curl and SQL client passwords) and URL passwords are refused. Draft SSH commands
retain strict host-key verification and a reviewed known-hosts file. curl TLS
verification bypasses are not accepted. Plan display withholds recognized unsafe
arguments instead of printing the credential. The runner's command log is private,
but private logs are not a justification for putting a password into argv.

Use a protected client configuration or a reviewed credential wrapper. The drafts
name operator-supplied wrappers under `/usr/local/libexec/sentinel-acceptance/` for
cases needing credentials; those executables and credentials are NOT supplied.
The guard recognizes common forms, not arbitrary shell/wrapper behavior. Every
probe remains trusted operator code that must be reviewed for scope, output,
side effects and secret handling. This is not a general command sandbox.

JSON input is bounded to 2 MiB and rejects duplicate keys and nonfinite values.
Hash-pinned local `{path, sha256}` references are based on the file that contains
them in both plan and run modes. Target paths and literal argv are not silently
expanded or rewritten. The reviewed inventory must use proper scoped paths.

## Automatic ports for existing services

Manual mode still takes a validated literal port. Automatic mode retains the
precedence of declared event/management port, saved configured port, then standard
default. An alternate suggestion is allowed only for eligible unconstrained
services observed absent, and requires fresh complete listener data. A service
reported installed/running/unknown does not qualify as a new listener merely
because its options omit a port. The GUI passes its selected host's presence
information into the resolver. Missing or invalid presence is not proof of absence.

This does not discover an existing server's effective port. When no required or
saved port exists the default is only a proposal, not a claim about current live
configuration. The UI does not change a host until the ordinary setup plan is
reviewed and approved. Listener information is advisory, not a reservation; verify
bind addresses, firewall, management, dependent clients and external scoring checks
on the actual host. No random post-approval port selection or broad scanning occurs.

## Native requirements are still pending

Use matching 1.9.94 source/tools and runtime. `--plan` is a nonmutating template plus
structural blockers; successful printing is NOT native acceptance or proof all
required inputs exist. `--run` continues to require an explicitly disposable
supported Linux host, root, systemd as PID 1, exact source/runtime identity, approved
event profile, installed prerequisites and a genuinely independent verifier.
No guard is bypassed to run in a container. Do not execute the mutation suite on a
shared range under a merely 'do not break anything' permission.

All twenty native failed-apply examples, precise updated-file pre-states and
observer wiring still require lab-specific completion. Some draft data queries
and denial signatures also require product-specific replacement. Remaining
implementation limitations include adopt-only provisioners, package installation,
unknown-fault repairs, identity/network breadth and full novice deployment.
Testing alone cannot create those features. See the measured validation report;
unit counts must never be converted to competition availability.
