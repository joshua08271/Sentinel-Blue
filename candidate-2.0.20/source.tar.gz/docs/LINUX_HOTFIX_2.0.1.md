# Sentinel Blue 2.0.1 — Linux corrections 31–36

Successor: 1.9.101. Full offline Linux x86_64 distribution retained. No outside
software source is needed by the launcher or local builder. See OFFLINE_RELEASE_2.0.1.md.

## Changes

31. Locked read-only setup admission (existing token/resource claims, missing files,
and reviewed previous hashes) precedes ledger prepare. The native executor repeats
the checks after durable prepare and compares exact admitted state. Later races and
unknown outcomes still remain held; no old uncertain history is deleted.

32. Native scoring workers use isolated Python (`-I -B`) before interpreter startup,
with explicit intended module paths and no inherited PYTHON* variables. Bundled
Python, native deadline/group supervision and local dependency policy are retained.

33. Service-name indexing follows the monitored host platform: case-sensitive on
Linux/unknown platforms, case-insensitive on Windows. Capitalization does not merge
simultaneous Linux units. Account indexing is unchanged by this correction.

34. POSIX integrity fingerprints include mode, UID/GID and bounded extended
attributes (ACLs, labels/capabilities included), using a canonical schema shared
with approved restoration. Attribute access errors/changes or limits reject the
sample with incomplete-coverage diagnostics. Content/metadata stability is checked
on the same descriptor; timestamps/inodes are not security-policy digest inputs.
Legacy missing fingerprints require explicit baseline review; no historical
metadata change is inferred, and unavailable current security holds restoration.

35. Failed/timed-out/malformed interface queries retain diagnostics and mark the
name/hostname fallback as partial. Interface/address caps, invalid/duplicate records
and provider stderr report incomplete coverage. A successful empty inventory is
not replaced by fabricated native address mapping.

36. Collision evidence retains protocol, address and family. Confirmed overlapping
local endpoints require ownership/bind review. Different loopback addresses and
unknown IPv6 dual-stack/unspecified-family evidence remain advisory, not proof that
a restart cannot bind. Existing bounded approval, probe and rollback gates remain.

## Versioning and safe migration

This is a release renumbering, not a new ledger format or native certification.
Retain historical schema identities, action evidence, installed helper references,
and catalog native-test flags. Reapprove runtime hashes and regenerate plans.
Do not use a fresh ledger to evade unresolved ownership. Existing pending helpers
are not updated by replacing the GUI. No existing deployment was modified here.

## Validation scope

Tests and the separate delivery report distinguish actual private files, ACLs,
loopback sockets, inert native subprocesses and append-only ledgers from modeled
service/provider/health calls. Source and exact offline-runtime regressions are
provided. Counts and final outcomes are recorded in the delivered evidence, not
assumed from previous versions. Native boot, multi-host/VM and competition testing
are separate acceptance work. No universal correctness guarantee is implied.
