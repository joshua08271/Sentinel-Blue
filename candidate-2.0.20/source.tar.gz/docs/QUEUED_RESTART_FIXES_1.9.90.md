# Queued restart revalidation — 1.9.90


**Queued automatic restart revalidation.** The agent now checks the latest
available observation of the target, not only the original dependency guard.
A target newly reported disabled, masked, missing/ambiguous, transitional,
start-limited, memory/resource-failed, looping, or blocked by a declared port or
required-data filesystem causes the old restart to be held for a fresh diagnosis.
The agent uses the approved manifest, including required business-data paths.
The executor independently checks target facts available in its file/probe guard.
No startup policy is changed and no restart-futility safeguard is removed.

An unchanged legitimate outage retains the existing approved restart path. An
already running target is validation-only; a historical native failure result
is not treated as a reason to restart it. A target that stopped after the latest
running observation requires a new diagnosis instead of silently rebinding the
old action to a new outage. Refused envelopes keep the existing replay tombstone.

Freshness is also rechecked after dependency/file preflight and after fresh local
repair probes. A guard that expires while those operations run cannot admit a
new forward repair. Already admitted transactions retain existing validation and
rollback behavior; this is not cancellation of all work at an arbitrary deadline.

**Testing boundary:** local regression fixtures exercise profiles, real SQLite,
action journals and temporary files; service-manager and final service-validation
calls are mocked in the queued-action replay. No real VM/native service was
accepted. Latest telemetry is not a fresh native service-manager snapshot and
cannot reveal changes that have not yet been collected. No new guard/wire schema,
baseline restart-counter binding, or universal atomic race-proof operation was
added. The original controller still validates baseline-relative restart counts.

**REQUIRES VM TESTING — NOT RUN:** see `docs/VM_TESTING_REQUIRED_1.9.90.md`
and its JSON companion, especially VM-L17. All 39 catalog flags remain false.
Use the matching source and runtime, deliberately review the release version/hash
in event profiles, and never erase ledgers or change acceptance flags to bypass
holds. Linux desktop packaging still requires installed Python 3.11+, Tk and
cryptography; startup/recording and the launcher are unchanged.

