# Sentinel Blue 1.9.67 history storage

The controller now archives eligible history before removing it from SQLite. An archive is written privately, flushed, authenticated and verified before the database commits its deletion. Failed writes roll back pending deletions. A bounded receipt catalog detects missing or changed committed archives. Interrupted archive expiry is recovered on startup.

| Controller setting | Default | Meaning |
| --- | --- | --- |
| --retention-days | 30 | Age for ordinary history expiry; active evidence can remain longer |
| --database-max-mib | 512 | Database page ceiling; new telemetry pauses before it is reached |
| --history-minimum-online-seconds | 3600 | Minimum age for archiving routine observations and surplus occurrences under pressure |
| --history-archive-max-mib | 1024 | Maximum owned archive storage |
| --history-archive-max-files | 256 | Maximum retained archive files |
| --history-archive-days | 90 | Maximum archive age, subject to earlier byte/count expiry |
| --backup-max-mib | 2048 | Recovery bundle storage budget |
| --backup-keep | 96 | Backup count target; the latest two and anchored latest bundle remain protected |
| --storage-minimum-free-mib | 256 | Free-space reserve; archival and backup creation require additional working space |

Use a local filesystem for the active database and its WAL/SHM files. Do not run the live database from a synchronized folder or a network share. Copy completed authenticated backups and archives for external retention; do not synchronize a changing SQLite file. SQLite documents the same-host requirement in its [WAL documentation](https://sqlite.org/wal.html). The local shared-workspace test had an integrity failure that was not reproduced on either Azure VM or in an unsynchronized local directory; its underlying cause has not been conclusively established. The reusable test runner therefore defaults to local OS temporary storage.

History defaults to a private directory beside the recovery anchor, named `<anchor>.history`. Recovery bundles remain in `<anchor>.backups`. The database, output directories, signing key and other authority inputs must have separate paths.

Current agent observations, pending telemetry derivatives, unfinished action evidence, first/latest alert lineage, live learning labels, baseline promotion dependencies, valid current capture receipts, and current-credential boot replay fences stay online. Closed, aged evidence graphs are archived in dependency order. Unresolved evidence quarantine blocks affected expiry. Active evidence can prevent reclamation; the controller then reports pressure and pauses telemetry admission instead of silently discarding it. Other active state and non-history writers still require capacity planning.

Admission pressure returns an authenticated HTTP 503 with `retain_telemetry=true`. Agents retain and retry the queued sample using their existing bounded spool and retry behavior. This does not make an agent spool infinite: the separate sampled telemetry and spool-loss limitation remains open. Database usage, reusable pages, WAL size, archive and backup bytes, counters, warnings and maintenance time are available in dashboard storage status. The desktop Services view also shows storage health.

The archive policy is finite. Once an owned, authenticated archive exceeds the selected age/count/byte limits it is deleted through a recorded expiry transition; cumulative expired-record counters survive. Retain an independent forensic copy before that window closes when longer history is required. Unrecognized files are counted against the budget and are never deleted to create space. Archives authenticate their contents but are not encrypted; filesystem privacy and control of the recovery signing key remain necessary.

To inspect one archive without importing any execution or learning authority:

```sh
python sentinel-blue.pyz history-verify --archive /private/history/example.sbhistory --recovery-key-file /private/recovery.key --output /private/verified-history.json
```

The output must be a new file. Archived SQL JSON fields retain their original stored strings. This forensic export is not a database restore or model-training input.

New databases use incremental page reclamation. Older databases reuse freed pages without necessarily shrinking the file. Stop the controller and supervisor before explicitly compacting an existing database:

```sh
python sentinel-blue.pyz history-compact --database /private/controller.db --recovery-anchor /private/recovery.anchor --recovery-key-file /private/recovery.key
```

Compaction requires the exclusive controller lock, valid authenticated recovery state and enough disk for a complete rewrite. It preserves the database recovery identity and verifies recovery again afterward. It can take longer on large databases. Backups authenticate live controller state; historical archives remain separate forensic files and must be retained separately when needed.

The automated storage exercise uses small explicit test budgets (32 MiB database, 16 MiB archives, four archive files, 128 MiB backups, 60-second minimum online age). Its load uses synthetic process lists for eight identities against a real packaged TLS controller and real filesystem. Actual elapsed runs are measured; they do not claim to represent a multi-day event or eight independent machines. Native Linux and Windows results and final runtime hashes are recorded in the accompanying validation report.

The controller recovery commands do not provide automatic restore. A verified backup is evidence of authenticated contents, not proof that it can immediately replace live state. Offline restoration must reconcile protected recovery authority. It must also account for the archive receipt catalog: an older backup can reference archives that have since expired, and missing catalogued archives currently block history startup. Keep required matching archives and a reviewed reconciliation procedure for disaster recovery. This remaining workflow gap is tracked as issue #34.
