# Sentinel Blue 1.9.68 range recording

The desktop, controller and agent now record local structured evidence automatically. Recording never calls ChatGPT, Azure or another external AI service. Profile approval, setup prerequisites and action permissions still apply. Recording does not create missing inventory, credentials or unrestricted repair authority.

## Range workflow

1. Extract the approved script and open it in your native Windows or Linux desktop. Prepare the event inventory, approved profile and controller connection as before.
2. On Session, press **Start**. An already active session is reused, so repeated clicks do not create competing recordings. If a reviewed setup plan is loaded, the existing setup approval flow starts that plan. Otherwise the existing configured defender continues running.
3. Minimize the window while working. Agents, controller and detached setup jobs keep recording without a terminal. Closing the window preserves background defense and its recordings. A window by itself does not deploy absent agents.
4. Press **Stop & save** at the end. Copy the single `Sentinel-Blue-session-<id>.zip` shown in the window, under `Sentinel-Blue-recordings` beside the script, to your laptop. Upload that ZIP here after the range. Stopping recording does not stop defense.

When the controller cannot be reached, Stop & save preserves a local-only ZIP and explicitly reports the missing controller export. Its remote recording may still be active. Reconnect to recover the controller's evidence. A single host's UI cannot retrieve undelivered data from disconnected remote agents.

## Evidence contents

The portable ZIP contains a `session.json` index and one or two verified recording ZIPs. Each recording contains `manifest.json`, a hash-chained `events.jsonl` timeline, and `READ-ME.txt`. If UI/setup and controller use the same local journal, the duplicate session is included only once.

Events include local host observations before delivery, accepted controller observations, queue and delivery sequences, collector timing/errors, setup stage progress and completion, opening stage progress, security operation outcomes, action dispatch/results, governance request results, operator setup approval, audit records, periodic controller snapshots, runtime log source locations and template fingerprints, and component heartbeats/start/stop.

Audit writes inside a larger transaction are explicitly labelled pending; only a later committed state establishes the outcome. Runtime logs retain source location, severity, exception class and a static template fingerprint, without interpolated messages. This helps correlate failures with the matching script source while excluding arbitrary log content.

Every new event carries its source version and runtime checksum, so a source remains identifiable across weekly session changes. The manifest records session/build identity, times, event counts, byte/event limits, omitted values, known dropped events, process-local and reported cross-process storage errors, source intervals, heartbeat gaps, clock reversals and controller observation-sequence gaps. A hash chain and whole-stream hash detect corruption, truncation and inconsistent transfers. They do not authenticate evidence against a privileged attacker who can replace the journal and every hash.

## Privacy and coverage

This is sampled, bounded host and controller evidence. It is not a packet capture, keylogger, screen recorder, complete application log collector, or proof that every event on the network was observed. Uninstrumented services, changes between samples, inaccessible event logs, remote agent outages and machine-off time remain possible gaps.

Passwords, tokens, vaults, private keys, command contents, environment variables, raw output and unstructured log text are excluded before journal writes. Known structured names, paths, account identities, addresses, file hashes and service/probe states remain in the evidence. Treat exports as private. They are never included in the public script release.

Existing collectors can report empty data without diagnosing every permission failure; the recorder preserves the evidence supplied by those collectors and cannot manufacture missing events. Agent spool loss counters now survive restarts, but full collector loss accounting remains a separate improvement.

## Durability and limits

The journal uses local SQLite WAL with full synchronous commits and a bounded two-second wait for concurrent writers. Active sessions resume after a component crash; stopped sessions stay stopped until Start explicitly creates another session. A process-wide and operating-system export lease prevents competing publishers from replacing a newer snapshot with an older one. Automatic ZIP snapshots share one schedule across all components. The minimum spacing is 60 seconds after completion; it adapts to the previous export duration up to 15 minutes to reduce repeated compression work. Component exit follows that same schedule; explicit Stop forces the final export. Each exporter snapshots committed rows while collection continues. The journal survives a lost automatic ZIP snapshot; an unclean exit can leave the portable ZIP behind by the current adaptive interval and any in-progress export time. The committed journal is the recovery source.

Defaults bound unarchived journal events to 250,000 and their encoded data to 512 MiB per recording directory. On a later Start, the previous stopped recording is finalized and fully verified, then its journal rows are replaced transactionally by an archive receipt. The existing ZIP is retained unchanged and SQLite pages can be reused by the next session. A damaged or unverifiable ZIP prevents reclamation and preserves the original journal. SQLite/WAL, old portable exports and a temporary export require additional space. A 64 MiB free-space floor prevents new event writes, and export requires enough space for an atomic copy. Collection lists are capped at 1,024 items, nested structures at 12 levels and events at 256 KiB. When an observation exceeds the byte budget, health and action fields are prioritized and larger inventory collections are shortened with explicit omitted-item counts. Quota drops and sanitization omissions are reported explicitly. Complete storage failure and collector blind spots remain subject to the limits below. Previous verified ZIPs remain on disk until the operator preserves and removes or moves them. The total disk space used by accumulated ZIPs still needs management; the free-space floor protects the host. A single session can still reach its event/byte quota. The recorder is independent of controller history pruning.

Recorder storage failures do not stop defense. Failures are visible in status and subsequent manifests; if storage is completely unavailable and the process then crashes, the in-memory write-failure count itself may be lost. The missing heartbeat interval remains an evidence gap. Use a local, unsynchronized filesystem for active state.

The default controller recorder is beside its database, and the default agent recorder is inside its state directory. Components launched by the desktop inherit its local recording directory; standalone services otherwise retain their own journals. Explicit `--recording-directory` is supported for controller and agent. Automatic local recovery ZIP paths are shown when Start is used.

## Offline verification and recovery

`python sentinel-blue.pyz recording-inspect --bundle <session.zip>` verifies the entire portable file, including each nested recording, without extraction, execution, training or restoration.

`python sentinel-blue.pyz recording-export --directory <recording-directory> --stop` recovers and finalizes the current local journal after a crash. Omit `--stop` to export a snapshot of an active recording. Inspecting evidence never authorizes actions or imports model training data.

The public script remains immutable during recording so its approved checksum stays valid. Copy the session ZIP shown by the UI, rather than copying only the unchanged script.

## Validation

Validation is in progress. Final measured results and known limits will be recorded in the release status and private evidence bundle. Do not treat this working document as proof of completed native acceptance.
