# Sentinel Blue 1.9.92 — port controls and review corrections

## What is delivered

This release is based on the uploaded 1.9.91 runtime. It corrects R91-01 through
R91-04 and adds a **Ports: Automatic / Manual…** dialog in Service setup. It does
not create a universal application installer or grant additional action authority.
The Linux launcher, auto-recording behavior and event-approval workflow are retained.
The runtime still needs Python 3.11+, cryptography and Tk; native service and remote
transport prerequisites are separate. All 39 catalog native_tested flags remain false.

## Using the port controls

Select a host and service in **Service setup**, then press **Ports: Automatic / Manual…**.
Each configurable connection has a labeled numeric box and Automatic/Manual selector.
Multiple mail listeners and FTP control/passive-range endpoints have separate rows.
The dialog scrolls on smaller screens and keeps Save/Preview/Cancel accessible.

**Automatic** chooses, in order: a matching loaded event or SSH-management requirement;
a value already saved in the selected service's configuration; otherwise the standard
value. This is not discovery of arbitrary existing daemon configuration. The displayed
number and explanation are the actual proposed value. **Manual** accepts an integer
from 1 through 65535 and refuses a conflicting required event/management value.

The optional alternate checkbox only applies to a new, unconstrained eligible primary
listener whose standard port appears occupied or conflicts with another selection.
It requires recent, complete, bounded telemetry from the selected host and searches a
fixed candidate range 20000–29999. It does not perform an active scan. It does not
silently relocate SSH, DNS, NTP, SMB or SMTP, and never moves an already configured or
required endpoint automatically. Missing/stale data cannot establish availability.
The suggestion is advisory: no remote socket is reserved and native bind races remain
possible. A failed bind must not cause a different unreviewed port to be selected later.

**Automatic for selected…** assigns declared/configured/default values to the selected
editable services without enabling alternate selection. Fixed/export-only/adopt-only
entries keep their current configuration and state the reason. It does not select or
start every catalog service.

Save stores choices in the open GUI session; export or merge persists the final literal values. Reopening a saved inventory does not randomly choose new ports. Complete any missing service parameters with **Configure selected
service…**, merge into a new inventory copy, then use ordinary **Setup review and approval**.
The port dialog does not require JSON for numeric ports, but other application parameters
are not yet a universal beginner wizard. Missing snapshots, certificates, content, account
settings or prerequisites remain blocking requirements rather than invented defaults.
Host selections have separate in-session configurations. Switching hosts or changing the
underlying parameters while a port dialog is open prevents a stale save.

## Port coverage

The following table describes generated configuration fields, **not native acceptance**.

| Catalog service | Editable port fields | Boundary |
|---|---|---|
| nginx | Web/HTTPS listening port | One selected site listener; complete content/TLS options still required. |
| apache2 | Web/HTTPS listening port | Existing listener required unless manage_listener is explicitly reviewed. |
| openssh-server | SSH/SFTP port | A configured remote SSH management port cannot be migrated by this GUI. |
| mariadb | Database port | Existing application/data/account requirements unchanged. |
| postgresql | Database port | Explicit supported cluster and TLS/authentication inputs still required. |
| redis | Redis port | Existing hash-pinned ACL/authentication guards remain. |
| gunicorn | Application port | Generated unit and application configuration still required. |
| haproxy | Frontend port | Backends retain their explicitly configured individual ports in advanced parameters. |
| mosquitto | MQTT listener port | Authentication/TLS prerequisites remain. |
| unbound | DNS TCP/UDP port | Clients must use the same declared DNS port. |
| dnsmasq | DNS TCP/UDP port | Does not reassign DHCP client/server ports. |
| bind9 | DNS default listening port | Requires an exact listener_config snapshot; explicit mismatched listen-on ports are held. |
| chrony | NTP server UDP port | Existing access configuration still controls whether a server listener is available. |
| postfix | Selected SMTP listener port | Requires exact master_config snapshot; no silent submission/smtps activation. |
| dovecot | IMAP, POP3, submission and their TLS variants | Rows follow enabled protocols/TLS prerequisites; generated layout targets Dovecot 2.3. |
| samba | Direct SMB and NetBIOS-over-TCP ports | Updates smbd ports, not all NetBIOS discovery/broadcast mechanisms. |
| vsftpd | FTP control port and passive-range start/end | Ordered range, at most 1024 ports, no overlap with control; explicit approved configuration required. |
| rsyslog | Forwarding destination port | This is an outbound remote destination, **not an inbound log-server listener**. |

Thus 18 catalog entries expose numeric controls: 17 inbound-service configurations
and one outbound forwarding destination. The other 21 entries consist of 19 adopt-only
entries, the ISC DHCP adapter (ports retained by this implementation), and the NFS
export adapter (kernel/RPC listeners are outside its current contract). A service's
software may support additional port layouts; this does not mean Sentinel has a reviewed
adapter for all of them. Disabled controls explain that distinction.

### Required parent snapshots

BIND `listener_config` is a local reviewed `{path, sha256}` snapshot of the target's
`/etc/bind/named.conf.options`. The merger modifies a single unambiguous options block,
preserves unrelated text/ACLs, and refuses mismatched explicit listen-on ports or
unresolved included options. Zone/include handling and preserved data retain the existing
contracts. The target must still match the snapshot before mutation.

Postfix `master_config` is a `{path, sha256}` snapshot of `/etc/postfix/master.cf`.
Only one selected existing smtpd inet service is changed (default selector `smtp`, or
an explicit prior numeric `smtp_listener`). Continuation lines and other services are
preserved; conflicting named/numeric listeners and unresolved symbolic layouts are held.
The existing hash-pinned `main_config` snapshot is also still required. New port support
does not authorize an open relay or enable an unrelated submission service.

## Event, network and management safety

The port dialog reads matching manifests from the current inventory/profile. The normal
setup compiler also checks the selected literal ports against the approved service
manifest and recognizable local transaction ports. The event profile is **not rewritten**.
A manual disagreement is held for explicit review of the requirement and associated
checks. The source of truth is the event's real requirements, not an arbitrary new GUI value.

No firewall rule, external observer, scoring engine, client, backend or management
connection is silently rewritten. This release does not deliver an atomic cross-host
port migration. A remote SSH change that would invalidate the management connection is
blocked. Prepare and independently validate any permitted network/client migration.

Conflict detection is conservative and uses protocol/port pairs, not complete virtual-host,
wildcard or socket-activation ownership. Explicit distinct configured web/DNS ports may
resolve catalog conflicts; other role conflicts remain held. Native startup/configuration
checks and ordinary rollback remain essential. A telemetry snapshot is not proof that the
same port will still be free when the reviewed plan eventually executes.

## Review defects corrected

**R91-01:** local checker trust failures now raise ProbeUnavailable and produce
executed=false/unverified. Recovery preflight checks local TLS prerequisites before
service changes. The hash-checked bytes are loaded directly into the SSL context.
Actual server certificate/handshake, connection or HTTP failures remain negative evidence;
TLS verification is not disabled as a workaround.

**R91-02:** controller success validation uses the same name-or-target identity matcher
as the probe executor. Unnamed valid results can complete; wrong targets, duplicates,
missing results and unexecuted success claims still fail.

**R91-03:** malformed top-level deadline parameters and nested transaction lists are
controlled ValueError refusals. This is internal hardening, not a demonstrated remote
vulnerability correction or a proof against every possible invalid input.

**R91-04:** current descriptions distinguish robustness sweeps (no unexpected exception)
from required-negative tests. Some valid/irrelevant original sweep values are admitted.
The old 'every malformed shape rejected' wording is not a valid blanket acceptance claim.

## Testing boundary

The matching validation report records actual commands/counts. Real local TLS tests use
loopback servers and temporary certificates; GUI tests use real Tk under Xvfb. Native
service controls in repair fixtures are explicitly mocked. Configuration generation and
shell parsing are not daemon acceptance. Read `VM_TESTING_REQUIRED_1.9.92.md` for the
19 environment/lifecycle areas and all 39 product acceptance requirements still pending.
Do not run a mutation suite on the restricted shared Kali pool without specific permission
for disposable native testing. No remote VM or account is accessed by these local tests.

## Primary documentation consulted for configuration semantics

* Python SSL: https://docs.python.org/3/library/ssl.html
* BIND options/listen ports: https://bind9.readthedocs.io/en/v9.18.50/reference.html
* Unbound configuration: https://unbound.docs.nlnetlabs.nl/en/latest/manpages/unbound.conf.html
* dnsmasq port: https://dnsmasq.org/docs/dnsmasq-man.html
* chrony port: https://chrony-project.org/doc/4.6/chrony.conf.html
* Dovecot 2.3 listeners: https://doc.dovecot.org/2.3/configuration_manual/service_configuration/
* Samba smb ports: https://devel.samba.org/samba/docs/4.20/man-html/smb.conf.5.html
* vsftpd control/passive ports: https://security.appspot.com/vsftpd/vsftpd_conf.html
* Postfix inet service names: https://www.postfix.org/master.5.html

These references do not replace native product acceptance; version-specific differences
remain in the VM checklist.
