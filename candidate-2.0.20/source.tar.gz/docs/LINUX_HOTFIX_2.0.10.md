# Sentinel Blue 2.0.10 — SB209 corrective release

This release addresses the five findings in the independent review of 2.0.9. It is a replacement build, not an in-place VM change.

## Corrections

### SB209-01 — retention preserves unreadable repair authority

`Store.redo_evidence_pins_locked` reads both stored parameters and result and calls the same `_redo_classification` used by live governance. Malformed JSON and non-object values remain pinned through archival and direct pruning even when the result otherwise reports a clean rollback. Valid clean rollbacks still age out. Verified-recovery receipts, original evidence and pin-overflow fail-closed behavior remain intact. No schema migration or deletion of records is required.

### SB209-02 — valid BIND zone header

Generated DNS zone files use a dedicated semicolon-prefixed ownership banner. Other configuration formats retain their existing hash-prefixed banner. The change is confined to the zone-file generator; existing user zones are not rewritten. RFC 1035 section 5.1 specifies this syntax. Regenerate and review a new setup plan before deploying newly generated zones; an old approved digest must not silently authorize changed content.

### SB209-03 — service-scoped manual redo

Manual redo excludes services with live holds, in-progress repairs, unsupported setup tasks, or other hard holds. It can launch unrelated covered services, records exclusions in private redo history and recording events, and displays their reasons in Recovery. If every candidate is excluded it launches nothing and explains why. There is no wildcard fallback for an empty selection. The fresh authenticated controller check and worker dependency expansion are unchanged: shared or host-level dependencies can still correctly hold an otherwise service-scoped request. Manual operator requests can override scheduler timers, never governance.

### SB209-04 — per-service hourly budget

The hourly budget uses the same `_history_covers` membership semantics as the short cooldown. Attempts for unrelated services no longer consume the allowance. Batch membership, legacy unscoped wildcards, explicit wildcards, expired history, and network host/service identity are covered by regressions. The existing legacy test asserting a global cap was updated to exercise three attempts for the same service; its safety-limit assertion was retained. Hourly timer holds have a typed marker so manual admission no longer relies on substring matching of a reason.

### SB209-05 — wheel includes Windows transaction helpers

The setuptools package-data list now includes `*.ps1`. The wheel test builds a disposable source copy with no index or dependency downloads, compares both helper resources with the source, then imports that wheel and compiles a Windows transaction. No PowerShell/native Windows action is executed. Windows source support remains included; this is not a Windows standalone installer.

## Verification and boundaries

New tests are in `tests/test_linux_hotfix_210.py`. They exercise private SQLite/files, signed loopback controllers, history maintenance, generated zone parsing, the GUI completion callback and a real built wheel. Native workers are inert in the redo fixtures. Optional `named-checkzone`, dnspython and wheel-builder checks skip explicitly when prerequisites are missing.

The release validation report records actual command results and omissions. Historical reports packaged with earlier builds are not current-build acceptance. A unit/regression pass does not establish real service rollback, desktop privilege elevation, reboot behavior, remote deployment or competitive uptime.

## Upgrade precautions

Preserve private ledgers, backups, receipts, keys, baselines and unresolved-conflict evidence. Stop/reconcile pending work using its matching old runtime before replacing components. Do not remove failure history to clear a hold. This patch prevents future unsafe retention; it cannot reconstruct evidence already pruned by a previous version. An archive or independent backup may require operator review, not automatic reimport.

Transfer the complete `.run` into the Linux guest, not the hypervisor. Mark it executable and open it as with 2.0.9. Use the GUI's normal administrator workflow when needed. Review/reapprove controller and agent version/hash together and regenerate approved setup plans. A newly opened GUI does not silently replace running agents, old extracted directories or boot registrations. Native server packages remain prerequisites; the offline application runtime is bundled without downloading replacements.

## Reference specifications

- RFC 1035 section 5.1: https://www.rfc-editor.org/rfc/rfc1035.html#section-5.1
- Setuptools data-file configuration: https://setuptools.pypa.io/en/latest/userguide/datafiles.html
