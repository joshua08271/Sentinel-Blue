> Historical 1.9.99 review. Corrections and current limits are documented in LINUX_HOTFIX_1.9.101.md.

# Sentinel Blue 1.9.99 — Fifth Linux review

## Result and boundaries

**Five additional findings were reproduced (LINUX-26 through LINUX-30). This was review only: no release patch or new version was produced.** Priorities are engineering triage, not CVSS scores. The exact source and packaged runtime reproduce every reported issue.

Private local fixtures exercised generated shell/file changes, mutation ledgers, process execution and agent spooling. Service-manager commands, login peers, provider observations and host-health conditions were modeled. No native service, firewall, route, account, cloud or remote host was changed.

Runtime SHA-256: `4809dd08afb7e4ffcfa662b4354ab1b192c7d2f325b61e1b3edbc9d6c21f61dc`. All 118 packaged source members match; the additional zipapp entry-point wrapper is not a source module. All 114 source Python modules parse under Python 3.11 grammar. Execution used 3.13.5 (main, Jul 15 2026, 20:25:40) [GCC 14.2.0]. All 324 original archive files are unchanged; the Linux ZIP passes integrity and contains the same runtime.

## Findings at a glance

| ID | Priority | Issue |
|---|---|---|
| LINUX-26 | High | Generic Linux service confirmation can strand native committed state with an applied ledger action |
| LINUX-27 | High | Later Linux setup rollback/confirmation ignores a changed file revision |
| LINUX-28 | High | Appending agent self-health errors breaks telemetry provenance/count validation |
| LINUX-29 | Medium | Nested native scoring clients outlive cancellation of their worker |
| LINUX-30 | Medium | Linux process UID-pair strings cannot match numeric protected-account guards |

## Measured tests

| Group | Run | Passed | Skipped | Failures / errors |
|---|---:|---:|---:|---:|
| Final full headless source suite | 1696 | 1667 | 28 | 1 / 0 |
| Prior issue-1–25 regressions, exact runtime | 307 | 307 | 0 | 0 / 0 |
| New desired-correctness assertions, source | 7 | 0 | 0 | 7 / 0 |
| New desired-correctness assertions, exact runtime | 7 | 0 | 0 | 7 / 0 |
| Isolated source rerun of failed cleanup assertion | 1 | 1 | 0 | 0 / 0 |

**The full source suite is not clean.** Its existing `test_linux_hotfix_1998.BoundedNativeClients1998.test_descendant_outliving_leader_is_stopped_on_overflow` failed its immediate exited/zombie-state assertion at test line 524. It passed in the exact-runtime retained group and in a subsequent isolated source invocation. Root cause remains unestablished. This is recorded separately, not counted as a sixth confirmed finding and not conflated with the distinct nested-group marker reproduction.

All seven new assertions fail with assertion failures (no test errors): two cover separate commit/rollback manifestations of LINUX-27 and two cover provenance/count manifestations of LINUX-28. Those failures expose current defects, not passing corrected behavior. Groups overlap. Full-suite skips require graphics, native Windows or native systemd. Runtime campaign module origins were checked; no `sentinel_blue` module leaked from the neighboring source tree.

## LINUX-26 — Generic Linux service confirmation can strand native committed state with an applied ledger action

**Priority:** High.

**Locations:** `src/sentinel_blue/setup_linux_transaction.py:311–322`; `src/sentinel_blue/setup_linux_transaction.py:364–370`.

**Cause.** The generic Linux transaction's native commit writes `status="committed"` and releases its resource claims before the enclosing wrapper calls `MutationLedger.commit()`. There is no authenticated confirmation-intent/reconciliation mechanism in this adapter. The router-specific fix does not cover this different adapter.

**Reproduction.** Generated the actual `_linux_service()` apply shell for one private file, with inert service controls, then called the actual `setup_linux_transaction.run(apply)` and commit path with a one-time injected exception at ledger commit. The file/transaction records and ledger were real. After removing the exception, native state was committed, the ledger stayed applied, confirmation retry failed, ordinary rollback failed, a fresh-token apply was blocked, and Emergency Withdraw refused the noncommitted ledger action. The desired file remained installed.

**Impact.** A transient finalization failure strands the service's ownership and recovery lifecycle. This is not an actual disk-full, power-loss, daemon startup or remote-transport test.

**Correction direction.** Make generic service confirmation a recoverable, authenticated state transition spanning native publication, resource release and ledger finalization. Retain completion/intent evidence until both sides are reconciled. Do not solve it by accepting an unproven mutable committed label or erasing an applied action.

### Exact-runtime evidence

```json
{
  "first": "RuntimeError:injected transient ledger commit failure",
  "native_state": "committed",
  "ledger_statuses": [
    "applied"
  ],
  "retry_commit": "ValueError:Setup changed before external-health confirmation",
  "rollback": "ValueError:Transaction has an unknown or committed outcome; reconcile it before rollback",
  "new_transaction_apply": "ValueError:An earlier action has unresolved ownership",
  "withdrawal": "OwnershipConflict:Only committed, uncontested actions can be reversed",
  "contents": "AFTER\n"
}
```

### Relevant unchanged source

`src/sentinel_blue/setup_linux_transaction.py`
```text
 311:         secure_directory(base)
 312:         state = read(base / 'state.json')
 313:         if state['spec'] != spec:
 314:             raise ValueError('Setup rollback does not match its private record')
 315:         if phase == 'rollback':
 316:             restore(base, spec, state, token)
 317:         else:
 318:             if state['status'] != 'applied' or capture(spec) != state['after']:
 319:                 raise ValueError('Setup changed before external-health confirmation')
 320:             state['status'] = 'committed'
 321:             save(base / 'state.json', state)
 322:             release(state, token)
```

`src/sentinel_blue/setup_linux_transaction.py`
```text
 364:         elif phase in {'commit', 'rollback'}:
 365:             _run(phase, spec, token, apply)
 366:             after = ledger_capture(spec)
 367:             if phase == 'commit':
 368:                 ledger.commit(action_id, after, {'success': True, 'external_health_confirmed': True})
 369:             else:
 370:                 ledger.append('cancelled', action_id=action_id, restored_hash=ledger.store(after), validation={'success': True})
```

## LINUX-27 — Later Linux setup rollback/confirmation ignores a changed file revision

**Priority:** High.

**Locations:** `src/sentinel_blue/setup_linux_transaction.py:50–86`; `src/sentinel_blue/setup_linux_transaction.py:159–206`; `src/sentinel_blue/setup_linux_transaction.py:317–337`; `src/sentinel_blue/setup_linux_transaction.py:364–370`.

**Cause.** `_read_file()` returns both a content/security fingerprint and a distinct file revision. `fingerprint()` and `capture()` discard the revision. Later native rollback and commit compare only those revision-free captures. The outer ledger does contain revision evidence, but the commit/rollback wrapper does not compare against it before invoking the native phase. Confirmation then captures the replacement and commits it as its new owned post-state.

**Reproduction.** After a successful real generated apply wrote `AFTER`, the fixture atomically replaced the file with a different inode containing the same bytes, owner/group and mode. The actual ledger snapshot detected a changed revision while the native capture remained equal. Ordinary rollback returned success, replaced that outside object with `BEFORE`, and recorded cancellation. A separate confirmation case returned success and adopted the replacement into a committed ledger snapshot.

**Impact and qualification.** The defect is a missed observable ownership/revision change, not an ability to bypass the existing different-content or different-mode checks. No different-content overwrite is claimed from this specific fixture. The inner failed-apply shell guard and long-lived withdrawal's initial exact-snapshot check are separate protections; the uncovered path is subsequent ordinary transaction rollback/confirmation.

**Correction direction.** Compare the current exact revision with authenticated applied evidence before later commit/rollback, then recheck at mutation boundaries. Backups can continue using semantic metadata for copied-inode comparison; keep that separate from live-object ownership. Preserve externally replaced objects and hold ambiguous transactions.

### Exact-runtime evidence

```json
{
  "rollback": {
    "revision_changed": true,
    "native_capture_unchanged": true,
    "operation": "success",
    "contents_after": "BEFORE\n",
    "ledger_statuses": [
      "cancelled"
    ],
    "native_state": "rolled-back"
  },
  "commit": {
    "revision_changed": true,
    "native_capture_unchanged": true,
    "operation": "success",
    "contents_after": "AFTER\n",
    "ledger_statuses": [
      "committed"
    ],
    "native_state": "committed"
  }
}
```

### Relevant unchanged source

`src/sentinel_blue/setup_linux_transaction.py`
```text
  50: def _read_file(path):
  51:     """Return metadata, bytes and revision from one bounded, stable descriptor.
  52: 
  53:     O_NOFOLLOW alone does not prevent a FIFO open from blocking. Validate the
  54:     nonblocking descriptor before reading, then detect replacement/modification.
  55:     Keep revision separate from the persisted fingerprint: copied backups have
  56:     different inodes/timestamps and are compared by content and metadata.
  57:     """
  58:     trusted_parent(path)
  59:     try:
  60:         fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
  61:     except FileNotFoundError:
  62:         return None, None, None
  63:     try:
  64:         st = os.fstat(fd)
  65:         if not stat.S_ISREG(st.st_mode) or st.st_nlink != 1 or st.st_size > MAX_FILE or st.st_mode & 0o022:
  66:             raise ValueError('Unsafe or oversized setup file')
  67:         data = bytearray()
  68:         while len(data) <= MAX_FILE:
  69:             block = os.read(fd, min(65536, MAX_FILE + 1 - len(data)))
  70:             if not block:
  71:                 break
  72:             data.extend(block)
  73:         if len(data) > MAX_FILE:
  74:             raise ValueError('Setup file exceeds the snapshot limit')
  75:         attrs = {name: base64.b64encode(os.getxattr(fd, name)).decode() for name in sorted(os.listxattr(fd))}
  76:         if _revision(st) != _revision(os.fstat(fd)) or _revision(st) != _revision(path.lstat()):
  77:             raise ValueError('Setup file changed during its bounded read')
  78:         info = {'sha256': hashlib.sha256(data).hexdigest(), 'uid': st.st_uid, 'gid': st.st_gid,
  79:                 'mode': stat.S_IMODE(st.st_mode), 'xattrs': attrs}
  80:         return info, bytes(data), [st.st_dev, st.st_ino, st.st_ctime_ns, st.st_mtime_ns]
  81:     finally:
  82:         os.close(fd)
  83: 
  84: 
  85: def fingerprint(path):
  86:     return _read_file(path)[0]
```

`src/sentinel_blue/setup_linux_transaction.py`
```text
 159: def restore(base, spec, state, token):
 160:     if state['status'] == 'rolled-back':
 161:         release(state, token)
 162:         return
 163:     if state['status'] not in {'applied', 'apply-failed'}:
 164:         raise ValueError('Transaction has an unknown or committed outcome; reconcile it before rollback')
 165:     current = capture(spec)
 166:     if current['files'] != state['after']['files']:
 167:         raise ValueError('Setup files changed after apply; automatic rollback is held')
 168:     # A stopped/crashed service can be repaired; a changed unit or startup policy
 169:     # needs review before any files are overwritten or a service is restarted.
 170:     for key in ('exists', 'enabled', 'configuration_sha256'):
 171:         if current['service'][key] != state['after']['service'][key]:
 172:             raise ValueError('Service configuration changed after apply; rollback is held')
 173:     for i, row in enumerate(spec['files']):
 174:         original = state['before']['files'][row['path']]
 175:         if original is not None and fingerprint(base / ('file-' + str(i))) != original:
 176:             raise ValueError('Private setup backup integrity changed')
 177:     # All current and backup preconditions pass before the first restoration.
 178:     # Stop a newly created running unit before removing its unit file. After a
 179:     # daemon reload systemd can report that live process as LoadState=not-found.
 180:     if current['service']['active'] and not state['before']['service']['active']:
 181:         command('systemctl', 'stop', '--', spec['service'])
 182:     if current['service']['exists'] and not state['before']['service']['exists']:
 183:         command('systemctl', 'disable', '--', spec['service'])
 184:     for i, row in enumerate(spec['files']):
 185:         path = Path(row['path'])
 186:         original = state['before']['files'][row['path']]
 187:         if original == current['files'][row['path']]:
 188:             continue
 189:         if fingerprint(path) != current['files'][row['path']]:
 190:             raise ValueError('Setup file changed during rollback; automatic rollback is held')
 191:         if original is None:
 192:             path.unlink()
 193:         else:
 194:             secure_directory(path.parent)
 195:             temp = path.with_name('.sentinel-restore-' + uuid.uuid4().hex)
 196:             try:
 197:                 shutil.copy2(base / ('file-' + str(i)), temp, follow_symlinks=False)
 198:                 os.chown(temp, original['uid'], original['gid'])
 199:                 os.chmod(temp, original['mode'])
 200:                 if fingerprint(temp) != original:
 201:                     raise ValueError('Restoration metadata did not match its backup')
 202:                 if fingerprint(path) != current['files'][row['path']]:
 203:                     raise ValueError('Setup file changed during rollback; automatic rollback is held')
 204:                 os.replace(temp, path)
 205:             finally:
 206:                 temp.unlink(missing_ok=True)
```

`src/sentinel_blue/setup_linux_transaction.py`
```text
 317:         else:
 318:             if state['status'] != 'applied' or capture(spec) != state['after']:
 319:                 raise ValueError('Setup changed before external-health confirmation')
 320:             state['status'] = 'committed'
 321:             save(base / 'state.json', state)
 322:             release(state, token)
 323:     finally:
 324:         os.close(fd)
 325: 
 326: 
 327: def ledger_capture(spec):
 328:     native = capture(spec)
 329:     evidence = {}
 330:     for row in spec['files']:
 331:         path = Path(row['path'])
 332:         info, data, revision = _read_file(path)
 333:         if info != native['files'][row['path']]:
 334:             raise ValueError('Setup file changed during durable ledger capture')
 335:         evidence[row['path']] = (None if info is None else
 336:             {'bytes': base64.b64encode(data).decode(), 'revision': revision})
 337:     return {'native': native, 'file_evidence': evidence}
```

`src/sentinel_blue/setup_linux_transaction.py`
```text
 364:         elif phase in {'commit', 'rollback'}:
 365:             _run(phase, spec, token, apply)
 366:             after = ledger_capture(spec)
 367:             if phase == 'commit':
 368:                 ledger.commit(action_id, after, {'success': True, 'external_health_confirmed': True})
 369:             else:
 370:                 ledger.append('cancelled', action_id=action_id, restored_hash=ledger.store(after), validation={'success': True})
```

## LINUX-28 — Appending agent self-health errors breaks telemetry provenance/count validation

**Priority:** High.

**Locations:** `src/sentinel_blue/agent.py:1518–1531`; `src/sentinel_blue/collectors.py:1720–1738`; `src/sentinel_blue/validation.py:814–822`.

**Cause.** `collect()` bounds and pairs `collector_errors` with `collector_issue_sources`. The agent later extends only `collector_errors` with self-health errors. The validator requires nonempty provenance arrays to have the same length as errors and caps errors at 256. That post-collection augmentation breaks its own wire contract.

**Reproduction.** Ran the actual agent loop once, with real protocol objects and a private durable spool, supplying a valid one-error/one-source collected sample and a modeled self-health error. The agent attempted a two-error/one-source upload. The actual controller validator raised `collector issue provenance must match every reported error`. The controlled client propagated that validator exception, leaving the spool item unacknowledged. With 256 initial errors the appended result had 257 errors and failed the count limit. With no initial collector errors the same self-health addition passed (empty provenance is the supported legacy case).

**Impact and limits.** Under the simultaneous collection/self-health-failure condition, an otherwise valid entire observation is rejected instead of conveying degraded status. This can remove useful monitoring exactly when the host is unhealthy. Self-health and collection providers were modeled; no real low-disk condition or HTTP controller deployment was induced. A production authenticated-400 rejection may be handled differently by the queue than this direct-validator fixture; only the demonstrated validator failure/unacknowledged local fixture is asserted.

**Correction direction.** Use one bounded diagnostic append/normalization path for collector and agent health evidence. Add matching source entries and preserve a truthful overflow indication. Do not discard health failures or weaken provenance validation to make the sample pass.

### Exact-runtime evidence

```json
{
  "origin": "/mnt/data/sentinel-blue-1.9.99.pyz/sentinel_blue/agent.py",
  "one_collector_error": {
    "collection_valid_before_agent_merge": true,
    "upload_attempts": 1,
    "errors_after_merge": 2,
    "sources_after_merge": 1,
    "controller_validator_failures": [
      "collector issue provenance must match every reported error"
    ],
    "unacknowledged_spool_items": 1,
    "agent_cycle_error_logged": true,
    "scope": "actual once-mode agent and real spool; modeled collection/self-health, upload uses real controller validator"
  },
  "diagnostic_limit": {
    "collection_valid_before_agent_merge": true,
    "upload_attempts": 1,
    "errors_after_merge": 257,
    "sources_after_merge": 256,
    "controller_validator_failures": [
      "collector_errors must be an array of at most 256 strings"
    ],
    "unacknowledged_spool_items": 1,
    "agent_cycle_error_logged": true,
    "scope": "actual once-mode agent and real spool; modeled collection/self-health, upload uses real controller validator"
  },
  "no_collector_errors_control": {
    "collection_valid_before_agent_merge": true,
    "upload_attempts": 1,
    "errors_after_merge": 1,
    "sources_after_merge": 0,
    "controller_validator_failures": [],
    "unacknowledged_spool_items": 0,
    "agent_cycle_error_logged": false,
    "scope": "actual once-mode agent and real spool; modeled collection/self-health, upload uses real controller validator"
  }
}
```

### Relevant unchanged source

`src/sentinel_blue/agent.py`
```text
1518:             for component, healthy, error in (
1519:                 ("action journal", journal.healthy, journal.error),
1520:                 ("sequence state", sequence.healthy, sequence.error),
1521:             ):
1522:                 if not healthy:
1523:                     health["errors"].append(f"self-health: {component}: {error}")
1524:                     health["critical_errors"].append(f"self-health: {component} requires review")
1525:                     health["healthy"] = False
1526:                     health["action_safe"] = False
1527:             refresh_recovery_health(
1528:                 executor, health, str(telemetry.get("boot_id", "unknown"))
1529:             )
1530:             telemetry["collector_errors"].extend(health["errors"])
1531:             from .recording import emit as record_event
```

`src/sentinel_blue/collectors.py`
```text
1720:     # verbose platform exception text.  Normalize them at the collection
1721:     # boundary so a failed sub-collector can never make the complete telemetry
1722:     # record invalid on the wire.
1723:     bounded_errors: list[str] = []
1724:     issue_sources: list[str] = []
1725:     for error in errors[:256]:
1726:         clean = "".join(
1727:             character
1728:             if ord(character) >= 32 or character in "\t\r\n"
1729:             else "\ufffd"
1730:             for character in str(error)
1731:         ).strip()
1732:         bounded_errors.append((clean or "collector failed without detail")[:256])
1733:         from .payload_inventory import PayloadCoverageIssue
1734:         issue_sources.append("payload_fingerprint" if isinstance(error, PayloadCoverageIssue) else "unknown")
1735:     if len(errors) > 256:
1736:         bounded_errors[-1] = "additional collector errors exceed the telemetry diagnostic limit"
1737:         issue_sources[-1] = "unknown"
1738:     from .activity_evidence import drain as drain_activity
```

`src/sentinel_blue/validation.py`
```text
 814:     result["collector_errors"] = _string_array(payload.get("collector_errors", []), "collector_errors", 256)
 815:     sources = payload.get("collector_issue_sources", [])
 816:     if (not isinstance(sources, list) or len(sources) > 256
 817:         or any(not isinstance(source, str) or source not in {"unknown", "payload_fingerprint"} for source in sources)
 818:         or sources and len(sources) != len(result["collector_errors"])):
 819:         raise ValidationError("collector issue provenance must match every reported error")
 820:     if "collector_issue_sources" in payload:
 821:         result["collector_issue_sources"] = list(sources)
 822:     collection_seconds = payload.get("collection_seconds")
```

## LINUX-29 — Nested native scoring clients outlive cancellation of their worker

**Priority:** Medium.

**Locations:** `src/sentinel_blue/native_probes.py:96–109`; `src/sentinel_blue/native_probes.py:343–388`; `src/sentinel_blue/bounded_capture.py:31–51`; `src/sentinel_blue/bounded_capture.py:140–178`.

**Cause.** `run_native_probe()` launches a Python worker through `_command()` / `capture_command()`. That worker uses the same capture helper to launch native clients. Every capture starts a new POSIX session. Consequently the native client belongs to a different process group from its worker. Killing the timed-out worker's group does not kill that inner client. The worker can be terminated before its own nested cleanup executes.

**Reproduction.** The real `run_native_probe('icmp',...)` path used a private executable named `ping` that did not open any sockets or send traffic. This inert client recorded its PID/group, slept, and wrote a harmless marker. With a three-second outer deadline the packaged probe returned TimeoutError after about 3.21 seconds; the client still existed, the marker was absent at return, and the marker appeared afterward. This uses the actual worker, inner capture and timeout cleanup, not a synthetic exception at the cleanup boundary. The client itself did not detach or ignore TERM; Sentinel's inner capture created its new group.

**Impact and qualification.** A cancelled native scoring transaction can leave a client running beyond its parent deadline. The return correctly says timeout/uncertain, so this does not prove a false healthy score. No database/DNS write or actual network effect was tested. Potential write/cleanup effects for other clients sharing this mechanism remain an implication, not measured product behavior.

**Correction direction.** Supervise all owned descendants across nested capture groups and propagate the original absolute deadline/cancellation. Verify child termination before releasing supervision. Merely removing the new-session option without adjusting group-signalling ownership could kill the wrong group and is not a complete correction.

### Exact-runtime evidence

```json
{
  "origin": "/mnt/data/sentinel-blue-1.9.99.pyz/sentinel_blue/native_probes.py",
  "outcome": "TimeoutError:scoring transaction timed out; write cleanup may be uncertain",
  "seconds_at_return": 3.2109463360000063,
  "child": {
    "pid": 9560,
    "pgid": 9560,
    "ppid": 9550
  },
  "child_exists_at_return": true,
  "marker_at_return": false,
  "marker_after_return": true,
  "scope": "real run_native_probe and nested captures; fake ping never opens a socket or sends traffic"
}
```

### Relevant unchanged source

`src/sentinel_blue/native_probes.py`
```text
  96: def _command(argv, seconds, *, incoming=b"", env=None):
  97:     """Enforce the response quota during execution, including worker subprocesses."""
  98:     from .bounded_capture import capture_command, CaptureError
  99:     try:
 100:         code, result = capture_command(argv, seconds, limit=65536, incoming=incoming, env=env)
 101:     except CaptureError as exc:
 102:         if exc.reason in {'invalid_deadline', 'deadline_before_launch', 'deadline_exceeded'}:
 103:             raise TimeoutError('scoring transaction timed out; write cleanup may be uncertain') from None
 104:         if exc.reason == 'output_limit_exceeded':
 105:             raise RuntimeError('scoring response exceeds 64 KiB; write cleanup may be uncertain') from None
 106:         raise RuntimeError('native scoring capture failed; write cleanup may be uncertain') from None
 107:     if code:
 108:         raise RuntimeError('native scoring client failed; check credentials, protocol, and dependencies')
 109:     return result
```

`src/sentinel_blue/native_probes.py`
```text
 343: def _perform(kind, spec, address, timeout):
 344:     if kind in {"mysql", "postgres"}:
 345:         return _sql(kind, spec, address, timeout)
 346:     if kind == "ssh-login":
 347:         return _ssh(spec, address, timeout)
 348:     if kind == "smb":
 349:         return _smb(spec, address, timeout)
 350:     if kind == "dns-update":
 351:         return _dns_update(spec, address, timeout)
 352:     if kind == "icmp":
 353:         if os.name == "nt":
 354:             argv = [_binary("ping"), "-n", "1", "-w", str(max(1, int(timeout * 1000))), address]
 355:         else:
 356:             argv = [_binary("ping"), "-n", "-c", "1", "-W", str(max(1, math.ceil(timeout))), address]
 357:         output = _command(argv, timeout)
 358:         # Windows ping can return zero for ICMP destination-unreachable replies.
 359:         if os.name == "nt" and not re.search(rb"\bTTL=\d+", output, re.IGNORECASE):
 360:             raise RuntimeError("no ICMP echo reply was verified")
 361:         return "ICMP echo reply received"
 362:     raise ValueError("unsupported native scoring probe")
 363: 
 364: 
 365: def run_native_probe(kind, spec, address, timeout):
 366:     # A child provides one hard overall deadline even when a library has several
 367:     # internal request timers. It also prevents logging/cache state crossing probes.
 368:     package_root = str(Path(__file__).parent.parent)
 369:     # Preserve explicitly configured dependency paths in embedded Python too;
 370:     # its isolated mode intentionally ignores the PYTHONPATH environment.
 371:     module_paths = json.dumps([package_root, *[str(Path(p).absolute()) for p in sys.path if p]])
 372:     code = "import json,sys; sys.path[:0]=json.loads(sys.argv[1]); from sentinel_blue.native_probes import _worker; _worker()"
 373:     payload = json.dumps({"kind": kind, "spec": spec, "address": address, "timeout": timeout}).encode()
 374:     if len(payload) > 65536:
 375:         raise ValueError("native scoring specification exceeds 64 KiB")
 376:     # Catch an absent client here as well: the child cannot start if the
 377:     # interpreter itself is unavailable, and the readiness answer is the same.
 378:     absent = missing_clients(kind)
 379:     if absent:
 380:         raise ProbeUnavailable("scoring client is not installed: " + ", ".join(absent))
 381:     result = _command([sys.executable, "-c", code, module_paths], timeout, incoming=payload)
 382:     record = json.loads(result)
 383:     if record.get("healthy") is not True:
 384:         detail = record.get("detail", "scoring transaction failed")
 385:         if record.get("unavailable") is True:
 386:             raise ProbeUnavailable(detail)
 387:         raise RuntimeError(detail)
 388:     return record["detail"]
```

`src/sentinel_blue/bounded_capture.py`
```text
  31: def _capture_stop(proc):
  32:     # Do not poll/wait on the leader before the final POSIX group signal: an
  33:     # unreaped leader pins its PID even when its descendants outlive it.
  34:     if os.name == 'posix':
  35:         try:
  36:             os.killpg(proc.pid, signal.SIGTERM)
  37:         except ProcessLookupError:
  38:             proc.wait(timeout=3)
  39:             return
  40:         until = time.monotonic() + CAPTURE_CLEANUP_GRACE
  41:         while time.monotonic() < until:
  42:             try:
  43:                 os.killpg(proc.pid, 0)
  44:             except ProcessLookupError:
  45:                 break
  46:             time.sleep(min(0.025, max(0.0, until - time.monotonic())))
  47:         try:
  48:             os.killpg(proc.pid, signal.SIGKILL)
  49:         except ProcessLookupError:
  50:             pass
  51:         proc.wait(timeout=3)
```

`src/sentinel_blue/bounded_capture.py`
```text
 140:     deadline = time.monotonic() + seconds
 141:     data = bytearray()
 142:     with tempfile.TemporaryFile() as source:
 143:         source.write(incoming)
 144:         source.seek(0)
 145:         if time.monotonic() >= deadline:
 146:             raise CaptureError('deadline_before_launch')
 147:         proc = subprocess.Popen(argv, stdin=source, stdout=subprocess.PIPE,
 148:                                 stderr=subprocess.STDOUT if merge_stderr else subprocess.DEVNULL,
 149:                                 env=env, start_new_session=os.name == 'posix',
 150:                                 creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0)
 151:         blocks = _capture_blocks(proc, deadline)
 152:         reaped = False
 153:         try:
 154:             for block in blocks:
 155:                 count = min(len(block), limit - len(data))
 156:                 data.extend(block[:count])
 157:                 if count < len(block):
 158:                     raise CaptureError('output_limit_exceeded', len(data))
 159:             remaining = deadline - time.monotonic()
 160:             if remaining <= 0:
 161:                 raise CaptureError('deadline_exceeded', len(data))
 162:             proc.wait(timeout=remaining)
 163:             reaped = True
 164:             if time.monotonic() >= deadline:
 165:                 raise CaptureError('deadline_exceeded', len(data))
 166:             return proc.returncode, bytes(data)
 167:         except BaseException as exc:
 168:             if not reaped:
 169:                 try:
 170:                     _capture_stop(proc)
 171:                 except (OSError, subprocess.SubprocessError):
 172:                     raise CaptureError('cleanup_incomplete', len(data)) from None
 173:             if isinstance(exc, CaptureError):
 174:                 raise CaptureError(exc.reason, len(data)) from None
 175:             if isinstance(exc, subprocess.TimeoutExpired):
 176:                 raise CaptureError('deadline_exceeded', len(data)) from None
 177:             if isinstance(exc, OSError):
 178:                 raise CaptureError('pipe_read_failed', len(data)) from None
```

## LINUX-30 — Linux process UID-pair strings cannot match numeric protected-account guards

**Priority:** Medium.

**Locations:** `src/sentinel_blue/process_identity.py:163–173`; `src/sentinel_blue/process_identity.py:198–210`; `src/sentinel_blue/collectors.py:193–239`; `src/sentinel_blue/identity_guard.py:15–39`; `src/sentinel_blue/identity_guard.py:76–80`; `src/sentinel_blue/identity_guard.py:101–126`.

**Cause.** Native Linux process identities encode user identity as `uid:<real>:<effective>`, while a protected identity guard requires a numeric UID string. The session analyzer compares those strings directly. No numeric guard can equal a normal Linux UID-pair string. This is separate from source-IP checking and the operating system's authentication.

**Reproduction.** Started a real harmless child and inspected its native identity (`uid:0:0`). The actual session collector consumed a modeled `who -u` row identifying that child, and the guard specified the matching root account (`account_id="0"`) and the exact modeled peer network. The protected-access analyzer emitted a critical `protected_identity_access_unverified` alert with `identity_matched=False`, `source_matched=True`, and reason `native_identity_unverified`. Removing only process identity made the fallback account/source check pass with no alert.

**Impact and limits.** Correct native process evidence causes a false critical identity mismatch for an otherwise matching protected Linux session. This is alert correctness, not an unauthorized login or a claim that IP/UID matches authenticate a scorer. No root account was created or modified, no setuid binary installed, and the peer/tty login was a fixture.

**Correction direction.** Parse and normalize Linux real/effective UID evidence under an explicit session-identity contract before comparing it with the bound account UID. Retain separate Windows SID handling and continue rejecting genuinely mismatched or malformed identity evidence.

### Exact-runtime evidence

```json
{
  "actual_process_identity_uid": "uid:0:0",
  "expected_account_id": "0",
  "collector_errors": [],
  "sessions": [
    {
      "username": "root",
      "source": "192.0.2.7",
      "session_id": "pts/9",
      "process_id": 11033,
      "privileged": true,
      "interactive": true,
      "process_identity": {
        "schema": "sentinel-process-v1",
        "platform": "linux",
        "process_id": 11033,
        "boot_id": "20bb11a6-5331-4f6b-b042-84c31f117b3c",
        "start_time": "74228",
        "executable_path": "/opt/pyvenv/bin/python3",
        "executable_file_id": "dev:1c:ino:8000000000018eb9",
        "user_id": "uid:0:0",
        "kernel_session_id": "0"
      }
    }
  ],
  "alerts": [
    {
      "kind": "protected_identity_access_unverified",
      "title": "Protected account access requires verification",
      "summary": "Access by protected account root from 192.0.2.7 failed its identity/source checks.",
      "severity": "critical",
      "confidence": 0.8,
      "evidence": {
        "account": {
          "name": "root",
          "account_id": "uid:0:0",
          "domain": ""
        },
        "source": "192.0.2.7",
        "observation": "session",
        "reasons": [
          "native_identity_unverified"
        ],
        "identity_matched": false,
        "source_matched": true,
        "scorer_authenticated": false,
        "_sentinel_blue_model_features": {
          "schema": 1,
          "feature_schema_sha256": "baefb7abd8e952abce371039493a0743dad7a3741ebb46f4c9193c0f747e71e1",
          "values": {
            "external_source": 1.0,
            "protected_identity": 1.0
          },
          "sha256": "b3bdc9cd072999c6008f439b91fee7671ba6a2bef12c5f617c619fdfa5bf1a67"
        }
      },
      "recommendation": "Preserve the required account. Verify this access through the official scoring/administration inventory. A username or source-IP match alone does not authenticate the operator; no blanket containment is authorized.",
      "recommended_action": "snapshot"
    }
  ],
  "alerts_without_process_identity": [],
  "scope": "real harmless child identity; who peer/tty rows and authorized guard modeled"
}
```

### Relevant unchanged source

`src/sentinel_blue/process_identity.py`
```text
 163:         effective_uid = ""
 164:         for line in status.splitlines():
 165:             if line.startswith("Uid:"):
 166:                 identifiers = line.split()[1:]
 167:                 if len(identifiers) >= 2 and all(item.isdigit() for item in identifiers[:2]):
 168:                     effective_uid = f"uid:{identifiers[0]}:{identifiers[1]}"
 169:                 break
 170:         if not effective_uid:
 171:             raise OSError("Linux process user identity is unavailable")
 172:         executable_path = os.readlink("exe", dir_fd=directory_descriptor)
 173:         if not executable_path or "\x00" in executable_path:
```

`src/sentinel_blue/process_identity.py`
```text
 198:     return validate_process_identity(
 199:         {
 200:             "schema": PROCESS_IDENTITY_SCHEMA,
 201:             "platform": "linux",
 202:             "process_id": process_id,
 203:             "boot_id": kernel_boot,
 204:             "start_time": before[19],
 205:             "executable_path": os.path.normpath(executable_path),
 206:             "executable_file_id": f"dev:{executable_info.st_dev:x}:ino:{executable_info.st_ino:x}",
 207:             "user_id": effective_uid,
 208:             "kernel_session_id": before[3],
 209:         }
 210:     )
```

`src/sentinel_blue/collectors.py`
```text
 193: 
 194: def _linux_sessions(privileged: set[str], errors: list[str] | None = None) -> list[Session]:
 195:     try:
 196:         result = _run(["who", "-u"])
 197:     except (OSError, subprocess.SubprocessError) as exc:
 198:         if errors is not None:
 199:             errors.append(f"Linux session inventory unavailable ({type(exc).__name__})")
 200:         return []
 201:     if result.returncode != 0:
 202:         if errors is not None:
 203:             errors.append("Linux session inventory unavailable")
 204:         return []
 205:     sessions: list[Session] = []
 206:     for line in result.stdout.splitlines():
 207:         parts = line.split()
 208:         if len(parts) < 2:
 209:             continue
 210:         username = parts[0]
 211:         source = "local"
 212:         if parts[-1].startswith("(") and parts[-1].endswith(")"):
 213:             source = parts[-1][1:-1]
 214:         process_id = None
 215:         for value in parts[4:]:
 216:             if value.isdigit():
 217:                 process_id = int(value)
 218:                 break
 219:         process_identity = None
 220:         if process_id is not None:
 221:             try:
 222:                 process_identity = inspect_process_identity(
 223:                     process_id, boot_id=_boot_id("linux")
 224:                 )
 225:             except (OSError, PermissionError, RuntimeError, ValueError) as exc:
 226:                 if errors is not None:
 227:                     errors.append(
 228:                         f"session process identity unavailable for PID {process_id}: {exc}"
 229:                     )
 230:         sessions.append(
 231:             Session(
 232:                 username=username,
 233:                 source=source,
 234:                 session_id=parts[1],
 235:                 process_id=process_id,
 236:                 privileged=username.casefold() in privileged,
 237:                 process_identity=process_identity,
 238:             )
 239:         )
```

`src/sentinel_blue/identity_guard.py`
```text
  15: 
  16: 
  17: def validate_guards(value: Any) -> list[dict]:
  18:     if not isinstance(value, list) or len(value) > 2048:
  19:         raise ValueError("identity_guards must be a bounded array")
  20:     result, seen = [], set()
  21:     for row in value:
  22:         required = {"agent_id", "name", "account_id", "allowed_sources"}
  23:         if not isinstance(row, dict) or not required <= set(row) or set(row) - required - {'ssh_public_keys'}:
  24:             raise ValueError("identity guard requires agent_id, name, account_id and allowed_sources")
  25:         for field in ("agent_id", "name", "account_id"):
  26:             if (not isinstance(row[field], str) or not 1 <= len(row[field]) <= 256
  27:                     or any(ord(c) < 32 for c in row[field])):
  28:                 raise ValueError("identity guard contains an invalid identity")
  29:         if row["agent_id"] == "*":
  30:             raise ValueError("identity guards require an exact agent, not a wildcard")
  31:         if not re.fullmatch(r"\d+|S-1-(?:\d+-)+\d+", row["account_id"], re.I):
  32:             raise ValueError("identity guard requires a native UID or SID")
  33:         sources = row["allowed_sources"]
  34:         if not isinstance(sources, list) or not 1 <= len(sources) <= 64:
  35:             raise ValueError("identity guard requires bounded source networks")
  36:         networks = []
  37:         for source in sources:
  38:             if not isinstance(source, str):
  39:                 raise ValueError('identity guard source networks must be strings')
```

`src/sentinel_blue/identity_guard.py`
```text
  76:     for account in telemetry.get("accounts", []):
  77:         accounts.setdefault(leaf(account.get("name", "")), []).append(account)
  78:     observations = [("session", s.get("username", ""), s.get("source", "unknown"),
  79:                      (s.get("process_identity") or {}).get("user_id", ""), "")
  80:                     for s in telemetry.get("sessions", [])]
```

`src/sentinel_blue/identity_guard.py`
```text
 101:     for origin, name, source, observed_id, domain in observations:
 102:         normalized = leaf(name)
 103:         # Do not let an earlier valid login suppress a different native identity.
 104:         key = (origin, str(name), source, observed_id, domain)
 105:         if normalized not in protected or key in seen:
 106:             continue
 107:         seen.add(key)
 108:         candidates = [g for g in applicable.values() if leaf(g["name"]) == normalized]
 109:         guard = candidates[0] if len(candidates) == 1 else None
 110:         rows = accounts.get(normalized, [])
 111:         identity_ok = bool(guard and len(rows) == 1
 112:                            and rows[0].get("account_id") == guard["account_id"]
 113:                            and (windows
 114:                                 or rows[0].get("name") == guard["name"]))
 115:         if observed_id:
 116:             identity_ok = bool(guard and observed_id.casefold() == guard["account_id"].casefold()
 117:                                and (windows or str(name) == guard["name"]))
 118:         elif windows:
 119:             # A local-account lookup cannot authenticate a domain login. Windows
 120:             # events and sessions must identify the actual subject's native SID.
 121:             identity_ok = False
 122:         source_ok = bool(guard and _source_allowed(source, guard["allowed_sources"]))
 123:         if identity_ok and source_ok:
 124:             continue
 125:         reasons = (["missing_identity_guard"] if not guard else
 126:                    ([] if identity_ok else ["native_identity_unverified"]) +
```

## Reproduction and preservation

The accompanying ZIP includes `harness/`, measured JSON and complete logs. It does not embed another release or alter the source. Place the matching source archive/runtime in your local authorized development environment and adjust the absolute output/source paths in the suite invocation. The fixtures use Linux root-owned temporary directories under `/var/lib`, stub all service controls, and clean their own temporary files. Do not run arbitrary test discovery on a production/competition host.

Example new-finding run, from the matching source root, with the ZIP harness extracted elsewhere:

```sh
PYTHONPATH=/path/to/review/harness:src:tests:. python3 -m unittest test_review_1999 -v
# Expected on unchanged 1.9.99: seven assertion failures, zero test errors.
PYTHONPATH=/path/to/review/harness:/path/to/sentinel-blue-1.9.99.pyz:tests:. python3 -m unittest test_review_1999 -v
```

Exploratory harness mistakes are not reported as application defects: initial unavailable streaming execution; a missing unittest argv that invoked the desktop error path; and a missing explicit mock attribute in the first agent fixture. The final source campaign fixed argv and still contains the independently reported cleanup assertion failure. The initial 0.7-second nested-capture fixture did not start its inner client and is not counted; the three-second final fixtures do.

## Remaining acceptance scope

This is a focused Linux boundary review, not an exhaustive audit or new native acceptance. The supplied 1.9.99 fix report still marks native systemd/timers, VM boot/restart, real router operation, distribution-specific providers, remote observers, multi-host withdrawal and competition uptime unmeasured. No flags or acceptance receipts were changed by this review. Prior fixes passing their regression suite do not establish absence of additional defects.

**Triage:** address the generic service transaction ownership/finalization and invalid degraded-telemetry paths before unattended reliance; then repair nested client cancellation and protected-session identity normalization.
