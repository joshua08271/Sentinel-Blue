# Activity evidence and outside observers in 1.9.69

The recorder can preserve evidence of activity that did not generate a Sentinel Blue alert. Windows native security events include process creation/exit, object-handle requests and audited object access, in addition to existing account/logon events. Linux retains recognized structured native audit rows from the journal. Protected-file change notifications are recorded separately, and Linux read/open notifications are coalesced by path over two seconds without waking repair collection.

Activity batches are included in authenticated host telemetry, so accepted evidence reaches the main controller recording. Bounded queues and unavailable/truncated coverage are recorded explicitly. The local host keeps its own evidence even when delivery fails. Events use structured identity, path, executable, native code and outcome fields; command text and raw log messages are excluded.

## What this establishes

A recorded successful access or process event can show what the OS observed even when the alert classifier did not recognize it. It does not establish red-team attribution on its own. Review it against the club's authorized activity log, independent network evidence or a red-team debrief. A lack of nearby alerts is a review lead, not proof of a missed attack; nearby alerts may concern other activity. The script does not automatically patch unknown findings or expand repair permissions from uploaded recordings.

Windows needs the relevant audit categories enabled and an auditing rule on each object to generate file-access events. The runtime reads these settings and reports disabled or unverified coverage; it does not silently change audit policy or install auditing rules. Linux file notifications do not identify the actor, every individual read or data sent out of the VM. Native journaling coverage depends on existing audit configuration. Root/SYSTEM can tamper with local evidence. Sampling, quotas, disconnected hosts and services outside the collector's coverage remain gaps.

## Outside VM setup

Use the same approved `sentinel-blue.pyz` in **observer** mode on each outside VM. This role performs only explicitly assigned checks and sends reports; it does not enroll a host agent, collect the outside VM's inventory, poll actions or execute repairs. Python 3.11 or newer is required. A separate executable and a desktop configuration wizard are not included.

1. Declare the target host and service in the main event profile. Confirm the exact target IPs, ports and expected transactions with the event's service requirements.
2. Fill in `examples/observer.example.json` for the outside VM and the matching entry in `examples/controller-observers.example.json` for the controller. Replace the placeholder runtime hash with the SHA-256 of the approved script. The observer ID, scope, intervals and checks must match at both ends; private file paths can differ.
3. Create a unique reporting key of 32–256 URL-safe characters for this observer. Put it in a private file at both ends. Use a different key from every agent, operator and other observer. Keep configuration files and state directories private. Do not put keys in URLs, command-line arguments or evidence uploads.
4. Supply the controller's existing trusted CA certificate to the observer and use its numeric HTTPS origin. The controller certificate must cover that address. Include the assigned outside VM in the controller profile's authorized host inventory and ingress scope; the network rules must also admit it. A certificate-verification bypass is not supported.
5. Add `--observer-config controller-observers.json` to the existing controller launch. Start the outside VM with `python sentinel-blue.pyz observer --config observer.json`. The reporting role runs until stopped. `--once` performs one check/report cycle.

The example addresses are documentation placeholders and do not describe a real network. They deliberately use a nonmatching runtime checksum. Prepare the actual approved configuration before the range; these examples cannot provision a missing controller or service.

## Checks, display and loss handling

Each observer can have 1–32 checks; the controller supports up to 64 observers. Supported checks are read-only HTTP/HTTPS, TCP, DNS and TLS. HTTP uses GET or HEAD and requires an expected status; use an expected body to check application content. The observer contract uses exact numeric target addresses within explicit authorized networks. It does not discover hosts or send arbitrary commands, request bodies, credentials or custom headers. It is not a replacement for every scorer transaction, especially authenticated or hostname-specific virtual hosts.

Reports have a dedicated signed endpoint and key, pinned configuration/runtime identities and durable increasing sequences. The controller verifies reports and returns signed acknowledgements. Replays and reordered reports are rejected. The observer key does not grant the agent or operator role. Local probe health remains separate from external health in the Services view. A locally healthy service with an unhealthy outside check is highlighted as a disagreement. Failed and stale outside checks appear in verification notices without repair approval controls.

The default interval is 15 seconds and the default stale deadline is 60 seconds. A missing report does not stay healthy forever. The observer does not queue a delivery outbox; after a failed send it samples again. Locally recorded failed reports remain on the outside VM, and gaps in later accepted sequences are recorded by the controller. The first accepted sequence has an explicitly unknown prior history. Starting a new controller without its prior durable state loses that earlier replay history.

## Export and review

The main Session **Stop & save** ZIP includes reports the controller accepted and activity delivered by host agents. Use that file for normal after-action review. For undelivered evidence, also export and copy the source agent/observer's own journal using `recording-export --directory <recording-directory> --stop`; the observer journal is under its configured `state_directory/recordings`. Keep these exports private.

`python sentinel-blue.pyz recording-review --bundle <session.zip> --output <private-directory>/activity-review.json` first verifies the recording, then writes a bounded timeline with observed activity, nearby-alert context and coverage gaps. It does not execute evidence, restore a controller, or train a model. Upload the original recording along with independent event context; the summary alone omits data beyond its display bound.

## Validation scope

The release status contains the exact script checksum and measured native and network results. The Azure rehearsal uses owned VMs on separate subnets of one VNet, ordinary service configuration faults and a paused observer. It does not establish reachability through an actual event router, public Internet path, official scorer, or representative opposing-team activity.

The final live relay test caught and corrected a Linux directory-notification defect: opening a watched directory no longer reports changes to all protected child files. Actual file changes and watch-loss signals still wake collection.
