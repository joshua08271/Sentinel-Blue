# Sentinel Blue 2.0.1 — Linux GUI 1

This Linux-only update is based on the supplied 2.0.1 livefix6 package. Its internal application version remains 2.0.1; the Linux GUI 1 label and SHA-256 identify the candidate. Windows-specific implementation files are unchanged and are retained in the source. No GitHub or public website release was made.

## Download and double-click (no terminal commands)

1. Open this chat in a browser **inside the Linux VM desktop** in the Proxmox console. Download `sentinel-blue-2.0.1-linux-gui1-x86_64.run` from this chat or the accompanying everything HTML.
2. In the VM's Downloads folder, right-click the downloaded file, open **Properties → Permissions**, and enable **Allow this file to run as a program / Is executable** if necessary. Browsers cannot set this permission for you.
3. Double-click the `.run` file and choose **Run / Execute** if your file manager asks. It verifies and unpacks its embedded offline application, then opens the GUI. There is no manual extraction, Python installation, pip command, shell command or internet dependency download.
4. If you are not already root, choose **Open as administrator…** on Start here and complete the normal desktop password prompt. Continue in the administrator window. Do this before configuring services, because administrator and ordinary-user settings are kept separately.
5. Choose **Service setup**. Double-click service rows to select them; choose **Configure selected service…** for ordinary fields and file pickers. Select **Ports: Automatic / Manual…** to review each port. The catalog distinguishes services it can configure from existing services it can only adopt/start.
6. Choose **Service check…** if you need a particular HTTP, HTTPS, DNS or TCP check. A TCP check only proves that a listener answers. It does not verify a database login or a competition scoring transaction.
7. On **Start here**, select approval-based or guarded automatic recovery, then **Review local setup**. Read the plan on **Setup** and click **Approve & start local setup**. The controller and agent start locally and the existing guarded setup engine applies the reviewed service plan. Changing choices after review invalidates approval.
8. Use **Services** for status and Pause/Resume, **Alerts & verification** for requests and their reasons, **Credentials** for private credentials, **Session** for recording and export, and **Withdraw / Recovery** for the existing recovery/removal controls. The alert dialog explains **why it needs attention** and **what response is needed**, with evidence beneath it.

Closing with the window's X minimizes it. Window → Close window keeps background monitoring running. Reopening the downloaded launcher and selecting **Reconnect saved local session** reconnects to a running local session. **Stop local monitoring** stops that session's controller and agent while retaining configured services and action records. This is distinct from Withdraw. Automatic startup after an OS reboot is not installed by the new launcher.

## Proxmox and prerequisites

Run this in an x86_64 Linux **guest VM with a desktop session**, such as a Kali/Debian/Ubuntu guest. Proxmox's management page provides access to the guest console; it is not a desktop application runner for an uploaded file. The local setup wizard refuses to configure the Proxmox hypervisor itself. See the [Proxmox GUI documentation](https://pve.proxmox.com/wiki/Graphical_User_Interface).

Sentinel's Python, Tcl/Tk and Python dependencies are included. A compatible Linux system, X11/XWayland desktop, native libraries, `tar`, `sha256sum`, and normal administrator authentication through `pkexec` and a desktop polkit agent are host prerequisites. For an ordinary user, a functioning graphical administrator prompt is needed to apply privileged changes. User cancellation does not grant access.

**Native service packages are not included in this application runtime.** Server software such as nginx, MariaDB or BIND must be installed before its configuration adapter can run; use your distribution's graphical package manager or approved offline packages. This update does not secretly fetch packages, create database contents, invent accounts or certificates, or configure unsupported products. Some service configurations still require existing files or domain/application details, entered with the form and file pickers. Advanced existing-file fields are expandable; file pickers record exact checksums without a terminal.

Automatic ports prefer required event ports or retained configured ports, then the protocol default. Optional alternate selection for a new service requires fresh complete listener evidence and explicit selection in the port dialog. Existing/unknown services and management/scoring constraints are not silently migrated. No port is reserved merely by reviewing it. Firewall/client changes require their own reviewed configuration.

The new guided startup creates a **single local-VM lab profile**, HTTPS controller on loopback, and a local agent. It does not authorize other machines. Existing remote-network and competition workflows remain available through **Connection** and **Setup** with their explicit inventory, credentials and approved profile. The wizard does not manufacture organizer approval or replace the full network inventory.

## Validation scope

The current candidate was tested in the local Linux execution environment, including real Tk windows, real TLS controller/agent processes, signed Pause/Resume, changed-plan refusal and orderly process shutdown. The focused regression suite ran 179 tests: 178 passed, one Windows DPAPI test skipped. Primary buttons were checked at 900×620. Screenshots of the first-run, services, setup-review and alert-review windows were inspected.

The downloadable executable is verified separately for extraction and full-bundle checksums. The build and delivery checks are recorded alongside this guide. **This updated candidate has not been installed/tested on your Proxmox VMs, and this is not a claim that every native service recipe has passed live acceptance.** Administrator authentication on your particular desktop remains a target-environment check. The saved original livefix6 reports describe the earlier supplied runtime, not this changed one.

The original 2.0.1/livefix6 Windows source, live-test checkpoint and historical validation documents remain available in the everything HTML. Historical notes about Workshop cleanup are retained as historical records; no VM was accessed or changed during this update.

## Files and privacy

On first launch the application extracts into a private versioned directory beneath `~/.local/share/sentinel-blue` (or your configured XDG data directory). The original `.run` file can be opened again; it reuses that version and verifies the unpacked file contents. Settings and local sessions use the application's existing private desktop directory. No credentials are embedded in the download; they are generated privately at runtime. Signing keys are excluded from saved connection settings. No terminal password entry is used by the new flow.

Checksums detect corruption. They are not a publisher signature. Keep the supplied checksums with the release if transferring it to another machine.
