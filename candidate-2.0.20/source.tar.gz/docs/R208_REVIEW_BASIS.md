# Sentinel Blue 2.0.8 — independent review (R208)

**Basis for 2.0.9.** Reviewed the exact 2.0.8 release (source SHA-256 `a73e9a87…18`, application `8ac8ffe3…9f`, installer `609db34a…58`) with its bundled Python 3.13.15 in a disposable container. Scope: the entire 2.0.7→2.0.8 application change and every path it touches (setup runner and job control, operator replay admission, retention and history archival, recovery workflow), plus packaging, the full test suite and runtime measurement. Line numbers refer to 2.0.8.

Packaging and the claimed 2.0.8 corrections held: all 10 embedded HTML artifacts and 5,339 payload files matched; the full suite ran 2,345 tests with 0 failures (18 native-only skips); R207 reproductions passed.

## R208-01 — High: operator-started redo is always refused

**Locations:** `setup_redo.py:449–451`; `redo_governance.py:58–61`; `desktop_recovery.py:252`.

`manual_redo()` takes `now` before fetching the live dashboard. The controller stamps the policy `observed_at` during that request, so `now - observed_at` is negative and the freshness gate (`0 <= age <= 30`) holds every unhealthy unit. **Recovery → Redo approved setup** always reported "fresh complete redo-governance evidence is unavailable" (8/8 real-HTTP runs) while the controller's own signed check permitted the redo. Approval-based mode has no other redo path. All vendor tests pinned `now`, which masks the ordering. The same gate compares the GUI's clock with the controller's on the network path: any GUI clock behind the controller holds network redo.

## R208-02 — Medium: one service's unresolved repair holds every service on the host

**Locations:** `store.py:6428` (`action_holds([item], agent)` without a service); `controller.py:1970` (`held.get(row['host'])`); `redo_governance.py:144–157` (worker widens scope to every service on the host).

A dirty rollback of `db.service` held the live check for `web.service`; a queued repair of one service made others wait. The legacy snapshot path in the same module is per service and the 2.0.8 notes describe host-wide scope only for maintenance grants. On a single VM this disables setup redo for every service until an operator verifies the one failure.

## R208-03 — Medium: the redo worker polls the controller ≈4×/s; Emergency Stop can be locked out

**Locations:** `setup.py:354–358, 717`; `desktop_jobs.py:126–132`; `controller.py:116`; `store.py:4804`.

`SetupRunner.paused()` runs on every 0.25 s scheduling iteration, and for a redo each call is a signed controller request. Measured: 4.0–4.6 signed checks/s during an apply (≈1,300 of the controller's 2,048 per-5-minute replay markers from one redo), ≈15,000 audit rows per hour, and ≈89 ms per check under the controller's global locks with 4,096 retained failures. When replay capacity is exhausted every operator request — including **Emergency Stop** — is refused with HTTP 503 for up to 5 minutes (reproduced). One redo alone stays below the cap; a redo plus ≈670 more operator requests in 5 minutes (e.g. a ≈85 MB recording export in 128 KiB chunks) reaches it.

## R208-04 — Low–Medium: copies of the operator signing key accumulate

**Locations:** `setup_redo.py:357`; `desktop_jobs.py:84`.

`redo-control.json` (operator origin, principal, epoch and HMAC token) is written before Setup admission. With local Setup paused but the controller not (e.g. the GUI's Emergency Stop reached the local pause but not the controller), each 15-second tick left a new 0600 copy and started nothing (5 ticks → 5 files). Finished jobs never removed theirs.

## R208-05 — Low: clean failures count toward a permanent bound

**Locations:** `store.py:6406–6413, 10583`.

`prune()` retains every failed `repair_service` action, and all of them — clean rollbacks and receipted recoveries included — count toward a 4,096-row bound whose overflow holds redo with no in-product release. Cost is ≈20 µs per retained row on every dashboard and check.

## R208-06 — Cosmetic

Operator-verified recovery closes incidents as `resolved_by_setup_redo` (`controller.py:3260`). With every service healthy the manual redo reports a missing scope while its completion text still describes redoing every service (`desktop_recovery.py:247`). In **Verify repaired redo holds…**, one refused request discarded the other services' results.

## R208-07 — Medium (found while correcting R208-05): history archival releases unresolved rollback holds

**Locations:** `controller.py:4515` (history storage always enabled); `controller.py:953` (`prune()` only without history); `history_storage.py:529–535`.

Production controllers never call `prune()`; history archival archives and deletes `failed` actions older than the retention age (30 days; 7 days once the database reaches 80 % of its 512 MiB ceiling, ≈8 hours at the measured ≈49 MB/h). Reproduced: a 40-day-old dirty failure was archived and its hold disappeared. This contradicts the 2.0.8 R207-03 statement that unresolved rollback holds do not expire through routine retention.

## Runtime measurements (2.0.8, packaged, TLS, one agent, 2 vCPU container)

Controller ≈5.7 % of one core and ≈71 MB RSS; agent ≈7 % and ≈46 MB; signed dashboard median ≈28 ms; controller database growth ≈49 MB/h (≈150 KB per 15-second observation). Installer 79.3 MB, unpacked 231 MB.

## Not established

No native VM, polkit, service pack, reboot, multi-host or competition acceptance. Windows code and GUI layout were not reviewed line by line.
