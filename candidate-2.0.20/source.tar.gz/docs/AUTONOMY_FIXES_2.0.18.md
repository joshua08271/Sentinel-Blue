# Sentinel Blue 2.0.18: stale stop requests, failed undos and undelivered restarts

2.0.18 fixes three problems:
- **Stale stop request.** A stop request left by a stopped or failed local session stopped the next start. This was found during the 2.0.17 review.
- **Bug 12** of the 2.0.15 autonomy review: a failed undo held Resume forever.
- **Bug 13**: restarts that were never delivered used up the failure budget.

Every other 2.0.17 behavior is unchanged. No approval, authentication, backup, ownership, baseline or offline requirement is relaxed.

## Stale stop request

**Before.** The GUI stops its local session by writing `stop-session.json`, and nothing ever removed it. After a Stop, or after a GUI start that failed and wrote its own stop, the next start of the same session stopped within a second of becoming ready.

**Now.**
- **Named requests.** A stop request names the runner it is for:
  - the GUI's **Stop** names the running session's `run_id`, which is now in `session-status.json`;
  - a GUI start names its own `launch_id`, which it passes to the runner, for the stops written by its failure paths.
- **Honoured once.** A runner stops only for a request that names it, and it removes the request once honoured.
- **Stale requests.** A request that names another runner can never apply, because that runner is gone. The runner removes it at start and whenever it sees one. A request that names no runner and is already there when the runner starts is also stale, since only one runner can hold the session, and is removed. One exception is kept: a request naming this launch, written by a GUI start that failed before its runner started, is honoured.
- **No lost Stop.** The runner clears leftover requests before it announces its `run_id`, so a Stop naming the new run is never cleared with them. It sets a request aside (renames it) before removing it, so a Stop written at the same moment is never removed unread.
- **During startup.** A stop for the current launch or run is also honoured while the session is still waiting for its controller to become ready. Before, it was honoured only after the agent had started.
- **Other sessions.** A request for another session is ignored and left in place, as before.
- **Leftover status.** A GUI start now reads only the status written by the runner it launched. Before, a `failed` or `running` status left by an earlier run could fail the next start with that run's reason. One case is kept: if the new runner exits because a running session still holds the lock, the GUI uses that session, as before. A runner that exits before writing any status is reported with its exit status.

**Still true.**
- A request written without a `run_id` or `launch_id`, the pre-2.0.18 format, still stops a session that is running when it is written, and is then removed.
- The GUI refuses its own Stop while its start is in progress. A Stop sent from a second GUI window in the half second before a new run announces itself names the previous run, and is removed as stale.

## 12. An undo that changed nothing no longer holds Resume

**Before.** When an operator's undo was refused before it changed anything, for example because the service had already stopped again, the result was still marked `review_required`. Resume of that service was then refused forever with "failed inverse requires evidence-based reconciliation before resume", and no reconciliation accepted it. The agent's undo hold on the service also stayed, because only a Resume clears it.

**Now.**
- **Refused before any change.** An undo is marked `review_required` only once it has begun changing the host. That point is when its journal is marked `undo_prepared`, just before the first change. An undo refused by its checks is an ordinary failure ("the undo changed nothing"): Resume works, and the agent's hold clears with it. The service history shows it as **Failed**.
- **Failed after it began.** Such an undo still holds Resume, because the host needs review. Resume's refusal now names the action. The GUI's review queue, on the **Alerts & verification** tab, shows it as **Review an undo that failed after it began**, with one choice, **Reviewed**, sent as a signed `/api/v1/actions/<id>/reconcile` request with `{"resolution": "reviewed"}`. The queue lists every failed undo awaiting review, not only those among the latest 100 actions.
- **Evidence the controller requires before accepting the review:**
  - the agent's latest observation was collected after the failure (placed on the controller's clock, erring towards "older"), is fresh (at most 90 s old on the agent's clock) and is sequenced;
  - it reports no self-health error. An interrupted change that the agent's own recovery has not finished reports one on every sample;
  - its diagnostic list is complete. A list truncated at the telemetry limit may have dropped that error, so it is refused. While a host's diagnostics overflow on every sample, the review waits; Resume's own check refuses such a sample anyway;
  - for a service undo, the service is in a known state: running or stopped. On Linux, systemd's `inactive` and `failed` also count as stopped.
- **What is recorded.** The action stays `failed`, and the agent's result is kept exactly as reported, so the agent's re-delivery of the same result is still acknowledged. The review and its evidence are kept beside it, in the same transaction as an audit record (`reconcile_failed_undo`). A repeated review returns `exact_retry`. The service history then shows **Reviewed**.
- **Kept until reviewed.** History archiving and pruning no longer remove a failed undo that awaits review. Before, removing it after the retention period (7 days or more) lifted the Resume hold without any review. Once reviewed, it follows ordinary retention. The review record itself is kept.
- **The agent finishes the undo itself.** The agent's recovery retries an interrupted change on every cycle. It now finishes an interrupted undo of an automatic start with restart permission alone, the permission that allowed the start. Before, it also needed restoration permission, so an agent run without `--allow-restoration` could never finish one: it reported a self-health error forever, refused all actions, and the review could never be accepted. A change that restored files still needs restoration permission to be finished.
- **Still true.** A later undo cannot be layered over a failed one, as before.

## 13. A restart no agent received no longer uses the failure budget

**Before.** When the agent was unreachable, an automatic restart that expired before any agent received it was recorded as a failed attempt. Three such outages used up the hourly failure budget. The service's next real outage was then held for up to an hour (`service_recovery_failed_attempt_hourly_budget_exhausted`, retry in 2355 s).

**Now.** An automatic restart or repair that expired before any agent received it costs no budget. It was never dispatched: no delivery attempt, no dispatch time. Automatic actions cancelled by Pause before delivery were already treated this way. When the agent returns, the next outage is restarted as usual.

Such an action is also not "later work" for an undo, which it no longer blocks, or for setup redo, which looks at the repair before it.

**Still counted:**
- a restart the agent received but never reported (`outcome_unknown`), which still holds that service until reconciled;
- a restart that ran and failed;
- an operator-queued restart that expired.

## Upgrade notes

- **Controller, agents and the GUI** must run the same release, as before.
- **Session status.** `session-status.json` gains `run_id`, and `launch_id` when the runner was started with one. The runner accepts an optional `--launch-id`, and the GUI passes it.
- **Leftover requests.** A `stop-session.json` left by 2.0.17 is removed when the session is next started, and does not stop it.
- **Dashboard.** The controller's dashboard gains `undo_reviews`, the failed undos awaiting review.
