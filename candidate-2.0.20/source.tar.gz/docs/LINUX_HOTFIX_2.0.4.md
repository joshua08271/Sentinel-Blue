# Sentinel Blue 2.0.4 — found by running it against a real systemd

**Status: untested on a competition VM.** 2.0.4 is 2.0.3 plus the fixes below.
Unlike 2.0.3, it was exercised end to end against a real systemd: the guided
local flow (workspace, session, approved setup, baseline, restore points)
ran through the product's own functions, and services were broken the way an
attacker or a bad change breaks them. That run found seven faults. Three of
them stopped all recovery on the host.

## How it was tested

The build machine has no systemd as PID 1, so a real systemd (Ubuntu 24.04,
systemd 255) was booted as PID 1 of a private PID and mount namespace, with its
own `/run`, `/tmp` and `/var/tmp`. Sentinel's controller, agent and setup jobs
ran inside it as root and managed real units: `redis-server.service`
(catalogued, adopt-only) and a custom HTTP service with its own configuration
file and unit. The script is in `tools/live_systemd_lab/`.

One thing was not real: this machine has no iproute2, so `ip` and `ss` were
small stand-ins that read the same kernel state from `/proc` and `ioctl`. Every
other command — `systemctl`, `nft`, `iptables` — was the real one.

## What broke, and what 2.0.4 does

| # | What happened on 2.0.3 | Effect | Fix |
|---|---|---|---|
| 1 | The agent keeps a floor of the controller it trusts in the host-wide ledger, keyed only by agent id. Every local session uses the agent id `local-linux`, so the second session on a VM — after *Change local choices*, or after upgrading — was refused as a "competing controller". | **Nothing ever ran again**: no restore points, so the baseline never finished, so no restart or repair. The window still showed services as healthy. | The floor belongs to the deployment that recorded it: agent id **and** approved profile. A restored or rival controller of the *same* deployment is still refused. |
| 2 | nftables prints `# Warning: table ip filter is managed by iptables-nft, do not touch!` on stderr for every table ufw, Docker or `iptables` owns. One `iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT` is enough. The collector called that a failed query. | Baseline approval refused, and **every restart and repair held** as "incomplete collection" — on any Ubuntu 24.04 host with a firewall rule, whoever added it. | That notice is accepted when the table it names is listed on stdout. Any other stderr is still a diagnostic. |
| 3 | A deleted unit file was planned for repair, then refused by the agent: systemd reports a unit with no file as not-found, which read as "state changed after diagnosis". | Deleting a unit file defeated repair. | When the repair restores that very unit file and it is still missing, the unit is the stopped unit the plan diagnosed. Rollback removes the file again and reloads. |
| 4 | That refusal reported `rolled_back: false`, which the setup redo read as a failed rollback and held. | Redo held when it should run. | A repair that started and could not undo itself is marked `review_required` (a field the result schema already has). Only that holds the redo. |
| 5 | Setup of a service that dies right after starting ended **uncertain**, not failed: systemd calls a simple unit active the instant it forks. | The uncertain transaction **held every later setup and all recovery**. The 2.0.3 setup redo produced exactly this when the damage was beyond setup. | After starting a service, setup watches it stay up for 3 seconds. A death in that window is an ordinary failed, rolled-back step. |
| 6 | The redo required a service to have been seen healthy during the session. One broken seconds after baseline approval never was. | Redo waited forever. | An approved baseline is that proof: approval is refused while any check fails. The baseline also now waits for custom services to be healthy. |
| 7 | The withdrawal adapter created the ledger's `file-restore` directory with the process umask (0755). Controller recovery capsules refuse any directory others can read. | **Controller backups never succeeded** on any host an agent had run on; "Recovery backups are not being written" never cleared. | Created 0700, and a 0755 one left by an earlier release is repaired on start. |

A fault in my own first attempt at #4 was also caught live: a new result field
was rejected by the controller's strict result schema, which left the action
"in progress" and held the agent. It never shipped; #4 uses the existing field.

## Live results on 2.0.4

| Scenario | Mode | Result |
|---|---|---|
| Configuration corrupted so the daemon exits | guarded | repaired automatically: file restored, restarted, checks stable |
| Unit masked, configuration corrupted (redis) | guarded | unmasked, enabled, file restored, running — 11 s |
| Unit file deleted | guarded | unit file restored, `daemon-reload`, started — 21 s (2.0.3: refused) |
| Configuration corrupted | approval-based | offered on Alerts & verification; nothing ran until approved; then repaired in 2 s |
| Program replaced with one that exits (outside every restore list) | guarded | repair failed and rolled back; setup redo ran the approved plan, failed cleanly and rolled back; recovery stayed live and repaired the service once the program was put back (2.0.3: redo left an uncertain transaction that froze all recovery) |
| Second local session on the same VM | — | baseline and restore points complete (2.0.3: never) |
| An `iptables -m state` rule present | — | baseline approved, recovery runs (2.0.3: held) |
| Controller recovery backups | — | written; state healthy (2.0.3: failing) |

## Upgrading

Nothing to migrate. A 2.0.3-or-earlier ledger floor no longer blocks a new
session, and a 0755 `file-restore` directory is repaired the first time 2.0.4
starts. A VM on which a 2.0.3 setup or redo already left an **uncertain** setup
transaction still has it: **Withdraw → Review** lists it as an interrupted
operation that needs reconciliation, and recovery stays held until it is
resolved. 2.0.4 does not create new ones for a service that dies on start.

## Evidence

| Check | Result |
|---|---|
| New tests, `tests/test_live_findings_204.py` | 18 tests, all pass; the ones for #1, #2, #3, #5 and #7 fail on 2.0.3 (#2 includes a real `iptables -m state` rule in a private network namespace) |
| Full suite with the bundled runtime | 2,062 tests; only the same 2 environment errors as 2.0.2 and 2.0.3 |
| Packaged checks | continuity 44/44, lifecycle, crash-resume and supervisor smokes, withdrawal check; the `.run` rebuilds byte-for-byte. The packaged runtime itself, with an `iptables -m state` rule present, repaired a deleted unit file and a masked, misconfigured redis at the same time in about 10 s |

**Still not established:** a full VM with a desktop session, the graphical
administrator prompt, the IPv6 firewall half (this kernel has IPv6 disabled),
and the configuration-generating service packs (their packages could not be
installed here). The redo's success path — setup fixing what repair could not —
needs a generated pack to show; only its failure path was run live.
