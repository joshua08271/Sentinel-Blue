# Sentinel Blue 2.0.2 — the firewall drops IPv6 too

Based on the unmodified 2.0.1 Linux GUI 1 source and runtime (`489277eb…`). One
module changes behaviour: `src/sentinel_blue/network_setup.py`, the compiler for
the `linux-router` recipe's nftables table. Nothing else in the program changes.

## What was wrong

The table is `table inet sentinel_blue_<name>`, so it filters IPv4 and IPv6. Both
of its drops were IPv4-only:

```
chain input {
  type filter hook input priority 10; policy accept;
  ...
  meta nfproto ipv4 drop        <- input_policy: drop
}
chain forward {
  ...
  meta nfproto ipv4 drop        <- forwarding: true
}
```

An IPv6 packet matched neither, fell to `policy accept`, and was delivered. Linux
enables IPv6 by default and most daemons listen dual-stack, so on a host set to
`input_policy: drop` every listening service stayed reachable over IPv6 — a
global address, or link-local from the same segment — while the reviewed plan
described a default-deny host.

## What 2.0.2 generates

```
chain input {
  type filter hook input priority 10; policy accept;
  iifname "lo" accept
  ct state established,related accept
  meta l4proto ipv6-icmp accept           new: before the invalid-state drop
  ct state invalid drop                   was IPv4-only
  ip protocol icmp accept
  ip  saddr 198.51.100.0/24 tcp dport 22 accept
  ip6 saddr 2001:db8:100::/64 tcp dport 22 accept     new: IPv6 sources
  drop                                    was: meta nfproto ipv4 drop
}
chain forward {
  type filter hook forward priority 10; policy accept;
  ct state established,related accept
  <IPv4 forward rules>
  drop                                    was: meta nfproto ipv4 drop
}
```

* **ICMPv6 is accepted.** Neighbor discovery, router advertisements and
  packet-too-big are ICMPv6. Dropping them does not filter IPv6, it breaks it, and
  a host that can't resolve its neighbours can't be reached even on allowed ports.
  It sits before the invalid-state drop so conntrack's view of it cannot matter.
  The IPv4 rule has always accepted ICMP; this is the same decision.
* **IPv6 sources are allowed in `management` and `allow`** and written `ip6 saddr`.
  Without them the fix would force an operator who needs a service reachable over
  IPv6 back to `input_policy: accept`, which is the hole again.
* **Routing stays IPv4.** `forward`, `masquerade`, `routes` and `addresses` still
  refuse IPv6 networks, and a forwarding router now drops IPv6 transit instead of
  passing it unreviewed.
* **`input_policy: accept` is unchanged** apart from invalid-state IPv6 packets now
  being dropped the way invalid IPv4 packets always were.
* **A number is not a network.** `ipaddress.ip_network(5)` returns `0.0.0.5/32`,
  and `True` becomes `0.0.0.1/32`, so a typed number used to be admitted as an
  address. `network()` now tests the type first.

The native applier needs no change: it loads the table with `nft --check` then
`nft --file`, and fingerprints what the kernel reports, so different rule text is
an ordinary approved update.

## Upgrading a host that already runs a Sentinel router table

Reapplying the approved plan replaces the table, and that is the fix taking
effect. **If you reach the management port over IPv6, add an IPv6 management
source before approving**, because the new table closes IPv6 access it does not
list. The existing rollback timer still applies: if the change cuts you off and
you cannot confirm it, it reverts on its own.

## Evidence

| Check | Result |
|---|---|
| New tests, `tests/test_linux_hotfix_202.py` | 11 tests; 10 pass here and the IPv6 connection test skips (see below). Against 2.0.1 they fail 10 of 11. |
| Every generated ruleset loads into a real kernel | yes — drop, accept, IPv6 allow, and forwarding with NAT |
| IPv4 through the new rules, real connections | blocked port blocked, allowed port reachable — identical to 2.0.1 |
| Full suite with the bundled runtime | 1,971 tests; the same 2 environment-only errors as 2.0.1 (`ss` absent; one test that needs a system Python) |
| Packaged checks | continuity 44/44, three smoke modes, withdrawal fixture |

**The IPv6 connection test could not run where this was built:** that kernel boots
with `ipv6.disable=1`, so no IPv6 socket can be opened at all. The IPv6 half is
established by the generated rules and by the kernel accepting them, not by a
live IPv6 connection. To see it on a VM with IPv6:

```sh
sudo unshare -n python3 tools/firewall_reachability.py .
sudo unshare -n python3 tools/firewall_reachability.py . with-ipv6-allow
```

`unshare -n` gives the tool a private network namespace containing only a
loopback interface; it refuses to run without one, and nothing on the host is
read or changed. Expected: port 8080 blocked over IPv4 and IPv6; port 8081
reachable over IPv4, and over IPv6 only with the IPv6 allow rule. Under 2.0.1
both ports answer over IPv6.

## Not changed

This is not a next-generation firewall. There is still no application
identification, packet-content inspection, IPS signatures, TLS inspection or
appliance integration, and firewall changes an attacker makes are still alerted
on rather than reverted.
