# Sentinel Blue 2.0.7 — additional independent Linux review

**Review only. Five additional confirmed issues; no code changes or new release.**

The same five findings reproduce in the unchanged source and exact packaged .pyz using bundled Python 3.13.15. They concern setup-redo permission/recovery gates and backup-loss diagnostic integration. The earlier five R206 fixes still pass their 89 focused regressions and 12 original reproduction/control assertions.

## Scope and interpretation

The tests use real private files, actual SQLite/controller policy, telemetry validation, backup capture/audit/restore, session-loop and job-admission code. Service/probe observations, approved setup artifacts and the clock are controlled fixtures. Controller, agent and setup-worker process launches in the new reproductions are inert handles. A job request that passes JobControl admission is not proof that all later native execution gates accept its mutations. No user VM, repository, firewall or native daemon was changed.

Prioritize R207-01 through R207-03 before relying on unattended setup redo. Emergency stop blocked new redo dispatch in the tested controls; a mode downgrade alone did not. This is not a claim that emergency stop cancels every already-running operation.

## R207-01 — High: Setup redo disregards an active authorized-change hold

**Locations:** `setup_redo.py:231–319, 361–425; controller.py:2460–2476`.

**Reproduction:** The real controller recognizes an active 600-second change grant and deliberately holds coordinated service repair. Its dashboard still reports the service unhealthy. The separate redo scheduler reads that health state but not the authorized-change/planner hold, so at 181 seconds on a controlled clock it admits and writes a setup-redo job while the grant remains active. No ordinary controller repair or restart is queued.

**Impact and qualification:** Automatic recovery can compete with a teammate’s approved maintenance. This is a reproduced job-admission defect, not a native overwritten-file demonstration: the process factory was inert and the target file was unchanged by Sentinel in this test. Later setup executors were not run.

**Controls:** The same fixture does not launch a job with automatic=False or with emergency stop active.

**Correction needed:** Carry authorized-change holds through the redo policy and revalidate them immediately before dispatch and before mutations. Treat deliberate policy holds differently from failed repair.

## R207-02 — High: Local redo keeps its startup autonomy setting after a mode change

**Locations:** `linux_workspace.py:763–783; setup_redo.py:231–244, 401–425`.

**Reproduction:** The actual run_session loop computes automatic_redo once from session.json. After a session starts guarded-autonomous, changing the real controller to approval-based or observe is visible in the next dashboard response but does not refresh that flag. Both cases still admit and write an automatic redo job.

**Impact and qualification:** Switching mode alone does not reliably stop this separate automation path. Ordinary repair policy is not shown to ignore the mode. The reproduction runs actual session-loop/control/store code with synthetic observations and inert controller/agent/worker process handles, not a native desktop click or service rewrite.

**Controls:** Keeping guarded mode launches as expected. Emergency stop prevents the launch even when the startup flag remains guarded.

**Correction needed:** Respect both original reviewed permission and current controller governance on every tick and at dispatch. A later downgrade must reduce permission, while a later upgrade must not silently widen the original approval.

## R207-03 — High: An incomplete-rollback hold expires solely with time

**Locations:** `setup_redo.py:47, 198–207, 299–319`.

**Reproduction:** A failed repair result with rolled_back=False, review_required=True and rollback-incomplete errors is initially held. The identical unresolved result becomes eligible and launches redo after the controlled clock advances 901 seconds: the 900-second recent-repair filter no longer applies.

**Impact and qualification:** The scheduler treats an old, unreconciled rollback failure like an ordinary persistent outage. This could request more setup work before ownership is reconciled. A synthetic failed-action result was used; this is not proof that a real host ledger subsequently accepts the mutation.

**Controls:** An outcome_unknown action remains held; a cleanly rolled-back failure is retryable.

**Correction needed:** Retain unresolved rollback/ownership holds until explicit authenticated reconciliation or superseding verified recovery, not until a timer expires.

## R207-04 — Medium: Lost manifest authority still produces a “verified repair plan” offer

**Locations:** `telemetry_diagnostics.py:18, 36–51; detection.py:601–608; controller.py:2158–2174`.

**Reproduction:** After a real approved capture, removing the metadata authentication key—or both authenticated metadata snapshots—causes audit_backups to report manifest loss and an explicit restoration hold. The actual telemetry merge/validator/controller receives those diagnostics. Nevertheless, its approval-based alert says “Service has a verified repair plan.” The controller only intersects repair file paths with the lost manifest path, so no match occurs.

**Impact and qualification:** The offer is misleading and cannot perform the advertised restoration. The actual restore operation correctly refuses and preserves the changed live file. This is NOT a bypass of authenticated restoration, and the new metadata-loss warning itself works.

**Controls:** Ordinary short-path content-blob loss suppresses the repair offer. Recoverable manifest loss with intact authority rebuilds metadata/content and restores trusted bytes.

**Correction needed:** Represent missing manifest authority as a scoped structured capability failure and block affected file-restoring repair offers, without blocking unrelated services unnecessarily.

## R207-05 — Medium: Diagnostic truncation loses the identity of an unavailable backup

**Locations:** `telemetry_diagnostics.py:36–58; detection.py:601–608; controller.py:2160–2174`.

**Reproduction:** A real captured file with a 307-character path loses both content backups and its live contents change. The audit correctly names the complete path. Diagnostic normalization clips the entire message to 256 characters. lost_restore_points then parses that shortened human-readable string as the file identity, so it no longer equals the full repair path. A verified-repair offer appears despite the missing backups.

**Impact and qualification:** Nested paths can bypass the controller’s unavailable-restore-point offer suppression. This establishes incorrect warning-to-policy association, not a successful restore without backup data.

**Controls:** The equivalent short-path backup-loss case suppresses the offer.

**Correction needed:** Send bounded structured file identifiers/digests separately from display text. Never use a truncated diagnostic string as the authoritative path key.

## Measured validation

| Campaign | Result |
|---|---|
| Prior 2.0.7 fix regressions, exact package | 89 passed; no failures/errors/skips |
| Prior defect reproductions and controls, exact package | 12 passed |
| Full unchanged source suite, bundled Python, virtual display | 2,267 run; 2,248 passed; 19 skipped; no failures/errors |
| Selected unchanged exact-package regressions | 887 run; 882 passed; 5 skipped; no failures/errors |
| New source correctness assertions | 16 run: 7 failing assertions expose 5 findings; 9 controls pass |
| Same new exact-package assertions | Same 7 failures and 9 passing controls |

Counts overlap. New failures are desired-correctness checks on intentionally unmodified code, not tests of implemented fixes. Approval/observe mode and two kinds of metadata-authority loss account for the extra assertions. See the JSON for exact original suite skip reasons; native-only skips are not passes. The review’s initial full-suite invocation error is retained separately and is not included in the completed run’s count.

## Integrity and remaining acceptance

All 5,329 offline payload checksums verified. All 129 application source members match, and 126 Python modules parse. Installer and standalone application match. The review-only launcher verification passed with invalid ambient Python settings. This pass did not repeat an actual GUI-window/polkit, kernel network-denial, installer rebuild, live service recovery, reboot, endurance or competition campaign. Those are distinct from the prior release’s reported validation.

All 9 initially fingerprinted release inputs and 394 original source files retain their bytes; source permissions also match. No original script was modified.

## Reproduce

Run in a disposable local review environment with the provided source and its bundled interpreter:

```bash
/path/to/bundled/python3 -I -B reproduce_207_review.py \
  --source /path/to/2.0.7/source \
  --runtime /path/to/sentinel-blue-2.0.7-linux-gui1.pyz \
  --output measured.json --assert-correctness
```

On unchanged 2.0.7, seven assertions fail and nine controls pass. Omit --runtime to exercise source. The fixtures do not deploy a daemon.

## Original source excerpts

### src/sentinel_blue/setup_redo.py:231–244

```text
231: 
232: 
233: def assess(snapshot: dict[str, Any], record: dict[str, Any] | None, state: dict[str, Any], now: float,
234:            *, agent: str = AGENT) -> dict[str, Any]:
235:     """Decide, for every service of this VM, whether a redo is due. Updates `state` timers."""
236:     result: dict[str, Any] = {"blocked": None, "units": {}}
237:     governance = (snapshot.get("controller") or {}).get("governance") or {}
238:     if record is None:
239:         result["blocked"] = "no approved local setup is recorded; approve setup on this VM first"
240:     elif governance.get("emergency_stopped"):
241:         result["blocked"] = "emergency stop is enabled"
242:     elif _job_running((state.get("running") or {}).get("job")):
243:         result["blocked"] = "a setup redo is already running"
244:     elif _job_running(record["original_job"]):
```

### src/sentinel_blue/setup_redo.py:287–320

```text
287:         if unit not in seen and not baseline_approved:
288:             verdict["reason"] = "not yet seen healthy in this session; setup itself has not finished"
289:         elif reason.startswith(futile):
290:             verdict.update(status="held", reason=f"setup cannot fix this: {reason}")
291:         elif str(native).casefold() in TRANSITIONAL:
292:             # Setup refuses a unit systemd is still starting, stopping or
293:             # reloading; running it now would only fail. Wait for it to settle.
294:             verdict["reason"] = "the service manager is still changing its state"
295:         elif repair and repair.get("status") == "outcome_unknown":
296:             verdict.update(status="held", reason="the last repair's outcome is unknown; review it first")
297:         elif repair and repair.get("status") in IN_PROGRESS:
298:             verdict["reason"] = "a repair is in progress"
299:         elif (repair and repair.get("status") == "failed" and _rollback_failed(result_row)
300:               and now - (repair.get("completed_at") or 0) < REPAIR_WINDOW_SECONDS):
301:             verdict.update(status="held", reason="the last repair did not roll back cleanly; review before any further change")
302:         elif (repair and repair.get("status") == "failed"
303:               and now - (repair.get("completed_at") or 0) < REPAIR_WINDOW_SECONDS):
304:             verdict.update(status="eligible", reason=("repair failed and was rolled back: " if result_row.get("rolled_back")
305:                                                       else "repair could not be applied: ")
306:                            + str(result_row.get("message", ""))[:200])
307:         elif native == "unknown":
308:             first = missing.setdefault(unit, now)
309:             if now - first >= MISSING_GRACE_SECONDS:
310:                 verdict.update(status="eligible", reason="the unit is no longer present on this host")
311:             else:
312:                 verdict["reason"] = "the unit is missing; waiting to confirm"
313:         elif now - since >= UNREPAIRED_GRACE_SECONDS and not (
314:                 repair and now - (repair.get("created_at") or 0) < UNREPAIRED_GRACE_SECONDS):
315:             verdict.update(status="eligible", reason="unhealthy for three minutes and repair could not fix it")
316:         else:
317:             verdict["reason"] = "waiting for repair"
318:         if verdict["status"] == "eligible":
319:             recent = [item for item in history if _history_covers(item, unit)
320:                       and now - item["at"] < UNIT_COOLDOWN_SECONDS]
```

### src/sentinel_blue/setup_redo.py:395–425

```text
395:     eligible = sorted(unit for unit, row in verdict["units"].items() if row["status"] == "eligible")
396:     for unit in list(eligible):
397:         if _task_for(record, unit) is None:
398:             verdict["units"][unit].update(status="held", reason="no task of the approved setup covers it, "
399:                                           "so a redo cannot fix it")
400:             eligible.remove(unit)
401:     if automatic and eligible and verdict["blocked"] is None:
402:         original = _job_result(record["original_job"]) or {}
403:         if original.get("status") not in {"passed", "ready"}:
404:             # 2.0.6: a service whose own approved task finished is still redone
405:             # automatically when an unrelated task of the same setup failed; the
406:             # redo runs only that service's tasks.
407:             finished = [unit for unit in eligible if _original_task_ready(record, unit) is True]
408:             for unit in eligible:
409:                 if unit not in finished:
410:                     verdict["units"][unit].update(status="held", reason="its approved setup task did not finish "
411:                                                   "successfully, so it is not redone automatically")
412:             eligible = finished
413:             if not eligible:
414:                 verdict["blocked"] = "the approved setup did not finish successfully, so it is not redone automatically"
415:         if eligible and verdict["blocked"] is None:
416:             try:
417:                 verdict["launched"] = launch_redo(workspace, record, state, eligible,
418:                                                   "; ".join(f"{u}: {verdict['units'][u]['reason']}" for u in eligible),
419:                                                   now=now, launcher=launcher)
420:                 return verdict
421:             except Exception as exc:          # a paused Setup, a busy disk: say so, keep monitoring
422:                 state["last"] = "redo not started: " + str(exc)[:300]
423:     save_state(workspace, state)
424:     verdict["last"] = state["last"]
425:     return verdict
```

### src/sentinel_blue/linux_workspace.py:760–786

```text
760:         children.append(agent)
761:         receipt('running', 'Controller ready; waiting for fresh agent telemetry.')
762:         from . import setup_redo
763:         automatic_redo = config.get('autonomy') == 'guarded-autonomous'
764:         next_redo_check = time.monotonic() + setup_redo.TICK_SECONDS
765:         while not stopped:
766:             stop_path = directory/'stop-session.json'
767:             if stop_path.exists():
768:                 request = read_private_json(stop_path, 4096)
769:                 if request.get('session_id') == config['session_id']:
770:                     break
771:             if any(child.poll() is not None for child in children):
772:                 raise RuntimeError('A local monitoring process exited. Reconnect or inspect the saved session before restarting.')
773:             if time.monotonic() >= next_redo_check:
774:                 next_redo_check = time.monotonic() + setup_redo.TICK_SECONDS
775:                 # When repair cannot fix a service, run its approved setup
776:                 # again (guarded mode), or keep the evidence the Recovery tab
777:                 # uses to offer it (approval mode). Never ends the session.
778:                 try:
779:                     setup_redo.tick(directory, client.dashboard(), automatic=automatic_redo,
780:                                     close_incident=lambda agent, service: client.request(
781:                                         f'/api/v1/agents/{agent}/services/recovered',
782:                                         {'service': service, 'source': 'setup_redo'}))
783:                 except Exception:
784:                     pass
785:             time.sleep(.3)
786:         receipt('stopping')
```

### src/sentinel_blue/controller.py:2458–2476

```text
2458:                 if len(states) == 1 and (states[0].get("state") != "running" or local_failed):
2459:                     coordinated_paths.update(manifest.get("repair_policy", {}).get("restore_files", []))
2460:         for service, parameters in list(service_recoveries.items()):
2461:             if "repair" not in parameters:
2462:                 continue
2463:             held = False
2464:             for item in parameters["repair"]["restore_files"]:
2465:                 material = "\x00".join((str(item["observed_sha256"]) if not item["observed_missing"] else "__missing__",
2466:                                         str(item["observed_security_descriptor_sha256"] or "__missing__")))
2467:                 if self.store.consume_change_grant(agent_id, item["path"], hashlib.sha256(material.encode()).hexdigest(), binding=binding):
2468:                     held = True
2469:             if held:
2470:                 service_recoveries.pop(service)
2471:                 self.service_recovery_planner.hold(agent_id, service, "approved change grant holds coordinated repair",
2472:                                                    reset_confirmations=False)
2473:                 continue
2474:             features = {"probe_failure": 1.0, "integrity_change": float(bool(parameters["repair"]["restore_files"]))}
2475:             detected.append(ModelBoundAlertCandidate(
2476:                 kind="service_repair_required", title="Service has a verified repair plan",
```

### src/sentinel_blue/telemetry_diagnostics.py:8–59

```text
8: MAX_DIAGNOSTICS = 256
9: VALID_SOURCES = frozenset({"unknown", "payload_fingerprint", "network_inventory", "restore_points"})
10: # Gaps in these collectors leave no hole in the evidence service recovery uses
11: # (service state, files, checks, listeners, capacity, accounts). They cost drift
12: # detection for firewall, routes, neighbors and interfaces, and are reported,
13: # but they must not hold a restart or repair. Before 2.0.5 they did: one nft
14: # warning, or a host without iproute2, disabled all recovery.
15: # A lost restore point is reported (and alerted) but costs only the repair of
16: # that one file; holding every other service's recovery for it would repeat the
17: # pre-2.0.5 mistake.
18: RECOVERY_INDEPENDENT_SOURCES = frozenset({"network_inventory", "restore_points"})
19: 
20: 
21: class DiagnosticIssue(str):
22:     """A diagnostic whose provenance is its type, never its text."""
23:     source = "unknown"
24: 
25: 
26: class NetworkInventoryIssue(DiagnosticIssue):
27:     """A firewall, route, neighbor or interface collection gap."""
28:     source = "network_inventory"
29: 
30: 
31: class RestorePointIssue(DiagnosticIssue):
32:     """A restore point whose backup bytes were deleted or rebuilt."""
33:     source = "restore_points"
34: 
35: 
36: def restore_point_issues(report):
37:     """Diagnostics for one audit_backups() report."""
38:     issues = [RestorePointIssue(f"restore point lost: {path}") for path in report.get("lost", [])]
39:     issues += [RestorePointIssue(f"restore point rebuilt: {path}") for path in report.get("rebuilt", [])]
40:     issues += [RestorePointIssue(f"restore manifest metadata: {message}")
41:                for key in ("metadata_errors", "metadata_notices") for message in report.get(key, [])]
42:     return issues
43: 
44: 
45: def recovery_blocking(telemetry, *, allow_payload=False):
46:     """The diagnostics that make this sample incomplete evidence for recovery."""
47:     errors = telemetry.get("collector_errors") or []
48:     sources = telemetry.get("collector_issue_sources")
49:     if not isinstance(sources, list) or len(sources) != len(errors):
50:         return list(errors)
51:     ignored = RECOVERY_INDEPENDENT_SOURCES | ({"payload_fingerprint"} if allow_payload else set())
52:     return [error for error, source in zip(errors, sources) if source not in ignored]
53: 
54: 
55: def _clean(error):
56:     text = "".join(c if ord(c) >= 32 or c in "\t\r\n" else "\ufffd"
57:                    for c in str(error)).strip()
58:     return (text or "collector failed without detail")[:256]
59: 
```

### src/sentinel_blue/detection.py:601–608

```text
601: def lost_restore_points(telemetry: dict[str, Any]) -> set[str]:
602:     """Files whose restore point, and its second copy, this report says are gone."""
603:     errors = telemetry.get("collector_errors") if isinstance(telemetry, dict) else None
604:     sources = telemetry.get("collector_issue_sources") if isinstance(telemetry, dict) else None
605:     if not isinstance(errors, list) or not isinstance(sources, list) or len(errors) != len(sources):
606:         return set()
607:     return {error.removeprefix("restore point lost: ") for error, source in zip(errors, sources)
608:             if source == "restore_points" and isinstance(error, str) and error.startswith("restore point lost: ")}
```

### src/sentinel_blue/controller.py:2155–2175

```text
2155:                 continue
2156:             # Found live on 2.0.6: with a file's restore point and its second
2157:             # copy both deleted, this was still offered as "a verified repair
2158:             # plan" and failed the moment it was approved. The restore point
2159:             # alert names the file; a setup redo rebuilds files setup writes.
2160:             from .detection import lost_restore_points
2161:             if {item.get("path") for item in parameters["repair"]["restore_files"]} & lost_restore_points(payload):
2162:                 continue
2163:             repairable.add(service)
2164:             features = {"probe_failure": 1.0,
2165:                         "integrity_change": float(bool(parameters["repair"]["restore_files"]))}
2166:             detected.append(ModelBoundAlertCandidate(
2167:                 kind="service_repair_required", title="Service has a verified repair plan",
2168:                 summary=f"{service} can be repaired: restore its approved configuration and startup, "
2169:                         "then restart and validate it.",
2170:                 severity="high", confidence=0.9, model_features=features,
2171:                 evidence={"service": service},
2172:                 recommendation="Approve to restore this service's approved files and startup mode, restart it, "
2173:                                "validate its check, and roll back on failure.",
2174:                 recommended_action="repair_service"))
2175:         # A repair includes the restart, so the bare restart recommendation for
```

