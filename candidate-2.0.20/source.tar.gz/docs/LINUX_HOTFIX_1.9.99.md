# Sentinel Blue 1.9.99 — Linux hotfix 21–25

This incremental source/runtime correction is based on the unmodified 1.9.98
source archive and its exact runtime. It retains the earlier 1–20 corrections.
No repository, cloud, live service, firewall or routing configuration is changed
by this delivery. Native acceptance remains outstanding.

## 21. Recoverable router confirmation

Confirmation now records a hash-chained intent binding the pending native state,
the admitted exact object snapshot and the intended committed state. The durable
ledger commit is the confirmation decision. It precedes timer cleanup and native
committed-state publication. A failed timer stop no longer publishes an unauthenticated
committed native state. The still-pending native record and intent are retained.

Every mutating router entry reconciles an unfinished, authenticated committed
decision before proceeding. Confirmation retry, the timer callback, apply and boot
can complete cleanup/publication. An interruption before the ledger commit leaves
the action applied and the rollback timer armed; ordinary rollback or expiry can
still restore and cancel it. Confirmation is never inferred from a mutable status.

Reconciliation compares the exact original pending/committed state and current
owned object evidence. A changed file, metadata, revision, policy, inverse or
lifecycle record holds instead of being adopted. Boot may recover missing volatile
network objects only after its persistent helper authentication. A nonzero timer
stop is an error. The generic ledger lifecycle rules are unchanged; completion
receipts do not replace withdrawal snapshots. A completed confirmation is idempotent.

The durable commit is a decision, not proof that systemd cleanup already finished.
After a post-decision error, retry the same confirmation to finish it. A timer
rollback callback must not undo an already authenticated committed decision.
Emergency Restore & Withdraw remains the explicit inverse of committed changes.

## 22. Guarded, single metadata restoration during withdrawal

The native inverse already restores content and metadata. The adapter no longer
opens and re-writes metadata a second time. The native inverse rechecks its completed
per-object receipts after final service-control callbacks; the adapter additionally
compares the exact produced file revisions and the full restored semantic state.
A late chmod, group/attribute edit, same-content rewrite or symlink substitution is
preserved and withdrawal is held, not reported successful. A clean reverse chain
still restores the original objects and metadata. A legacy forwarding-only record
with no files remains supported; missing proof cannot authorize nonempty file work.

## 23. Platform-scoped pathname identity

Linux executable and persistence pathname identity preserves case. Distinct
`worker`/`Worker` and `Backup`/`backup` entries cannot suppress one another's
specific detections. Windows retains its case-folded comparison, selected from
telemetry platform rather than the controller's own OS. Unknown platform identity
preserves spelling conservatively. This is not a full filesystem identity resolver
or a guarantee of detection of arbitrary persistence mechanisms.

## 24. Unknown firewall evidence stays unknown

Failed provider queries return unknown (`enabled: null`) plus sanitized coverage
diagnostics instead of a fabricated disabled state. Optional missing providers
may be skipped; failure of an earlier provider cannot be disproved by an empty
fallback. Explicit successful nonempty/empty observations remain distinguishable.
The detector requires the boolean transition true -> false for a disabled alert.
Unknown, absent or malformed values do not satisfy that condition. The telemetry
validator now accepts and preserves unknown; malformed nonbooleans still refuse.
Provider selection and rules-presence heuristics are not a universal firewall
policy evaluator. Native-provider behavior still needs distribution acceptance.

## 25. Bounded complete service-detail queries; no invented zero counts

Up to 2,000 returned loaded units are queried in argv batches of at most 512 under
one shared 20-second detail budget. Initial loaded-unit and startup-mode queries
retain their separate 15-second limits. Missing, failed, late, malformed or duplicate
metadata produces coverage diagnostics; useful earlier batches remain available.
The overall 2,000-service inventory limit is unchanged.

Unknown restart counts are null, missing native result is `unknown`, and missing
exit status is null. Unloaded installed units are not loaded merely to inspect
metadata: their unobserved fields remain unknown. Explicit nullable restart counts
survive the controller validator. Legacy omitted restart fields retain their prior
wire default; malformed supplied numbers still reject. Detection and repair evidence
do not calculate a fabricated zero-based delta from an explicit unknown count.

## Validation and scope

See the separately delivered `Sentinel_Blue_1.9.99_Linux_Fixes_21-25.md`, evidence
JSON and validation logs for measured final counts and artifact hashes. The matching
source contains the original tests plus new regression fixtures. Use the source and
runtime together; the runtime intentionally excludes private test tools.

Fixtures use real private root-owned files/ledgers with modeled native systemd,
nftables, route and address commands; telemetry uses controlled provider output.
No live VM reboot, native systemd cycle, live firewall/routing mutation, cloud
or remote-host acceptance is implied. No native catalog flag or acceptance receipt
is upgraded. Thread deadlines and file guards do not bound arbitrary kernel stalls
or offer atomic compare-and-swap against arbitrary racing privileged writers.

## Upgrade and recovery

Reapprove `release.version` and the delivered SHA-256 in real event profiles, then
regenerate setup plans. Only the unapproved example is repinned here. Update the
controller before or with the agents: older controllers may reject the new explicit
nullable restart count or unknown firewall value.

Replacing a desktop/runtime does not rewrite generated scripts, installed native
router/witness helpers or pending rollback timers. Reconcile pending transactions
with their matching preserved helpers and authenticated evidence before upgrading
helpers. Preserve the ledger, exact snapshots and completion/conflict records.

An existing 1.9.98 committed-native/applied-ledger mismatch without the new bound
confirmation intent is NOT silently promoted or cleared. It requires explicit
recovery from preserved authenticated evidence. This patch prevents/reconciles
new interruptions; it does not invent missing history or weaken ownership guards.
The existing launcher still requires Python 3.11+, Tk and cryptography.

## Reproduction

Only on authorized disposable infrastructure, from the matching source root:

```sh
env -u DISPLAY -u WAYLAND_DISPLAY PYTHONPATH=.:src:tests python3 -m unittest discover -s tests -t tests -v
PYTHONPATH=.:src:tests python3 -m unittest test_linux_hotfix_1999 -v
PYTHONPATH=. python3 tools/build_defensive_release.py --output ../build
```
