# Sentinel Blue 1.9.95 — Linux fixes 1–4

## Scope

Based on the uploaded 1.9.94 source. Linux runtime and shared Linux execution paths
are patched; this release does not add features or correct review issues 5–8.
Historical test counts and acceptance reports do not validate this build.

## Corrections

1. Generated Linux service recipes now retain private before/backup/post-state
   receipts and guard rollback using file bytes, ownership, mode, extended
   attributes, and revision. All declared files are checked before undo starts;
   changed or uncertain objects hold rollback and retain snapshots/resource claims.
   The outer transaction recognizes the inner rollback hold and cannot adopt the
   third state as Sentinel-owned. Ordinary outer rollback also rechecks at writes.
2. Linux account/session/service queries catch subprocess failures; each Linux
   collection section has a safety boundary. Missing sections report incomplete
   coverage, and the existing service-recovery gate rejects it. The agent cycle
   catches SubprocessError, clears stale accepted telemetry, redacts command details,
   and continues collecting on subsequent cycles.
3. Timed-out POSIX command groups receive TERM then KILL after the cleanup grace,
   even if the parent exits first. The leader is not reaped before the last group
   signal, preserving its group identity. Timeout remains an uncertain outcome.
4. Pending router forwarding writes use durable intent and observed post-state
   receipts. A setting that Sentinel never changed is never restored. Missing or
   ambiguous ownership is held; current values are checked before rollback writes.
   Long-lived withdrawal derives the inverse from authenticated ledger snapshots,
   retaining the previously supported committed/legacy path.

## Upgrade and retained state

Review release.version and release.sha256 in your real event profile. The example
inventory is unapproved and its placeholder hash is not a deployment approval.
Rebuild/reapprove plans from the new runtime; old scripts still contain old logic.
Existing pending router transactions and installed native.py helpers need explicit
reconciliation/upgrading on the host; replacing the runtime alone does not patch
an already running timer/helper. Never erase transaction/withdrawal ledgers to get
past a hold. Private backups and ownership receipts remain on the host.

The Linux ZIP retains its existing launcher workflow and requires system Python
3.11+, Tk and cryptography. The embedded file guard uses /usr/bin/python3 with the
standard library only; no third-party package is added by this patch.

## Limits

No native service manager, remote SSH/Azure, reboot or network mutations were tested
by this local patch campaign. Local file/process tests and mocked command tests do
not establish full competition reliability. The file/sysctl checks are not atomic
compare-and-swap against arbitrary racing privileged writers. Process cleanup is
for descendants remaining in the owned POSIX group; a process that escapes into a
new session/group, an uninterruptible kernel wait, or a remote process needs native
supervision/cgroup/remote-observer validation. The timeout result remains uncertain.
Issues 5–8 (UDP coverage, config ownership, the original transaction FIFO read, and
same-process thread ledger deadline handling) remain outstanding. The new guard's
nonblocking reader does not repair those pre-existing readers elsewhere.

See the accompanying 1.9.95 patch report and measured test evidence for results
actually obtained in this campaign. Every native acceptance flag remains false.

## Local validation for the delivered build

The final headless full suite ran 1,427 tests: 1,399 passed, 28 skipped, no failures
or errors. It includes all 38 newly added regression methods. The skips require a
graphical display, native Windows, or native systemd. A separate run against the
built zipapp ran 266 tests: 265 passed and one graphical test was skipped. Counts
overlap; neither pass ratio is a service-uptime measurement. All 116 packaged
source members match the delivered source; the runtime rebuilt identically twice.
The runtime/test sources were frozen during the final suite; this documentation
summary was added after results were obtained, without changing tested code.
