# Sentinel Blue 2.0.6 — the issues left after 2.0.5, and twelve more found live

**Status: untested on a competition VM.** 2.0.6 is 2.0.5 plus the fixes below.
Like 2.0.5 it was run end to end against a real systemd (Ubuntu 24.04,
systemd 255, booted as PID 1 of a private namespace; `tools/live_systemd_lab/`).
This time three configuration packs ran live — Redis, **PostgreSQL 16** and
**gunicorn** (a pack that creates a new unit) — in both approval-based and
guarded mode, together with two custom services, a red-team batch across four
services, deleted backups, and the controller's boot registration.

## Part 1 — the issues listed as open after 2.0.5

| # | Issue in 2.0.5 | 2.0.6 |
|---|---|---|
| 1 | Three "Existing persistence requires inventory review" alerts were open at once, one per change in the number of startup entries. | One per host; later changes add occurrences to it. |
| 2 | On a single VM, Withdraw ended "held" with no explanation, and the way back (`withdraw-release`) was a command only. | The Withdraw tab explains the held result (no separate observer; what was still reversed) and shows the operation id. **Allow Sentinel on this VM again…** checks, asks, and records the release. |
| 3 | The Services tab's Recovery column clipped its words. | Wider. |
| 4 | A restore point had one copy; deleting it lost the repair. | A private second copy in the ledger directory (`restore-mirror`, 0700, root). The audit rebuilds a deleted restore point from it, or from a file that still matches; a rolling content check catches a same-size substitution; repair reads the copy when the blob is gone. |
| 5 | A setup redo reran the whole approved setup, so one unrelated failed task blocked or failed every redo. | A redo runs only the affected services' tasks and what they require; tasks not chosen are "not-selected". A service no task covers is not redone. |
| 6 | Only the local session could redo a setup. | The desktop remembers an approved network setup and redoes a failed host's service (automatically in guarded mode, offered in approval mode). |
| 7 | The PostgreSQL pack accepted only PostgreSQL 17+ (Ubuntu 24.04 ships 16) and wrote `include 'sentinel-pg-hba.conf'`, which PostgreSQL reads as a file name with quotes and refuses to start. | 10 and later accepted; the include is double-quoted (checked on a real PostgreSQL 16); HBA rules below 16 are refused with the reason. |
| 8 | Catalog entries that name a folder (`/etc/postgresql` and six others) gave an adopted service no files to repair. | A folder stands for its regular files (shallowest first, no links, at most 64, each ≤ 1 MiB). |
| 9 | Two packs in one plan exceeded the plan's total size. | The apply payload travels only in the apply phase; a plan still too large is refused when compiled, with the reason. |
| 10 | The launch test needed a system Python. | Runs under `/usr/bin/python3` when the suite runs on the bundled runtime. |

## Part 2 — found by running 2.0.6 live, and fixed

| # | What happened | Effect | Fix |
|---|---|---|---|
| a | The review built a pack's parent files in the order the form filled them; the setup job, reading the saved key-sorted inventory, built them the other way round. | **Every setup with PostgreSQL's two parent files was refused** ("Configuration changed after review"). | Pack options are built from their canonical form, and the review compiles exactly what it saves. |
| b | Ubuntu ships `pg_hba.conf` as 0640; the pack wrote parent files 0644 unless told otherwise, and refused to widen it only when the approved setup ran. | PostgreSQL could not be configured. | At review, each activated parent file keeps the widest pack mode no wider than its current one. The refusal names the file and both modes. |
| c | Redis (6379) and PostgreSQL (5432) were both checked by TCP on 127.0.0.1; both results were named "127.0.0.1". | **Both stayed "unverified"; the baseline could never be approved.** Closing one service's incident could also close the other's failed check. | An unnamed check is named by its target and port (`127.0.0.1:6379`), in the agent and every reader; incidents close by that name. |
| d | The PostgreSQL check ran `pg_conftool 16 main show`, which prints its usage and exits 1. | **Every PostgreSQL setup failed.** | `show all`, which also fails on a bad line in `conf.d`. |
| e | `postgresql.service` is a wrapper that stays "active (exited)" and starts `postgresql@16-main.service`. | Read as "active", which nothing treats as up: **PostgreSQL could never be baselined or repaired.** A cluster that failed to start left the wrapper active, so setup reported ready. | A unit that stays active by design (`RemainAfterExit=yes`) is up. Setup also waits for `postgresql@<version>-<cluster>.service`; a cluster that does not come up is a failed, rolled-back step. |
| f | Repairing or redoing `postgresql.service` restarted its cluster. | The cluster's "not running" alert stayed open; so did the failed automatic repair a later fix superseded. | An instance (`name@…`) running again after a verified repair or redo of its parent closes; so does the superseded failure. |
| g | A file's restore point and its copy were both deleted and the file changed. | Approval mode still offered "a verified repair plan", which failed on approval. | Not offered while the restore point is lost; the restore-point alert names the file. |
| h | The redo was refused for a corrupted owned file ("differs from the reviewed before/after hashes"): a setup step changes a file only from its reviewed before-state. | **The redo could never fix what repair could not** (deleted backups plus a damaged file). | A redo (bound at run time, not part of the plan) may replace a file its approved step owns in any state; the damaged bytes stay in the step's record and the ledger. Live: back in 22 s. |
| i | After `systemctl stop sentinel-blue-controller`, removing the boot registration was refused as "changed after inventory" and recorded a conflict. | The registration was then **neither listed nor removable**; Withdraw had the same fault. | Its running state may differ; everything Sentinel installed must still match. A registration held by the old fault is released and removed when that is all that differs. |
| j | The gunicorn pack wrote `WorkingDirectory="/srv/app"`; systemd does not unquote it ("path is not absolute"). | The unit never loaded. | Unquoted, with plain path characters only. |
| k | A step that created a unit which then failed to start stopped it after removing its file ("not loaded"). | **The step ended uncertain and held every other setup task on the host**, and left its enable link behind. | A unit the step created is stopped and disabled before its file is removed. Checked on the real systemd; fails before the fix. |
| l | The gunicorn pack's unit, unit file, enable link and listener were raised as "new" during setup. | Four alerts about Sentinel's own reviewed change stayed open after approval. | Closed once the approved baseline holds exactly them and they belong to a service of the profile. Anything else, including an item planted before approval, stays open. |

## Live results on 2.0.6 (real systemd)

| Scenario | Mode | Result |
|---|---|---|
| Setup: Redis and PostgreSQL by their packs, two custom services | approval | all ready in 17 s after fixes a–e; baseline approved |
| PostgreSQL `conf.d` file corrupted, cluster down | approval | offered, approved, repaired in 6 s |
| All 21 restore points deleted, scoreboard file defaced | approval | all 21 rebuilt from the second copy within one cycle; repair approved, 5 s |
| Both copies deleted, public-page file changed | approval | reported lost (high); put back by hand → rebuilt, alerts closed |
| Redis's generated file corrupted (`Restart=always` loop) | approval | approved, repaired in 3 s |
| PostgreSQL broken | guarded | repaired in 9 s; cluster alert closed |
| PostgreSQL file corrupted and both backups deleted | guarded | repair fails plainly, redo replaces the file, back in 22 s, all 7 alerts closed |
| gunicorn pack (new unit) | guarded | ready; unit file deleted and service stopped → repaired in 7 s |
| Red-team batch: Redis masked and misconfigured, PostgreSQL HBA rules corrupted, gunicorn disabled and stopped, scoreboard defaced | guarded | all four repaired within 19 s; the mask and new links stay open as evidence |
| Controller boot registration | — | install → verified start → crash restart → stop → status → remove; remove while running |
| A real uncertain step (gunicorn before fix k) | — | Reconcile: "nothing it began remains changed" |

## Upgrading

Nothing to migrate. A new session is needed for new checks and packs (a new
runtime always requires one). A boot registration held by the fault in i is
released by `sudo sentinel-blue controller-boot-uninstall` when only its
running state differs (`controller-boot-status` shows it as held). An uncertain step left by fault k is closed
by **Reconcile interrupted setup**; its enable link in
`/etc/systemd/system/*.wants/` is not one of the step's recorded objects and is
left in place (systemd ignores a link to a missing unit; remove it by hand).

## Evidence

| Check | Result |
|---|---|
| New tests, `tests/test_live_findings_206.py` | 51 tests, all pass; none of the 50 that run off systemd passes on 2.0.5 |
| Native tests on the real systemd (`test_native_setup_rollback`, `test_native_setup_interruption`, the new-unit rollback) | pass; the new-unit test fails (exit 43) without fix k |
| Full suite with the bundled runtime | 2,178 tests, all pass (18 skipped: the native systemd tests, run separately above); 2.0.2–2.0.5 each had one environment error (a test that needed a system Python) |
| Packaged checks | continuity 44/44, lifecycle, crash-resume and supervisor smokes, withdrawal check; the `.run` rebuilds byte-for-byte; a double-click opens the 2.0.6 window in 5.5 s |

**Still not established:** a full VM with a desktop session and the graphical
administrator prompt; the IPv6 firewall half (this kernel has IPv6 disabled); a
network deployment with separate controller and agent hosts (the lab has no SSH
client or server and package mirrors are blocked); gunicorn itself (PyPI was
unreachable, so a `wsgiref` stand-in with gunicorn's command line served the
pack's unit); packs other than Redis, PostgreSQL and gunicorn.

**Known limits:** when a file Sentinel only adopted (not one setup writes)
loses its restore point and its copy and is then changed, nothing Sentinel holds
can put it back: the redo does not write that file. The alert says so; restore
it by hand and the restore point is rebuilt.
