# Sentinel Blue 2.0.14 — automatic Linux recovery with recorded undo

## Scope

With guarded-autonomous recovery already approved and enabled, supported Linux service recovery runs without a new per-attempt approval. A completed, journaled automatic operation is shown in the same **Services → select VM/service → Choose action / Undo… → History / undo** view as operator-started work. Its exact recorded inverse can be reviewed and approved there.

This release closes the ordinary automatic-start journal gap and the undo/reapply loop. It does not make arbitrary host changes reversible, replace a native application backup, invent missing event permissions, or remove the previous mandatory review of a manual action.

| Automatic operation | What is recorded / offered |
|---|---|
| Start an approved stopped Linux service | A no-file, no-startup-change coordinated journal under the existing `restart_service` authority. The permitted `rollback_service` inverse restores the observed stopped state. |
| Repair approved configuration/startup and recover the service | The existing coordinated repair journal, exact prior bytes/metadata/service state, and `rollback_service_repair` inverse. |
| Restore an explicitly declared service configuration file | The existing restoration transaction and `rollback_integrity` inverse, associated with the service(s) declaring that file. |
| Service already recovered before execution | Validates the actual service/files/probes only. Explicit no-op result, no native start, no fake transaction and nothing to undo. |
| Failed action automatically rolled back | History reports failure/rollback, not a successful change needing another inverse. |

History labels the source **Automatic** or **Operator**. Signed, reconciled offline service-start results can also become undo candidates after reconnection. A record is a candidate, not proof that its inverse remains safe now.

Full approved-setup redo has its separate reviewed setup/withdrawal job workflow; it is not rebranded as one service-action inverse. Containment, package installation, arbitrary operating-system changes, process memory, sessions and application/database writes are not made universally reversible by this feature.

## Before upgrading

Use the full `sentinel-blue-2.0.14-linux-gui1-x86_64.run` on each intended Linux host. It includes the existing offline Python/Tk/dependencies; native libraries, server packages, appropriate privileges and network connectivity remain prerequisites. The `.pyz` alone is not the complete offline runtime.

Reconcile pending work with the matching old runtime. Preserve the entire private state tree, including controller database/backups, agent credentials, action-delivery state, repair journals, `service-repair-history`, restore blobs, security metadata and receipts. After this release is used, preserve `service-automation.json` too. Do not delete a hold or history to force an operation, overwrite an active extracted installation, or downgrade an active migrated state directory.

Update controller and agents together through the existing reviewed release/profile workflow. Regenerate affected plans and approve the current release/hash. Opening the new GUI does not replace running processes, boot registrations, old identities, baselines or approvals. Existing generic restart records are not retroactively converted into accurate journals.

The direct-IPv4 dedicated-management mode remains available and still requires an actual separate authorized trusted management host. The original single-VM mode remains colocated. Windows-specific modules and PowerShell helpers are preserved; this new automatic-start path is Linux-only. Native Windows acceptance is not implied.

## Required permissions: approve once, not silently on every attempt

For automatic recovery, both the event profile and service manifest must already authorize the forward action in guarded-autonomous mode. An independently verified baseline, fresh telemetry, matching release/profile/agent identity and required native privileges are still necessary.

This release additionally requires the corresponding reviewed inverse permission before admitting those automatic Linux changes:

| Forward grant | Required inverse grant |
|---|---|
| `restart_service` | `rollback_service` |
| `repair_service` | `rollback_service_repair` |
| `restore_integrity` for declared service files | `rollback_integrity` |

The code **refuses missing inverse authority**; it does not add it to an existing approved profile. Newly generated local setup candidates include the journaled-start inverse for review, while existing profiles need explicit approval and matching deployment. A start-only operation does not require file-restoration privileges and cannot expand into changing file content or startup policy. File/configuration repair still requires its actual restoration privileges and backups.

The GUI's manual action picker continues to require effect review and per-action approval. It is an additional operator choice, not an instruction to silently turn every selected action into an automatic rule.

## Normal automatic recovery

1. Connect the GUI to its matching controller and verify fresh reports from the intended agent.
2. Review the real service transaction, baseline and forward/inverse permissions. Enable the existing guarded-autonomous recovery mode through its approved workflow.
3. Sentinel diagnoses a covered failure and queues an allowed action subject to confirmation, cooldown, hourly limits, maintenance, resource/dependency checks and global governance.
4. The agent independently rechecks the signed action, current target, private state, approved files and budget. For a stopped-service start it durably records the before-state before native mutation.
5. The agent validates native state and declared application probes and returns its actual result. A queued action ID does not mean the service was repaired.
6. Open **History / undo → Refresh results** to inspect the completed operation. The Undo column offers review only for a qualifying committed journal.

No-op validation is deliberately not presented as a change that can be undone. If native state changes after diagnosis or the checking evidence conflicts, the operation is held rather than manufacturing a prior state.

## Undo a completed automatic action

1. On **Services**, select the exact agent/service row; identically named services on other VMs are different targets.
2. Choose **Choose action / Undo… → History / undo → Refresh results**.
3. Select the particular completed action and click **Review undo of selected action**.
4. Read the exact files, metadata, service state and warning. Undo may intentionally return the service to an unhealthy previous state. It cannot reconstruct lost application data, live sessions or process memory.
5. Enter a meaningful reason in the action/reason area, select **Approve recorded undo**, and confirm.
6. Refresh results. The agent rechecks its own journal and present post-state before applying the inverse. Later conflicting teammate changes, missing evidence, unknown work or subsequent service mutations refuse the inverse rather than being overwritten.

The controller **durably pauses automatic recovery for the affected service before queuing the inverse**. For a shared restored file it pauses every declared affected service. The agent separately records a sticky local inverse hold before undoing. A lost reply, controller reconnection or agent restart does not make the undone change automatically eligible again.

The pause remains even if the inverse cannot be queued or fails. This conservative result is visible: it is not a success claim and is not a reason to delete journals.

## Pause and resume from the GUI

The **History / undo** tab includes:

- **Pause automatic recovery**: enter a reason and confirm. The controller stores the service hold and cancels only automatic work positively known never to have been delivered. Manual actions, read-only checks and already dispatched/unknown actions are not silently cancelled.
- **Resume approved automatic recovery**: after inspecting the service and reconciling pending/unknown work, enter a reason and confirm. This clears only the service-specific hold; it does not grant actions, approve a baseline, change retry limits, or override Emergency Stop/observe mode and failure safeguards.

The dialog reports the saved hold and whether the controller's automatic recovery is enabled. Clearing a service hold does not turn on a globally disabled controller.

The controller checks a revision number so an old dialog cannot overwrite a newer decision. Signed action-poll responses carry the saved state to agents before new work is returned. An agent rejects a rollback of that revision or altered equal-revision state. Its undo latch is removed only by a newer explicit resume for the matching transaction. An older controller backup cannot silently unpause it.

A disconnected guest cannot receive a newly issued pause instantly. It retains its last authenticated hold and any local undo latch. The GUI's 'controller-applied' status is not a claim that every disconnected agent has acknowledged it. Existing Emergency Stop, independent management pause, role stop and Withdraw retain their separate meanings.

Automatic setup-redo also observes the service hold. Shared host-level setup work can consequently remain held when it touches that service. This is not an unrestricted whole-host pause, and unrelated per-service automation remains eligible under its own policy.

## Offline continuity

Only the existing explicitly approved, time-limited offline restart policy can authorize disconnected changes. Those Linux starts now use the same recorded-start machinery. A known local service pause/undo latch prevents offline intent creation and does not spend another offline attempt. A late hold is rechecked at execution as well.

After reconnection the original signed continuity journal must be reconciled before an offline start is available for GUI undo. A fabricated or incomplete offline report does not become a trusted inverse. No replacement controller election or unlimited offline authority is added.

## Retry limits (issue C)

The 2.0.13 approved-policy ranges remain: 15–300 seconds between permitted attempts and 1–120 attempts per rolling hour. Defaults remain 300 seconds / 3 attempts. Failures retain at least 300 seconds and three failures per hour; success does not clear earlier failures. Full setup-redo keeps its independent 600-second / three-per-hour budget.

An explicit undo of a successful repair preserves its original forward-success classification in native history. It does not erase that attempt or turn it into a fake failure. A cancelled, never-delivered controller action is retained as audit evidence but does not masquerade as a native recovery attempt.

**Repeated-disruption policy** still saves an unapproved candidate. Saving does not activate a changed profile; approval and consistent controller/agent deployment/re-enrollment are required. This release does not introduce a live policy-fingerprint migration API. Pause/resume operates separately and changes no permissions or budgets.

## Intentional limits

Unknown outcomes, unclean rollback, revoked credentials, missing backups, stale telemetry, unapproved baselines, incorrect resource/dependency state, Emergency Stop and ownership conflicts remain holds. A safe reviewed inverse is not an arbitrary rewind stack. Earlier operations may no longer be undoable after later work. The bounded history view explicitly reports truncation rather than implying deletion.

The current disk-contention behavior, finite history/child-audit budgets, guest-local restore storage and lack of automatic redundant-controller failover remain. A root-compromised guest can still stop its own agent or alter its local evidence. Correct placement and independent backups remain necessary.

## Validation boundary

Use the matching 2.0.14 validation report for final measured results. Tests exercise temporary files, private journal/SQLite state, signed local HTTP, controlled offline reconciliation and real Tk callbacks. Native service transitions and application probes in the new tests are controlled fixtures, not a live daemon or separate VM. Installer/GUI/TLS-controller checks do not establish full native service deployment, reboot, polkit, hostile-root containment, Windows lifecycle or competition uptime.
