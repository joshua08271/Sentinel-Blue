# Sentinel Blue 2.0.12 — control-plane isolation option

Adds opt-in profile-bound dedicated management, host-role startup enforcement, socket-peer agent/operator API separation, a Linux GUI for prepared controller-only workspaces and strict per-guest joins, exclusive credential issuance, one-snapshot import verification, and exact-process background start/status/stop.

The goal is to place controller secrets/state outside defended guests. This requires an actual distinct authorized trusted machine; the program does not provision one or assert hardware attestation. Existing local mode stays available and retains its shared host boundary. No local state is automatically migrated. The new path creates independent identities and requires new profile/release approval.

See DEDICATED_MANAGEMENT_2.0.12.md for the exact workflow and limits. Guest-local file backups are not replicated by this feature; redundancy, reboot acceptance, segmentation and real multi-VM adversarial testing remain separate work. Current source and packaged regression results are in the separately supplied 2.0.12 validation report. Historical reports shipped in the bundle apply only to their named versions.
