# Sentinel Blue 2.0.8 — R207 governance and restore-capability corrections

This release corrects all five findings in the independent 2.0.7 review. It retains the self-contained Linux x86_64 installer, bundled Python/Tk, licenses, and matching source. The full `Sentinel-Blue-2.0.8-everything.html` includes the complete `.run` as embedded bytes, not a URL or a split-file requirement.

## R207-01: maintenance grants apply to setup redo

The controller supplies an explicit, bounded, fresh redo-policy view backed by its full action and change-grant store, not the dashboard's 100 recent rows. A live authenticated operator request to `/api/v1/setup/redo/check` is required at dispatch and by the worker before new task admission and apply. The worker checks the exact profile and selected-service scope, including dependency hosts. Unavailable/old controllers, stale agents, revoked agents, invalid responses, missing authority files, unknown scopes, and connection errors hold rather than grant permission.

An active maintenance grant conservatively holds setup redo across the affected host: setup tasks can write shared parents/directories beyond the ordinary repair list. It does not hold unrelated hosts. Revoking or expiring a grant through the existing authorized workflow removes that grant's hold; a separate unresolved-repair hold still applies. Already admitted bounded work must finish verification or rollback; this is not instant cancellation of a remote command already executing.

## R207-02: current mode cannot exceed original authority

Automatic redo requires the original reviewed permission **and** current guarded-autonomous controller permission. Approval-based mode stops automatic redo; observe mode holds manual and automatic redo. Emergency Stop remains a separate gate. A later mode upgrade cannot itself widen an originally approval-only local session. Both the local-session and network GUI paths pass a live authenticated controller connection to the worker; connection material is stored in a private 0600 file beneath a private 0700 job directory, never on the command line or in job result text.

## R207-03: unresolved rollback holds do not expire

All relevant unresolved repairs are checked, not merely the newest action or the last 15 minutes. A newer clean failure does not hide an older dirty rollback. Failed coordinated repair actions and their receipts remain retained ownership evidence rather than expiring through routine pruning. A bounded history overflow itself holds redo.

After an operator has completed/reconciled the target operation and independently verified recovery, **Recovery → Verify repaired redo holds…** requests acknowledgment from the controller. It requires fresh unique baseline-matching service, executed probe, content, security-metadata, and available restore-capability evidence. It records a separate receipt bound to the exact failed action and evidence digest; it does not rewrite the failure, modify files, change the baseline, or acknowledge an unknown outcome. Unknown action outcomes still use the existing outcome-reconciliation workflow. New or changed failures are not covered by an old receipt.

The additive `redo_recovery_receipts` table is explicitly allowed by authenticated backup inspection and included in the signed whole-database backup. It is not required when inspecting an older backup: absent receipts never clear old holds. Unknown tables/triggers remain refused. Preserve matching older runtimes and backups for deliberate upgrade/recovery; do not edit schema pragmas or recovery state manually.

## R207-04 and R207-05: structured restoration capability

Each new agent audit sends a separate `restore_point_health` report with schema, metadata-authority state, completeness, and full lost/rebuilt paths. The evidence is validated, scoped to the reporting agent, and bounded to 2,048 paths per list, 4,096 characters per path, and 256 KiB of combined path text. Overflow or malformed identity produces incomplete capability, never a shortened authoritative filename. Human diagnostics retain their normal 256-character display limit independently.

The central repair planner refuses file-restoring plans when required backups are missing, metadata authority is unavailable, or coverage is incomplete. A restart requiring no file restoration and unrelated services with usable backups are not unnecessarily blocked. Obsolete approval offers are withdrawn with `repair_offer_withdrawn_backup_unavailable`, not marked repaired; failure/security alerts remain. Legacy peers with ambiguous restore-loss diagnostics conservatively hold file restoration until fresh structured evidence is received. Actual authenticated restoration continues to fail closed independently.

## Integration correction: private bundled interpreter and UID readability checks

The full suite exposed a pre-existing portability problem: launching Python **after** dropping to a service UID cannot traverse the installer's private extraction directory. The fixed reader initializes the trusted isolated bundled interpreter first, then irreversibly sets supplementary groups and real/effective/saved GIDs/UIDs **before opening the target file**. It inherits no root-open target descriptor, does not expose file contents, does not relax target or bundle permissions, and does not fall back to system Python. Existing ownership, xattr, denial, rollback, and teammate-change checks remain.

## Upgrade and deployment

Update the controller and agents together, reapprove the release/hash and setup plans, and restart/reconnect through the reviewed workflow. New workers fail closed with older controllers that lack the signed check endpoint. Previously generated helpers, installed agents, controller boot registrations, and pending tasks are not upgraded merely by opening the new GUI. Preserve private job directories, ledgers, snapshots, authentication keys, and conflict records; they are not public repository material. Retain pending operations with their matching preserved runtime until reconciled.

The previous 2.0.7 authenticated-manifest migration, explicit DNS expected-answer checks, baseline security metadata, and bounded discovery requirements remain. Native Apache/database/FTP/SSH/SMB/DNS/DHCP packages and approved configuration are not bundled operating-system images. Missing all approved copies or keys cannot be repaired by inventing known-good data.

## Validation scope

See the accompanying measured 2.0.8 report/JSON/logs for final counts and exact hashes. Source/package regression tests use private real files, SQLite, signed local controller HTTP exchanges, and controlled clocks/service/process inputs. Late mode/grant/network failures are exercised through actual SetupRunner checkpoints with a modeled transport. Prior assertions remain in `tools/reproduce_R207.py`; its adapter supplies the newly required live-controller fixture without removing any of the original 16 assertions. No full user VM, native service recovery, graphical administrator authentication, reboot, multi-host deployment, or competition acceptance is claimed. Historical validation documents in the bundle apply only to their explicitly named release.
