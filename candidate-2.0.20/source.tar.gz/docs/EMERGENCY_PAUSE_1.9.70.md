# Emergency pause in 1.9.70

Select **Pause automatic changes** on the Services tab. Pause has a separate worker and reserved network slot, so an ordinary queued operation or recording export cannot consume its admission slot. Repeated clicks are coalesced. The window reports local setup control and the signed controller acknowledgement separately. A timeout or rejected acknowledgement is shown as unconfirmed.

Local setup pause works without a controller connection. It is stored in the desktop workspace and applies to 1.9.70 detached setup/opening jobs launched from that workspace, including launches queued before Pause. Reopening the window retains the pause. An absent, unreadable or invalid existing control file holds workers for review.

Pause stops admission of new setup changes at transaction boundaries. A setup runbook already admitted may finish its bounded command, health checks and owned rollback. Likewise, a host deployment already admitted may finish installation/cleanup, and an account change already admitted may finish verifying the same saved credential. The UI does not kill an installer or interrupt a password write. Independent jobs and controllers using other workspaces or older runtimes require their own controls.

**Resume approved changes** requests controller resume when connected, then allows newly reviewed local setup runs after acknowledgement. Without a connection it controls local setup only. It never replays a stopped job. Review the saved task outcomes and current service health, then review and approve a new plan. An unknown mutation outcome retains its existing reconciliation requirements.

The recording includes pause changes, controller confirmation or failure, and the partial setup results. Local control cannot prove the state of an unreachable remote controller. Commands already dispatched by a controller or detached setup job can still finish after the pause acknowledgement.

Validation results are recorded in the release status report. Native Tk automation exercises the actual button callbacks, TLS controller and detached workers on disposable fixtures; it does not certify every desktop workflow or an entire competition.

Native Windows acceptance exposed setup-state directories whose permissions could not be revalidated after the desktop reopened. Setup state and command-output directories now use the existing native private-directory creator. The strict ACL check remains in place. Python documents special Windows handling for mode 0700 in [os.mkdir](https://docs.python.org/3/library/os.html#os.mkdir). The native regression creates command output and verifies the complete directory again after closing it.
