# Sentinel Blue 2.0.5 — the issues left after 2.0.4, and ten more found live

**Status: untested on a competition VM.** 2.0.5 is 2.0.4 plus the fixes below.
Like 2.0.4 it was run end to end against a real systemd (Ubuntu 24.04,
systemd 255, booted as PID 1 of a private namespace; `tools/live_systemd_lab/`),
this time with **no iproute2 on the path at all**, with Redis configured by its
own configuration-generating pack, with a service checked on the VM's own
address, through the real desktop window, and through a red-team batch.

## Part 1 — the issues listed as open after 2.0.4

| # | Issue in 2.0.4 | 2.0.5 |
|---|---|---|
| 1 | A unit stuck *stopping* (redis with an unwritable data directory, `TimeoutStopSec=0`) was diagnosed as "another process holds the port", and setup's `systemctl` calls could wait on it forever, leaving an uncertain transaction. | Named for what it is: "stuck stopping; its own process still holds the port". Repair and the redo wait while a unit is changing state. Setup's start, restart and stop are bounded to 120 s, so a stuck unit is an ordinary failed, rolled-back step. The 3 s settle check runs only when setup actually started or restarted the service. |
| 2 | Any collector error held all recovery on the host — a failed firewall or route query, or a host without `ip`/`ss`. | Firewall, route, neighbour and interface gaps are *network inventory* warnings: reported, they cost score, but they never hold a restart or repair. Without iproute2 the same facts are read from the kernel's own tables (`/proc/net/*`, `ioctl`). |
| 3 | A VM on which 2.0.3 left an *uncertain* setup stayed blocked. | **Recovery → Reconcile interrupted setup** (or `sentinel-blue setup-reconcile`) closes an uncertain setup when its objects are exactly as recorded before it ran, or exactly as its approved plan leaves them. Anything else stays held and the difference is named. Verified on the real frozen 2.0.3 ledger. |
| 4 | **Withdraw** after a setup redo put the damage back. | A redo that re-applied the same approved setup is absorbed, so the original setup's inverse runs. Live: Withdraw after a redo returned `redis.conf` to Ubuntu's stock bytes. |
| 5 | Custom checks could only target 127.0.0.1. | A check may target this VM's own address. It still counts as a local check (a connection to your own address never leaves the host), so repair can tell a broken service from a network fault. The profile is scoped to exactly the address used. |
| 6 | A repaired service's alerts stayed open. | A repair (or restart) that finished with stable, verified checks closes that service's incident: stopped, restart-loop, check-failed and restored-file alerts, decision `resolved_by_repair`. Accounts, persistence and other services stay open. |
| 7 | README said LINUX-26…30 were still open. | Corrected: they were fixed in 1.9.101. |

## Part 2 — found by running 2.0.5 live, and fixed

| # | What happened | Effect | Fix |
|---|---|---|---|
| a | Configuring Redis through its pack on stock Ubuntu: `redis.conf` is 106 KB; embedded in the setup step and wrapped again by the transaction layer it became a 393 KB string, over the plan's 256 KiB limit. | **Configuring Redis could never start** ("JSON string exceeds the per-string limit"). | Embedded files and programs are zlib-compressed (the Redis step is now 114 KB, a custom service's 24 KB instead of 90 KB). A step still too large is refused with its reason. |
| b | A setup step refused *before changing anything* then had its rollback fail for want of an ownership record. | The task was reported **uncertain**, which holds all later setup. | The rollback of a step that never reached its durable prepare (no record, no claim, no ledger event) is a verified no-op, so the task is an ordinary failure. |
| c | Ubuntu ships `/etc/redis` as `redis:redis 2770`. Setup changes files as root only under root-owned directories no other account can write (otherwise the `redis` account could swap a temporary file for a link to `/etc/shadow`). | The pack failed on every stock Ubuntu. | Refused **at review**, naming the directory and its owner, with the advice to adopt Redis instead (adopted Redis is still fully repaired). PostgreSQL's `/etc/postgresql/*/main` is the same. To have the pack generate Redis configuration, make the directory root-owned first (`chown root:redis /etc/redis; chmod 2750 /etc/redis`). |
| d | A pack changes `redis.conf` seconds before the first baseline is approved. | A critical "file no longer matches the approved baseline" alert about Sentinel's own reviewed change stayed open. | Approving a baseline closes file alerts whose observed content and security descriptor are exactly what was approved (`resolved_by_baseline_approval`). |
| e | Deleting Sentinel's restore-point blobs went unnoticed until a repair failed with `[Errno 2] No such file or directory: '0cda…'`. | Silent loss of repair. | The agent checks its blobs every cycle (a `stat` each). A missing one whose file still matches is rebuilt from it (the blob is named by that digest); otherwise the restore point is reported **lost**. Both raise *Sentinel restore points were deleted* (one alert per loss, closed when rebuilt) and a readiness warning, without holding other recovery. Repair says "the restore point for X was deleted". |
| f | After the setup redo rebuilt Redis, its five incident alerts stayed open. | Alert noise. | The local session asks the controller to close the incident after a redo finishes ready. The controller closes it only if its own latest telemetry shows the service running, its checks healthy and its restorable files as approved (`resolved_by_setup_redo`). A service that merely came back by itself keeps its alerts. |
| g | Redis (`Restart=always`) with a corrupted `redis.conf` restart-looped, hit its start limit, and repair was "held for review". | **Repair never ran** for any packaged daemon that restarts on failure. | When the repair restores a changed file, a restart loop or start limit no longer holds it (a plain restart still is held). The executor reads a unit waiting in `auto-restart` as stopped, and clears the start limit (`reset-failed`) before starting. Live: repaired in 27 s. |
| h | Local setup attaches host-wide watched files (`/etc/passwd`, `/etc/group`, `/etc/hosts`, `sudoers`, `crontab`, SSH keys) to the first service so the baseline covers them. One `useradd` by the red team then read as a changed configuration file of that service. | That service's repair was refused for good ("file repair is not authorized: /etc/group"). | New `repair_policy.host_files`: files a manifest carries for coverage and approval-based restoration that its restart and repair neither require nor restore. Local setup and `repair-grant` (for identity files) fill it. The files stay monitored, alerted on and restorable from an alert. |
| i | After an executed Withdraw a new session's controller only "exited before readiness". The host stays paused by design, but nothing could record the human decision to use Sentinel there again short of deleting the ledger, which destroys the evidence. | No way back. | `sentinel-blue withdraw-release --operation-id <id>` (root) records that decision. It refuses while anything is in flight and changes nothing on the host; held conflicts stay held. The session now shows the exact reason and command. |
| j | The Services tab said "running service needs authorized restart and a failed local application transaction" for every healthy service, and `service_recovery_cooldown` after a repair. A redo note read "started for *". The Recovery tab clipped its own explanation. | Confusing. | "nothing to recover; running and its checks pass"; status codes in words; "every service in the approved setup"; label rewrapped. `repair-grant` counts a check on the host's own address as local. |

## Live results on 2.0.5 (real systemd, no iproute2)

| Scenario | Mode | Result |
|---|---|---|
| Guided setup: Redis by its pack, two custom services (one checked on 192.0.2.2) | guarded | all ready in 8 s; baseline readiness 100, no collector errors |
| Scoreboard configuration corrupted, process crashed | guarded | repaired in 4 s; its 4 alerts closed |
| Public page defaced while running (checked on the VM's own address) | guarded | detected and repaired in 6 s |
| Restore points deleted, files intact | guarded | 14 rebuilt within one cycle, one medium alert |
| Pack's generated file and its restore point deleted, Redis crashed | guarded | repair refused plainly; the redo rebuilt the file; Redis back in 62 s; restore point rebuilt; incident closed |
| Redis stuck stopping (data directory unwritable) | guarded | "stuck stopping" named; repair and redo held; repaired 13 s after the stop completed |
| `redis.conf` corrupted, `Restart=always` loop | guarded | repaired in 27 s (held forever before fix g) |
| Red-team batch: unit file deleted, page defaced, Redis masked and misconfigured, `useradd redteam`, `/etc/hosts` poisoned | guarded | all three services healthy in 12 s; account, `passwd`/`group`/`hosts` and new shell files stay as open alerts |
| Real desktop window attached to the session | — | services render; Reconcile ("nothing to reconcile") and Redo buttons work |
| Withdraw after a redo, clean ledger | — | redo absorbed, original undone: `redis.conf` back to stock, generated file gone, Redis running; then `withdraw-release` and a new session |

## Upgrading

Nothing to migrate. To pick up fix h on an existing local session, review the
local setup again (**Change local choices**): the new profile carries
`host_files`. A host paused by an earlier Withdraw can be released with
`withdraw-release`. An uncertain setup left by 2.0.3 can be closed with
**Reconcile interrupted setup**.

## Evidence

| Check | Result |
|---|---|
| New tests, `tests/test_live_findings_205.py` | 65 tests, all pass; run against 2.0.4 all but 8 fail or error (the 8 are the "still held when it should be" guards) |
| Native setup tests on the real systemd (`test_native_setup_rollback`, `test_native_setup_interruption`) | pass with the compressed setup payloads |
| Full suite with the bundled runtime | 2,127 tests; only the same environment error as 2.0.2–2.0.4 (a test that needs a system Python) |
| Packaged checks | continuity 44/44, lifecycle, crash-resume and supervisor smokes, withdrawal check; the `.run` rebuilds byte-for-byte; a double-click opens the 2.0.5 window in 5.1 s |

**Still not established:** a full VM with a desktop session and the graphical
administrator prompt; the IPv6 firewall half (this kernel has IPv6 disabled);
configuration packs other than Redis; a network deployment with separate
controller and agent hosts (only the `repair-grant` output was checked from the
packaged build).
