# Sentinel Blue 2.0.12 — dedicated management and agent-only Linux deployment

## What this changes

This release adds an explicit alternative to the combined single-VM session. A separate, authorized, team-controlled management host runs the controller, GUI/operator identity, controller database, recovery key, TLS private key and authenticated controller backups. Each defended VM runs only its own enrolled agent. The controller starts no local agent in this mode.

**Separate processes on the same root-compromised VM are not a security boundary.** You must actually place the management workspace on a different trusted host. A second address on a defended VM, another local user, a renamed directory or a container managed by that VM's root does not achieve this. Guards check the declared topology and currently visible interface addresses; they do not attest a hypervisor, detect every pre-existing service, or prevent a privileged user from changing code. Shared hypervisor/storage failures and compromise of the management host remain possible.

Only use hosts explicitly permitted by the event and controlled by your team. A scorer, organizer server, hypervisor or another team's system is not an eligible deployment target merely because it is reachable. A laptop is usable only when authorized and actually able to reach the competition network. With browser-console-only access, an authorized internal management VM may be needed. This release never creates a VM or changes Proxmox, Azure, routing or firewall configuration.

## Before using it

Keep a trusted, independent copy of your existing entire state directories. Reconcile pending work with its matching old runtime. Do not silently replace an active controller, discard ledgers or reuse a migrated state directory under an older release. This workflow creates **new identities and new workspaces**; it does not migrate old baselines, pending work, credentials, setup approvals or agent-local restore blobs. Old saved evidence remains available for its existing reconciliation workflow.

Use the complete 2.0.12 `.run` on the management host and each defended Linux VM. It contains Python/Tk and the same dependencies as 2.0.11. There is no network dependency download, but network connectivity between hosts is necessary for operation. Native server packages and a working Linux desktop/admin-authentication environment remain prerequisites.

Prepare your actual network inventory and event profile through the existing configuration workflow. This is **not an automatic discovery or profile-authoring wizard**. The isolated GUI takes explicit, existing host/service declarations, and refuses a local-transport inventory. The single-VM loopback profile is not suitable unchanged. Every guest needs its own unique agent ID, non-loopback IPv4 address and service manifest. The controller and operator source addresses must already be in authorized scope, with `external_controller` explicitly permitted. A live competition profile needs fresh approval; previous approval is not transferred to a changed topology or release.

Use distinct management credentials. Do not mount the controller directory on guests or reuse their administrator keys/passwords for management. Any shared secret deliberately written by an operator into a public event profile is outside the exporter's generated-secret separation; do not put private management credentials in profiles.

## Network requirements

This first dedicated GUI mode supports direct, stable **IPv4** management connections and 1–64 explicitly declared Linux agents. Existing IPv6 service checks are not removed. Hostnames, management IPv6, shared-source NAT, reverse proxies, wrapper/forwarded addresses and overlapping operator/guest source addresses are not supported by this role binding.

The controller binds only its declared management address and port (default 8765, configurable from 1024 through 65535). Each guest initiates HTTPS to that address. A GUI on another permitted management machine connects to the same HTTPS endpoint. The prepared certificate includes the management address as its SAN, and its exact public bytes are pinned in the profile. No TLS private key is placed on a guest.

Permit only the intended guest and management sources to reach this port using separately reviewed network controls. Preserve scorer/client paths and existing administrative access. No firewall is automatically installed by this wizard. Optional later service setup via the existing remote workflow still requires its reviewed SSH route and the target's own bundled interpreter path; joining an agent does not implicitly configure SSH or install a scored application.

The actual socket peer is checked, not `X-Forwarded-For`. Guest sources may reach their own agent endpoints and the limited health endpoint; dashboard, operator identity information, readiness, governance, recovery and observer interfaces are management-source-only. Existing signatures, per-host credentials, replay defenses and authorization checks still apply. A source allowlist is additional protection, not proof that a source is uncompromised.

## Management host: GUI workflow

1. Open the complete `.run` **on the separate trusted management host**. Select **Start here → Dedicated management…**. Do not select Review local setup: that is the original combined local workflow.
2. In **1 Prepare controller**, select the existing network inventory, source event profile and this release's extracted `sentinel-blue.pyz`. The application field defaults to the current runtime; the `.run` itself is not a `.pyz`.
3. Enter the management VM's actual IPv4 address and an available approved HTTPS port. Optional operator sources are exact comma-separated management IPs. The management address itself is included automatically. Guest addresses cannot be operator sources.
4. Enter a meaningful reference to the authorization for this management host. Confirm the separate-host/no-scored-services/no-shared-guest-writable-storage/no-reused-guest-admin-credentials requirement. A checkbox is a declaration, not independent proof of event permission.
5. Select **Prepare isolated candidate (no deployment)**. This creates a private `management-<id>` workspace and `candidate-profile.json`; it starts no process. It refuses the wrong host, a local inventory, unauthorized scope, conflicting roles or unavailable topology. Preparation does not expand the authorized target scope or grant new repair permissions.
6. In **2 Approve / start**, review that candidate. For a live event, supply an externally approved profile of the exact candidate. Only existing approval/publication facts may differ; a changed service, CA, address or permission requires new preparation. For a disposable range only, enter the range operator identity instead. The range control cannot approve a live event.
7. Select **Finalize approved profile and create join files**. Existing runtime-readiness and release/CA checks execute. Finalization is exclusively locked; it will not silently replace an already-issued or partially issued identity. It produces `agent-exports/<agent-id>.sentinel-agent.zip` and a separate `EXPORTS-SHA256.txt`. No controller or agent has started yet.
8. Select **Start saved role** and confirm. This starts only the controller role, with the existing controller supervisor and authenticated backup scheduling. Select **Connect this GUI to management**. The role status "process-started" is not readiness: verify a signed dashboard/readiness response and subsequently fresh observations from all expected guests.

The controller workspace contains sensitive master enrollment material, operator credentials, private TLS/recovery keys and database/backups. **Never transfer the entire workspace to a guest.** Transfer each guest only its own join ZIP. Provide the expected SHA-256 through an independently trusted management channel; a checksum supplied alongside an attacker-controlled replacement is not a trust anchor.

## Defended guest: GUI workflow

1. Stop/reconcile the old local session and preserve its full state. A previous combined session is not converted or removed automatically. Restart/reopen the GUI without reconnecting an old session, or clear the stopped local plan selection after reconciling it.
2. Run this release's complete `.run` inside the intended guest. Use **Open as administrator…** for the privileged agent workspace. Choose **Start here → Join as agent…**.
3. Select this guest's join ZIP, paste the expected SHA-256 obtained independently from management, and confirm this guest's own extracted `.pyz` path. Do not select a different VM's ZIP or an earlier application version.
4. Select **Verify and import only this agent**. Verification and parsing use the same bounded regular-file snapshot. Links/devices/FIFOs, extra entries, duplicate names, traversal paths, wrong hashes, wrong guest addresses, changed profile/CA/runtime and unexpected probes are rejected. Import creates a new private `agent-<id>-<id>` workspace; it starts no process.
5. In **Status / stop**, select **Start saved role**. This starts only that VM's agent. It cannot import/start an agent role on the management address. No controller, operator key or recovery master is imported. The agent requests its own enrollment and ordinary signed controller communication.
6. On management, verify the correct agent identity, fresh observations and meaningful application checks. Review and approve a fresh baseline/recovery authority before expecting autonomous repair. Join/import does not itself capture a baseline, install a service, enable containment, or grant unrestricted recovery.

The exporter contains exactly five files: `join.json`, `event-profile.json`, `controller-ca.crt`, `enrollment.json` and `probes.json`. The profile and CA are shared public configuration; the enrollment ticket is unique to that agent/profile and is sensitive. Imported state remains private. Keep unused exports secure; bootstrap copies are not evidence that an agent remains authorized after revocation. Existing explicit re-enrollment and revocation rules remain in force.

## Stopping, reboot, failure and recovery

Closing the GUI does not stop a background role. **Status / stop → Request graceful stop** signals only the exact recorded process identity, not a bare reused PID. It does not withdraw changes. Inspect the final status; an unresponsive runtime remains stopping rather than being force-killed and reported as clean. The role writes bounded rotating logs. If the wrapper disappeared but its recorded child still exists with the exact identity, stop can target that child and a duplicate start is refused.

This mode does not silently install/update boot services. Following a real reboot, restart the saved role explicitly using the GUI after checking state; review any boot registration separately. The controller's existing supervised restart is not a redundant-controller failover cluster. Existing conservative crash governance remains enabled, and automatic crash resume is not implicitly granted.

A guest with root compromise can kill its agent, erase its local restoration evidence, falsify its own observations or exhaust network resources. It does not receive the other guests' tickets or management secrets, and its source is refused management APIs. That separation reduces the direct impact of a guest compromise; it is not proof of freedom from controller vulnerabilities, denial of service, key theft through other channels or hypervisor compromise.

Central database/history and authenticated controller backups live on management. **This feature does not replicate every guest's file-restore blob, local mutation journal or data backup off-host.** Preserve independent approved backups. Loss of the management host or its storage is still a central failure. Source checks do not repair broken routing. Disconnected agents have only their existing expressly approved bounded continuity behavior; they do not elect a replacement controller or invent new repair authority.

## Compatibility and acceptance

Single-VM behavior remains available for existing profiles without `control_plane`, with no claim that it now has independent host isolation. Windows-specific files/helpers remain preserved; this new GUI preparation/join workflow is Linux-only and native Windows acceptance is not claimed. Shared core checks apply only to profiles that opt into the new contract.

The release adds contract, workspace/export, cryptographic HTTP role, GUI and process-identity regressions. Socket-peer values in multi-agent HTTP tests are controlled fixtures, not actual separate VMs. A local real TLS controller-role smoke demonstrates packaged management startup/clean restart, not physical network segmentation, native guest service recovery, reboot, live competition performance or hostile-root containment. Use the matching validation report for exact test scope and measured results.
