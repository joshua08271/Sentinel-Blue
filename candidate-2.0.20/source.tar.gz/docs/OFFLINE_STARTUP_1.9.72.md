# Sentinel Blue 1.9.72 offline startup

Use the full Windows x64 or Linux x86_64 offline ZIP. Extract everything to a local writable folder. Open `Start-Sentinel-Blue.cmd` on Windows, or run `./Start-Sentinel-Blue.sh` from a graphical Linux session. Keep the `runtime` directory beside the launcher and `sentinel-blue.pyz`.

The bundles contain a portable CPython distribution, Tcl/Tk, the credential-vault cryptography implementation, and the SSH/SMB Python dependencies. Startup does not fetch dependencies or require internet, ChatGPT, Azure, account sign-in, activation, or a system Python installation. The script remains the exact checksum-reviewed zipapp. Detached desktop workers and supervised controllers keep the bundled isolated interpreter.

Pass normal command arguments to the launcher, such as `offline-check --desktop`, `controller ...`, `agent ...`, or `observer --config observer.json`. `offline-check` imports and exercises the local libraries. With `--desktop` it opens and closes a real Tk window. It does not make an internet connectivity test or install anything.

The operating system still supplies its basic runtime and administration facilities. Linux needs glibc **2.34 or newer** for the included wheels, and an X11/XWayland session for the desktop. Windows needs a supported x64 Windows installation; Server 2022 is the native acceptance target. Other CPU architectures are not included in these two downloads.

Sentinel's own startup dependencies are different from service provisioning inputs. Before an offline event, prepare the approved profiles, local credentials, controller trust anchors, OS management tools, and any installers required for services you intend to add. An application setup task may need an approved local repository or installation media if that application is absent. The offline launcher does not silently fetch it.

Controller, agent, and observer communication still uses the approved range network. A disconnected outside observer cannot deliver its results until that connection works. No external AI is needed to plan or execute the existing approved, bounded rules, but controller-loss recovery remains issue #17.

Observer profiles still need reviewed service assignments and reporting credentials. A wizard for creating those configurations is outside the offline startup change.

Each archive includes `offline-manifest.json`, `SHA256SUMS`, and retained third-party license files. The manifest records the official Python archive, its SHA-256, each dependency wheel's digest, the script digest, and dependency-check results. These checks establish file identity; they are not a replacement for independently trusting the release or the host.

The portable CPython source and distribution requirements are documented by [python-build-standalone](https://gregoryszorc.com/docs/python-build-standalone/main/running.html). The release status carries the exact test results and platform limits for the supplied artifacts.
