# Sentinel Blue 2.0.7 — Linux corrective release

This release fixes R206-01 through R206-05 from the independent review of 2.0.6. It preserves the complete self-contained Linux x86_64 installer: bundled Python, Tcl/Tk, dependencies, licenses, application and matching source/build tools. It does not download dependencies during startup or this build. It is not an operating-system image or a collection of every native server package.

## Changes

### R206-01: restore-point metadata loss
POSIX restore-point capture now publishes two HMAC-authenticated snapshots containing the full path/content/security metadata, not only a second content blob. The session holds one snapshot; when a content mirror is configured, the other snapshot and private key are in the ledger's sibling `restore-metadata/<scope>` directory. The scope binds the snapshots to the absolute restore-store path. A signed generation checkpoint rejects an older snapshot when a newer generation is known. The JSON manifest is a verified cache, not a new source of authority.

A missing or corrupt manifest is rebuilt from a valid authenticated snapshot; damaged bytes are retained as bounded private evidence. An interrupted multi-file publication is reconciled on read. A lock and generation comparison prevent a concurrent capture from replacing a newer snapshot. Missing keys, untrusted metadata, unsafe paths, conflicting generations or exhausted evidence storage cause an explicit lost-restore-point diagnostic and a hold. The agent now reports an unexpected audit failure in telemetry instead of logging it alone. It never approves the current changed file merely to make the warning disappear.

Existing unsigned manifests are preserved and identified as legacy; they are not silently signed. Complete explicitly approved recapture is required to establish authenticated metadata redundancy. A partial recapture does not promote other old entries. Keep the old record and external known-good backup until migration is verified. Missing/corrupt legacy authority cannot be invented retrospectively.

This is protection against loss, corruption and unauthorized modification without the private key, not protection against an attacker controlling the same privileged account/key, a rollback of all protected state together, or loss of every independent copy. Windows retains its existing metadata path.

### R206-02: setup-redo incident closure
Redo completion now needs fresh sequenced, complete telemetry; a unique running service observation; healthy unambiguous executed checks; and exact content plus valid security-metadata fingerprints for every declared restoration file. Missing, unreadable, duplicated, stale or permission-mismatched evidence leaves the incident open with a reason. Empty legacy security fields require baseline review rather than being treated as proof. Duplicate instance observations cannot close a dependent service's alerts. Instance indexing is linear in the bounded observation count.

### R206-03: DNS health evidence
Every DNS response is structurally parsed, even without exact-answer matching. The question must match; all declared answer, authority and additional records must fit; common record encodings and compression are checked; and a relevant answer of the requested type must exist for the query or a valid CNAME chain. Header-only, truncated, unrelated and malformed responses are unhealthy. Existing count, traversal, timeout and response-size bounds remain. An exact answer list must match its query's address family.

The local wizard no longer invents a DNS readiness test from a zone/domain alone. Save a DNS Service check with the actual query and expected addresses. Existing explicit valid checks remain supported. DHCP lease verification is not supplied by a DNS or TCP check.

### R206-04: batched-redo cooldown
Cooldown enforcement now checks membership in the complete batch's `units`, not just a singular `unit`. Legacy wildcard histories without a usable membership list conservatively cover all affected services. The latest relevant timestamp is used. The ten-minute service cooldown, one job at a time and three-redos-per-hour limit remain; an unrelated host/service is not delayed by a well-formed scoped batch. Explicit manual override remains an operator decision.

### R206-05: configuration discovery
Automatic configuration discovery is breadth first before applying the file limit. It retains the default 64-file cap and 1 MiB/file limit, plus bounded directory, queue and entry inspection. No symbolic-link components are followed. Incomplete coverage, rejected paths, limits or unreadable directories are reported, saved in the workspace and shown in the setup-plan description. The separate repair-file cap and approval policy are unchanged: discovering a file does not automatically authorize its restoration.

## Tests and scope

The source includes 89 new regression methods in `tests/test_linux_hotfix_207.py`, using real private files, POSIX permissions/xattrs, authenticated metadata, SQLite and loopback DNS sockets, with modeled service observations, clocks and job launches. The original independent reproductions are also replayed. Their adapter only permits the new version and explicitly tests the old DNS probe shape after the unsafe automatic default is refused; the original desired-correctness assertions and controls are retained.

Two existing test fixtures were clarified: the intentionally non-bundled-Python refusal runs headlessly, because it expects an exit rather than an interactive error dialog; the old redo-closure fixture supplies a synthetic security fingerprint for its synthetic file. No assertion was removed. Final measured counts, skips and logs are supplied separately with the release; earlier 2.0.6 and older native test reports are historical evidence, not acceptance of 2.0.7.

No user VM, hypervisor, cloud account, live daemon, firewall, remote deployment or GitHub repository was changed. No real desktop/polkit, OS reboot, competition uptime or sustained workload claim is made. Native server packages and the user's actual service stack still require target-specific acceptance.

## Upgrade

Finish or reconcile pending work with the matching old runtime and preserve all ledgers, snapshots, keys, receipts and conflict evidence. Do not overwrite an extracted running bundle. Use the new versioned installer; reapprove its version/hash and create or review a matching session/setup plan. Existing generated scripts, remote agents, scheduled helpers and optional controller boot registrations are not updated merely by opening a new GUI. Stop/review/re-register the old boot configuration through its supported controls when deliberately migrating it; do not delete its evidence to bypass a hold.

For legacy restore points, review files against independent known-good content and permissions before explicit recapture. A missing old security baseline must not be replaced with guessed values. For DNS, save the intended query and exact expected answer before reviewing the new plan. Review all configuration-coverage warnings and explicitly supply any omitted required paths through the approved workflow. Test stop/reconnect/removal and the intended reboot procedure on a recoverable VM before unattended use.
