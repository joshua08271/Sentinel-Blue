# Sentinel Blue 2.0.3 — repair reaches every service

**Status: untested on a competition VM.** Built on 2.0.2. Everything below passed
its unit and integration tests in a sandbox that has no systemd, so the parts
that talk to systemd were exercised against a recorded model of it, not a live
one. Prove it on a lab VM before relying on it.

Until 2.0.3 the in-place repair (restore a service's configuration, put its
startup back, restart it, check it, and roll everything back if the check fails)
existed, but almost nothing reached it:

* the guided local setup never granted it, so every service chosen in Service
  setup could only be restarted;
* it ran only in guarded-autonomous mode — approval-based mode could not even
  offer it;
* a masked unit could not be repaired at all, and a restored unit file was never
  reloaded before the restart that depended on it;
* a service that is not one of the 39 catalogued ones could not be set up or
  repaired from the desktop;
* an operator-written event profile had to spell out a `repair_policy` by hand;
* when repair could not fix a service, nothing else was tried.

## 1. Every service chosen in Service setup can be repaired

Review local setup now gives every selected service — a generated pack, an
adopted catalogued service, or a custom one — the same grant:

| | |
|---|---|
| restores | the files that belong to that service: what setup generated for it, its product's own configuration paths, its unit file (at most 16) |
| startup | back to `enabled`, including from a mask |
| restart | yes, then its own check must pass, repeatedly, within 30 s |
| on failure | every step is rolled back exactly, mask included |
| approval-based | the failed service is offered on Alerts & verification; nothing is restored until you approve |
| guarded-autonomous | repaired automatically, within the existing attempt limits |

Host-wide files every baseline also watches — accounts, sudoers, PAM, SSH keys —
stay monitored and alerted on. They are never in any service's restore list: a
web server's repair must not be the thing that rewrites `/etc/shadow`. The review
screen lists exactly which files each service's repair may restore.

Adopted services are now set up with `unmask` as well as `enable`, so setup can
bring back a unit that was masked before it ran.

## 2. Services outside the catalog

**Service setup → Add custom service…** takes a systemd unit name, the
configuration files that belong to it, and the check that proves it works
(TCP, HTTP, HTTPS or DNS against 127.0.0.1). Setup adopts and starts the unit;
repair restores those files and the unit file, re-enables and restarts it. The
form refuses a catalogued unit (choose it from the list), a file two services
both claim, and account, sudo, PAM, SSH, `/proc`, `/sys`, `/dev` or `/boot`
paths.

**Services on the rest of the network** are described by the event profile.
`repair-grant` writes a *new* profile in which each service can be repaired, from
what the profile already says about it:

```sh
sentinel-blue repair-grant --event-profile event.json --output event.repair.json            # approval only
sentinel-blue repair-grant --event-profile event.json --output event.repair.json --automatic
```

or **Setup → Grant repair to every service…** in the desktop, which writes
`event.repair.json` beside the original and switches the Setup tab to it. Per
file, a service may restore only what is its own:

* a file another service on the same host also lists is shared → alert only;
* a file inside one of its `required_data` paths is data → never rolled back;
* account, sudo, PAM, SSH-key and kernel/boot paths → alert only;
* beyond 16 files → alert only, and named.

A service that lists no `required_files` is skipped with the reason. One that
already has a `repair_policy` keeps it. Capabilities the profile turns off stay
off unless `--enable-capabilities` is given, and automatic repair is granted only
with `--automatic`. The original file is never changed, and the copy keeps its
approval record, so an event that approves profile changes should review the copy.
Agents need `--allow-service-recovery --allow-restoration`, and the baseline has
to be approved again so its backups exist.

## 3. When repair fails, the approved setup runs again

A repair puts back what the baseline captured. Some damage is outside that — a
deleted unit, a removed directory, a generated file beyond the repair limit. The
setup that built the VM's services can rebuild those, and it is already approved.

When you approve local setup, Sentinel keeps a record of exactly what was
approved. A **redo** runs that plan again as a new background job:

* the worker recompiles the plan and refuses to start unless it hashes to the
  digest you approved — a profile or inventory edited since then stops it;
* setup checks each service first and leaves a healthy one alone;
* it honours the Setup pause and runs one job at a time.

A service qualifies when it was healthy earlier in the session and then either a
repair failed and rolled back cleanly, its unit disappeared for a minute, or it
stayed down for three minutes without repair fixing it. It never qualifies after
a repair whose rollback did not complete, while an action's outcome is unknown,
during an emergency stop, or for a fault setup cannot fix (another process on its
port, a full or read-only filesystem, host memory, a restart loop). At most once
per service every ten minutes and three times an hour.

In guarded-autonomous mode the local session runs the redo itself. In either mode
**Recovery → Redo approved setup of this VM** starts one on request (the timers
do not apply; the holds do), and the Recovery tab shows each service's redo
status.

A redo is recorded like any setup. **Withdraw** reverses it to the state it
found — the broken state — and then holds the original setup's inverse for
review, which is what already happens when setup is re-run by hand.

## Repair engine changes

* **Masked units.** `unmask` is its own grant in `repair_policy` and requires
  `restore_start_mode: enabled`. The agent runs `systemctl unmask` then
  `enable` (the `--runtime` forms for `masked-runtime`), verifies the result,
  and a failed repair puts the mask back. Without the grant a mask still holds
  repair, as before. Windows has no mask and is unchanged.
* **Unit files are reloaded.** Restoring a file under a systemd unit directory
  (`/etc`, `/run`, `/lib`, `/usr/lib` and `/usr/local/lib` `systemd/system`,
  drop-ins included) runs `systemctl daemon-reload`
  before the start, and again on rollback.
* **Operator-approved repairs use the approval list.** A repair approved from an
  alert is authorized by `approval_actions`; an automatic one by
  `allowed_automatic_actions`. The controller and the agent each check the list
  the action came from. An automatic grant does not imply an approval grant.
* **Approval-based mode offers repair.** When a service with an approved
  baseline fails and a repair can be built, the controller raises
  `service_repair_required` (recommended action `repair_service`) in place of the
  restart-only `baseline_service_stopped`. Approving it queues the exact repair.

## Evidence

| Check | Result |
|---|---|
| New tests (`test_linux_repair_203`, `test_repair_grants_203`, `test_setup_redo_203`, `test_desktop_repair_203`) | 71 tests, all pass |
| Setup redo through a real detached worker built from this source | the redo ran the approved plan; a plan changed since approval was refused before any work |
| Custom-service form, grant button, redo status | driven in a real Tk window under Xvfb |
| Full suite with the bundled runtime | 2,042 tests; only the same 2 environment errors as 2.0.2 (`ss` absent; one test that needs a system Python) |
| Packaged checks | continuity 44/44, lifecycle, crash-resume and supervisor smokes, withdrawal check; the `.run` rebuilds byte-for-byte and a double-click opens the window in 4.4 s |

**Not established here:** a live systemd. The sandbox has none, so `unmask`,
`daemon-reload` and the restart sequence were checked against recorded
`systemctl` behaviour. On a lab VM: mask a scored unit and corrupt its
configuration, and watch it come back (guarded) or be offered (approval-based);
delete its unit file and watch the redo rebuild it.
