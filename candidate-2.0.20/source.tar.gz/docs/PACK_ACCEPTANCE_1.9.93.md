# Sentinel Blue 1.9.93 — making the acceptance harness reachable

Every catalog row says `native_tested: False`. `tools/service_pack_acceptance.py`
exists to change that on a host you can destroy. This release is about the gap
between those two sentences: the harness was finished, and what it needs an
operator to know about each product was not written down anywhere.

Nothing here is native evidence. **0 of 20 configuring services have been
accepted**, and every probe command shipped below is a draft that has never run
against the product it names.

## What was missing

A receipt requires six things per service, and has since 1.9.88:

| key | what it is |
|---|---|
| `positive` | the scored transaction this service must answer |
| `denied` | the weakening this service must refuse |
| `effective` | a query that asks the running product what it is using |
| `update_options` | a second reviewed option set, to prove an approved change |
| `invalid_options` | an option set the pack must refuse |
| `withdrawal` | how to reach the separate observer that confirms the restore |

`examples/acceptance-profile.example.json` answered them with a **shape example**,
and said so on its first line: *"1.9.88 SHAPE EXAMPLE ONLY: replace every
/REPLACE/ wrapper and populate complete reviewed option sets. This file is
intentionally not runnable."* That was an honest thing to ship. It carried the
right keys, in the right shapes, with `/REPLACE/` wrappers where host-specific
values belong, for five of the twenty configuring services.

What it could not do is tell an operator what to put in them. `update_options`
and `invalid_options` were empty objects; `effective` pointed at
`/REPLACE/bind9-effective-settings`. So before a single service could be planned
usefully, someone had to work out — per product — a scored transaction, a
weakening that must be refused, a query that reports effective settings, an
option change worth approving, and an option set the pack refuses. Fifteen
services had no entry at all. The harness was finished; the product knowledge it
needs was not written down anywhere.

One thing that did go unnoticed: the gate's list of required keys was a tuple
inside `main()`, and nothing compared it to the example it gates. That is now
`REQUIRED_PROFILE_KEYS`, a module constant, and `tests/test_acceptance_profiles_1993.py`
imports it — a key added to the gate without an answer in the example fails in
the suite rather than on a host during an event.

## What ships now

**Two files, both keyed by service id.** `--options` now accepts a service-keyed
file the way `--profile` already did, so one reviewed file covers every service
and `--service` selects the section.

```
examples/acceptance-options.example.json   the reviewed options each pack is built from
examples/acceptance-profile.example.json   the probes, the update, the refusal, the notes
examples/acceptance-postfix-main.cf        the snapshot the Postfix options pin
examples/acceptance-nginx-index.html       the content the nginx options pin
examples/acceptance-nginx-index-v2.html    what the approved update serves instead
```

Two packs edit a file they did not generate — Postfix has no active include
directory, and the nginx adapter serves a file you supply — and both refuse to
touch it without the exact digest of what they are replacing. A reviewed option
set for either one therefore has to name a real file and a real digest; an
example that pins a placeholder is an example that cannot be run. So the example
ships the files it pins, with their digests. **Replace them with your host's own
file and digest.** Getting a mismatch because you forgot is the pin doing its job.

**Verified mechanically, for all twenty**, by `tests/test_acceptance_profiles_1993.py`:

* the reviewed options and the update both compile through the real pack builder,
  nginx through its own adapter, exactly as `pack_contract` routes them;
* the update produces a different pack fingerprint — an approved-change step needs
  a change to approve;
* `invalid_options` is genuinely refused, and the refusal text is recorded in the
  entry next to it;
* a configuration test exists, from the catalog or from the profile;
* every probe is a bounded argv list naming an absolute path;
* the profile holds no key the harness would refuse;
* `--plan` runs clean for all twenty, reporting exactly one missing key.

**Not verified, and marked DRAFT on every entry:** whether `dig` prints
`Transfer failed` on a refused BIND, whether your Samba rejects `smbclient -N`,
whether `swaks` is installed at `/usr/bin/swaks`. That is product behaviour, and
no sandbox can observe it. Read every argv in `--plan` before you run one.

**`withdrawal` is left out rather than placeheld.** It is four paths on your own
observer, not product knowledge. The 1.9.88 example carried
`/REPLACE/reviewed-observer-argv-forwarder`, which passes the gate as a
non-empty string and then fails at the rollback step — after the host has been
changed. Absent, `--run` refuses before touching anything and names what it
wants. The block to add:

```json
"withdrawal": {
  "runtime_argv": ["/usr/bin/ssh", "observer.range.test",
                   "/opt/sentinel/sentinel-blue.pyz"],
  "inventory": "/opt/sentinel/inventory.json",
  "event_profile": "/opt/sentinel/event-profile.json",
  "directory": "/var/lib/sentinel/observer"
}
```

A receipt records outside verification, and there is nothing to record if nobody
was watching. The refusal now names what each missing key is and where the
template lives, instead of listing bare key names.

**Preserved data is still compared byte for byte.** `data_invariants` lets a
profile substitute a reviewed logical query for a data path, and the default —
strict tree equality — is the stricter of the two, so none is supplied here. For
ten of the twenty that default cannot hold: a database writes on every
transaction, a mail queue moves, a lease file ticks, `/var/log` grows while the
acceptance is running. Each of those profiles names its declared data paths and
says which one needs a reviewed query, so the requirement is met while reading
the file rather than when a snapshot comparison fails halfway through a run.

**Probe commands name absolute paths.** A bare program name leaves PATH in the
evidence, and a receipt records no PATH. This matches what every catalog
`validate_argv` already did.

## Seven option shapes that crashed instead of explaining themselves

The malformed-input sweep that has run since 1.9.83 mutated the keys present in a
reviewed **baseline**. An option a baseline happened not to set was never tried,
and that is exactly where these were:

| pack | option | what an operator wrote | what happened |
|---|---|---|---|
| dnsmasq | `addresses` | a list of names | `.items()` on a list |
| dovecot | `protocols` | `null` | iterating `None` |
| dovecot | `protocols` | `[[]]` | `set()` over an unhashable member |
| openssh-server | `allow_users` | `null` | iterating `None` |
| postgresql | `listen_addresses` | `null` | iterating `None` |
| unbound | `access_control` | `null` | iterating `None` |
| unbound | `forwarders` | `null` | iterating `None` |

Each raised an `AttributeError` or `TypeError`. The dialog that collects these
options only shows a correction for `ValueError`, so the operator saw no message
at all — the same failure mode as the haproxy backend written as `"host:port"`
that 1.9.83 fixed. This is the fourth appearance of use-before-type-check in this
codebase, and the sweep now walks every option each pack **declares**: 2,400
inputs across every declared option of 19 packs, each refused with a stated
reason or accepted deliberately.

## A null option no longer discards its own default

`options.get(name, default)` cannot tell an absent key from a key present as
`null`. Both arrived as `None`, and `None` became an empty list. So:

```json
{"protocols": null}      →  a Dovecot with no protocol enabled
{"mynetworks": null}     →  a Postfix that trusts nothing
{"allow_query": null}    →  a BIND answering nobody
```

— in each case instead of the default the operator had just read in the
documentation, and without a word on screen. Absence keeps the default; a null is
refused, naming both alternatives:

```
protocols is empty; give it a list of entries, or remove the option
entirely to keep its default
```

This is what `_boolean` has always done with a null where it wanted true or
false. Sixteen call sites across eleven packs now go through `_option_list`, the
one place that decides what an absent key means.

## A service with no distribution package failed its first step

`gunicorn` wraps an application you supply and declares no apt packages. The
preflight step ran `dpkg-query -W` with no names — which lists every installed
package on the host and exits 0 — compared that against zero expected rows, and
reported a missing package that was never required. `--plan --service gunicorn`
did not print a plan at all; it raised `KeyError: 'apt'`.

A pack with no declared package now checks the unit alone and says so in the
report. A test plans every configuring service, so neither comes back.

## The boundary, stated plainly

* No probe in these examples has been run against a real product.
* No service has been accepted. `doctor` still reports 0 of 20.
* All 39 catalog entries still report `native_tested: False`.
* What is verified here is that the option sets compile, differ and refuse as
  described, and that the shipped examples drive the tool without error. That is
  a working harness, not a tested pack.

`docs/VM_TESTING_REQUIRED_1.9.93.md` carries VM-L20, which is how this becomes
evidence.
