# Sentinel Blue 1.9.97 — Linux fixes 9–14

## Scope

Incremental correction of 1.9.96 retaining issues 1–8 fixes. Original uploads are
unchanged. No cloud, repository, remote host or native service/network settings
were changed. Code/fixture validation is not native acceptance.

## 9. Per-object router rollback ownership

Pending state records each helper file, nftables table, additional route and
address separately: not-written, writing, applied, restoring or restored. Intent
is flushed before mutation; completed post-state is saved only after successful
execution and observation. Planned additions are not ownership receipts.
Rollback preflights every receipt before any inverse and rechecks at each write.
Files include bytes, UID, GID, permissions, extended attributes and revision;
restoration stages metadata before replacement. Missing/in-flight receipts or
observable third states hold for review. Early failures no longer bypass checks
because a final table fingerprint is absent. Attempted service-control operations
are tracked separately, so untouched service-control steps are not blindly undone.
Nonempty legacy pending records without ownership proof refuse automatic rollback.
Committed withdrawal reconstructs receipts from authenticated before/after ledger
snapshots after an exact current-state check, not untrusted pending receipts.

## 10. Router rollback/startup identity

The complete preceding committed state is retained, including ledger_action_id,
inverse and forwarding metadata. Oversized state refuses before helper writes.
An update rollback validates the prior action's authenticated semantic state
before rebasing restored inode revisions. Boot authorization is not weakened.
The boot audit uses boot_before_hash, not before_hash, preserving original
withdrawal pre-state. Existing ledger history is not rewritten or guessed.

## 11. Service-validation deadline

Validation checks its deadline before every batch and before accepting success.
An absolute deadline flows through run_probes into each admitted probe; queued
checks cannot start a fresh full-duration budget after it expires. Late/expired
results are not admissible health evidence. The existing bounded request pool
owns draining workers. An empty contract remains unmeasured, not proof of health.

## 12. Routed-witness reader

The separate route_check_native reader uses O_NONBLOCK and O_NOFOLLOW, validates
the open descriptor before reading, enforces a 65,536-byte limit and compares
descriptor/path revisions afterward. FIFOs, directories, symlinks, hard links,
broad permissions, observed replacement and growth refuse. No unsafe pathname
reopen is used for JSON decoding.

## 13. Linux group coverage

Successful sudo/wheel/admin queries retain GIDs and explicit members. Known
primary/supplementary privilege evidence survives bulk group-enumeration failure.
Failures, malformed records and timeouts mark coverage incomplete; missing
individual distribution-specific groups do not. This remains group-based
classification, not evaluation of every effective sudoers or PAM rule.

## 14. Bounded output capture

Child output uses a bounded pipe, not an unlimited temporary output file, and is
hashed incrementally. Only finite reviewed stdin uses a temporary file. Captured
output and retained private logs have a 16 MiB per-command quota. Overflow stops
the owned process group/tree and reports uncertain=True, output_truncated=True,
failure_reason=output_limit_exceeded. output_bytes counts captured bytes and
output_sha256 hashes that captured prefix, not discarded output. Normal output
retains an exact digest. Reading consumes the execution deadline; termination
retains the separate cleanup grace. SSH/WinRM wrappers preserve the new fields.

## Limits and upgrading

These observable-state guards do not provide atomic compare-and-swap against an
arbitrary racing privileged writer. Root-private pending receipts are not a new
trust boundary against a privileged attacker. File-type guards do not bound
arbitrary filesystem/kernel stalls. Process groups do not contain deliberate
group escapes or prove remote-host termination when a local SSH client stops.
Windows-native pipe/tree cleanup was not exercised.

Reapprove version/hash and regenerate plans. Reconcile pending transactions using
their preserved helper and evidence before replacing installed helpers; replacing
the desktop runtime does not update old scripts/timers. Retain ledgers, backups
and conflict receipts. Already truncated prior-state records or old boot audit
history require explicit recovery from preserved authenticated records; no
ownership or missing data is invented to bypass a hold.

Native systemd, real router services, boot/crash lifecycles, separate observers,
SSH/multi-host deployment/withdrawal, target-distribution NSS and competition
acceptance remain required. No catalog flag or acceptance receipt was upgraded.
Final measured results are in the matching delivery report and evidence.

## Reproduction on authorized disposable infrastructure

```sh
env -u DISPLAY -u WAYLAND_DISPLAY PYTHONPATH=.:src:tests python3 -m unittest test_linux_hotfix_1997 test_linux_hotfix_1996 test_linux_hotfix_1995 -v
env -u DISPLAY -u WAYLAND_DISPLAY PYTHONPATH=.:src:tests python3 -m unittest discover -s tests -t tests -v
PYTHONPATH=. python3 tools/build_defensive_release.py --output ../build
```
