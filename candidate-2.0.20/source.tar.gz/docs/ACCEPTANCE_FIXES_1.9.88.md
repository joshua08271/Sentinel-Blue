# Acceptance corrections — Sentinel Blue 1.9.88

## Scope and evidence

This release corrects R87-01 through R87-08 from the independent 1.9.87 review.
It changes acceptance tooling and evidence reporting, not the defensive decision
engine, service builders, recording behavior or the Linux launcher. It grants
no new permission. A passing test double cannot issue a real product acceptance.
The shipped service catalog stays at 39 entries, with all static `native_tested`
flags false. This round does not provide Windows, systemd, reboot, full-product,
Proxmox or competition-uptime acceptance.

## Receipt migration and current-context reporting

Receipt schema is now **2**. Version-1 receipts are historical and do not count,
because the old harness could pass incomplete lifecycle checks. Do not manually
edit an old receipt's schema or runtime hash. A fresh acceptance is required.

`doctor` and the summary API fingerprint the running zipapp, not the invoking
helper script. A source-tree invocation uses a distinct `source:<sha256>` over
the runtime package. The receipt must also match the host, platform, age limit,
reviewed desired configuration and a supplied current product-version observation.
Unreadable, malformed, oversized or incomplete evidence is untested. Wrong
runtime/platform/version/configuration or expired evidence is stale. Neither
counts as accepted. Unknown current context is not inferred from the receipt.

A doctor context file is a private JSON object such as this **illustrative shape**:

```json
{
  "redis": {
    "options": {"bind_address": "127.0.0.1"},
    "root": "/absolute/path/to/reviewed-options-sources",
    "product_version": "the exact currently observed version"
  }
}
```

Use the exact reviewed options, not these example values. Obtain the version
from the installed product; do not copy it from a receipt just to match it.

```sh
python3 sentinel-blue.pyz doctor --state-dir /absolute/private/state \
  --acceptance-context /absolute/private/current-context.json
```

The API equivalent is `summary(state_dir, contexts=contexts)`. Without a context,
`doctor` deliberately reports no current accepted configurations. This does not
mean historical evidence was deleted. A matching context is evidence about the
tested configuration, **not an assertion that current live effective settings are
unchanged or the service is healthy**. Reports are local records, not signed
attestations that a root-compromised machine is trustworthy. The existing GUI
still uses its static summary unless a caller explicitly supplies host context;
this change does not add remote receipt transport or a new GUI wizard.

Receipt directories are created privately. Existing symlinked, nonprivate or
unowned receipt storage is refused; it is not silently chmodded into compliance.

## Native acceptance prerequisites

Use `tools/service_pack_acceptance.py` from the matching source archive. This is
**development tooling**, not a command in the defensive public zipapp.

`--run` requires all of the following before admitting service mutations:

* An explicitly authorized disposable Debian/Ubuntu/Kali Linux host, root,
  installed product prerequisites, and PID 1 really running systemd.
* The exact `--runtime` zipapp, whose packaged source matches the tool's tree.
* An explicit approved `--event-profile`, a complete reviewed inventory for
  exactly one local loopback Linux host, and no unrelated setup tasks.
* Complete product probes, reviewed update and failed-apply option sets, an
  operator name, observed product version, and independent withdrawal verifier.

The tool does not install missing products, broaden scope, approve an event
profile, delete a ledger or invent credentials. Use `--range-deployment` only
when the existing reviewed profile actually permits that path. Use absolute
paths for inventory artifacts and source references to avoid ambiguity when a
new inventory copy is staged in the private work directory.

`--plan` is nonmutating and prints a **review template**, not every eventual
runtime-generated command. Exact plans are computed and digest-bound by ordinary
setup before execution. This avoids falsely presenting a placeholder checklist
as a fully resolved execution plan.

## Product profile contract

The example profile is intentionally non-executable. Supply and review these
product-specific fields; no missing mandatory step is counted as passed:

| Field | Evidence required |
|---|---|
| `positive` | A real authorized transaction, including expected output where exit status alone is ambiguous. |
| `denied` | A real disallowed transaction with a specifically identified refusal. A missing client, timeout or truncated output is not proof of access denial. |
| `config_test` | An actual product configuration check; required when the catalog has no suitable check. A memory benchmark is not a configuration validator. |
| `effective` | A query that checks active settings against the intended configuration, not merely syntax or file existence. |
| `update_options` | Complete reviewed different options, including exact current per-object hashes and activation/source references where required. |
| `invalid_options` | Complete options that pass Sentinel planning, enter an actual write stage and fail the product's apply/configuration validation. A bad type or builder rejection is not enough. |
| `withdrawal` | A reviewed argv-forwarding wrapper to a separate observer, plus its explicit inventory, event-profile and report-directory paths. |
| `data_invariants` | Optional map from catalog data paths to deterministic logical data checks, described below. |

Probes are literal `argv` arrays. Keep secrets out of argument lists and reports:
use a reviewed protected credential/configuration mechanism. Probe code is
trusted operator-supplied test code and must itself be reviewed for scope and
side effects. Output matching is only as meaningful as the selected expectation.
Changing options must not silently change which scored transaction is tested.

## Restore & Withdraw is real reviewed execution

Rollback requests `restore-withdraw`, obtains and validates the actual review
and its digest, restricts that review to the exact host and action IDs recorded
by this test, then supplies `--approved-digest` for execution. A review-only exit
code of zero is not success. A conflicting or out-of-scope unexecuted review is
cancelled through the ordinary cancellation path. No forced ledger cleanup occurs.

The final result must be `complete`, mode `restore-withdraw`, bound to the same
review, conflict-free, and contain nonempty healthy **external** verification.
The watched configuration/data invariants and initial active/enabled state must
also be restored. Remove mode is refused because it preserves service changes.

The observer specification has exactly these keys:

```json
{
  "runtime_argv": ["/absolute/path/to/reviewed-observer-forwarder"],
  "inventory": "/absolute/observer/inventory.json",
  "event_profile": "/absolute/observer/event-profile.json",
  "directory": "/absolute/observer/new-private-withdraw-report"
}
```

The wrapper is supplied by the operator, forwards each literal argument safely,
returns the remote exit status, and returns the complete JSON response on stdout.
It is **not** a suggestion to join arguments into an `ssh` shell string. The
observer inventory must identify the same target and approved runtime/action
scope via its authorized management transport. Credentials and TLS trust must
already be configured. The ordinary observer-origin check is not overridden.
Without a suitable independent observer the production hold remains in place,
and no native receipt can be issued. Do not test this on a shared competition
host containing unrelated Sentinel-owned actions: the harness refuses those.

## Filesystem and failed-apply evidence

Snapshots use explicit file/directory/symlink/absent states. Regular files cover
content, mode, owner, group and extended attributes. Directory digests recursively
cover bounded child names, types and content/metadata. Revision checks detect
concurrent changes during reading. Permission errors, special files, coverage
limits and unstable observations raise errors; they are never converted to None
and compared as though nothing changed. Time/byte/entry/depth limits are explicit. This is a bounded traversal, not an atomic filesystem snapshot; use a quiescent fixture, native snapshot or appropriate logical invariants for concurrently changing data.

A symlink records the link, not the target's content. Preserved data containing
symlinks therefore requires an explicit product invariant. A live database/mail
queue normally changes bytes even when the application is behaving correctly.
Use a quiescent reviewed snapshot or deterministic logical checks such as a
stable set of test records, permissions or existing-message identifiers. The
query output's digest is compared before/after; the query must actually enumerate
the data that is intended to be preserved. No arbitrary database files are copied
back, and the test never claims a logical query covers data it did not read.

The outside-edit fixture captures the **post-edit** state, requires a specifically
identified ownership refusal and exact preservation, then removes only its own
marker if the state still matches. A third-party edit or deletion stops cleanup
and retains the private original backup. This fixture assumes an isolated lab;
it is not an adversarially atomic substitute for the production mutation ledger.

The failed-apply step uses native inotify to witness writes on the exact owned
paths. It also requires a failed, non-uncertain apply report and a completed
rollback, followed by exact pre-state/data-invariant comparison. Planning
rejection, empty write evidence, lost/overflowed watches or unknown outcomes
cannot pass. Events prove writes were observed, not which actor wrote them. Only
an isolated, quiescent test host supports attribution to the test. This verifies
**failed apply after writes**, not SIGKILL, kernel crash or sudden power loss.
Real reboot/crash campaigns remain separate; optional reboot is still skipped.

Identical reapply compares file state, `changed: false`, and systemd invocation,
start timestamps and restart counter. An unexpected new service invocation fails
even if the files have identical bytes. This is lifecycle evidence, not a
continuous network-availability measurement.

## Running and interpreting results

```sh
python3 tools/service_pack_acceptance.py --service YOUR_SERVICE --plan \
  --options /absolute/reviewed/options.json --profile /absolute/reviewed/profile.json
```

After reviewing the actual target and all test inputs on a disposable system:

```sh
python3 tools/service_pack_acceptance.py --service YOUR_SERVICE --run \
  --host-is-disposable --runtime /absolute/sentinel-blue-1.9.88.pyz \
  --inventory /absolute/reviewed/inventory.json \
  --event-profile /absolute/reviewed/event-profile.json \
  --options /absolute/reviewed/options.json --profile /absolute/reviewed/profile.json \
  --operator 'authorized operator' --product-version 'exact observed version' \
  --workdir /absolute/new-empty-private-work --state-dir /absolute/private/state
```

A failed required step prevents a receipt and blocks later mutation tests. The
harness attempts guarded restoration after an admitted apply when safe; it does
not overwrite unresolved outside edits. Keep the full private report and inspect
all holds. No clock-based performance or competition uptime follows from a unit
test pass rate. Positive local tests of the harness itself must be labeled as
simulations, filesystem fixtures or coordinator-contract tests—not native pack
acceptance. The separate validation report records exactly what this release ran.
