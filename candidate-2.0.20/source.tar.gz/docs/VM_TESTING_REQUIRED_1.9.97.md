# Sentinel Blue 1.9.97 — REQUIRED VM TESTING

**No new native acceptance was established.**

## Added 1.9.97 cases — REQUIRES VM TESTING, NOT RUN

Exercise early router failure at every file/table/route/address boundary with
competing operator edits. Test real timers and boot retries, then the complete
apply/commit/update/rollback/reboot/withdrawal lifecycle and existing-helper
upgrades. Measure deadlines on real services, NSS lookup failures, witness
cancellation/expiry, and output overflow with an independent observer. Use only
authorized disposable hosts, not a competition or shared production machine.

## Retained checklist; statuses unchanged

# Sentinel Blue 1.9.96 — REQUIRED VM TESTING

**Every native item below: REQUIRES VM TESTING — NOT RUN in this release.**

Local fixtures and graphical tests are documented separately. They are not full native acceptance. A disposable physical machine can provide native evidence; VMs are recommended for isolation. The shared Kali pool does not implicitly authorize disruptive tests.

## Added 1.9.95 native checks — NOT RUN

Exercise failed setup rollback with edits during validation and service restart;
time out real systemctl inventory and confirm agent continuity plus repair holds;
expire real local/SSH setup and independently inspect the target process tree;
exercise pending router confirmation, failure, reboot, old pending records and
committed Emergency Restore & Withdraw with concurrent IP-forwarding changes.
These require explicitly authorized disposable native infrastructure.

## Added 1.9.96 native checks — NOT RUN

Verify TCP and UDP inventory on each target distribution, including IPv6 and
collector failures. Exercise Redis/Mosquitto create/adopt/update under their
real service identities; verify directory traversal, ACLs, mandatory-access
policy, chroots and systemd sandbox behavior. Custom users/groups require
reviewed `file_access`. Prove special-file substitutions refuse promptly in
real setup/withdrawal, and verify lock contention through long-lived desktop,
agent and controller processes. Reconcile pending transactions before replacing
installed helpers. None of these native acceptance checks was run here.

## Infrastructure and lifecycle checks

### VM-L01 [P0] New probe-evidence correction on real service managers

**REQUIRES VM TESTING — NOT RUN.**

Environment: Disposable Linux VM, installed target service and its checking clients

Keep a healthy service running while a test-owned client becomes unavailable or the probe worker pool is occupied. Verify unchanged systemd invocation/no stop or file write, unverified health, and an actionable missing-check result. Restore checking capacity and prove normal checks recover. Then cause an approved genuine service failure and prove normal bounded recovery still works.

### VM-L02 [P0] Complete native service setup and adoption

**REQUIRES VM TESTING — NOT RUN.**

Environment: Disposable supported apt-family Linux VMs plus installed product prerequisites

For each configured product below: create/adopt, parse configuration, query effective settings, positive and denied transactions, identical reapply without restart, approved update, outside-edit preservation, failed apply after writes, native restart, rollback, and independently verified Restore & Withdraw. Adoption-only rows need adoption-specific acceptance; do not claim missing configuration adapters exist.

### VM-L03 [P0] systemd startup, enablement and reboot

**REQUIRES VM TESTING — NOT RUN.**

Environment: Disposable Linux VM with systemd as PID 1 and explicit reboot permission

Verify declared unit identity and start mode, actual service transitions, controller/agent boot registration, reboots, crash restarts, late dependencies, interrupted registration and restart-after-crash. All checks use exact delivered bytes and retain controller/ledger bindings.

### VM-L04 [P0] Remote SSH deployment and enrollment

**REQUIRES VM TESTING — NOT RUN.**

Environment: Two or more authorized native Linux VMs

Approved inventory -> runtime verification -> SSH deployment -> one-time enrollment -> fresh telemetry -> approved action -> application checks -> durable receipt. Exercise bad credentials, wrong host keys, duplicate enrollment, disconnection and retry without adopting untrusted identities.

### VM-L05 [P0] Independent observation and network-wide withdrawal

**REQUIRES VM TESTING — NOT RUN.**

Environment: At least one target VM and a genuinely separate authorized observer

Use actual signed/TLS observer reports and real event-profile authorization. Verify stale/missing evidence holds, review-only output is not execution, Remove preserves legitimate service changes, Restore & Withdraw restores only owned changes, and unrelated or teammate-modified objects block unsafe undo.

### VM-L06 [P0] Controller loss, offline operation and multi-host reconciliation (#17/#34)

**REQUIRES VM TESTING — NOT RUN.**

Environment: Multiple native agents and primary/replacement controllers

Test lost controller, permitted bounded offline actions, lease expiry, reconnect, staggered partitions, epoch changes, stale-controller return, replay/idempotence and conflict handling. No duplicate action and no admission from stale authority. Local fixture passes are not this test.

### VM-L07 [P1] Abrupt termination, storage interruption and recovery

**REQUIRES VM TESTING — NOT RUN.**

Environment: Disposable native VM with approved process-kill/reboot/snapshot controls

Exercise SIGKILL during mutation, agent/controller restart, disk-full during journal write, and separately approved reboot/power-loss cases. Preserve uncertain outcomes. The existing failed-apply-after-writes fixture does not prove hard-kill or power-loss recovery.

### VM-L08 [P1] Production load and 1/5/10/20/40-host scale (#22)

**REQUIRES VM TESTING — NOT RUN.**

Environment: Authorized native Linux VM pool with stated CPU/RAM/disk limits

Measure actual systemd/journald collection, telemetry freshness, probe-pool saturation, controller queue/DB growth, recording volume, latency percentiles and repair delay. Distinguish checker overload from service failure; do not extrapolate from local unit-test speed.

### VM-L09 [P1] Full-event and extended endurance

**REQUIRES VM TESTING — NOT RUN.**

Environment: Explicitly authorized sustained native range

Run declared event-length and longer campaigns with stable transaction observers. Measure successful/failed/unverified checks separately, per-service availability, memory/disk growth, cache aging, credential expiry, reconnection and accumulated action history. Do not convert unit-test pass rates to uptime.

### VM-L10 [P1] Filesystem/resource faults and existing diagnostic holds (#13)

**REQUIRES VM TESTING — NOT RUN.**

Environment: Disposable service-owned volume/cgroup, not the shared host root volume

Validate actual disk/inode exhaustion, read-only mounts, memory limits, restart loops, start limits and port conflicts. Confirm holds and recovery after external cause removal. This release does not add disk cleanup, OOM killing, port eviction or reset-failed automation.

### VM-L11 [P1] Native identities, persistence and ownership protections

**REQUIRES VM TESTING — NOT RUN.**

Environment: Disposable Linux VM with approved test-owned accounts/jobs/units

Verify actual cron/sudoers/systemd timer/socket/path collection and approved reversible response, protected/scoring/teammate exclusions, exact process identity, release/expiry and service effects. Validate native sudoers syntax where appropriate; generalized identity recovery is still incomplete.

### VM-L12 [P1] Measured detection and safe response (#30)

**REQUIRES VM TESTING — NOT RUN.**

Environment: Separately authorized isolated adversarial exercise plus independent ground truth

Measure misses, false alarms, containment side effects, attribution limits and repeated attacker interference. Test benign teammate/inject changes alongside allowed adversarial activity. No adversarial campaign was run in this release.

### VM-L13 [P1] Cross-host application and routing dependencies

**REQUIRES VM TESTING — NOT RUN.**

Environment: Isolated multi-host Linux application/network layout

Exercise DNS -> application -> database/mail/file-sharing dependencies and approved router/firewall paths. Verify true external transactions, partial failures, management connectivity, account/TLS dependencies and safe repair order. General appliance and cross-host recovery are not completed by this checklist.

### VM-L14 [P1] Distribution/version/native-permission compatibility

**REQUIRES VM TESTING — NOT RUN.**

Environment: Declared Debian/Ubuntu/Kali VM versions and relevant filesystems

Verify actual package prerequisites, unit/config paths, service identities, UID/GID, ACL/xattrs, symlink handling and security policy. Non-apt provisioning is still held; RPM-family support needs implementation before native acceptance.

### VM-L15 [P2] Real desktop and privilege-boundary startup

**REQUIRES VM TESTING — NOT RUN.**

Environment: Unprivileged Linux desktops with installed Python/Tk/cryptography

Verify installed launcher under the actual desktop/file manager and X11/XWayland policy, trust prompt, fresh/reused storage, missing prerequisites, recording failure visibility and clean shutdown. A graphical unit run here is not all-desktop acceptance; no new Python-free package is provided.

### VM-W01 [P1] Windows paths remain unaccepted

**REQUIRES VM TESTING — NOT RUN.**

Environment: Native Windows VM with explicit administrative test permission

SCM, ACLs, IIS, WinRM, scheduled tasks, domain behavior, Windows GUI, inventory and reboot paths remain native-untested. Shared probe-evidence logic is portable Python, but Linux tests do not accept Windows. Missing Windows feature/catalog/launcher work remains separate implementation work.

### VM-L17 [P0] Queued restart and preflight freshness revalidation

**REQUIRES VM TESTING — NOT RUN.**

Environment: Disposable native Linux VM with systemd, test-owned service and data volume, approved action profiles and explicit fault permission

Queue a permitted restart, then collect a newer sample reporting disabled/masked/missing/transitioning target, start-limit, OOM/resource verdict, native loop, port conflict or full/read-only business-data filesystem. Verify no start or service configuration change, a stated hold and no replay of that action. Test valid unchanged outage and independently recovered running service as positive controls. Delay checking/file preflight beyond the existing 90-second observation window: no first forward mutation may be admitted. Test changes occurring after the most recent observation separately; this release does not claim atomic native state revalidation. Retain normal rollback for already admitted work and confirm restart budgets/ledger and scope remain enforced.

### VM-L18 [P0] Local TLS checking prerequisites and unnamed probe completion

**REQUIRES VM TESTING — NOT RUN.**

Environment: Specifically authorized disposable native VMs, installed products and an independent observer

On native Linux/Windows service hosts with separate observers, change only test-owned checker CA material; confirm unverified evidence and no service stop/restart/write. Restore trust and verify checks recover. Confirm actual endpoint TLS/HTTP failures still report negative evidence. Exercise unnamed and named probes through authenticated remote queue/dispatch/completion without stale action state. Preserve all trust and authorization guards.

### VM-L19 [P1] Manual/automatic port setup and client dependency validation

**REQUIRES VM TESTING — NOT RUN.**

Environment: Specifically authorized disposable native VMs, installed products and an independent observer

For each editable adapter on supported disposable native products, drive the real GUI and actual remote setup: declared/default/manual ports, optional alternate suggestions, duplicate and wildcard/IPv4/IPv6 bind conflicts, socket-activation overrides, runtime listener races, effective configuration, positive/denied transactions, firewall and external clients/observers, idempotent reapply, approved updates, teammate conflicts, failed-apply rollback and Restore & Withdraw. Verify required scoring and SSH-management ports cannot be moved silently. Check BIND and Postfix parent snapshots, Dovecot 2.3 version contract, SMB multi-ports and FTP passive ranges. rsyslog is an outbound destination, not an inbound listener. This release does not migrate arbitrary client/scorer configurations or configure adopt-only products.

### VM-L20 [P0] Run the shipped acceptance profile for each configuring service

**REQUIRES VM TESTING — NOT RUN.**

Environment: Disposable apt-family Linux VM with the product installed, plus a genuinely separate authorized observer for the withdrawal step

Complete the DRAFT service profile with exact base/update/failed-apply pre-states, compiling options rejected by the product after writes, real positive/denied/effective/data queries and independent observer wiring. Run ordinary plans, actual configuration and transactions, reapply, updates, conflict preservation, failed-apply rollback and independent Restore & Withdraw. Builder refusals or template printing are not acceptance.

### VM-L21 [P0] Native denial and preflight contracts after 1.9.94

**REQUIRES VM TESTING — NOT RUN.**

Environment: Explicitly authorized disposable Linux VM with installed product/client and separate observer

Prove a specific denied operation and authorized operation on the real product. Refused connections, timeouts, missing credentials and checker errors must not pass denial. Verify correct stdout/stderr matching, protected credentials, verified peers, all three preplans, exact update pre-states, observed failed-apply writes and rollback. Confirm all twenty incomplete drafts refuse before mutation.

### VM-L22 [P1] Existing versus absent service automatic-port behavior

**REQUIRES VM TESTING — NOT RUN.**

Environment: Disposable native Linux desktop/target VM with fresh listener and service-presence telemetry

Existing/running/unknown services never qualify for alternate suggestion solely because options omit a port. Absent new eligible service may get a reviewed alternate; required/saved ports remain locked. Exercise stale/missing/cross-host presence and telemetry, actual bind addresses, firewall/scoring dependencies and normal reviewed apply/rollback. No reservation guarantee is implied.

## Catalog products — all 39 pending

All products remain native_tested: False. Configure does not mean prerequisite installer; adopt-only entries do not acquire configuration support by testing. Historical limited web checks do not constitute full service-manager/boot/remote acceptance.

```json
{
  "service_id": "openssh-server",
  "label": "OpenSSH server and SFTP",
  "family": "access",
  "capability": "configure",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Actual SSH login/SFTP with expected host key and protected credentials, rejected unauthorized login, and preserved scoring/management access.",
  "limitation": "Configuration-capable is not a prerequisite installer."
}
```

```json
{
  "service_id": "mosquitto",
  "label": "Mosquitto MQTT broker",
  "family": "broker",
  "capability": "configure",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Actual publish/consume with approved credentials and permissions, rejected unauthorized access and preserved durable messages where applicable.",
  "limitation": "Configuration-capable is not a prerequisite installer."
}
```

```json
{
  "service_id": "rabbitmq-server",
  "label": "RabbitMQ broker",
  "family": "broker",
  "capability": "adopt",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Actual publish/consume with approved credentials and permissions, rejected unauthorized access and preserved durable messages where applicable.",
  "limitation": "Adopt-only: full configuration/provisioning adapter remains unimplemented."
}
```

```json
{
  "service_id": "memcached",
  "label": "Memcached",
  "family": "cache",
  "capability": "adopt",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Authenticated permitted operations, explicit unauthenticated/unauthorized denial and preserved relevant data; no configuration-only auth assumption.",
  "limitation": "Adopt-only: full configuration/provisioning adapter remains unimplemented."
}
```

```json
{
  "service_id": "redis",
  "label": "Redis",
  "family": "cache",
  "capability": "configure",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Authenticated permitted operations, explicit unauthenticated/unauthorized denial and preserved relevant data; no configuration-only auth assumption.",
  "limitation": "Configuration-capable is not a prerequisite installer."
}
```

```json
{
  "service_id": "docker",
  "label": "Docker engine",
  "family": "container",
  "capability": "adopt",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Adoption of existing approved services without unauthorized relocation/redeployment; preserve volumes/images and service semantics.",
  "limitation": "Adopt-only: full configuration/provisioning adapter remains unimplemented."
}
```

```json
{
  "service_id": "podman",
  "label": "Podman",
  "family": "container",
  "capability": "adopt",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Adoption of existing approved services without unauthorized relocation/redeployment; preserve volumes/images and service semantics.",
  "limitation": "Adopt-only: full configuration/provisioning adapter remains unimplemented."
}
```

```json
{
  "service_id": "mariadb",
  "label": "MariaDB / MySQL",
  "family": "database",
  "capability": "configure",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Actual scoped read/write transaction and permission denial; listener/auth/TLS effective settings; preserve existing logical data and cluster state.",
  "limitation": "Configuration-capable is not a prerequisite installer."
}
```

```json
{
  "service_id": "mongodb",
  "label": "MongoDB",
  "family": "database",
  "capability": "adopt",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Actual scoped read/write transaction and permission denial; listener/auth/TLS effective settings; preserve existing logical data and cluster state.",
  "limitation": "Adopt-only: full configuration/provisioning adapter remains unimplemented."
}
```

```json
{
  "service_id": "postgresql",
  "label": "PostgreSQL",
  "family": "database",
  "capability": "configure",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Actual scoped read/write transaction and permission denial; listener/auth/TLS effective settings; preserve existing logical data and cluster state.",
  "limitation": "Configuration-capable is not a prerequisite installer."
}
```

```json
{
  "service_id": "isc-dhcp-server",
  "label": "ISC DHCP server",
  "family": "dhcp",
  "capability": "configure",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Lease acquisition/renewal on a specifically isolated segment, approved scopes/interfaces/reservations, and preserved leases; never broadcast onto the shared range.",
  "limitation": "Configuration-capable is not a prerequisite installer."
}
```

```json
{
  "service_id": "kea-dhcp4",
  "label": "Kea DHCPv4 server",
  "family": "dhcp",
  "capability": "adopt",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Lease acquisition/renewal on a specifically isolated segment, approved scopes/interfaces/reservations, and preserved leases; never broadcast onto the shared range.",
  "limitation": "Adopt-only: full configuration/provisioning adapter remains unimplemented."
}
```

```json
{
  "service_id": "freeradius",
  "label": "FreeRADIUS",
  "family": "directory",
  "capability": "adopt",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Approved bind/ticket/authentication and denied identity, correct realm/domain dependencies and preserved accounts/privileges.",
  "limitation": "Adopt-only: full configuration/provisioning adapter remains unimplemented."
}
```

```json
{
  "service_id": "krb5-kdc",
  "label": "Kerberos KDC",
  "family": "directory",
  "capability": "adopt",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Approved bind/ticket/authentication and denied identity, correct realm/domain dependencies and preserved accounts/privileges.",
  "limitation": "Adopt-only: full configuration/provisioning adapter remains unimplemented."
}
```

```json
{
  "service_id": "slapd",
  "label": "OpenLDAP directory",
  "family": "directory",
  "capability": "adopt",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Approved bind/ticket/authentication and denied identity, correct realm/domain dependencies and preserved accounts/privileges.",
  "limitation": "Adopt-only: full configuration/provisioning adapter remains unimplemented."
}
```

```json
{
  "service_id": "sssd",
  "label": "SSSD domain integration",
  "family": "directory",
  "capability": "adopt",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Approved bind/ticket/authentication and denied identity, correct realm/domain dependencies and preserved accounts/privileges.",
  "limitation": "Adopt-only: full configuration/provisioning adapter remains unimplemented."
}
```

```json
{
  "service_id": "bind9",
  "label": "BIND 9 authoritative/recursive DNS",
  "family": "dns",
  "capability": "configure",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Authoritative/recursive expected records, UDP/TCP and allowed dynamic updates; denied transfers/recursion; preserve zone files and journals.",
  "limitation": "Configuration-capable is not a prerequisite installer."
}
```

```json
{
  "service_id": "dnsmasq",
  "label": "dnsmasq DNS and DHCP",
  "family": "dns",
  "capability": "configure",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Authoritative/recursive expected records, UDP/TCP and allowed dynamic updates; denied transfers/recursion; preserve zone files and journals.",
  "limitation": "Configuration-capable is not a prerequisite installer."
}
```

```json
{
  "service_id": "unbound",
  "label": "Unbound recursive resolver",
  "family": "dns",
  "capability": "configure",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Authoritative/recursive expected records, UDP/TCP and allowed dynamic updates; denied transfers/recursion; preserve zone files and journals.",
  "limitation": "Configuration-capable is not a prerequisite installer."
}
```

```json
{
  "service_id": "rsyslog",
  "label": "rsyslog",
  "family": "logging",
  "capability": "configure",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Actual test event delivery and correct source handling, preserved logs and bounded resource behavior.",
  "limitation": "Configuration-capable is not a prerequisite installer."
}
```

```json
{
  "service_id": "dovecot",
  "label": "Dovecot IMAP/POP3",
  "family": "mail",
  "capability": "configure",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Authorized send/receipt and mailbox access, denied relay/login, effective TLS/identity settings and preserved existing queues/messages.",
  "limitation": "Configuration-capable is not a prerequisite installer."
}
```

```json
{
  "service_id": "exim4",
  "label": "Exim MTA",
  "family": "mail",
  "capability": "adopt",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Authorized send/receipt and mailbox access, denied relay/login, effective TLS/identity settings and preserved existing queues/messages.",
  "limitation": "Adopt-only: full configuration/provisioning adapter remains unimplemented."
}
```

```json
{
  "service_id": "postfix",
  "label": "Postfix SMTP",
  "family": "mail",
  "capability": "configure",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Authorized send/receipt and mailbox access, denied relay/login, effective TLS/identity settings and preserved existing queues/messages.",
  "limitation": "Configuration-capable is not a prerequisite installer."
}
```

```json
{
  "service_id": "cups",
  "label": "CUPS printing",
  "family": "printing",
  "capability": "adopt",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Authorized print/job queue operations and denied unauthorized access, preserving existing queue/configuration.",
  "limitation": "Adopt-only: full configuration/provisioning adapter remains unimplemented."
}
```

```json
{
  "service_id": "haproxy",
  "label": "HAProxy load balancer",
  "family": "proxy",
  "capability": "configure",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Correct frontend/backend routing, health/failure behavior, access restrictions and TLS as required.",
  "limitation": "Configuration-capable is not a prerequisite installer."
}
```

```json
{
  "service_id": "squid",
  "label": "Squid forward proxy",
  "family": "proxy",
  "capability": "adopt",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Correct frontend/backend routing, health/failure behavior, access restrictions and TLS as required.",
  "limitation": "Adopt-only: full configuration/provisioning adapter remains unimplemented."
}
```

```json
{
  "service_id": "gunicorn",
  "label": "Python WSGI application unit",
  "family": "runtime",
  "capability": "configure",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Correct application/unit identity, served application transaction, process user/environment and dependency readiness.",
  "limitation": "Configuration-capable is not a prerequisite installer."
}
```

```json
{
  "service_id": "php-fpm",
  "label": "PHP-FPM application runtime",
  "family": "runtime",
  "capability": "adopt",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Correct application/unit identity, served application transaction, process user/environment and dependency readiness.",
  "limitation": "Adopt-only: full configuration/provisioning adapter remains unimplemented."
}
```

```json
{
  "service_id": "tomcat",
  "label": "Apache Tomcat",
  "family": "runtime",
  "capability": "adopt",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Correct application/unit identity, served application transaction, process user/environment and dependency readiness.",
  "limitation": "Adopt-only: full configuration/provisioning adapter remains unimplemented."
}
```

```json
{
  "service_id": "nfs-server",
  "label": "NFS exports",
  "family": "sharing",
  "capability": "configure",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Actual share/export file operations and identity/client denial, preserved contents and access controls.",
  "limitation": "Configuration-capable is not a prerequisite installer."
}
```

```json
{
  "service_id": "samba",
  "label": "Samba SMB file services",
  "family": "sharing",
  "capability": "configure",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Actual share/export file operations and identity/client denial, preserved contents and access controls.",
  "limitation": "Configuration-capable is not a prerequisite installer."
}
```

```json
{
  "service_id": "chrony",
  "label": "chrony time service",
  "family": "time",
  "capability": "configure",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Correct approved time-source operation and authentication/restrictions where configured; no unapproved system-wide clock changes.",
  "limitation": "Configuration-capable is not a prerequisite installer."
}
```

```json
{
  "service_id": "ntpd",
  "label": "ntpd / ntpsec time service",
  "family": "time",
  "capability": "adopt",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Correct approved time-source operation and authentication/restrictions where configured; no unapproved system-wide clock changes.",
  "limitation": "Adopt-only: full configuration/provisioning adapter remains unimplemented."
}
```

```json
{
  "service_id": "systemd-timesyncd",
  "label": "systemd-timesyncd",
  "family": "time",
  "capability": "adopt",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Correct approved time-source operation and authentication/restrictions where configured; no unapproved system-wide clock changes.",
  "limitation": "Adopt-only: full configuration/provisioning adapter remains unimplemented."
}
```

```json
{
  "service_id": "proftpd",
  "label": "ProFTPD",
  "family": "transfer",
  "capability": "adopt",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Authorized upload/download/login as required, checksum and permission checks, denied unauthorized operations, and preserved data.",
  "limitation": "Adopt-only: full configuration/provisioning adapter remains unimplemented."
}
```

```json
{
  "service_id": "tftpd-hpa",
  "label": "TFTP server",
  "family": "transfer",
  "capability": "adopt",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Authorized upload/download/login as required, checksum and permission checks, denied unauthorized operations, and preserved data.",
  "limitation": "Adopt-only: full configuration/provisioning adapter remains unimplemented."
}
```

```json
{
  "service_id": "vsftpd",
  "label": "vsftpd FTP/FTPS",
  "family": "transfer",
  "capability": "configure",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Authorized upload/download/login as required, checksum and permission checks, denied unauthorized operations, and preserved data.",
  "limitation": "Configuration-capable is not a prerequisite installer."
}
```

```json
{
  "service_id": "apache2",
  "label": "Apache HTTP Server",
  "family": "web",
  "capability": "configure",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Correct hostname/port/content and HTTPS identity, effective virtual host, exact reapply/update and failed-config rollback.",
  "limitation": "Configuration-capable is not a prerequisite installer."
}
```

```json
{
  "service_id": "nginx",
  "label": "nginx HTTP/HTTPS",
  "family": "web",
  "capability": "configure",
  "native_tested": false,
  "status": "REQUIRES_VM_TESTING_NOT_RUN",
  "required_evidence": "Correct hostname/port/content and HTTPS identity, effective virtual host, exact reapply/update and failed-config rollback.",
  "limitation": "Configuration-capable is not a prerequisite installer."
}
```

## Implementation still open (not closed by a VM test)

- Broad root-cause remediation (#13), including start-limit/resource/port-conflict cases.
- Generalized application/identity/network and cross-host recovery.
- Full provisioners for 19 adopt-only catalog entries and reversible prerequisite installation.
- Non-apt platform contracts; Python-free current offline bundle; complete novice setup/observer workflow.
