# Sentinel Blue 1.9.89 — REQUIRED VM TESTING

**Status: all items below require native VM testing and were NOT RUN in this release.**
Baseline: corrected 1.9.88. This release fixes execution-time probe evidence;
it does not accept the service catalog, a native operating system or a competition.
A disposable native machine can also supply OS evidence; VMs are the recommended
isolation for the workflows below. A container or mocked systemctl is not a substitute.

## What was changed, versus what remains

A saturated checker no longer reports a fabricated service outage. A fresh local
check that did not execute cannot authorize stopping a running service. Native
checking-client readiness is checked before service mutations, and executed,
matching evidence is required for successful validation and controller acceptance.
These are guarded runtime corrections, not new blanket repair authority.

Local regression tests and actual loopback HTTP/file/thread fixtures cover the
correction. The validation report records measured counts. Native service control
is mocked in the repair fixtures. No catalog row or acceptance receipt is promoted.

## Native infrastructure checklist

### VM-L01 [P0] New probe-evidence correction on real service managers

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Disposable Linux VM, installed target service and its checking clients.

**Required evidence:** Keep a healthy service running while a test-owned client becomes unavailable or the probe worker pool is occupied. Verify unchanged systemd invocation/no stop or file write, unverified health, and an actionable missing-check result. Restore checking capacity and prove normal checks recover. Then cause an approved genuine service failure and prove normal bounded recovery still works.

### VM-L02 [P0] Complete native service setup and adoption

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Disposable supported apt-family Linux VMs plus installed product prerequisites.

**Required evidence:** For each configured product below: create/adopt, parse configuration, query effective settings, positive and denied transactions, identical reapply without restart, approved update, outside-edit preservation, failed apply after writes, native restart, rollback, and independently verified Restore & Withdraw. Adoption-only rows need adoption-specific acceptance; do not claim missing configuration adapters exist.

### VM-L03 [P0] systemd startup, enablement and reboot

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Disposable Linux VM with systemd as PID 1 and explicit reboot permission.

**Required evidence:** Verify declared unit identity and start mode, actual service transitions, controller/agent boot registration, reboots, crash restarts, late dependencies, interrupted registration and restart-after-crash. All checks use exact delivered bytes and retain controller/ledger bindings.

### VM-L04 [P0] Remote SSH deployment and enrollment

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Two or more authorized native Linux VMs.

**Required evidence:** Approved inventory -> runtime verification -> SSH deployment -> one-time enrollment -> fresh telemetry -> approved action -> application checks -> durable receipt. Exercise bad credentials, wrong host keys, duplicate enrollment, disconnection and retry without adopting untrusted identities.

### VM-L05 [P0] Independent observation and network-wide withdrawal

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** At least one target VM and a genuinely separate authorized observer.

**Required evidence:** Use actual signed/TLS observer reports and real event-profile authorization. Verify stale/missing evidence holds, review-only output is not execution, Remove preserves legitimate service changes, Restore & Withdraw restores only owned changes, and unrelated or teammate-modified objects block unsafe undo.

### VM-L06 [P0] Controller loss, offline operation and multi-host reconciliation (#17/#34)

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Multiple native agents and primary/replacement controllers.

**Required evidence:** Test lost controller, permitted bounded offline actions, lease expiry, reconnect, staggered partitions, epoch changes, stale-controller return, replay/idempotence and conflict handling. No duplicate action and no admission from stale authority. Local fixture passes are not this test.

### VM-L07 [P1] Abrupt termination, storage interruption and recovery

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Disposable native VM with approved process-kill/reboot/snapshot controls.

**Required evidence:** Exercise SIGKILL during mutation, agent/controller restart, disk-full during journal write, and separately approved reboot/power-loss cases. Preserve uncertain outcomes. The existing failed-apply-after-writes fixture does not prove hard-kill or power-loss recovery.

### VM-L08 [P1] Production load and 1/5/10/20/40-host scale (#22)

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Authorized native Linux VM pool with stated CPU/RAM/disk limits.

**Required evidence:** Measure actual systemd/journald collection, telemetry freshness, probe-pool saturation, controller queue/DB growth, recording volume, latency percentiles and repair delay. Distinguish checker overload from service failure; do not extrapolate from local unit-test speed.

### VM-L09 [P1] Full-event and extended endurance

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Explicitly authorized sustained native range.

**Required evidence:** Run declared event-length and longer campaigns with stable transaction observers. Measure successful/failed/unverified checks separately, per-service availability, memory/disk growth, cache aging, credential expiry, reconnection and accumulated action history. Do not convert unit-test pass rates to uptime.

### VM-L10 [P1] Filesystem/resource faults and existing diagnostic holds (#13)

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Disposable service-owned volume/cgroup, not the shared host root volume.

**Required evidence:** Validate actual disk/inode exhaustion, read-only mounts, memory limits, restart loops, start limits and port conflicts. Confirm holds and recovery after external cause removal. This release does not add disk cleanup, OOM killing, port eviction or reset-failed automation.

### VM-L11 [P1] Native identities, persistence and ownership protections

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Disposable Linux VM with approved test-owned accounts/jobs/units.

**Required evidence:** Verify actual cron/sudoers/systemd timer/socket/path collection and approved reversible response, protected/scoring/teammate exclusions, exact process identity, release/expiry and service effects. Validate native sudoers syntax where appropriate; generalized identity recovery is still incomplete.

### VM-L12 [P1] Measured detection and safe response (#30)

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Separately authorized isolated adversarial exercise plus independent ground truth.

**Required evidence:** Measure misses, false alarms, containment side effects, attribution limits and repeated attacker interference. Test benign teammate/inject changes alongside allowed adversarial activity. No adversarial campaign was run in this release.

### VM-L13 [P1] Cross-host application and routing dependencies

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Isolated multi-host Linux application/network layout.

**Required evidence:** Exercise DNS -> application -> database/mail/file-sharing dependencies and approved router/firewall paths. Verify true external transactions, partial failures, management connectivity, account/TLS dependencies and safe repair order. General appliance and cross-host recovery are not completed by this checklist.

### VM-L14 [P1] Distribution/version/native-permission compatibility

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Declared Debian/Ubuntu/Kali VM versions and relevant filesystems.

**Required evidence:** Verify actual package prerequisites, unit/config paths, service identities, UID/GID, ACL/xattrs, symlink handling and security policy. Non-apt provisioning is still held; RPM-family support needs implementation before native acceptance.

### VM-L15 [P2] Real desktop and privilege-boundary startup

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Unprivileged Linux desktops with installed Python/Tk/cryptography.

**Required evidence:** Verify installed launcher under the actual desktop/file manager and X11/XWayland policy, trust prompt, fresh/reused storage, missing prerequisites, recording failure visibility and clean shutdown. A graphical unit run here is not all-desktop acceptance; no new Python-free package is provided.

### VM-W01 [P1] Windows paths remain unaccepted

**REQUIRES VM TESTING — NOT RUN.**

**Environment:** Native Windows VM with explicit administrative test permission.

**Required evidence:** SCM, ACLs, IIS, WinRM, scheduled tasks, domain behavior, Windows GUI, inventory and reboot paths remain native-untested. Shared probe-evidence logic is portable Python, but Linux tests do not accept Windows. Missing Windows feature/catalog/launcher work remains separate implementation work.

## All 39 catalog products: native acceptance still required

Every row below is **REQUIRES VM TESTING — NOT RUN** for complete native acceptance.
The 20 configuration-capable entries generate configuration; they are not universal
prerequisite installers. The other 19 remain adopt-only and need additional code
before full provisioning can be tested. Historical limited nginx/Apache application
checks are not erased, but were not repeated or upgraded to native acceptance here.

| Service | Capability now | Required native evidence |
|---|---|---|
| openssh-server | configure | Actual SSH login/SFTP with expected host key and protected credentials, rejected unauthorized login, and preserved scoring/management access. |
| mosquitto | configure | Actual publish/consume with approved credentials and permissions, rejected unauthorized access and preserved durable messages where applicable. |
| rabbitmq-server | adopt | Actual publish/consume with approved credentials and permissions, rejected unauthorized access and preserved durable messages where applicable. |
| memcached | adopt | Authenticated permitted operations, explicit unauthenticated/unauthorized denial and preserved relevant data; no configuration-only auth assumption. |
| redis | configure | Authenticated permitted operations, explicit unauthenticated/unauthorized denial and preserved relevant data; no configuration-only auth assumption. |
| docker | adopt | Adoption of existing approved services without unauthorized relocation/redeployment; preserve volumes/images and service semantics. |
| podman | adopt | Adoption of existing approved services without unauthorized relocation/redeployment; preserve volumes/images and service semantics. |
| mariadb | configure | Actual scoped read/write transaction and permission denial; listener/auth/TLS effective settings; preserve existing logical data and cluster state. |
| mongodb | adopt | Actual scoped read/write transaction and permission denial; listener/auth/TLS effective settings; preserve existing logical data and cluster state. |
| postgresql | configure | Actual scoped read/write transaction and permission denial; listener/auth/TLS effective settings; preserve existing logical data and cluster state. |
| isc-dhcp-server | configure | Lease acquisition/renewal on a specifically isolated segment, approved scopes/interfaces/reservations, and preserved leases; never broadcast onto the shared range. |
| kea-dhcp4 | adopt | Lease acquisition/renewal on a specifically isolated segment, approved scopes/interfaces/reservations, and preserved leases; never broadcast onto the shared range. |
| freeradius | adopt | Approved bind/ticket/authentication and denied identity, correct realm/domain dependencies and preserved accounts/privileges. |
| krb5-kdc | adopt | Approved bind/ticket/authentication and denied identity, correct realm/domain dependencies and preserved accounts/privileges. |
| slapd | adopt | Approved bind/ticket/authentication and denied identity, correct realm/domain dependencies and preserved accounts/privileges. |
| sssd | adopt | Approved bind/ticket/authentication and denied identity, correct realm/domain dependencies and preserved accounts/privileges. |
| bind9 | configure | Authoritative/recursive expected records, UDP/TCP and allowed dynamic updates; denied transfers/recursion; preserve zone files and journals. |
| dnsmasq | configure | Authoritative/recursive expected records, UDP/TCP and allowed dynamic updates; denied transfers/recursion; preserve zone files and journals. |
| unbound | configure | Authoritative/recursive expected records, UDP/TCP and allowed dynamic updates; denied transfers/recursion; preserve zone files and journals. |
| rsyslog | configure | Actual test event delivery and correct source handling, preserved logs and bounded resource behavior. |
| dovecot | configure | Authorized send/receipt and mailbox access, denied relay/login, effective TLS/identity settings and preserved existing queues/messages. |
| exim4 | adopt | Authorized send/receipt and mailbox access, denied relay/login, effective TLS/identity settings and preserved existing queues/messages. |
| postfix | configure | Authorized send/receipt and mailbox access, denied relay/login, effective TLS/identity settings and preserved existing queues/messages. |
| cups | adopt | Authorized print/job queue operations and denied unauthorized access, preserving existing queue/configuration. |
| haproxy | configure | Correct frontend/backend routing, health/failure behavior, access restrictions and TLS as required. |
| squid | adopt | Correct frontend/backend routing, health/failure behavior, access restrictions and TLS as required. |
| gunicorn | configure | Correct application/unit identity, served application transaction, process user/environment and dependency readiness. |
| php-fpm | adopt | Correct application/unit identity, served application transaction, process user/environment and dependency readiness. |
| tomcat | adopt | Correct application/unit identity, served application transaction, process user/environment and dependency readiness. |
| nfs-server | configure | Actual share/export file operations and identity/client denial, preserved contents and access controls. |
| samba | configure | Actual share/export file operations and identity/client denial, preserved contents and access controls. |
| chrony | configure | Correct approved time-source operation and authentication/restrictions where configured; no unapproved system-wide clock changes. |
| ntpd | adopt | Correct approved time-source operation and authentication/restrictions where configured; no unapproved system-wide clock changes. |
| systemd-timesyncd | adopt | Correct approved time-source operation and authentication/restrictions where configured; no unapproved system-wide clock changes. |
| proftpd | adopt | Authorized upload/download/login as required, checksum and permission checks, denied unauthorized operations, and preserved data. |
| tftpd-hpa | adopt | Authorized upload/download/login as required, checksum and permission checks, denied unauthorized operations, and preserved data. |
| vsftpd | configure | Authorized upload/download/login as required, checksum and permission checks, denied unauthorized operations, and preserved data. |
| apache2 | configure | Correct hostname/port/content and HTTPS identity, effective virtual host, exact reapply/update and failed-config rollback. |
| nginx | configure | Correct hostname/port/content and HTTPS identity, effective virtual host, exact reapply/update and failed-config rollback. |

## Work that is NOT merely waiting for a VM

The following remains implementation work as well as a later validation need:

- Broad root-cause remediation (#13), including start-limit/resource/port-conflict cases.
- Generalized application/identity/network and cross-host recovery.
- Full provisioners for 19 adopt-only catalog entries and reversible prerequisite installation.
- Non-apt platform contracts; Python-free current offline bundle; complete novice setup/observer workflow.

The #13 hold on reset-failed, out-of-memory/resource faults, looping units,
occupied ports and full/read-only filesystems is retained. This change must not be
misread as adding those root-cause remediators. The eight R87 harness corrections
remain incorporated and are not re-listed as unresolved defects.

## Conditions for closing a VM item

Record the exact runtime hash, source/tool identity, OS/product versions, approved
profile/options, test inputs and expected outcomes. Retain full bounded logs,
transaction results, before/after ownership and data evidence, and failures/skips.
Use the matching 1.9.89 private acceptance tools with the runtime. Product profiles
must include effective-setting checks and real positive/denied transactions;
passing shell syntax or returning zero is not enough. Separate-host withdrawal
verification, bootstrap/reboot and multi-host/endurance each need their own evidence.

Do not fill an evidence gap by changing `native_tested`, editing receipt schemas,
removing approvals, widening scope or clearing the ledger. No current uptime
percentage follows from the local test results.

## Your shared Proxmox pool

Your 40 Kali VMs are potential test capacity, not automatic permission to disrupt
shared services. Obtain the environment owner's explicit approval for any mutation,
restart, fault injection, DHCP/routing, network changes, memory/disk pressure or
reboot. Otherwise confine work to read-only checks and separately approved
per-user fixtures. This release accessed no Proxmox/Azure hosts and changed no
hypervisor or remote-machine settings.

Source basis: the actual 1.9.88 runtime, its validation report and inherited Linux
catalog/operating boundaries. This document is a pending acceptance plan, not a
claim that all listed operations already have complete automation implementations.
