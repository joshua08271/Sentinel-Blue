# Sentinel Blue 1.9.98 — Linux fixes 15–20

This corrects the six findings in the third Linux review of 1.9.97, retaining
fixes 1–14. No target-native acceptance or measured scored-service availability
is implied. Consult the delivered measured report/evidence for executed tests.

## Router rollback completion (15)

A completed inverse retains its action identity until object restoration and
required service controls finish. A hash-chained completion event binds the exact
restored snapshot, pending state and intended restored lifecycle state to the
admitted action. The preceding native state is stored at admission and verified
before any inverse. Recovery reconciles this event against current exact
revisions and authenticated original before-state, republishes the recorded
restored state when appropriate, rebases the preceding committed file revision
evidence after a verified update inverse, and cancels the failed action.

Automatic apply failures, explicit rollback, confirmation expiry and pending boot
rollback use this common reconciliation. Completed cancellation retries do not
append another mutation. Changed objects/lifecycle state, failed service control,
altered inverses and missing completion proof remain held. The event
`router_rollback_completed` is evidence, not a healthy/committed state. Ledger
transition rules are not relaxed. The withdrawal adapter retains its own undo
lifecycle and does not emit setup-cancellation events.

## Committed ownership and confirmation (16–17)

Committed helper contents, metadata and revisions are compared with the currently
expected authenticated ledger snapshot. Update admission also compares declared
router objects, routes/addresses and owned forwarding before preparing/writing
an update. Inverse metadata must match its immutable ledger reference. Third-party
modes, groups, attributes and same-byte replacements are conflicts, not baselines.
Checks and boot do not silently adopt changed persistent helpers; the boot path
can still reinstall missing declared volatile networking under existing guards.

A healthy, unchanged, authenticated already-committed router can be confirmed
again without another ledger commit or duplicate mutation. Wrong-spec,
unauthenticated, changed and unresolved records refuse. The real setup runner
continues requiring its normal reviewed external health checks.

## Process privilege evidence (18)

ProcessObservation adds optional Linux `real_uid`, `effective_uid`, `saved_uid`,
`filesystem_uid` and `effective_capabilities`. `username` still names the real UID.
The conservative `privileged` flag is true when any of the four UIDs is zero or
CapEff is nonzero. Malformed UID/capability evidence reports incomplete coverage.
Nonroot identities without effective capabilities remain unprivileged under this
rule. This is not a full namespace, LSM, sudoers or capability-policy evaluator;
nonzero capabilities are deliberately a broad indicator. The optional fields
default to None on Windows; no native Windows validation is inferred.

## Persistence coverage (19)

Directory enumeration retains the deterministic smallest 1,025 entries in a
bounded heap. The first 1,024 are processed, with a per-source incomplete-coverage
diagnostic on overflow. The 2,048-unit list limit similarly reports truncation.
Missing source directories are normal; inaccessible directories and failed or
timed-out unit inventory report incomplete coverage. Partial observations remain
useful but do not authorize a complete-data claim.

## Internal native-client capture (20)

The shared standalone `bounded_capture.py` reads output through a pipe and retains
at most the caller's response quota (plus a fixed read chunk to detect overflow).
There is no child-output spool. Service-pack checks share a 1 MiB stdout/stderr
quota; scoring clients use a 64 KiB stdout quota with stderr discarded, not saved.
A finite private stdin file remains. The helper is embedded in generated
service-pack scripts, which do not require an installed Sentinel package.

Overflow and timeouts terminate the owned group/tree and return sanitized failure,
never partial healthy output. The POSIX leader is not polled/reaped before final
group termination. Cleanup grace is separate from execution time. Diagnostics do
not echo argv, input or output. Stopping a client does not establish remote write
rollback. Deliberately escaped groups and uninterruptible kernel/filesystem
operations are outside this mechanism. Windows fallback is not natively tested.

## Upgrade and existing state

Reapprove `release.version`/`release.sha256` and regenerate setup scripts. Replacing
the runtime does not rewrite installed native.py/witness helpers or pending timers.
Reconcile pending changes with their matching preserved helpers/evidence before
upgrading. Preserve ledgers, snapshots and receipts. Legacy unresolved actions
without authenticated completion proof are NOT silently cancelled or guessed
correct. Legacy pending router actions lacking the preceding-state reference
require explicit review. Historical damaged/truncated or falsely uncertain state
is not rewritten. Intact committed records remain usable for a new reviewed
update after checking their existing content and metadata.

## Local reproduction

Run only on authorized disposable development infrastructure, from source root:

```sh
env -u DISPLAY -u WAYLAND_DISPLAY PYTHONPATH=.:src:tests python3 -m unittest test_linux_hotfix_1998 test_linux_hotfix_1997 test_linux_hotfix_1996 test_linux_hotfix_1995 -v
env -u DISPLAY -u WAYLAND_DISPLAY PYTHONPATH=.:src:tests python3 -m unittest discover -s tests -t tests -v
PYTHONPATH=. python3 tools/build_defensive_release.py --output ../build
```

Native host boot/restart, real routers, SSH/remote observers, target distribution,
NSS and mandatory-access policy, Windows-native clients and competition exercises
remain separate validation. Local network/service commands are modeled.
