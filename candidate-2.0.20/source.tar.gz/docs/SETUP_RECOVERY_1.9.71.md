# Setup rollback and router verification — 1.9.71

Use this with the inventory and event profile reviewed for your range. The release status gives the exact tested runtime checksum and the limits of the live acceptance. This guide describes the implementation; it is not evidence of event-wide acceptance.

## Owned rollback

The setup scheduler reserves part of each task's existing deadline for rollback. If an apply command completes but subsequent native or external service checks fail, it runs that task's rollback and records whether restoration completed. Verification exceptions also enter this path. An uncertain apply, an expired deadline, or an unconfirmed rollback holds the host for review and never grants permission to replay the mutation.

Built-in transactions persist their intent and snapshots before changing resources. A new controller or reopened workspace cannot adopt an unresolved transaction simply because the service is now reachable. Both the desktop recording and setup state retain the transaction identifier and rollback outcome; raw command output and backup contents remain in protected local storage.

| Recipe | Restoration scope |
| --- | --- |
| `linux-service` | Declared file bytes, mode, ownership and extended attributes; previous unit configuration, running state and enablement. New units are stopped before their unit files are removed. |
| `linux-nginx` | Owned site configuration, content and declared TLS files, plus nginx's previous running state and enablement. |
| `windows-service` | Previous running state, startup type and delayed-start registry setting, including whether the setting existed. |
| `windows-firewall` | Newly created matching rules only. Pre-existing matching rules are retained. |
| `windows-iis` | Newly created owned site, pool, content and HTTPS binding; previous site/pool/service running states. Existing certificates remain installed. |
| `linux-router` | The existing native guarded router transaction, with additional refusal when later policy/helper changes make automatic restoration unsafe. |
| Scored `runbook` | The explicit, checksum-pinned rollback supplied by the operator. Compilation refuses a scored custom runbook without one. |

Shared package and Windows feature prerequisites remain installed. Empty Linux application directories and private transaction records may remain. These are scoped resource transactions, not whole-machine snapshots or coordinated rollback of already committed work on other hosts.

Before restoration, the helper checks its recorded after-state and backup integrity. Later content, permission, service configuration or firewall changes cause a hold. IIS also checks its configuration file conservatively: an unrelated IIS change can require review. A stopped or crashed service can still be restored when its configuration matches.

Linux transaction records are under `/var/lib/sentinel-blue-setup-transactions`; Windows records are under `%ProgramData%\SentinelBlueSetupTransactions`. Preserve unresolved records for review. Deleting ownership records is not a safe way to authorize another setup attempt. Completed records and captured output still need disk-retention management.

## Routed service checks

For a router that forwards traffic, every downstream setup probe needs a corresponding `path_checks` entry. `probe_index` is zero-based within the router manifest's `expected_transactions`; keep the fresh management connection probe there too.

```json
"path_checks": [
  {
    "probe_index": 1,
    "source_address": "10.20.1.10",
    "in_interface": "eth1",
    "out_interface": "eth2"
  }
]
```

The source must be a real IPv4 address assigned to the machine running setup. The source, router and downstream destination must be separate authorized hosts. Both interfaces and the destination port must match a declared forwarding rule. Use the actual event values, not the example addresses.

For each observation, setup reserves a fresh source port, arms a temporary counter on the intended router over its authenticated management transport, then makes the actual TCP/HTTP/HTTPS connection from that endpoint. Readiness requires both successful application health and matching forward-path SYN/SYN-ACK counters. A healthy service reached through another path is rejected.

Arming verifies that the forward chain and both counter rules actually exist. The native helper uses explicit table, chain and rule commands in one transaction. Live nftables 1.0.9 testing showed that the earlier nested `create table` form could return success with only an empty table; an empty or incomplete witness is now rejected before probing.

The counter rules do not add allow exceptions. They run after Sentinel's forward-filter decision and have a native expiry timer, so a lost checking process does not normally leave active witnesses. Modified or incompletely recorded witness state requires review rather than unconditional deletion. Private witness records live under `/var/lib/sentinel-blue-route-checks` and are retained after closure.

This relies on Linux's real forwarding hook and ordered nftables base-chain processing. An accept policy in the counter chain does not override a drop in another chain. [Official nftables manual](https://www.netfilter.org/projects/nftables/manpage.html).

The current witness supports literal IPv4 TCP, HTTP and HTTPS endpoints. It does not add IPv6, general appliances, UDP/DNS path proof, NAT types beyond the router adapter's existing support, or official competition scorer integration. The router and controller remain trusted components: root access can falsify host evidence. Actual event topology and identities still need event-specific acceptance.
