# Sentinel Blue 2.0.20 — recovery capsule correction

Native Kali testing of 2.0.19 found that copying nested restore metadata into a
recovery capsule could create intermediate folders with group/other access.
The capsule verifier then correctly rejected those folders, and retention
correctly preserved the unverified material instead of deleting it. That could
eventually stop automatic backups at the storage budget.

This candidate creates each copied directory level privately. Regression tests
use real restore-point metadata under umask 022 and 000, then verify the capsule,
restore a lost database and ledger, and exercise retention. Changed permissions
are still rejected; existing failed capsules are not silently repaired.

Retained-capsule inspection now authenticates historical material separately
from restore admission. Restoration still requires the exact latest protected
backup, matching release/profile, independent key and anchor, and intact ledger.

The storage rehearsal now uses its own ledger, includes nested restore metadata,
verifies complete current-format capsules, and detects backup stalls and retention
failure. The recording fixture starts with an already-ready owned HTTP service.
Two regression assertions now account for private installer modes and native
systemd hosts; the separate archive-mode and non-systemd refusal checks remain.

The companion testing checkpoint records results for the exact release hashes.
Earlier native measurements belong to 2.0.19. No full catalog, reboot, Windows,
independent multi-host, or endurance acceptance is implied by this correction.
Controller, agents and desktop must use the same reviewed release. Preserve
private state and use the existing reviewed upgrade workflow.
