# Sentinel Blue 1.9.39

Development candidate 1.9.39 reuses an owned PowerShell inventory host while fetching fresh observations for every cycle. Each request requires its own nonce, every expected section, and a completion record within the original deadline. Timeout, malformed output, replay, or failed helper cleanup cannot authorize action. A native diagnostic measured four loaded queries at 100.086 seconds cold and 59.834 seconds with reused modules; this is not yet a successful full-collection or deployment measurement. Native validation is pending.

Version 1.9.38 holds provisioning after an uncertain initial readiness check. Previously, two timed-out Windows feature reads could be followed by an install command. The focused regression now verifies that no mutation starts.

Version 1.9.37 removes the duplicate Windows feature inventory that caused the native preparation failure. The actual setup task still verifies all required features. Its native Windows practice still failed setup, persistence execution and loaded collection; transport, probe deadlines and service repair passed. All four VMs were deallocated and the original network restored. The recovered preceding Linux guest run passed all five phases in 226.18 seconds, including service-plus-Sentinel setup in 66.564 seconds with existing packages; its surrounding Azure command timed out.

Version 1.9.36 extends total network deadlines to service probes and opening readiness. In 60 live slow-response trials with a 0.25-second budget, it rejected late results in 0.2502–0.2665 seconds; the identical exercise against 1.9.35 incorrectly accepted responses after about 1.084 seconds. Fixed worker capacity contains stuck resolvers across repeated cycles. Setup preparation failures now save an explicit failed report even when the builder has not returned a cleanup contract.

The approved Azure practice ran 1.9.35. Windows setup failed after 121.202 seconds before producing its acceptance report; later Windows phases were held because cleanup was unverified. That report was initially inaccessible after browser control failed. The recovered report confirms all four VMs were deallocated and the original network was restored; the Linux guest result passed, while its cloud command timed out. See [live practice](docs/LIVE_PRACTICE.md) for evidence and continuation details. Version 1.9.32 remains the last validated release; a full cold deployment under three minutes and competition-length autonomous uptime are not established.

Version 1.9.31 adds default Windows Startup-folder and permanent WMI subscription fingerprints, optional organizer-approved SSH scorer key enforcement, and stronger persistence removal verification. Authorized-key revocation parses quoted options; task removal rejects wildcard targets; registry rollback holds reappeared values; systemd quarantine also checks live service state. Linux startup reads reject arbitrary parent symlinks and include service-account homes. See [security startup](docs/SECURITY_STARTUP.md) for configuration and boundaries.

Windows inventory uses one owned PowerShell process with a bounded deadline for every collection, preserving separate section errors and fresh evidence. Referenced script/program changes and unknown enabled accounts are reviewed independently of the first baseline. Ready hosts can install Sentinel while other hosts finish service setup, within the same deadline and concurrency limit.

Version 1.9.28 introduced baseline-independent startup-item review, exact-object persistence quarantine and rollback, scoring-account source/UID/SID checks, optional Linux SSH source restrictions, and encrypted blue-team password rotation. See [security startup](docs/SECURITY_STARTUP.md) for configuration, supported accounts, and limits. It does not guarantee discovery of every backdoor or authenticate a scorer from its IP address.

Version 1.9.27 adds separate 13-check NCAE and GDDC/UAlbany opening catalogs,
a single deadline covering service setup and Sentinel deployment/activation,
and authenticated SSH, SMB, PostgreSQL/MySQL and dynamic-DNS scoring probes.
DNS also checks exact TCP and reverse answers. Hosts deploy concurrently, Linux
files transfer in one batch, and the runtime is compressed to roughly 394 KB.
See [competition opening](docs/COMPETITION_OPENING.md) for the complete inputs,
client dependencies, supported paths, and completion checks.

With version 1.9.31, native service-plus-Sentinel setup completed in **174.439 seconds on Windows**
and **78.104 seconds on Linux**, using the strict 180-second deadline. These are
per-guest lab results with existing Python/service prerequisites and exclude VM boot.
They measure supervised Sentinel processes, not boot-persistent Sentinel OS-service installation.
Security exercises run after this clock. See [security startup](docs/SECURITY_STARTUP.md)
and the [measurement scope](docs/COMPETITION_OPENING.md#windows-inventory-execution-in-1930).

A full Linux/Windows event opening in under three minutes, including upload,
is still unverified. Service-fixture timings do not establish that result.

Sentinel Blue is a Python controller and host agent for authorized blue-team environments. It collects host state, detects changes, preserves evidence, and performs explicitly authorized recovery actions on Linux and Windows.

The downloadable `.pyz` runtime requires Python 3.11 or newer. The complete ZIP includes that runtime, source, tests, examples, and deployment tools.

```console
python sentinel-blue-1.9.39.pyz --help
python sentinel-blue-1.9.39.pyz doctor
python sentinel-blue-1.9.39.pyz self-test --json
```

Use `launcher --help` to prepare an inventory-based deployment. The launcher needs a reachable controller, an exact release checksum, an event profile, and the approved deployment credentials and routes. Browser access to a VM console alone does not provide SSH access.

Versions 1.9.17–1.9.19 fix native Linux recovery states, dependency configuration checks, independent service permissions, and ordinary controller shutdowns. Version 1.9.18 also keeps internal probe records out of remote-agent authority checks, avoids Windows inventory helper races, and reports blocked action admission as a conflict. See [the recovery guide](docs/AUTONOMOUS_SERVICE_RECOVERY.md) for activation requirements and behavior. It also preserves the integrity restoration, signed controller/agent protocol, protected identity policy, reversible containment, and native Windows persistence and firewall monitoring from earlier releases.

Version 1.9.19 processes queued captures before replacing their accepted telemetry and recollects after actions that arrived during collection. Windows firewall inventory has a bounded 60-second timeout.

Version 1.9.20 limits Windows helper concurrency to available CPUs, gives native inventories a bounded 60-second timeout, and collects process owners in bulk with PID and creation-time correlation. These changes address incomplete telemetry observed during the native Windows recovery exercise. Recovery still requires complete, fresh observations.

Version 1.9.21 dates telemetry at the start of collection, rejects partial PowerShell results accompanied by errors, and reports empty required account/service inventories as incomplete. Windows deployments and inventory helpers explicitly use normal CPU priority. Its native Windows pressure tests still exceeded a 120-second collection deadline.

Version 1.9.22 retrieves only the CIM properties used for service/process/boot observations and shares one PowerShell host across route, neighbor, and listener queries. Per-section failures remain explicit, and every existing network field is retained. Its native Linux/Windows service and file recovery checks passed. Sustained CPU load still exceeded a 120-second collection deadline, and a clean controller restart unexpectedly entered observe mode with emergency stop enabled. Those native failures remain unresolved; a passing local suite does not establish competition readiness.

Version 1.9.23 closes privileged-account review gaps: disabled logins and initial baseline membership no longer exempt unknown administrative identities, familiar account names need matching built-in identifiers, name collisions retain every account row, and protected UID/SID replacements raise an alert. Linux primary-group administrative membership is included. See [pre-existing privileged accounts](docs/PREEXISTING_PRIVILEGED_ACCOUNTS.md) for coverage and trust limits. Native validation of this candidate is pending.

Further work on 1.9.23 reproduces the clean-restart failure with a slow loopback probe and fixes its shutdown path. The controller drains active HTTP requests, relay probes, and maintenance work against one 20-second deadline. Queued probes stop before opening connections; a cancelled batch cannot become telemetry. Repeated stop signals remain handled through database cleanup. A worker that cannot drain or an uncertain governance write still leaves the crash marker set. The packaged local test preserves approved governance across a clean restart and resets to observation with emergency stop after a forced kill. The Azure restart case and Windows CPU-pressure case still need native retesting. CI now derives package paths from the current release version and runs this lifecycle check on Linux.

The default settings collect and report evidence. An event profile governs which actions may run automatically. An approved baseline is an explicit trust decision: it must be reviewed before promotion, especially on a host that might already be compromised. A compromised host with root or SYSTEM can interfere with its own defender; this package does not guarantee recovery from every such attack.

Version 1.9.24 shares a 75-second budget across Windows inventory queries, reuses the same boot identity throughout collection, and reports incomplete results explicitly. This bounds query contention without extending the 90-second evidence freshness limit. The service recovery panel shows durable cooldowns, unresolved outcomes, attempt limits, and the earliest possible retry time; fresh observations and normal authorization are still required. The native runner workflow measures real collection before, during, and after bounded CPU load. This candidate's validation results must be checked before deployment; these changes alone do not establish full-event competition readiness.

The Windows restore path compares the replacement file's security descriptor before changing it. Matching SACL components remain intact while changed owner, group, or DACL components are restored on the exclusive native handle. The complete descriptor must still match before publication; other differences require the full backup path and the same verification. See [endurance acceptance](docs/ENDURANCE_ACCEPTANCE.md) for the remaining practice-event gates.

Competition use requires the event's actual rules and permitted deployment paths. The included examples are templates and do not establish organizer approval or authorize a scored network.
