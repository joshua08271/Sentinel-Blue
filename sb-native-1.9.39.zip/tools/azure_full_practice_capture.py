"""Run the owned native practice and retain JSON evidence before VM shutdown.

Uses the existing exact-network lifecycle and private, expiring staging. Only
JSON reports are exported; fixture inputs, credentials and console logs are not.
"""
from __future__ import annotations

import argparse
import base64
import datetime
import fcntl
import json
import os
from pathlib import Path
import re
import signal
import tempfile

import azure_security_rehearsal as security
from azure_private_transfer import cli, private_payload

life = security.lifecycle

# This recovery is deliberately limited to the inspected 1.9.35 preparation
# failure. The hashed builder failed in its first read-only feature query,
# before it wrote any inputs or created service/account fixtures.
EMPTY_WINDOWS_PREPARATION = r"""
$emptyRoot='C:\ProgramData\SentinelAzureSetup-b2f5cee0daca'
$emptyInput=Join-Path $emptyRoot 'inputs-46ca72c449'
$cleanupSidecar=Join-Path $emptyRoot 'empty-preparation-cleanup.json'
foreach($path in @($emptyRoot,(Join-Path $emptyRoot 'tools'),$emptyInput)) {
  $item=Get-Item -LiteralPath $path -Force
  if(!$item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) {throw 'Owned preparation directory identity changed'}
}
$expectedHashes=@{
 'runtime.pyz'='30b8c299f57b8765e21c9229278355ec6f208684781f5d8405c1a146f62c0441'
 'tools\setup_native_inputs.py'='a69d714abdc309f68adca1933c18c43f52623b0bc484189953849a57030ac8a0'
 'tools\competition_native_inputs.py'='049ba59f621f8f7adbb4b6a8d86f1091850ac64428495e22b504d8c1b4aaee54'
 'tools\azure_setup_guest.py'='ad75490d2448424fa08e39b49fca7dc93084847f18e65464e6e2a75997c77d1b'
 'result.json'='fe8ed8f8e8bb758aa7be7aef4f60dbe9855748403934d7f4e10290be2bf6a3a3'
}
foreach($relative in $expectedHashes.Keys) {
  $path=Join-Path $emptyRoot $relative
  $item=Get-Item -LiteralPath $path -Force
  if($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) {throw 'Owned preparation file identity changed'}
  if((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ine $expectedHashes[$relative]) {throw 'Owned preparation hash mismatch'}
}
$inputDirectories=@(Get-ChildItem -LiteralPath $emptyRoot -Directory -Force -Filter 'inputs-*')
if($inputDirectories.Count -ne 1 -or $inputDirectories[0].Name -cne 'inputs-46ca72c449') {throw 'Unexpected preparation directories'}
if(@(Get-ChildItem -LiteralPath $emptyInput -Force).Count -ne 0) {throw 'Preparation input is no longer empty'}
if(Test-Path -LiteralPath $cleanupSidecar) {throw 'Preparation cleanup already recorded'}
# Nonrecursive deletion also refuses content created after the enumeration.
[IO.Directory]::Delete($emptyInput,$false)
if(Test-Path -LiteralPath $emptyInput) {throw 'Empty preparation cleanup not verified'}
if((Get-FileHash -LiteralPath (Join-Path $emptyRoot 'result.json') -Algorithm SHA256).Hash -ine $expectedHashes['result.json']) {throw 'Original failure report changed'}
$emptyCleanup=[ordered]@{status='passed';verified=$true;kind='inspected-empty-preparation-cleanup';run_id='b2f5cee0daca';input_directory='inputs-46ca72c449';original_failure_preserved=$true;removed_only_empty_directory=$true;verified_hashes=$expectedHashes}
$stream=[IO.File]::Open($cleanupSidecar,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
$writer=[IO.StreamWriter]::new($stream)
try {$writer.Write(($emptyCleanup | ConvertTo-Json -Depth 5))} finally {$writer.Dispose()}
Write-Output 'SB_EMPTY_PREPARATION_CLEANUP_VERIFIED'
"""

WINDOWS_PRIOR = r"""
Write-Output 'SB_PRIOR_INSPECTION_ENTERED'
$priorResultPath=$null
$priorResults=@()
$unverified=@()
foreach($directory in @(Get-ChildItem 'C:\ProgramData' -Directory -Filter 'SentinelAzureSetup-*')) {
  $oldResult=Join-Path $directory.FullName 'result.json'
  $oldRuntime=Join-Path $directory.FullName 'runtime.pyz'
  $old=$null
  if(Test-Path -LiteralPath $oldResult) {$old=Get-Content -Raw -LiteralPath $oldResult | ConvertFrom-Json}
  if(@(Get-ChildItem -LiteralPath $directory.FullName -Directory -Filter 'inputs-*').Count -and !$old.cleanup.verified) {$unverified+=$directory.Name}
  if((Test-Path -LiteralPath $oldRuntime) -and (Get-FileHash -LiteralPath $oldRuntime -Algorithm SHA256).Hash -ieq '__PRIOR_SHA__') {
    $priorResultPath=$oldResult
    $priorResults+=[ordered]@{directory=$directory.Name;passed=$old.passed;worker_removed=$old.checks.worker_removed;audit_restored=$old.checks.audit_policy_restored;failures=@($old.failures)}
  }
}
$leftovers=@(Get-Service -Name 'sbrepair*' -ErrorAction SilentlyContinue | Where-Object {$_.Name -match '^sbrepair[0-9a-f]{10}$'} | Select-Object -ExpandProperty Name)
$priorClean=$priorResults.Count -eq 1 -and $unverified.Count -eq 0 -and $leftovers.Count -eq 0
foreach($row in $priorResults) {if(!$row.worker_removed -or !$row.audit_restored) {$priorClean=$false}}
$priorSummary=[ordered]@{status=$(if($priorClean){'passed'}else{'failed'});kind='prior_collection_cleanup';prior=$priorResults;unverified_setup=$unverified;leftover_repair_services=$leftovers}
Write-Output ('SB_PRIOR_RESULT='+($priorSummary | ConvertTo-Json -Depth 8 -Compress))
if(!$priorClean) {
  Write-Output ('SB_SETUP_RESULT='+([ordered]@{status='failed';passed=$false;reason='Prior collection fixture cleanup requires inspection';prior=$priorSummary} | ConvertTo-Json -Depth 10 -Compress))
  exit 0
}
"""

EVIDENCE = r"""
import hashlib,io,json,pathlib,urllib.request,zipfile
root=pathlib.Path.cwd()
names={'result.json','setup-practice-result.json','prior-result.json','prior-setup-cleanup.json','practice-progress.json'}
names.update('practice-'+phase+'.json' for phase in ('setup','transport','probe_deadlines','security','service_repair','collection_pressure'))
stream=io.BytesIO()
total=0
with zipfile.ZipFile(stream,'w',zipfile.ZIP_DEFLATED) as archive:
    for name in sorted(names):
        p=root/name
        if not p.exists(): continue
        assert not p.is_symlink() and p.is_file()
        assert p.stat().st_size<=4*1024*1024
        data=p.read_bytes(); total+=len(data)
        assert total<=16*1024*1024
        json.loads(data)
        archive.writestr(name,data)
data=stream.getvalue()
request=urllib.request.Request(__URL__,data=data,method='PUT',headers={'x-ms-blob-type':'BlockBlob','If-None-Match':'*','Content-Type':'application/zip'})
with urllib.request.urlopen(request,timeout=45) as response:
    assert response.status==201
print('SB_JSON_EVIDENCE_UPLOADED='+hashlib.sha256(data).hexdigest(),flush=True)
"""


def captured_script(name, identity, packed, packed_sha, run_id, download_url, evidence_url, prior_sha,
                    reconcile_empty_windows_setup=False):
    script = security.download_script(name, identity, packed, packed_sha, run_id, download_url)
    encoded = base64.b64encode(EVIDENCE.replace('__URL__', repr(evidence_url)).encode()).decode()
    if name == 'sb-linux-target':
        marker = 'sys.exit(result.returncode)'
        assert script.count(marker) == 1
        # The staging subprocess uses cwd=root; this parent must select it too.
        return script.replace(marker, "os.chdir(root)\nexec(base64.b64decode(" + repr(encoded) + "))\n" + marker)
    script = "Write-Output 'SB_NATIVE_COMMAND_ENTERED'\n" + script
    marker = "$root='C:\\ProgramData\\SentinelAzureSetup-" + run_id + "'"
    assert script.count(marker) == 1
    if reconcile_empty_windows_setup:
        if not prior_sha:
            raise ValueError('Known empty preparation recovery requires the prior cleanup gate')
        script = script.replace(marker, EMPTY_WINDOWS_PREPARATION + '\n' + marker)
    if prior_sha:
        script = script.replace(marker, WINDOWS_PRIOR.replace('__PRIOR_SHA__', prior_sha) + '\n' + marker)
        marker = "Write-Output 'SB_GUEST_STAGE_VERIFIED'"
        assert script.count(marker) == 1
        script = script.replace(marker, "Copy-Item -LiteralPath $priorResultPath -Destination ($root+'\\prior-result.json')\n" + marker)
    if reconcile_empty_windows_setup:
        marker = "Write-Output 'SB_GUEST_STAGE_VERIFIED'"
        script = script.replace(marker, "Copy-Item -LiteralPath $cleanupSidecar -Destination ($root+'\\prior-setup-cleanup.json')\n" + marker)
    return script + "\n& $py[0] -c \"import base64;exec(base64.b64decode('" + encoded + "'))\"\nif ($LASTEXITCODE -ne 0) {throw 'JSON evidence capture failed'}\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runtime', type=Path, required=True)
    parser.add_argument('--runtime-sha256', required=True)
    parser.add_argument('--expected-network-sha256', required=True)
    parser.add_argument('--private-storage-account', required=True)
    parser.add_argument('--prior-windows-runtime-sha256')
    parser.add_argument('--target', action='append', choices=life.TARGETS)
    parser.add_argument('--reconcile-empty-windows-setup', action='store_true',
                        help='Remove only the hashed, inspected empty inputs-46ca72c449 directory from run b2f5cee0daca')
    args = parser.parse_args()
    targets = args.target or list(life.TARGETS)
    if len(set(targets)) != len(targets):
        parser.error('Each target must be selected only once')
    if args.reconcile_empty_windows_setup and ('sb-windows-target' not in targets or not args.prior_windows_runtime_sha256):
        parser.error('Empty preparation recovery requires the Windows target and prior cleanup gate')
    if args.prior_windows_runtime_sha256 and not re.fullmatch('[a-f0-9]{64}', args.prior_windows_runtime_sha256):
        parser.error('prior runtime must be a SHA256 digest')
    packed, packed_sha = security.pack(args.runtime, args.runtime_sha256, 'full-practice')
    for name in targets:
        captured_script(name,'/reviewed-resource',packed,packed_sha,'templatecheck',
                        'https://example.blob.core.windows.net/test/input?sig=review',
                        'https://example.blob.core.windows.net/test/output?sig=review',args.prior_windows_runtime_sha256,
                        args.reconcile_empty_windows_setup)
    os.umask(0o077)
    descriptor = os.open(Path.home()/'.sentinel-azure-preflight.lock',os.O_WRONLY|os.O_CREAT|os.O_NOFOLLOW,0o600)
    with os.fdopen(descriptor,'w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        work=Path(tempfile.mkdtemp(prefix='sentinel-full-practice-'))
        print('SB_FULL_PRACTICE_WORK='+str(work),flush=True)
        azure=life.lab.Azure(work)
        state=life.iso.snapshot(azure)
        assert life.iso.network_digest(state)==args.expected_network_sha256, 'Reviewed network changed'
        (work/'initial-network.json').write_text(json.dumps(state,indent=2))
        def interrupted(*_): raise KeyboardInterrupt
        signal.signal(signal.SIGTERM,interrupted)
        archive=work/'payload.zip'; archive.write_bytes(base64.b64decode(packed,validate=True))
        with private_payload(archive,account=args.private_storage_account,group=life.lab.GROUP) as delivery:
            common=['--account-name',args.private_storage_account,'--auth-mode','key']
            expiry=(datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(minutes=45)).strftime('%Y-%m-%dT%H:%MZ')
            urls={}
            for name in targets:
                token=cli('storage','blob','generate-sas','--container-name',delivery['container'],
                          '--name',name+'-evidence.zip','--permissions','cw','--expiry',expiry,'--https-only',*common)
                urls[name]='https://'+args.private_storage_account+'.blob.core.windows.net/'+delivery['container']+'/'+name+'-evidence.zip?'+token
            factory=lambda name,*values: captured_script(name,*values,delivery['url'],urls[name],args.prior_windows_runtime_sha256,
                                                        args.reconcile_empty_windows_setup)
            report=life.run(azure,state,args.expected_network_sha256,packed,packed_sha,
                            targets=targets,guest_script_factory=factory,stage_linux_payload=False)
            report['evidence_capture']={}
            for name in targets:
                present=cli('storage','blob','exists','--container-name',delivery['container'],'--name',name+'-evidence.zip',*common)
                if present['exists']:
                    path=work/(name+'-evidence.zip')
                    cli('storage','blob','download','--container-name',delivery['container'],'--name',name+'-evidence.zip','--file',str(path),*common)
                    report['evidence_capture'][name]='downloaded'
                else:
                    report['evidence_capture'][name]='not returned'
            report['kind']='azure-full-native-practice'
            (work/'result.json').write_text(json.dumps(report,indent=2))
        report['private_staging_cleanup_verified']=True
        (work/'result.json').write_text(json.dumps(report,indent=2))
        print('SB_FULL_PRACTICE_COMPLETE='+json.dumps(report,separators=(',',':')),flush=True)
        return 0 if report['status']=='guest_local_setup_passed' else 1


if __name__=='__main__':
    raise SystemExit(main())
