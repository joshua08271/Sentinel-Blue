"""Recover detached lab IP associations after an interrupted owned rehearsal.

All four VMs must already be deallocated. The caller supplies the original
reviewed network digest; the entire current network must match that digest
apart from the exact three allowed public-IP associations. No VM is started,
no credentials are recovered, and no other network setting is changed.
"""
from __future__ import annotations

import argparse
import fcntl
import json
import os
from pathlib import Path
import tempfile

try:
    from tools import azure_lab_isolated_boot as iso, azure_lab_preflight as lab
except ModuleNotFoundError:
    import azure_lab_isolated_boot as iso
    import azure_lab_preflight as lab


def recover(azure, expected_digest: str, *, execute: bool = False) -> dict:
    state = iso.snapshot(azure, allow_detached=True)
    actual = iso.network_digest(state)
    if actual != expected_digest:
        raise lab.PreflightError("Network differs from the original reviewed digest; no changes attempted")
    (azure.work / "recovery-network.json").write_text(json.dumps(state, indent=2))
    detached = sorted(name for name in iso.PUBLIC_HOSTS
                      if iso.attached(state["network"][name]["nic"]["ipConfigurations"][0]) is None)
    report = {"status": "recovery_reviewed", "network_sha256": actual, "detached": detached,
              "all_four_vms_deallocated": True, "restored": []}
    if execute:
        for name in detached:
            iso.require_off(azure, state["vms"])
            iso.change_association(azure, name, state["network"][name], restore=True)
            report["restored"].append(name)
            (azure.work / "recovery-result.json").write_text(json.dumps(report, indent=2))
        if iso.network_digest(iso.snapshot(azure)) != expected_digest:
            raise lab.PreflightError("Restored network does not match its reviewed digest")
        report["status"] = "recovery_verified"
    (azure.work / "recovery-result.json").write_text(json.dumps(report, indent=2))
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expected-network-sha256", required=True)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    descriptor = os.open(Path.home() / ".sentinel-azure-preflight.lock",
                         os.O_WRONLY | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    with os.fdopen(descriptor, "w") as handle:
        fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        root = Path(tempfile.mkdtemp(prefix="sentinel-azure-recovery-"))
        print("Private diagnostic directory: " + str(root), flush=True)
        print(json.dumps(recover(lab.Azure(root), args.expected_network_sha256,
                                 execute=args.execute), indent=2), flush=True)
