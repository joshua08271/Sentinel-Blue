"""Read a failed owned Windows setup log through the guarded Azure lifecycle.

No guest file, service, account, or failure report is changed. The existing
Windows target is the only VM started, and original power/network are restored.
Only exception types, traceback locations and fixture file metadata are returned.
"""
from __future__ import annotations

import argparse
import fcntl
import json
import os
from pathlib import Path
import re
import signal
import tempfile

try:
    from tools import azure_lab_setup_rehearsal as life
except ModuleNotFoundError:
    import azure_lab_setup_rehearsal as life


def inspection_script(identity, run_id, runtime_sha256):
    if not re.fullmatch(r'[a-f0-9]{12}', run_id):
        raise ValueError('An exact owned rehearsal run ID is required')
    if not re.fullmatch(r'[a-f0-9]{64}', runtime_sha256):
        raise ValueError('An exact runtime SHA256 is required')
    if not re.fullmatch(r'/subscriptions/[a-f0-9-]{36}/resourceGroups/sentinel-blue-range-wus2/providers/Microsoft.Compute/virtualMachines/sb-windows-target', identity, re.I):
        raise ValueError('Only the existing Windows target is permitted')
    return r'''$ErrorActionPreference='Stop'
$request=[Net.WebRequest]::Create('http://169.254.169.254/metadata/instance?api-version=2021-02-01')
$request.Proxy=$null;$request.Timeout=5000;$request.ReadWriteTimeout=5000
$request.Headers.Add('Metadata','true')
$response=$request.GetResponse();$reader=[IO.StreamReader]::new($response.GetResponseStream())
try {$metadata=$reader.ReadToEnd() | ConvertFrom-Json} finally {$reader.Dispose();$response.Dispose()}
if($metadata.compute.resourceId -ine '__IDENTITY__' -or $metadata.compute.osType -ne 'Windows') {throw 'Azure scope mismatch'}
$root='C:\ProgramData\SentinelAzureSetup-__RUN_ID__'
$directory=Get-Item -LiteralPath $root
if(!$directory.PSIsContainer -or ($directory.Attributes -band [IO.FileAttributes]::ReparsePoint)) {throw 'Invalid owned root'}
$runtime=Join-Path $root 'runtime.pyz'
if((Get-FileHash -LiteralPath $runtime -Algorithm SHA256).Hash -ine '__RUNTIME_SHA__') {throw 'Runtime identity mismatch'}
$logs=@()
foreach($name in @('setup-practice.log','private-error.txt')) {
 $path=Join-Path $root $name
 if(!(Test-Path -LiteralPath $path)) {continue}
 $file=Get-Item -LiteralPath $path
 if($file.Attributes -band [IO.FileAttributes]::ReparsePoint) {throw 'Log is a reparse point'}
 $frames=@();$types=@()
 foreach($line in @(Get-Content -LiteralPath $path -Tail 80)) {
  if($line -match '^\s*File "([^"]+)", line (\d+), in ([\w<>]+)$') {
   $frames+=@{file=[IO.Path]::GetFileName($Matches[1]);line=[int]$Matches[2];function=$Matches[3]}
  }
  if($line -match '^([\w.]+(?:Error|Exception|Expired|Exit)):') {$types+=$Matches[1]}
 }
 $logs+=@{name=$name;bytes=$file.Length;exception_types=@($types | Select-Object -Last 3);frames=@($frames | Select-Object -Last 6)}
}
$inputs=@()
foreach($inputDir in @(Get-ChildItem -LiteralPath $root -Directory -Filter 'inputs-*')) {
 if($inputDir.Attributes -band [IO.FileAttributes]::ReparsePoint) {throw 'Input is a reparse point'}
 $children=@(Get-ChildItem -LiteralPath $inputDir.FullName -Force)
 $inputs+=@{name=$inputDir.Name;entry_count=$children.Count;entries=@($children | Select-Object -First 20 -ExpandProperty Name)}
}
$services=@(Get-Service W3SVC,DNS -ErrorAction SilentlyContinue | Select-Object Name,@{n='status';e={[string]$_.Status}})
$report=[ordered]@{status='passed';kind='read-only-failed-setup-inspection';run_id='__RUN_ID__';runtime_sha256='__RUNTIME_SHA__';logs=$logs;inputs=$inputs;base_services=$services;guest_mutations_performed=$false;full_competition_readiness_proven=$false}
Write-Output ('SB_SETUP_RESULT='+($report | ConvertTo-Json -Depth 8 -Compress))
'''.replace('__IDENTITY__', identity).replace('__RUN_ID__', run_id).replace('__RUNTIME_SHA__', runtime_sha256)


class InspectionAzure(life.lab.Azure):
    def call(self, *args, timeout=60):
        if args[:3] == ('vm', 'run-command', 'invoke'):
            timeout = min(timeout, 300)
        return super().call(*args, timeout=timeout)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-id',required=True)
    parser.add_argument('--runtime-sha256',required=True)
    parser.add_argument('--expected-network-sha256',required=True)
    parser.add_argument('--execute',action='store_true')
    args=parser.parse_args()
    inspection_script('/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/sentinel-blue-range-wus2/providers/Microsoft.Compute/virtualMachines/sb-windows-target',args.run_id,args.runtime_sha256)
    os.umask(0o077)
    descriptor=os.open(Path.home()/'.sentinel-azure-preflight.lock',os.O_WRONLY|os.O_CREAT|os.O_NOFOLLOW,0o600)
    with os.fdopen(descriptor,'w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        work=Path(tempfile.mkdtemp(prefix='sentinel-setup-inspection-'))
        print('SB_INSPECTION_WORK='+str(work),flush=True)
        azure=InspectionAzure(work)
        state=life.iso.snapshot(azure)
        if life.iso.network_digest(state)!=args.expected_network_sha256:
            raise ValueError('Reviewed network changed')
        if not args.execute:
            print(json.dumps({'status':'reviewed','network_sha256':args.expected_network_sha256}))
            return 0
        def interrupted(*_): raise KeyboardInterrupt
        signal.signal(signal.SIGTERM,interrupted)
        factory=lambda name,identity,*_: inspection_script(identity,args.run_id,args.runtime_sha256)
        report=life.run(azure,state,args.expected_network_sha256,'','',targets=['sb-windows-target'],
                        guest_script_factory=factory,stage_linux_payload=False)
        complete=(report.get('status')=='guest_local_setup_passed' and report.get('all_vms_deallocated') and report.get('network_restored'))
        report.update(kind='read-only-failed-setup-inspection',status='inspection_complete' if complete else 'inspection_failed')
        (work/'result.json').write_text(json.dumps(report,indent=2))
        print('SB_INSPECTION_RESULT='+json.dumps(report,separators=(',',':')),flush=True)
        return 0 if complete else 1


if __name__=='__main__':
    raise SystemExit(main())
