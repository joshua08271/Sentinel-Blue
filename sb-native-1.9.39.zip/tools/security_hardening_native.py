"""Owned native checks for scorer key enforcement and Windows persistence coverage."""
from __future__ import annotations

import dataclasses
import hashlib
import os
import signal
import socket
import subprocess
import tempfile
import time
from pathlib import Path

from sentinel_blue.persistence_security import PersistenceRemediator
from sentinel_blue.security_native import native_command, powershell_json


def rehearse_hardening(root, name, account_id, password, checks):
    if os.name == 'nt':
        windows_startup_fixture(root, name, checks)
        windows_wmi_fixture(root, name, checks)
    else:
        ssh_scorer_fixture(name, account_id, password, checks)


def ssh_scorer_fixture(name, account_id, password, checks):
    """A separate loopback daemon; never edits or reloads the system SSH service."""
    import shutil
    from sentinel_blue import scorer_ssh_guard as guard
    sshd, ssh, keygen = (shutil.which(n) for n in ('sshd','ssh','ssh-keygen'))
    if not all((sshd, ssh, keygen)):
        raise RuntimeError('owned SSH fixture prerequisites unavailable')
    # OpenSSH StrictModes rejects key paths beneath world-writable /tmp even
    # when the immediate fixture directory is root-owned. Match /etc's trusted
    # ancestor permissions without touching the real SSH service configuration.
    with tempfile.TemporaryDirectory(prefix='sentinel-scorer-native-',dir='/run') as directory:
        root = Path(directory)
        root.chmod(0o755)  # sshd reads approved public keys after dropping UID.
        for key in ('host', 'approved', 'unapproved'):
            native_command([keygen,'-q','-t','ed25519','-N','','-f',str(root/key)])
        with socket.socket() as reservation:
            reservation.bind(('127.0.0.1',0)); port = reservation.getsockname()[1]
        original_fragment = guard.FRAGMENT
        guard.FRAGMENT = root/'guard.conf'
        guard.FRAGMENT.write_bytes(b'# owned initial configuration\n')
        alternate = root/'alternate.keys'
        alternate.write_bytes((root/'unapproved.pub').read_bytes()); alternate.chmod(0o644)
        configuration = root/'sshd.conf'
        configuration.write_text(
            f'Port {port}\nListenAddress 127.0.0.1\n'
            f'HostKey {root / "host"}\nPidFile {root / "sshd.pid"}\n'
            f'AuthorizedKeysFile {alternate}\nPasswordAuthentication yes\n'
            'PubkeyAuthentication yes\nKbdInteractiveAuthentication no\nUsePAM no\n'
            'StrictModes yes\nPermitRootLogin no\nUseDNS no\nLogLevel ERROR\n'
            f'Include {guard.FRAGMENT}\n')
        configuration.chmod(0o600)
        host = (root/'host.pub').read_text().split()
        (root/'known_hosts').write_text(f'[127.0.0.1]:{port} {host[0]} {host[1]}\n')
        askpass = root/'askpass'
        askpass.write_text('#!/bin/sh\nprintf "%s\\n" "$SENTINEL_FIXTURE_PASSWORD"\n')
        askpass.chmod(0o700)
        daemon = None
        def login(key=None, source='127.0.0.1', use_password=False):
            args = [ssh,'-F','/dev/null','-p',str(port),'-b',source,
                    '-o','ConnectTimeout=3','-o','ConnectionAttempts=1',
                    '-o','StrictHostKeyChecking=yes','-o','GlobalKnownHostsFile=/dev/null',
                    '-o','UserKnownHostsFile='+str(root/'known_hosts'),
                    '-o','IdentityAgent=none','-o','IdentitiesOnly=yes','-o','LogLevel=ERROR']
            environment = dict(os.environ)
            if use_password:
                args += ['-o','PreferredAuthentications=password','-o','PubkeyAuthentication=no',
                         '-o','NumberOfPasswordPrompts=1']
                environment.update(SSH_ASKPASS=str(askpass),SSH_ASKPASS_REQUIRE='force',
                                   DISPLAY='sentinel-owned-fixture',SENTINEL_FIXTURE_PASSWORD=password)
            else:
                args += ['-o','BatchMode=yes','-o','PreferredAuthentications=publickey','-i',str(root/key)]
            result = subprocess.run(args+[name+'@127.0.0.1','/usr/bin/true'],env=environment,
                stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                start_new_session=True,timeout=8)
            return result.returncode == 0, result.returncode == 255 and b'Permission denied' in result.stderr
        try:
            native_command([sshd,'-t','-f',str(configuration)])
            daemon = subprocess.Popen([sshd,'-D','-f',str(configuration),'-E',str(root/'sshd.log')],
                stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
            deadline = time.monotonic()+5
            while True:
                if daemon.poll() is not None or time.monotonic() >= deadline:
                    raise RuntimeError('owned SSH daemon did not start')
                try:
                    with socket.create_connection(('127.0.0.1',port),timeout=0.2): break
                except OSError: time.sleep(0.05)
            checks['scorer_fixture_initial_password_works'] = login(use_password=True)[0]
            checks['scorer_fixture_initial_alternate_key_works'] = login('unapproved')[0]
            if not all(checks[k] for k in checks if k.startswith('scorer_fixture_initial_')):
                raise RuntimeError('owned SSH authentication prerequisites failed')
            approved = {'agent_id':'fixture','name':name,'account_id':account_id,
                        'allowed_sources':['127.0.0.1/32'],
                        'ssh_public_keys':[(root/'approved.pub').read_text().strip()]}
            def command(argv):
                if argv[0] == sshd:
                    return native_command(argv+['-f',str(configuration)])
                if argv[:2] == ['systemctl','is-active']:
                    if daemon.poll() is not None: raise RuntimeError('owned SSH daemon exited')
                    return b'active\n'
                if argv[:2] == ['systemctl','reload']:
                    if daemon.poll() is not None: raise RuntimeError('owned SSH daemon exited')
                    daemon.send_signal(signal.SIGHUP)
                    return b''
                return native_command(argv)
            checks['scorer_approved_key_configuration_verified'] = False
            result = guard.enforce_ssh_guard([approved],root/'state',command=command)
            checks['scorer_approved_key_configuration_verified'] = result['approved_key_authentication_required']==[name]
            # A child started before the reload must not be used as acceptance.
            deadline = time.monotonic()+3
            while True:
                good, _ = login('approved')
                if good or time.monotonic() >= deadline: break
                time.sleep(0.05)
            checks['scorer_approved_key_and_source_allowed'] = good
            checks['scorer_same_account_same_source_wrong_key_rejected'] = login('unapproved')[1]
            checks['scorer_same_account_same_source_valid_password_rejected'] = login(use_password=True)[1]
            checks['scorer_approved_key_wrong_source_rejected'] = login('approved','127.0.0.2')[1]
            checks['scorer_approved_access_survives_rejections'] = login('approved')[0]
            checks['scorer_authentication_claim_remains_scoped'] = not result['scorer_authenticated'] and not result['other_protocols_enforced']
        finally:
            guard.FRAGMENT = original_fragment
            if daemon is not None:
                if daemon.poll() is None:
                    os.killpg(daemon.pid,signal.SIGTERM)
                    try: daemon.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        os.killpg(daemon.pid,signal.SIGKILL); daemon.wait(timeout=5)
                checks['scorer_fixture_daemon_removed'] = daemon.poll() is not None


def windows_startup_fixture(root, name, checks):
    """An inert text file in the real all-users Startup folder, never executed."""
    from sentinel_blue.collectors import _windows_persistence
    from sentinel_blue.detection import detect
    folder = Path(os.environ['ProgramData'])/'Microsoft/Windows/Start Menu/Programs/Startup'
    target_file = folder/(name+'.txt')
    original = b'Sentinel owned inert Startup-folder inventory fixture\r\n'
    changed = original+b'Changed marker bytes\r\n'
    from sentinel_blue.restoration import RestorePointStore
    store = RestorePointStore(root/'startup-fixture-files')
    metadata = store._read_target_if_present(target_file)
    if metadata is not None: raise RuntimeError('owned Startup fixture already exists')
    created = False
    remediator = PersistenceRemediator(root/'startup-quarantine')
    try:
        # The file helper pins parent directories and rejects reparse/hard links.
        # Create under this folder's own security context. A descriptor inherited
        # in the temporary directory cannot be transplanted here as an exact
        # restoration; subsequent mutation/rollback uses this file's real ACL.
        store._atomic_write(target_file,original,0o600,expected_current=None)
        created = True
        def inventory():
            errors = []
            matches = [dataclasses.asdict(item) for item in _windows_persistence(errors)
                       if item.kind=='startup-folder-file' and item.name.casefold()==str(target_file).casefold()]
            if len(matches) != 1: raise RuntimeError('owned Startup marker missing from native inventory')
            return {'agent_id':'fixture','persistence':matches}
        checks['startup_default_folder_content_detected'] = False
        initial = inventory()
        checks['startup_default_folder_content_detected'] = initial['persistence'][0]['sha256']==hashlib.sha256(original).hexdigest()
        trusted = {'trusted':[{'agent_id':'fixture',**{k:item[k] for k in ('kind','name','sha256')}}
                              for item in initial['persistence']], 'malicious_sha256':[]}
        current = store._read_target_if_present(target_file)
        store._replace_target(target_file,changed,current[1],expected_current=current)
        checks['startup_changed_payload_detected'] = 'persistence_inventory_unverified' in {
            a.kind for a in detect(inventory(),initial,set(),persistence_policy=trusted)}
        target = {'kind':'file','path':str(target_file)}
        before = remediator.snapshot(target)
        review = remediator.inspect(target)
        checks['startup_exact_file_quarantined'] = remediator.remove(target,review['snapshot_sha256'],operation_id='startup_marker')['status']=='quarantined'
        restored = remediator.restore('startup_marker')
        checks['startup_restore_status_verified'] = restored['status']=='restored'
        after = remediator.snapshot(target)
        checks['startup_restored_bytes_match'] = before['content']==after['content']
        # Self-relative descriptors can have different offsets/padding while
        # preserving their owner, group, ACLs and control flags exactly.
        checks['startup_restored_security_matches'] = remediator.files._metadata_matches(before['metadata'],after['metadata'])
        checks['startup_exact_file_rollback'] = all(checks[k] for k in (
            'startup_restore_status_verified','startup_restored_bytes_match','startup_restored_security_matches'))
    finally:
        remediator.close()
        if created:
            current = store._read_target_if_present(target_file)
            if current:
                if current[0] not in (original,changed): raise RuntimeError('Startup marker changed; cleanup held')
                store._unlink_target(target_file,expected_current=current)
            checks['startup_fixture_removed'] = store._read_target_if_present(target_file) is None


def windows_wmi_fixture(root, name, checks):
    """Owned filter, log-only consumer and binding with an impossible event name."""
    from sentinel_blue.collectors import _windows_persistence
    from sentinel_blue.detection import detect
    created = False
    arguments = {'name':name,'log':str(root/(name+'.log')),'query':
        "SELECT * FROM Win32_ProcessStartTrace WHERE ProcessName = '"+name+"_never_created.exe'"}
    try:
        # On partial creation, the same guarded cleanup still runs.
        created = True
        creation = powershell_json(r'''
$stage='precheck'
try {
$ns='root/subscription'
if ((Get-CimInstance -Namespace $ns -ClassName __EventFilter -Filter ("Name='"+$p.name+"'")) -or
    (Get-CimInstance -Namespace $ns -ClassName LogFileEventConsumer -Filter ("Name='"+$p.name+"'"))) { throw 'Owned WMI name already exists' }
$stage='filter'
$f=New-CimInstance -Namespace $ns -ClassName __EventFilter -Property @{Name=$p.name;EventNamespace='root\cimv2';QueryLanguage='WQL';Query=$p.query}
$stage='consumer'
$c=New-CimInstance -Namespace $ns -ClassName LogFileEventConsumer -Property @{Name=$p.name;FileName=$p.log;Text='Owned Sentinel inert event fixture'}
$stage='binding'
# Use the native schema so PowerShell marshals these values as CIM references,
# rather than guessing embedded-instance types from the supplied objects.
$bindingClass=Get-CimClass -Namespace $ns -ClassName __FilterToConsumerBinding
New-CimInstance -CimClass $bindingClass -Property @{Filter=$f;Consumer=$c} | Out-Null
[PSCustomObject]@{OK=$true} | ConvertTo-Json -Compress
} catch {
 [PSCustomObject]@{OK=$false;Stage=$stage;ErrorId=([string]$_.FullyQualifiedErrorId -replace '[^A-Za-z0-9_.-]','_');NativeCode=[string]$_.Exception.NativeErrorCode} | ConvertTo-Json -Compress
}
''', arguments)
        if not creation.get('OK'):
            import re
            detail='_'.join(str(creation.get(k,'')) for k in ('Stage','ErrorId','NativeCode'))
            checks['wmi_creation_failed_'+re.sub('[^A-Za-z0-9_.-]','_',detail)[:140]]=False
            raise RuntimeError('owned WMI fixture creation failed')
        def inventory():
            errors = []
            items = [dataclasses.asdict(item) for item in _windows_persistence(errors)
                     if item.kind.startswith('wmi-event-') and name in item.name]
            return {'agent_id':'fixture','persistence':items}
        initial = inventory()
        checks['wmi_filter_consumer_binding_detected'] = {x['kind'] for x in initial['persistence']} == {
            'wmi-event-filter','wmi-event-consumer','wmi-event-binding'} and len(initial['persistence'])==3
        if not checks['wmi_filter_consumer_binding_detected']:
            raise RuntimeError('owned WMI subscription missing from inventory')
        checks['wmi_fingerprints_stable_between_reads'] = inventory()==initial
        checks['wmi_preplaced_subscription_requires_review'] = 'persistence_inventory_unverified' in {
            a.kind for a in detect(initial,initial,set(),persistence_policy={'trusted':[],'malicious_sha256':[]})}
        trusted = {'trusted':[{'agent_id':'fixture',**{k:item[k] for k in ('kind','name','sha256')}}
                              for item in initial['persistence']], 'malicious_sha256':[]}
        powershell_json(r'''
$c=Get-CimInstance -Namespace root/subscription -ClassName LogFileEventConsumer -Filter ("Name='"+$p.name+"'")
if (!$c -or $c.FileName -cne $p.log -or $c.Text -cne 'Owned Sentinel inert event fixture') { throw 'Owned WMI consumer changed' }
$c | Set-CimInstance -Property @{Text='Owned Sentinel changed inert event fixture'} | Out-Null
'true'
''', arguments)
        checks['wmi_changed_consumer_detected'] = 'persistence_inventory_unverified' in {
            a.kind for a in detect(inventory(),initial,set(),persistence_policy=trusted)}
    finally:
        if created:
            checks['wmi_owned_fixture_removed'] = powershell_json(r'''
$ns='root/subscription'
$f=Get-CimInstance -Namespace $ns -ClassName __EventFilter -Filter ("Name='"+$p.name+"'")
$c=Get-CimInstance -Namespace $ns -ClassName LogFileEventConsumer -Filter ("Name='"+$p.name+"'")
if ($f -and ($f.Query -cne $p.query -or $f.EventNamespace -cne 'root\cimv2')) { throw 'WMI filter changed; cleanup held' }
if ($c -and ($c.FileName -cne $p.log -or $c.Text -notin @('Owned Sentinel inert event fixture','Owned Sentinel changed inert event fixture'))) { throw 'WMI consumer changed; cleanup held' }
$bindings=@(Get-CimInstance -Namespace $ns -ClassName __FilterToConsumerBinding)
foreach ($b in $bindings) {
 $matchesFilter=$f -and $b.Filter.CimSystemProperties.ClassName -ceq '__EventFilter' -and $b.Filter.Name -ceq $p.name
 $matchesConsumer=$c -and $b.Consumer.CimSystemProperties.ClassName -ceq 'LogFileEventConsumer' -and $b.Consumer.Name -ceq $p.name
 if ($matchesFilter -or $matchesConsumer) {
  if (!$matchesFilter -or !$matchesConsumer) { throw 'WMI binding changed; cleanup held' }
  $b | Remove-CimInstance
 }
}
if ($c) { $c | Remove-CimInstance }
if ($f) { $f | Remove-CimInstance }
$remaining=@(Get-CimInstance -Namespace $ns -ClassName __EventFilter -Filter ("Name='"+$p.name+"'"))
$remaining+=@(Get-CimInstance -Namespace $ns -ClassName LogFileEventConsumer -Filter ("Name='"+$p.name+"'"))
$remaining+=@(Get-CimInstance -Namespace $ns -ClassName __FilterToConsumerBinding | Where-Object { $_.Filter.Name -ceq $p.name -or $_.Consumer.Name -ceq $p.name })
($remaining.Count -eq 0) | ConvertTo-Json -Compress
''', arguments)
