"""Compare fixed, read-only Windows queries under one expiring CPU worker."""
from __future__ import annotations

import ctypes
import os
import subprocess
import sys
import time

from sentinel_blue.windows_query_batch import read_query_batch


QUERIES = {
    'CIM_SERVICES': "Get-CimInstance Win32_Service -Property Name,State | Select-Object Name,State | ConvertTo-Json -Compress",
    'EVENT_HASHTABLE': r"""
$items=@(Get-WinEvent -FilterHashtable @{LogName='System';ProviderName='Service Control Manager';Id=7031,7034;StartTime=(Get-Date).AddMinutes(-15)} -MaxEvents 512 -ErrorAction SilentlyContinue)
[PSCustomObject]@{Count=$items.Count} | ConvertTo-Json -Compress
""",
    'EVENT_XPATH': r"""
$errors=@()
$items=@(Get-WinEvent -LogName System -FilterXPath "*[System[Provider[@Name='Service Control Manager'] and (EventID=7031 or EventID=7034) and TimeCreated[timediff(@SystemTime) <= 900000]]]" -MaxEvents 512 -ErrorAction SilentlyContinue -ErrorVariable errors)
if (@($errors | Where-Object { $_.FullyQualifiedErrorId -notlike 'NoMatchingEventsFound*' }).Count) { throw 'event query failed' }
[PSCustomObject]@{Count=$items.Count} | ConvertTo-Json -Compress
""",
    'CIM_PROCESSES': "Get-CimInstance Win32_Process -Property ProcessId,Name | Select-Object ProcessId,Name | ConvertTo-Json -Compress",
}


def rehearse():
    if os.name != 'nt':
        raise RuntimeError('requires native Windows')
    rows=[]
    child=None
    api=ctypes.WinDLL('kernel32',use_last_error=True)
    api.GetCurrentProcess.restype=ctypes.c_void_p
    api.GetPriorityClass.argtypes=[ctypes.c_void_p]
    api.GetPriorityClass.restype=ctypes.c_uint32
    priority=int(api.GetPriorityClass(api.GetCurrentProcess()))
    try:
        for phase in ('idle','cpu_load'):
            if phase=='cpu_load':
                code="import time,hashlib\nuntil=time.monotonic()+240\nv=b'owned diagnostic'\nwhile time.monotonic()<until:\n for _ in range(500):v=hashlib.sha256(v).digest()\n"
                child=subprocess.Popen([sys.executable,'-c',code],stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
                time.sleep(3)
            for name,query in QUERIES.items():
                before=time.monotonic()
                result=read_query_batch(before+25,{name:query})[name]
                rows.append({'phase':phase,'section':name,'seconds':round(time.monotonic()-before,3),
                    'native_seconds':round(result.seconds,3),'rows':len(result.rows),'error':result.error})
                if child is not None and child.poll() is not None:
                    raise RuntimeError('owned worker expired during measurement')
    finally:
        if child is not None:
            if child.poll() is None: child.terminate()
            child.wait(timeout=10)
    return {'passed':True,'diagnostic_only':True,'parent_priority_class':priority,
            'logical_cpu_count':os.cpu_count(),'worker_removed':child.poll() is not None,'measurements':rows}
