"""Read only the retained state of one owned Windows setup rehearsal."""
from __future__ import annotations

import argparse
import base64
import fcntl
import json
import os
from pathlib import Path
import re
import tempfile

if __package__:
    from tools import azure_lab_setup_rehearsal as lifecycle
else:
    import azure_lab_setup_rehearsal as lifecycle


def windows_script(identity, run_id):
    if not re.fullmatch(r'[0-9a-f]{12}',run_id):
        raise ValueError('one exact owned setup run is required')
    code = r'''
import base64,gzip,json,pathlib,re,sqlite3
root=pathlib.Path(r'C:\ProgramData\SentinelAzureSetup-__RUN__')
assert root.is_dir() and not root.is_symlink()
directories=list(root.glob('inputs-*/defender'))
assert len(directories)==1
directory=directories[0]
assert not directory.is_symlink()
report={'status':'passed','scope':'read-only diagnostics of one retained owned Windows rehearsal',
        'full_competition_readiness_proven':False,'run_id':'__RUN__'}
with sqlite3.connect((directory/'controller.db').as_uri()+'?mode=ro',uri=True,timeout=3) as database:
    database.row_factory=sqlite3.Row
    report['promotions']=[dict(row) for row in database.execute(
        'SELECT status,failure_reason,created_at,updated_at,completed_at FROM baseline_promotions ORDER BY created_at DESC LIMIT 8')]
    report['baseline_status']=[dict(row) for row in database.execute('SELECT agent_id,status,approved_at FROM baselines')]
    actions=[]
    for row in database.execute("SELECT action_type,status,attempts,result_json FROM actions WHERE action_type='capture_restore_point' ORDER BY created_at DESC LIMIT 8"):
        value=dict(row)
        result=json.loads(value.pop('result_json') or '{}')
        value['result']={key:result[key] for key in ('status','reason','error','detail','results','files','errors') if key in result}
        actions.append(value)
    report['captures']=actions
    report['collector_errors']=[json.loads(row[0] or '{}').get('collector_errors',[]) for row in database.execute('SELECT latest_telemetry FROM agents')]
readiness=directory/'readiness.json'
if readiness.is_file():
    value=json.loads(readiness.read_text())
    report['readiness']=value.get('readiness')
    report['restoration_blockers']=value.get('controller',{}).get('restoration_blockers')
    report['governance']={key:value.get('controller',{}).get(key) for key in ('autonomy_mode','emergency_stopped')}
log=directory/'agent.log'
if log.is_file() and log.stat().st_size<4*1024*1024:
    lines=log.read_text(errors='replace').splitlines()
    report['agent_errors']=[line[:300] for line in lines if 'ERROR' in line][-12:]
    report['collection_durations']=[float(value) for value in re.findall(r'telemetry collection completed in ([0-9.]+) seconds','\n'.join(lines))][-12:]
packed=base64.b64encode(gzip.compress(json.dumps(report,separators=(',',':')).encode())).decode()
assert len(packed)<3500
print('SB_SETUP_RESULT_GZIP='+packed,flush=True)
'''.replace('__RUN__',run_id)
    encoded = base64.b64encode(code.encode()).decode()
    return r'''
$ErrorActionPreference='Stop'
$metadata=Invoke-RestMethod -Headers @{Metadata='true'} -Uri 'http://169.254.169.254/metadata/instance?api-version=2021-02-01' -TimeoutSec 5
if ($metadata.compute.resourceId -ine '__IDENTITY__') {throw 'Guest scope mismatch'}
$py=@(Get-ChildItem 'C:\ProgramData\SentinelBlue' -Filter python.exe -File -Recurse | Select-Object -ExpandProperty FullName)
if ($py.Count -ne 1) {throw 'Expected one existing Sentinel Python runtime'}
& $py[0] -c "import base64; exec(base64.b64decode('__CODE__'))"
if ($LASTEXITCODE -ne 0) {throw 'Read-only diagnostic failed'}
'''.replace('__IDENTITY__',identity).replace('__CODE__',encoded)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-id',required=True)
    parser.add_argument('--expected-network-sha256',required=True)
    args=parser.parse_args()
    windows_script('/scope-template',args.run_id)
    os.umask(0o077)
    descriptor=os.open(Path.home()/'.sentinel-azure-preflight.lock',
                       os.O_WRONLY|os.O_CREAT|os.O_NOFOLLOW,0o600)
    with os.fdopen(descriptor,'w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        work=Path(tempfile.mkdtemp(prefix='sentinel-windows-setup-diagnostic-'))
        print(str(work),flush=True)
        azure=lifecycle.lab.Azure(work)
        state=lifecycle.iso.snapshot(azure)
        def factory(name,identity,*_):
            if name!='sb-windows-target':
                raise ValueError('Only the existing Windows target may be inspected')
            return windows_script(identity,args.run_id)
        report=lifecycle.run(azure,state,args.expected_network_sha256,'','',targets=['sb-windows-target'],
                             guest_script_factory=factory,stage_linux_payload=False)
        report['kind']='read-only-retained-windows-setup-diagnostic'
        (work/'result.json').write_text(json.dumps(report,indent=2))
        print(json.dumps(report,indent=2),flush=True)


if __name__=='__main__':
    main()
