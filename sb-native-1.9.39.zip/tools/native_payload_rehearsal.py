"""Exercise live payload discovery using only owned temporary Linux processes.

No accounts, OS startup entries, network connections or system files are changed.
Results apply to these inert fixtures, not to a general malware detection rate.
"""
from __future__ import annotations

import argparse
import dataclasses
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from sentinel_blue import __version__
from sentinel_blue.detection import detect
from sentinel_blue.payload_inventory import linux_process_payloads


def rehearse():
    if os.name != 'posix' or not Path('/proc/self/exe').exists():
        raise RuntimeError('This rehearsal requires native Linux procfs')
    sleep_binary = shutil.which('sleep')
    if sleep_binary is None:
        raise RuntimeError('A local sleep executable is required for the inert fixture')
    start = time.monotonic()
    children = []
    checks, scans = {}, []
    report = {'version':__version__, 'scope':'owned temporary live Linux processes',
              'full_competition_readiness_proven':False}
    with tempfile.TemporaryDirectory(prefix='sentinel-payload-rehearsal-') as temporary:
        root = Path(temporary).resolve()
        script = root/'relative-fixture.py'
        script.write_text("from pathlib import Path\nimport time\nPath('started').touch()\ntime.sleep(30)\n")
        program = root/'extensionless-worker'
        shutil.copyfile(sleep_binary, program); program.chmod(0o700)
        try:
            children.append(subprocess.Popen([sys.executable, script.name], cwd=root))
            children.append(subprocess.Popen([str(program), '30'], cwd=root))
            deadline = time.monotonic()+5
            while not (root/'started').exists() and time.monotonic()<deadline:
                if children[0].poll() is not None:
                    raise RuntimeError('Owned script exited before starting')
                time.sleep(0.01)
            if not (root/'started').exists():
                raise RuntimeError('Owned script did not start')

            def collect():
                errors = []; then = time.monotonic()
                items = linux_process_payloads(errors)
                scans.append({'seconds':round(time.monotonic()-then,4),
                              'host_coverage_error_count':len(errors)})
                return {'agent_id':'owned-payload-rehearsal', 'platform':'Linux',
                        'persistence':[dataclasses.asdict(item) for item in items
                                       if item.name in {str(script),str(program)}]}, errors

            before, errors = collect()
            items = {row['name']:row for row in before['persistence']}
            checks['running_relative_script_discovered'] = str(script) in items
            checks['running_extensionless_program_discovered'] = str(program) in items
            digest = hashlib.sha256(program.read_bytes()).hexdigest()
            alerts = detect(before, before, set(), persistence_policy={'trusted':[], 'malicious_sha256':[digest]})
            checks['preexisting_known_fingerprint_alerted'] = any(a.kind=='known_malicious_persistence' for a in alerts)
            trusted = [{'agent_id':before['agent_id'], **{key:row[key] for key in ('kind','name','sha256')}}
                       for row in before['persistence']]
            script.write_text(script.read_text()+'# changed owned fixture\n')
            after, _ = collect()
            alerts = detect(after, before, set(), persistence_policy={'trusted':trusted, 'malicious_sha256':[]})
            checks['changed_script_alerted_with_same_process'] = any(a.kind=='persistence_inventory_unverified' for a in alerts)
            program.unlink()
            _, unlinked_errors = collect()
            checks['unlinked_running_program_reported_as_coverage_gap'] = any('unlinked' in e for e in unlinked_errors)
            checks['fixtures_still_running_before_cleanup'] = all(p.poll() is None for p in children)
        finally:
            for child in children:
                if child.poll() is None:
                    child.terminate()
                try:
                    child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    child.kill(); child.wait(timeout=5)
            checks['owned_process_cleanup_verified'] = all(p.poll() is not None for p in children)
        report.update(checks=checks, scans=scans)
    report['temporary_directory_removed'] = not root.exists()
    report['seconds'] = round(time.monotonic()-start,4)
    report['passed'] = bool(checks) and all(checks.values()) and report['temporary_directory_removed']
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = rehearse()
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    raise SystemExit(0 if result['passed'] else 1)
