"""Measure fixed native inventory queries with cold and reused module state.

This diagnostic does not change the production collection budget, priority,
query contents, or freshness checks. Each pass queries current native state.
It exports counts and timings only and removes its own expiring CPU worker.
"""
from __future__ import annotations

import os
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time

from sentinel_blue.windows_queries import WINDOWS_QUERIES
from sentinel_blue.windows_query_batch import read_query_batch


def inspect_prior_setup():
    """Read only the exact, completed 1.9.37 run retained on this lab target."""
    root = Path(r'C:\ProgramData\SentinelAzureSetup-1d5e03c9aeb5')

    def regular(path):
        if (path.is_symlink() or path.is_junction() or not path.is_file() or
                path.stat().st_size > 4 * 1024 * 1024):
            raise ValueError('Prior diagnostic file identity is invalid')
        return path.read_bytes()

    if root.is_symlink() or root.is_junction() or not root.is_dir():
        raise ValueError('Prior diagnostic root identity changed')
    if hashlib.sha256(regular(root/'runtime.pyz')).hexdigest() != 'ce0f1f223f01cfe645c020613f849568a36e7e148bb42eb82df6f7fdf928ed2e':
        raise ValueError('Prior runtime identity changed')
    previous = json.loads(regular(root/'result.json'))
    if previous.get('cleanup', {}).get('verified') is not True:
        raise ValueError('Prior setup cleanup is unverified')
    for filename, required in (
        ('practice-security.json', ('active_fixture_cleanup', 'fixture_account_removed',
                                   'native_startup_fixture_removed', 'logon_audit_policy_restored')),
        ('practice-collection_pressure.json', ('worker_removed', 'audit_policy_restored', 'damaged_files_fixture_removed')),
        ('practice-service_repair.json', tuple(kind + '_fixture_removed' for kind in
                                             ('damaged_files', 'missing_file', 'running_unhealthy', 'failed_validation'))),
    ):
        report = json.loads(regular(root/filename))
        if any(report.get('checks', {}).get(name) is not True for name in required):
            raise ValueError('Prior native fixture cleanup is unverified')
    result = {'run_id':'1d5e03c9aeb5', 'original_reports_preserved':True, 'cleanup_verified':True,
              'inputs':[]}
    for directory in root.glob('inputs-*'):
        if (not re.fullmatch(r'inputs-[a-f0-9]{10}', directory.name) or
                directory.is_symlink() or directory.is_junction() or not directory.is_dir()):
            raise ValueError('Prior input identity is invalid')
        state_dir = directory/'state'
        if state_dir.is_symlink() or state_dir.is_junction():
            raise ValueError('Prior state directory identity is invalid')
        state = json.loads(regular(state_dir/'setup-state.json'))
        fields = ('status', 'changed', 'seconds', 'initial_check_seconds', 'health_check_seconds',
                  'checks', 'reason', 'started_at', 'already_ready')
        tasks = {name:{key:row[key] for key in fields if key in row}
                 for name,row in state.get('tasks', {}).items()}
        logs = []
        log_dir = state_dir/'private-command-output'
        if log_dir.is_symlink() or log_dir.is_junction():
            raise ValueError('Prior log directory identity is invalid')
        for path in sorted(log_dir.glob('*.log')):
            data = regular(path)
            text = data.decode('utf-8', errors='replace')
            logs.append({'name':path.name, 'bytes':len(data), 'sha256':hashlib.sha256(data).hexdigest(),
                         'fixed_markers':[term for term in ('Get-WindowsFeature', 'Install-WindowsFeature',
                             'ServerManager', 'ParserError', 'Access is denied', 'timed out') if term in text]})
        result['inputs'].append({'name':directory.name, 'tasks':tasks,
                                 'host_preflight':state.get('host_preflight'), 'logs':logs})
    return result


def diagnostic_queries():
    queries = {}
    for pass_name in ('COLD', 'WARM'):
        for section in ('BOOT', 'TOPOLOGY', 'PERSISTENCE', 'FIREWALL'):
            query = WINDOWS_QUERIES[section]
            if section == 'PERSISTENCE':
                # Retain compiled code, never the preceding service snapshot.
                query = '$script:sentinelNativeServices=$null\n' + query
            queries[pass_name + '_' + section] = query
    return queries


def rehearse():
    if os.name != 'nt':
        raise RuntimeError('Native Windows is required')
    child = None
    rows = []
    failures = []
    prior = {}
    features = {}
    started = time.monotonic()
    try:
        prior = inspect_prior_setup()
        before = time.monotonic()
        feature = read_query_batch(before + 30, {'FEATURES':
            "Import-Module ServerManager; Get-WindowsFeature -Name 'Web-Server','DNS','FS-FileServer' | "
            "Select-Object Name,Installed | ConvertTo-Json -Compress"})['FEATURES']
        features = {'seconds':round(time.monotonic()-before, 3), 'native_seconds':round(feature.seconds, 3),
                    'rows':feature.rows, 'error':feature.error, 'read_only':True}
        for phase in ('idle', 'cpu_load'):
            if phase == 'cpu_load':
                worker = "import time,hashlib\nuntil=time.monotonic()+240\nv=b'owned query diagnostic'\nwhile time.monotonic()<until:\n for _ in range(500): v=hashlib.sha256(v).digest()\n"
                child = subprocess.Popen([sys.executable, '-c', worker], stdin=subprocess.DEVNULL,
                                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                time.sleep(3)
            before = time.monotonic()
            results = read_query_batch(before + 180, diagnostic_queries())
            for name, result in results.items():
                rows.append({'phase': phase, 'section': name, 'native_seconds': round(result.seconds, 3),
                             'rows': len(result.rows), 'error': result.error})
            if child is not None and child.poll() is not None:
                failures.append('Owned load worker ended before measurement completed')
    except Exception as exc:
        failures.append(type(exc).__name__)
    finally:
        if child is not None:
            if child.poll() is None:
                child.terminate()
            child.wait(timeout=10)
    removed = child is None or child.poll() is not None
    return {'passed': len(rows) == 16 and removed and not failures,
            'diagnostic_only': True, 'production_collection_budget_unchanged': True,
            'logical_cpu_count': os.cpu_count(), 'measurements': rows,
            'worker_removed': removed, 'failures': failures,
            'prior_setup_inspection':prior, 'feature_readiness_diagnostic':features,
            'seconds': round(time.monotonic() - started, 3),
            'full_competition_readiness_proven': False}
