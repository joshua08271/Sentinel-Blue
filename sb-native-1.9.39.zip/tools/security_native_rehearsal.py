"""Owned heartbeat/startup and account fixtures; no existing account is rotated."""

from __future__ import annotations

import argparse
import copy
import dataclasses
import hashlib
import json
import os
import secrets
import sys
import tempfile
import time
from pathlib import Path

from sentinel_blue.credential_vault import CredentialVault, new_password
from sentinel_blue.event_profile import EventProfile
from sentinel_blue.persistence_security import PersistenceRemediator, fingerprint
from sentinel_blue.security_native import NativeSecurityBackend, native_command, powershell_json
from sentinel_blue.security_workflow import SecurityCoordinator, compile_security_plan, guest_request


def fixture_account_absent(name, account_id):
    """A failed provider query cannot certify removal of the owned account."""
    try:
        if os.name == 'nt':
            return powershell_json(r'''
$matches=@(Get-LocalUser -ErrorAction Stop | Where-Object {
 $_.Name -ieq $p.name -or $_.SID.Value -eq $p.account_id
})
([bool]($matches.Count -eq 0)) | ConvertTo-Json -Compress
''', {'name':name,'account_id':account_id}) is True
        rows=[line.split(':') for line in Path('/etc/passwd').read_text().splitlines() if line]
        if (not rows or not str(account_id).isdigit() or
                any(len(row)!=7 or not row[2].isdigit() for row in rows)):
            return False
        return not any(row[0]==name or int(row[2])==int(account_id) for row in rows)
    except (OSError,RuntimeError,ValueError,TypeError):
        return False



def executable_persistence_fixture(root, name, checks, diagnostics=None):
    """Execute only an owned heartbeat, then verify startup and payload removal."""
    from sentinel_blue.collectors import _linux_persistence, _windows_persistence
    from sentinel_blue.detection import detect
    backend = NativeSecurityBackend()
    name += '_active'
    payload = root / (name + '.py')
    pulse = payload.with_suffix('.pulse')
    code = b'from pathlib import Path\nimport time\np=Path(__file__).with_suffix(".pulse")\nwhile True:\n p.write_text(str(time.time()))\n time.sleep(0.2)\n'
    payload.write_bytes(code); payload.chmod(0o700)
    created = False
    unit = None
    target = {'kind':'scheduled-task','task_path':'\\','task_name':name} if os.name == 'nt' else {
        'kind':'systemd-service','path':'/etc/systemd/system/'+name+'.service','service':name+'.service'}
    def inventory():
        errors = []
        items = (_windows_persistence if os.name == 'nt' else _linux_persistence)(errors)
        matching = [dataclasses.asdict(item) for item in items if item.name == str(payload)]
        if not matching:
            raise RuntimeError('native collector did not observe owned startup payload')
        # Other entries may be unreadable; this fixture does not claim their coverage.
        return {'agent_id':'fixture', 'persistence':matching}
    try:
        if os.name == 'nt':
            powershell_json(r'''
if (Get-ScheduledTask -TaskPath '\' -TaskName $p.name -ErrorAction SilentlyContinue) { throw 'Existing task' }
$a=New-ScheduledTaskAction -Execute $p.python -Argument ('"'+$p.script+'"')
$principal=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
Register-ScheduledTask -TaskPath '\' -TaskName $p.name -Action $a -Principal $principal | Out-Null
'true'
''', {'name':name, 'python':sys.executable, 'script':str(payload)})
            created = True
            powershell_json("Start-ScheduledTask -TaskPath '\\' -TaskName $p.name; 'true'", {'name': name})
        else:
            unit = Path(target['path'])
            data = ('[Unit]\nDescription=Sentinel owned heartbeat fixture\n[Service]\nExecStart='+sys.executable+' '+str(payload)+'\n[Install]\nWantedBy=multi-user.target\n').encode()
            with unit.open('xb') as stream: stream.write(data)
            unit.chmod(0o600)
            created = True
            backend.reload_systemd()
            native_command(['systemctl','enable','--now',target['service']])
        created = True
        limit = time.monotonic()+15
        while not pulse.exists() and time.monotonic()<limit:
            time.sleep(0.1)
        checks['owned_persistence_payload_actually_executed'] = pulse.exists()
        if not pulse.exists():
            if os.name == 'nt' and diagnostics is not None:
                # Read only this exact owned task before cleanup. Preserve its
                # scheduler result without exporting command lines or secrets.
                diagnostics['owned_task_launch'] = powershell_json(r'''
$task=Get-ScheduledTask -TaskPath '\' -TaskName $p.name -ErrorAction Stop
$info=Get-ScheduledTaskInfo -InputObject $task -ErrorAction Stop
[PSCustomObject]@{State=[string]$task.State;LastTaskResult=[long]$info.LastTaskResult;MissedRuns=[long]$info.NumberOfMissedRuns;LastRunUtc=$info.LastRunTime.ToUniversalTime().ToString('o')} | ConvertTo-Json -Compress
''', {'name':name})
            raise RuntimeError('owned heartbeat did not execute')
        initial = inventory()
        digest = hashlib.sha256(code).hexdigest()
        policy = {'trusted':[], 'malicious_sha256':[digest]}
        checks['preplaced_payload_fingerprint_detected'] = 'known_malicious_persistence' in {
            x.kind for x in detect(initial, initial, set(), persistence_policy=policy)}
        trusted = {'trusted':[{'agent_id':'fixture', **{k:item[k] for k in ('kind','name','sha256')}}
                              for item in initial['persistence']], 'malicious_sha256':[]}
        payload.write_bytes(code + b'# changed during the owned rehearsal\n')
        current = inventory()
        checks['changed_script_behind_unchanged_startup_detected'] = 'persistence_inventory_unverified' in {
            x.kind for x in detect(current, initial, set(), persistence_policy=trusted)}
        remediator = PersistenceRemediator(root/'active-quarantine')
        try:
            review = remediator.inspect(target)
            removal = remediator.remove(target, review['snapshot_sha256'], operation_id='active_startup')
            checks['active_startup_quarantined'] = removal['status']=='quarantined'
            before = pulse.read_bytes()
            time.sleep(0.7)
            checks['active_payload_stopped'] = pulse.read_bytes()==before
            file_target = {'kind':'file','path':str(payload)}
            file_review = remediator.inspect(file_target)
            removed = remediator.remove(file_target,file_review['snapshot_sha256'],operation_id='active_payload')
            checks['active_payload_file_quarantined'] = removed['status']=='quarantined' and not payload.exists()
            checks['active_payload_exact_rollback'] = remediator.restore('active_payload')['status']=='restored'
            checks['active_startup_exact_rollback'] = remediator.restore('active_startup')['status']=='restored'
        finally:
            remediator.close()
    finally:
        if created:
            if os.name == 'nt':
                powershell_json(r'''
$t=Get-ScheduledTask -TaskPath '\' -TaskName $p.name -ErrorAction SilentlyContinue
if ($t) {
 if ($t.Actions.Count -ne 1 -or $t.Actions[0].Execute -ne $p.python -or $t.Actions[0].Arguments -cne ('"'+$p.script+'"')) { throw 'Owned task action changed; cleanup held' }
 Stop-ScheduledTask -InputObject $t; Unregister-ScheduledTask -InputObject $t -Confirm:$false
}
'true'
''', {'name':name, 'python':sys.executable, 'script':str(payload)})
                checks['active_fixture_cleanup'] = backend.persistence_absent(target)
            else:
                native_command(['systemctl','stop',target['service']])
                native_command(['systemctl','disable',target['service']])
                if unit.exists():
                    if unit.is_symlink() or unit.read_bytes()!=data:
                        raise RuntimeError('owned unit changed; cleanup held')
                    unit.unlink()
                backend.reload_systemd()
                checks['active_fixture_cleanup'] = not unit.exists()

def native_persistence_fixture(root, name, checks):
    """An inert owned native startup object, including rollback of its metadata."""
    targets = []
    backend = NativeSecurityBackend()
    if os.name == 'nt':
        import winreg
        key_name = r'Software\Microsoft\Windows\CurrentVersion\Run'
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key_name, access=winreg.KEY_READ|winreg.KEY_SET_VALUE|winreg.KEY_WOW64_64KEY) as key:
            try:
                winreg.QueryValueEx(key,name)
                raise RuntimeError('owned fixture value already exists')
            except FileNotFoundError:
                pass
            value = r'C:\Windows\System32\cmd.exe /c exit 0'
            winreg.SetValueEx(key,name,0,winreg.REG_SZ,value)
        targets.append({'kind':'registry-value','hive':'HKLM','key':key_name,'value_name':name})
    else:
        unit_path=Path('/etc/systemd/system')/(name+'.service')
        data=b'[Unit]\nDescription=Sentinel owned inert fixture\n[Service]\nType=simple\nExecStart=/bin/sleep 300\n[Install]\nWantedBy=multi-user.target\n'
        with unit_path.open('xb') as stream:
            stream.write(data)
        unit_path.chmod(0o600)
        targets.append({'kind':'systemd-service','path':str(unit_path),'service':name+'.service'})
    try:
        if os.name!='nt':
            backend.reload_systemd()
            native_command(['systemctl','enable','--now',name+'.service'])
        remediator=PersistenceRemediator(root/'native-quarantine')
        try:
            for index,target in enumerate(targets):
                original=remediator.inspect(target)
                operation='native_fixture_'+str(index)
                removed=remediator.remove(target,original['snapshot_sha256'],operation_id=operation)
                checks[target['kind']+'_quarantine_verified']=removed['status']=='quarantined'
                restored=remediator.restore(operation)
                checks[target['kind']+'_rollback_verified']=(restored['status']=='restored' and
                    remediator.inspect(target)['snapshot_sha256']==original['snapshot_sha256'])
        finally:
            remediator.close()
    finally:
        if os.name=='nt':
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,key_name,access=winreg.KEY_READ|winreg.KEY_SET_VALUE|winreg.KEY_WOW64_64KEY) as key:
                try:
                    current=winreg.QueryValueEx(key,name)
                except FileNotFoundError:
                    current=None
                if current is not None:
                    if current!=(value,winreg.REG_SZ):
                        raise RuntimeError('fixture registry value changed; cleanup held')
                    winreg.DeleteValue(key,name)
            checks['native_startup_fixture_removed']=backend.persistence_absent(targets[0])
        else:
            native_command(['systemctl','stop',name+'.service'])
            native_command(['systemctl','disable',name+'.service'])
            if unit_path.exists():
                if unit_path.read_bytes()!=data or unit_path.is_symlink():
                    raise RuntimeError('fixture service changed; cleanup held')
                unit_path.unlink()
            backend.reload_systemd()
            checks['native_startup_fixture_removed']=not unit_path.exists()


def rehearse():
    if os.name != 'nt':
        return _rehearse()
    from sentinel_blue.windows_audit import temporary_logon_auditing
    with temporary_logon_auditing() as auditing:
        result = _rehearse()
    result['audit_policy'] = auditing
    result['checks']['logon_audit_policy_restored'] = auditing['restored']
    result['passed'] = all(result['checks'].values())
    return result


def _rehearse():
    name = "sbsec_" + secrets.token_hex(5)
    initial = new_password()
    backend = NativeSecurityBackend()
    created, account_id = False, None
    report = {"scope": "owned disposable account, native startup, and executable heartbeat payload",
              "platform": "windows" if os.name == "nt" else "linux", "checks": {}}
    started = time.monotonic()
    with tempfile.TemporaryDirectory(prefix="sentinel-security-native-") as temporary:
        root = Path(temporary)
        try:
            if os.name == "nt":
                powershell_json(r"""
if (Get-LocalUser -Name $p.name -ErrorAction SilentlyContinue) { throw 'Existing account' }
New-LocalUser -Name $p.name -Password (ConvertTo-SecureString $p.password -AsPlainText -Force) -Description 'Sentinel owned disposable fixture' | Out-Null
'true'
""", {"name": name, "password": initial})
            else:
                import pwd
                try:
                    pwd.getpwnam(name)
                    raise RuntimeError("fixture account name already exists")
                except KeyError:
                    pass
                native_command(["useradd", "--no-create-home", "--user-group", "--shell", "/bin/sh", "--home-dir", str(root / "home"), name])
                created = True
                account_id = str(pwd.getpwnam(name).pw_uid)
                native_command(["chpasswd"], incoming=(name + ":" + initial + "\n").encode())
            created = True
            before = backend.account(name)
            account_id = before["account_id"]
            report["checks"]["initial_password_authenticates"] = backend.verify_password(name, account_id, initial)
            if not report["checks"]["initial_password_authenticates"]:
                raise RuntimeError("native password verification prerequisite failed")
            native_persistence_fixture(root,name,report['checks'])
            from sentinel_blue.collectors import _linux_accounts, _windows_accounts, _windows_security_events
            from sentinel_blue.detection import detect
            accounts = _windows_accounts([]) if os.name == 'nt' else _linux_accounts()
            own = [dataclasses.asdict(row) for row in accounts if row.account_id == account_id]
            account_telemetry = {'agent_id':'fixture','platform':report['platform'], 'accounts':own}
            report['checks']['native_nonadmin_account_detected_without_trusting_baseline'] = 'unverified_login_account' in {
                a.kind for a in detect(account_telemetry,account_telemetry,set())}
            report['checks']['approved_native_account_control_preserved'] = 'unverified_login_account' not in {
                a.kind for a in detect(account_telemetry,account_telemetry,{name})}
            if os.name == 'nt':
                # Generate a fresh native login immediately before the bounded
                # event query; earlier setup activity can fill its event window.
                if not backend.verify_password(name, account_id, initial):
                    raise RuntimeError('native event fixture login failed')
                event_errors = []
                events = _windows_security_events(event_errors)
                # Native audit delivery can lag the successful LogonUser call.
                # Only retry this read; never repeat the account mutation/login.
                event_deadline = time.monotonic() + 8
                from sentinel_blue.collectors import _windows_deadline
                while not any(e.category=='auth_success' and e.account_id==account_id for e in events) and time.monotonic() < event_deadline:
                    time.sleep(0.25)
                    token = _windows_deadline.set(event_deadline)
                    try:
                        events = _windows_security_events(event_errors)
                    finally:
                        _windows_deadline.reset(token)
                report['native_event_diagnostic'] = {'events':len(events), 'errors':event_errors}
                report['checks']['native_login_event_sid_retained'] = any(
                    e.category=='auth_success' and e.account_id==account_id for e in events)
                if not report['checks']['native_login_event_sid_retained']:
                    # Emit counts/timestamps only, never other accounts' names,
                    # addresses, raw event messages, or the fixture password.
                    report['native_event_diagnostic']['native_log'] = powershell_json(r'''
$rows = @(Get-WinEvent -FilterHashtable @{LogName='Security';Id=4624} -MaxEvents 32 -ErrorAction SilentlyContinue)
$matching = 0
$latest = @($rows | ForEach-Object {
 $x = [xml]$_.ToXml()
 foreach ($d in $x.Event.EventData.Data) { if ($d.Name -eq 'TargetUserSid' -and [string]$d.'#text' -eq $p.sid) { $matching++ } }
 [PSCustomObject]@{Unix=([DateTimeOffset]$_.TimeCreated).ToUnixTimeMilliseconds()/1000.0;XmlUtc=[string]$x.Event.System.TimeCreated.SystemTime}
})
[PSCustomObject]@{Now=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()/1000.0;Count=$rows.Count;FixtureSidMatches=$matching;Latest=@($latest | Select-Object -First 2)} | ConvertTo-Json -Depth 4 -Compress
''', {'sid': account_id})
            executable_persistence_fixture(root,name,report['checks'],report.setdefault('diagnostics',{}))
            from tools.security_hardening_native import rehearse_hardening
            rehearse_hardening(root, name, account_id, initial, report['checks'])
            raw = copy.deepcopy(EventProfile.testing().raw)
            raw["scope"]["authorized_networks"] = ["127.0.0.0/8"]
            raw["scope"]["authorized_hosts"] = ["127.0.0.1"]
            raw["scope"]["approved_deployment_paths"] = [str(root)]
            raw["official_identities"] = [{"agent_id": "fixture-host", "name": name,
                                           "class": "blue-admin", "source": "owned-native-fixture"}]
            profile = EventProfile.from_dict(raw)
            inventory = {"authorized_networks": ["127.0.0.0/8"], "hosts": [{"name": "fixture-host", "agent_id": "fixture-host",
                "address": "127.0.0.1", "platform": report["platform"], "transport": "local",
                "runtime_path": str(root / "runtime.pyz"), "security_state_dir": str(root / "quarantine")}],
                "security": {"batch_id": "owned-native-fixture", "budget_seconds": 180,
                    "blue_accounts": [{"host": "fixture-host", "name": name, "account_id": account_id}], "removals": []}}
            marker = root / "inert-startup-marker.sh"
            marker.write_bytes(b"# Sentinel disposable marker; contains no executable command\n")
            target = {"kind": "file", "path": str(marker)}
            remediator = PersistenceRemediator(root / "quarantine")
            try:
                review = remediator.inspect(target)
            finally:
                remediator.close()
            inventory["security"]["removals"] = [{"host": "fixture-host", "target": target,
                "snapshot_sha256": review["snapshot_sha256"], "reason": "owned inert native acceptance marker"}]
            plan = compile_security_plan(inventory, profile)

            class LocalTransport:
                def request(self, host, body, seconds):
                    return guest_request(body, profile, host)

            with CredentialVault(root / "vault", new_password(), create=True) as vault:
                coordinator = SecurityCoordinator(plan, profile, vault, LocalTransport())
                outcome = coordinator.execute(approved_digest=fingerprint(plan))
                entry = next(row for row in vault.data["entries"].values() if "password" in row)
                report["checks"]["rotation_and_removal_completed"] = outcome["status"] == "completed"
                report["checks"]["new_password_authenticates"] = backend.verify_password(name, account_id, entry["password"])
                report["checks"]["preset_password_rejected"] = not backend.verify_password(name, account_id, initial)
                report["checks"]["account_identity_and_groups_preserved"] = backend.account(name) == before
                report["checks"]["quarantined_marker_absent"] = not marker.exists()
                report["checks"]["vault_contains_no_plaintext_password"] = entry["password"].encode() not in (root / "vault/vault.json").read_bytes()
                repeated = coordinator.execute(approved_digest=fingerprint(plan))
                report["checks"]["repeat_reconciles_without_new_password"] = repeated["status"] == "completed" and backend.verify_password(name, account_id, entry["password"])
            remediator = PersistenceRemediator(root / "quarantine")
            try:
                operation = "remove_" + fingerprint(plan)[:24] + "_0"
                restored = remediator.restore(operation)
                report["checks"]["quarantine_rollback_verified"] = restored["status"] == "restored" and marker.read_bytes().startswith(b"# Sentinel")
            finally:
                remediator.close()
        except Exception as exc:
            # Preserve completed checks and a bounded diagnostic without logging
            # command payloads, account credentials, or native event contents.
            report['error_type'] = type(exc).__name__
            import traceback
            report['error_sites'] = [Path(frame.filename).name+':'+str(frame.lineno)
                                     for frame in traceback.extract_tb(exc.__traceback__)[-3:]]
            report['checks']['native_fixture_completed'] = False
        finally:
            if created:
                if os.name == "nt":
                    # Resolve and retain exact SID even if a later fixture step failed.
                    if account_id is None:
                        account_id = backend.account(name)["account_id"]
                    powershell_json(r"""
$u=Get-LocalUser -SID $p.account_id
if ($u.Name -cne $p.name -or $u.Description -ne 'Sentinel owned disposable fixture') { throw 'Cleanup identity mismatch' }
Remove-LocalUser -SID $u.SID
'true'
""", {"name": name, "account_id": account_id})
                else:
                    import pwd
                    if str(pwd.getpwnam(name).pw_uid) != account_id:
                        raise RuntimeError("fixture cleanup identity changed")
                    native_command(["userdel", name])
                report['checks']['fixture_account_removed'] = fixture_account_absent(name,account_id)
    report["seconds"] = round(time.monotonic() - started, 3)
    report["passed"] = bool(report["checks"]) and all(report["checks"].values())
    report["full_competition_security_proven"] = False
    return report


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--confirm", required=True, choices=["disposable-owned-fixtures"])
    parser.add_argument("--output")
    args = parser.parse_args()
    report = rehearse()
    if args.output:
        Path(args.output).write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
