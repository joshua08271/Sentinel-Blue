"""Provision owned native services on the owner's disposable hosted runners.

This is a single-host rehearsal per OS, not a claim about a multi-VM event.
The packaged setup CLI performs every installation/configuration/start. The
harness prepares input files, measures it, checks a resume, and removes its
owned service instances. It never runs on an ordinary or self-hosted machine.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path

from sentinel_blue import __version__
from sentinel_blue.event_profile import EventProfile
from sentinel_blue.setup import compile_plan, plan_digest
from sentinel_blue.state import read_private_json, write_private_json


if __package__:
    from tools.setup_native_inputs import linux_inputs, windows_inputs, profile_inventory
else:  # Direct script invocation by the existing CI workflow.
    from setup_native_inputs import linux_inputs, windows_inputs, profile_inventory


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if os.name == "nt":
        from sentinel_blue.windows_native_range_lab import validate_runner_environment
    else:
        from sentinel_blue.native_range_lab import validate_runner_environment
    validate_runner_environment()
    report = {"status": "failed", "version": __version__, "runtime_sha256": hashlib.sha256(args.runtime.read_bytes()).hexdigest(),
              "scope": "one disposable native host per OS; loopback service checks",
              "full_competition_readiness_proven": False}
    with tempfile.TemporaryDirectory(prefix="sentinel-setup-input-") as directory:
        root = Path(directory)
        suffix = uuid.uuid4().hex[:10]
        builder = windows_inputs if os.name == "nt" else linux_inputs
        tasks, services, initial, identities, cleanup, secrets = builder(
            root, suffix, **({"stop_base_services": True} if os.name == "nt" else {}))
        report["initial_packages_or_features"] = initial
        report["initial_scored_service_state"] = "owned instances absent; Windows base services stopped if present"
        try:
            inventory = profile_inventory(args.runtime, tasks, services)
            inventory_path = root / "inventory.json"
            write_private_json(inventory_path, inventory)
            profile = EventProfile.from_dict(inventory["event_profile"])
            plan = compile_plan(inventory, profile, root)
            command = [sys.executable, str(args.runtime.absolute()), "setup", "--inventory", str(inventory_path),
                       "--execute", "--approve-plan", plan_digest(plan), "--state-dir", str(root / "state"),
                       "--range-deployment", "--output", str(root / "result.json")]
            started = time.monotonic()
            result = subprocess.run(command, capture_output=True, text=True, timeout=1845)
            report["timed_command_seconds"] = round(time.monotonic() - started, 3)
            if (root / "result.json").exists():
                report["setup"] = read_private_json(root / "result.json")
            else:
                error = result.stderr[-3000:]
                for secret in secrets:
                    error = error.replace(secret, "[redacted]")
                report["error"] = error
            if result.returncode != 0:
                # Only the owned fixture checks are rerun. Their outputs are
                # sanitized and bounded to diagnose native configuration errors.
                diagnostics = {}
                for task in plan["tasks"]:
                    if report.get("setup", {}).get("tasks", {}).get(task["id"], {}).get("status") in {"failed", "uncertain", "changed"}:
                        record = report["setup"]["tasks"][task["id"]]
                        log_name = record.get("apply", {}).get("output_log")
                        if log_name:
                            private_log = root / "state/private-command-output" / log_name
                            if private_log.is_file():
                                text = private_log.read_text(errors="replace")[-4000:]
                                for secret in secrets:
                                    text = text.replace(secret, "[redacted]")
                                diagnostics[task["id"]] = {"apply_output": text}
                        if os.name == "posix":
                            check = subprocess.run(["bash", "-se"], input=task["check"], capture_output=True, text=True, timeout=30)
                            text = (check.stdout + check.stderr)[-2000:]
                            for secret in secrets:
                                text = text.replace(secret, "[redacted]")
                            diagnostics.setdefault(task["id"], {}).update(code=check.returncode, output=text)
                report["diagnostics"] = diagnostics
                raise RuntimeError("packaged native setup did not complete")
            before = identities()
            resumed = subprocess.run(command + ["--resume"], capture_output=True, text=True, timeout=180)
            after = identities()
            report["resume_without_service_restart"] = resumed.returncode == 0 and before == after
            report["status"] = "passed" if report["resume_without_service_restart"] and report["timed_command_seconds"] < 1800 else "failed"
        except Exception as exc:
            report.setdefault("error", type(exc).__name__ + ": " + str(exc))
        finally:
            try:
                report["cleanup"] = cleanup()
            except Exception as exc:
                report["cleanup"] = {"verified": False, "error": type(exc).__name__}
            if not report["cleanup"].get("verified"):
                report["status"] = "failed"
            write_private_json(args.output, report)
            if os.name == "posix":
                # This one sanitized report is read by the unprivileged artifact
                # uploader. Inventories, scripts, and raw logs remain private.
                args.output.chmod(0o644)
    print(json.dumps(report, indent=2))
    return 0 if report["status"] == "passed" else 2


if __name__ == "__main__":
    raise SystemExit(main())
