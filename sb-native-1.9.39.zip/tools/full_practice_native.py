"""Guest-local setup, defense, repair and load checks behind Azure identity gates."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import urllib.request


def safe_failure_context(path):
    """Retain exception/frame identities without argv, source lines or secrets."""
    with path.open('rb') as stream:
        size=stream.seek(0,2)
        stream.seek(max(0,size-65536))
        text=stream.read(65536).decode('utf-8',errors='replace')
    frames=[]; errors=[]
    for line in text.splitlines():
        match=re.match(r'^\s*File "([^"]+)", line (\d+), in ([\w<>]+)$',line)
        if match:
            frames.append({'file':match[1].replace('\\','/').rsplit('/',1)[-1][:100],
                           'line':int(match[2]),'function':match[3][:100]})
        match=re.match(r'^([\w.]+(?:Error|Exception|Expired|Exit)):',line)
        if match: errors.append(match[1][:100])
    return {'exception_types':errors[-3:],'frames':frames[-6:],'log_tail_only':size>65536}


def security_cleanup_verified(result):
    required={'fixture_account_removed','native_startup_fixture_removed','active_fixture_cleanup'}
    if os.name=='nt':
        required.add('logon_audit_policy_restored')
    return all(result.get('checks',{}).get(name) is True for name in required)


def rehearse():
    from sentinel_blue import __version__
    from tools import agent_transport_rehearsal, probe_timing_rehearsal, security_native_rehearsal, service_repair_native
    root = Path(__file__).resolve().parent
    runtime = root / 'runtime.pyz'
    started = time.monotonic()
    phases = {}
    report = {'version': __version__, 'runtime_sha256': hashlib.sha256(runtime.read_bytes()).hexdigest(),
              'platform': 'Windows' if os.name == 'nt' else 'Linux', 'phases': phases,
              'full_competition_readiness_proven': False, 'scope': 'owned guest-local native fixtures'}

    def phase(name, operation):
        before = time.monotonic()
        try:
            result = operation()
        except Exception as exc:
            result = {'passed': False, 'error_type': type(exc).__name__}
        (root / ('practice-' + name + '.json')).write_text(json.dumps(result, indent=2))
        phases[name] = {'passed': result.get('passed', result.get('status') == 'passed'),
                        'seconds': round(time.monotonic() - before, 3)}
        for key in ('error_type', 'failure_stage', 'failure_context', 'checks', 'errors', 'failures', 'repair_seconds', 'cleanup_verified'):
            if key in result:
                phases[name][key] = result[key]
        (root / 'practice-progress.json').write_text(json.dumps(report, indent=2))
        return result

    def setup():
        request = urllib.request.Request('http://169.254.169.254/metadata/instance?api-version=2021-02-01',
                                         headers={'Metadata': 'true'})
        with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(request, timeout=5) as response:
            identity = json.load(response)['compute']['resourceId']
        output = root / 'setup-practice-result.json'
        with (root / 'setup-practice.log').open('w') as stream:
            completed = subprocess.run([sys.executable, str(root / 'tools/azure_setup_guest.py'),
                '--runtime', str(runtime), '--expected-resource-id', identity, '--output', str(output),
                '--with-defender', '--budget-seconds', '180'], stdout=stream, stderr=subprocess.STDOUT, timeout=900)
        result = json.loads(output.read_text()) if output.exists() else {
            'status':'failed','error_type':'SetupResultMissing',
            'failure_context':safe_failure_context(root/'setup-practice.log')}
        if completed.returncode:
            result['status'] = 'failed'
        return result

    opening = phase('setup', setup)
    # azure_setup_guest uses this exact field to reconcile old setup fixture
    # directories before another run. Preserve it in the outer result too.
    report['cleanup'] = opening.get('cleanup', {})
    phases['setup']['acceptance'] = opening.get('acceptance', {})
    for key in ('complete_opening_seconds', 'complete_opening_under_180_seconds', 'complete_opening_within_budget',
                'opening_clock_scope'):
        if key in opening:
            phases['setup'][key] = opening[key]
    phases['setup']['cleanup'] = opening.get('cleanup', {})
    if opening.get('cleanup', {}).get('verified') is not True:
        report.update(passed=False, stopped_for_unverified_setup_cleanup=True,
                      seconds=round(time.monotonic() - started, 3))
        return report
    phase('transport', lambda: agent_transport_rehearsal.rehearse(repeats=10))
    phase('probe_deadlines', lambda: probe_timing_rehearsal.rehearse(repeats=5))
    security_result=phase('security', security_native_rehearsal.rehearse)
    if not security_cleanup_verified(security_result):
        report.update(passed=False,stopped_for_unverified_security_cleanup=True,
                      seconds=round(time.monotonic()-started,3))
        return report
    phase('service_repair', service_repair_native.rehearse)
    if os.name == 'nt':
        from tools.windows_load_native import rehearse as load
        pressure = phase('collection_pressure', load)
        keys = ('phase', 'seconds', 'age_seconds', 'error_count', 'error_categories', 'usable_for_recovery')
    else:
        from tools.measure_collection_pressure import limit_cpus, measure
        def load():
            with limit_cpus(1):
                return measure(workers=4, load_seconds=90, samples=5)
        pressure = phase('collection_pressure', load)
        keys = ('phase', 'elapsed_seconds', 'observation_age_seconds', 'collector_error_count', 'error_categories', 'usable_for_recovery')
    phases['collection_pressure']['samples'] = [{key: row[key] for key in keys} for row in pressure.get('samples', [])]
    report.update(passed=bool(phases) and all(row['passed'] for row in phases.values()),
                  seconds=round(time.monotonic() - started, 3))
    return report


def summary(report):
    """Fit Azure's output tail without dropping the authoritative full report."""
    result = {key: report[key] for key in ('version', 'runtime_sha256', 'platform', 'scope',
              'full_competition_readiness_proven', 'passed', 'seconds', 'status') if key in report}
    result['phases'] = {}
    for name, row in report.get('phases', {}).items():
        checks = row.get('checks', {})
        value = {'passed': row['passed'], 'seconds': row['seconds'],
                 'checks': len(checks), 'failed_checks': [k for k, v in checks.items() if v is False][:12]}
        for key in ('samples', 'repair_seconds', 'cleanup_verified', 'error_type', 'failure_stage', 'failure_context',
                    'complete_opening_seconds', 'complete_opening_under_180_seconds', 'complete_opening_within_budget',
                    'opening_clock_scope'):
            if key in row:
                value[key] = row[key]
        if name == 'setup':
            value['acceptance'] = {key: row.get('acceptance', {}).get(key) for key in
                                   ('status', 'elapsed_seconds', 'budget_seconds', 'under_3_minutes')}
            value['cleanup_verified'] = row.get('cleanup', {}).get('verified', False)
        value['errors'] = [str(item)[:250] for item in row.get('failures', [])[:3]]
        result['phases'][name] = value
    return result
