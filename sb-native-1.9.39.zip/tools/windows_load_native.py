"""Native Windows collection and owned service recovery under bounded CPU load.

All inventories come from the packaged production collector. Instrumentation
records only counts, durations and error categories, without changing output.
"""
from __future__ import annotations

import hashlib
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

from sentinel_blue import collectors
from sentinel_blue.windows_audit import temporary_logon_auditing


WORKER = """
import hashlib,time
until=time.monotonic()+480
value=b'owned bounded Sentinel load'
while time.monotonic()<until:
 for _ in range(500): value=hashlib.sha256(value).digest()
"""


def worker_metrics(child, started):
    import ctypes
    from ctypes import wintypes
    api = ctypes.WinDLL('kernel32', use_last_error=True)
    api.GetPriorityClass.argtypes = [wintypes.HANDLE]
    api.GetPriorityClass.restype = wintypes.DWORD
    api.GetProcessTimes.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)]*4
    api.GetProcessTimes.restype = wintypes.BOOL
    values = [wintypes.FILETIME() for _ in range(4)]
    # The Popen-owned handle pins our worker even if a PID is later reused.
    priority = int(api.GetPriorityClass(int(child._handle)))
    if not priority or not api.GetProcessTimes(int(child._handle), *(ctypes.byref(row) for row in values)):
        raise ctypes.WinError(ctypes.get_last_error())
    cpu = sum((row.dwHighDateTime << 32) + row.dwLowDateTime for row in values[2:])/10000000
    return {'priority_class':priority, 'cpu_seconds':round(cpu,3),
            'wall_seconds':round(time.monotonic()-started,3)}


def verify_inventory_parent_death(root):
    """Kill only our disposable parent and verify its pinned helper also exits."""
    import ctypes
    from ctypes import wintypes
    from sentinel_blue import windows_inventory_host
    marker = root/'owned-inventory-helper.pid'
    package = str(Path(windows_inventory_host.__file__).parent.parent)
    code = ("import pathlib,sys,time\n" + f"sys.path.insert(0,{package!r})\n" +
            "from sentinel_blue.windows_inventory_host import InventoryHost\n" +
            "host=InventoryHost()\n" + f"pathlib.Path({str(marker)!r}).write_text(str(host.process.pid))\n" +
            "time.sleep(30)\n")
    parent = subprocess.Popen([sys.executable,'-c',code],stdin=subprocess.DEVNULL,
                              stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    api=ctypes.WinDLL('kernel32',use_last_error=True)
    api.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
    api.OpenProcess.restype=wintypes.HANDLE
    api.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD]
    api.WaitForSingleObject.restype=wintypes.DWORD
    api.CloseHandle.argtypes=[wintypes.HANDLE]
    api.CloseHandle.restype=wintypes.BOOL
    handle=None
    try:
        deadline=time.monotonic()+15
        while not marker.exists() and parent.poll() is None and time.monotonic()<deadline:
            time.sleep(.05)
        if not marker.exists() or parent.poll() is not None:
            raise RuntimeError('Owned inventory parent did not establish its helper')
        pid=int(marker.read_text())
        # SYNCHRONIZE pins this owned process identity before parent termination.
        handle=api.OpenProcess(0x100000,False,pid)
        if not handle or api.WaitForSingleObject(handle,0)!=258:
            raise RuntimeError('Owned inventory helper was not alive before parent death')
        parent.kill();parent.wait(timeout=5)
        if api.WaitForSingleObject(handle,5000)!=0:
            raise RuntimeError('Inventory helper survived owned parent death')
        return True
    finally:
        if parent.poll() is None:
            parent.kill()
        parent.wait(timeout=5)
        if handle:
            api.CloseHandle(handle)
        marker.unlink(missing_ok=True)


def rehearse():
    if os.name != 'nt':
        raise RuntimeError('Windows load acceptance requires a native Windows target')
    from sentinel_blue import payload_inventory, windows_startup
    rows, queries, file_reads, repair_observations, failures = [], [], [], [], []
    child = None
    checks = {}
    started = time.monotonic()
    original_batch = collectors.read_query_batch
    original_files = payload_inventory.fingerprint_references
    original_startup = windows_startup.startup_folder_inventory
    auditing = {'restored': False}

    def batch(*args, **kwargs):
        result = original_batch(*args, **kwargs)
        queries.extend({'section':name,'seconds':round(row.seconds,3),'rows':len(row.rows),
                        'error':row.error} for name,row in result.items())
        return result

    def files(*args, **kwargs):
        before = time.monotonic()
        result = original_files(*args, **kwargs)
        file_reads.append({'kind':kwargs.get('kind','startup-payload'),
                           'seconds':round(time.monotonic()-before,3),'items':len(result)})
        return result

    def startup(*args, **kwargs):
        before = time.monotonic()
        result = original_startup(*args, **kwargs)
        file_reads.append({'kind':'startup-folders','seconds':round(time.monotonic()-before,3),
                           'items':len(result)})
        return result

    collectors.read_query_batch = batch
    payload_inventory.fingerprint_references = files
    windows_startup.startup_folder_inventory = startup
    try:
        with temporary_logon_auditing() as auditing, tempfile.TemporaryDirectory(prefix='sentinel-load-',dir=Path(__file__).resolve().parent) as directory:
            checks['inventory_helper_exits_on_parent_death'] = verify_inventory_parent_death(Path(directory))
            target = Path(directory)/'owned.conf'
            target.write_bytes(b'owned unchanged configuration\n')

            from sentinel_blue.windows_service_query import SERVICE_SNAPSHOT
            comparison = original_batch(time.monotonic()+45, {'SCM_PARITY':SERVICE_SNAPSHOT+r'''
$native=@(Get-SentinelServiceSnapshot)
$cim=@(Get-CimInstance Win32_Service -Property Name,StartMode,PathName)
$index=@{}; foreach($row in $native) {$index[$row.Name]=$row}
$mismatches=0
foreach($row in $cim) {
  $found=$index[$row.Name]
  if(!$found -or $found.StartMode -ine $row.StartMode -or $found.PathName -ine $row.PathName) {$mismatches++}
}
[PSCustomObject]@{NativeCount=$native.Count;CimCount=$cim.Count;Mismatches=$mismatches} | ConvertTo-Json -Compress
'''})['SCM_PARITY']
            checks['service_snapshot_parity'] = {'error':comparison.error, 'rows':comparison.rows}
            if comparison.error or len(comparison.rows)!=1:
                raise ValueError('native SCM parity query failed: '+comparison.error)
            counts = comparison.rows[0]
            if counts['NativeCount']!=counts['CimCount'] or counts['Mismatches']:
                raise ValueError('SCM and CIM service identities/configurations differ')
            checks['service_snapshot_matches_cim'] = True

            def sample(phase):
                queries.clear(); file_reads.clear()
                before = time.monotonic()
                telemetry = collectors.collect('native-load-fixture',integrity_paths=[str(target)]).as_dict()
                elapsed = time.monotonic()-before
                age = time.time()-telemetry['observed_at']
                errors = telemetry['collector_errors']
                # Preserve section diagnostics, never raw account/command/credential contents.
                categories = sorted(set('query_budget' if 'budget' in e else
                    'timeout' if 'timed out' in e else 'payload_time_or_read_bound' if 'payload' in e else
                    'session_identity' if 'session process identity' in e else
                    'native_section' if 'Native section failed' in e else 'collection_error' for e in errors))
                protected = [item for item in telemetry['integrity'] if item['path']==str(target)]
                intact = len(protected)==1 and protected[0]['sha256']==hashlib.sha256(target.read_bytes()).hexdigest()
                good = (not errors and 0<=age<=90 and telemetry['boot_id'] not in {'','unknown'}
                        and len(telemetry['accounts'])>0 and len(telemetry['services'])>0 and intact)
                rows.append({'phase':phase,'seconds':round(elapsed,3),'age_seconds':round(age,3),
                             'error_count':len(errors),'error_categories':categories,'usable_for_recovery':good,
                             'inventory_counts':{name:len(telemetry[name]) for name in
                                  ('accounts','services','sessions','processes','persistence','integrity')},
                             'query_sections':list(queries),'file_reads':list(file_reads)})

            sample('idle')
            if not rows[-1]['usable_for_recovery']:
                raise ValueError('idle collection failed before load: '+str(rows[-1]['query_sections'])[:600])
            child = subprocess.Popen([sys.executable,'-c',WORKER],stdin=subprocess.DEVNULL,
                                     stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            load_start = time.monotonic()
            for index in range(3):
                due = load_start+3+60*index
                while time.monotonic()<due:
                    time.sleep(max(0,min(.25,due-time.monotonic())))
                if child.poll() is not None:
                    raise RuntimeError('owned CPU worker ended before its loaded sample')
                sample('cpu_load')
                if child.poll() is not None:
                    raise RuntimeError('owned CPU worker ended during a loaded sample')
            while time.monotonic()-load_start<180:
                time.sleep(.25)
            checks['sustained_load_seconds'] = round(time.monotonic()-load_start,3)
            checks['collection_worker'] = worker_metrics(child, load_start)
            child.terminate(); child.wait(timeout=10)

            # A fresh expiring worker keeps the real collection-to-repair path
            # under load without depending on the earlier worker's lifetime.
            from tools.service_repair_native import CSHARP_WORKER, scenario
            from sentinel_blue.security_native import powershell_json
            executable = Path(directory)/'owned-service.exe'
            powershell_json('Add-Type -TypeDefinition $p.source -OutputAssembly $p.output -OutputType WindowsApplication -ReferencedAssemblies System.ServiceProcess,System; "true"',
                            {'source':CSHARP_WORKER,'output':str(executable)})
            child = subprocess.Popen([sys.executable,'-c',WORKER],stdin=subprocess.DEVNULL,
                                     stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            repair_load_started = time.monotonic()

            def repair_sample(sample):
                if child.poll() is not None:
                    raise RuntimeError('owned worker stopped during native repair collection')
                repair_observations.append({'age_seconds':round(time.time()-sample['observed_at'],3),
                    'errors':len(sample['collector_errors']),'native_boot_available':sample['boot_id'] not in {'','unknown'},
                    'services':len(sample['services']),'persistence':len(sample['persistence'])})

            checks['native_repair_seconds'] = scenario(Path(directory)/'repair',executable,'damaged_files',checks,
                native_collection=True,observation_interval=15,sample_observer=repair_sample,verify_restart_event=True)
            checks['repair_load_seconds'] = round(time.monotonic()-repair_load_started,3)
            if child.poll() is not None:
                raise RuntimeError('owned worker stopped before repair verification')
            checks['repair_worker'] = worker_metrics(child, repair_load_started)
            child.terminate(); child.wait(timeout=10)
            sample('after_load')
    except Exception as exc:
        failures.append(type(exc).__name__+': '+str(exc)[:700])
    finally:
        if child is not None:
            if child.poll() is None:
                child.kill()
            child.wait(timeout=10)
        checks['worker_removed'] = child is None or child.poll() is not None
        checks['audit_policy_restored'] = auditing['restored']
        try:
            from sentinel_blue.windows_inventory_host import close_inventory_host
            close_inventory_host()
            checks['inventory_helper_removed'] = True
        except Exception as exc:
            checks['inventory_helper_removed'] = False
            failures.append('Inventory helper cleanup: '+type(exc).__name__)
        collectors.read_query_batch = original_batch
        payload_inventory.fingerprint_references = original_files
        windows_startup.startup_folder_inventory = original_startup
    return {'passed':len(rows)==5 and all(row['usable_for_recovery'] for row in rows) and not failures
                     and checks['worker_removed'] and checks['audit_policy_restored']
                     and checks.get('inventory_helper_exits_on_parent_death') is True
                     and checks.get('inventory_helper_removed') is True
                     and checks.get('healthy_service_responsive_during_collection') is True
                     and checks.get('damaged_files_autonomous_repair_passed') is True,
            'logical_cpu_count':os.cpu_count(),'owned_cpu_workers':1,'samples':rows,'checks':checks,
            'repair_observations':repair_observations,'failures':failures,
            'seconds':round(time.monotonic()-started,3),'full_competition_readiness_proven':False}
