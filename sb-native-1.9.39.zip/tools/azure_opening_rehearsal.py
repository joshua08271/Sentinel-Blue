"""Timed native service + Sentinel openings using private Azure payload delivery.

This measures one independent opening per guest. Cross-host dependencies and a
single Linux-to-Windows controller are explicitly outside this fixture's claim.
"""
from __future__ import annotations
import argparse
import base64
import hashlib
import io
import json
import os
import signal
import tempfile
import time
import zipfile
from pathlib import Path

if __package__:
    from tools import azure_lab_setup_rehearsal as lifecycle
    from tools.azure_private_transfer import private_payload
else:
    import azure_lab_setup_rehearsal as lifecycle
    from azure_private_transfer import private_payload


EXTRA = ['native_defender_startup.py','smoke_release.py','security_native_rehearsal.py',
         'security_hardening_native.py','windows_query_contract.py']


def payload(runtime, digest):
    if hashlib.sha256(runtime.read_bytes()).hexdigest()!=digest:
        raise ValueError('runtime changed before native opening')
    stream=io.BytesIO()
    with zipfile.ZipFile(stream,'w',zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('runtime.pyz',runtime.read_bytes())
        archive.writestr('tools/__init__.py',b'')
        for name in lifecycle.GUEST_FILES+EXTRA:
            archive.writestr('tools/'+name,Path(__file__).with_name(name).read_bytes())
    data=stream.getvalue()
    return base64.b64encode(data).decode(),hashlib.sha256(data).hexdigest()


def download_script(name, identity, packed, packed_sha, run_id, delivery, *, budget_seconds=180,
                    security_fixture=True):
    from urllib.parse import urlparse
    if type(budget_seconds) is not int or not 30 <= budget_seconds <= 1800:
        raise ValueError('opening measurement budget must be 30..1800 seconds')
    url=delivery['url']
    if urlparse(url).scheme!='https' or not urlparse(url).hostname.endswith('.blob.core.windows.net') or "'" in url:
        raise ValueError('private Azure HTTPS payload required')
    # Start on the provider before dispatch, not inside the guest after Azure's
    # Run Command queue. Staging is added back; VM boot remains excluded. These
    # are per-guest clocks and do not claim the browser-to-Cloud-Shell upload.
    started_at = time.time() - delivery['staging_seconds']
    original=lifecycle.guest_script(name,identity,packed,packed_sha,run_id)
    if name=='sb-linux-target':
        count=(len(packed)+lifecycle.LINUX_CHUNK_SIZE-1)//lifecycle.LINUX_CHUNK_SIZE
        old="data=base64.b64decode(''.join((root/f'part-{i:03d}.b64').read_text() for i in range("+str(count)+")),validate=True)"
        if old not in original: raise ValueError('Linux delivery template changed')
        original=original.replace('assert root.is_dir() and not root.is_symlink()','root.mkdir(mode=0o700)')
        original=original.replace(old,"import time\nos.environ['SENTINEL_OPENING_STARTED_AT']="+repr(str(started_at))+"\nwith urllib.request.urlopen("+repr(url)+",timeout=45) as response:\n    data=response.read(32*1024*1024+1)\nassert len(data)<=32*1024*1024")
        oldset="{'runtime.pyz','tools/__init__.py','tools/azure_setup_guest.py','tools/setup_native_inputs.py','tools/competition_native_inputs.py','tools/measure_setup_acceptance.py'}"
        members=['runtime.pyz','tools/__init__.py']+['tools/'+n for n in lifecycle.GUEST_FILES+EXTRA]
        if oldset not in original: raise ValueError('archive allowlist template changed')
        original=original.replace(oldset,repr(set(members)))
        oldarg="'--output',str(root/'result.json')]"
        arguments = ['--with-defender','--budget-seconds',str(budget_seconds)]
        if security_fixture:
            arguments.append('--security-fixture')
        return original.replace(oldarg,"'--output',str(root/'result.json'),"+
                                ','.join(repr(value) for value in arguments)+']')
    old="[IO.File]::WriteAllBytes($root+'\\payload.zip',[Convert]::FromBase64String('"+packed+"'))"
    if old not in original: raise ValueError('Windows delivery template changed')
    original=original.replace(old,"$env:SENTINEL_OPENING_STARTED_AT='"+str(started_at)+"'\n$ProgressPreference='SilentlyContinue'\nInvoke-WebRequest -UseBasicParsing -Uri '"+url+"' -OutFile ($root+'\\payload.zip') -TimeoutSec 45")
    arguments = ' --with-defender --budget-seconds '+str(budget_seconds)
    if security_fixture:
        arguments += ' --security-fixture'
    return original.replace("--output ($root+'\\result.json')","--output ($root+'\\result.json')"+arguments)


def main():
    import fcntl
    p=argparse.ArgumentParser()
    p.add_argument('--runtime',type=Path,required=True);p.add_argument('--runtime-sha256',required=True)
    p.add_argument('--expected-network-sha256',required=True)
    p.add_argument('--private-storage-account',required=True)
    p.add_argument('--target',action='append',choices=lifecycle.TARGETS)
    p.add_argument('--budget-seconds',type=int,default=180)
    p.add_argument('--skip-security-fixture',action='store_true',
                   help='Measure installation without a separate post-timer security exercise.')
    args=p.parse_args()
    if not 30 <= args.budget_seconds <= 1800:
        p.error('--budget-seconds must be 30..1800')
    os.umask(0o077)
    fd=os.open(Path.home()/'.sentinel-azure-preflight.lock',os.O_WRONLY|os.O_CREAT|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        work=Path(tempfile.mkdtemp(prefix='sentinel-azure-opening-'))
        print('Private diagnostic directory: '+str(work),flush=True)
        azure=lifecycle.lab.Azure(work)
        state=lifecycle.iso.snapshot(azure)
        if lifecycle.iso.network_digest(state)!=args.expected_network_sha256:
            raise ValueError('network changed before native opening')
        packed,digest=payload(args.runtime,args.runtime_sha256)
        archive=work/'payload.zip';archive.write_bytes(base64.b64decode(packed,validate=True))
        def interrupted(*_): raise KeyboardInterrupt
        signal.signal(signal.SIGTERM,interrupted)
        with private_payload(archive,account=args.private_storage_account,group=lifecycle.lab.GROUP) as delivery:
            factory=lambda *values: download_script(*values,delivery,budget_seconds=args.budget_seconds,
                                                   security_fixture=not args.skip_security_fixture)
            for target in lifecycle.TARGETS:
                factory(target,'/scope-template',packed,digest,'template')
            result=lifecycle.run(azure,state,args.expected_network_sha256,packed,digest,targets=args.target,
                                 guest_script_factory=factory,stage_linux_payload=False)
            result['private_payload_staging_seconds']=delivery['staging_seconds']
        result['private_payload_cleanup_verified']=True
        result['kind']='native-per-guest-service-and-defender-opening'
        result['measurement_budget_seconds']=args.budget_seconds
        result['whole_delivery_rehearsal_cleanup_seconds']=round(result.get('guest_rehearsal_wall_seconds',0)+result['private_payload_staging_seconds'],3)
        (work/'result.json').write_text(json.dumps(result,indent=2))
        print(json.dumps(result,indent=2),flush=True)
        return 0 if result['status']=='guest_local_setup_passed' else 1


if __name__=='__main__':
    raise SystemExit(main())
