"""Real immutable enforcement using the unchanged released NativeFlags API.
The test class is copied unchanged from delivered 2.0.28; only this wrapper is new.
Uses unique disposable root-owned files and releases their flags in finally.
"""
import errno, os, sys, tempfile, unittest
from pathlib import Path
sys.path.insert(0, os.environ['SB_PYZ'])
from sentinel_blue import immutable_files as im
from sentinel_blue.linux_workspace import is_proxmox_host

class NativeIoctlTests(unittest.TestCase):
    def test_real_descriptor_policy_rejects_writable_parent_and_hardlink(self):
        native = im.NativeFlags()
        with tempfile.TemporaryDirectory(prefix='sb227-policy-', dir='/srv') as folder:
            path = Path(folder)/'web.conf'; path.write_bytes(b'approved'); path.chmod(0o640)
            os.chmod(folder, 0o777)
            with self.assertRaisesRegex(ValueError, 'parents'):
                with native.opened(path): self.fail('unsafe parent admitted')
            os.chmod(folder, 0o700); os.link(path, Path(folder)/'alias')
            with self.assertRaisesRegex(ValueError, 'unique'):
                with native.opened(path): self.fail('hardlink admitted')

    def test_actual_linux_ioctl_reads_and_denies_missing_capability(self):
        native = im.NativeFlags()
        with tempfile.TemporaryFile() as file:
            file.write(b'native-ioctl-check'); file.flush()
            try: flags = native.flags(file.fileno())
            except OSError as exc:
                if exc.errno in {errno.ENOTTY, errno.EOPNOTSUPP}: self.skipTest('filesystem does not expose inode flags')
                raise
            try: native.capability()
            except PermissionError:
                with self.assertRaises(OSError) as denied: native.set_flags(file.fileno(), flags | im.IMMUTABLE)
                self.assertEqual(denied.exception.errno, errno.EPERM)
                self.assertEqual(native.flags(file.fileno()), flags)
            else:
                self.skipTest('capability present; separate enforcement cycle covers mutations')

    def test_real_kernel_enforces_and_releases_immutable_flag_when_available(self):
        native = im.NativeFlags()
        try: native.capability()
        except PermissionError as exc: self.skipTest(str(exc))
        directory = Path(tempfile.mkdtemp(prefix='sb227-native-', dir='/srv'))
        path = directory/'native.conf'; path.write_bytes(b'approved')
        try:
            current = native.snapshot(path)
            protected = native.change(path, current, current['flags'] | im.IMMUTABLE)
            with self.assertRaises(PermissionError): path.write_bytes(b'changed')
            with self.assertRaises(PermissionError): path.unlink()
            native.change(path, protected, current['flags'])
            path.write_bytes(b'maintenance'); self.assertEqual(path.read_bytes(), b'maintenance')
        finally:
            if path.exists():
                current = native.snapshot(path)
                if current['flags'] & im.IMMUTABLE: native.change(path, current, current['flags'] & ~im.IMMUTABLE)
                path.unlink()
            directory.rmdir()

if __name__ == '__main__':
    if os.geteuid() != 0 or is_proxmox_host() or Path('/proc/1/comm').read_text().strip() != 'systemd':
        raise SystemExit('requires root on an idle disposable VM with native systemd; hypervisors refused')
    unittest.main(defaultTest='NativeIoctlTests.test_real_kernel_enforces_and_releases_immutable_flag_when_available', verbosity=2)
