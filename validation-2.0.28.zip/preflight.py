"""Read-only native lab inventory. Never approves scope or starts a service."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys

if os.environ.get('SB_PYZ'):
    sys.path.insert(0, os.environ['SB_PYZ'])

from sentinel_blue import __version__
from sentinel_blue.linux_workspace import is_proxmox_host
from sentinel_blue.state import write_private_json


def collect():
    capabilities = {}
    for line in Path('/proc/self/status').read_text().splitlines():
        name, _, value = line.partition(':')
        if name in {'CapEff', 'CapBnd'}:
            capabilities[name] = value.strip()
    effective = int(capabilities.get('CapEff', '0'), 16)
    binaries = {name: shutil.which(name, path='/usr/sbin:/usr/bin:/sbin:/bin')
                for name in ('nft', 'ip', 'systemctl', 'systemd-analyze', 'unshare', 'loginctl', 'who', 'ss')}
    proxmox = is_proxmox_host()
    manager = Path('/proc/1/comm').read_text().strip() == 'systemd' and Path('/run/systemd/system').is_dir()
    result = {'schema': 1, 'product_version': __version__, 'platform': platform.platform(),
              'hostname': platform.node(), 'uid': os.geteuid(), 'capabilities': capabilities,
              'native_systemd_pid1': manager, 'proxmox_host_refused': proxmox,
              'cap_net_admin': bool(effective & (1 << 12)),
              'cap_linux_immutable': bool(effective & (1 << 9)), 'binaries': binaries,
              'tk_display_declared': bool(os.environ.get('DISPLAY')),
              'native_mutation_run': False, 'routeros_device_verified': False,
              'occupancy_must_be_checked_by_operator': True, 'commands': {}}
    for name, command in {'nft_version': ['nft', '--version'],
                          'systemd_version': ['systemctl', '--version'],
                          'sessions': ['loginctl', 'list-sessions', '--no-legend'],
                          'interactive_users': ['who', '--count']}.items():
        try:
            run = subprocess.run(command, capture_output=True, text=True, timeout=5,
                                 env={'PATH': '/usr/sbin:/usr/bin:/sbin:/bin', 'LANG': 'C.UTF-8'})
            # These specific read-only outputs contain no command lines,
            # authentication contents or network-policy snapshots.
            output = run.stdout if len(run.stdout.encode()) <= 16384 else '[output exceeds bound]'
            result['commands'][name] = {'returncode': run.returncode, 'stdout': output}
        except (OSError, subprocess.SubprocessError) as exc:
            result['commands'][name] = {'error_type': type(exc).__name__}
    pyz = os.environ.get('SB_PYZ')
    if pyz:
        result['application_archive_sha256'] = hashlib.sha256(Path(pyz).read_bytes()).hexdigest()
    result['local_native_prerequisites_present'] = (os.geteuid() == 0 and manager and not proxmox)
    result['isolated_nft_prerequisites_present'] = bool(result['local_native_prerequisites_present']
        and result['cap_net_admin'] and binaries['nft'] and binaries['unshare'])
    result['remaining_checks'] = ['idle workshop ownership', 'reviewed session/profile/baseline and probe credentials',
                                  'real native transactions', 'external scoring and management access',
                                  'watchdog timeout, reboot and later-edit preservation', 'RouterOS interpreter/device rights']
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, help='private result JSON; no guest settings changed')
    args = parser.parse_args()
    result = collect()
    write_private_json(Path(args.output), result)
    print(json.dumps(result, indent=2))
