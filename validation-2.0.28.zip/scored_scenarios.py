"""Inject ONE scoped fault into an already approved disposable local lab.

This does not create accounts, approve profiles/baselines, change authentication
policy, or initialize databases. Only the selected manifest target is mutated.
All pre-fault bytes stay in private local restore evidence, not the JSON report.
"""
from __future__ import annotations
import argparse
import ctypes
import errno
import fcntl
import hashlib
import json
import os
from pathlib import Path
import secrets
import stat
import subprocess
import sys
import time

if os.environ.get('SB_PYZ'):
    sys.path.insert(0, os.environ['SB_PYZ'])

from sentinel_blue.event_profile import load_event_profile
from sentinel_blue.linux_workspace import client_for, is_proxmox_host
from sentinel_blue.probes import run_probes
from sentinel_blue.probe_evidence import all_probes_healthy
from sentinel_blue.restoration import RestorePointStore
from sentinel_blue.scored_state import timer_scope, cron_scope
from sentinel_blue.state import read_private_json, write_private_json
from measurement import Measurement


class ScenarioFailure(ValueError):
    def __init__(self, result):
        self.result = result
        super().__init__('native lab scenario held; inspect its private result and Blue History before another fault')


def require_native_lab(args):
    if (not args.ack_disposable_vm or os.geteuid() != 0 or is_proxmox_host()
            or Path('/proc/1/comm').read_text().strip() != 'systemd'):
        raise ValueError('requires root on an explicitly acknowledged disposable VM with real systemd; Proxmox hosts refused')


def require_previous_finished(directory):
    entries = list(Path(directory).glob('scored-fault-*'))
    if len(entries) > 512:
        raise ValueError('lab evidence inventory exceeds its bound; review/archive it before more faults')
    for entry in entries:
        if not entry.is_dir() or entry.is_symlink():
            raise ValueError('lab evidence directory is ambiguous; review before another fault')
        result = read_private_json(entry / 'result.json')
        if not isinstance(result, dict) or result.get('status') not in {'recovered', 'prevented'}:
            raise ValueError('a prior lab scenario needs review before another injection')


def check_running(config, profile, manifest, client):
    dashboard = client.dashboard()
    governance = dashboard.get('controller', {}).get('governance') or {}
    if (governance.get('profile_fingerprint') != profile.fingerprint
            or governance.get('autonomy_mode') != 'guarded-autonomous'
            or governance.get('emergency_stopped') is not False
            or governance.get('automatic_recovery') is not True):
        raise ValueError('running controller must match the reviewed profile and allow automatic recovery')
    agents = [row for row in dashboard.get('agents', []) if row.get('agent_id') == 'local-linux']
    if len(agents) != 1 or agents[0].get('baseline_status') != 'approved':
        raise ValueError('local lab baseline is not approved')
    policy = dashboard.get('controller', {}).get('setup_redo_policy')
    if not isinstance(policy, dict) or policy.get('complete') is not True:
        raise ValueError('complete current recovery hold evidence is required before injection')
    from sentinel_blue.redo_governance import snapshot_hold
    if snapshot_hold(dashboard, 'local-linux', manifest['service_id'], time.time()):
        raise ValueError('Pause, a change grant or unresolved transaction holds this lab scenario')
    rows = [row for row in dashboard.get('controller', {}).get('service_recovery_status', [])
            if row.get('agent_id') == 'local-linux' and row.get('service') == manifest['service_id']]
    if len(rows) != 1 or rows[0].get('budget', {}).get('allowed') is not True:
        raise ValueError('recovery budget is unavailable or exhausted; no fault injected')
    if not profile.action_allowed('repair_service', automated=True,
                                   autonomy_mode='guarded-autonomous', emergency_stopped=False) or 'repair_service' not in manifest['allowed_automatic_actions']:
        raise ValueError('profile does not allow scoped automatic repair')
    from sentinel_blue.service_automation import LocalAutomation
    local = LocalAutomation(Path(config['directory']) / 'agent-state', profile, 'local-linux')
    control = local.read()
    if (local.sync() is not None or manifest['service_id'] in control['latches']
            or control['snapshot']['services'].get(manifest['service_id'], {}).get('paused') is True):
        raise ValueError('local inverse/Pause/synchronization hold blocks another lab fault')
    from sentinel_blue.mutation_ledger import MutationLedger
    if MutationLedger().automation_paused():
        raise ValueError('host-wide Pause or withdrawal holds another lab fault')


def corrupt_file(path, before, metadata, damaged):
    """Ordinary guarded write: never borrow Sentinel's immutable release path."""
    parent = RestorePointStore._open_parent_descriptor(path)
    descriptor = None
    try:
        descriptor = os.open(path.name, os.O_RDWR | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
        first = os.fstat(descriptor)
        if not stat.S_ISREG(first.st_mode) or first.st_nlink != 1:
            raise ValueError('lab file fault requires one unique regular file')
        data = os.read(descriptor, len(before) + 1)
        observed_meta = dict(metadata, mode=stat.S_IMODE(first.st_mode), uid=first.st_uid,
                             gid=first.st_gid, xattrs=RestorePointStore._capture_xattrs(descriptor))
        identity = lambda x: (x.st_dev, x.st_ino, x.st_mode, x.st_uid, x.st_gid,
                              x.st_nlink, x.st_size, x.st_mtime_ns, x.st_ctime_ns)
        if (data != before or not RestorePointStore._metadata_matches(metadata, observed_meta)
                or identity(first) != identity(os.fstat(descriptor))
                or identity(first) != identity(os.stat(path.name, dir_fd=parent, follow_symlinks=False))):
            raise ValueError('selected lab target changed before injection; preserve the newer state')
        os.lseek(descriptor, 0, os.SEEK_SET)
        view = memoryview(damaged)
        while view:
            written = os.write(descriptor, view)
            if written <= 0:
                raise OSError('lab fault write made no progress')
            view = view[written:]
        os.ftruncate(descriptor, len(damaged))
        os.fsync(descriptor)
    finally:
        if descriptor is not None:
            os.close(descriptor)
        if parent is not None:
            os.close(parent)


def run(args):
    require_native_lab(args)
    if type(args.timeout) is not int or not 15 <= args.timeout <= 600:
        raise ValueError('native scenario requires a 15..600 second timeout')
    config = read_private_json(Path(args.session))
    lock_path = Path(config['directory']) / 'scored-lab.lock'
    descriptor = os.open(lock_path, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    try:
        info = os.fstat(descriptor)
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid() or info.st_nlink != 1 or info.st_mode & 0o077:
            raise ValueError('lab scenario lock must be owned, private and unique')
        fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        require_previous_finished(config['directory'])
        return exercise(args, config)
    finally:
        os.close(descriptor)


def exercise(args, config):
    profile = load_event_profile(config['event_profile'])
    profile.require_range_ready()
    runtime = os.environ.get('SB_PYZ')
    if not runtime:
        raise ValueError('SB_PYZ must select the exact approved packaged lab runtime')
    profile.verify_release_file(runtime)
    if config.get('autonomy') != 'guarded-autonomous':
        raise ValueError('lab session must already be in reviewed guarded-autonomous mode')
    manifests = [row for row in profile.services if row['host'] == 'local-linux' and row['service_id'] == args.service]
    if len(manifests) != 1:
        raise ValueError('select exactly one service declared in the local lab')
    manifest = manifests[0]
    targets = [row for row in manifest.get('repair_policy', {}).get('scored_targets', []) if row['path'] == args.target]
    if len(targets) != 1:
        raise ValueError('target is not in this service’s approved scored recovery scope')
    target = targets[0]
    if target['kind'] not in {'content', 'seed', 'zone', 'cron', 'authorized_keys', 'credential', 'timers', 'cron_scope'}:
        raise ValueError('this lab does not tamper with program binaries or general host configuration')
    client = client_for(config)
    check_running(config, profile, manifest, client)
    def probes(deadline=None):
        return run_probes(
            manifest['expected_transactions'], list(profile.authorized_networks),
            authorized_hosts=list(profile.authorized_hosts), excluded_hosts=list(profile.excluded_hosts),
            deadline=deadline)
    initial_probes = probes(time.monotonic() + 15)
    if not all_probes_healthy(manifest['expected_transactions'], initial_probes):
        raise ValueError('all declared service/login/content transactions must pass before fault injection')
    state = Path(config['directory']) / 'agent-state'
    if not (state / 'restore-points').is_dir():
        raise ValueError('agent restore store is missing')
    from sentinel_blue.agent import restore_mirror_directory
    agent_points = RestorePointStore(state, mirror=restore_mirror_directory())
    path = Path(target['path']); before, metadata = agent_points._read_target(path)
    pin = agent_points._read_manifest().get(str(path))
    if (not pin or pin.get('sha256') != hashlib.sha256(before).hexdigest()
            or not agent_points._metadata_matches(pin, metadata)):
        raise ValueError('current target does not match its authenticated approved capture')
    if agent_points.approved_bytes(pin['sha256'], path) != before:
        raise ValueError('approved backup verification failed')
    directory = Path(config['directory']) / ('scored-fault-' + secrets.token_hex(8))
    directory.mkdir(mode=0o700)
    points = RestorePointStore(directory)
    capture = points.capture([{'path': str(path), 'sha256': pin['sha256'],
        'security_descriptor_sha256': points._metadata_security_descriptor_sha256(metadata)}])
    if not capture['success']:
        raise ValueError('private pre-fault evidence capture failed')
    measurement = Measurement(directory, manifest['expected_transactions'])
    measurement.sample(initial_probes, matched=True, phase='before-fault')
    result = {'schema': 1, 'status': 'prepared', 'service': args.service, 'target': str(path),
              'kind': target['kind'], 'recovered': False, 'fault_observed': False,
              'pre_fault_sha256': pin['sha256'], 'private_evidence': str(directory),
              'native_systemd': True, 'external_scoring_measured': False,
              'profile_fingerprint': profile.fingerprint}
    measurement.report(result)
    started = time.monotonic()
    try:
        # The healthy capture does not authorize a later fault after Pause or
        # a controller/profile change during preparation.
        check_running(config, profile, manifest, client)
        if agent_points._read_target(path) != (before, metadata):
            raise ValueError('selected target changed during lab preparation')
        result['status'] = 'injecting'
        measurement.report(result)
        inject(args, target, path, before, metadata, points)
        current, current_meta = points._read_target(path)
        if current == before and points._metadata_matches(metadata, current_meta):
            result['status'] = 'fault_not_observed'
            raise ScenarioFailure(result)
        result['fault_observed'] = True
        result['status'] = 'waiting_for_recovery'
        measurement.report(result)
        # A fault may be removed while a slow login probe completes. Recovery
        # requires a second exact state read after all transactions pass.
        while time.monotonic() - started < args.timeout:
            began = time.monotonic()
            error, matched, rows = '', None, None
            try:
                current, current_meta = points._read_target(path)
                matched = current == before and points._metadata_matches(metadata, current_meta)
                rows = probes(started + args.timeout)
                if matched and all_probes_healthy(manifest['expected_transactions'], rows):
                    current, current_meta = points._read_target(path)
                    matched = current == before and points._metadata_matches(metadata, current_meta)
            except (OSError, ValueError) as exc:
                error = type(exc).__name__
            if time.monotonic() - started > args.timeout:
                rows, error = None, 'ProbeDeadlineExceeded'
            sample = measurement.sample(rows, matched=matched, began=began, error_type=error)
            if (sample['baseline_matches'] is True and sample['healthy'] is True and not error
                    and time.monotonic() - started <= args.timeout):
                result['status'], result['recovered'] = 'recovered', True
                break
            time.sleep(min(1, max(0, args.timeout - (time.monotonic() - started))))
        if result['status'] == 'waiting_for_recovery':
            result['status'] = 'timed_out'
    except PermissionError as exc:
        # An EPERM by itself cannot establish successful prevention. Require
        # the configured native immutable bit, exact baseline, and real probes.
        try:
            from sentinel_blue.immutable_files import NativeFlags, IMMUTABLE
            protected = (result['status'] == 'injecting' and not result['fault_observed']
                         and str(path) in manifest['repair_policy'].get('immutable_files', [])
                         and exc.errno == errno.EPERM
                         and NativeFlags().snapshot(path)['flags'] & IMMUTABLE)
            current, current_meta = points._read_target(path)
            matched = current == before and points._metadata_matches(metadata, current_meta)
            rows = probes(started + args.timeout)
            current, current_meta = points._read_target(path)
            matched = matched and current == before and points._metadata_matches(metadata, current_meta)
            sample = measurement.sample(rows, matched=matched, phase='prevention')
            result['status'] = ('prevented' if protected and matched and sample['healthy'] is True
                                and time.monotonic() - started <= args.timeout else 'held')
        except (OSError, ValueError):
            result['status'] = 'held'
        result['error_type'] = type(exc).__name__
    except ScenarioFailure:
        pass
    except (Exception, KeyboardInterrupt) as exc:
        result['status'] = 'held'
        result['error_type'] = type(exc).__name__
    finally:
        result['elapsed_seconds'] = round(time.monotonic() - started, 3)
        try:
            result = measurement.report(result)
        finally:
            measurement.close()
    print(json.dumps(result, indent=2))
    if result['status'] not in {'recovered', 'prevented'}:
        raise ScenarioFailure(result)
    return result


def inject(args, target, path, before, metadata, points):
    command = lambda *args: subprocess.run(['systemctl', *args], check=True, capture_output=True, timeout=15)
    if target['kind'] == 'credential':
        record = json.loads(before)
        crypt = ctypes.CDLL('libcrypt.so.1').crypt
        crypt.argtypes = [ctypes.c_char_p, ctypes.c_char_p]; crypt.restype = ctypes.c_char_p
        hashed = crypt(secrets.token_urlsafe(32).encode(), b'$6$sentinel-lab$')
        if not hashed or not hashed.startswith(b'$6$'):
            raise ValueError('native test password hashing failed')
        record['password_hash'] = hashed.decode()
        record['aging'][0] = str(int(time.time() // 86400))
        from sentinel_blue.json_codec import canonical_json_bytes
        points._replace_target(path, canonical_json_bytes(record), metadata, expected_current=(before, metadata))
    elif target['kind'] == 'timers':
        name = timer_scope(path) + 'lab-' + secrets.token_hex(4) + '.timer'
        native = Path('/etc/systemd/system') / name
        data = ('[Unit]\nDescription=Sentinel disposable coverage fault\n[Timer]\nOnActiveSec=3600\n'
                'Unit=' + args.service + '\n[Install]\nWantedBy=timers.target\n').encode()
        with native.open('xb') as handle: handle.write(data)
        native.chmod(0o644)
        command('daemon-reload'); command('enable', '--', name); command('start', '--', name)
    elif target['kind'] == 'cron_scope':
        native = Path('/etc/cron.d') / (cron_scope(path) + 'lab-' + secrets.token_hex(4))
        with native.open('xb') as handle: handle.write(b'* * * * * root /usr/bin/true\n')
        native.chmod(0o644)
    else:
        damaged = (before + b'\n* * * * * root /usr/bin/true\n' if target['kind'] == 'cron'
                   else b'# Sentinel disposable coverage fault\n')
        corrupt_file(path, before, metadata, damaged)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--session', required=True, help='existing approved local lab session.json')
    parser.add_argument('--service', required=True)
    parser.add_argument('--target', required=True, help='exact approved scored target path from the manifest')
    parser.add_argument('--timeout', type=int, default=120, choices=range(15, 601), metavar='15..600')
    parser.add_argument('--ack-disposable-vm', action='store_true')
    run(parser.parse_args())
