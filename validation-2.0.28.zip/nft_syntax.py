"""Native nft JSON roundtrip in a separate network namespace, without base hooks.

Checks the production single-table JSON generator against a real interpreter.
This is not systemd-watchdog, reboot, lockout or external scoring acceptance.
Run through unshare --net only on an idle disposable root lab VM.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import secrets
import sys

if os.environ.get('SB_PYZ'):
    sys.path.insert(0, os.environ['SB_PYZ'])

from sentinel_blue.network_recovery_nft import NftBackend, native, transaction, normalize_table
from sentinel_blue.network_recovery_common import normalize_config
from sentinel_blue.state import write_private_json
from scored_scenarios import require_native_lab


def require_namespace():
    if os.stat('/proc/self/ns/net').st_ino == os.stat('/proc/1/ns/net').st_ino:
        raise ValueError('refuses the host network namespace; run with unshare --net on a disposable VM')
    capabilities = next(line.split()[1] for line in Path('/proc/self/status').read_text().splitlines()
                        if line.startswith('CapEff:'))
    if not int(capabilities, 16) & (1 << 12):
        raise ValueError('real native nft syntax acceptance requires CAP_NET_ADMIN')


def lab_case(table):
    config = normalize_config({'provider': 'nft', 'address': '127.0.0.1', 'family': 'inet',
                              'table': table, 'probes': [
                                  {'role': 'management', 'address': '127.0.0.1', 'port': 22},
                                  {'role': 'scoring', 'address': '127.0.0.1', 'port': 80}]})
    # Probes describe the normal generator contract. This syntax test never
    # executes them or claims they establish access from another machine.
    wanted = {'nftables': [{'table': {'family': 'inet', 'name': config['table']}},
              {'chain': {'family': 'inet', 'table': config['table'], 'name': 'checked_chain'}},
              {'rule': {'family': 'inet', 'table': config['table'], 'chain': 'checked_chain',
                        'expr': [{'counter': {'packets': 0, 'bytes': 0}}, {'accept': None}],
                        'comment': 'sentinel-lab-native-json'}}]}
    return config, wanted


def check(args):
    require_native_lab(args)
    require_namespace()
    config, wanted = lab_case('sb_lab_' + secrets.token_hex(8))
    backend = NftBackend(config, None)
    if not backend.nft:
        raise ValueError('nftables is not installed; no native acceptance claimed')
    result = {'schema': 1, 'status': 'running', 'checks': [],
              'scope': 'native nft JSON syntax/roundtrip only; private network namespace; no base hooks',
              'systemd_watchdog_tested': False, 'external_scoring_measured': False,
              'network_namespace_inode': os.stat('/proc/self/ns/net').st_ino,
              'host_network_namespace_inode': os.stat('/proc/1/ns/net').st_ino}
    write_private_json(Path(args.output), result)
    try:
        if backend.snapshot() is not None:
            raise ValueError('random lab table already exists; no write performed')
        for label, desired in [('create', wanted), ('delete', None), ('recreate_missing', wanted), ('delete_again', None)]:
            before = backend.snapshot()
            backend.validate_transition(before, desired)
            command = transaction(config, before, desired)
            native([backend.nft, '-j', '-f', '-'], command)
            after = backend.snapshot()
            if after != normalize_table(desired, config):
                raise ValueError('real nft roundtrip differs from the generated static baseline')
            result['checks'].append({'check': label, 'passed': True,
                                     'transaction_sha256': hashlib.sha256(command.encode()).hexdigest()})
            write_private_json(Path(args.output), result)
        result['status'] = 'passed'
    except (Exception, KeyboardInterrupt) as exc:
        result['status'] = 'held'
        result['error_type'] = type(exc).__name__
        raise
    finally:
        # Leaving unshare destroys this namespace and its tables. Never fall
        # back to flushing the host's ruleset when an assertion fails.
        write_private_json(Path(args.output), result)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True)
    parser.add_argument('--ack-disposable-vm', action='store_true')
    print(json.dumps(check(parser.parse_args()), indent=2))
