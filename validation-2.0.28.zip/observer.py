"""Read-only transaction observer, usable on a separate authorized lab VM.

An explicit vantage label describes placement; it does not prove host isolation.
No passwords, query results or raw response bodies are saved in sample evidence.
"""
from __future__ import annotations

import argparse
import ipaddress
import json
import os
from pathlib import Path
import secrets
import sys
import time
from urllib.parse import urlparse

if os.environ.get('SB_PYZ'):
    sys.path.insert(0, os.environ['SB_PYZ'])

from sentinel_blue.event_profile import load_event_profile
from sentinel_blue.probes import run_probes
from measurement import Measurement


def check_vantage(specs, vantage):
    if vantage != 'separate-host':
        return
    for spec in specs:
        host = spec.get('host') or spec.get('target', '')
        if '://' in host:
            host = urlparse(host).hostname or ''
        if not host or host.rstrip('.').casefold() == 'localhost':
            raise ValueError('separate-host measurements require remote service endpoints')
        try:
            address = ipaddress.ip_address(host)
        except ValueError:
            continue  # Approved DNS is still resolved/pinned by the real probe.
        if address.is_loopback or address.is_unspecified:
            raise ValueError('loopback/unspecified endpoints cannot establish separate-host scoring')


def observe(args, *, clock=time.monotonic, sleeper=time.sleep, probe=run_probes):
    if (type(args.seconds) is not int or not 15 <= args.seconds <= 3600
            or type(args.interval) is not int or not 1 <= args.interval <= 60
            or args.vantage not in {'same-host', 'separate-host'}):
        raise ValueError('observer requires 15..3600 seconds, 1..60 second cadence and an explicit vantage')
    profile = load_event_profile(args.event_profile)
    profile.require_range_ready()
    runtime = os.environ.get('SB_PYZ')
    if not runtime:
        raise ValueError('SB_PYZ must select the exact approved packaged lab runtime')
    profile.verify_release_file(runtime)
    matches = [row for row in profile.services if row['host'] == args.host and row['service_id'] == args.service]
    if len(matches) != 1 or not matches[0]['expected_transactions']:
        raise ValueError('select one reviewed service with declared transaction probes')
    specs = matches[0]['expected_transactions']
    check_vantage(specs, args.vantage)
    directory = Path(args.output) / ('probe-observer-' + secrets.token_hex(8))
    directory.mkdir(mode=0o700, parents=True)
    measurement = Measurement(directory, specs, clock=clock)
    result = {'schema': 1, 'status': 'running', 'host': args.host, 'service': args.service,
              'vantage_declared_by_operator': args.vantage,
              'observer_hostname': __import__('socket').gethostname(),
              'profile_fingerprint': profile.fingerprint, 'interval_seconds': args.interval,
              'requested_seconds': args.seconds, 'private_evidence': str(directory),
              'scope': 'reviewed transaction sampling; not proof of host isolation or competition uptime'}
    measurement.report(result)
    deadline = measurement.started + args.seconds
    next_due = measurement.started
    try:
        while clock() < deadline:
            sleeper(max(0, min(next_due, deadline) - clock()))
            if clock() >= deadline:
                break
            began = clock()
            error, rows = '', None
            try:
                rows = probe(specs, list(profile.authorized_networks),
                             authorized_hosts=list(profile.authorized_hosts),
                             excluded_hosts=list(profile.excluded_hosts),
                             deadline=min(deadline, began + args.interval))
            except Exception as exc:
                error = type(exc).__name__
            if clock() > min(deadline, began + args.interval):
                rows, error = None, 'ProbeDeadlineExceeded'
            measurement.sample(rows, began=began, error_type=error, phase='observer')
            next_due += args.interval
            # A slow probe does not backfill missed scoring opportunities as
            # successes. Mark every elapsed scheduled slot as unknown.
            while next_due < min(clock(), deadline):
                measurement.sample(None, error_type='MissedScheduledSample', phase='observer-gap')
                next_due += args.interval
        result['status'] = 'completed'
    except (Exception, KeyboardInterrupt) as exc:
        result['status'] = 'interrupted'
        result['error_type'] = type(exc).__name__
        raise
    finally:
        result['elapsed_seconds'] = round(clock() - measurement.started, 3)
        try:
            result = measurement.report(result)
        finally:
            measurement.close()
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--event-profile', required=True)
    parser.add_argument('--host', required=True)
    parser.add_argument('--service', required=True)
    parser.add_argument('--output', required=True, help='owned private evidence parent')
    parser.add_argument('--seconds', type=int, default=600)
    parser.add_argument('--interval', type=int, default=60)
    parser.add_argument('--vantage', choices=['same-host', 'separate-host'], required=True)
    print(json.dumps(observe(parser.parse_args()), indent=2))
