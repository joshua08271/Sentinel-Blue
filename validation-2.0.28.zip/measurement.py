"""Measured transaction samples; missing evidence never earns a passing sample.

These are sampled lab observations, not inferred continuous or event uptime.
Probe bodies, credentials, exception messages and raw protocol rows are omitted.
"""
from __future__ import annotations

import hashlib
import os
from pathlib import Path
import stat
import time

from sentinel_blue.json_codec import canonical_json_bytes
from sentinel_blue.probe_evidence import matching_probe_health
from sentinel_blue.state import write_private_json


def verdict(specs, rows):
    values = matching_probe_health(specs, rows, exact=True)
    if not specs or len(values) != len(specs):
        return None
    if any(value is False for value in values):
        return False
    return True if all(value is True for value in values) else None


def summary(samples):
    counts = {'passing': 0, 'failing': 0, 'unknown': 0}
    for sample in samples:
        value = sample['healthy']
        if value is not None and type(value) is not bool:
            raise ValueError('probe samples require three-state evidence')
        counts['unknown' if value is None else 'passing' if value else 'failing'] += 1
    total = sum(counts.values())
    return dict(counts, total=total,
                passing_sample_percent=round(100 * counts['passing'] / total, 3) if total else None,
                metric='transaction samples; unknown samples remain in the denominator',
                continuous_uptime_measured=False)


class Measurement:
    """Append and fsync each bounded, sanitized sample before reporting progress."""
    def __init__(self, directory, specs, *, clock=None):
        self.directory = Path(directory)
        info = self.directory.lstat()
        if (not stat.S_ISDIR(info.st_mode) or info.st_uid != os.geteuid()
                or stat.S_IMODE(info.st_mode) & 0o077):
            raise ValueError('lab evidence requires an owned private directory')
        self.specs = specs
        self.clock = time.monotonic if clock is None else clock
        self.started = self.clock()
        self.samples = []
        self.path = self.directory / 'probe-timeline.jsonl'
        self.fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        self.contract_sha256 = hashlib.sha256(canonical_json_bytes(specs)).hexdigest()

    def close(self):
        if self.fd is not None:
            os.close(self.fd)
            self.fd = None

    def sample(self, rows=None, *, matched=None, error_type='', began=None, phase='recovery'):
        if self.fd is None or len(self.samples) >= 7201:
            raise ValueError('lab probe evidence is closed or exceeds its bounded sample count')
        ended = self.clock()
        began = ended if began is None else began
        if ended < began or began < self.started:
            raise ValueError('lab measurement clock regressed')
        if matched is not None and type(matched) is not bool:
            raise ValueError('baseline match must be measured or unknown')
        # Store only slot verdicts. A backend's messages or rows can contain
        # private query results, login material or page bodies.
        values = matching_probe_health(self.specs, rows, exact=True)
        sample = {'offset_seconds': round(began - self.started, 6),
                  'completed_seconds': round(ended - self.started, 6),
                  'healthy': verdict(self.specs, rows), 'probe_verdicts': values,
                  'baseline_matches': matched, 'phase': phase,
                  'error_type': error_type}
        data = canonical_json_bytes(sample) + b'\n'
        view = memoryview(data)
        while view:
            written = os.write(self.fd, view)
            if written <= 0:
                raise OSError('lab sample write made no progress')
            view = view[written:]
        os.fsync(self.fd)
        self.samples.append(sample)
        return sample

    def report(self, result):
        # Baseline preflight is kept in the timeline, outside the fault-window
        # denominator. Otherwise a one-poll failure gains an artificial pass.
        measured = [sample for sample in self.samples if sample['phase'] != 'before-fault']
        value = dict(result, probe_measurement=summary(measured),
                     probe_contract_sha256=self.contract_sha256,
                     probe_timeline=str(self.path))
        write_private_json(self.directory / 'result.json', value)
        return value
