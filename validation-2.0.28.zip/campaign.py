"""Repeat reviewed scored-state faults, stopping on the first unresolved result.

Does not select a broader scope, approve profiles, bypass recovery budgets,
resume automation or retry an uncertain mutation. Run on a disposable VM only.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import secrets
import sys
import time
from types import SimpleNamespace

if os.environ.get('SB_PYZ'):
    sys.path.insert(0, os.environ['SB_PYZ'])

from sentinel_blue.state import read_private_json, write_private_json
from scored_scenarios import run, ScenarioFailure, require_native_lab


def validate_plan(plan):
    if (not isinstance(plan, dict) or set(plan) != {'schema', 'rounds', 'gap_seconds', 'scenarios'}
            or type(plan['schema']) is not int or plan['schema'] != 1
            or type(plan['rounds']) is not int or not 1 <= plan['rounds'] <= 16
            or type(plan['gap_seconds']) is not int or not 15 <= plan['gap_seconds'] <= 3600
            or not isinstance(plan['scenarios'], list) or not 1 <= len(plan['scenarios']) <= 16
            or plan['rounds'] * len(plan['scenarios']) > 64):
        raise ValueError('campaign requires 1..64 faults, 1..16 rounds and a 15..3600 second gap')
    seen = set()
    for row in plan['scenarios']:
        if (not isinstance(row, dict) or set(row) != {'service', 'target', 'timeout'}
                or not isinstance(row['service'], str) or not row['service']
                or not isinstance(row['target'], str) or not row['target'].startswith('/')
                or type(row['timeout']) is not int or not 15 <= row['timeout'] <= 600):
            raise ValueError('each scenario requires one exact service/target and a 15..600 second timeout')
        key = (row['service'], row['target'])
        if key in seen:
            raise ValueError('duplicate campaign target; use rounds for repetition')
        seen.add(key)
    return plan


def execute(args, *, runner=run, sleeper=time.sleep):
    require_native_lab(args)
    plan = validate_plan(read_private_json(Path(args.plan), 65536))
    config = read_private_json(Path(args.session))
    directory = Path(config['directory']) / ('scored-campaign-' + secrets.token_hex(8))
    directory.mkdir(mode=0o700)
    result = {'schema': 1, 'status': 'running', 'requested_faults': plan['rounds'] * len(plan['scenarios']),
              'scenarios': [], 'private_evidence': str(directory),
              'scope': 'selected native lab faults; local transaction samples; not event uptime'}
    write_private_json(directory / 'campaign.json', result)
    try:
        for round_number in range(1, plan['rounds'] + 1):
            for row in plan['scenarios']:
                if result['scenarios']:
                    # Recovery cooldown counts from the repair, not injection.
                    # The next scenario independently rechecks the actual budget.
                    sleeper(plan['gap_seconds'])
                options = SimpleNamespace(session=args.session, ack_disposable_vm=True, **row)
                try:
                    measured = runner(options)
                except ScenarioFailure as exc:
                    measured = exc.result
                except (Exception, KeyboardInterrupt) as exc:
                    result['scenarios'].append(dict(row, round=round_number, status='held',
                                                     error_type=type(exc).__name__))
                    raise
                if not isinstance(measured, dict) or measured.get('status') not in {'recovered', 'prevented'}:
                    if not isinstance(measured, dict):
                        raise ValueError('scenario returned no bounded recovery evidence')
                    result['scenarios'].append(dict(measured, round=round_number))
                    result['status'] = 'held'
                    write_private_json(directory / 'campaign.json', result)
                    return result
                result['scenarios'].append(dict(measured, round=round_number))
                write_private_json(directory / 'campaign.json', result)
        result['status'] = 'completed'
    except (Exception, KeyboardInterrupt) as exc:
        result['status'] = 'held'
        result['error_type'] = type(exc).__name__
        write_private_json(directory / 'campaign.json', result)
        raise
    # Do not pool incompatible probe contracts or different durations into an
    # impressive uptime percentage. Each fault retains its own full timeline.
    result['completed_faults'] = sum(row.get('status') == 'recovered' for row in result['scenarios'])
    result['prevented_faults'] = sum(row.get('status') == 'prevented' for row in result['scenarios'])
    recovered = [row['elapsed_seconds'] for row in result['scenarios'] if row.get('status') == 'recovered']
    result['maximum_recovery_seconds'] = max(recovered) if recovered else None
    write_private_json(directory / 'campaign.json', result)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--session', required=True)
    parser.add_argument('--plan', required=True, help='private JSON with exact approved targets')
    parser.add_argument('--ack-disposable-vm', action='store_true')
    result = execute(parser.parse_args())
    print(json.dumps(result, indent=2))
    sys.exit(0 if result['status'] == 'completed' else 2)
